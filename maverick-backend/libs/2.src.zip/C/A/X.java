package C.A;

import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEval;

public class X
  implements HandEval
{
  static final int j = 1;
  static final int g = 2;
  static final int n = 3;
  static final int i = 4;
  static final int m = 5;
  static final int f = 6;
  static final int h = 7;
  static final int d = 8;
  static final int e = 9;
  static final short[][] k = { { 0, 322, 321, 320, 319, 318, 317, 316, 315, 314, 313, 312, 311 }, { 310, 0, 309, 308, 307, 306, 305, 304, 303, 302, 301, 300, 299 }, { 298, 297, 0, 296, 295, 294, 293, 292, 291, 290, 289, 288, 287 }, { 286, 285, 284, 0, 283, 282, 281, 280, 279, 278, 277, 276, 275 }, { 274, 273, 272, 271, 0, 270, 269, 268, 267, 266, 265, 264, 263 }, { 262, 261, 260, 259, 258, 0, 257, 256, 255, 254, 253, 252, 251 }, { 250, 249, 248, 247, 246, 245, 0, 244, 243, 242, 241, 240, 239 }, { 238, 237, 236, 235, 234, 233, 232, 0, 231, 230, 229, 228, 227 }, { 226, 225, 224, 223, 222, 221, 220, 219, 0, 218, 217, 216, 215 }, { 214, 213, 212, 211, 210, 209, 208, 207, 206, 0, 205, 204, 203 }, { 202, 201, 200, 199, 198, 197, 196, 195, 194, 193, 0, 192, 191 }, { 190, 189, 188, 187, 186, 185, 184, 183, 182, 181, 180, 0, 179 }, { 178, 177, 176, 175, 174, 173, 172, 171, 170, 169, 168, 167 } };
  static final short[][] c = { R.A, Q.A, d.A, E.A, J.A, _.A, e.A, V.A, Z.A, g.A, c.A, P.A, Y.A };
  static final short[][] b = { A.A, G.A, T.A, a.A, f.A, W.A, M.A, L.A, N.A, U.A, K.A, F.A, O.A };
  static final int[] l = { 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096 };

  public static int F(int paramInt)
  {
    if ((paramInt < 1) || (paramInt > 7462))
      return -1;
    if (paramInt > 6185)
      return 9;
    if (paramInt > 3325)
      return 8;
    if (paramInt > 2467)
      return 7;
    if (paramInt > 1609)
      return 6;
    if (paramInt > 1599)
      return 5;
    if (paramInt > 322)
      return 4;
    if (paramInt > 166)
      return 3;
    if (paramInt > 10)
      return 2;
    return 1;
  }

  public static String D(int paramInt)
  {
    int i1 = F(paramInt);
    return E(i1);
  }

  public static String E(int paramInt)
  {
    if (paramInt == 9)
      return "High Card";
    if (paramInt == 8)
      return "One Pair";
    if (paramInt == 7)
      return "Two Pair";
    if (paramInt == 6)
      return "Three of a Kind";
    if (paramInt == 5)
      return "Straight";
    if (paramInt == 4)
      return "Flush";
    if (paramInt == 3)
      return "Full House";
    if (paramInt == 2)
      return "Four of a Kind";
    if (paramInt == 1)
      return "Straight Flush";
    return "Invalid Hand";
  }

  public static String B(long paramLong)
  {
    String str1 = "23456789TJQKA";
    String str2 = " ";
    int i2 = (int)(paramLong & 0x1FFF);
    for (int i1 = 12; i1 >= 0; i1--)
      if ((i2 & l[i1]) != 0)
        str2 = str2.concat(str1.substring(i1, i1 + 1) + "c ");
    i2 = (int)(paramLong >> 13 & 0x1FFF);
    for (i1 = 12; i1 >= 0; i1--)
      if ((i2 & l[i1]) != 0)
        str2 = str2.concat(str1.substring(i1, i1 + 1) + "d ");
    i2 = (int)(paramLong >> 26 & 0x1FFF);
    for (i1 = 12; i1 >= 0; i1--)
      if ((i2 & l[i1]) != 0)
        str2 = str2.concat(str1.substring(i1, i1 + 1) + "h ");
    i2 = (int)(paramLong >> 39 & 0x1FFF);
    for (i1 = 12; i1 >= 0; i1--)
      if ((i2 & l[i1]) != 0)
        str2 = str2.concat(str1.substring(i1, i1 + 1) + "s ");
    return str2;
  }

  public static String C(int paramInt)
  {
    String str1 = "";
    String str2 = Integer.toBinaryString(paramInt);
    int i1 = 13 - str2.length();
    for (int i2 = 0; i2 < i1; i2++)
      str1 = str1.concat("0");
    return str1 + str2;
  }

  public static int C(long paramLong)
  {
    int i3 = 0;
    int i4 = (int)(paramLong & 0x1FFF);
    paramLong >>= 13;
    int i5 = (int)(paramLong & 0x1FFF);
    paramLong >>= 13;
    int i6 = (int)(paramLong & 0x1FFF);
    paramLong >>= 13;
    int i7 = (int)(paramLong & 0x1FFF);
    i3 = b.A[i4] | b.A[i5] | b.A[i6] | b.A[i7];
    if (i3 > 0)
      return i3;
    int i8 = i4 | i5 | i6 | i7;
    i3 = H.A[i8];
    if (i3 > 0)
      return i3;
    int i9 = i4 & i5 & i6 & i7;
    int i2;
    if (i9 > 0)
    {
      i1 = C.A[i9];
      i2 = C.A[(i9 ^ i8)];
      i3 = k[i1][i2] - 156;
      return i3;
    }
    int i10 = S.A[i8];
    int i11 = i4 ^ i5 ^ i6 ^ i7;
    if (i10 == 6)
    {
      i1 = C.A[(i8 ^ i11)];
      i3 = c[i1][i11];
      return i3;
    }
    if ((i8 == i11) && (i10 == 5))
    {
      i12 = i4 & i5 | i6 & i7;
      i1 = C.A[i12];
      i3 = b[i1][(i12 ^ i11)];
      return i3;
    }
    int i12 = S.A[i11];
    int i1 = i10 + i12;
    int i14;
    if ((i1 == 8) || (i1 == 5))
    {
      i14 = i8 ^ i11;
      i1 = C.A[i14];
      i14 ^= l[i1];
      i2 = C.A[i14];
      int i13;
      if (i12 == 3)
      {
        i13 = C.A[i11];
      }
      else
      {
        i14 ^= l[i2];
        i13 = C.A[(i14 | i11)];
      }
      i3 = D.D[i2][(i1 - i2 - 1)][i13];
      return i3;
    }
    if (i10 == 4)
    {
      i14 = i8 ^ i11;
      i2 = C.A[i14];
      i14 = i4 & i5 ^ i6 & i7;
      i1 = C.A[(i11 & i14)];
    }
    else if (i12 == 1)
    {
      i1 = C.A[i11];
      i2 = C.A[(i11 ^ i8)];
    }
    else
    {
      i14 = i4 & i5 | i6 & i7;
      i1 = C.A[i14];
      i14 ^= l[i1];
      i2 = C.A[i14];
    }
    i3 = k[i1][i2];
    return i3;
  }

  public short A(long paramLong)
  {
    int i10 = (int)(paramLong & 0x1FFF);
    paramLong >>= 13;
    int i11 = (int)(paramLong & 0x1FFF);
    paramLong >>= 13;
    int i12 = (int)(paramLong & 0x1FFF);
    paramLong >>= 13;
    int i13 = (int)(paramLong & 0x1FFF);
    short s = (short)(b.A[i10] | b.A[i11] | b.A[i12] | b.A[i13]);
    if (s != 0)
      return s;
    int i6 = i10 | i11 | i12 | i13;
    s = I.A[i6];
    if (s != 0)
      return s;
    int i7 = i10 & i11 & i12 & i13;
    int i2;
    if (i7 != 0)
    {
      i1 = C.A[i7];
      i2 = C.A[(i6 ^ i7)];
      s = (short)(B.A[i1][i2] - 156);
      return s;
    }
    int i4 = S.A[i6];
    int i8 = i10 ^ i11 ^ i12 ^ i13;
    if (i4 == 4)
    {
      i1 = C.A[(i6 ^ i8)];
      s = c[i1][i8];
      return s;
    }
    if (i4 == 2)
    {
      i1 = C.A[i8];
      i2 = C.A[(i8 ^ i6)];
      s = B.A[i1][i2];
      return s;
    }
    int i5 = S.A[i8];
    if (i5 == 1)
    {
      i9 = i6 ^ i8;
      i1 = C.A[i9];
      i9 ^= l[i1];
      i2 = C.A[i9];
      int i3 = C.A[i8];
      s = D.D[i2][(i1 - i2 - 1)][i3];
      return s;
    }
    int i9 = i10 & i11 | i12 & i13;
    int i1 = C.A[i9];
    s = b[i1][(i9 ^ i8)];
    return s;
  }

  public int rankHand(Hand paramHand)
  {
    switch (paramHand.size())
    {
    case 7:
      return rankHand7(paramHand);
    case 6:
      return rankHand6(paramHand);
    case 5:
      return rankHand5(paramHand);
    }
    if (!$assertionsDisabled)
      throw new AssertionError();
    return -1;
  }

  public final int rankHand7(Hand paramHand)
  {
    long l1 = 0L;
    l1 |= 1L << paramHand.getCardIndex(1);
    l1 |= 1L << paramHand.getCardIndex(2);
    l1 |= 1L << paramHand.getCardIndex(3);
    l1 |= 1L << paramHand.getCardIndex(4);
    l1 |= 1L << paramHand.getCardIndex(5);
    l1 |= 1L << paramHand.getCardIndex(6);
    l1 |= 1L << paramHand.getCardIndex(7);
    return 7462 - C(l1);
  }

  public int rankHand6(Hand paramHand)
  {
    Hand localHand = new Hand();
    int i1 = -1;
    for (int i2 = 1; i2 <= 6; i2++)
    {
      localHand.makeEmpty();
      for (int i3 = 1; i3 <= 6; i3++)
        if (i2 != i3)
          localHand.addCard(paramHand.getCardIndex(i3));
      i3 = rankHand5(localHand);
      if (i3 > i1)
        i1 = i3;
    }
    return i1;
  }

  public int rankHand5(Hand paramHand)
  {
    assert (paramHand.size() == 5);
    long l1 = 0L;
    l1 |= 1L << paramHand.getCardIndex(1);
    l1 |= 1L << paramHand.getCardIndex(2);
    l1 |= 1L << paramHand.getCardIndex(3);
    l1 |= 1L << paramHand.getCardIndex(4);
    l1 |= 1L << paramHand.getCardIndex(5);
    return 7462 - A(l1);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     C.A.X
 * JD-Core Version:    0.6.2
 */