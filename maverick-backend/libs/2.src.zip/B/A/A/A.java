package B.A.A;

import java.io.PrintStream;
import java.util.Vector;

class A
{
  private Vector A = new Vector();

  public void A(int paramInt1, int paramInt2)
  {
    if (paramInt1 >= this.A.size())
    {
      this.A.add(paramInt1, new Integer(paramInt2));
    }
    else
    {
      int i = paramInt2 - A(paramInt1);
      if (i > 0)
        for (int j = paramInt1; j < this.A.size(); j++)
          this.A.set(j, new Integer(A(j) + i));
    }
  }

  public int A(int paramInt)
  {
    return ((Integer)this.A.get(paramInt)).intValue();
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer(getClass().getName() + " {");
    for (int i = 0; i < this.A.size(); i++)
    {
      localStringBuffer.append(this.A.get(i));
      if (i < this.A.size() - 1)
        localStringBuffer.append(',');
    }
    localStringBuffer.append('}');
    return localStringBuffer.toString();
  }

  public static void A(String[] paramArrayOfString)
  {
    A localA = new A();
    localA.A(0, 10);
    localA.A(1, 20);
    localA.A(2, 30);
    System.out.println(localA);
    localA.A(1, 25);
    System.out.println(localA);
    System.out.println(localA.A(0));
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     B.A.A.A
 * JD-Core Version:    0.6.2
 */