package B.A.A;

import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

public class B extends FlowLayout
  implements LayoutManager, Serializable
{
  public static final String B = "br";
  public static final String A = "p";
  public static final String H = "tab";
  public static final String G = "hfill";
  public static final String D = "vfill";
  public static final String LEFT = "left";
  public static final String RIGHT = "right";
  public static final String CENTER = "center";
  public static final String J = "vtop";
  public static final String E = "vcenter";
  Map C = new HashMap();
  String I = "vcenter";
  int hgap;
  int vgap;
  Insets F;
  Insets K = new Insets(0, 0, 0, 0);

  public B()
  {
    this(10, 5);
  }

  public B(int paramInt1, int paramInt2)
  {
    this.hgap = paramInt1;
    this.vgap = paramInt2;
    A(new Insets(0, paramInt1, paramInt1, paramInt1));
  }

  public int getHgap()
  {
    return this.hgap;
  }

  public void setHgap(int paramInt)
  {
    this.hgap = paramInt;
  }

  public int getVgap()
  {
    return this.vgap;
  }

  public Insets A()
  {
    return this.F;
  }

  public void A(Insets paramInsets)
  {
    this.F = paramInsets;
  }

  protected Insets B(Container paramContainer)
  {
    Insets localInsets = paramContainer.getInsets();
    this.K.top = (localInsets.top + this.F.top);
    this.K.left = (localInsets.left + this.F.left);
    this.K.bottom = (localInsets.bottom + this.F.bottom);
    this.K.right = (localInsets.right + this.F.right);
    return this.K;
  }

  public void setVgap(int paramInt)
  {
    this.vgap = paramInt;
  }

  public void addLayoutComponent(String paramString, Component paramComponent)
  {
    this.C.put(paramComponent, paramString);
  }

  public void removeLayoutComponent(Component paramComponent)
  {
    this.C.remove(paramComponent);
  }

  boolean D(Component paramComponent)
  {
    String str = (String)this.C.get(paramComponent);
    return (str != null) && ((str.indexOf("br") != -1) || (str.indexOf("p") != -1));
  }

  boolean C(Component paramComponent)
  {
    return A(paramComponent, "hfill");
  }

  boolean B(Component paramComponent)
  {
    return A(paramComponent, "vfill");
  }

  boolean A(Component paramComponent, String paramString)
  {
    String str = (String)this.C.get(paramComponent);
    if (str == null)
      return false;
    StringTokenizer localStringTokenizer = new StringTokenizer(str);
    while (localStringTokenizer.hasMoreTokens())
      if (localStringTokenizer.nextToken().equals(paramString))
        return true;
    return false;
  }

  protected A A(Container paramContainer)
  {
    A localA = new A();
    int i = paramContainer.getComponentCount();
    int j = 0;
    int k = 0;
    for (int m = 0; m < i; m++)
    {
      Component localComponent = paramContainer.getComponent(m);
      if ((D(localComponent)) || (m == 0))
      {
        j = 0;
        k = 0;
      }
      else
      {
        j += this.hgap;
      }
      if (A(localComponent, "tab"))
      {
        localA.A(k, j);
        j = localA.A(k++);
      }
      Dimension localDimension = localComponent.getPreferredSize();
      j += localDimension.width;
    }
    return localA;
  }

  public Dimension preferredLayoutSize(Container paramContainer)
  {
    synchronized (paramContainer.getTreeLock())
    {
      Dimension localDimension1 = new Dimension(0, 0);
      Dimension localDimension2 = new Dimension(0, 0);
      int i = paramContainer.getComponentCount();
      int j = 1;
      int k = 0;
      A localA = A(paramContainer);
      for (int m = 0; m < i; m++)
      {
        Component localComponent = paramContainer.getComponent(m);
        if (D(localComponent))
        {
          k = 0;
          localDimension1.width = Math.max(localDimension1.width, localDimension2.width);
          localDimension1.height += localDimension2.height + this.vgap;
          if (A(localComponent, "p"))
            localDimension1.height += 2 * this.vgap;
          localDimension2 = new Dimension(0, 0);
        }
        if (A(localComponent, "tab"))
          localDimension2.width = localA.A(k++);
        Dimension localDimension3 = localComponent.getPreferredSize();
        localDimension2.height = Math.max(localDimension2.height, localDimension3.height);
        if (j != 0)
          j = 0;
        else
          localDimension2.width += this.hgap;
        localDimension2.width += localDimension3.width;
      }
      localDimension1.width = Math.max(localDimension1.width, localDimension2.width);
      localDimension1.height += localDimension2.height;
      Insets localInsets = B(paramContainer);
      localDimension1.width += localInsets.left + localInsets.right;
      localDimension1.height += localInsets.top + localInsets.bottom;
      return localDimension1;
    }
  }

  public Dimension minimumLayoutSize(Container paramContainer)
  {
    synchronized (paramContainer.getTreeLock())
    {
      Dimension localDimension1 = new Dimension(0, 0);
      Dimension localDimension2 = new Dimension(0, 0);
      int i = paramContainer.getComponentCount();
      int j = 1;
      int k = 0;
      A localA = A(paramContainer);
      for (int m = 0; m < i; m++)
      {
        Component localComponent = paramContainer.getComponent(m);
        if (D(localComponent))
        {
          k = 0;
          localDimension1.width = Math.max(localDimension1.width, localDimension2.width);
          localDimension1.height += localDimension2.height + this.vgap;
          if (A(localComponent, "p"))
            localDimension1.height += 2 * this.vgap;
          localDimension2 = new Dimension(0, 0);
        }
        if (A(localComponent, "tab"))
          localDimension2.width = localA.A(k++);
        Dimension localDimension3 = localComponent.getMinimumSize();
        localDimension2.height = Math.max(localDimension2.height, localDimension3.height);
        if (j != 0)
          j = 0;
        else
          localDimension2.width += this.hgap;
        localDimension2.width += localDimension3.width;
      }
      localDimension1.width = Math.max(localDimension1.width, localDimension2.width);
      localDimension1.height += localDimension2.height;
      Insets localInsets = B(paramContainer);
      localDimension1.width += localInsets.left + localInsets.right;
      localDimension1.height += localInsets.top + localInsets.bottom;
      return localDimension1;
    }
  }

  protected void A(Container paramContainer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean, A paramA)
  {
    synchronized (paramContainer.getTreeLock())
    {
      switch (getAlignment())
      {
      case 0:
        paramInt1 += (paramBoolean ? 0 : paramInt3);
        break;
      case 1:
        paramInt1 += paramInt3 / 2;
        break;
      case 2:
        paramInt1 += (paramBoolean ? paramInt3 : 0);
        break;
      case 3:
        break;
      case 4:
        paramInt1 += paramInt3;
      }
      int i = 0;
      for (int j = paramInt5; j < paramInt6; j++)
      {
        Component localComponent = paramContainer.getComponent(j);
        if (A(localComponent, "tab"))
          paramInt1 = B(paramContainer).left + paramA.A(i++);
        int k = this.I == "vtop" ? 0 : (paramInt4 - localComponent.getHeight()) / 2;
        if (paramBoolean)
          localComponent.setLocation(paramInt1, paramInt2 + k);
        else
          localComponent.setLocation(paramContainer.getWidth() - paramInt1 - localComponent.getWidth(), paramInt2 + k);
        paramInt1 += localComponent.getWidth() + this.hgap;
      }
    }
  }

  protected void A(Container paramContainer, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    synchronized (paramContainer.getTreeLock())
    {
      for (int i = paramInt3; i < paramInt4; i++)
      {
        Component localComponent = paramContainer.getComponent(i);
        localComponent.setLocation(localComponent.getX() + paramInt1, localComponent.getY() + paramInt2);
      }
    }
  }

  protected void A(Component paramComponent)
  {
    if (A(paramComponent, "left"))
      setAlignment(0);
    else if (A(paramComponent, "right"))
      setAlignment(2);
    else if (A(paramComponent, "center"))
      setAlignment(1);
    if (A(paramComponent, "vtop"))
      this.I = "vtop";
    else if (A(paramComponent, "vcenter"))
      this.I = "vcenter";
  }

  public void layoutContainer(Container paramContainer)
  {
    setAlignment(0);
    synchronized (paramContainer.getTreeLock())
    {
      Insets localInsets = B(paramContainer);
      int i = paramContainer.getWidth() - (localInsets.left + localInsets.right);
      int j = paramContainer.getHeight() - (localInsets.top + localInsets.bottom);
      int k = paramContainer.getComponentCount();
      int m = 0;
      int n = localInsets.top + this.vgap;
      int i1 = 0;
      int i2 = 0;
      int i3 = 0;
      boolean bool = paramContainer.getComponentOrientation().isLeftToRight();
      Object localObject1 = null;
      Object localObject2 = null;
      A localA = A(paramContainer);
      int i4 = 0;
      for (int i5 = 0; i5 < k; i5++)
      {
        Component localComponent = paramContainer.getComponent(i5);
        Dimension localDimension = localComponent.getPreferredSize();
        localComponent.setSize(localDimension.width, localDimension.height);
        if (D(localComponent))
          i4 = 0;
        if (A(localComponent, "tab"))
          m = localA.A(i4++);
        if (!D(localComponent))
        {
          if ((i5 > 0) && (!A(localComponent, "tab")))
            m += this.hgap;
          m += localDimension.width;
          i1 = Math.max(i1, localDimension.height);
        }
        else
        {
          if ((localObject2 != null) && (i3 == 0))
            i3 = i5;
          if (localObject1 != null)
          {
            localObject1.setSize(localObject1.getWidth() + i - m, localObject1.getHeight());
            m = i;
          }
          A(paramContainer, localInsets.left, n, i - m, i1, i2, i5, bool, localA);
          m = localDimension.width;
          n += this.vgap + i1;
          if (A(localComponent, "p"))
            n += 2 * this.vgap;
          i1 = localDimension.height;
          i2 = i5;
          localObject1 = null;
        }
        if (C(localComponent))
          localObject1 = localComponent;
        if (B(localComponent))
          localObject2 = localComponent;
        A(localComponent);
      }
      if ((localObject2 != null) && (i3 == 0))
        i3 = k;
      if (localObject1 != null)
      {
        localObject1.setSize(localObject1.getWidth() + i - m, localObject1.getHeight());
        m = i;
      }
      A(paramContainer, localInsets.left, n, i - m, i1, i2, k, bool, localA);
      i5 = j - (n + i1);
      if ((i5 != 0) && (localObject2 != null))
      {
        localObject2.setSize(localObject2.getWidth(), i5 + localObject2.getHeight());
        A(paramContainer, 0, i5, i3, k);
      }
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     B.A.A.B
 * JD-Core Version:    0.6.2
 */