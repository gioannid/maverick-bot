package com.sun.crypto.provider;

import java.security.InvalidKeyException;

final class SunJCE_p extends SunJCE_h
{
  private final byte[] a = new byte[this.b];
  private byte[] b = null;

  SunJCE_p(SunJCE_e paramSunJCE_e)
  {
    super(paramSunJCE_e);
  }

  String a()
  {
    return "PCBC";
  }

  void a(boolean paramBoolean, String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws InvalidKeyException
  {
    if ((paramArrayOfByte1 == null) || (paramArrayOfByte2 == null) || (paramArrayOfByte2.length != this.b))
      throw new InvalidKeyException("Internal error");
    this.c = paramArrayOfByte2;
    b();
    this.a.a(paramBoolean, paramString, paramArrayOfByte1);
  }

  void b()
  {
    System.arraycopy(this.c, 0, this.a, 0, this.b);
  }

  void c()
  {
    if (this.b == null)
      this.b = new byte[this.b];
    System.arraycopy(this.a, 0, this.b, 0, this.b);
  }

  void d()
  {
    System.arraycopy(this.b, 0, this.a, 0, this.b);
  }

  void a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    int j = paramInt1 + paramInt2;
    while (paramInt1 < j)
    {
      for (int i = 0; i < this.b; i++)
      {
        int tmp29_27 = i;
        byte[] tmp29_24 = this.a;
        tmp29_24[tmp29_27] = ((byte)(tmp29_24[tmp29_27] ^ paramArrayOfByte1[(i + paramInt1)]));
      }
      this.a.a(this.a, 0, paramArrayOfByte2, paramInt3);
      for (i = 0; i < this.b; i++)
        this.a[i] = ((byte)(paramArrayOfByte1[(i + paramInt1)] ^ paramArrayOfByte2[(i + paramInt3)]));
      paramInt1 += this.b;
      paramInt3 += this.b;
    }
  }

  void b(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    int j = paramInt1 + paramInt2;
    while (paramInt1 < j)
    {
      this.a.b(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt3);
      for (int i = 0; i < this.b; i++)
      {
        int tmp43_42 = (i + paramInt3);
        byte[] tmp43_36 = paramArrayOfByte2;
        tmp43_36[tmp43_42] = ((byte)(tmp43_36[tmp43_42] ^ this.a[i]));
      }
      for (i = 0; i < this.b; i++)
        this.a[i] = ((byte)(paramArrayOfByte2[(i + paramInt3)] ^ paramArrayOfByte1[(i + paramInt1)]));
      paramInt3 += this.b;
      paramInt1 += this.b;
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.sun.crypto.provider.SunJCE_p
 * JD-Core Version:    0.6.2
 */