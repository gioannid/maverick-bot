package com.sun.crypto.provider;

import java.security.InvalidKeyException;

final class SunJCE_n extends SunJCE_h
{
  private final byte[] a;
  private final byte[] b;
  private int c;
  private byte[] d = null;

  SunJCE_n(SunJCE_e paramSunJCE_e, int paramInt)
  {
    super(paramSunJCE_e);
    if (paramInt > this.b)
      paramInt = this.b;
    this.c = paramInt;
    this.a = new byte[this.b];
    this.b = new byte[this.b];
  }

  String a()
  {
    return "CFB";
  }

  void a(boolean paramBoolean, String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws InvalidKeyException
  {
    if ((paramArrayOfByte1 == null) || (paramArrayOfByte2 == null) || (paramArrayOfByte2.length != this.b))
      throw new InvalidKeyException("Internal error");
    this.c = paramArrayOfByte2;
    b();
    this.a.a(false, paramString, paramArrayOfByte1);
  }

  void b()
  {
    System.arraycopy(this.c, 0, this.b, 0, this.b);
  }

  void c()
  {
    if (this.d == null)
      this.d = new byte[this.b];
    System.arraycopy(this.b, 0, this.d, 0, this.b);
  }

  void d()
  {
    System.arraycopy(this.d, 0, this.b, 0, this.b);
  }

  void a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    int j = this.b - this.c;
    int k = paramInt2 / this.c;
    int m = paramInt2 % this.c;
    int i;
    if (j == 0)
    {
      while (k > 0)
      {
        this.a.a(this.b, 0, this.a, 0);
        for (i = 0; i < this.b; i++)
        {
          byte tmp94_93 = ((byte)(this.a[i] ^ paramArrayOfByte1[(i + paramInt1)]));
          paramArrayOfByte2[(i + paramInt3)] = tmp94_93;
          this.b[i] = tmp94_93;
        }
        paramInt1 += this.c;
        paramInt3 += this.c;
        k--;
      }
      if (m > 0)
      {
        this.a.a(this.b, 0, this.a, 0);
        for (i = 0; i < m; i++)
        {
          byte tmp185_184 = ((byte)(this.a[i] ^ paramArrayOfByte1[(i + paramInt1)]));
          paramArrayOfByte2[(i + paramInt3)] = tmp185_184;
          this.b[i] = tmp185_184;
        }
      }
    }
    else
    {
      while (k > 0)
      {
        this.a.a(this.b, 0, this.a, 0);
        System.arraycopy(this.b, this.c, this.b, 0, j);
        for (i = 0; i < this.c; i++)
        {
          byte tmp277_276 = ((byte)(this.a[i] ^ paramArrayOfByte1[(i + paramInt1)]));
          paramArrayOfByte2[(i + paramInt3)] = tmp277_276;
          this.b[(i + j)] = tmp277_276;
        }
        paramInt1 += this.c;
        paramInt3 += this.c;
        k--;
      }
      if (m != 0)
      {
        this.a.a(this.b, 0, this.a, 0);
        System.arraycopy(this.b, this.c, this.b, 0, j);
        for (i = 0; i < m; i++)
        {
          byte tmp389_388 = ((byte)(this.a[i] ^ paramArrayOfByte1[(i + paramInt1)]));
          paramArrayOfByte2[(i + paramInt3)] = tmp389_388;
          this.b[(i + j)] = tmp389_388;
        }
      }
    }
  }

  void b(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    int j = this.b - this.c;
    int k = paramInt2 / this.c;
    int m = paramInt2 % this.c;
    int i;
    if (j == 0)
    {
      while (k > 0)
      {
        this.a.a(this.b, 0, this.a, 0);
        for (i = 0; i < this.b; i++)
        {
          this.b[i] = paramArrayOfByte1[(i + paramInt1)];
          paramArrayOfByte2[(i + paramInt3)] = ((byte)(paramArrayOfByte1[(i + paramInt1)] ^ this.a[i]));
        }
        paramInt3 += this.c;
        paramInt1 += this.c;
        k--;
      }
      if (m > 0)
      {
        this.a.a(this.b, 0, this.a, 0);
        for (i = 0; i < m; i++)
        {
          this.b[i] = paramArrayOfByte1[(i + paramInt1)];
          paramArrayOfByte2[(i + paramInt3)] = ((byte)(paramArrayOfByte1[(i + paramInt1)] ^ this.a[i]));
        }
      }
    }
    else
    {
      while (k > 0)
      {
        this.a.a(this.b, 0, this.a, 0);
        System.arraycopy(this.b, this.c, this.b, 0, j);
        for (i = 0; i < this.c; i++)
        {
          this.b[(i + j)] = paramArrayOfByte1[(i + paramInt1)];
          paramArrayOfByte2[(i + paramInt3)] = ((byte)(paramArrayOfByte1[(i + paramInt1)] ^ this.a[i]));
        }
        paramInt3 += this.c;
        paramInt1 += this.c;
        k--;
      }
      if (m != 0)
      {
        this.a.a(this.b, 0, this.a, 0);
        System.arraycopy(this.b, this.c, this.b, 0, j);
        for (i = 0; i < m; i++)
        {
          this.b[(i + j)] = paramArrayOfByte1[(i + paramInt1)];
          paramArrayOfByte2[(i + paramInt3)] = ((byte)(paramArrayOfByte1[(i + paramInt1)] ^ this.a[i]));
        }
      }
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.sun.crypto.provider.SunJCE_n
 * JD-Core Version:    0.6.2
 */