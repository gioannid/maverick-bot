package com.sun.crypto.provider;

import java.io.ByteArrayInputStream;
import java.net.URL;
import java.security.AccessController;
import java.security.CodeSource;
import java.security.PrivilegedAction;
import java.security.ProtectionDomain;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

public final class SunJCE extends Provider
{
  private static final long serialVersionUID = 6812507587804302833L;
  private static final String a = "SunJCE Provider (implements RSA, DES, Triple DES, AES, Blowfish, ARCFOUR, RC2, PBE, Diffie-Hellman, HMAC)";
  private static final String b = "1.2.840.113549.1.12.1.6";
  private static final String c = "1.2.840.113549.1.12.1.3";
  private static final String d = "1.2.840.113549.1.5.3";
  private static final String e = "1.2.840.113549.1.5.12";
  private static final String f = "1.2.840.113549.1.3.1";
  static final boolean g = false;
  static final SecureRandom h = new SecureRandom();
  private static boolean i = false;

  public SunJCE()
  {
    super("SunJCE", 1.6D, "SunJCE Provider (implements RSA, DES, Triple DES, AES, Blowfish, ARCFOUR, RC2, PBE, Diffie-Hellman, HMAC)");
    AccessController.doPrivileged(new PrivilegedAction()
    {
      public Object run()
      {
        SunJCE.this.put("Cipher.RSA", "com.sun.crypto.provider.RSACipher");
        SunJCE.this.put("Cipher.RSA SupportedModes", "ECB");
        SunJCE.this.put("Cipher.RSA SupportedPaddings", "NOPADDING|PKCS1PADDING|OAEPWITHMD5ANDMGF1PADDING|OAEPWITHSHA1ANDMGF1PADDING|OAEPWITHSHA-1ANDMGF1PADDING|OAEPWITHSHA-256ANDMGF1PADDING|OAEPWITHSHA-384ANDMGF1PADDING|OAEPWITHSHA-512ANDMGF1PADDING");
        SunJCE.this.put("Cipher.RSA SupportedKeyClasses", "java.security.interfaces.RSAPublicKey|java.security.interfaces.RSAPrivateKey");
        SunJCE.this.put("Cipher.DES", "com.sun.crypto.provider.DESCipher");
        SunJCE.this.put("Cipher.DES SupportedModes", "ECB|CBC|PCBC|CTR|CTS|CFB|OFB|CFB8|CFB16|CFB24|CFB32|CFB40|CFB48|CFB56|CFB64|OFB8|OFB16|OFB24|OFB32|OFB40|OFB48|OFB56|OFB64");
        SunJCE.this.put("Cipher.DES SupportedPaddings", "NOPADDING|PKCS5PADDING|ISO10126PADDING");
        SunJCE.this.put("Cipher.DES SupportedKeyFormats", "RAW");
        SunJCE.this.put("Cipher.DESede", "com.sun.crypto.provider.DESedeCipher");
        SunJCE.this.put("Alg.Alias.Cipher.TripleDES", "DESede");
        SunJCE.this.put("Cipher.DESede SupportedModes", "ECB|CBC|PCBC|CTR|CTS|CFB|OFB|CFB8|CFB16|CFB24|CFB32|CFB40|CFB48|CFB56|CFB64|OFB8|OFB16|OFB24|OFB32|OFB40|OFB48|OFB56|OFB64");
        SunJCE.this.put("Cipher.DESede SupportedPaddings", "NOPADDING|PKCS5PADDING|ISO10126PADDING");
        SunJCE.this.put("Cipher.DESede SupportedKeyFormats", "RAW");
        SunJCE.this.put("Cipher.DESedeWrap", "com.sun.crypto.provider.DESedeWrapCipher");
        SunJCE.this.put("Cipher.DESedeWrap SupportedModes", "CBC");
        SunJCE.this.put("Cipher.DESedeWrap SupportedPaddings", "NOPADDING");
        SunJCE.this.put("Cipher.DESedeWrap SupportedKeyFormats", "RAW");
        SunJCE.this.put("Cipher.PBEWithMD5AndDES", "com.sun.crypto.provider.PBEWithMD5AndDESCipher");
        SunJCE.this.put("Alg.Alias.Cipher.OID.1.2.840.113549.1.5.3", "PBEWithMD5AndDES");
        SunJCE.this.put("Alg.Alias.Cipher.1.2.840.113549.1.5.3", "PBEWithMD5AndDES");
        SunJCE.this.put("Cipher.PBEWithMD5AndTripleDES", "com.sun.crypto.provider.PBEWithMD5AndTripleDESCipher");
        SunJCE.this.put("Cipher.PBEWithSHA1AndRC2_40", "com.sun.crypto.provider.PKCS12PBECipherCore$PBEWithSHA1AndRC2_40");
        SunJCE.this.put("Alg.Alias.Cipher.OID.1.2.840.113549.1.12.1.6", "PBEWithSHA1AndRC2_40");
        SunJCE.this.put("Alg.Alias.Cipher.1.2.840.113549.1.12.1.6", "PBEWithSHA1AndRC2_40");
        SunJCE.this.put("Cipher.PBEWithSHA1AndDESede", "com.sun.crypto.provider.PKCS12PBECipherCore$PBEWithSHA1AndDESede");
        SunJCE.this.put("Alg.Alias.Cipher.OID.1.2.840.113549.1.12.1.3", "PBEWithSHA1AndDESede");
        SunJCE.this.put("Alg.Alias.Cipher.1.2.840.113549.1.12.1.3", "PBEWithSHA1AndDESede");
        SunJCE.this.put("Cipher.Blowfish", "com.sun.crypto.provider.BlowfishCipher");
        SunJCE.this.put("Cipher.Blowfish SupportedModes", "ECB|CBC|PCBC|CTR|CTS|CFB|OFB|CFB8|CFB16|CFB24|CFB32|CFB40|CFB48|CFB56|CFB64|OFB8|OFB16|OFB24|OFB32|OFB40|OFB48|OFB56|OFB64");
        SunJCE.this.put("Cipher.Blowfish SupportedPaddings", "NOPADDING|PKCS5PADDING|ISO10126PADDING");
        SunJCE.this.put("Cipher.Blowfish SupportedKeyFormats", "RAW");
        SunJCE.this.put("Cipher.AES", "com.sun.crypto.provider.AESCipher");
        SunJCE.this.put("Alg.Alias.Cipher.Rijndael", "AES");
        SunJCE.this.put("Cipher.AES SupportedModes", "ECB|CBC|PCBC|CTR|CTS|CFB|OFB|CFB8|CFB16|CFB24|CFB32|CFB40|CFB48|CFB56|CFB64|OFB8|OFB16|OFB24|OFB32|OFB40|OFB48|OFB56|OFB64|CFB72|CFB80|CFB88|CFB96|CFB104|CFB112|CFB120|CFB128|OFB72|OFB80|OFB88|OFB96|OFB104|OFB112|OFB120|OFB128");
        SunJCE.this.put("Cipher.AES SupportedPaddings", "NOPADDING|PKCS5PADDING|ISO10126PADDING");
        SunJCE.this.put("Cipher.AES SupportedKeyFormats", "RAW");
        SunJCE.this.put("Cipher.AESWrap", "com.sun.crypto.provider.AESWrapCipher");
        SunJCE.this.put("Cipher.AESWrap SupportedModes", "ECB");
        SunJCE.this.put("Cipher.AESWrap SupportedPaddings", "NOPADDING");
        SunJCE.this.put("Cipher.AESWrap SupportedKeyFormats", "RAW");
        SunJCE.this.put("Cipher.RC2", "com.sun.crypto.provider.RC2Cipher");
        SunJCE.this.put("Cipher.RC2 SupportedModes", "ECB|CBC|PCBC|CTR|CTS|CFB|OFB|CFB8|CFB16|CFB24|CFB32|CFB40|CFB48|CFB56|CFB64|OFB8|OFB16|OFB24|OFB32|OFB40|OFB48|OFB56|OFB64");
        SunJCE.this.put("Cipher.RC2 SupportedPaddings", "NOPADDING|PKCS5PADDING|ISO10126PADDING");
        SunJCE.this.put("Cipher.RC2 SupportedKeyFormats", "RAW");
        SunJCE.this.put("Cipher.ARCFOUR", "com.sun.crypto.provider.ARCFOURCipher");
        SunJCE.this.put("Alg.Alias.Cipher.RC4", "ARCFOUR");
        SunJCE.this.put("Cipher.ARCFOUR SupportedModes", "ECB");
        SunJCE.this.put("Cipher.ARCFOUR SupportedPaddings", "NOPADDING");
        SunJCE.this.put("Cipher.ARCFOUR SupportedKeyFormats", "RAW");
        SunJCE.this.put("KeyGenerator.DES", "com.sun.crypto.provider.DESKeyGenerator");
        SunJCE.this.put("KeyGenerator.DESede", "com.sun.crypto.provider.DESedeKeyGenerator");
        SunJCE.this.put("Alg.Alias.KeyGenerator.TripleDES", "DESede");
        SunJCE.this.put("KeyGenerator.Blowfish", "com.sun.crypto.provider.BlowfishKeyGenerator");
        SunJCE.this.put("KeyGenerator.AES", "com.sun.crypto.provider.AESKeyGenerator");
        SunJCE.this.put("Alg.Alias.KeyGenerator.Rijndael", "AES");
        SunJCE.this.put("KeyGenerator.RC2", "com.sun.crypto.provider.KeyGeneratorCore$RC2KeyGenerator");
        SunJCE.this.put("KeyGenerator.ARCFOUR", "com.sun.crypto.provider.KeyGeneratorCore$ARCFOURKeyGenerator");
        SunJCE.this.put("Alg.Alias.KeyGenerator.RC4", "ARCFOUR");
        SunJCE.this.put("KeyGenerator.HmacMD5", "com.sun.crypto.provider.HmacMD5KeyGenerator");
        SunJCE.this.put("KeyGenerator.HmacSHA1", "com.sun.crypto.provider.HmacSHA1KeyGenerator");
        SunJCE.this.put("KeyGenerator.HmacSHA256", "com.sun.crypto.provider.KeyGeneratorCore$HmacSHA256KG");
        SunJCE.this.put("KeyGenerator.HmacSHA384", "com.sun.crypto.provider.KeyGeneratorCore$HmacSHA384KG");
        SunJCE.this.put("KeyGenerator.HmacSHA512", "com.sun.crypto.provider.KeyGeneratorCore$HmacSHA512KG");
        SunJCE.this.put("KeyPairGenerator.DiffieHellman", "com.sun.crypto.provider.DHKeyPairGenerator");
        SunJCE.this.put("Alg.Alias.KeyPairGenerator.DH", "DiffieHellman");
        SunJCE.this.put("Alg.Alias.KeyPairGenerator.OID.1.2.840.113549.1.3.1", "DiffieHellman");
        SunJCE.this.put("Alg.Alias.KeyPairGenerator.1.2.840.113549.1.3.1", "DiffieHellman");
        SunJCE.this.put("AlgorithmParameterGenerator.DiffieHellman", "com.sun.crypto.provider.DHParameterGenerator");
        SunJCE.this.put("Alg.Alias.AlgorithmParameterGenerator.DH", "DiffieHellman");
        SunJCE.this.put("Alg.Alias.AlgorithmParameterGenerator.OID.1.2.840.113549.1.3.1", "DiffieHellman");
        SunJCE.this.put("Alg.Alias.AlgorithmParameterGenerator.1.2.840.113549.1.3.1", "DiffieHellman");
        SunJCE.this.put("KeyAgreement.DiffieHellman", "com.sun.crypto.provider.DHKeyAgreement");
        SunJCE.this.put("Alg.Alias.KeyAgreement.DH", "DiffieHellman");
        SunJCE.this.put("Alg.Alias.KeyAgreement.OID.1.2.840.113549.1.3.1", "DiffieHellman");
        SunJCE.this.put("Alg.Alias.KeyAgreement.1.2.840.113549.1.3.1", "DiffieHellman");
        SunJCE.this.put("KeyAgreement.DiffieHellman SupportedKeyClasses", "javax.crypto.interfaces.DHPublicKey|javax.crypto.interfaces.DHPrivateKey");
        SunJCE.this.put("AlgorithmParameters.DiffieHellman", "com.sun.crypto.provider.DHParameters");
        SunJCE.this.put("Alg.Alias.AlgorithmParameters.DH", "DiffieHellman");
        SunJCE.this.put("Alg.Alias.AlgorithmParameters.OID.1.2.840.113549.1.3.1", "DiffieHellman");
        SunJCE.this.put("Alg.Alias.AlgorithmParameters.1.2.840.113549.1.3.1", "DiffieHellman");
        SunJCE.this.put("AlgorithmParameters.DES", "com.sun.crypto.provider.DESParameters");
        SunJCE.this.put("AlgorithmParameters.DESede", "com.sun.crypto.provider.DESedeParameters");
        SunJCE.this.put("Alg.Alias.AlgorithmParameters.TripleDES", "DESede");
        SunJCE.this.put("AlgorithmParameters.PBE", "com.sun.crypto.provider.PBEParameters");
        SunJCE.this.put("AlgorithmParameters.PBEWithMD5AndDES", "com.sun.crypto.provider.PBEParameters");
        SunJCE.this.put("Alg.Alias.AlgorithmParameters.OID.1.2.840.113549.1.5.3", "PBEWithMD5AndDES");
        SunJCE.this.put("Alg.Alias.AlgorithmParameters.1.2.840.113549.1.5.3", "PBEWithMD5AndDES");
        SunJCE.this.put("AlgorithmParameters.PBEWithMD5AndTripleDES", "com.sun.crypto.provider.PBEParameters");
        SunJCE.this.put("AlgorithmParameters.PBEWithSHA1AndDESede", "com.sun.crypto.provider.PBEParameters");
        SunJCE.this.put("Alg.Alias.AlgorithmParameters.OID.1.2.840.113549.1.12.1.3", "PBEWithSHA1AndDESede");
        SunJCE.this.put("Alg.Alias.AlgorithmParameters.1.2.840.113549.1.12.1.3", "PBEWithSHA1AndDESede");
        SunJCE.this.put("AlgorithmParameters.PBEWithSHA1AndRC2_40", "com.sun.crypto.provider.PBEParameters");
        SunJCE.this.put("Alg.Alias.AlgorithmParameters.OID.1.2.840.113549.1.12.1.6", "PBEWithSHA1AndRC2_40");
        SunJCE.this.put("Alg.Alias.AlgorithmParameters.1.2.840.113549.1.12.1.6", "PBEWithSHA1AndRC2_40");
        SunJCE.this.put("AlgorithmParameters.Blowfish", "com.sun.crypto.provider.BlowfishParameters");
        SunJCE.this.put("AlgorithmParameters.AES", "com.sun.crypto.provider.AESParameters");
        SunJCE.this.put("Alg.Alias.AlgorithmParameters.Rijndael", "AES");
        SunJCE.this.put("AlgorithmParameters.RC2", "com.sun.crypto.provider.RC2Parameters");
        SunJCE.this.put("AlgorithmParameters.OAEP", "com.sun.crypto.provider.OAEPParameters");
        SunJCE.this.put("KeyFactory.DiffieHellman", "com.sun.crypto.provider.DHKeyFactory");
        SunJCE.this.put("Alg.Alias.KeyFactory.DH", "DiffieHellman");
        SunJCE.this.put("Alg.Alias.KeyFactory.OID.1.2.840.113549.1.3.1", "DiffieHellman");
        SunJCE.this.put("Alg.Alias.KeyFactory.1.2.840.113549.1.3.1", "DiffieHellman");
        SunJCE.this.put("SecretKeyFactory.DES", "com.sun.crypto.provider.DESKeyFactory");
        SunJCE.this.put("SecretKeyFactory.DESede", "com.sun.crypto.provider.DESedeKeyFactory");
        SunJCE.this.put("Alg.Alias.SecretKeyFactory.TripleDES", "DESede");
        SunJCE.this.put("SecretKeyFactory.PBEWithMD5AndDES", "com.sun.crypto.provider.PBEKeyFactory$PBEWithMD5AndDES");
        SunJCE.this.put("Alg.Alias.SecretKeyFactory.OID.1.2.840.113549.1.5.3", "PBEWithMD5AndDES");
        SunJCE.this.put("Alg.Alias.SecretKeyFactory.1.2.840.113549.1.5.3", "PBEWithMD5AndDES");
        SunJCE.this.put("Alg.Alias.SecretKeyFactory.PBE", "PBEWithMD5AndDES");
        SunJCE.this.put("SecretKeyFactory.PBEWithMD5AndTripleDES", "com.sun.crypto.provider.PBEKeyFactory$PBEWithMD5AndTripleDES");
        SunJCE.this.put("SecretKeyFactory.PBEWithSHA1AndDESede", "com.sun.crypto.provider.PBEKeyFactory$PBEWithSHA1AndDESede");
        SunJCE.this.put("Alg.Alias.SecretKeyFactory.OID.1.2.840.113549.1.12.1.3", "PBEWithSHA1AndDESede");
        SunJCE.this.put("Alg.Alias.SecretKeyFactory.1.2.840.113549.1.12.1.3", "PBEWithSHA1AndDESede");
        SunJCE.this.put("SecretKeyFactory.PBEWithSHA1AndRC2_40", "com.sun.crypto.provider.PBEKeyFactory$PBEWithSHA1AndRC2_40");
        SunJCE.this.put("Alg.Alias.SecretKeyFactory.OID.1.2.840.113549.1.12.1.6", "PBEWithSHA1AndRC2_40");
        SunJCE.this.put("Alg.Alias.SecretKeyFactory.1.2.840.113549.1.12.1.6", "PBEWithSHA1AndRC2_40");
        SunJCE.this.put("SecretKeyFactory.PBKDF2WithHmacSHA1", "com.sun.crypto.provider.PBKDF2HmacSHA1Factory");
        SunJCE.this.put("Alg.Alias.SecretKeyFactory.OID.1.2.840.113549.1.5.12", "PBKDF2WithHmacSHA1");
        SunJCE.this.put("Alg.Alias.SecretKeyFactory.1.2.840.113549.1.5.12", "PBKDF2WithHmacSHA1");
        SunJCE.this.put("Mac.HmacMD5", "com.sun.crypto.provider.HmacMD5");
        SunJCE.this.put("Mac.HmacSHA1", "com.sun.crypto.provider.HmacSHA1");
        SunJCE.this.put("Mac.HmacSHA256", "com.sun.crypto.provider.HmacCore$HmacSHA256");
        SunJCE.this.put("Mac.HmacSHA384", "com.sun.crypto.provider.HmacCore$HmacSHA384");
        SunJCE.this.put("Mac.HmacSHA512", "com.sun.crypto.provider.HmacCore$HmacSHA512");
        SunJCE.this.put("Mac.HmacPBESHA1", "com.sun.crypto.provider.HmacPKCS12PBESHA1");
        SunJCE.this.put("Mac.SslMacMD5", "com.sun.crypto.provider.SslMacCore$SslMacMD5");
        SunJCE.this.put("Mac.SslMacSHA1", "com.sun.crypto.provider.SslMacCore$SslMacSHA1");
        SunJCE.this.put("Mac.HmacMD5 SupportedKeyFormats", "RAW");
        SunJCE.this.put("Mac.HmacSHA1 SupportedKeyFormats", "RAW");
        SunJCE.this.put("Mac.HmacSHA256 SupportedKeyFormats", "RAW");
        SunJCE.this.put("Mac.HmacSHA384 SupportedKeyFormats", "RAW");
        SunJCE.this.put("Mac.HmacSHA512 SupportedKeyFormats", "RAW");
        SunJCE.this.put("Mac.HmacPBESHA1 SupportedKeyFormats", "RAW");
        SunJCE.this.put("Mac.SslMacMD5 SupportedKeyFormats", "RAW");
        SunJCE.this.put("Mac.SslMacSHA1 SupportedKeyFormats", "RAW");
        SunJCE.this.put("KeyStore.JCEKS", "com.sun.crypto.provider.JceKeyStore");
        SunJCE.this.put("KeyGenerator.SunTlsPrf", "com.sun.crypto.provider.TlsPrfGenerator");
        SunJCE.this.put("KeyGenerator.SunTlsRsaPremasterSecret", "com.sun.crypto.provider.TlsRsaPremasterSecretGenerator");
        SunJCE.this.put("KeyGenerator.SunTlsMasterSecret", "com.sun.crypto.provider.TlsMasterSecretGenerator");
        SunJCE.this.put("KeyGenerator.SunTlsKeyMaterial", "com.sun.crypto.provider.TlsKeyMaterialGenerator");
        return null;
      }
    });
  }

  static void a(Class paramClass)
  {
    if (!b(paramClass))
      throw new SecurityException("The SunJCE provider may have been tampered.");
  }

  static final boolean b(Class paramClass)
  {
    if (i)
      return true;
    return c(paramClass);
  }

  private static final synchronized boolean c(Class paramClass)
  {
    if (i)
      return true;
    X509Certificate localX509Certificate;
    try
    {
      CertificateFactory localCertificateFactory = CertificateFactory.getInstance("X.509");
      localObject = "-----BEGIN CERTIFICATE-----\nMIICnTCCAlugAwIBAgICAh8wCwYHKoZIzjgEAwUAMIGQMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExEjAQBgNVBAcTCVBhbG8gQWx0bzEdMBsGA1UEChMUU3VuIE1pY3Jvc3lzdGVtcyBJbmMxIzAhBgNVBAsTGkphdmEgU29mdHdhcmUgQ29kZSBTaWduaW5nMRwwGgYDVQQDExNKQ0UgQ29kZSBTaWduaW5nIENBMB4XDTA1MTEyMzIyNDk0MVoXDTEwMTEyNzIyNDk0MVowYzEdMBsGA1UEChMUU3VuIE1pY3Jvc3lzdGVtcyBJbmMxIzAhBgNVBAsTGkphdmEgU29mdHdhcmUgQ29kZSBTaWduaW5nMR0wGwYDVQQDExRTdW4gTWljcm9zeXN0ZW1zIEluYzCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEA16bKo6tC3OHFDNfPXLKXMCMtIyeubNnsEtlvrH34HhfF+ZmpSliLCvQ15ms705vy4XgZUbZ3mgSOlLRMAGRo6596ePhc+0Z6yeKhbb3LZ8iz97ZIptkHGOshj9cfcSRPYmorUug9OsybMdIfQXazxT9mZJ9Yx5IDw6xak7kVbpUCAwEAAaOBiDCBhTARBglghkgBhvhCAQEEBAMCBBAwDgYDVR0PAQH/BAQDAgXgMB0GA1UdDgQWBBRI319jCbhc9DWJVltXgfrMybHNjzAfBgNVHSMEGDAWgBRl4vSGydNO8JFOWKJq9dh4WprBpjAgBgNVHREEGTAXgRV5dS1jaGluZy5wZW5nQHN1bi5jb20wCwYHKoZIzjgEAwUAAy8AMCwCFFBFmED9s3OoN9rbXfQV3+brJPW/AhQr+Wq1MlubAvnfjrlqeksh0QaDAQ==\n-----END CERTIFICATE-----".getBytes("UTF8");
      localX509Certificate = (X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream((byte[])localObject));
    }
    catch (Exception localException1)
    {
      return false;
    }
    Class localClass = paramClass;
    Object localObject = (URL)AccessController.doPrivileged(new PrivilegedAction()
    {
      public Object run()
      {
        CodeSource localCodeSource = this.a.getProtectionDomain().getCodeSource();
        return localCodeSource.getLocation();
      }
    });
    if (localObject == null)
      return false;
    SunJCE_b localSunJCE_b = new SunJCE_b((URL)localObject);
    try
    {
      localSunJCE_b.a(localX509Certificate);
    }
    catch (Exception localException2)
    {
      return false;
    }
    i = true;
    return true;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.sun.crypto.provider.SunJCE
 * JD-Core Version:    0.6.2
 */