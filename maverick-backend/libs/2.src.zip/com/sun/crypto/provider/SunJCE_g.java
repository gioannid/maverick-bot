package com.sun.crypto.provider;

import java.security.InvalidKeyException;

final class SunJCE_g extends SunJCE_h
{
  SunJCE_g(SunJCE_e paramSunJCE_e)
  {
    super(paramSunJCE_e);
  }

  String a()
  {
    return "ECB";
  }

  void b()
  {
  }

  void c()
  {
  }

  void d()
  {
  }

  void a(boolean paramBoolean, String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws InvalidKeyException
  {
    if ((paramArrayOfByte1 == null) || (paramArrayOfByte2 != null))
      throw new InvalidKeyException("Internal error");
    this.a.a(paramBoolean, paramString, paramArrayOfByte1);
  }

  void a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    while (paramInt2 >= this.b)
    {
      this.a.a(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt3);
      paramInt2 -= this.b;
      paramInt1 += this.b;
      paramInt3 += this.b;
    }
  }

  void b(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    while (paramInt2 >= this.b)
    {
      this.a.b(paramArrayOfByte1, paramInt1, paramArrayOfByte2, paramInt3);
      paramInt2 -= this.b;
      paramInt1 += this.b;
      paramInt3 += this.b;
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.sun.crypto.provider.SunJCE_g
 * JD-Core Version:    0.6.2
 */