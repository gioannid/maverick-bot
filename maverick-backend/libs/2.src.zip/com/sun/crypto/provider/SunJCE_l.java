package com.sun.crypto.provider;

import javax.crypto.IllegalBlockSizeException;

final class SunJCE_l extends SunJCE_k
{
  SunJCE_l(SunJCE_e paramSunJCE_e)
  {
    super(paramSunJCE_e);
  }

  String a()
  {
    return "CTS";
  }

  void c(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws IllegalBlockSizeException
  {
    if (paramInt2 < this.b)
      throw new IllegalBlockSizeException("input is too short!");
    if (paramInt2 == this.b)
    {
      a(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3);
    }
    else
    {
      int i = paramInt2 % this.b;
      int j;
      if (i == 0)
      {
        a(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3);
        j = paramInt3 + paramInt2 - this.b;
        int k = j - this.b;
        byte[] arrayOfByte2 = new byte[this.b];
        System.arraycopy(paramArrayOfByte2, j, arrayOfByte2, 0, this.b);
        System.arraycopy(paramArrayOfByte2, k, paramArrayOfByte2, j, this.b);
        System.arraycopy(arrayOfByte2, 0, paramArrayOfByte2, k, this.b);
      }
      else
      {
        j = paramInt2 - (this.b + i);
        if (j > 0)
        {
          a(paramArrayOfByte1, paramInt1, j, paramArrayOfByte2, paramInt3);
          paramInt1 += j;
          paramInt3 += j;
        }
        byte[] arrayOfByte1 = new byte[this.b];
        for (int m = 0; m < this.b; m++)
          arrayOfByte1[m] = ((byte)(paramArrayOfByte1[(paramInt1 + m)] ^ this.a[m]));
        byte[] arrayOfByte3 = new byte[this.b];
        this.a.a(arrayOfByte1, 0, arrayOfByte3, 0);
        System.arraycopy(arrayOfByte3, 0, paramArrayOfByte2, paramInt3 + this.b, i);
        for (int n = 0; n < i; n++)
          arrayOfByte3[n] = ((byte)(paramArrayOfByte1[(paramInt1 + this.b + n)] ^ arrayOfByte3[n]));
        this.a.a(arrayOfByte3, 0, paramArrayOfByte2, paramInt3);
      }
    }
  }

  void d(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws IllegalBlockSizeException
  {
    if (paramInt2 < this.b)
      throw new IllegalBlockSizeException("input is too short!");
    if (paramInt2 == this.b)
    {
      b(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3);
    }
    else
    {
      int i = paramInt2 % this.b;
      int j;
      if (i == 0)
      {
        j = paramInt1 + paramInt2 - this.b;
        int k = paramInt1 + paramInt2 - 2 * this.b;
        byte[] arrayOfByte2 = new byte[2 * this.b];
        System.arraycopy(paramArrayOfByte1, j, arrayOfByte2, 0, this.b);
        System.arraycopy(paramArrayOfByte1, k, arrayOfByte2, this.b, this.b);
        int n = paramInt2 - 2 * this.b;
        b(paramArrayOfByte1, paramInt1, n, paramArrayOfByte2, paramInt3);
        b(arrayOfByte2, 0, 2 * this.b, paramArrayOfByte2, paramInt3 + n);
      }
      else
      {
        j = paramInt2 - (this.b + i);
        if (j > 0)
        {
          b(paramArrayOfByte1, paramInt1, j, paramArrayOfByte2, paramInt3);
          paramInt1 += j;
          paramInt3 += j;
        }
        byte[] arrayOfByte1 = new byte[this.b];
        this.a.b(paramArrayOfByte1, paramInt1, arrayOfByte1, 0);
        for (int m = 0; m < i; m++)
          paramArrayOfByte2[(paramInt3 + this.b + m)] = ((byte)(paramArrayOfByte1[(paramInt1 + this.b + m)] ^ arrayOfByte1[m]));
        System.arraycopy(paramArrayOfByte1, paramInt1 + this.b, arrayOfByte1, 0, i);
        this.a.b(arrayOfByte1, 0, paramArrayOfByte2, paramInt3);
        for (m = 0; m < this.b; m++)
          paramArrayOfByte2[(paramInt3 + m)] = ((byte)(paramArrayOfByte2[(paramInt3 + m)] ^ this.a[m]));
      }
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.sun.crypto.provider.SunJCE_l
 * JD-Core Version:    0.6.2
 */