package com.sun.crypto.provider;

import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.InvalidParameterSpecException;
import java.util.Locale;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.ShortBufferException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.RC2ParameterSpec;

final class SunJCE_f
{
  private byte[] a = null;
  private int b = 0;
  private int c = 0;
  private int d = 0;
  private int e = 0;
  private int f = 0;
  private SunJCE_j g = null;
  private SunJCE_h h = null;
  private int i = 0;
  private boolean j = false;
  private static final int k = 0;
  private static final int l = 1;
  private static final int m = 2;
  private static final int n = 3;
  private static final int o = 4;
  private static final int p = 5;
  private static final int q = 6;

  SunJCE_f(SunJCE_e paramSunJCE_e, int paramInt)
  {
    this.b = paramInt;
    this.c = paramInt;
    this.f = paramInt;
    this.a = new byte[this.b * 2];
    this.h = new SunJCE_g(paramSunJCE_e);
    this.g = new SunJCE_i(this.b);
  }

  void a(String paramString)
    throws NoSuchAlgorithmException
  {
    if (paramString == null)
      throw new NoSuchAlgorithmException("null mode");
    String str = paramString.toUpperCase(Locale.ENGLISH);
    if (str.equals("ECB"))
      return;
    SunJCE_e localSunJCE_e = this.h.e();
    if (str.equals("CBC"))
    {
      this.i = 1;
      this.h = new SunJCE_k(localSunJCE_e);
    }
    else if (str.equals("CTS"))
    {
      this.i = 6;
      this.h = new SunJCE_l(localSunJCE_e);
      this.e = (this.b + 1);
      this.g = null;
    }
    else if (str.equals("CTR"))
    {
      this.i = 5;
      this.h = new SunJCE_m(localSunJCE_e);
      this.c = 1;
      this.g = null;
    }
    else if (str.startsWith("CFB"))
    {
      this.i = 2;
      this.c = a(paramString, "CFB".length(), this.b);
      this.h = new SunJCE_n(localSunJCE_e, this.c);
    }
    else if (str.startsWith("OFB"))
    {
      this.i = 3;
      this.c = a(paramString, "OFB".length(), this.b);
      this.h = new SunJCE_o(localSunJCE_e, this.c);
    }
    else if (str.equals("PCBC"))
    {
      this.i = 4;
      this.h = new SunJCE_p(localSunJCE_e);
    }
    else
    {
      throw new NoSuchAlgorithmException("Cipher mode: " + paramString + " not found");
    }
  }

  private static int a(String paramString, int paramInt1, int paramInt2)
    throws NoSuchAlgorithmException
  {
    int i1 = paramInt2;
    if (paramString.length() > paramInt1)
    {
      int i2;
      try
      {
        Integer localInteger = Integer.valueOf(paramString.substring(paramInt1));
        i2 = localInteger.intValue();
        i1 = i2 >> 3;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        throw new NoSuchAlgorithmException("Algorithm mode: " + paramString + " not implemented");
      }
      if ((i2 % 8 != 0) || (i1 > paramInt2))
        throw new NoSuchAlgorithmException("Invalid algorithm mode: " + paramString);
    }
    return i1;
  }

  void b(String paramString)
    throws NoSuchPaddingException
  {
    if (paramString == null)
      throw new NoSuchPaddingException("null padding");
    if (paramString.equalsIgnoreCase("NoPadding"))
      this.g = null;
    else if (paramString.equalsIgnoreCase("ISO10126Padding"))
      this.g = new SunJCE_q(this.b);
    else if (!paramString.equalsIgnoreCase("PKCS5Padding"))
      throw new NoSuchPaddingException("Padding: " + paramString + " not implemented");
    if ((this.g != null) && ((this.i == 5) || (this.i == 6)))
    {
      this.g = null;
      throw new NoSuchPaddingException((this.i == 5 ? "CTR" : "CTS") + " mode must be used with NoPadding");
    }
  }

  int a(int paramInt)
  {
    int i1 = this.d + paramInt;
    if (this.g == null)
      return i1;
    if (this.j)
      return i1;
    if (this.c != this.b)
    {
      if (i1 < this.f)
        return this.f;
      return i1 + this.b - (i1 - this.f) % this.b;
    }
    return i1 + this.g.a(i1);
  }

  byte[] a()
  {
    byte[] arrayOfByte = this.h.g();
    return arrayOfByte == null ? null : (byte[])arrayOfByte.clone();
  }

  AlgorithmParameters c(String paramString)
  {
    AlgorithmParameters localAlgorithmParameters = null;
    if (this.i == 0)
      return null;
    byte[] arrayOfByte = a();
    if (arrayOfByte != null)
    {
      Object localObject;
      if (paramString.equals("RC2"))
      {
        SunJCE_r localSunJCE_r = (SunJCE_r)this.h.e();
        localObject = new RC2ParameterSpec(localSunJCE_r.b(), arrayOfByte);
      }
      else
      {
        localObject = new IvParameterSpec(arrayOfByte);
      }
      try
      {
        localAlgorithmParameters = AlgorithmParameters.getInstance(paramString, "SunJCE");
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
      {
        throw new RuntimeException("Cannot find " + paramString + " AlgorithmParameters implementation in SunJCE provider");
      }
      catch (NoSuchProviderException localNoSuchProviderException)
      {
        throw new RuntimeException("Cannot find SunJCE provider");
      }
      try
      {
        localAlgorithmParameters.init((AlgorithmParameterSpec)localObject);
      }
      catch (InvalidParameterSpecException localInvalidParameterSpecException)
      {
        throw new RuntimeException("IvParameterSpec not supported");
      }
    }
    return localAlgorithmParameters;
  }

  void a(int paramInt, Key paramKey, SecureRandom paramSecureRandom)
    throws InvalidKeyException
  {
    try
    {
      a(paramInt, paramKey, (AlgorithmParameterSpec)null, paramSecureRandom);
    }
    catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
    {
      throw new InvalidKeyException(localInvalidAlgorithmParameterException.getMessage());
    }
  }

  void a(int paramInt, Key paramKey, AlgorithmParameterSpec paramAlgorithmParameterSpec, SecureRandom paramSecureRandom)
    throws InvalidKeyException, InvalidAlgorithmParameterException
  {
    this.j = ((paramInt == 2) || (paramInt == 4));
    byte[] arrayOfByte1 = a(paramKey);
    byte[] arrayOfByte2;
    if (paramAlgorithmParameterSpec == null)
    {
      arrayOfByte2 = null;
    }
    else if ((paramAlgorithmParameterSpec instanceof IvParameterSpec))
    {
      arrayOfByte2 = ((IvParameterSpec)paramAlgorithmParameterSpec).getIV();
      if ((arrayOfByte2 == null) || (arrayOfByte2.length != this.b))
        throw new InvalidAlgorithmParameterException("Wrong IV length: must be " + this.b + " bytes long");
    }
    else if ((paramAlgorithmParameterSpec instanceof RC2ParameterSpec))
    {
      arrayOfByte2 = ((RC2ParameterSpec)paramAlgorithmParameterSpec).getIV();
      if ((arrayOfByte2 != null) && (arrayOfByte2.length != this.b))
        throw new InvalidAlgorithmParameterException("Wrong IV length: must be " + this.b + " bytes long");
    }
    else
    {
      throw new InvalidAlgorithmParameterException("Wrong parameter type: IV expected");
    }
    if (this.i == 0)
    {
      if (arrayOfByte2 != null)
        throw new InvalidAlgorithmParameterException("ECB mode cannot use IV");
    }
    else if (arrayOfByte2 == null)
    {
      if (this.j)
        throw new InvalidAlgorithmParameterException("Parameters missing");
      if (paramSecureRandom == null)
        paramSecureRandom = SunJCE.h;
      arrayOfByte2 = new byte[this.b];
      paramSecureRandom.nextBytes(arrayOfByte2);
    }
    this.d = 0;
    this.f = this.b;
    String str = paramKey.getAlgorithm();
    this.h.a(this.j, str, arrayOfByte1, arrayOfByte2);
  }

  void a(int paramInt, Key paramKey, AlgorithmParameters paramAlgorithmParameters, SecureRandom paramSecureRandom)
    throws InvalidKeyException, InvalidAlgorithmParameterException
  {
    IvParameterSpec localIvParameterSpec = null;
    if (paramAlgorithmParameters != null)
      try
      {
        localIvParameterSpec = (IvParameterSpec)paramAlgorithmParameters.getParameterSpec(IvParameterSpec.class);
      }
      catch (InvalidParameterSpecException localInvalidParameterSpecException)
      {
        throw new InvalidAlgorithmParameterException("Wrong parameter type: IV expected");
      }
    a(paramInt, paramKey, localIvParameterSpec, paramSecureRandom);
  }

  static byte[] a(Key paramKey)
    throws InvalidKeyException
  {
    if (paramKey == null)
      throw new InvalidKeyException("No key given");
    if (!"RAW".equalsIgnoreCase(paramKey.getFormat()))
      throw new InvalidKeyException("Wrong format: RAW bytes needed");
    byte[] arrayOfByte = paramKey.getEncoded();
    if (arrayOfByte == null)
      throw new InvalidKeyException("RAW key bytes missing");
    return arrayOfByte;
  }

  byte[] a(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte1 = null;
    byte[] arrayOfByte2 = null;
    try
    {
      arrayOfByte1 = new byte[a(paramInt2)];
      int i1 = a(paramArrayOfByte, paramInt1, paramInt2, arrayOfByte1, 0);
      if (i1 == arrayOfByte1.length)
      {
        arrayOfByte2 = arrayOfByte1;
      }
      else
      {
        arrayOfByte2 = new byte[i1];
        System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i1);
      }
    }
    catch (ShortBufferException localShortBufferException)
    {
    }
    return arrayOfByte2;
  }

  int a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws ShortBufferException
  {
    int i1 = this.d + paramInt2 - this.e;
    if ((this.g != null) && (this.j))
      i1 -= this.b;
    i1 = i1 > 0 ? i1 - i1 % this.c : 0;
    if ((paramArrayOfByte2 == null) || (paramArrayOfByte2.length - paramInt3 < i1))
      throw new ShortBufferException("Output buffer must be (at least) " + i1 + " bytes long");
    if (i1 != 0)
    {
      byte[] arrayOfByte = new byte[i1];
      int i2 = i1 - this.d;
      int i3 = this.d;
      if (i2 < 0)
      {
        i2 = 0;
        i3 = i1;
      }
      if (this.d != 0)
        System.arraycopy(this.a, 0, arrayOfByte, 0, i3);
      if (i2 > 0)
        System.arraycopy(paramArrayOfByte1, paramInt1, arrayOfByte, i3, i2);
      if (this.j)
        this.h.b(arrayOfByte, 0, i1, paramArrayOfByte2, paramInt3);
      else
        this.h.a(arrayOfByte, 0, i1, paramArrayOfByte2, paramInt3);
      if (this.c != this.b)
        if (i1 < this.f)
          this.f -= i1;
        else
          this.f = (this.b - (i1 - this.f) % this.b);
      paramInt2 -= i2;
      paramInt1 += i2;
      paramInt3 += i1;
      this.d -= i3;
      if (this.d > 0)
        System.arraycopy(this.a, i3, this.a, 0, this.d);
    }
    if (paramInt2 > 0)
      System.arraycopy(paramArrayOfByte1, paramInt1, this.a, this.d, paramInt2);
    this.d += paramInt2;
    return i1;
  }

  byte[] b(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IllegalBlockSizeException, BadPaddingException
  {
    byte[] arrayOfByte1 = null;
    byte[] arrayOfByte2 = null;
    try
    {
      arrayOfByte1 = new byte[a(paramInt2)];
      int i1 = b(paramArrayOfByte, paramInt1, paramInt2, arrayOfByte1, 0);
      if (i1 < arrayOfByte1.length)
      {
        arrayOfByte2 = new byte[i1];
        if (i1 != 0)
          System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i1);
      }
      else
      {
        arrayOfByte2 = arrayOfByte1;
      }
    }
    catch (ShortBufferException localShortBufferException)
    {
    }
    return arrayOfByte2;
  }

  int b(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws IllegalBlockSizeException, ShortBufferException, BadPaddingException
  {
    int i1 = this.d + paramInt2;
    int i2 = i1;
    int i3 = 0;
    if (this.c != this.b)
    {
      if (i1 < this.f)
        i3 = this.f - i1;
      else
        i3 = this.b - (i1 - this.f) % this.b;
    }
    else if (this.g != null)
      i3 = this.g.a(i1);
    if ((i3 > 0) && (i3 != this.b) && (this.g != null) && (this.j))
      throw new IllegalBlockSizeException("Input length must be multiple of " + this.b + " when decrypting with padded cipher");
    if ((!this.j) && (this.g != null))
      i2 += i3;
    if (paramArrayOfByte2 == null)
      throw new ShortBufferException("Output buffer is null");
    int i4 = paramArrayOfByte2.length - paramInt3;
    if (((this.j) && (this.g != null)) || ((i4 < i2) || ((this.j) && (i4 < i2 - this.b))))
      throw new ShortBufferException("Output buffer too short: " + i4 + " bytes given, " + i2 + " bytes needed");
    byte[] arrayOfByte1 = paramArrayOfByte1;
    int i5 = paramInt1;
    if ((this.d != 0) || ((!this.j) && (this.g != null)))
    {
      i5 = 0;
      arrayOfByte1 = new byte[i2];
      if (this.d != 0)
        System.arraycopy(this.a, 0, arrayOfByte1, 0, this.d);
      if (paramInt2 != 0)
        System.arraycopy(paramArrayOfByte1, paramInt1, arrayOfByte1, this.d, paramInt2);
      if ((!this.j) && (this.g != null))
        this.g.a(arrayOfByte1, i1, i3);
    }
    if (this.j)
    {
      if (i4 < i2)
        this.h.c();
      byte[] arrayOfByte2 = new byte[i1];
      i1 = a(arrayOfByte1, i5, arrayOfByte2, 0, i1);
      if (this.g != null)
      {
        i6 = this.g.b(arrayOfByte2, 0, i1);
        if (i6 < 0)
          throw new BadPaddingException("Given final block not properly padded");
        i1 = i6;
      }
      if (paramArrayOfByte2.length - paramInt3 < i1)
      {
        this.h.d();
        throw new ShortBufferException("Output buffer too short: " + (paramArrayOfByte2.length - paramInt3) + " bytes given, " + i1 + " bytes needed");
      }
      for (int i6 = 0; i6 < i1; i6++)
        paramArrayOfByte2[(paramInt3 + i6)] = arrayOfByte2[i6];
    }
    else
    {
      i1 = a(arrayOfByte1, i5, paramArrayOfByte2, paramInt3, i2);
    }
    this.d = 0;
    this.f = this.b;
    if (this.i != 0)
      this.h.b();
    return i1;
  }

  private int a(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, int paramInt3)
    throws IllegalBlockSizeException
  {
    if ((paramArrayOfByte1 == null) || (paramInt3 == 0))
      return 0;
    if ((this.i != 2) && (this.i != 3) && (paramInt3 % this.c != 0) && (this.i != 6))
    {
      if (this.g != null)
        throw new IllegalBlockSizeException("Input length (with padding) not multiple of " + this.c + " bytes");
      throw new IllegalBlockSizeException("Input length not multiple of " + this.c + " bytes");
    }
    if (this.j)
      this.h.d(paramArrayOfByte1, paramInt1, paramInt3, paramArrayOfByte2, paramInt2);
    else
      this.h.c(paramArrayOfByte1, paramInt1, paramInt3, paramArrayOfByte2, paramInt2);
    return paramInt3;
  }

  byte[] b(Key paramKey)
    throws IllegalBlockSizeException, InvalidKeyException
  {
    byte[] arrayOfByte1 = null;
    try
    {
      byte[] arrayOfByte2 = paramKey.getEncoded();
      if ((arrayOfByte2 == null) || (arrayOfByte2.length == 0))
        throw new InvalidKeyException("Cannot get an encoding of the key to be wrapped");
      arrayOfByte1 = b(arrayOfByte2, 0, arrayOfByte2.length);
    }
    catch (BadPaddingException localBadPaddingException)
    {
    }
    return arrayOfByte1;
  }

  Key a(byte[] paramArrayOfByte, String paramString, int paramInt)
    throws InvalidKeyException, NoSuchAlgorithmException
  {
    byte[] arrayOfByte;
    try
    {
      arrayOfByte = b(paramArrayOfByte, 0, paramArrayOfByte.length);
    }
    catch (BadPaddingException localBadPaddingException)
    {
      throw new InvalidKeyException("The wrapped key is not padded correctly");
    }
    catch (IllegalBlockSizeException localIllegalBlockSizeException)
    {
      throw new InvalidKeyException("The wrapped key does not have the correct length");
    }
    return SunJCE_s.a(arrayOfByte, paramString, paramInt);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.sun.crypto.provider.SunJCE_f
 * JD-Core Version:    0.6.2
 */