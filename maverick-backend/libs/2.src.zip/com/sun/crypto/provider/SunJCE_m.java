package com.sun.crypto.provider;

import java.security.InvalidKeyException;

final class SunJCE_m extends SunJCE_h
{
  private final byte[] a = new byte[this.b];
  private final byte[] b = new byte[this.b];
  private int c;
  private byte[] d = null;
  private byte[] e = null;
  private int f = 0;

  SunJCE_m(SunJCE_e paramSunJCE_e)
  {
    super(paramSunJCE_e);
  }

  String a()
  {
    return "CTR";
  }

  void b()
  {
    System.arraycopy(this.c, 0, this.a, 0, this.b);
    this.c = this.b;
  }

  void c()
  {
    if (this.d == null)
    {
      this.d = new byte[this.b];
      this.e = new byte[this.b];
    }
    System.arraycopy(this.a, 0, this.d, 0, this.b);
    System.arraycopy(this.b, 0, this.e, 0, this.b);
    this.f = this.c;
  }

  void d()
  {
    System.arraycopy(this.d, 0, this.a, 0, this.b);
    System.arraycopy(this.e, 0, this.b, 0, this.b);
    this.c = this.f;
  }

  void a(boolean paramBoolean, String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws InvalidKeyException
  {
    if ((paramArrayOfByte1 == null) || (paramArrayOfByte2 == null) || (paramArrayOfByte2.length != this.b))
      throw new InvalidKeyException("Internal error");
    this.c = paramArrayOfByte2;
    b();
    this.a.a(false, paramString, paramArrayOfByte1);
  }

  void a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    e(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3);
  }

  void b(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    e(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3);
  }

  private static void a(byte[] paramArrayOfByte)
  {
    for (int i = paramArrayOfByte.length - 1; i >= 0; i--)
    {
      int tmp11_10 = i;
      if ((paramArrayOfByte[tmp11_10] = (byte)(paramArrayOfByte[tmp11_10] + 1)) != 0)
        break;
    }
  }

  private void e(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    while (paramInt2-- > 0)
    {
      if (this.c >= this.b)
      {
        this.a.a(this.a, 0, this.b, 0);
        a(this.a);
        this.c = 0;
      }
      paramArrayOfByte2[(paramInt3++)] = ((byte)(paramArrayOfByte1[(paramInt1++)] ^ this.b[(this.c++)]));
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.sun.crypto.provider.SunJCE_m
 * JD-Core Version:    0.6.2
 */