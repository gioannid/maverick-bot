package com.sun.crypto.provider;

import javax.crypto.ShortBufferException;

final class SunJCE_i
  implements SunJCE_j
{
  private int a;

  SunJCE_i(int paramInt)
  {
    this.a = paramInt;
  }

  public void a(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws ShortBufferException
  {
    if (paramArrayOfByte == null)
      return;
    if (paramInt1 + paramInt2 > paramArrayOfByte.length)
      throw new ShortBufferException("Buffer too small to hold padding");
    int i = (byte)(paramInt2 & 0xFF);
    for (int j = 0; j < paramInt2; j++)
      paramArrayOfByte[(j + paramInt1)] = i;
  }

  public int b(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if ((paramArrayOfByte == null) || (paramInt2 == 0))
      return 0;
    int i = paramArrayOfByte[(paramInt1 + paramInt2 - 1)];
    int j = i & 0xFF;
    if ((j < 1) || (j > this.a))
      return -1;
    int k = paramInt1 + paramInt2 - (i & 0xFF);
    if (k < paramInt1)
      return -1;
    for (int m = 0; m < (i & 0xFF); m++)
      if (paramArrayOfByte[(k + m)] != i)
        return -1;
    return k;
  }

  public int a(int paramInt)
  {
    int i = this.a - paramInt % this.a;
    return i;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.sun.crypto.provider.SunJCE_i
 * JD-Core Version:    0.6.2
 */