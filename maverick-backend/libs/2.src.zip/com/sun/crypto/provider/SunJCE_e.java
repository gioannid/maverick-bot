package com.sun.crypto.provider;

import java.security.InvalidKeyException;

abstract class SunJCE_e
{
  abstract int a();

  abstract void a(boolean paramBoolean, String paramString, byte[] paramArrayOfByte)
    throws InvalidKeyException;

  abstract void a(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2);

  abstract void b(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2);
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.sun.crypto.provider.SunJCE_e
 * JD-Core Version:    0.6.2
 */