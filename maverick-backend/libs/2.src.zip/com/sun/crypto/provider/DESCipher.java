package com.sun.crypto.provider;

import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.BadPaddingException;
import javax.crypto.CipherSpi;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.ShortBufferException;

public final class DESCipher extends CipherSpi
{
  private SunJCE_f a = null;

  public DESCipher()
  {
    SunJCE.a(getClass());
    this.a = new SunJCE_f(new SunJCE_w(), 8);
  }

  protected void engineSetMode(String paramString)
    throws NoSuchAlgorithmException
  {
    this.a.a(paramString);
  }

  protected void engineSetPadding(String paramString)
    throws NoSuchPaddingException
  {
    this.a.b(paramString);
  }

  protected int engineGetBlockSize()
  {
    return 8;
  }

  protected int engineGetOutputSize(int paramInt)
  {
    return this.a.a(paramInt);
  }

  protected byte[] engineGetIV()
  {
    return this.a.a();
  }

  protected AlgorithmParameters engineGetParameters()
  {
    return this.a.c("DES");
  }

  protected void engineInit(int paramInt, Key paramKey, SecureRandom paramSecureRandom)
    throws InvalidKeyException
  {
    this.a.a(paramInt, paramKey, paramSecureRandom);
  }

  protected void engineInit(int paramInt, Key paramKey, AlgorithmParameterSpec paramAlgorithmParameterSpec, SecureRandom paramSecureRandom)
    throws InvalidKeyException, InvalidAlgorithmParameterException
  {
    this.a.a(paramInt, paramKey, paramAlgorithmParameterSpec, paramSecureRandom);
  }

  protected void engineInit(int paramInt, Key paramKey, AlgorithmParameters paramAlgorithmParameters, SecureRandom paramSecureRandom)
    throws InvalidKeyException, InvalidAlgorithmParameterException
  {
    this.a.a(paramInt, paramKey, paramAlgorithmParameters, paramSecureRandom);
  }

  protected byte[] engineUpdate(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    return this.a.a(paramArrayOfByte, paramInt1, paramInt2);
  }

  protected int engineUpdate(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws ShortBufferException
  {
    return this.a.a(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3);
  }

  protected byte[] engineDoFinal(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IllegalBlockSizeException, BadPaddingException
  {
    return this.a.b(paramArrayOfByte, paramInt1, paramInt2);
  }

  protected int engineDoFinal(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws IllegalBlockSizeException, ShortBufferException, BadPaddingException
  {
    return this.a.b(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3);
  }

  protected int engineGetKeySize(Key paramKey)
    throws InvalidKeyException
  {
    byte[] arrayOfByte = paramKey.getEncoded();
    if (arrayOfByte.length != 8)
      throw new InvalidKeyException("Invalid key length: " + arrayOfByte.length + " bytes");
    return 56;
  }

  protected byte[] engineWrap(Key paramKey)
    throws IllegalBlockSizeException, InvalidKeyException
  {
    return this.a.b(paramKey);
  }

  protected Key engineUnwrap(byte[] paramArrayOfByte, String paramString, int paramInt)
    throws InvalidKeyException, NoSuchAlgorithmException
  {
    return this.a.a(paramArrayOfByte, paramString, paramInt);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.sun.crypto.provider.DESCipher
 * JD-Core Version:    0.6.2
 */