package com.sun.crypto.provider;

abstract interface SunJCE_x
{
  public static final int a = 8;
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.sun.crypto.provider.SunJCE_x
 * JD-Core Version:    0.6.2
 */