package com.sun.crypto.provider;

import java.io.IOException;
import java.io.InputStream;
import java.net.JarURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.AccessController;
import java.security.NoSuchProviderException;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Enumeration;
import java.util.Vector;
import java.util.jar.Attributes;
import java.util.jar.Attributes.Name;
import java.util.jar.JarEntry;
import java.util.jar.JarException;
import java.util.jar.JarFile;
import java.util.jar.Manifest;
import java.util.zip.ZipEntry;

final class SunJCE_b
{
  private static final boolean a = false;
  private URL b;

  SunJCE_b(URL paramURL)
  {
    this.b = paramURL;
  }

  void a(X509Certificate paramX509Certificate)
    throws JarException, IOException
  {
    try
    {
      a(this.b, null, paramX509Certificate);
    }
    catch (NoSuchProviderException localNoSuchProviderException)
    {
      throw new JarException("Cannot verify " + this.b.toString());
    }
    catch (CertificateException localCertificateException)
    {
      throw new JarException("Cannot verify " + this.b.toString());
    }
  }

  private void a(URL paramURL, Vector paramVector, X509Certificate paramX509Certificate)
    throws NoSuchProviderException, CertificateException, IOException
  {
    String str1 = paramURL.toString();
    if ((paramVector == null) || (!paramVector.contains(str1)))
    {
      String str2 = a(paramURL, paramX509Certificate);
      if (paramVector != null)
        paramVector.addElement(str1);
      if (str2 != null)
      {
        if (paramVector == null)
        {
          paramVector = new Vector();
          paramVector.addElement(str1);
        }
        a(paramURL, str2, paramVector, paramX509Certificate);
      }
    }
  }

  private void a(URL paramURL, String paramString, Vector paramVector, X509Certificate paramX509Certificate)
    throws NoSuchProviderException, CertificateException, IOException
  {
    String[] arrayOfString = a(paramString);
    try
    {
      for (int i = 0; i < arrayOfString.length; i++)
      {
        localObject = new URL(paramURL, arrayOfString[i]);
        a((URL)localObject, paramVector, paramX509Certificate);
      }
    }
    catch (MalformedURLException localMalformedURLException)
    {
      Object localObject = new MalformedURLException("The JAR file " + paramURL.toString() + " contains invalid URLs in its Class-Path attribute");
      ((MalformedURLException)localObject).initCause(localMalformedURLException);
      throw ((Throwable)localObject);
    }
  }

  private String a(URL paramURL, X509Certificate paramX509Certificate)
    throws NoSuchProviderException, CertificateException, IOException
  {
    final URL localURL = paramURL.getProtocol().equalsIgnoreCase("jar") ? paramURL : new URL("jar:" + paramURL.toString() + "!/");
    JarFile localJarFile = null;
    try
    {
      try
      {
        localJarFile = (JarFile)AccessController.doPrivileged(new PrivilegedExceptionAction()
        {
          public Object run()
            throws Exception
          {
            JarURLConnection localJarURLConnection = (JarURLConnection)localURL.openConnection();
            localJarURLConnection.setUseCaches(false);
            return localJarURLConnection.getJarFile();
          }
        });
      }
      catch (PrivilegedActionException localPrivilegedActionException)
      {
        localObject1 = new SecurityException("Cannot verify " + localURL.toString());
        ((SecurityException)localObject1).initCause(localPrivilegedActionException);
        throw ((Throwable)localObject1);
      }
      byte[] arrayOfByte = new byte[8192];
      Object localObject1 = new Vector();
      Enumeration localEnumeration = localJarFile.entries();
      while (localEnumeration.hasMoreElements())
      {
        localObject2 = (JarEntry)localEnumeration.nextElement();
        ((Vector)localObject1).addElement(localObject2);
        localObject3 = localJarFile.getInputStream((ZipEntry)localObject2);
        try
        {
          while (((InputStream)localObject3).read(arrayOfByte, 0, arrayOfByte.length) != -1);
        }
        finally
        {
          ((InputStream)localObject3).close();
        }
      }
      Object localObject2 = localJarFile.getManifest();
      if (localObject2 == null)
        throw new JarException(paramURL.toString() + " is not signed.");
      Object localObject3 = localJarFile.entries();
      while (((Enumeration)localObject3).hasMoreElements())
      {
        localObject5 = (JarEntry)((Enumeration)localObject3).nextElement();
        if (!((JarEntry)localObject5).isDirectory())
        {
          Certificate[] arrayOfCertificate = ((JarEntry)localObject5).getCertificates();
          if ((arrayOfCertificate == null) || (arrayOfCertificate.length == 0))
          {
            if (!((JarEntry)localObject5).getName().startsWith("META-INF"))
              throw new JarException(paramURL.toString() + " has unsigned entries - " + ((JarEntry)localObject5).getName());
          }
          else
          {
            int i = 0;
            int j = 0;
            X509Certificate[] arrayOfX509Certificate;
            while ((arrayOfX509Certificate = a(arrayOfCertificate, i)) != null)
            {
              if (paramX509Certificate.equals(arrayOfX509Certificate[0]))
              {
                j = 1;
                break;
              }
              i += arrayOfX509Certificate.length;
            }
            if (j == 0)
              throw new JarException(paramURL.toString() + " is not signed by a" + " trusted signer.");
          }
        }
      }
      Object localObject5 = ((Manifest)localObject2).getMainAttributes().getValue(Attributes.Name.CLASS_PATH);
      return localObject5;
    }
    finally
    {
      if (localJarFile != null)
      {
        localJarFile.close();
        localJarFile = null;
      }
    }
  }

  private static String[] a(String paramString)
    throws JarException
  {
    paramString = paramString.trim();
    int i = paramString.indexOf(' ');
    String str = null;
    Vector localVector = new Vector();
    int j = 0;
    do
    {
      if (i > 0)
      {
        str = paramString.substring(0, i);
        paramString = paramString.substring(i + 1).trim();
        i = paramString.indexOf(' ');
      }
      else
      {
        str = paramString;
        j = 1;
      }
      if (str.endsWith(".jar"))
        localVector.addElement(str);
      else
        throw new JarException("The provider contains un-verifiable components");
    }
    while (j == 0);
    String[] arrayOfString = new String[localVector.size()];
    localVector.copyInto(arrayOfString);
    return arrayOfString;
  }

  private static X509Certificate[] a(Certificate[] paramArrayOfCertificate, int paramInt)
  {
    if (paramInt > paramArrayOfCertificate.length - 1)
      return null;
    for (int i = paramInt; (i < paramArrayOfCertificate.length - 1) && (((X509Certificate)paramArrayOfCertificate[(i + 1)]).getSubjectDN().equals(((X509Certificate)paramArrayOfCertificate[i]).getIssuerDN())); i++);
    int j = i - paramInt + 1;
    X509Certificate[] arrayOfX509Certificate = new X509Certificate[j];
    for (int k = 0; k < j; k++)
      arrayOfX509Certificate[k] = ((X509Certificate)paramArrayOfCertificate[(paramInt + k)]);
    return arrayOfX509Certificate;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.sun.crypto.provider.SunJCE_b
 * JD-Core Version:    0.6.2
 */