package com.sun.crypto.provider;

import java.security.InvalidKeyException;
import javax.crypto.IllegalBlockSizeException;

abstract class SunJCE_h
{
  final SunJCE_e a;
  final int b;
  byte[] c;

  SunJCE_h(SunJCE_e paramSunJCE_e)
  {
    this.a = paramSunJCE_e;
    this.b = paramSunJCE_e.a();
  }

  final SunJCE_e e()
  {
    return this.a;
  }

  final int f()
  {
    return this.b;
  }

  abstract String a();

  abstract void c();

  abstract void d();

  abstract void a(boolean paramBoolean, String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws InvalidKeyException;

  final byte[] g()
  {
    return this.c;
  }

  abstract void b();

  abstract void a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3);

  void c(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws IllegalBlockSizeException
  {
    a(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3);
  }

  abstract void b(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3);

  void d(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
    throws IllegalBlockSizeException
  {
    b(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.sun.crypto.provider.SunJCE_h
 * JD-Core Version:    0.6.2
 */