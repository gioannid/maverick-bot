package com.sun.crypto.provider;

import java.security.InvalidKeyException;

final class SunJCE_o extends SunJCE_h
{
  private byte[] a = null;
  private byte[] b = null;
  private int c;
  private byte[] d = null;

  SunJCE_o(SunJCE_e paramSunJCE_e, int paramInt)
  {
    super(paramSunJCE_e);
    if (paramInt > this.b)
      paramInt = this.b;
    this.c = paramInt;
    this.a = new byte[this.b];
    this.b = new byte[this.b];
  }

  String a()
  {
    return "OFB";
  }

  void a(boolean paramBoolean, String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws InvalidKeyException
  {
    if ((paramArrayOfByte1 == null) || (paramArrayOfByte2 == null) || (paramArrayOfByte2.length != this.b))
      throw new InvalidKeyException("Internal error");
    this.c = paramArrayOfByte2;
    b();
    this.a.a(false, paramString, paramArrayOfByte1);
  }

  void b()
  {
    System.arraycopy(this.c, 0, this.b, 0, this.b);
  }

  void c()
  {
    if (this.d == null)
      this.d = new byte[this.b];
    System.arraycopy(this.b, 0, this.d, 0, this.b);
  }

  void d()
  {
    System.arraycopy(this.d, 0, this.b, 0, this.b);
  }

  void a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    int j = this.b - this.c;
    int k = paramInt2 / this.c;
    int m = paramInt2 % this.c;
    int i;
    if (j == 0)
    {
      while (k > 0)
      {
        this.a.a(this.b, 0, this.a, 0);
        for (i = 0; i < this.c; i++)
          paramArrayOfByte2[(i + paramInt3)] = ((byte)(this.a[i] ^ paramArrayOfByte1[(i + paramInt1)]));
        System.arraycopy(this.a, 0, this.b, 0, this.c);
        paramInt1 += this.c;
        paramInt3 += this.c;
        k--;
      }
      if (m > 0)
      {
        this.a.a(this.b, 0, this.a, 0);
        for (i = 0; i < m; i++)
          paramArrayOfByte2[(i + paramInt3)] = ((byte)(this.a[i] ^ paramArrayOfByte1[(i + paramInt1)]));
        System.arraycopy(this.a, 0, this.b, 0, this.c);
      }
    }
    else
    {
      while (k > 0)
      {
        this.a.a(this.b, 0, this.a, 0);
        for (i = 0; i < this.c; i++)
          paramArrayOfByte2[(i + paramInt3)] = ((byte)(this.a[i] ^ paramArrayOfByte1[(i + paramInt1)]));
        System.arraycopy(this.b, this.c, this.b, 0, j);
        System.arraycopy(this.a, 0, this.b, j, this.c);
        paramInt1 += this.c;
        paramInt3 += this.c;
        k--;
      }
      if (m > 0)
      {
        this.a.a(this.b, 0, this.a, 0);
        for (i = 0; i < m; i++)
          paramArrayOfByte2[(i + paramInt3)] = ((byte)(this.a[i] ^ paramArrayOfByte1[(i + paramInt1)]));
        System.arraycopy(this.b, this.c, this.b, 0, j);
        System.arraycopy(this.a, 0, this.b, j, this.c);
      }
    }
  }

  void b(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    a(paramArrayOfByte1, paramInt1, paramInt2, paramArrayOfByte2, paramInt3);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.sun.crypto.provider.SunJCE_o
 * JD-Core Version:    0.6.2
 */