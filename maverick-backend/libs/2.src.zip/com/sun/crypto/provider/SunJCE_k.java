package com.sun.crypto.provider;

import java.security.InvalidKeyException;

class SunJCE_k extends SunJCE_h
{
  protected byte[] a = new byte[this.b];
  private byte[] b = new byte[this.b];
  private byte[] c = null;

  SunJCE_k(SunJCE_e paramSunJCE_e)
  {
    super(paramSunJCE_e);
  }

  String a()
  {
    return "CBC";
  }

  void a(boolean paramBoolean, String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
    throws InvalidKeyException
  {
    if ((paramArrayOfByte1 == null) || (paramArrayOfByte2 == null) || (paramArrayOfByte2.length != this.b))
      throw new InvalidKeyException("Internal error");
    this.c = paramArrayOfByte2;
    b();
    this.a.a(paramBoolean, paramString, paramArrayOfByte1);
  }

  void b()
  {
    System.arraycopy(this.c, 0, this.a, 0, this.b);
  }

  void c()
  {
    if (this.c == null)
      this.c = new byte[this.b];
    System.arraycopy(this.a, 0, this.c, 0, this.b);
  }

  void d()
  {
    System.arraycopy(this.c, 0, this.a, 0, this.b);
  }

  void a(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    int j = paramInt1 + paramInt2;
    while (paramInt1 < j)
    {
      for (int i = 0; i < this.b; i++)
        this.b[i] = ((byte)(paramArrayOfByte1[(i + paramInt1)] ^ this.a[i]));
      this.a.a(this.b, 0, paramArrayOfByte2, paramInt3);
      System.arraycopy(paramArrayOfByte2, paramInt3, this.a, 0, this.b);
      paramInt1 += this.b;
      paramInt3 += this.b;
    }
  }

  void b(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    byte[] arrayOfByte = null;
    int j = paramInt1 + paramInt2;
    if ((paramArrayOfByte1 == paramArrayOfByte2) && (paramInt1 >= paramInt3) && (paramInt1 - paramInt3 < this.b))
      arrayOfByte = (byte[])paramArrayOfByte1.clone();
    while (paramInt1 < j)
    {
      this.a.b(paramArrayOfByte1, paramInt1, this.b, 0);
      for (int i = 0; i < this.b; i++)
        paramArrayOfByte2[(i + paramInt3)] = ((byte)(this.b[i] ^ this.a[i]));
      if (arrayOfByte == null)
        System.arraycopy(paramArrayOfByte1, paramInt1, this.a, 0, this.b);
      else
        System.arraycopy(arrayOfByte, paramInt1, this.a, 0, this.b);
      paramInt1 += this.b;
      paramInt3 += this.b;
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.sun.crypto.provider.SunJCE_k
 * JD-Core Version:    0.6.2
 */