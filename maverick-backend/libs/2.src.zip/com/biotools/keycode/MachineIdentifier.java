package com.biotools.keycode;

import com.biotools.A.e;
import com.biotools.poker.E;
import java.util.List;

public final class MachineIdentifier
{
  private static boolean B = false;
  public static String A = "00000000";

  static
  {
    try
    {
      B = true;
      String str = System.getProperty("os.name");
      if (str.equals("Linux"))
        System.loadLibrary("eval_linux");
      else if (str.equals("SunOS"))
        System.loadLibrary("eval_sunos");
      else if (str.equals("Mac OS X"))
        System.loadLibrary("eval");
      else if (str.startsWith("Windows"))
        System.loadLibrary("eval");
      else
        B = false;
    }
    catch (UnsatisfiedLinkError localUnsatisfiedLinkError)
    {
      B = false;
    }
    catch (Exception localException)
    {
      B = false;
    }
  }

  private static native String getMachineID();

  private static native String getAllMachineIDs();

  public static native boolean isCDMounted(String paramString);

  public static String getID()
  {
    if (E.Å())
    {
      str = e.E();
      if (str != null)
        return str.replaceAll("-", "");
    }
    if (!B)
      return A;
    String str = getMachineID();
    if (str == null)
      return A;
    if (str.length() == 0)
      return A;
    return str;
  }

  public static String[] getIDs()
  {
    if (!B)
      return null;
    String[] arrayOfString1 = getAllMachineIDs().split(",");
    if (E.Å())
    {
      List localList = e.B();
      if ((localList != null) && (localList.size() > 0))
      {
        String[] arrayOfString2 = new String[arrayOfString1.length + localList.size()];
        int i = 0;
        for (int j = 0; j < arrayOfString1.length; j++)
          arrayOfString2[(i++)] = arrayOfString1[j];
        for (j = 0; j < localList.size(); j++)
          arrayOfString2[(i++)] = ((String)localList.get(j)).replaceAll("-", "");
        return arrayOfString2;
      }
    }
    return arrayOfString1;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.keycode.MachineIdentifier
 * JD-Core Version:    0.6.2
 */