package com.biotools.meerkat;

import com.biotools.meerkat.util.Preferences;

public abstract interface Player extends GameObserver
{
  public abstract void init(Preferences paramPreferences);

  public abstract void holeCards(Card paramCard1, Card paramCard2, int paramInt);

  public abstract Action getAction();
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.meerkat.Player
 * JD-Core Version:    0.6.2
 */