package com.biotools.meerkat;

public abstract interface HandEval
{
  public abstract int rankHand(Hand paramHand);

  public abstract int rankHand7(Hand paramHand);

  public abstract int rankHand6(Hand paramHand);

  public abstract int rankHand5(Hand paramHand);
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.meerkat.HandEval
 * JD-Core Version:    0.6.2
 */