package com.biotools.meerkat;

import java.util.List;

public abstract interface GameInfo
{
  public abstract String getLogDirectory();

  public abstract long getGameID();

  public abstract int getStage();

  public abstract boolean isPreFlop();

  public abstract boolean isPostFlop();

  public abstract boolean isFlop();

  public abstract boolean isTurn();

  public abstract boolean isRiver();

  public abstract double getAnte();

  public abstract double getSmallBlindSize();

  public abstract double getBigBlindSize();

  public abstract double getCurrentBetSize();

  public abstract int nextSeat(int paramInt);

  public abstract int nextPlayer(int paramInt);

  public abstract int previousPlayer(int paramInt);

  public abstract int nextActivePlayer(int paramInt);

  public abstract Hand getBoard();

  public abstract double getTotalPotSize();

  public abstract double getMainPotSize();

  public abstract int getNumSidePots();

  public abstract double getSidePotSize(int paramInt);

  public abstract int getButtonSeat();

  public abstract int getSmallBlindSeat();

  public abstract int getBigBlindSeat();

  public abstract int getCurrentPlayerSeat();

  public abstract double getEligiblePot(int paramInt);

  public abstract int getNumPlayers();

  public abstract int getNumActivePlayers();

  public abstract int getNumberOfAllInPlayers();

  public abstract int getNumActivePlayersNotAllIn();

  public abstract int getNumToAct();

  public abstract int getUnacted();

  public abstract int getNumSeats();

  public abstract double getStakes();

  public abstract List getPlayersInPot(double paramDouble);

  public abstract PlayerInfo getPlayer(int paramInt);

  public abstract PlayerInfo getPlayer(String paramString);

  public abstract double getBetsToCall(int paramInt);

  public abstract double getAmountToCall(int paramInt);

  public abstract double getBankRoll(int paramInt);

  public abstract double getBankRollAtRisk(int paramInt);

  public abstract String getPlayerName(int paramInt);

  public abstract int getPlayerSeat(String paramString);

  public abstract boolean canRaise(int paramInt);

  public abstract boolean inGame(int paramInt);

  public abstract boolean isActive(int paramInt);

  public abstract boolean isCommitted(int paramInt);

  public abstract int getNumWinners();

  public abstract boolean isGameOver();

  public abstract boolean isNoLimit();

  public abstract boolean isFixedLimit();

  public abstract boolean isPotLimit();

  public abstract int getNumRaises();

  public abstract double getMinRaise();

  public abstract double getRake();

  public abstract boolean isSimulation();

  public abstract boolean isZipMode();

  public abstract boolean isReverseBlinds();
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.meerkat.GameInfo
 * JD-Core Version:    0.6.2
 */