package com.biotools.meerkat;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class Messages
{
  private static final String F = "com.biotools.meerkat.messages";
  private static ResourceBundle C;
  private static ResourceBundle E;
  private static Locale B;
  private static Locale D;
  private static ClassLoader A = null;

  private static final ResourceBundle B()
  {
    if (C == null)
      try
      {
        C = ResourceBundle.getBundle("com.biotools.meerkat.messages", getLocale(), A);
      }
      catch (MissingResourceException localMissingResourceException)
      {
        localMissingResourceException.printStackTrace();
        if (!getLocale().getLanguage().equalsIgnoreCase("en"))
        {
          setLocale(new Locale("en"));
          C = B();
        }
      }
    return C;
  }

  private static final ResourceBundle A()
  {
    if (E == null)
      try
      {
        E = ResourceBundle.getBundle("com.biotools.meerkat.messages", getLocaleEN(), A);
      }
      catch (MissingResourceException localMissingResourceException)
      {
        localMissingResourceException.printStackTrace();
      }
    return E;
  }

  public static String getString(String paramString, Object[] paramArrayOfObject)
  {
    return getString(false, paramString, paramArrayOfObject);
  }

  public static String getString(boolean paramBoolean, String paramString, Object[] paramArrayOfObject)
  {
    MessageFormat localMessageFormat = new MessageFormat(getString(paramBoolean, paramString), paramBoolean ? getLocaleEN() : getLocale());
    String str = localMessageFormat.format(paramArrayOfObject);
    return str;
  }

  public static String getString(String paramString)
  {
    return getString(false, paramString);
  }

  public static String getString(boolean paramBoolean, String paramString)
  {
    String str;
    try
    {
      if (paramBoolean)
        str = A().getString(paramString.trim());
      else
        str = B().getString(paramString.trim());
    }
    catch (Exception localException)
    {
      if (!paramBoolean)
      {
        str = getString(true, paramString);
      }
      else
      {
        if (!$assertionsDisabled)
          throw new AssertionError("Resource Bundle not found for " + paramString);
        str = "*" + paramString + "*";
      }
    }
    return str;
  }

  public static Locale getLocale()
  {
    if (B == null)
      setLocale();
    return B;
  }

  public static Locale getLocaleEN()
  {
    if (D == null)
      D = new Locale("en");
    return D;
  }

  public static void setLocale()
  {
    setLocale(new Locale("en"));
  }

  public static void setLocale(Locale paramLocale)
  {
    B = paramLocale;
    C = null;
  }

  public static void setLoader(ClassLoader paramClassLoader)
  {
    A = paramClassLoader;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.meerkat.Messages
 * JD-Core Version:    0.6.2
 */