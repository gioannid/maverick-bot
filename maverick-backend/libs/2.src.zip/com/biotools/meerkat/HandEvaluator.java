package com.biotools.meerkat;

import com.biotools.meerkat.util.NChoose2IntTable;

public class HandEvaluator
{
  private static HandEval A;

  public static final int rankHand(Hand paramHand)
  {
    return A.rankHand(paramHand);
  }

  public static final int rankHand7(Hand paramHand)
  {
    return A.rankHand7(paramHand);
  }

  public static final int rankHand6(Hand paramHand)
  {
    return A.rankHand6(paramHand);
  }

  public static final int rankHand5(Hand paramHand)
  {
    return A.rankHand5(paramHand);
  }

  public static int rankHand(int paramInt1, int paramInt2, Hand paramHand)
  {
    paramHand.addCard(paramInt1);
    paramHand.addCard(paramInt2);
    int i = A.rankHand(paramHand);
    paramHand.removeCard();
    paramHand.removeCard();
    return i;
  }

  public static int rankHand(Card paramCard1, Card paramCard2, Hand paramHand)
  {
    paramHand.addCard(paramCard1);
    paramHand.addCard(paramCard2);
    int i = A.rankHand(paramHand);
    paramHand.removeCard();
    paramHand.removeCard();
    return i;
  }

  public static int compareHands(Hand paramHand1, Hand paramHand2)
  {
    int i = rankHand(paramHand1);
    int j = rankHand(paramHand2);
    if (i > j)
      return 1;
    if (i < j)
      return 2;
    return 0;
  }

  public static int compareHands(int paramInt, Hand paramHand)
  {
    int i = paramInt;
    int j = rankHand(paramHand);
    if (i > j)
      return 1;
    if (i < j)
      return 2;
    return 0;
  }

  public static NChoose2IntTable getRanks(Hand paramHand)
  {
    Hand localHand = new Hand(paramHand);
    NChoose2IntTable localNChoose2IntTable = new NChoose2IntTable(52);
    Deck localDeck = new Deck();
    localDeck.extractHand(paramHand);
    for (int i = localDeck.getTopCardIndex(); i < 52; i++)
    {
      localHand.addCard(localDeck.getCard(i));
      int k = localDeck.getCard(i).getIndex();
      for (int j = i + 1; j < 52; j++)
      {
        localHand.addCard(localDeck.getCard(j));
        int m = localDeck.getCard(j).getIndex();
        localNChoose2IntTable.set(k, m, rankHand(localHand));
        localHand.removeCard();
      }
      localHand.removeCard();
    }
    return localNChoose2IntTable;
  }

  public static void getRanksSquare(Hand paramHand, int[][] paramArrayOfInt)
  {
    Hand localHand = new Hand(paramHand);
    Deck localDeck = new Deck();
    localDeck.extractHand(paramHand);
    for (int i = localDeck.getTopCardIndex(); i < 52; i++)
    {
      localHand.addCard(localDeck.getCard(i));
      int k = localDeck.getCard(i).getIndex();
      for (int j = i + 1; j < 52; j++)
      {
        localHand.addCard(localDeck.getCard(j));
        int m = localDeck.getCard(j).getIndex();
        int n = rankHand(localHand);
        paramArrayOfInt[k][m] = n;
        paramArrayOfInt[m][k] = n;
        localHand.removeCard();
      }
      localHand.removeCard();
    }
  }

  public static double handRank(Card paramCard1, Card paramCard2, Hand paramHand, int paramInt)
  {
    double d1 = handRank(paramCard1, paramCard2, paramHand);
    double d2 = d1;
    for (int i = 0; i < paramInt - 1; i++)
      d2 *= d1;
    return d2;
  }

  public static double handRank(Card paramCard1, Card paramCard2, Hand paramHand)
  {
    Hand localHand1 = new Hand(paramHand);
    Hand localHand2 = new Hand(paramHand);
    localHand1.addCard(paramCard1);
    localHand1.addCard(paramCard2);
    int m = rankHand(localHand1);
    Deck localDeck = new Deck();
    int n = 0;
    int i1 = 0;
    int i2 = 0;
    localDeck.reset();
    localDeck.extractCard(paramCard1);
    localDeck.extractCard(paramCard2);
    localDeck.extractHand(paramHand);
    for (int i = localDeck.getTopCardIndex(); i < 52; i++)
    {
      localHand2.addCard(localDeck.getCard(i));
      for (int j = i + 1; j < 52; j++)
      {
        localHand2.addCard(localDeck.getCard(j));
        int k = compareHands(m, localHand2);
        if (k == 1)
          n++;
        else if (k == 2)
          i1++;
        else
          i2++;
        localHand2.removeCard();
      }
      localHand2.removeCard();
    }
    return (n + i2 / 2.0D) / (n + i1 + i2);
  }

  public static double handRank(Card paramCard1, Card paramCard2, NChoose2IntTable paramNChoose2IntTable, Deck paramDeck)
  {
    int i = paramCard1.getIndex();
    int j = paramCard2.getIndex();
    int k = paramNChoose2IntTable.get(i, j);
    int m = 0;
    int n = 0;
    int i1 = 0;
    for (int i4 = paramDeck.getTopCardIndex(); i4 < 52; i4++)
    {
      int i5 = paramDeck.getCard(i4).getIndex();
      if ((i5 != i) && (i5 != j))
        for (int i2 = i4 + 1; i2 < 52; i2++)
        {
          int i6 = paramDeck.getCard(i2).getIndex();
          if ((i6 != i) && (i6 != j))
          {
            int i3 = paramNChoose2IntTable.get(i5, i6);
            if (k > i3)
              m++;
            else if (k < i3)
              n++;
            else
              i1++;
          }
        }
    }
    return (m + i1 / 2.0D) / (m + n + i1);
  }

  public static final boolean isTheNuts(Card paramCard1, Card paramCard2, Hand paramHand, NChoose2IntTable paramNChoose2IntTable)
  {
    Deck localDeck = new Deck();
    localDeck.extractCard(paramCard1);
    localDeck.extractCard(paramCard2);
    localDeck.extractHand(paramHand);
    int i = paramCard1.getIndex();
    int j = paramCard2.getIndex();
    int k = paramNChoose2IntTable.get(i, j);
    for (int m = localDeck.getTopCardIndex(); m < 52; m++)
    {
      int n = localDeck.getCard(m).getIndex();
      if ((n != i) && (n != j))
        for (int i1 = m + 1; i1 < 52; i1++)
        {
          int i2 = localDeck.getCard(i1).getIndex();
          if ((i2 != i) && (i2 != j) && (k < paramNChoose2IntTable.get(n, i2)))
            return false;
        }
    }
    return true;
  }

  public static HandEval getHandEval()
  {
    return A;
  }

  public static void setHandEval(HandEval paramHandEval)
  {
    A = paramHandEval;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.meerkat.HandEvaluator
 * JD-Core Version:    0.6.2
 */