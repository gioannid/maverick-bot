package com.biotools.meerkat;

public abstract interface GameObserver
{
  public abstract void actionEvent(int paramInt, Action paramAction);

  public abstract void stageEvent(int paramInt);

  public abstract void showdownEvent(int paramInt, Card paramCard1, Card paramCard2);

  public abstract void gameStartEvent(GameInfo paramGameInfo);

  public abstract void dealHoleCardsEvent();

  public abstract void gameOverEvent();

  public abstract void winEvent(int paramInt, double paramDouble, String paramString);

  public abstract void gameStateChanged();
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.meerkat.GameObserver
 * JD-Core Version:    0.6.2
 */