package com.biotools.meerkat;

import com.biotools.A.W;

public class Deck
{
  public static final int NUM_CARDS = 52;
  private transient W D = W.A();
  private Card[] C = new Card[52];
  private int[] B = new int[52];
  private int A = 0;

  public Deck()
  {
    for (int i = 0; i < 52; i++)
    {
      this.C[i] = new Card(i);
      this.B[i] = i;
    }
  }

  public void copy(Deck paramDeck)
  {
    System.arraycopy(paramDeck.C, 0, this.C, 0, 52);
    System.arraycopy(paramDeck.B, 0, this.B, 0, 52);
    this.A = paramDeck.A;
  }

  public Deck(long paramLong)
  {
    this();
    setSeed(paramLong);
  }

  public void setSeed(long paramLong)
  {
    if (paramLong != 0L)
    {
      this.D = new W();
      this.D.setSeed(paramLong);
    }
  }

  public void reset()
  {
    this.A = 0;
  }

  public void shuffle()
  {
    for (int i = 0; i < 52; i++)
    {
      int j = i + this.D.nextInt(52 - i);
      Card localCard = this.C[j];
      this.C[j] = this.C[i];
      this.C[i] = localCard;
      this.B[this.C[i].getIndex()] = i;
      this.B[this.C[j].getIndex()] = j;
    }
    this.A = 0;
  }

  public Card deal()
  {
    return this.A < 52 ? this.C[(this.A++)] : null;
  }

  public Card dealCard()
  {
    return extractRandomCard();
  }

  public int findCard(Card paramCard)
  {
    return this.B[paramCard.getIndex()];
  }

  public int findCard(int paramInt)
  {
    return this.B[paramInt];
  }

  public int findDiscard(Card paramCard)
  {
    return findDiscard(paramCard.getIndex());
  }

  public int findDiscard(int paramInt)
  {
    return this.B[paramInt];
  }

  public boolean inDeck(Card paramCard)
  {
    return this.B[paramCard.getIndex()] >= this.A;
  }

  public void extractHand(Hand paramHand)
  {
    for (int i = 1; i <= paramHand.size(); i++)
      if (paramHand.getCardIndex(i) >= 0)
        extractCard(paramHand.getCardIndex(i));
  }

  public void extractCard(int paramInt)
  {
    int i = findCard(paramInt);
    if (i != -1)
    {
      Card localCard = this.C[i];
      this.C[i] = this.C[this.A];
      this.C[this.A] = localCard;
      this.B[this.C[i].getIndex()] = i;
      this.B[localCard.getIndex()] = this.A;
      this.A += 1;
    }
    else if (!$assertionsDisabled)
    {
      throw new AssertionError();
    }
  }

  public void extractCardAtPosition(int paramInt)
  {
    Card localCard = this.C[paramInt];
    this.C[paramInt] = this.C[this.A];
    this.C[this.A] = localCard;
    this.B[this.C[paramInt].getIndex()] = paramInt;
    this.B[localCard.getIndex()] = this.A;
    this.A += 1;
  }

  public void replaceCardExtractedFromPosition(int paramInt)
  {
    this.A -= 1;
    Card localCard = this.C[paramInt];
    this.C[paramInt] = this.C[this.A];
    this.C[this.A] = localCard;
    this.B[this.C[paramInt].getIndex()] = paramInt;
    this.B[localCard.getIndex()] = this.A;
  }

  public void extractCard(Card paramCard)
  {
    extractCard(paramCard.getIndex());
  }

  public Card extractRandomCard()
  {
    int i = this.A + this.D.nextInt(52 - this.A);
    Card localCard = this.C[i];
    this.C[i] = this.C[this.A];
    this.C[this.A] = localCard;
    this.B[this.C[i].getIndex()] = i;
    this.B[localCard.getIndex()] = this.A;
    this.A += 1;
    return localCard;
  }

  public Card pickRandomCard()
  {
    return this.C[(this.A + this.D.nextInt(52 - this.A))];
  }

  public void replaceCard(Card paramCard)
  {
    replaceCard(paramCard.getIndex());
  }

  public void replaceCard(int paramInt)
  {
    int i = findDiscard(paramInt);
    if (i != -1)
    {
      this.A -= 1;
      Card localCard = this.C[i];
      this.C[i] = this.C[this.A];
      this.C[this.A] = localCard;
      this.B[this.C[i].getIndex()] = i;
      this.B[localCard.getIndex()] = this.A;
    }
  }

  public int getTopCardIndex()
  {
    return this.A;
  }

  public Card getTopCard()
  {
    return getCard(this.A);
  }

  public int cardsLeft()
  {
    return 52 - this.A;
  }

  public final Card getCard(int paramInt)
  {
    return this.C[paramInt];
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("* ");
    for (int i = 0; i < this.A; i++)
      localStringBuffer.append(this.C[i].toString() + " ");
    localStringBuffer.append("\n* ");
    for (i = this.A; i < 52; i++)
      localStringBuffer.append(this.C[i].toString() + " ");
    return localStringBuffer.toString();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.meerkat.Deck
 * JD-Core Version:    0.6.2
 */