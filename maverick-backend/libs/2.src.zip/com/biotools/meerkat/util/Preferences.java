package com.biotools.meerkat.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.util.SortedSet;
import java.util.StringTokenizer;
import java.util.TreeSet;
import java.util.Vector;

public class Preferences
  implements Serializable
{
  private Hashtable A = new Hashtable();
  private File B;
  private Vector D;
  private boolean C = false;

  public Preferences()
  {
  }

  public Preferences(Preferences paramPreferences)
  {
    this.C = paramPreferences.C;
    this.B = paramPreferences.B;
    this.A = new Hashtable(paramPreferences.A);
  }

  public Preferences(File paramFile)
  {
    this.B = paramFile;
    loadPreferences(this.B);
  }

  public Preferences(String paramString)
  {
    this.B = new File(paramString);
    loadPreferences(this.B);
  }

  public Preferences(String paramString1, String paramString2)
  {
    String[] arrayOfString = paramString1.split(paramString2);
    for (int i = 0; i < arrayOfString.length; i++)
      C(arrayOfString[i]);
  }

  private void C(String paramString)
  {
    if ((paramString.startsWith("#")) || (paramString.length() <= 2))
      return;
    StringTokenizer localStringTokenizer;
    String str1;
    if (paramString.startsWith(">"))
    {
      localStringTokenizer = new StringTokenizer(paramString, ">");
      if (localStringTokenizer.countTokens() == 1)
      {
        str1 = localStringTokenizer.nextToken();
        String str2 = this.B.getParent();
        if (str2 != null)
          loadPreferences(new File(str2 + "/" + str1));
        else
          loadPreferences(this.B);
      }
    }
    else
    {
      localStringTokenizer = new StringTokenizer(paramString, "=");
      if (localStringTokenizer.countTokens() == 2)
      {
        this.A.put(localStringTokenizer.nextToken(), B(localStringTokenizer.nextToken()));
      }
      else if ((localStringTokenizer.countTokens() == 1) && (paramString.endsWith("=")))
      {
        str1 = localStringTokenizer.nextToken();
        this.A.put(str1, "");
      }
    }
  }

  public boolean empty()
  {
    return this.A.size() == 0;
  }

  public void clearAll()
  {
    this.A.clear();
  }

  public String[] keys()
  {
    Set localSet = this.A.keySet();
    return (String[])localSet.toArray(new String[localSet.size()]);
  }

  public synchronized String getPreference(String paramString1, String paramString2)
  {
    String str = (String)this.A.get(paramString1);
    if (str == null)
      return paramString2;
    return str;
  }

  public synchronized String getPreference(String paramString)
  {
    return (String)this.A.get(paramString);
  }

  public synchronized int getIntPreference(String paramString)
  {
    try
    {
      String str = getPreference(paramString);
      if (str != null)
        return Integer.parseInt(str);
      return -1;
    }
    catch (NullPointerException localNullPointerException)
    {
      return -1;
    }
    catch (Exception localException)
    {
    }
    return -1;
  }

  public synchronized int getIntPreference(String paramString, int paramInt)
  {
    String str = getPreference(paramString);
    if (str != null)
      return Integer.parseInt(str);
    return paramInt;
  }

  public synchronized long getLongPreference(String paramString, long paramLong)
  {
    try
    {
      String str = getPreference(paramString);
      if (str != null)
        return Long.parseLong(str);
      return paramLong;
    }
    catch (Exception localException)
    {
    }
    return paramLong;
  }

  public synchronized double getDoublePreference(String paramString, double paramDouble)
  {
    String str = getPreference(paramString);
    if (str == null)
      return paramDouble;
    return Double.parseDouble(str);
  }

  public synchronized double getDoublePreference(String paramString)
  {
    String str = getPreference(paramString);
    if (str == null)
      return -1.0D;
    return Double.parseDouble(str);
  }

  public synchronized boolean getBooleanPreference(String paramString)
  {
    String str = getPreference(paramString);
    if (str == null)
      return false;
    return str.equals("true");
  }

  public synchronized boolean getBoolean(String paramString, boolean paramBoolean)
  {
    return getBooleanPreference(paramString, paramBoolean);
  }

  public synchronized int getInt(String paramString, int paramInt)
  {
    return getIntPreference(paramString, paramInt);
  }

  public synchronized double getDouble(String paramString, double paramDouble)
  {
    return getDoublePreference(paramString, paramDouble);
  }

  public synchronized long getLong(String paramString, long paramLong)
  {
    return getLongPreference(paramString, paramLong);
  }

  public synchronized String get(String paramString1, String paramString2)
  {
    return getPreference(paramString1, paramString2);
  }

  public synchronized void put(String paramString1, String paramString2)
  {
    setPreference(paramString1, paramString2);
  }

  public synchronized void putDouble(String paramString, double paramDouble)
  {
    setPreference(paramString, paramDouble);
  }

  public synchronized void putInt(String paramString, int paramInt)
  {
    setPreference(paramString, paramInt);
  }

  public synchronized void putBoolean(String paramString, boolean paramBoolean)
  {
    setPreference(paramString, paramBoolean);
  }

  public synchronized void putLong(String paramString, long paramLong)
  {
    setPreference(paramString, paramLong);
  }

  public synchronized boolean getBooleanPreference(String paramString, boolean paramBoolean)
  {
    String str = getPreference(paramString);
    if (str == null)
      return paramBoolean;
    return str.equals("true");
  }

  public synchronized void setPreference(String paramString1, String paramString2)
  {
    this.A.put(paramString1, paramString2);
    this.C = true;
    firePreferenceChangeEvent(paramString1, paramString2);
  }

  public synchronized void setPreference(String paramString, int paramInt)
  {
    setPreference(paramString, Integer.toString(paramInt));
    this.C = true;
  }

  public synchronized void setPreference(String paramString, long paramLong)
  {
    setPreference(paramString, Long.toString(paramLong));
    this.C = true;
  }

  public synchronized void setPreference(String paramString, boolean paramBoolean)
  {
    setPreference(paramString, Boolean.toString(paramBoolean));
    this.C = true;
  }

  public synchronized void setPreference(String paramString, double paramDouble)
  {
    setPreference(paramString, Double.toString(paramDouble));
    this.C = true;
  }

  public synchronized void savePreferences(String paramString)
  {
    savePreferences(new File(paramString));
  }

  public synchronized void savePreferences(File paramFile)
  {
    this.B = paramFile;
    savePreferences();
  }

  public synchronized void savePreferences()
  {
    try
    {
      RandomAccessFile localRandomAccessFile = new RandomAccessFile(this.B, "rw");
      Enumeration localEnumeration = this.A.keys();
      while (localEnumeration.hasMoreElements())
      {
        String str1 = (String)localEnumeration.nextElement();
        String str2 = str1 + "=" + A((String)this.A.get(str1)) + "\n";
        localRandomAccessFile.writeBytes(str2);
      }
      while (localRandomAccessFile.getFilePointer() < localRandomAccessFile.length())
        localRandomAccessFile.write(10);
      localRandomAccessFile.close();
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
    this.C = false;
  }

  public synchronized void saveSortedPreferences()
  {
    try
    {
      RandomAccessFile localRandomAccessFile = new RandomAccessFile(this.B, "rw");
      TreeSet localTreeSet = new TreeSet(this.A.keySet());
      Iterator localIterator = localTreeSet.iterator();
      while (localIterator.hasNext())
      {
        String str1 = (String)localIterator.next();
        String str2 = str1 + "=" + A((String)this.A.get(str1)) + "\n";
        localRandomAccessFile.writeBytes(str2);
      }
      while (localRandomAccessFile.getFilePointer() < localRandomAccessFile.length())
        localRandomAccessFile.write(10);
      localRandomAccessFile.close();
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
    this.C = false;
  }

  public String toString()
  {
    return toString('\n');
  }

  public String toString(char paramChar)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    Enumeration localEnumeration = this.A.keys();
    while (localEnumeration.hasMoreElements())
    {
      String str = (String)localEnumeration.nextElement();
      localStringBuffer.append(str);
      localStringBuffer.append('=');
      localStringBuffer.append((String)this.A.get(str));
      localStringBuffer.append(paramChar);
    }
    return localStringBuffer.toString();
  }

  public synchronized void loadPreferences(File paramFile)
  {
    try
    {
      RandomAccessFile localRandomAccessFile = new RandomAccessFile(paramFile, "r");
      while (localRandomAccessFile.getFilePointer() < localRandomAccessFile.length())
      {
        String str = localRandomAccessFile.readLine();
        C(str);
      }
      localRandomAccessFile.close();
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
    }
    catch (IOException localIOException)
    {
    }
    this.C = false;
  }

  protected String A(String paramString)
  {
    return paramString;
  }

  protected String B(String paramString)
  {
    return paramString;
  }

  public static String munkString(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i < paramString.length(); i++)
    {
      char c = paramString.charAt(i);
      if (((c >= 'a') && (c <= 'z')) || ((c >= 'A') && (c <= 'Z')) || ((c >= '0') && (c <= '9')) || (c == '.') || (c == '-'))
      {
        localStringBuffer.append(c);
      }
      else
      {
        localStringBuffer.append('{');
        localStringBuffer.append(Integer.toString(c));
        localStringBuffer.append('}');
      }
    }
    return localStringBuffer.toString();
  }

  public static String unmunkString(String paramString)
  {
    if (paramString == null)
      return null;
    StringBuffer localStringBuffer1 = new StringBuffer();
    for (int i = 0; i < paramString.length(); i++)
    {
      char c = paramString.charAt(i);
      if (((c >= 'a') && (c <= 'z')) || ((c >= 'A') && (c <= 'Z')) || ((c >= '0') && (c <= '9')) || (c == '.') || (c == '-') || (c == ' ') || (c == '<') || (c == '>') || (c == '/') || (c == '&') || (c == ';') || (c == '?') || (c == '\'') || (c == '"'))
      {
        localStringBuffer1.append(c);
      }
      else if (c == '{')
      {
        StringBuffer localStringBuffer2 = new StringBuffer();
        while (c != '}')
        {
          c = paramString.charAt(++i);
          if (c != '}')
            localStringBuffer2.append(c);
        }
        c = (char)Integer.decode(localStringBuffer2.toString()).intValue();
        localStringBuffer1.append(c);
      }
    }
    return localStringBuffer1.toString();
  }

  public String getFileName()
  {
    if (this.B != null)
      return this.B.getAbsolutePath();
    return null;
  }

  public File getFile()
  {
    return this.B;
  }

  public void removePreference(String paramString)
  {
    this.A.remove(paramString);
    this.C = true;
  }

  public boolean isDirty()
  {
    return this.C;
  }

  public void setDirty(boolean paramBoolean)
  {
    this.C = paramBoolean;
  }

  private synchronized Vector A()
  {
    if (this.D == null)
      this.D = new Vector();
    return this.D;
  }

  public synchronized void addPreferenceChangeListener(PreferenceChangeListener paramPreferenceChangeListener)
  {
    A().add(paramPreferenceChangeListener);
  }

  public synchronized void removePreferenceChangeListener(PreferenceChangeListener paramPreferenceChangeListener)
  {
    A().remove(paramPreferenceChangeListener);
  }

  public synchronized void firePreferenceChangeEvent(String paramString1, String paramString2)
  {
    if (this.D != null)
    {
      PreferenceChangeEvent localPreferenceChangeEvent = new PreferenceChangeEvent(this, paramString1, paramString2);
      for (int i = 0; i < this.D.size(); i++)
        ((PreferenceChangeListener)this.D.get(i)).preferenceChange(localPreferenceChangeEvent);
    }
  }

  public boolean hasPreference(String paramString)
  {
    return this.A.containsKey(paramString);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.meerkat.util.Preferences
 * JD-Core Version:    0.6.2
 */