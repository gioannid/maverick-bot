package com.biotools.meerkat.util;

import java.util.Arrays;

public class NChoose2IntTable
{
  private int[] A;

  public NChoose2IntTable(int paramInt)
  {
    this.A = new int[paramInt * (paramInt - 1) / 2];
  }

  public void initTable(int paramInt)
  {
    Arrays.fill(this.A, paramInt);
  }

  public final int getValue(int paramInt)
  {
    return this.A[paramInt];
  }

  public void setValue(int paramInt1, int paramInt2)
  {
    this.A[paramInt1] = paramInt2;
  }

  public final int length()
  {
    return this.A.length;
  }

  private final int A(int paramInt1, int paramInt2)
  {
    if (paramInt1 > paramInt2)
      return paramInt1 * (paramInt1 - 1) / 2 + paramInt2;
    if (paramInt1 < paramInt2)
      return paramInt2 * (paramInt2 - 1) / 2 + paramInt1;
    return -1;
  }

  public final int get(int paramInt1, int paramInt2)
  {
    return this.A[A(paramInt1, paramInt2)];
  }

  public final void set(int paramInt1, int paramInt2, int paramInt3)
  {
    this.A[A(paramInt1, paramInt2)] = paramInt3;
  }

  public int[] getValues()
  {
    return this.A;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.meerkat.util.NChoose2IntTable
 * JD-Core Version:    0.6.2
 */