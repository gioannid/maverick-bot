package com.biotools.meerkat.util;

import java.util.EventObject;

public class PreferenceChangeEvent extends EventObject
{
  private String A;
  private String B;

  public PreferenceChangeEvent(Object paramObject, String paramString1, String paramString2)
  {
    super(paramObject);
    this.A = paramString1;
    this.B = paramString2;
  }

  public String getKey()
  {
    return this.A;
  }

  public String getNewValue()
  {
    return this.B;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.meerkat.util.PreferenceChangeEvent
 * JD-Core Version:    0.6.2
 */