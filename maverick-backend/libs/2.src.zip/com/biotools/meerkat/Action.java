package com.biotools.meerkat;

import java.text.DecimalFormat;

public class Action
{
  public static final int INVALID = -1;
  public static final int FOLD = 0;
  public static final int CHECK = 1;
  public static final int CALL = 2;
  public static final int BET = 3;
  public static final int RAISE = 4;
  public static final int SMALL_BLIND = 5;
  public static final int BIG_BLIND = 6;
  public static final int POST_BLIND = 7;
  public static final int ALLIN_PASS = 8;
  public static final int MUCK = 9;
  public static final int POST_ANTE = 10;
  public static final int SIT_OUT = 11;
  public static final int POST_DEAD_BLIND = 12;
  private int C = -1;
  private double B = 0.0D;
  private double A = 0.0D;

  public Action(int paramInt, double paramDouble1, double paramDouble2)
  {
    this.C = paramInt;
    this.B = A(paramDouble2);
    this.A = A(paramDouble1);
  }

  public boolean equivalent(Action paramAction)
  {
    return (this.C == paramAction.C) && (this.B == paramAction.B) && (this.A == paramAction.A);
  }

  public double getAmount()
  {
    return this.B;
  }

  public double getToCall()
  {
    return this.A;
  }

  public int getType()
  {
    return this.C;
  }

  public static Action postAnte(double paramDouble)
  {
    return new Action(10, 0.0D, paramDouble);
  }

  public static Action sitout()
  {
    return new Action(11, 0.0D, 0.0D);
  }

  public static Action postBlindAction(double paramDouble)
  {
    return new Action(7, 0.0D, paramDouble);
  }

  public static Action postDeadBlindAction(double paramDouble)
  {
    return new Action(12, 0.0D, paramDouble);
  }

  public static Action smallBlindAction(double paramDouble)
  {
    return new Action(5, 0.0D, paramDouble);
  }

  public static Action bigBlindAction(double paramDouble)
  {
    return new Action(6, 0.0D, paramDouble);
  }

  public static Action foldAction(GameInfo paramGameInfo)
  {
    return foldAction(paramGameInfo.getAmountToCall(paramGameInfo.getCurrentPlayerSeat()));
  }

  public static Action foldAction(double paramDouble)
  {
    return new Action(0, paramDouble, 0.0D);
  }

  public static Action checkOrFoldAction(GameInfo paramGameInfo)
  {
    return checkOrFoldAction(paramGameInfo.getAmountToCall(paramGameInfo.getCurrentPlayerSeat()));
  }

  public static Action checkOrFoldAction(double paramDouble)
  {
    if (paramDouble > 0.0D)
      return new Action(0, paramDouble, 0.0D);
    return checkAction();
  }

  public static Action muckAction()
  {
    return new Action(9, 0.0D, 0.0D);
  }

  public static Action checkAction()
  {
    return new Action(1, 0.0D, 0.0D);
  }

  public static Action callAction(GameInfo paramGameInfo)
  {
    return callAction(paramGameInfo.getAmountToCall(paramGameInfo.getCurrentPlayerSeat()));
  }

  public static Action callAction(double paramDouble)
  {
    if (paramDouble == 0.0D)
      return checkAction();
    return new Action(2, paramDouble, 0.0D);
  }

  public static Action betAction(GameInfo paramGameInfo)
  {
    return betAction(paramGameInfo.getMinRaise());
  }

  public static Action betAction(double paramDouble)
  {
    return new Action(3, 0.0D, paramDouble);
  }

  public static Action raiseAction(GameInfo paramGameInfo)
  {
    return raiseAction(paramGameInfo, paramGameInfo.getMinRaise());
  }

  public static Action raiseAction(GameInfo paramGameInfo, double paramDouble)
  {
    return raiseAction(paramGameInfo.getAmountToCall(paramGameInfo.getCurrentPlayerSeat()), paramDouble);
  }

  public static Action raiseAction(double paramDouble1, double paramDouble2)
  {
    if (paramDouble2 <= 0.0D)
      return callAction(paramDouble1);
    if (paramDouble1 == 0.0D)
      return betAction(paramDouble2);
    return new Action(4, paramDouble1, paramDouble2);
  }

  public static Action allInPassAction()
  {
    return new Action(8, 0.0D, 0.0D);
  }

  public boolean isFold()
  {
    return this.C == 0;
  }

  public boolean isFoldOrMuck()
  {
    return (this.C == 0) || (this.C == 9);
  }

  public boolean isCheck()
  {
    return this.C == 1;
  }

  public boolean isCall()
  {
    return this.C == 2;
  }

  public boolean isCheckOrCall()
  {
    return (this.C == 2) || (this.C == 1);
  }

  public boolean isBet()
  {
    return this.C == 3;
  }

  public boolean isRaise()
  {
    return this.C == 4;
  }

  public boolean isBetOrRaise()
  {
    return (this.C == 3) || (this.C == 4);
  }

  public boolean isBlind()
  {
    return (this.C == 5) || (this.C == 6) || (this.C == 7) || (this.C == 12);
  }

  public boolean isPost()
  {
    return (this.C == 7) || (this.C == 12);
  }

  public boolean isPostDeadBlind()
  {
    return this.C == 12;
  }

  public boolean isSmallBlind()
  {
    return this.C == 5;
  }

  public boolean isBigBlind()
  {
    return this.C == 6;
  }

  public boolean isAllInPass()
  {
    return this.C == 8;
  }

  public boolean isSitout()
  {
    return this.C == 11;
  }

  public boolean isMuck()
  {
    return this.C == 9;
  }

  public boolean isAnte()
  {
    return this.C == 10;
  }

  public int getActionIndex()
  {
    switch (this.C)
    {
    case 0:
      return 0;
    case 1:
      return 1;
    case 2:
      return 1;
    case 3:
      return 2;
    case 4:
      return 2;
    }
    return -1;
  }

  public static Action getAction(int paramInt, double paramDouble1, double paramDouble2)
  {
    switch (paramInt)
    {
    case 0:
      return checkOrFoldAction(paramDouble1);
    case 1:
      return callAction(paramDouble1);
    case 2:
      return raiseAction(paramDouble1, paramDouble2);
    }
    return null;
  }

  public String toString()
  {
    Object[] arrayOfObject1 = { formatCash(this.B) };
    switch (this.C)
    {
    case 5:
      return Messages.getString("Action.BlindPattern", arrayOfObject1);
    case 6:
      return Messages.getString("Action.BlindPattern", arrayOfObject1);
    case 7:
      return Messages.getString("Action.PostPattern", arrayOfObject1);
    case 12:
      return Messages.getString("Action.PostDeadPattern", arrayOfObject1);
    case 10:
      return Messages.getString("Action.AntePattern", arrayOfObject1);
    case 0:
      return Messages.getString("Action.Fold");
    case 9:
      return Messages.getString("Action.Muck");
    case 1:
      return Messages.getString("Action.Check");
    case 2:
      Object[] arrayOfObject2 = { formatCash(this.A) };
      return Messages.getString("Action.CallPattern", arrayOfObject2);
    case 3:
      return Messages.getString("Action.BetPattern", arrayOfObject1);
    case 4:
      return Messages.getString("Action.RaisePattern", arrayOfObject1);
    case 8:
      return Messages.getString("Action.AllIn");
    case 11:
      return Messages.getString("Action.SitsOut");
    }
    return "";
  }

  public String toStringForTranscript(boolean paramBoolean)
  {
    Object[] arrayOfObject1 = { formatCash(paramBoolean, this.B) };
    switch (this.C)
    {
    case 5:
      return Messages.getString(paramBoolean, "Action.SmallBlindLongPattern", arrayOfObject1);
    case 6:
      return Messages.getString(paramBoolean, "Action.BigBlindLongPattern", arrayOfObject1);
    case 7:
      return Messages.getString(paramBoolean, "Action.BlindLongPattern", arrayOfObject1);
    case 12:
      return Messages.getString(paramBoolean, "Action.PostDeadLongPattern", arrayOfObject1);
    case 10:
      return Messages.getString(paramBoolean, "Action.AnteLongPattern", arrayOfObject1);
    case 0:
      return Messages.getString(paramBoolean, "Action.FoldLong");
    case 9:
      return Messages.getString(paramBoolean, "Action.MuckLong");
    case 1:
      return Messages.getString(paramBoolean, "Action.CheckLong");
    case 2:
      Object[] arrayOfObject2 = { formatCash(paramBoolean, this.A) };
      return Messages.getString(paramBoolean, "Action.CallLongPattern", arrayOfObject2);
    case 3:
      return Messages.getString(paramBoolean, "Action.BetLongPattern", arrayOfObject1);
    case 4:
      return Messages.getString(paramBoolean, "Action.RaiseLongPattern", arrayOfObject1);
    case 8:
      return Messages.getString(paramBoolean, "Action.AllInLong");
    case 11:
      return Messages.getString(paramBoolean, "Action.SitOutLong");
    }
    return "";
  }

  public static String formatCash(double paramDouble)
  {
    return formatCash(false, paramDouble);
  }

  public static String formatCash(boolean paramBoolean, double paramDouble)
  {
    DecimalFormat localDecimalFormat1 = new DecimalFormat(Messages.getString(paramBoolean, "Action.DollarFormatWithCents"));
    DecimalFormat localDecimalFormat2 = new DecimalFormat(Messages.getString(paramBoolean, "Action.DollarFormat"));
    if (paramDouble == (int)paramDouble)
      return localDecimalFormat2.format(paramDouble);
    return localDecimalFormat1.format(paramDouble);
  }

  public static String formatCashFull(double paramDouble)
  {
    DecimalFormat localDecimalFormat = new DecimalFormat(Messages.getString("Action.DollarFormatWithCents"));
    return localDecimalFormat.format(paramDouble);
  }

  public boolean isVoluntary()
  {
    return (!isAnte()) && (!isAllInPass()) && (!isBlind());
  }

  private double A(double paramDouble)
  {
    return Math.round(paramDouble * 100.0D) / 100.0D;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.meerkat.Action
 * JD-Core Version:    0.6.2
 */