package com.biotools.meerkat;

import com.biotools.poker.E;
import java.io.Serializable;
import java.util.StringTokenizer;

public final class Hand
  implements Serializable
{
  public static final int MAX_CARDS = 7;
  private int[] A = new int[8];

  public Hand()
  {
    this.A[0] = 0;
  }

  public Hand(String paramString)
  {
    this.A[0] = 0;
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, " -");
    while (localStringTokenizer.hasMoreTokens())
    {
      String str = localStringTokenizer.nextToken();
      if (str.length() == 2)
      {
        Card localCard = new Card(str.charAt(0), str.charAt(1));
        if (localCard.getIndex() != -1)
          addCard(localCard);
      }
    }
  }

  public Hand(Hand paramHand)
  {
    this.A[0] = paramHand.size();
    for (int i = 1; i <= this.A[0]; i++)
      this.A[i] = paramHand.A[i];
  }

  public void clear()
  {
    this.A[0] = 0;
  }

  public final int size()
  {
    return this.A[0];
  }

  public void removeCard()
  {
    assert (this.A[0] > 0);
    this.A[0] -= 1;
  }

  public void makeEmpty()
  {
    this.A[0] = 0;
  }

  public boolean addCard(Card paramCard)
  {
    if ((paramCard == null) || (this.A[0] == 7))
      return false;
    this.A[0] += 1;
    this.A[this.A[0]] = paramCard.getIndex();
    return true;
  }

  public boolean addCard(int paramInt)
  {
    if (this.A[0] == 7)
      return false;
    this.A[0] += 1;
    this.A[this.A[0]] = paramInt;
    return true;
  }

  public Card getCard(int paramInt)
  {
    assert ((paramInt >= 1) && (paramInt <= this.A[0]));
    return new Card(this.A[paramInt]);
  }

  public int getCardIndex(int paramInt)
  {
    return this.A[paramInt];
  }

  public int getLastCardIndex()
  {
    return this.A[this.A[0]];
  }

  public void setCard(int paramInt, Card paramCard)
  {
    if (this.A[0] < paramInt)
      this.A[0] = paramInt;
    this.A[paramInt] = paramCard.getIndex();
  }

  public void setCard(int paramInt1, int paramInt2)
  {
    if (this.A[0] < paramInt1)
      this.A[0] = paramInt1;
    this.A[paramInt1] = paramInt2;
  }

  public int[] getCardArray()
  {
    return this.A;
  }

  public void sort()
  {
    int i = 1;
    while (i != 0)
    {
      i = 0;
      for (int j = 1; j < this.A[0]; j++)
        if (this.A[j] < this.A[(j + 1)])
        {
          i = 1;
          int k = this.A[j];
          this.A[j] = this.A[(j + 1)];
          this.A[(j + 1)] = k;
        }
    }
  }

  public boolean equals(Hand paramHand)
  {
    if (paramHand.size() != this.A[0])
      return false;
    for (int i = 1; i <= this.A[0]; i++)
      if (this.A[i] != paramHand.A[i])
        return false;
    return true;
  }

  public String toString()
  {
    String str = new String();
    for (int i = 1; i <= this.A[0]; i++)
      str = str + " " + getCard(i).toString();
    return str.trim();
  }

  public String toTranslatedString()
  {
    String str = new String();
    for (int i = 1; i <= this.A[0]; i++)
      str = str + " " + getCard(i).toTranslatedString();
    return str.trim();
  }

  public String flashingString()
  {
    String str1 = new String();
    for (int i = 1; i <= this.A[0]; i++)
    {
      String str2 = getCard(i).toTranslatedString();
      if (!str2.equals("??"))
        str1 = str1 + " " + str2;
    }
    return str1.trim();
  }

  public boolean contains(Card paramCard)
  {
    if (paramCard == null)
      return false;
    for (int i = 1; i <= size(); i++)
      if (getCard(i).equals(paramCard))
        return true;
    return false;
  }

  public void addHand(Hand paramHand)
  {
    for (int i = 1; i <= paramHand.size(); i++)
      addCard(paramHand.getCard(i));
  }

  public void clearBadCards()
  {
    for (int i = size(); i > 0; i--)
      if (!getCard(i).valid())
        removeCard(i);
  }

  public void removeCard(int paramInt)
  {
    for (int i = paramInt; i < size(); i++)
      this.A[i] = this.A[(i + 1)];
    if (this.A[0] > 0)
      this.A[0] -= 1;
  }

  public static String getCardString(Card paramCard1, Card paramCard2)
  {
    if ((!paramCard1.valid()) || (!paramCard2.valid()))
      return "??";
    if (paramCard1.getRank() < paramCard2.getRank())
    {
      Card localCard = paramCard1;
      paramCard1 = paramCard2;
      paramCard2 = localCard;
    }
    if (paramCard1.getRank() == paramCard2.getRank())
      return Card.getRankChar(paramCard1.getRank()) + Card.getRankChar(paramCard2.getRank());
    if (paramCard1.getSuit() == paramCard2.getSuit())
      return Card.getRankChar(paramCard1.getRank()) + Card.getRankChar(paramCard2.getRank()) + "s";
    return Card.getRankChar(paramCard1.getRank()) + Card.getRankChar(paramCard2.getRank()) + "o";
  }

  public static String getTranslatedCardString(Card paramCard1, Card paramCard2)
  {
    if ((!paramCard1.valid()) || (!paramCard2.valid()))
      return "??";
    if (paramCard1.getRank() < paramCard2.getRank())
    {
      localObject = paramCard1;
      paramCard1 = paramCard2;
      paramCard2 = (Card)localObject;
    }
    Object localObject = { Card.getExpandedRankString(paramCard1.getRank()), Card.getExpandedRankString(paramCard2.getRank()) };
    String str;
    if (paramCard1.getRank() == paramCard2.getRank())
      str = "HandInfo.PairPattern";
    else if (paramCard1.getSuit() == paramCard2.getSuit())
      str = "HandInfo.SuitedPattern";
    else
      str = "HandInfo.OffsuitPattern";
    return E.A(str, (Object[])localObject);
  }

  public final Card getLastCard()
  {
    return getCard(this.A[0]);
  }

  public Card getFirstCard()
  {
    return getCard(1);
  }

  public Card getSecondCard()
  {
    return getCard(2);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.meerkat.Hand
 * JD-Core Version:    0.6.2
 */