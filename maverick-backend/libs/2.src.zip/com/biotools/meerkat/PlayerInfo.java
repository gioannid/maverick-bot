package com.biotools.meerkat;

public abstract interface PlayerInfo
{
  public abstract double getNetGain();

  public abstract double getBankRoll();

  public abstract double getBankRollAtStartOfHand();

  public abstract double getBankRollInSmallBets();

  public abstract boolean inGame();

  public abstract int getSeat();

  public abstract String getName();

  public abstract boolean isAllIn();

  public abstract boolean isSittingOut();

  public abstract Hand getRevealedHand();

  public abstract double getAmountToCall();

  public abstract boolean isCommitted();

  public abstract boolean hasActedThisRound();

  public abstract double getAmountInPot();

  public abstract double getAmountInPotThisRound();

  public abstract int getLastAction();

  public abstract GameInfo getGameInfo();

  public abstract boolean isActive();

  public abstract boolean isFolded();

  public abstract boolean isButton();

  public abstract boolean hasEnoughToRaise();

  public abstract double getAmountRaiseable();

  public abstract double getAmountCallable();

  public abstract String toString();

  public abstract double getBankRollAtRisk();

  public abstract double getRaiseAmount(double paramDouble);
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.meerkat.PlayerInfo
 * JD-Core Version:    0.6.2
 */