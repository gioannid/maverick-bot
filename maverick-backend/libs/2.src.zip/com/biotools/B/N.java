package com.biotools.B;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;

public class N extends JTable
{
  public static final Color A = new Color(240, 240, 255);

  public N(TableModel paramTableModel)
  {
    super(paramTableModel);
    getTableHeader().setReorderingAllowed(false);
    setShowGrid(false);
  }

  public N()
  {
    setShowGrid(false);
  }

  public Component prepareRenderer(TableCellRenderer paramTableCellRenderer, int paramInt1, int paramInt2)
  {
    Component localComponent = super.prepareRenderer(paramTableCellRenderer, paramInt1, paramInt2);
    if (paramInt1 % 2 == 0)
      localComponent.setBackground(Color.WHITE);
    else
      localComponent.setBackground(A);
    if (getSelectionModel().isSelectedIndex(paramInt1))
      localComponent.setBackground(localComponent.getBackground().darker());
    return localComponent;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.B.N
 * JD-Core Version:    0.6.2
 */