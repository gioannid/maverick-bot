package com.biotools.B;

import com.biotools.A.I;
import com.jgoodies.looks.plastic.PlasticXPUtils;
import java.awt.Color;
import java.awt.Component;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.JComponent;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JSlider;

public class A
{
  public static Color M;
  public static Color D;
  public static Color P;
  public static Color I;
  public static Color L;
  public static Color E;
  public static Color Q;
  public static Color K;
  public static Color J;
  public static Color H;
  public static Color A;
  public static Color O;
  public static Color G;
  public static Color B;
  public static Color C;
  public static Color F;
  private static boolean N = true;

  static
  {
    A(true, new Color(255, 190, 140), new Color(93, 27, 27));
  }

  public static void A(boolean paramBoolean, Color paramColor1, Color paramColor2)
  {
    M = paramColor2;
    D = paramColor1;
    P = paramColor2;
    I = paramColor1;
    L = paramBoolean ? paramColor2.brighter().brighter() : paramColor1.brighter().brighter();
    E = paramColor2;
    Q = paramColor1;
    K = paramColor1;
    J = paramBoolean ? paramColor1 : paramColor2;
    H = paramColor2;
    A = paramColor1;
    O = paramBoolean ? paramColor1.darker() : paramColor1;
    G = paramBoolean ? paramColor2 : paramColor1;
    B = paramBoolean ? paramColor1 : paramColor2;
    C = L.A(paramColor2, paramColor1, 0.5D);
    F = paramBoolean ? new Color(150, 230, 230) : Color.BLUE.darker();
    PlasticXPUtils.setColors(paramBoolean, paramColor1, paramColor2);
  }

  public static void A(Map paramMap)
  {
    Iterator localIterator = paramMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      Color localColor = (Color)paramMap.get(str);
      if (str.equals("BGCOL"))
        M = localColor;
      if (str.equals("FGCOL"))
        D = localColor;
      if (str.equals("MB_BGCOL"))
        P = localColor;
      if (str.equals("MB_FGCOL"))
        I = localColor;
      if (str.equals("MB_DISCOL"))
        L = localColor;
      if (str.equals("SB_BG"))
        E = localColor;
      if (str.equals("SB_FG"))
        Q = localColor;
      if (str.equals("SB_ARROW"))
        K = localColor;
      if (str.equals("SB_SHADOW"))
        J = localColor;
      if (str.equals("SB_DARK_SHADOW"))
        H = localColor;
      if (str.equals("SB_HILIGHT"))
        A = localColor;
      if (str.equals("SB_THUMB"))
        O = localColor;
      if (str.equals("SB_THUMB_SHADOW"))
        G = localColor;
      if (str.equals("SB_THUMB_HILIGHT"))
        B = localColor;
      if (str.equals("ADMIN_TEXT"))
        F = localColor;
    }
    PlasticXPUtils.setColors(paramMap);
  }

  public static void B(String paramString)
  {
    PrintWriter localPrintWriter = null;
    try
    {
      localPrintWriter = new PrintWriter(new BufferedOutputStream(new FileOutputStream(paramString)));
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      I.A("Could not save scheme", localFileNotFoundException);
      return;
    }
    localPrintWriter.println("#\n# Colors are in rrggbb format where each component is a hex integer (like web colors)\n#\n\n# main colors\n");
    A(M, "BGCOL", localPrintWriter);
    A(D, "FGCOL", localPrintWriter);
    localPrintWriter.println("\n# menubar colors\n");
    A(P, "MB_BGCOL", localPrintWriter);
    A(I, "MB_FGCOL", localPrintWriter);
    A(L, "MB_DISCOL", localPrintWriter);
    localPrintWriter.println("\n# scrollbar colors\n");
    A(E, "SB_BG", localPrintWriter);
    A(Q, "SB_FG", localPrintWriter);
    A(K, "SB_ARROW", localPrintWriter);
    A(J, "SB_SHADOW", localPrintWriter);
    A(H, "SB_DARK_SHADOW", localPrintWriter);
    A(A, "SB_HILIGHT", localPrintWriter);
    A(O, "SB_THUMB", localPrintWriter);
    A(G, "SB_THUMB_SHADOW", localPrintWriter);
    A(B, "SB_THUMB_HILIGHT", localPrintWriter);
    A(F, "ADMIN_TEXT", localPrintWriter);
    localPrintWriter.println("\n# whether or not to colorize popup menus\n");
    localPrintWriter.println("doMenus=" + (N ? "true" : "false"));
    localPrintWriter.close();
  }

  private static void A(Color paramColor, String paramString, PrintWriter paramPrintWriter)
  {
    int i = paramColor.getRGB();
    i &= 16777215;
    paramPrintWriter.println(paramString + "=" + Integer.toHexString(i));
  }

  public static void A(String paramString)
  {
    String str1 = "data/schemes/" + paramString + ".col";
    try
    {
      HashMap localHashMap = new HashMap();
      BufferedReader localBufferedReader = new BufferedReader(new FileReader(str1));
      for (String str2 = localBufferedReader.readLine(); str2 != null; str2 = localBufferedReader.readLine())
        if ((!str2.trim().startsWith("#")) && (str2.trim().length() != 0))
        {
          String[] arrayOfString = str2.split("=");
          if (arrayOfString[0].equalsIgnoreCase("doMenus"))
          {
            N = arrayOfString[1].equalsIgnoreCase("true");
          }
          else
          {
            int i = Integer.parseInt(arrayOfString[1], 16);
            localHashMap.put(arrayOfString[0], new Color(i));
          }
        }
      localBufferedReader.close();
      A(localHashMap);
    }
    catch (Exception localException)
    {
      I.A("Could not read color scheme: " + str1, localException);
    }
  }

  public static List A()
  {
    File[] arrayOfFile = new File("data/schemes").listFiles();
    ArrayList localArrayList = new ArrayList(0);
    for (int i = 0; i < arrayOfFile.length; i++)
    {
      String str = arrayOfFile[i].getName();
      if (str.endsWith("col"))
        localArrayList.add(str.substring(0, str.length() - 4));
    }
    return localArrayList;
  }

  public static void A(JComponent paramJComponent)
  {
    if (paramJComponent == null)
      return;
    if (((paramJComponent instanceof JMenuBar)) && (!N))
    {
      paramJComponent.setForeground(D);
      paramJComponent.setBackground(M);
      for (int i = 0; i < paramJComponent.getComponentCount(); i++)
      {
        Component localComponent = paramJComponent.getComponent(i);
        if ((localComponent instanceof JComponent))
        {
          localComponent.setForeground(D);
          localComponent.setBackground(M);
        }
      }
      return;
    }
    if (((paramJComponent instanceof JMenu)) && (!N))
      return;
    if (((paramJComponent instanceof JPopupMenu)) && (!N))
      return;
    B(paramJComponent);
  }

  private static void B(JComponent paramJComponent)
  {
    if (paramJComponent == null)
      return;
    paramJComponent.setForeground(D);
    paramJComponent.setBackground(M);
    Object localObject1;
    if ((paramJComponent instanceof JMenu))
    {
      localObject1 = (JMenu)paramJComponent;
      B(((JMenu)localObject1).getPopupMenu());
      return;
    }
    Object localObject2;
    if ((paramJComponent instanceof JSlider))
    {
      localObject1 = ((JSlider)paramJComponent).getLabelTable().keys();
      while (((Enumeration)localObject1).hasMoreElements())
      {
        localObject2 = ((JSlider)paramJComponent).getLabelTable().get(((Enumeration)localObject1).nextElement());
        if ((localObject2 instanceof JComponent))
          B((JComponent)localObject2);
      }
    }
    for (int i = 0; i < paramJComponent.getComponentCount(); i++)
    {
      localObject2 = paramJComponent.getComponent(i);
      if ((localObject2 instanceof JComponent))
      {
        B((JComponent)localObject2);
      }
      else
      {
        paramJComponent.setForeground(D);
        paramJComponent.setBackground(M);
      }
    }
  }

  public static void A(JComponent paramJComponent, Color paramColor)
  {
    if (paramJComponent == null)
      return;
    if ((paramJComponent instanceof JPanel))
      paramJComponent.setBackground(paramColor);
    for (int i = 0; i < paramJComponent.getComponentCount(); i++)
    {
      Component localComponent = paramJComponent.getComponent(i);
      if ((localComponent instanceof JComponent))
        A((JComponent)localComponent, paramColor);
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.B.A
 * JD-Core Version:    0.6.2
 */