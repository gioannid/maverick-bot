package com.biotools.B;

import java.awt.Component;
import java.awt.Dimension;
import java.util.Map;

public class K extends J
{
  private static Map[] F;

  protected static void B(Component paramComponent)
  {
    String str1 = "pix/toolbar/pill/";
    String[] arrayOfString1 = { "pill_on.png", "pill_off.png", "pill_disabled.png", "pill_pressed.png" };
    String[] arrayOfString2 = { "load-table.png", "start-game.png", "connect.png", "resume-unfinished.png", "create-room.png", "join-room.png", "disconnect.png", "next-page.png", "prev-page.png", "unregister.png" };
    F = A(paramComponent, str1, arrayOfString1, arrayOfString2);
    arrayOfString1[1] = "pill_special.png";
    String[] arrayOfString3 = { "resume-game.png", "register.png" };
    Map[] arrayOfMap = A(paramComponent, str1, arrayOfString1, arrayOfString3);
    String str2 = arrayOfString3[0];
    for (int i = 0; i < 4; i++)
      F[i].put(str2, arrayOfMap[i].get(str2));
    str2 = arrayOfString3[1];
    for (i = 0; i < 4; i++)
      F[i].put(str2, arrayOfMap[i].get(str2));
  }

  public K(String paramString1, String paramString2)
  {
    super(paramString1, paramString2, new Dimension(158, 33));
  }

  protected Map[] A()
  {
    return F;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.B.K
 * JD-Core Version:    0.6.2
 */