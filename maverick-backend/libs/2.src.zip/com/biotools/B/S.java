package com.biotools.B;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Vector;
import javax.swing.JFormattedTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class S extends JFormattedTextField
  implements PropertyChangeListener
{
  private static NumberFormat E = NumberFormat.getNumberInstance();
  private int B = -2147483648;
  private int A = 2147483647;
  private Vector D = new Vector();
  private boolean C = false;

  public S(int paramInt1, int paramInt2)
  {
    super(E);
    E.setParseIntegerOnly(true);
    setValue(new Integer(paramInt1));
    setColumns(paramInt2);
    addPropertyChangeListener("value", this);
    selectAll();
    addMouseListener(new MouseAdapter()
    {
      public void mouseEntered(MouseEvent paramAnonymousMouseEvent)
      {
        S.this.requestFocus();
        S.this.selectAll();
      }

      public void mousePressed(MouseEvent paramAnonymousMouseEvent)
      {
        S.this.requestFocus();
        S.this.selectAll();
      }
    });
    requestFocusInWindow();
  }

  public void A(int paramInt1, int paramInt2)
  {
    this.B = paramInt1;
    this.A = paramInt2;
  }

  public void C(int paramInt)
  {
    setValue(new Integer(paramInt));
  }

  public void A(int paramInt)
  {
    this.A = paramInt;
  }

  public void B(int paramInt)
  {
    this.B = paramInt;
  }

  public int B()
  {
    try
    {
      commitEdit();
    }
    catch (ParseException localParseException)
    {
    }
    return ((Number)getValue()).intValue();
  }

  public void B(ChangeListener paramChangeListener)
  {
    this.D.add(paramChangeListener);
  }

  public void A(ChangeListener paramChangeListener)
  {
    this.D.remove(paramChangeListener);
  }

  public void A()
  {
    if (!this.C)
    {
      ChangeEvent localChangeEvent = new ChangeEvent(this);
      for (int i = 0; i < this.D.size(); i++)
        ((ChangeListener)this.D.get(i)).stateChanged(localChangeEvent);
    }
  }

  public void propertyChange(PropertyChangeEvent paramPropertyChangeEvent)
  {
    A();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.B.S
 * JD-Core Version:    0.6.2
 */