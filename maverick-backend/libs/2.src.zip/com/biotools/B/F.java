package com.biotools.B;

import java.awt.AlphaComposite;
import java.awt.Composite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.Icon;
import javax.swing.JLabel;

public class F extends JLabel
{
  double A = 1.0D;

  public F(double paramDouble, String paramString)
  {
    super(paramString);
    this.A = paramDouble;
    setOpaque(false);
  }

  public F(double paramDouble, String paramString, int paramInt)
  {
    super(paramString, paramInt);
    this.A = paramDouble;
    setOpaque(false);
  }

  public F(double paramDouble, Icon paramIcon)
  {
    super(paramIcon);
    this.A = paramDouble;
    setOpaque(false);
  }

  public void A(double paramDouble)
  {
    this.A = paramDouble;
  }

  public void paint(Graphics paramGraphics)
  {
    Graphics2D localGraphics2D = (Graphics2D)paramGraphics;
    localGraphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    Composite localComposite = localGraphics2D.getComposite();
    localGraphics2D.setComposite(AlphaComposite.getInstance(3, (float)this.A));
    localGraphics2D.setColor(getBackground());
    localGraphics2D.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
    localGraphics2D.setComposite(localComposite);
    super.paint(paramGraphics);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.B.F
 * JD-Core Version:    0.6.2
 */