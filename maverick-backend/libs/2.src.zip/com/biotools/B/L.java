package com.biotools.B;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.NumberFormat;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.TitledBorder;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class L
{
  public static final double A = 0.001D;

  public static void A(Window paramWindow)
  {
    if (paramWindow == null)
      throw new NullPointerException("Passed in a null jframe");
    paramWindow.pack();
    B(paramWindow);
  }

  public static void A(JTree paramJTree)
  {
    int i = 0;
    while (i < paramJTree.getRowCount())
      paramJTree.expandRow(i++);
  }

  public static void B(Window paramWindow)
  {
    if (paramWindow == null)
      throw new NullPointerException("Passed in a null jframe");
    Toolkit localToolkit = Toolkit.getDefaultToolkit();
    Dimension localDimension = localToolkit.getScreenSize();
    int i = paramWindow.getWidth();
    int j = paramWindow.getHeight();
    paramWindow.setLocation(localDimension.width / 2 - i / 2, localDimension.height / 2 - j / 2);
  }

  public static String A()
  {
    Runtime localRuntime = Runtime.getRuntime();
    long l1 = localRuntime.freeMemory();
    long l2 = localRuntime.totalMemory();
    long l3 = localRuntime.maxMemory();
    long l4 = ()Math.pow(2.0D, 20.0D);
    l1 /= l4;
    l2 /= l4;
    l3 /= l4;
    String str = "Memory: " + l1 + "M of " + l2 + "M available, " + l3 + "M max";
    return str;
  }

  public static String B()
  {
    System.runFinalization();
    System.gc();
    Runtime localRuntime = Runtime.getRuntime();
    long l1 = localRuntime.freeMemory();
    long l2 = localRuntime.totalMemory();
    long l3 = (l2 - l1) / 1024L;
    return "Used Memory = " + l3 + "Kb";
  }

  public static void C(long paramLong)
  {
    try
    {
      Thread.sleep(paramLong);
    }
    catch (InterruptedException localInterruptedException)
    {
    }
  }

  public static String A(Node paramNode)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    NodeList localNodeList = paramNode.getChildNodes();
    for (int i = 0; i < localNodeList.getLength(); i++)
    {
      if (localNodeList.item(i).getNodeValue() != null)
        localStringBuffer.append(localNodeList.item(i).getNodeValue());
      localStringBuffer.append(A(localNodeList.item(i)));
    }
    return localStringBuffer.toString();
  }

  public static String B(long paramLong)
  {
    return NumberFormat.getInstance().format(paramLong);
  }

  public static String D(int paramInt)
  {
    return NumberFormat.getInstance().format(paramInt);
  }

  public static String A(double paramDouble)
  {
    return NumberFormat.getInstance().format(paramDouble);
  }

  public static String A(float paramFloat)
  {
    return NumberFormat.getInstance().format(paramFloat);
  }

  public static Color A(Color paramColor1, Color paramColor2, double paramDouble)
  {
    assert ((paramDouble >= 0.0D) && (paramDouble <= 1.0D));
    Color localColor = new Color((int)(paramColor1.getRed() * paramDouble + paramColor2.getRed() * (1.0D - paramDouble)), (int)(paramColor1.getGreen() * paramDouble + paramColor2.getGreen() * (1.0D - paramDouble)), (int)(paramColor1.getBlue() * paramDouble + paramColor2.getBlue() * (1.0D - paramDouble)));
    return localColor;
  }

  public static String A(Color paramColor)
  {
    return Integer.toHexString(paramColor.getRGB() & 0xFFFFFF);
  }

  public static JPanel A(JComponent paramJComponent1, JComponent paramJComponent2)
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(paramJComponent1);
    localJPanel.add(Box.createHorizontalStrut(3));
    localJPanel.add(paramJComponent2);
    return localJPanel;
  }

  public static String A(String paramString)
  {
    String str1 = "REG_SZ";
    String str2 = "REG_DWORD";
    try
    {
      Process localProcess = Runtime.getRuntime().exec("reg query " + paramString);
      BufferedInputStream localBufferedInputStream = new BufferedInputStream(localProcess.getInputStream());
      StringWriter localStringWriter = new StringWriter();
      try
      {
        int i;
        while ((i = localBufferedInputStream.read()) != -1)
          localStringWriter.write(i);
      }
      catch (IOException localIOException)
      {
      }
      String str3 = localStringWriter.toString();
      int j = str3.indexOf("REG_SZ");
      if (j == -1)
        return null;
      return str3.substring(j + "REG_SZ".length()).trim();
    }
    catch (Exception localException)
    {
    }
    return null;
  }

  public static Border A(Border paramBorder, int paramInt)
  {
    return BorderFactory.createCompoundBorder(paramBorder, BorderFactory.createEmptyBorder(paramInt, paramInt, paramInt, paramInt));
  }

  public static Border B(int paramInt)
  {
    return BorderFactory.createEmptyBorder(paramInt, paramInt, paramInt, paramInt);
  }

  public static Image A(File paramFile, Component paramComponent)
  {
    Image localImage = Toolkit.getDefaultToolkit().getImage(paramFile.getPath());
    MediaTracker localMediaTracker = new MediaTracker(paramComponent);
    localMediaTracker.addImage(localImage, 0);
    try
    {
      localMediaTracker.waitForAll();
    }
    catch (InterruptedException localInterruptedException)
    {
    }
    return localImage;
  }

  public static Image A(URL paramURL, Component paramComponent)
  {
    Image localImage = Toolkit.getDefaultToolkit().getImage(paramURL);
    MediaTracker localMediaTracker = new MediaTracker(paramComponent);
    localMediaTracker.addImage(localImage, 0);
    try
    {
      localMediaTracker.waitForAll();
    }
    catch (InterruptedException localInterruptedException)
    {
    }
    return localImage;
  }

  public static Image A(int paramInt1, int paramInt2)
  {
    GraphicsConfiguration localGraphicsConfiguration = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration();
    BufferedImage localBufferedImage = localGraphicsConfiguration.createCompatibleImage(paramInt1, paramInt2, 3);
    return localBufferedImage;
  }

  public static JFrame A(Component paramComponent, String paramString)
  {
    JFrame localJFrame = new JFrame(paramString);
    localJFrame.getContentPane().add(paramComponent);
    localJFrame.pack();
    localJFrame.setVisible(true);
    return localJFrame;
  }

  public static void A(final int paramInt, final Runnable paramRunnable)
  {
    Thread local1 = new Thread("Toolbox fireEvent")
    {
      private final int val$ms;
      private final Runnable val$runnable;

      public void run()
      {
        L.C(paramInt);
        paramRunnable.run();
      }
    };
    local1.start();
  }

  public static void A(final Runnable paramRunnable1, final Runnable paramRunnable2)
  {
    Thread local2 = new Thread("Toolbox runThread")
    {
      private final Runnable val$runnable;
      private final Runnable val$finished;

      public void run()
      {
        paramRunnable1.run();
        if (paramRunnable2 != null)
          SwingUtilities.invokeLater(paramRunnable2);
      }
    };
    local2.start();
  }

  public static final int A(byte[] paramArrayOfByte)
  {
    return paramArrayOfByte[0] << 24 | (paramArrayOfByte[1] & 0xFF) << 16 | (paramArrayOfByte[2] & 0xFF) << 8 | paramArrayOfByte[3] & 0xFF;
  }

  public static final byte[] C(int paramInt)
  {
    return new byte[] { (byte)(paramInt >> 24), (byte)(paramInt >> 16), (byte)(paramInt >> 8), (byte)paramInt };
  }

  public static final int A(double paramDouble1, double paramDouble2)
  {
    if (Math.abs(paramDouble1 - paramDouble2) < 0.001D)
      return 0;
    return paramDouble1 < paramDouble2 ? -1 : 1;
  }

  public static void A(Border paramBorder, float paramFloat)
  {
    if (paramBorder != null)
    {
      Object localObject;
      if ((paramBorder instanceof CompoundBorder))
      {
        localObject = (CompoundBorder)paramBorder;
        A(((CompoundBorder)localObject).getInsideBorder(), paramFloat);
        A(((CompoundBorder)localObject).getOutsideBorder(), paramFloat);
      }
      else if ((paramBorder instanceof TitledBorder))
      {
        localObject = (TitledBorder)paramBorder;
        ((TitledBorder)localObject).setTitleFont(((TitledBorder)localObject).getTitleFont().deriveFont(paramFloat));
      }
    }
  }

  public static void A(JComponent paramJComponent, float paramFloat)
  {
    paramJComponent.setFont(paramJComponent.getFont().deriveFont(paramFloat));
    for (int i = 0; i < paramJComponent.getComponentCount(); i++)
    {
      Component localComponent = paramJComponent.getComponent(i);
      if ((localComponent instanceof JComponent))
      {
        A((JComponent)localComponent, paramFloat);
        Border localBorder = ((JComponent)localComponent).getBorder();
        A(localBorder, paramFloat);
      }
    }
  }

  public static String A(int paramInt)
  {
    int i = paramInt % 100;
    if ((i >= 10) && (i <= 20))
      return "th";
    int j = paramInt % 10;
    switch (j)
    {
    case 1:
      return "st";
    case 2:
      return "nd";
    case 3:
      return "rd";
    }
    return "th";
  }

  public static String A(long paramLong)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    long l1 = paramLong / 1000L;
    long l2 = l1 / 60L;
    long l3 = l2 / 60L;
    l2 -= l3 * 60L;
    if (l3 > 0L)
    {
      localStringBuffer.append(l3 + " hour" + (l3 > 1L ? "s" : ""));
      if (l2 > 0L)
        localStringBuffer.append(", ");
    }
    if (l2 > 0L)
      localStringBuffer.append(l2 + " minute" + (l2 > 1L ? "s" : ""));
    if ((l3 == 0L) && (l2 == 0L))
      localStringBuffer.append("< 1 minute");
    return localStringBuffer.toString();
  }

  public static boolean C()
  {
    String str = "127.0.0.1";
    try
    {
      InetAddress localInetAddress = InetAddress.getLocalHost();
      str = localInetAddress.getHostAddress();
    }
    catch (UnknownHostException localUnknownHostException)
    {
    }
    return !str.equals("127.0.0.1");
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.B.L
 * JD-Core Version:    0.6.2
 */