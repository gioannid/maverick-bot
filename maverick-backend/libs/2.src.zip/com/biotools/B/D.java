package com.biotools.B;

import com.biotools.A.I;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.lang.reflect.Method;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.text.DefaultCaret;
import javax.swing.text.Document;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;

public class D extends JPanel
{
  private JTextPane B = new JTextPane();
  private JScrollPane A;
  private static final int D = 40000;
  private boolean C = false;
  private boolean E = false;
  static Class class$0;

  public D(Dimension paramDimension)
  {
    this.B.setFont(new Font("Courier", 0, 12));
    this.B.setEditable(false);
    this.B.setBorder(new EmptyBorder(2, 2, 2, 2));
    Style localStyle1 = B("regular", A());
    Style localStyle2 = B("bold", localStyle1);
    StyleConstants.setBold(localStyle2, true);
    this.A = new JScrollPane(this.B);
    this.A.setPreferredSize(paramDimension);
    this.A.setMinimumSize(paramDimension);
    this.B.setMinimumSize(paramDimension);
    this.B.setPreferredSize(paramDimension);
    F();
    setLayout(new BorderLayout());
    add(this.A, "Center");
  }

  private void F()
  {
    try
    {
      Class[] arrayOfClass = { Integer.TYPE };
      Method localMethod = DefaultCaret.class.getMethod("setUpdatePolicy", arrayOfClass);
      DefaultCaret localDefaultCaret = new DefaultCaret();
      Object[] arrayOfObject = { new Integer(1) };
      localMethod.invoke(localDefaultCaret, arrayOfObject);
      this.B.setCaret(localDefaultCaret);
    }
    catch (Exception localException)
    {
      this.C = true;
    }
  }

  public void A(Font paramFont)
  {
    this.B.setFont(paramFont);
  }

  public Style A()
  {
    return StyleContext.getDefaultStyleContext().getStyle("default");
  }

  public Style B(String paramString)
  {
    return this.B.getStyle(paramString);
  }

  public Style B(String paramString, Style paramStyle)
  {
    return this.B.addStyle(paramString, paramStyle);
  }

  public void D(String paramString)
  {
    A(paramString, "regular");
  }

  public void A(String paramString)
  {
    A(paramString, "bold");
  }

  public synchronized void A(String paramString1, String paramString2)
  {
    if (this.E)
    {
      paramString1 = '\n' + paramString1;
      this.E = false;
    }
    if (paramString1.charAt(paramString1.length() - 1) == '\n')
    {
      paramString1 = paramString1.substring(0, paramString1.length() - 1);
      this.E = true;
    }
    final String str = paramString1;
    final Style localStyle = this.B.getStyle(paramString2);
    if (this.C)
    {
      Thread localThread = new Thread(new D.1(this, str, localStyle), "insert console text");
      localThread.start();
    }
    else
    {
      SwingUtilities.invokeLater(new Runnable()
      {
        private final String val$str;
        private final Style val$style;

        public void run()
        {
          D.this.A(str, localStyle);
        }
      });
    }
  }

  private synchronized void A(String paramString, Style paramStyle)
  {
    try
    {
      Document localDocument = this.B.getDocument();
      if (localDocument.getLength() > 40000)
        localDocument.remove(0, 20000);
      localDocument.insertString(localDocument.getLength(), paramString, paramStyle);
      SwingUtilities.invokeLater(new Runnable()
      {
        public void run()
        {
          D.this.G();
        }
      });
    }
    catch (Exception localException)
    {
      I.A("", localException);
    }
  }

  private void G()
  {
    try
    {
      Document localDocument = this.B.getDocument();
      int i = this.A.getVerticalScrollBar().getValue();
      int j = this.A.getVerticalScrollBar().getVisibleAmount();
      int k = this.A.getVerticalScrollBar().getMaximum();
      if (i + j > k - j)
        this.B.setCaretPosition(localDocument.getLength());
    }
    catch (Exception localException)
    {
    }
  }

  public void C(final String paramString)
  {
    SwingUtilities.invokeLater(new Runnable()
    {
      private final String val$s;

      public void run()
      {
        try
        {
          D.this.B.setText(paramString);
        }
        catch (Exception localException)
        {
          I.A("", localException);
        }
      }
    });
  }

  public void E()
  {
    SwingUtilities.invokeLater(new Runnable()
    {
      public void run()
      {
        try
        {
          D.this.B.setCaretPosition(0);
        }
        catch (Exception localException)
        {
          I.A("", localException);
        }
      }
    });
  }

  public void B()
  {
    try
    {
      Document localDocument = this.B.getDocument();
      localDocument.remove(0, localDocument.getLength());
    }
    catch (Exception localException)
    {
      I.A("", localException);
    }
  }

  public JTextPane D()
  {
    return this.B;
  }

  public JScrollPane C()
  {
    return this.A;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.B.D
 * JD-Core Version:    0.6.2
 */