package com.biotools.B;

import java.awt.CardLayout;
import javax.swing.JPanel;

public class O extends JPanel
{
  private CardLayout B = new CardLayout();
  private String A;

  public O()
  {
    setLayout(this.B);
  }

  public void A(JPanel paramJPanel, String paramString)
  {
    add(paramJPanel, paramString);
    this.A = paramString;
  }

  public void A(String paramString)
  {
    this.B.show(this, paramString);
    this.A = paramString;
  }

  public String A()
  {
    return this.A;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.B.O
 * JD-Core Version:    0.6.2
 */