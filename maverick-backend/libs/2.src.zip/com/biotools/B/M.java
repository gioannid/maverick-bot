package com.biotools.B;

import java.awt.AlphaComposite;
import java.awt.Composite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import javax.swing.JPanel;

public class M extends JPanel
{
  double A = 1.0D;

  public M(double paramDouble)
  {
    this.A = paramDouble;
    setOpaque(false);
  }

  public void paint(Graphics paramGraphics)
  {
    Graphics2D localGraphics2D = (Graphics2D)paramGraphics;
    Composite localComposite = localGraphics2D.getComposite();
    localGraphics2D.setComposite(AlphaComposite.getInstance(3, (float)this.A));
    localGraphics2D.setColor(getBackground());
    localGraphics2D.fillRect(0, 0, paramGraphics.getClipBounds().width, paramGraphics.getClipBounds().height);
    localGraphics2D.setComposite(localComposite);
    super.paint(paramGraphics);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.B.M
 * JD-Core Version:    0.6.2
 */