package com.biotools.B;

import com.biotools.poker.E;
import java.awt.AlphaComposite;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;
import java.util.HashMap;
import java.util.Map;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class J extends JButton
{
  public static final int B = 0;
  public static final int D = 1;
  public static final int C = 2;
  public static final int A = 3;
  private static Map[] E;

  public J(ImageIcon paramImageIcon)
  {
    super(paramImageIcon);
  }

  public J(String paramString1, String paramString2)
  {
    this(paramString1, paramString2, new Dimension(34, 36));
  }

  public J(String paramString1, String paramString2, Dimension paramDimension)
  {
    Map[] arrayOfMap = A();
    assert (arrayOfMap[0].containsKey(paramString1));
    ImageIcon[] arrayOfImageIcon = new ImageIcon[4];
    arrayOfImageIcon[1] = ((ImageIcon)arrayOfMap[1].get(paramString1));
    arrayOfImageIcon[0] = ((ImageIcon)arrayOfMap[0].get(paramString1));
    arrayOfImageIcon[2] = ((ImageIcon)arrayOfMap[2].get(paramString1));
    arrayOfImageIcon[3] = ((ImageIcon)arrayOfMap[3].get(paramString1));
    A(arrayOfImageIcon, paramString2, paramDimension);
  }

  public J(ImageIcon[] paramArrayOfImageIcon, String paramString, Dimension paramDimension)
  {
    A(paramArrayOfImageIcon, paramString, paramDimension);
  }

  private void A(ImageIcon[] paramArrayOfImageIcon, String paramString, Dimension paramDimension)
  {
    setContentAreaFilled(false);
    setBorderPainted(false);
    setRolloverEnabled(true);
    setFocusable(false);
    setToolTipText(paramString);
    setIcon(paramArrayOfImageIcon[1]);
    setRolloverIcon(paramArrayOfImageIcon[0]);
    setDisabledIcon(paramArrayOfImageIcon[2]);
    setPressedIcon(paramArrayOfImageIcon[3]);
    setPreferredSize(paramDimension);
  }

  protected Map[] A()
  {
    A(this);
    return E;
  }

  private static ImageIcon A(Component paramComponent, Image paramImage, String paramString, boolean paramBoolean)
  {
    Image localImage1 = L.A(E.K(paramString), paramComponent);
    Image localImage2 = L.A(paramImage.getWidth(null), paramImage.getHeight(null));
    Graphics2D localGraphics2D = (Graphics2D)localImage2.getGraphics();
    localGraphics2D.drawImage(paramImage, 0, 0, null);
    if (paramBoolean)
      localGraphics2D.setComposite(AlphaComposite.getInstance(3, 0.6F));
    localGraphics2D.drawImage(localImage1, 0, 0, null);
    localGraphics2D.dispose();
    return new ImageIcon(localImage2);
  }

  private static synchronized void A(Component paramComponent)
  {
    if (E == null)
    {
      String str = "pix/toolbar/";
      String[] arrayOfString1 = { "bg-on.png", "bg-off.png", "bg-disabled.png", "bg-pressed.png" };
      String[] arrayOfString2 = { "del.png", "play.png", "help.png", "calc.png", "export.png", "open.png", "prefs.png", "import.png", "hand.png", "graph.png", "graphT.png", "save.png", "add.png", "plus.png", "minus.png" };
      E = A(paramComponent, str, arrayOfString1, arrayOfString2);
      K.B(paramComponent);
    }
  }

  public static Map[] A(Component paramComponent, String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2)
  {
    Image localImage1 = L.A(E.K(paramString + paramArrayOfString1[0]), paramComponent);
    Image localImage2 = L.A(E.K(paramString + paramArrayOfString1[1]), paramComponent);
    Image localImage3 = L.A(E.K(paramString + paramArrayOfString1[2]), paramComponent);
    Image localImage4 = L.A(E.K(paramString + paramArrayOfString1[3]), paramComponent);
    Map[] arrayOfMap = new Map[4];
    for (int i = 0; i < 4; i++)
      arrayOfMap[i] = new HashMap();
    for (i = 0; i < paramArrayOfString2.length; i++)
    {
      arrayOfMap[0].put(paramArrayOfString2[i], A(paramComponent, localImage1, paramString + paramArrayOfString2[i], false));
      arrayOfMap[1].put(paramArrayOfString2[i], A(paramComponent, localImage2, paramString + paramArrayOfString2[i], false));
      arrayOfMap[2].put(paramArrayOfString2[i], A(paramComponent, localImage3, paramString + paramArrayOfString2[i], true));
      arrayOfMap[3].put(paramArrayOfString2[i], A(paramComponent, localImage4, paramString + paramArrayOfString2[i], true));
    }
    return arrayOfMap;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.B.J
 * JD-Core Version:    0.6.2
 */