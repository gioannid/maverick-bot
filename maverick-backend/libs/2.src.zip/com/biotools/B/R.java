package com.biotools.B;

import com.biotools.A.B;
import com.biotools.A.I;
import com.biotools.poker.E;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTree;
import javax.swing.KeyStroke;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkEvent.EventType;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLFrameHyperlinkEvent;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class R extends JFrame
  implements HyperlinkListener
{
  private JEditorPane G;
  private R._B E = E.Ú() ? new R._B(this, "Main", E.K("help/index-std.html")) : new R._B(this, "Main", E.K("help/index.html"));
  private JTree I;
  private _A F;
  private Vector B = new Vector(10);
  private int C = -1;
  private JButton D;
  private JButton A;
  private static volatile R H = null;

  public static File A(URL paramURL)
  {
    if (!paramURL.getProtocol().equalsIgnoreCase("file"))
      return null;
    File localFile1 = new File(paramURL.getFile());
    File localFile2 = new File(localFile1.getParent(), "content/" + localFile1.getName());
    if ((E.y()) && (localFile2.exists()) && (!localFile1.exists()))
      try
      {
        localFile1.createNewFile();
      }
      catch (IOException localIOException)
      {
        I.A("Could not create default empty html file", localIOException);
      }
    return localFile2;
  }

  public static String A(File paramFile)
  {
    return B.A(paramFile);
  }

  public static R B(String paramString)
  {
    if (H != null)
      H.E();
    else
      H = new R(paramString);
    return H;
  }

  public R(String paramString)
  {
    super(paramString);
    setIconImage(E.¢);
    setSize(770, 570);
    setJMenuBar(new _C());
    addWindowListener(new R.3(this));
    this.F = new _A(paramString);
    if (E.Ú())
      A(E.K("help/help-std.xml"), this.F);
    else
      A(E.K("help/help.xml"), this.F);
    this.I = new JTree(this.F);
    this.I.getSelectionModel().setSelectionMode(1);
    this.I.expandPath(new TreePath(this.F));
    this.I.addTreeSelectionListener(new R.4(this));
    JScrollPane localJScrollPane1 = new JScrollPane(this.I);
    this.I.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
    this.D = new JButton(new ImageIcon("data/pix/back24.gif"));
    this.A = new JButton(new ImageIcon("data/pix/forward24.gif"));
    this.D.setBorderPainted(false);
    this.A.setBorderPainted(false);
    this.D.addActionListener(new R.5(this));
    this.A.addActionListener(new R.6(this));
    JPanel localJPanel1 = new JPanel();
    localJPanel1.setLayout(new BoxLayout(localJPanel1, 0));
    localJPanel1.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));
    localJPanel1.add(Box.createHorizontalGlue());
    localJPanel1.add(this.D);
    localJPanel1.add(Box.createHorizontalStrut(15));
    localJPanel1.add(this.A);
    localJPanel1.add(Box.createHorizontalGlue());
    JPanel localJPanel2 = new JPanel(new BorderLayout(3, 3));
    localJPanel2.setBorder(BorderFactory.createEmptyBorder(3, 3, 0, 0));
    localJPanel2.add(localJPanel1, "North");
    localJPanel2.add(localJScrollPane1, "Center");
    this.G = new JEditorPane();
    this.G.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));
    this.G.addHyperlinkListener(this);
    this.G.setEditable(false);
    JScrollPane localJScrollPane2 = new JScrollPane(this.G);
    JSplitPane localJSplitPane = new JSplitPane(1);
    localJSplitPane.setLeftComponent(localJPanel2);
    localJSplitPane.setRightComponent(localJScrollPane2);
    Dimension localDimension = new Dimension(225, 200);
    localJScrollPane2.setMinimumSize(localDimension);
    localJScrollPane1.setMinimumSize(localDimension);
    localJSplitPane.setPreferredSize(new Dimension(550, 400));
    getContentPane().add(localJSplitPane, "Center");
    A(this.E);
    L.B(this);
    setVisible(true);
  }

  private void E()
  {
    if (getState() == 1)
      setState(0);
    toFront();
  }

  private void C()
  {
    H = null;
    dispose();
  }

  public void A(JTree paramJTree)
  {
    int i = 0;
    while (i < paramJTree.getRowCount())
      paramJTree.expandRow(i++);
  }

  public void A(R._B param_B)
  {
    int i = 1;
    A(param_B.B, true);
  }

  public void A(String paramString)
  {
    File localFile = E.K("help/" + paramString);
    try
    {
      int i = 1;
      A(localFile.toURI().toURL(), true);
    }
    catch (MalformedURLException localMalformedURLException)
    {
      I.A("Bad url for " + paramString, localMalformedURLException);
    }
  }

  public void A(URL paramURL, boolean paramBoolean)
  {
    if ((this.B.size() > 0) && (paramURL.toString().equals(this.B.elementAt(this.C).toString())))
      return;
    if (paramBoolean)
    {
      while (this.B.size() - 1 > this.C)
        this.B.removeElementAt(this.C + 1);
      this.B.add(paramURL);
      this.C += 1;
      D();
    }
    B(paramURL);
  }

  public boolean A(URL paramURL, DefaultMutableTreeNode paramDefaultMutableTreeNode)
  {
    int i = paramDefaultMutableTreeNode.getChildCount();
    for (int j = 0; j < i; j++)
    {
      DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)paramDefaultMutableTreeNode.getChildAt(j);
      if ((localDefaultMutableTreeNode instanceof R._B))
      {
        if (A(paramURL, (R._B)localDefaultMutableTreeNode))
          return true;
      }
      else if (A(paramURL, localDefaultMutableTreeNode))
        return true;
    }
    return false;
  }

  public boolean A(URL paramURL, R._B param_B)
  {
    if (param_B.B.equals(paramURL))
    {
      TreePath localTreePath = new TreePath(param_B.getPath());
      this.I.expandPath(localTreePath);
      this.I.setSelectionPath(localTreePath);
      this.I.scrollPathToVisible(localTreePath);
      return true;
    }
    return false;
  }

  public void B(URL paramURL)
  {
    try
    {
      File localFile = A(paramURL);
      if (localFile.exists())
      {
        System.out.println(">>>> " + localFile);
        this.G.setPage(paramURL);
        this.G.setText(A(localFile));
        this.G.setCaretPosition(0);
      }
      else
      {
        this.G.setPage(paramURL);
      }
      A(paramURL, this.F);
    }
    catch (IOException localIOException)
    {
      I.A("Attempted to read a bad URL: " + paramURL, localIOException);
    }
  }

  private void B()
  {
    int i = -1;
    try
    {
      i = this.C - 1;
      URL localURL = (URL)this.B.elementAt(i);
      B(localURL);
      this.C = i;
    }
    catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException)
    {
      I.A("Walked off visitedPage stack with index of " + i, localArrayIndexOutOfBoundsException);
    }
    D();
  }

  private void A()
  {
    int i = -1;
    try
    {
      i = this.C + 1;
      URL localURL = (URL)this.B.elementAt(i);
      B(localURL);
      this.C = i;
    }
    catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException)
    {
      I.A("Walked off visitedPage stack with index of " + i, localArrayIndexOutOfBoundsException);
    }
    D();
  }

  private void D()
  {
    if (this.C == 0)
      this.D.setEnabled(false);
    else
      this.D.setEnabled(true);
    if (this.C == this.B.size() - 1)
      this.A.setEnabled(false);
    else
      this.A.setEnabled(true);
  }

  private void A(File paramFile, _A param_A)
  {
    try
    {
      DocumentBuilderFactory localDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
      localDocumentBuilderFactory.setNamespaceAware(true);
      DocumentBuilder localDocumentBuilder = localDocumentBuilderFactory.newDocumentBuilder();
      Document localDocument = localDocumentBuilder.parse(paramFile);
      Element localElement = localDocument.getDocumentElement();
      String str = localElement.getAttribute("title");
      if (str != null)
      {
        setTitle(str);
        param_A.setUserObject(str);
      }
      A(localElement, param_A);
    }
    catch (Exception localException)
    {
      I.A("", localException);
    }
  }

  private void A(Element paramElement, _A param_A)
  {
    NodeList localNodeList = paramElement.getChildNodes();
    for (int i = 0; i < localNodeList.getLength(); i++)
      if ((localNodeList.item(i) instanceof Element))
      {
        Element localElement = (Element)localNodeList.item(i);
        String str;
        Object localObject;
        if (localElement.getNodeName().equalsIgnoreCase("page"))
        {
          str = localElement.getAttribute("title");
          localObject = E.K("help/" + localElement.getAttribute("file"));
          R._B local_B = new R._B(this, str, (File)localObject);
          param_A.add(local_B);
        }
        else if (localElement.getNodeName().equalsIgnoreCase("section"))
        {
          str = localElement.getAttribute("title");
          localObject = new _A(str);
          A(localElement, (_A)localObject);
          param_A.add((MutableTreeNode)localObject);
        }
      }
  }

  public void hyperlinkUpdate(HyperlinkEvent paramHyperlinkEvent)
  {
    if (paramHyperlinkEvent.getEventType() == HyperlinkEvent.EventType.ACTIVATED)
    {
      JEditorPane localJEditorPane = (JEditorPane)paramHyperlinkEvent.getSource();
      if ((paramHyperlinkEvent instanceof HTMLFrameHyperlinkEvent))
      {
        HTMLFrameHyperlinkEvent localHTMLFrameHyperlinkEvent = (HTMLFrameHyperlinkEvent)paramHyperlinkEvent;
        HTMLDocument localHTMLDocument = (HTMLDocument)localJEditorPane.getDocument();
        localHTMLDocument.processHTMLFrameHyperlinkEvent(localHTMLFrameHyperlinkEvent);
      }
      else
      {
        A(paramHyperlinkEvent.getURL(), true);
      }
    }
  }

  public class _A extends DefaultMutableTreeNode
  {
    public _A(Object arg2)
    {
      super();
    }
  }

  public class _C extends JMenuBar
  {
    JMenu A = new JMenu(E.D("PokerAppMenu.File"));

    public _C()
    {
      add(A());
    }

    protected JMenu A()
    {
      this.A.add(C());
      this.A.add(B());
      return this.A;
    }

    protected KeyStroke A(int paramInt)
    {
      return KeyStroke.getKeyStroke(paramInt, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask());
    }

    protected JMenuItem C()
    {
      JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.Close"), 67);
      localJMenuItem.setAccelerator(A(87));
      localJMenuItem.addActionListener(new R.1(this));
      return localJMenuItem;
    }

    protected JMenuItem B()
    {
      JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.QuitProgram"), 81);
      localJMenuItem.setAccelerator(A(81));
      localJMenuItem.setToolTipText(E.D("PokerAppMenu.QuitProgramToolTip"));
      localJMenuItem.addActionListener(new R.2(this));
      return localJMenuItem;
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.B.R
 * JD-Core Version:    0.6.2
 */