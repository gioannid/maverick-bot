package com.biotools.B;

import java.awt.Image;
import java.io.File;

public abstract interface G
{
  public abstract Image B(File paramFile);
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.B.G
 * JD-Core Version:    0.6.2
 */