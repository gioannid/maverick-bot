package com.biotools.poker.S.B;

import com.biotools.A.F;
import com.biotools.A.L;
import com.biotools.A.d;
import com.biotools.poker.S.D.M;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;

public class E
{
  private static final M L = new M();
  private static int J = 1;
  private volatile BufferedInputStream K = null;
  private volatile BufferedOutputStream S = null;
  private volatile SSLSocket M = null;
  private volatile Thread G = null;
  private volatile Thread C;
  protected L D = new L();
  protected L F = new L();
  private volatile boolean R = false;
  private int P = J;
  private SSLSocket O;
  private BufferedInputStream B;
  private BufferedOutputStream N;
  private Thread Q;
  private Thread E;
  private long T = F.A();
  long H = F.A();
  long I = 0L;
  PrintWriter A = null;

  public static void A(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      System.setProperty("javax.net.ssl.keyStore", "server/keys.server");
      System.setProperty("javax.net.ssl.keyStorePassword", "k7docda4n");
    }
    else
    {
      System.setProperty("javax.net.ssl.trustStore", "data/keys.client");
      System.setProperty("javax.net.ssl.trustPassword", "btipoker");
    }
  }

  public E()
  {
    J += 1;
  }

  public int P()
  {
    return this.P;
  }

  private void B(SSLSocket paramSSLSocket)
    throws SocketException
  {
    if (paramSSLSocket == null)
      return;
    d.E("SOCKET OPTS: " + paramSSLSocket.getSoLinger() + " " + paramSSLSocket.getKeepAlive() + " " + paramSSLSocket.getTcpNoDelay());
    paramSSLSocket.setSoLinger(false, 1);
    paramSSLSocket.setKeepAlive(false);
    paramSSLSocket.setTcpNoDelay(true);
    d.E("SOCKET OPTS: " + paramSSLSocket.getSoLinger() + " " + paramSSLSocket.getKeepAlive() + " " + paramSSLSocket.getTcpNoDelay());
  }

  private SSLSocketFactory O()
    throws NoSuchAlgorithmException, KeyManagementException
  {
    SSLContext localSSLContext = SSLContext.getInstance("SSL");
    E.1 local1 = new E.1(this);
    localSSLContext.init(null, new TrustManager[] { local1 }, null);
    return localSSLContext.getSocketFactory();
  }

  public String A(String paramString, int paramInt)
  {
    com.biotools.poker.E.H("Connecting to " + paramString + ":" + paramInt);
    try
    {
      SSLSocketFactory localSSLSocketFactory = O();
      this.M = ((SSLSocket)localSSLSocketFactory.createSocket(paramString, paramInt));
      B(this.M);
    }
    catch (UnknownHostException localUnknownHostException)
    {
      d.A(localUnknownHostException);
      return "Unknown host error.  Please check your network and firewall settings and try again.";
    }
    catch (IOException localIOException1)
    {
      d.A(localIOException1);
      return "Unable to establish a connection to the server.\nThe server could be down or a firewall could be blocking the request.\nPlease check your firewall settings or try connecting later.";
    }
    catch (Exception localException)
    {
      d.A(localException);
      return "Unexpected error: " + localException.getMessage();
    }
    try
    {
      this.M.startHandshake();
    }
    catch (IOException localIOException2)
    {
      d.A(localIOException2);
      return "Unexpected error: SSL handshake failed.";
    }
    try
    {
      this.S = new BufferedOutputStream(this.M.getOutputStream());
    }
    catch (IOException localIOException3)
    {
      d.A(localIOException3);
      return "Unexpected error: Output stream creation failed";
    }
    try
    {
      this.K = new BufferedInputStream(this.M.getInputStream());
    }
    catch (IOException localIOException4)
    {
      d.A(localIOException4);
      return "Unexpected error: Input stream creation failed";
    }
    J();
    return null;
  }

  public String A(SSLSocket paramSSLSocket)
  {
    this.M = paramSSLSocket;
    try
    {
      B(paramSSLSocket);
      this.S = new BufferedOutputStream(this.M.getOutputStream());
    }
    catch (IOException localIOException1)
    {
      d.A("Output stream creation failed");
      d.A(localIOException1);
      return "Output stream creation failed";
    }
    try
    {
      this.K = new BufferedInputStream(this.M.getInputStream());
    }
    catch (IOException localIOException2)
    {
      d.A("Input stream creation failed");
      d.A(localIOException2);
      return "Input stream creation failed";
    }
    J();
    return null;
  }

  public void K()
  {
    this.G = new Thread(new E.2(this), "ioRec-" + this.P);
    this.G.start();
  }

  private void D(String paramString)
  {
    if (!com.biotools.poker.E.y())
      return;
    this.I += paramString.length();
  }

  public void J()
  {
    this.C = new Thread(new E.3(this), "ioSend-" + this.P);
    this.C.start();
  }

  public M E()
  {
    return L;
  }

  public boolean A(String paramString)
  {
    if (this.R)
      return false;
    d.A(this.P, paramString);
    String str = paramString + "\n";
    try
    {
      this.S.write(str.getBytes(), 0, str.length());
      this.S.flush();
    }
    catch (IOException localIOException)
    {
      com.biotools.poker.E.H("Socket write failed --> " + localIOException.getMessage());
      I();
      return false;
    }
    catch (NullPointerException localNullPointerException)
    {
      com.biotools.poker.E.H("Socket write: out turned null");
      I();
      return false;
    }
    return true;
  }

  public void B(String paramString)
  {
    if (H())
      return;
    if (this.F.B() > 500)
    {
      d.E("send queue too big, closing connection");
      I();
      return;
    }
    this.F.A(paramString);
  }

  public boolean G()
  {
    return this.D.B() > 0;
  }

  public String M()
  {
    try
    {
      return (String)this.D.C();
    }
    catch (InterruptedException localInterruptedException)
    {
    }
    return null;
  }

  public void I()
  {
    if (this.R)
      return;
    this.R = true;
    this.O = this.M;
    this.B = this.K;
    this.N = this.S;
    this.Q = this.C;
    this.E = this.G;
    this.M = null;
    this.K = null;
    this.S = null;
    this.C = null;
    this.G = null;
    this.F.A(null);
    if (this.A != null)
      this.A.close();
  }

  private void N()
  {
    try
    {
      if (this.O != null)
        this.O.close();
      if (this.B != null)
        this.B.close();
      if (this.N != null)
        this.N.close();
    }
    catch (IOException localIOException)
    {
      d.A("problem closing");
      d.A(localIOException);
    }
    if (this.E != null)
      this.E.interrupt();
    this.O = null;
    this.B = null;
    this.N = null;
    this.E = null;
    this.Q = null;
    A();
  }

  protected void A()
  {
    this.F.A();
  }

  public boolean H()
  {
    return this.R;
  }

  public String D()
  {
    if (this.R)
      return null;
    String str = null;
    try
    {
      StringBuffer localStringBuffer = new StringBuffer();
      char c = '\000';
      while (true)
      {
        int i = this.K.read();
        if (i == -1)
        {
          com.biotools.poker.E.H("CLOSE on read end of stream");
          I();
          break;
        }
        c = (char)i;
        if (c == '\n')
        {
          str = localStringBuffer.toString();
          break;
        }
        localStringBuffer.append(c);
      }
    }
    catch (IOException localIOException)
    {
      com.biotools.poker.E.H("CLOSE on read exception --> " + localIOException.getMessage());
      I();
      return null;
    }
    catch (NullPointerException localNullPointerException)
    {
      com.biotools.poker.E.H("CLOSE on exception --> " + localNullPointerException.getMessage());
      I();
      return null;
    }
    if (str != null)
    {
      D(str);
      d.C(this.P, str);
      this.T = F.A();
    }
    return str;
  }

  public String B()
  {
    return this.M.getInetAddress().getHostAddress();
  }

  private void C(String paramString)
    throws InterruptedException
  {
    if (this.C == null)
    {
      d.C("TCPROB trying to test a dead send thread");
      return;
    }
    d.C("TCPROB sending mess");
    B(paramString);
    d.C("TCPROB sent mess");
    int i = 0;
    while (this.F.B(paramString))
    {
      i++;
      Thread.sleep(50L);
      if (i == 5)
      {
        d.C("TCPROB dead because of no send action");
        I();
        return;
      }
    }
    d.C("TCPROB done");
  }

  public double C()
  {
    long l = F.A(this.H);
    if (l <= 0L)
    {
      com.biotools.poker.E.H("getBPS() elapsedMillis = " + l);
      l = 1L;
    }
    double d = this.I * 1000L / l;
    this.H = F.A();
    this.I = 0L;
    return d;
  }

  public boolean L()
  {
    if (H())
      return true;
    return F.A(this.T) >= 40000L;
  }

  public boolean F()
  {
    try
    {
      C("<ignore/>");
    }
    catch (InterruptedException localInterruptedException)
    {
    }
    return !L();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.S.B.E
 * JD-Core Version:    0.6.2
 */