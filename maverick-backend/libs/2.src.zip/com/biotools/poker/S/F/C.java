package com.biotools.poker.S.F;

import com.biotools.A.I;
import com.biotools.A.d;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class C
{
  protected static DocumentBuilder A = null;

  public C()
  {
    if (A == null)
    {
      DocumentBuilderFactory localDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
      try
      {
        A = localDocumentBuilderFactory.newDocumentBuilder();
      }
      catch (ParserConfigurationException localParserConfigurationException)
      {
        I.A("Could not make XML parser", localParserConfigurationException);
      }
    }
  }

  public static Document A(String paramString)
  {
    if ((paramString == null) || (paramString.length() == 0))
      return null;
    try
    {
      Document localDocument = null;
      synchronized (A)
      {
        localDocument = A.parse(new InputSource(new StringReader(paramString)));
      }
      return localDocument;
    }
    catch (Exception localException)
    {
      d.A("bad parse, maybe a bad packet: [[[" + paramString + "]]]");
      d.A(localException);
    }
    return null;
  }

  protected String A(boolean paramBoolean1, String paramString, boolean paramBoolean2)
  {
    String str1 = paramBoolean2 ? "</" : "<";
    String str2 = paramBoolean1 ? "/>" : ">";
    return str1 + paramString + str2;
  }

  protected String A(boolean paramBoolean, String paramString1, String paramString2, String paramString3)
  {
    String str = paramBoolean ? "/>" : ">";
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<");
    localStringBuffer.append(paramString1);
    localStringBuffer.append(' ');
    localStringBuffer.append(paramString2);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString3);
    localStringBuffer.append("\" ");
    localStringBuffer.append(str);
    return localStringBuffer.toString();
  }

  protected String A(boolean paramBoolean, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
  {
    String str = paramBoolean ? "/>" : ">";
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<");
    localStringBuffer.append(paramString1);
    localStringBuffer.append(' ');
    localStringBuffer.append(paramString2);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString3);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString4);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString5);
    localStringBuffer.append("\" ");
    localStringBuffer.append(str);
    return localStringBuffer.toString();
  }

  protected String A(boolean paramBoolean, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7)
  {
    String str = paramBoolean ? "/>" : ">";
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<");
    localStringBuffer.append(paramString1);
    localStringBuffer.append(' ');
    localStringBuffer.append(paramString2);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString3);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString4);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString5);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString6);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString7);
    localStringBuffer.append("\" ");
    localStringBuffer.append(str);
    return localStringBuffer.toString();
  }

  protected String A(boolean paramBoolean, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9)
  {
    String str = paramBoolean ? "/>" : ">";
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<");
    localStringBuffer.append(paramString1);
    localStringBuffer.append(' ');
    localStringBuffer.append(paramString2);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString3);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString4);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString5);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString6);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString7);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString8);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString9);
    localStringBuffer.append("\" ");
    localStringBuffer.append(str);
    return localStringBuffer.toString();
  }

  protected String A(boolean paramBoolean, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11)
  {
    String str = paramBoolean ? "/>" : ">";
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<");
    localStringBuffer.append(paramString1);
    localStringBuffer.append(' ');
    localStringBuffer.append(paramString2);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString3);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString4);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString5);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString6);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString7);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString8);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString9);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString10);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString11);
    localStringBuffer.append("\" ");
    localStringBuffer.append(str);
    return localStringBuffer.toString();
  }

  protected String A(boolean paramBoolean, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, String paramString12, String paramString13)
  {
    String str = paramBoolean ? "/>" : ">";
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<");
    localStringBuffer.append(paramString1);
    localStringBuffer.append(' ');
    localStringBuffer.append(paramString2);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString3);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString4);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString5);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString6);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString7);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString8);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString9);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString10);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString11);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString12);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString13);
    localStringBuffer.append("\" ");
    localStringBuffer.append(str);
    return localStringBuffer.toString();
  }

  protected String A(boolean paramBoolean, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, String paramString12, String paramString13, String paramString14, String paramString15)
  {
    String str = paramBoolean ? "/>" : ">";
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<");
    localStringBuffer.append(paramString1);
    localStringBuffer.append(' ');
    localStringBuffer.append(paramString2);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString3);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString4);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString5);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString6);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString7);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString8);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString9);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString10);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString11);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString12);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString13);
    localStringBuffer.append("\" ");
    localStringBuffer.append(paramString14);
    localStringBuffer.append("=\"");
    localStringBuffer.append(paramString15);
    localStringBuffer.append("\" ");
    localStringBuffer.append(str);
    return localStringBuffer.toString();
  }

  protected String A(boolean paramBoolean, String paramString, String[] paramArrayOfString)
  {
    String str = paramBoolean ? "/>" : ">";
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<");
    localStringBuffer.append(paramString);
    localStringBuffer.append(' ');
    for (int i = 0; i < paramArrayOfString.length; i += 2)
    {
      localStringBuffer.append(paramArrayOfString[i]);
      localStringBuffer.append("=\"");
      localStringBuffer.append(paramArrayOfString[(i + 1)]);
      localStringBuffer.append("\" ");
    }
    localStringBuffer.append(str);
    return localStringBuffer.toString();
  }

  protected double D(Element paramElement, String paramString)
  {
    return Double.parseDouble(paramElement.getAttribute(paramString));
  }

  protected int E(Element paramElement, String paramString)
  {
    return Integer.parseInt(paramElement.getAttribute(paramString));
  }

  protected long A(Element paramElement, String paramString)
  {
    return Long.parseLong(paramElement.getAttribute(paramString));
  }

  protected String B(Element paramElement, String paramString)
  {
    return paramElement.getAttribute(paramString);
  }

  protected boolean C(Element paramElement, String paramString)
  {
    String str = paramElement.getAttribute(paramString);
    return (str.equals("t")) || (str.equals("true"));
  }

  protected List B(Element paramElement)
  {
    ArrayList localArrayList = new ArrayList();
    NodeList localNodeList = paramElement.getElementsByTagName("py");
    for (int i = 0; i < localNodeList.getLength(); i++)
    {
      Element localElement = (Element)localNodeList.item(i);
      localArrayList.add(new B(B(localElement, "n"), D(localElement, "b"), E(localElement, "p"), E(localElement, "s")));
    }
    return localArrayList;
  }

  protected List A(Element paramElement)
  {
    ArrayList localArrayList = new ArrayList();
    NodeList localNodeList = paramElement.getElementsByTagName("cd");
    for (int i = 0; i < localNodeList.getLength(); i++)
    {
      Element localElement = (Element)localNodeList.item(i);
      localArrayList.add(B(localElement, "v"));
    }
    return localArrayList;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.S.F.C
 * JD-Core Version:    0.6.2
 */