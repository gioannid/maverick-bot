package com.biotools.poker.S.E;

import com.biotools.A.N;
import com.biotools.B.L;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.C.B.D;
import com.biotools.poker.G.T;
import com.biotools.poker.S.F.B;
import java.awt.Image;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class K
{
  private String H;
  private int L;
  private String Y;
  private int W;
  private int J;
  private int G;
  private List C;
  private boolean U;
  private double D;
  private double O;
  private String E;
  private boolean T;
  private boolean B;
  private String A;
  private String Q;
  private boolean S;
  private String V;
  private boolean F = true;
  private C K = null;
  private boolean M = true;
  private String X = null;
  private String I = null;
  private String R = null;
  private ImageIcon N = null;
  private long P = -1L;

  public K()
  {
  }

  public K(Element paramElement)
  {
    this.Y = paramElement.getAttribute("n");
    this.V = paramElement.getAttribute("st");
    this.E = paramElement.getAttribute("sk");
    this.T = Boolean.valueOf(paramElement.getAttribute("T")).booleanValue();
    this.B = Boolean.valueOf(paramElement.getAttribute("NL")).booleanValue();
    this.S = Boolean.valueOf(paramElement.getAttribute("Pe")).booleanValue();
    this.G = Integer.parseInt(paramElement.getAttribute("m"));
    this.J = Integer.parseInt(paramElement.getAttribute("nP"));
    this.W = Integer.parseInt(paramElement.getAttribute("nO"));
    this.U = Boolean.valueOf(paramElement.getAttribute("p")).booleanValue();
    this.D = Double.parseDouble(paramElement.getAttribute("nb"));
    this.O = Double.parseDouble(paramElement.getAttribute("xb"));
    this.H = paramElement.getAttribute("ip");
    this.L = Integer.parseInt(paramElement.getAttribute("po"));
    this.A = paramElement.getAttribute("ppd");
    this.Q = paramElement.getAttribute("opd");
    if (paramElement.hasAttribute("start"))
      this.P = Long.parseLong(paramElement.getAttribute("start"));
    if (paramElement.hasAttribute("hasStats"))
      this.M = Boolean.valueOf(paramElement.getAttribute("hasStats")).booleanValue();
    if (paramElement.hasAttribute("imageO"))
      this.X = paramElement.getAttribute("imageO");
    if (paramElement.hasAttribute("imageC"))
      this.I = paramElement.getAttribute("imageC");
    if (paramElement.hasAttribute("imageR"))
      this.R = paramElement.getAttribute("imageR");
    NodeList localNodeList = paramElement.getElementsByTagName("py");
    if (localNodeList.getLength() > 0)
    {
      this.C = new ArrayList();
      for (int i = 0; i < localNodeList.getLength(); i++)
      {
        Element localElement = (Element)localNodeList.item(i);
        B localB = new B(localElement);
        this.C.add(localB);
      }
    }
  }

  public N A(boolean paramBoolean1, boolean paramBoolean2)
  {
    N localN = new N("rix");
    localN.A("n", this.Y);
    localN.A("st", this.V);
    localN.A("sk", this.E);
    localN.A("m", this.G);
    localN.A("nP", this.J);
    localN.A("nO", this.W);
    localN.A("NL", this.B);
    localN.A("T", this.T);
    localN.A("p", this.U);
    localN.A("Pe", this.S);
    localN.A("nb", this.D);
    localN.A("xb", this.O);
    if (this.P != -1L)
      localN.A("start", this.P);
    if (!this.M)
      localN.A("hasStats", this.M);
    if (this.X != null)
      localN.A("imageO", this.X);
    if (this.I != null)
      localN.A("imageC", this.I);
    if (this.R != null)
      localN.A("imageR", this.R);
    if (paramBoolean1)
    {
      localN.A("ip", this.H);
      localN.A("po", this.L);
      if (this.A != null)
        localN.A("ppd", this.A);
      if (this.Q != null)
        localN.A("opd", this.Q);
    }
    else
    {
      if (this.A != null)
        localN.A("ppd", "pass");
      if (this.Q != null)
        localN.A("opd", "pass");
    }
    if ((paramBoolean2) && (this.C != null))
    {
      Iterator localIterator = this.C.iterator();
      while (localIterator.hasNext())
      {
        B localB = (B)localIterator.next();
        localN.A(localB.C());
      }
    }
    return localN;
  }

  public int f()
  {
    int i = (this.A != null) && (this.A.length() > 0) ? 1 : 0;
    int j = (this.Q != null) && (this.Q.length() > 0) ? 1 : 0;
    if ((i != 0) && (j == 0))
      return 11;
    if ((i == 0) && (j != 0))
      return 12;
    if ((i != 0) && (j != 0))
      return 10;
    return 13;
  }

  public void A(int paramInt)
  {
    int i = (paramInt != 11) && (paramInt != 10) ? 0 : 1;
    int j = (paramInt != 12) && (paramInt != 10) ? 0 : 1;
    this.A = (i != 0 ? "pass" : null);
    this.Q = (j != 0 ? "pass" : null);
  }

  public boolean _()
  {
    return this.B;
  }

  public boolean D()
  {
    return !this.B;
  }

  public boolean O()
  {
    return !this.T;
  }

  public boolean h()
  {
    return this.T;
  }

  public String W()
  {
    return this.H;
  }

  public String a()
  {
    return this.Y;
  }

  public int R()
  {
    return this.W;
  }

  public int T()
  {
    return this.J;
  }

  public List U()
  {
    return this.C;
  }

  public int V()
  {
    return this.L;
  }

  public String d()
  {
    return this.Q;
  }

  public String S()
  {
    return this.A;
  }

  public int g()
  {
    return this.G;
  }

  public long Q()
  {
    return this.P;
  }

  public boolean B()
  {
    return this.S;
  }

  public boolean b()
  {
    return (D()) && (O());
  }

  public boolean X()
  {
    return (_()) && (O());
  }

  public boolean c()
  {
    return f() != 13;
  }

  public boolean M()
  {
    return this.A.length() > 0;
  }

  public void A(String paramString)
  {
    this.H = paramString;
  }

  public void C(String paramString)
  {
    this.Y = paramString;
  }

  public void B(int paramInt)
  {
    if (this.W != paramInt)
    {
      this.W = paramInt;
      A(true);
    }
  }

  public void C(int paramInt)
  {
    if (this.J != paramInt)
    {
      this.J = paramInt;
      A(true);
    }
  }

  public void E(int paramInt)
  {
    if (this.G != paramInt)
    {
      this.G = paramInt;
      A(true);
    }
  }

  public void A(List paramList)
  {
    this.C = paramList;
  }

  public void F(int paramInt)
  {
    this.L = paramInt;
  }

  public void B(String paramString)
  {
    this.Q = paramString;
  }

  public void F(String paramString)
  {
    this.A = paramString;
  }

  public void C(boolean paramBoolean)
  {
    this.S = paramBoolean;
  }

  public void A(T paramT)
  {
    this.B = paramT.Y();
    this.T = paramT.E();
    this.E = paramT.q();
    this.G = paramT.Á();
  }

  public String P()
  {
    if (O())
    {
      if (D())
        return "Limit";
      if (_())
        return "No-Limit";
    }
    else
    {
      if (D())
        return "Limit Tourney";
      if (_())
        return "No-Limit Tourney";
    }
    return null;
  }

  public String G()
  {
    if (this.U)
      return this.E + " play";
    return this.E;
  }

  public boolean E()
  {
    return (h()) && (this.E.equals("Freeroll"));
  }

  public String toString()
  {
    return a() + " (" + T() + " players)";
  }

  public synchronized void D(int paramInt)
  {
    String str = "SERVER_GAME_ID" + Integer.toString(V() % 1000);
    M.Q.putInt(str, paramInt);
    M.Q.saveSortedPreferences();
  }

  public synchronized int N()
  {
    String str = "SERVER_GAME_ID" + Integer.toString(V() % 1000);
    int i = M.Q.getInt(str, 0);
    i++;
    D(i);
    return i;
  }

  public String K()
  {
    return this.V;
  }

  public void E(String paramString)
  {
    if (this.V != paramString)
    {
      if ((paramString != null) && (this.V != null) && (paramString.equals(this.V)))
        return;
      this.V = paramString;
      A(true);
    }
  }

  public double Z()
  {
    return this.O;
  }

  public void A(double paramDouble)
  {
    this.O = paramDouble;
  }

  public double A()
  {
    return this.D;
  }

  public void B(double paramDouble)
  {
    this.D = paramDouble;
  }

  public void B(boolean paramBoolean)
  {
    this.U = paramBoolean;
  }

  public boolean L()
  {
    return this.U;
  }

  public boolean F()
  {
    return !this.U;
  }

  public boolean H()
  {
    return this.F;
  }

  public void A(boolean paramBoolean)
  {
    this.F = paramBoolean;
  }

  public void A(long paramLong)
  {
    if (paramLong != this.P)
      A(true);
    this.P = paramLong;
  }

  public C e()
  {
    return this.K;
  }

  public void A(C paramC)
  {
    this.K = paramC;
  }

  public void J()
  {
    if (E())
    {
      A(C.F());
      return;
    }
    if (B())
    {
      if (F())
        A(C.D());
      else
        A(C.E());
      return;
    }
    A(C.B());
  }

  public boolean I()
  {
    return this.M;
  }

  public String Y()
  {
    return this.X;
  }

  public String i()
  {
    return this.I;
  }

  public void D(String paramString)
  {
    if ((paramString == null) || (paramString.length() == 0))
      return;
    String[] arrayOfString = D.D(paramString);
    if (arrayOfString != null)
    {
      if ((arrayOfString.length > 0) && (arrayOfString[0].length() > 0) && (!arrayOfString[0].equals("x")))
        this.X = arrayOfString[0];
      if ((arrayOfString.length > 1) && (arrayOfString[1].length() > 0) && (!arrayOfString[1].equals("x")))
        this.I = arrayOfString[1];
      if ((arrayOfString.length > 2) && (arrayOfString[2].length() > 0) && (!arrayOfString[2].equals("x")))
      {
        this.R = arrayOfString[2];
        this.N = null;
      }
    }
    int i = D.B(paramString);
    boolean[] arrayOfBoolean = D.C(paramString);
    this.K = new C(i, arrayOfBoolean);
    this.M = D.A(paramString);
  }

  public ImageIcon A(JComponent paramJComponent)
  {
    if (this.R == null)
      return null;
    if (this.N == null)
    {
      URL localURL;
      try
      {
        localURL = new URL(this.R);
      }
      catch (MalformedURLException localMalformedURLException)
      {
        return null;
      }
      Image localImage = L.A(localURL, paramJComponent);
      this.N = new ImageIcon(localImage);
    }
    return this.N;
  }

  public boolean C()
  {
    return this.P > 0L;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.S.E.K
 * JD-Core Version:    0.6.2
 */