package com.biotools.poker.S.E;

import com.biotools.A.d;
import com.biotools.poker.G.Y;
import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class N extends com.biotools.poker.S.F.C
{
  public String A(String paramString1, String paramString2, int paramInt1, int paramInt2, int paramInt3)
  {
    paramString1 = com.biotools.A.B.B(paramString1);
    return A(true, "login", "name", paramString1, "key", paramString2, "type", Integer.toString(paramInt1), "version", Integer.toString(paramInt2), "mode", Integer.toString(paramInt3));
  }

  public String D(String paramString1, String paramString2)
  {
    paramString2 = paramString2.replace('\n', ' ');
    paramString2 = com.biotools.A.B.B(paramString2);
    return A(true, "loginGood", "version", paramString1, "motd", paramString2);
  }

  public String A(int paramInt, String paramString)
  {
    paramString = com.biotools.A.B.B(paramString);
    return A(true, "loginBad", "id", Integer.toString(paramInt), "reason", paramString);
  }

  public String B(int paramInt)
  {
    return A(true, "badJoin", "id", Integer.toString(paramInt));
  }

  public String I(String paramString)
  {
    paramString = com.biotools.A.B.B(paramString);
    return A(true, "dialog", "message", paramString);
  }

  public String J(String paramString)
  {
    paramString = com.biotools.A.B.B(paramString);
    return A(true, "noTable", "name", paramString);
  }

  public String A(L paramL)
  {
    com.biotools.A.N localN = new com.biotools.A.N("addPlayer");
    localN.A("name", paramL.Y());
    localN.A("location", paramL.W());
    localN.A("access", paramL.X());
    return localN.toString();
  }

  public String K(String paramString)
  {
    paramString = com.biotools.A.B.B(paramString);
    return A(true, "removePlayer", "name", paramString);
  }

  public String B()
  {
    return A(true, "Lpong", false);
  }

  public String C()
  {
    return A(true, "Lping", false);
  }

  public String C(String paramString1, String paramString2)
  {
    paramString2 = com.biotools.A.B.B(paramString2);
    paramString1 = com.biotools.A.B.B(paramString1);
    return A(true, "chat", "who", paramString1, "mess", paramString2);
  }

  public String D()
  {
    return A(true, "administrator", false);
  }

  public String C(int paramInt)
  {
    return A(true, "serverInfo", "players", Integer.toString(paramInt));
  }

  public String E(String paramString1, String paramString2)
  {
    paramString1 = com.biotools.A.B.B(paramString1);
    return A(true, "join", "tableName", paramString1, "passwd", paramString2);
  }

  public String A(K paramK, String paramString)
  {
    return A(true, "goTo", "ip", paramK.W(), "port", Integer.toString(paramK.V()), "passwd", paramString, "name", com.biotools.A.N.A(paramK.a()));
  }

  public String H(String paramString)
  {
    paramString = com.biotools.A.B.B(paramString);
    return A(true, "tableDetails", "name", paramString);
  }

  public String A(String paramString1, int paramInt, List paramList, String paramString2)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append(A(false, "tableInfo", "name", com.biotools.A.N.A(paramString1), "numObservers", Integer.toString(paramInt), "status", com.biotools.A.N.A(paramString2)));
    if (paramList != null)
      for (int i = 0; i < paramList.size(); i++)
      {
        com.biotools.poker.S.F.B localB = (com.biotools.poker.S.F.B)paramList.get(i);
        localStringBuffer.append(A(true, "py", "n", localB.E(), "b", Double.toString(localB.D()), "p", Integer.toString(localB.B()), "s", Integer.toString(localB.F())));
      }
    localStringBuffer.append(A(false, "tableInfo", true));
    return localStringBuffer.toString();
  }

  public String A(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt, boolean paramBoolean1, boolean paramBoolean2)
  {
    paramString1 = com.biotools.A.B.B(paramString1);
    paramString2 = com.biotools.A.B.B(paramString2);
    paramString3 = com.biotools.A.B.B(paramString3);
    return A(paramString1, paramString2, paramString3, paramString4, paramInt, paramBoolean1, paramBoolean2, -1L, null);
  }

  public String A(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt, boolean paramBoolean1, boolean paramBoolean2, long paramLong, String paramString5)
  {
    paramString1 = com.biotools.A.B.B(paramString1);
    paramString2 = com.biotools.A.B.B(paramString2);
    paramString3 = com.biotools.A.B.B(paramString3);
    StringBuffer localStringBuffer = new StringBuffer();
    String[] arrayOfString = { "name", paramString1, "playPasswd", paramString2, "obsPasswd", paramString3, "timeout", Integer.toString(paramInt), "isPerm", paramBoolean1 ? "t" : "f", "isPAX", paramBoolean2 ? "t" : "f", "startTime", Long.toString(paramLong), "adv", paramString5 == null ? "" : paramString5 };
    localStringBuffer.append(A(false, "newTable", arrayOfString));
    localStringBuffer.append(paramString4.replace('\n', ' '));
    localStringBuffer.append(A(false, "newTable", true));
    return localStringBuffer.toString();
  }

  public String M(String paramString)
  {
    paramString = com.biotools.A.B.B(paramString);
    return A(true, "tableCreationFailed", "reason", paramString);
  }

  public String G(String paramString)
  {
    paramString = com.biotools.A.B.B(paramString);
    return A(true, "tableCreationDone", "name", paramString);
  }

  public void A(String paramString, com.biotools.poker.S.A.A paramA)
  {
    Document localDocument = A(paramString);
    if (localDocument == null)
      return;
    Element localElement = localDocument.getDocumentElement();
    String str = localElement.getNodeName();
    if (str.equals("loginGood"))
    {
      paramA.A(B(localElement, "version"), B(localElement, "motd"));
      return;
    }
    if (str.equals("loginBad"))
    {
      paramA.A(E(localElement, "id"), B(localElement, "reason"));
      return;
    }
    if (str.equals("dialog"))
    {
      paramA._(B(localElement, "message"));
      return;
    }
    if (str.equals("tableCreationFailed"))
    {
      paramA.Z(B(localElement, "reason"));
      return;
    }
    if (str.equals("tableCreationDone"))
    {
      paramA.V(B(localElement, "name"));
      return;
    }
    if (str.equals("noTable"))
    {
      paramA.X(B(localElement, "name"));
      return;
    }
    if (str.equals("goTo"))
    {
      paramA.A(B(localElement, "ip"), E(localElement, "port"), B(localElement, "passwd"), B(localElement, "name"));
      return;
    }
    if (str.equals("accountInfo"))
    {
      paramA.A(D(localElement, "bankroll"), D(localElement, "inPlay"), A(localElement, "reset"));
      return;
    }
    if (str.equals("tableInfo"))
    {
      paramA.A(B(localElement, "name"), E(localElement, "numObservers"), B(localElement));
      return;
    }
    Object localObject;
    if (str.equals("addRoomInfo"))
    {
      localObject = F(localElement, paramString);
      if (((List)localObject).size() >= 1)
        paramA.A((K)((List)localObject).get(0));
      return;
    }
    if (str.equals("removeRoomInfo"))
    {
      paramA.W(B(localElement, "name"));
      return;
    }
    if (str.equals("serverInfo"))
    {
      paramA.O(E(localElement, "players"));
      return;
    }
    if (str.equals("badJoin"))
    {
      paramA.P(E(localElement, "id"));
      return;
    }
    if (str.equals("Lpong"))
    {
      paramA.Đ();
      return;
    }
    if (str.equals("addPlayer"))
    {
      paramA.A(B(localElement, "name"), B(localElement, "location"), B(localElement, "access"));
      return;
    }
    if (str.equals("removePlayer"))
    {
      paramA.Y(B(localElement, "name"));
      return;
    }
    if (str.equals("chat"))
    {
      paramA.B(B(localElement, "who"), B(localElement, "mess"));
      return;
    }
    if (str.equals("ignore"))
      return;
    if ((paramA instanceof com.biotools.poker.S.A.C))
    {
      localObject = (com.biotools.poker.S.A.C)paramA;
      if (str.equals("administrator"))
      {
        ((com.biotools.poker.S.A.C)localObject).Ė();
        return;
      }
      if (str.equals("adminConsole"))
      {
        ((com.biotools.poker.S.A.C)localObject).c(B(localElement, "message"));
        return;
      }
      if (str.equals("UserDetails"))
      {
        ((com.biotools.poker.S.A.C)localObject).A(new com.biotools.poker.C.A.B(localElement));
        return;
      }
    }
    d.A("Unhandled client XML: [" + paramString + "]");
  }

  public void A(Object paramObject, String paramString, J paramJ)
  {
    Document localDocument = A(paramString);
    if (localDocument == null)
      return;
    Element localElement = localDocument.getDocumentElement();
    String str1 = localElement.getNodeName();
    if (str1.equals("join"))
    {
      paramJ.B(paramObject, B(localElement, "tableName"), B(localElement, "passwd"));
      return;
    }
    int i;
    if (str1.equals("login"))
    {
      i = 5;
      if (localElement.hasAttribute("mode"))
        i = Integer.parseInt(localElement.getAttribute("mode"));
      paramJ.A(paramObject, B(localElement, "name"), B(localElement, "key"), E(localElement, "type"), E(localElement, "version"), i);
      return;
    }
    if (str1.equals("newTable"))
    {
      i = com.biotools.poker.S.F.A.K();
      long l = -1L;
      if (localElement.hasAttribute("startTime"))
        l = Long.parseLong(localElement.getAttribute("startTime"));
      String str2 = null;
      if (localElement.hasAttribute("adv"))
        str2 = B(localElement, "adv");
      paramJ.A(paramObject, B(localElement, "name"), B(localElement, "playPasswd"), B(localElement, "obsPasswd"), Y.C(paramString), E(localElement, "timeout") * 1000, C(localElement, "isPerm"), C(localElement, "isPAX"), l, str2);
      return;
    }
    if (str1.equals("tableDetails"))
    {
      paramJ.B(paramObject, B(localElement, "name"));
      return;
    }
    if (str1.equals("serverInfo"))
    {
      paramJ.H(paramObject);
      return;
    }
    if (str1.equals("Lping"))
    {
      paramJ.F(paramObject);
      return;
    }
    if (str1.equals("chat"))
    {
      paramJ.C(B(localElement, "who"), B(localElement, "mess"));
      return;
    }
    if (str1.equals("killRoom"))
    {
      paramJ.A(E(localElement, "port"), C(localElement, "immediate"));
      return;
    }
    if (str1.equals("boot"))
    {
      paramJ.S(B(localElement, "name"));
      return;
    }
    if (str1.equals("setban"))
    {
      paramJ.E(B(localElement, "name"), C(localElement, "value"));
      return;
    }
    if (str1.equals("setchat"))
    {
      paramJ.F(B(localElement, "name"), C(localElement, "chat"));
      return;
    }
    if (str1.equals("adminSay"))
    {
      paramJ.A(E(localElement, "port"), B(localElement, "message"));
      return;
    }
    if (str1.equals("admin"))
    {
      paramJ.T(B(localElement, "command"));
      return;
    }
    if (str1.equals("setpax"))
    {
      paramJ.E(B(localElement, "name"), D(localElement, "amount"));
      return;
    }
    if (str1.equals("fixpax"))
    {
      paramJ.R(B(localElement, "name"));
      return;
    }
    if (str1.equals("release"))
    {
      paramJ.O(B(localElement, "name"));
      return;
    }
    if (str1.equals("getUserDetails"))
    {
      paramJ.Q(B(localElement, "name"));
      return;
    }
    d.A("Unhandled server XML: [" + paramString + "] from: " + paramObject);
  }

  protected List F(Element paramElement, String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    NodeList localNodeList = paramElement.getElementsByTagName("rix");
    for (int i = 0; i < localNodeList.getLength(); i++)
    {
      Element localElement = (Element)localNodeList.item(i);
      localArrayList.add(new K(localElement));
    }
    return localArrayList;
  }

  public String A(K paramK)
  {
    com.biotools.A.N localN = new com.biotools.A.N("addRoomInfo");
    localN.A(paramK.A(true, false));
    return localN.toString();
  }

  public String B(K paramK)
  {
    return L(paramK.a());
  }

  public String L(String paramString)
  {
    com.biotools.A.N localN = new com.biotools.A.N("removeRoomInfo");
    localN.A("name", paramString);
    return localN.toString();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.S.E.N
 * JD-Core Version:    0.6.2
 */