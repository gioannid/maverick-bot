package com.biotools.poker.S.A;

import com.biotools.poker.S.E.K;
import java.util.List;

public abstract interface A
{
  public abstract void A(String paramString1, String paramString2);

  public abstract void A(int paramInt, String paramString);

  public abstract void P(int paramInt);

  public abstract void A(String paramString1, int paramInt, String paramString2, String paramString3);

  public abstract void Z(String paramString);

  public abstract void A(String paramString, int paramInt, List paramList);

  public abstract void O(int paramInt);

  public abstract void X(String paramString);

  public abstract void V(String paramString);

  public abstract void Đ();

  public abstract void B(String paramString1, String paramString2);

  public abstract void A(double paramDouble1, double paramDouble2, long paramLong);

  public abstract void A(K paramK);

  public abstract void W(String paramString);

  public abstract void A(String paramString1, String paramString2, String paramString3);

  public abstract void Y(String paramString);

  public abstract void _(String paramString);
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.S.A.A
 * JD-Core Version:    0.6.2
 */