package com.biotools.poker.S.A;

import com.biotools.meerkat.Action;
import java.util.List;

public abstract interface B
{
  public abstract void D(double paramDouble);

  public abstract void Ë();

  public abstract void B(int paramInt, Action paramAction);

  public abstract void B(int paramInt, double paramDouble, String paramString);

  public abstract void U(int paramInt);

  public abstract void A(double paramDouble1, double paramDouble2, double paramDouble3, int paramInt);

  public abstract void A(String paramString1, String paramString2, boolean paramBoolean);

  public abstract void B(int paramInt, String paramString, double paramDouble);

  public abstract void A(double paramDouble1, double paramDouble2, double paramDouble3, long paramLong, int paramInt, boolean paramBoolean, List paramList);

  public abstract void C(int paramInt, List paramList);

  public abstract void B(int paramInt, List paramList);

  public abstract void D(int paramInt, List paramList);

  public abstract void A(int paramInt, List paramList);

  public abstract void G(String paramString);

  public abstract void Í();

  public abstract void Æ();

  public abstract void F(String paramString);

  public abstract void A(int paramInt, String paramString, double paramDouble);

  public abstract void Î();

  public abstract void Ì();

  public abstract void E(String paramString);

  public abstract void C(String paramString);

  public abstract void A(int paramInt, boolean paramBoolean1, boolean paramBoolean2);

  public abstract void V(int paramInt);

  public abstract void A(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);

  public abstract void B(String paramString);

  public abstract void A(String paramString, double paramDouble);

  public abstract void Ê();

  public abstract void Ç();

  public abstract void B(int paramInt, boolean paramBoolean);

  public abstract void A(int paramInt1, int paramInt2, String paramString);

  public abstract void É();

  public abstract void A(String paramString, boolean paramBoolean);

  public abstract void A(String[] paramArrayOfString);

  public abstract void D(String paramString);

  public abstract void È();

  public abstract void Ï();

  public abstract void E(double paramDouble);
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.S.A.B
 * JD-Core Version:    0.6.2
 */