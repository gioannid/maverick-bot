package com.biotools.poker.S.A;

import com.biotools.poker.C.A.B;

public abstract interface C
{
  public abstract void Ė();

  public abstract void c(String paramString);

  public abstract void A(B paramB);
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.S.A.C
 * JD-Core Version:    0.6.2
 */