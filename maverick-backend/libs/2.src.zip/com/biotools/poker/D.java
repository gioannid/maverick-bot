package com.biotools.poker;

import java.awt.BorderLayout;
import java.awt.DisplayMode;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRootPane;
import javax.swing.UIManager;

public class D extends PokerApp
{
  JPopupMenu ϖ;
  public JLabel ϕ;

  public void ɶ()
  {
    setUndecorated(true);
    getRootPane().setWindowDecorationStyle(0);
    if (JOptionPane.showConfirmDialog(null, E.D("SpectatorApp.RunInFullscreen"), E.D("SpectatorApp.Fullscreen"), 0) == 0)
      ʤ();
    else
      super.ɶ();
  }

  public void ʥ()
  {
    setUndecorated(true);
    getRootPane().setWindowDecorationStyle(0);
    try
    {
      GraphicsDevice localGraphicsDevice = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
      if (localGraphicsDevice.isFullScreenSupported())
        localGraphicsDevice.setFullScreenWindow(this);
      DisplayMode localDisplayMode = null;
      DisplayMode[] arrayOfDisplayMode = localGraphicsDevice.getDisplayModes();
      for (int i = 0; i < arrayOfDisplayMode.length; i++)
        if ((arrayOfDisplayMode[i].getWidth() == 1280) && (arrayOfDisplayMode[i].getHeight() == 768))
          if (localDisplayMode == null)
            localDisplayMode = arrayOfDisplayMode[i];
          else if (arrayOfDisplayMode[i].getBitDepth() > localDisplayMode.getBitDepth())
            localDisplayMode = arrayOfDisplayMode[i];
          else if ((arrayOfDisplayMode[i].getBitDepth() == localDisplayMode.getBitDepth()) && (arrayOfDisplayMode[i].getRefreshRate() > localDisplayMode.getRefreshRate()))
            localDisplayMode = arrayOfDisplayMode[i];
      localGraphicsDevice.setDisplayMode(localDisplayMode);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  private void ʤ()
  {
    setUndecorated(true);
    getRootPane().setWindowDecorationStyle(0);
    super.ɶ();
    try
    {
      GraphicsDevice localGraphicsDevice = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
      if (localGraphicsDevice.isFullScreenSupported())
        localGraphicsDevice.setFullScreenWindow(this);
      DisplayMode localDisplayMode = null;
      DisplayMode[] arrayOfDisplayMode = localGraphicsDevice.getDisplayModes();
      for (int i = 0; i < arrayOfDisplayMode.length; i++)
        if ((arrayOfDisplayMode[i].getWidth() == 1280) && (arrayOfDisplayMode[i].getHeight() == 768))
          if (localDisplayMode == null)
            localDisplayMode = arrayOfDisplayMode[i];
          else if (arrayOfDisplayMode[i].getBitDepth() > localDisplayMode.getBitDepth())
            localDisplayMode = arrayOfDisplayMode[i];
          else if ((arrayOfDisplayMode[i].getBitDepth() == localDisplayMode.getBitDepth()) && (arrayOfDisplayMode[i].getRefreshRate() > localDisplayMode.getRefreshRate()))
            localDisplayMode = arrayOfDisplayMode[i];
      localGraphicsDevice.setDisplayMode(localDisplayMode);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  protected void ʢ()
  {
    this.ϖ = new JPopupMenu();
    this.menuBar = new B(this, this.ϖ);
  }

  protected JPanel Y(boolean paramBoolean)
  {
    JPanel localJPanel = new JPanel(new BorderLayout(0, 0));
    localJPanel.add(ʉ(), "Center");
    if (paramBoolean)
      ɽ();
    JLabel localJLabel = new JLabel();
    this.ϕ = localJLabel;
    localJPanel.add(localJLabel, "North");
    localJLabel.addMouseListener(new D.1(this, localJLabel));
    return localJPanel;
  }

  public static void main(String[] paramArrayOfString)
  {
    try
    {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    catch (Exception localException)
    {
    }
    D localD = new D();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.D
 * JD-Core Version:    0.6.2
 */