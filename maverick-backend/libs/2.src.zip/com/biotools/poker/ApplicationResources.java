package com.biotools.poker;

import java.awt.Rectangle;
import java.util.ListResourceBundle;

public class ApplicationResources extends ListResourceBundle
{
  static final Object[][] A = { { "Poker.Lobby.Coords.G_LeftBox_full", new Rectangle(100, 160, 330, 400) }, { "Poker.Lobby.Coords.G_RightBox_full", new Rectangle(480, 160, 480, 400) }, { "Poker.Lobby.Coords.G_LeftBox_comp", new Rectangle(10, 50, 300, 380) }, { "Poker.Lobby.Coords.G_RightBox_comp", new Rectangle(340, 50, 420, 380) } };

  protected Object[][] getContents()
  {
    return A;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.ApplicationResources
 * JD-Core Version:    0.6.2
 */