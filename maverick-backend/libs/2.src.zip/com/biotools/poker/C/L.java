package com.biotools.poker.C;

import com.biotools.A.I;
import com.biotools.A.b;
import com.biotools.B.P;
import com.biotools.B.S;
import com.biotools.meerkat.Action;
import com.biotools.poker.G.A.C;
import com.biotools.poker.G.T;
import com.biotools.poker.G.V;
import com.biotools.poker.G.Z;
import com.biotools.poker.G.a;
import com.biotools.poker.G.e;
import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.PrintStream;
import java.io.StringReader;
import java.text.ParseException;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JViewport;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class L extends JPanel
{
  private T f;
  private C B;
  private D Z;
  private com.biotools.poker.G.B F;
  private H K;
  private JTabbedPane I;
  private com.biotools.poker.E.E l;
  private com.A.B.A m;
  private ArrayList M;
  private JLabel v;
  private JLabel w;
  private JLabel E;
  private JLabel n;
  private JTextArea P;
  private JTextField p;
  private JButton s;
  protected JSlider X;
  protected S c;
  private JSpinner G;
  private SpinnerNumberModel D;
  private JSpinner W;
  private JSpinner Q;
  private JSpinner o;
  private JSpinner O;
  private SpinnerNumberModel e;
  private SpinnerNumberModel k;
  private SpinnerNumberModel r;
  private SpinnerNumberModel R;
  private JSpinner £;
  private JSpinner A;
  private JSpinner _;
  private SpinnerNumberModel t;
  private SpinnerNumberModel a;
  private SpinnerNumberModel h;
  private JComboBox d;
  private JComboBox U;
  private JComboBox V;
  private DefaultComboBoxModel T;
  private DefaultComboBoxModel N;
  private DefaultComboBoxModel H;
  protected int S = 0;
  private boolean q = false;
  private boolean Y = false;
  private boolean L = false;
  private boolean ¢ = true;
  private static final int j = 1;
  private static final int C = 100;
  private static final int b = 0;
  private static final int z = 1000000;
  private static final int J = 100;
  private static final int g = 3;
  private static final int i = 1;
  private static final int u = 64;

  public L(D paramD)
  {
    this.Z = paramD;
    setOpaque(false);
    setLayout(new BorderLayout());
    setBorder(BorderFactory.createEmptyBorder(0, 2, 0, 2));
    com.biotools.poker.E.É().addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent paramAnonymousWindowEvent)
      {
        L.this.U();
      }
    });
    add(¤(), "North");
    add(¢(), "Center");
    add(ß(), "South");
    com.biotools.B.L.A(¢(), 10.0F);
    com.biotools.B.L.A(ß(), 10.0F);
  }

  private JPanel ß()
  {
    com.biotools.B.M localM = new com.biotools.B.M(0.75D);
    localM.setLayout(new BorderLayout());
    localM.add(G(), "Center");
    return localM;
  }

  private JLabel G()
  {
    if (this.w == null)
      this.w = new JLabel(com.biotools.poker.E.D("TournamentSettingsPanel.StatusOK"), 0);
    return this.w;
  }

  private JPanel ¤()
  {
    JPanel localJPanel = new JPanel(new B.A.A.B());
    localJPanel.add("tab hfill", ú());
    localJPanel.add("right", Â());
    localJPanel.add("br hfill", è());
    localJPanel.setOpaque(false);
    return localJPanel;
  }

  private JPanel è()
  {
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.setOpaque(false);
    localJPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
    localJPanel.add(b(), "West");
    localJPanel.add(w(), "Center");
    localJPanel.add(P(), "East");
    return localJPanel;
  }

  private JPanel Â()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setOpaque(false);
    localJPanel.add(N(), "West");
    return localJPanel;
  }

  private JPanel ú()
  {
    JPanel localJPanel = new JPanel(new B.A.A.B());
    localJPanel.setForeground(Color.WHITE);
    JLabel localJLabel = new JLabel(com.biotools.poker.E.D("TournamentSettingsPanel.NameTitle"), 4);
    localJLabel.setForeground(Color.WHITE);
    localJPanel.add("left", localJLabel);
    localJPanel.add("tab hfill", q());
    localJPanel.setOpaque(false);
    return localJPanel;
  }

  private JTabbedPane ¢()
  {
    if (this.I == null)
    {
      this.I = new JTabbedPane();
      this.I.setOpaque(false);
      this.I.addTab(com.biotools.poker.E.D("TournamentSettingsPanel.Details"), e());
      this.I.addTab(com.biotools.poker.E.D("TournamentSettingsPanel.Structure"), F());
      this.I.addTab(com.biotools.poker.E.D("TournamentSettingsPanel.Players"), é());
      this.I.addTab(com.biotools.poker.E.D("TournamentSettingsPanel.Payouts"), B());
    }
    return this.I;
  }

  private JPanel e()
  {
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 0, 3));
    localJPanel.add(Å(), "North");
    localJPanel.add(Î(), "Center");
    return localJPanel;
  }

  private JPanel Å()
  {
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.add(Ô(), "West");
    localJPanel.add(Ø(), "Center");
    return localJPanel;
  }

  private JPanel Ô()
  {
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.add(Õ(), "Center");
    if (!com.biotools.poker.E.Ú())
      localJPanel.add(ê(), "South");
    return localJPanel;
  }

  private JPanel Ø()
  {
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.add(É(), "Center");
    return localJPanel;
  }

  private JPanel Õ()
  {
    JPanel localJPanel = new JPanel(new GridLayout(3, 2, 3, 2));
    localJPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("TournamentSettingsPanel.GameTimeDetails")), BorderFactory.createEmptyBorder(0, 3, 0, 3)));
    localJPanel.add(new JLabel(com.biotools.poker.E.D("TournamentSettingsPanel.StartingChips"), 2));
    localJPanel.add(Ë());
    localJPanel.add(new JLabel(com.biotools.poker.E.D("TournamentSettingsPanel.StartingPlayers"), 2));
    localJPanel.add(î());
    localJPanel.add(new JLabel(com.biotools.poker.E.D("TournamentSettingsPanel.PlayersPerTable"), 2));
    localJPanel.add(g());
    return localJPanel;
  }

  private JPanel ê()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("TournamentSettingsPanel.Players")), BorderFactory.createEmptyBorder(0, 3, 0, 3)));
    localJPanel.add(W());
    localJPanel.add(ï());
    return localJPanel;
  }

  private JPanel W()
  {
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 3));
    localJPanel.add(new JLabel(com.biotools.poker.E.D("TournamentSettingsPanel.MinTitle")), "West");
    localJPanel.add(£(), "Center");
    return localJPanel;
  }

  private JPanel ï()
  {
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.setBorder(BorderFactory.createEmptyBorder(0, 3, 0, 0));
    localJPanel.add(new JLabel(com.biotools.poker.E.D("TournamentSettingsPanel.MaxTitle")), "West");
    localJPanel.add(ó(), "Center");
    return localJPanel;
  }

  private JPanel É()
  {
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.setBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("TournamentSettingsPanel.BuyIns")));
    localJPanel.add(p(), "Center");
    return localJPanel;
  }

  public com.biotools.poker.G.B p()
  {
    if (this.F == null)
    {
      this.F = new com.biotools.poker.G.B(this);
      this.F.addPropertyChangeListener(new PropertyChangeListener()
      {
        public void propertyChange(PropertyChangeEvent paramAnonymousPropertyChangeEvent)
        {
          L.this.C(true);
          L.this.ë();
        }
      });
      this.F.B(new ListSelectionListener()
      {
        public void valueChanged(ListSelectionEvent paramAnonymousListSelectionEvent)
        {
          L.this.C(true);
          L.this.ë();
        }
      });
    }
    return this.F;
  }

  public JPanel Î()
  {
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.setBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("TournamentSettingsPanel.Description")));
    JScrollPane localJScrollPane = new JScrollPane(c());
    localJScrollPane.setOpaque(false);
    localJScrollPane.getViewport().setOpaque(false);
    localJScrollPane.setPreferredSize(new Dimension(150, 60));
    localJScrollPane.setBorder(BorderFactory.createEtchedBorder());
    localJPanel.add(localJScrollPane, "Center");
    return localJPanel;
  }

  private H é()
  {
    if (this.K == null)
      this.K = new H();
    return this.K;
  }

  private JPanel F()
  {
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
    localJPanel.add(X(), "North");
    localJPanel.add(È(), "Center");
    return localJPanel;
  }

  private JPanel X()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(d());
    localJPanel.add(V());
    localJPanel.add(ý());
    return localJPanel;
  }

  private JPanel ý()
  {
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("TournamentSettingsPanel.BettingType")), BorderFactory.createEmptyBorder(3, 3, 3, 3)));
    localJPanel.add(K(), "Center");
    return localJPanel;
  }

  private JPanel V()
  {
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("TournamentSettingsPanel.LevelLength")), BorderFactory.createEmptyBorder(3, 3, 3, 3)));
    localJPanel.add(ã(), "Center");
    localJPanel.add(Ò(), "East");
    return localJPanel;
  }

  private JPanel Ò()
  {
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 0));
    localJPanel.add(Ì(), "Center");
    return localJPanel;
  }

  private JPanel d()
  {
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("TournamentSettingsPanel.StartLevel")), BorderFactory.createEmptyBorder(3, 3, 3, 3)));
    localJPanel.add(Ù(), "Center");
    return localJPanel;
  }

  private JPanel È()
  {
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.setBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("TournamentSettingsPanel.LevelEditor")));
    localJPanel.add(h(), "Center");
    return localJPanel;
  }

  private C h()
  {
    if (this.B == null)
    {
      this.B = new C();
      this.B.addPropertyChangeListener(new PropertyChangeListener()
      {
        public void propertyChange(PropertyChangeEvent paramAnonymousPropertyChangeEvent)
        {
          L.this.C(true);
        }
      });
    }
    return this.B;
  }

  private JPanel B()
  {
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
    localJPanel.add(Ú(), "North");
    localJPanel.add(å(), "Center");
    return localJPanel;
  }

  private JPanel Ú()
  {
    JPanel localJPanel = new JPanel(new B.A.A.B());
    localJPanel.setBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("TournamentSettingsPanel.ChoosePayouts")));
    localJPanel.add("hfill", Ð());
    localJPanel.add("tab", new JLabel(com.biotools.poker.E.D("TournamentSettingsPanel.InitialPrizePool")));
    localJPanel.add("tab hfill", Ö());
    localJPanel.add("br center", ø());
    return localJPanel;
  }

  private JPanel å()
  {
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.setBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("TournamentSettingsPanel.PayoutViewer")));
    localJPanel.add(E(), "Center");
    return localJPanel;
  }

  private com.A.B.A E()
  {
    if (this.m == null)
    {
      this.m = new com.A.B.A();
      this.m.setPreferredSize(new Dimension(300, 150));
    }
    return this.m;
  }

  private DefaultComboBoxModel L()
  {
    if (this.T == null)
      this.T = new DefaultComboBoxModel(com.biotools.poker.G.M.J());
    return this.T;
  }

  private JComboBox K()
  {
    if (this.d == null)
    {
      this.d = new JComboBox(L());
      this.d.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          L.this.C(true);
        }
      });
    }
    return this.d;
  }

  private SpinnerNumberModel i()
  {
    if (this.r == null)
      this.r = new SpinnerNumberModel(10, 3, 6600, 1);
    return this.r;
  }

  private JSpinner ó()
  {
    if (this.o == null)
    {
      this.o = new JSpinner(i());
      this.o.addChangeListener(new ChangeListener()
      {
        public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
        {
          int i = L.this.ñ().getNumber().intValue();
          int j = L.this.þ();
          int k = L.this.ù();
          if (j < k)
            L.this.ò().setValue(L.this.i().getNumber());
          if (j < i)
            L.this.B(j);
          L.this.Û();
          L.this.C(true);
        }
      });
    }
    return this.o;
  }

  private SpinnerNumberModel ò()
  {
    if (this.k == null)
      this.k = new SpinnerNumberModel(3, 3, 6600, 1);
    return this.k;
  }

  private JSpinner £()
  {
    if (this.Q == null)
    {
      this.Q = new JSpinner(ò());
      this.Q.addChangeListener(new ChangeListener()
      {
        public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
        {
          if (L.this.ñ().getNumber().intValue() < L.this.ò().getNumber().intValue())
            L.this.B(L.access$2(L.this).getNumber().intValue());
          L.this.Û();
          L.this.C(true);
        }
      });
    }
    return this.Q;
  }

  private SpinnerNumberModel ñ()
  {
    if (this.e == null)
    {
      this.e = new SpinnerNumberModel(10, 3, 6600, 1);
      if (í() != null)
        Ā();
    }
    return this.e;
  }

  private JSpinner î()
  {
    if (this.W == null)
    {
      this.W = new JSpinner(ñ());
      this.W.addChangeListener(new ChangeListener()
      {
        public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
        {
          if (L.this.ñ().getNumber().intValue() > L.this.þ())
            L.this.i().setValue(L.this.ñ().getNumber());
          if (L.this.ñ().getNumber().intValue() < L.this.ù())
            L.this.ò().setValue(L.this.ñ().getNumber());
          L.this.B(L.access$1(L.this).getNumber().intValue());
          L.this.C(true);
        }
      });
    }
    return this.W;
  }

  private SpinnerNumberModel Á()
  {
    if (this.D == null)
      this.D = new SpinnerNumberModel(1000, 100, 500000, 100);
    return this.D;
  }

  private JSpinner Ë()
  {
    if (this.G == null)
    {
      this.G = new JSpinner(Á());
      this.G.addChangeListener(new ChangeListener()
      {
        public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
        {
          L.this.C(true);
        }
      });
    }
    return this.G;
  }

  private JTextArea c()
  {
    if (this.P == null)
    {
      this.P = new JTextArea()
      {
        public void paint(Graphics paramAnonymousGraphics)
        {
          Graphics2D localGraphics2D = (Graphics2D)paramAnonymousGraphics;
          Composite localComposite = localGraphics2D.getComposite();
          localGraphics2D.setComposite(AlphaComposite.getInstance(3, 0.5F));
          localGraphics2D.setColor(Color.BLACK);
          localGraphics2D.fillRect(0, 0, getWidth(), getHeight());
          localGraphics2D.setComposite(localComposite);
          super.paint(paramAnonymousGraphics);
        }
      };
      this.P.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
      this.P.setToolTipText(com.biotools.poker.E.D("TournamentSettingsPanel.EditDescription"));
      this.P.setEditable(true);
      this.P.setWrapStyleWord(true);
      this.P.setLineWrap(true);
      this.P.setOpaque(false);
      this.P.setForeground(Color.WHITE);
      this.P.addKeyListener(new KeyAdapter()
      {
        public void keyTyped(KeyEvent paramAnonymousKeyEvent)
        {
          L.this.C(true);
        }
      });
    }
    return this.P;
  }

  private JSpinner g()
  {
    if (this.O == null)
    {
      this.O = new JSpinner(µ());
      this.O.addChangeListener(new ChangeListener()
      {
        public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
        {
          L.this.C(true);
        }
      });
    }
    return this.O;
  }

  private SpinnerNumberModel µ()
  {
    if (this.R == null)
      this.R = new SpinnerNumberModel(10, 3, 10, 1);
    return this.R;
  }

  private JComboBox Ì()
  {
    if (this.V == null)
    {
      this.V = new JComboBox(à());
      this.V.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          L.this.C(true);
        }
      });
    }
    return this.V;
  }

  private DefaultComboBoxModel à()
  {
    if (this.H == null)
      this.H = new DefaultComboBoxModel();
    return this.H;
  }

  private JSpinner ã()
  {
    if (this.A == null)
    {
      this.A = new JSpinner(s());
      this.A.addChangeListener(new ChangeListener()
      {
        public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
        {
          L.this.C(true);
        }
      });
    }
    return this.A;
  }

  private SpinnerNumberModel s()
  {
    if (this.a == null)
      this.a = new SpinnerNumberModel(10, 1, 120, 1);
    return this.a;
  }

  private SpinnerNumberModel ö()
  {
    if (this.t == null)
      this.t = new SpinnerNumberModel(1, 1, 15, 1);
    return this.t;
  }

  private JSpinner Ù()
  {
    if (this.£ == null)
    {
      this.£ = new JSpinner(ö());
      this.£.addChangeListener(new ChangeListener()
      {
        public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
        {
          L.this.C(true);
        }
      });
    }
    return this.£;
  }

  private JLabel ä()
  {
    if (this.v == null)
    {
      this.v = new JLabel("<html><b></b></html>", 0);
      this.v.setForeground(Color.WHITE);
    }
    return this.v;
  }

  private String ª()
  {
    return q().getText();
  }

  private JTextField q()
  {
    if (this.p == null)
    {
      this.p = new JTextField();
      this.p.setToolTipText(com.biotools.poker.E.D("TournamentSettingsPanel.EditTournamentName"));
      this.p.addKeyListener(new KeyListener()
      {
        public void keyTyped(KeyEvent paramAnonymousKeyEvent)
        {
          L.this.C(true);
        }

        public void keyPressed(KeyEvent paramAnonymousKeyEvent)
        {
          L.this.C(true);
        }

        public void keyReleased(KeyEvent paramAnonymousKeyEvent)
        {
        }
      });
      if (í() != null)
        this.p.setText(í().S());
    }
    return this.p;
  }

  private JLabel ø()
  {
    if (this.n == null)
      this.n = new JLabel(ç(), 0);
    return this.n;
  }

  private String ç()
  {
    return new String("<html>" + com.biotools.poker.E.D("TournamentSettingsPanel.PrizePool") + " <b>" + Action.formatCash(o()) + "</b> &nbsp; &nbsp; " + com.biotools.poker.E.D("TournamentSettingsPanel.NumberOfPlayersTitle") + " <b>" + â() + "</b></html>");
  }

  private DefaultComboBoxModel Ü()
  {
    if (this.N == null)
    {
      this.N = new DefaultComboBoxModel();
      ô();
    }
    return this.N;
  }

  private JComboBox Ð()
  {
    if (this.U == null)
    {
      this.U = new JComboBox(Ü());
      this.U.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          L.this.ë();
          L.this.C(true);
        }
      });
    }
    return this.U;
  }

  private void ë()
  {
    if (í() != null)
    {
      int i1 = this.U.getSelectedIndex();
      com.biotools.poker.G.A localA = (com.biotools.poker.G.A)this.M.get(this.U.getSelectedIndex());
      E().A(localA.A(â(), o()));
    }
    ø().setText(ç());
  }

  private SpinnerNumberModel Ê()
  {
    if (this.h == null)
      this.h = new SpinnerNumberModel(0, 0, 1000000, 100);
    return this.h;
  }

  private JSpinner Ö()
  {
    if (this._ == null)
    {
      this._ = new JSpinner(Ê());
      this._.addChangeListener(new ChangeListener()
      {
        public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
        {
          L.this.C(true);
          L.this.ë();
        }
      });
    }
    return this._;
  }

  private JSlider w()
  {
    if (this.X == null)
    {
      this.X = new JSlider();
      this.X.setOpaque(false);
      this.X.addChangeListener(new ChangeListener()
      {
        public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
        {
          L.this.B(L.this.X.getValue());
        }
      });
    }
    return this.X;
  }

  private S P()
  {
    if (this.c == null)
    {
      this.c = new S(10, 6);
      this.c.B(new ChangeListener()
      {
        public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
        {
          L.this.B(L.this.c.B());
        }
      });
    }
    return this.c;
  }

  private JLabel b()
  {
    if (this.E == null)
    {
      this.E = new JLabel("", 4);
      this.E.setForeground(Color.WHITE);
    }
    return this.E;
  }

  private String m()
  {
    return new String("<html><h3>" + í().ª() + "</h3></html>");
  }

  private String u()
  {
    Object[] arrayOfObject = { new Integer(í().µ()), new Integer(í().Á()) };
    return com.biotools.poker.E.A("TournamentSettingsPanel.NumPlayersPattern", arrayOfObject);
  }

  private String Q()
  {
    Object[] arrayOfObject = { new Integer(ù()), new Integer(þ()) };
    return com.biotools.poker.E.A("TournamentSettingsPanel.NumPlayersPattern", arrayOfObject);
  }

  private T í()
  {
    return this.f;
  }

  private void A(T paramT)
  {
    this.f = paramT;
  }

  public int â()
  {
    return w().getValue();
  }

  public com.biotools.poker.G.d C()
  {
    return h().B();
  }

  protected com.biotools.poker.E.E O()
  {
    return é().A(â());
  }

  protected void ð()
  {
    é().L();
  }

  private int l()
  {
    return Ê().getNumber().intValue();
  }

  private V _()
  {
    return this.F.L();
  }

  protected double o()
  {
    double d1 = _().A();
    return l() + d1 * â();
  }

  protected int Í()
  {
    Integer localInteger = (Integer)ã().getValue();
    return localInteger.intValue();
  }

  protected int z()
  {
    return Ì().getSelectedIndex();
  }

  public boolean A()
  {
    return h().H();
  }

  public int Þ()
  {
    return h().I();
  }

  public String C(int paramInt)
  {
    return h().C(paramInt);
  }

  public T f()
  {
    T localT = new T();
    F(localT);
    if (localT.S() == null)
      localT.C(com.biotools.poker.E.D("TournamentSettingsPanel.UnknownTournament"));
    else if (localT.S().length() <= 1)
      localT.C(com.biotools.poker.E.D("TournamentSettingsPanel.UnknownTournament"));
    return localT;
  }

  private void A(boolean paramBoolean)
  {
    this.L = paramBoolean;
  }

  private boolean t()
  {
    return this.L;
  }

  public D r()
  {
    return this.Z;
  }

  public void E(T paramT)
  {
    r().B(paramT);
    C(paramT);
  }

  public void D(T paramT)
  {
    r().C(paramT);
  }

  protected int y()
  {
    return Á().getNumber().intValue();
  }

  protected int M()
  {
    return ö().getNumber().intValue();
  }

  protected int ì()
  {
    return µ().getNumber().intValue();
  }

  protected int æ()
  {
    Integer localInteger = (Integer)î().getValue();
    return localInteger.intValue();
  }

  protected int þ()
  {
    return i().getNumber().intValue();
  }

  protected int ù()
  {
    return ò().getNumber().intValue();
  }

  private boolean Y()
  {
    return this.Y;
  }

  public void C(boolean paramBoolean)
  {
    N().setEnabled(paramBoolean);
    this.Y = paramBoolean;
    if (paramBoolean)
      G().setText(com.biotools.poker.E.D("TournamentSettingsPanel.StatusUnsavedChanges"));
    else
      G().setText(com.biotools.poker.E.D("TournamentSettingsPanel.StatusOK"));
  }

  private void B(boolean paramBoolean)
  {
    this.¢ = paramBoolean;
  }

  private boolean Ã()
  {
    return this.¢;
  }

  private JButton N()
  {
    if (this.s == null)
    {
      this.s = new com.biotools.B.J("save.png", com.biotools.poker.E.D("TournamentSettingsPanel.SaveDescription"));
      this.s.setVisible(true);
      this.s.setEnabled(false);
      this.s.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          L.this.k();
        }
      });
    }
    return this.s;
  }

  public void À()
  {
    T localT1 = í();
    U();
    T localT2 = B(localT1);
    localT2.b();
    String str = (String)JOptionPane.showInputDialog(this, com.biotools.poker.E.D("TournamentSettingsPanel.ChooseANameTitle"), com.biotools.poker.E.D("TournamentSettingsPanel.CreateCustomTournament"), -1, null, null, localT2.S());
    if (str != null)
    {
      localT2.C(str);
      E(localT2);
      B(true);
      A(true);
      C(true);
    }
  }

  private T B(T paramT)
  {
    T localT = new T();
    if (paramT != null)
    {
      localT.A(new com.biotools.poker.G.d(paramT.B()));
      localT.W(paramT.o());
      localT.A(new com.biotools.poker.G.E(paramT.J()));
      localT.N(paramT.y());
      localT.I(paramT.¢());
      localT.P(paramT.Q());
      localT.A(paramT.s());
      localT.A();
    }
    else
    {
      localT.A(com.biotools.poker.G.d.F());
      localT.A(Z.B, Z.D);
    }
    return localT;
  }

  private Z x()
  {
    Z localZ = new Z((String)K().getSelectedItem());
    if (þ() > ì())
      localZ.A(new Z(Z.D));
    else
      localZ.A(new Z(Z.E));
    return localZ;
  }

  public boolean õ()
  {
    if (!Y())
      return true;
    if (í() == null)
      return true;
    Object[] arrayOfObject = { ª() };
    int i1 = JOptionPane.showConfirmDialog(this, com.biotools.poker.E.A("TournamentSettingsPanel.SaveTournamentPattern", arrayOfObject), com.biotools.poker.E.D("TournamentSettingsPanel.UnsavedChanges"), 0);
    if (i1 == 0)
    {
      r().Á();
      R();
      D(í());
      return true;
    }
    return false;
  }

  public void k()
  {
    if (!Y())
      return;
    if (í() == null)
      return;
    if (R())
    {
      r().Á();
      int i1 = ¢().getSelectedIndex();
      E(í());
      ¢().setSelectedIndex(i1);
    }
  }

  public int Ç()
  {
    return ¢().getSelectedIndex();
  }

  public void A(int paramInt)
  {
    ¢().setSelectedIndex(paramInt);
  }

  private boolean R()
  {
    if (H())
      return false;
    F(í());
    í().h();
    A(false);
    C(false);
    return true;
  }

  public boolean H()
  {
    if (ª().length() <= 1)
    {
      C(true);
      Object[] arrayOfObject = { new Integer(1), new Integer(64) };
      G().setText(com.biotools.poker.E.A("TournamentSettingsPanel.ErrorNameLengthPattern", arrayOfObject));
      Object localObject = JOptionPane.showInputDialog(this, com.biotools.poker.E.D("TournamentSettingsPanel.ChooseLongerName"), com.biotools.poker.E.D("TournamentSettingsPanel.ErrorInvalidName"), 0, null, null, ª());
      if (localObject != null)
      {
        String str = (String)localObject;
        if ((str.length() > 1) && (str.length() < 64))
        {
          q().setText(str);
          return H();
        }
      }
      return H();
    }
    return false;
  }

  public void U()
  {
    if (!õ())
    {
      ¥();
      return;
    }
    if ((Y()) && (t()))
    {
      í().£();
      r().Á();
    }
    C(false);
    A(false);
  }

  public void S()
  {
    Object[] arrayOfObject = { ª() };
    int i1 = JOptionPane.showConfirmDialog(this, com.biotools.poker.E.A("TournamentSettingsPanel.DeleteTournamentDescriptionPattern", arrayOfObject), com.biotools.poker.E.D("TournamentSettingsPanel.DeleteTournament"), 0);
    if (i1 == 0)
    {
      í().£();
      r().Á();
    }
    C(false);
    A(false);
    B(false);
  }

  public void D()
  {
    JFileChooser localJFileChooser = new JFileChooser();
    localJFileChooser.setFileFilter(new com.biotools.A.J());
    localJFileChooser.setDialogTitle(com.biotools.poker.E.D("TournamentSettingsPanel.ExportDescription"));
    localJFileChooser.setSelectedFile(new File(í().S() + ".xml"));
    if (localJFileChooser.showDialog(this, com.biotools.poker.E.D("TournamentSettingsPanel.Export")) == 0)
    {
      File localFile = localJFileChooser.getSelectedFile();
      if (localFile != null)
      {
        T localT = í();
        localT.B(localFile);
        localT.h();
      }
    }
  }

  public void Ý()
  {
    JFileChooser localJFileChooser = new JFileChooser();
    localJFileChooser.setFileFilter(new com.biotools.A.J());
    localJFileChooser.setDialogTitle(com.biotools.poker.E.D("TournamentSettingsPanel.ImportDescription"));
    if (localJFileChooser.showDialog(this, com.biotools.poker.E.D("TournamentSettingsPanel.Import")) == 0)
    {
      File localFile = localJFileChooser.getSelectedFile();
      if (localFile != null)
      {
        T localT = T.C(localFile);
        if (localT != null)
        {
          localT.A(com.biotools.poker.E.T());
          E(localT);
        }
        else
        {
          JOptionPane.showMessageDialog(this, com.biotools.poker.E.D("TournamentSettingsPanel.ErrorBadXML"), com.biotools.poker.E.D("TournamentSettingsPanel.ErrorImportingCustom"), 0);
        }
      }
      else
      {
        JOptionPane.showMessageDialog(this, com.biotools.poker.E.D("TournamentSettingsPanel.ErrorBadXML"), com.biotools.poker.E.D("TournamentSettingsPanel.ErrorImportingCustom"), 0);
      }
    }
  }

  public void F(T paramT)
  {
    j();
    paramT.C(ª());
    paramT.B(c().getText());
    paramT.D(æ());
    paramT.I(ì());
    paramT.B(þ());
    paramT.V(ù());
    paramT.W(y());
    paramT.A(new com.biotools.poker.G.d(C()));
    paramT.L(M());
    paramT.A(Í(), z());
    paramT.P(K().getSelectedIndex());
    paramT.A(x());
    paramT.A((com.biotools.poker.G.A)this.M.get(this.U.getSelectedIndex()));
    paramT.U(l());
    paramT.A(p().A());
    paramT.N(p().F());
  }

  public void ü()
  {
    í().T(â() * y());
    ð();
    P.A(com.biotools.poker.E.D("TournamentSettingsPanel.SeatingPlayers"));
    O().H();
  }

  private void Z()
  {
    K().setSelectedIndex(í().Q());
  }

  private void Û()
  {
    b().setText(Q());
  }

  private void º()
  {
    Ê().setValue(new Double(í().X()));
  }

  private void Ā()
  {
    ñ().setValue(new Integer(í().V()));
  }

  private void Ä()
  {
    ò().setValue(new Integer(í().µ()));
    if (í().Á() <= í().¢())
      ò().setMinimum(new Integer(2));
    else
      ò().setMinimum(new Integer(3));
  }

  private void a()
  {
    i().setValue(new Integer(í().Á()));
  }

  private void Æ()
  {
    Á().setValue(new Integer(í().o()));
  }

  private void ÿ()
  {
    ö().setMaximum(new Integer(í().l()));
    ö().setValue(new Integer(í().I()));
  }

  private void Ï()
  {
    µ().setValue(new Integer(í().¢()));
  }

  private void B(int paramInt)
  {
    if (this.q)
      return;
    if (paramInt == this.S)
      return;
    this.S = paramInt;
    com.biotools.poker.E.H("TournamentSettingsPanel: setNumPlayers: " + paramInt);
    this.q = true;
    if (paramInt > þ())
      paramInt = þ();
    if (paramInt < ù())
      paramInt = ù();
    if ((!w().getValueIsAdjusting()) && (w().getValue() != paramInt))
      w().setValue(paramInt);
    if (P().B() != paramInt)
      P().C(paramInt);
    if (ñ().getNumber().intValue() != paramInt)
      ñ().setValue(new Integer(paramInt));
    ë();
    Û();
    this.q = false;
  }

  protected void C(T paramT)
  {
    if (paramT == null)
      return;
    U();
    A(paramT);
    ¥();
    A(false);
    C(false);
  }

  public void ¥()
  {
    á();
    J();
    v();
    û();
    C(false);
  }

  private void á()
  {
    ä().setText(m());
    q().setText(í().S());
    c().setText(í().i());
    p().A(í().u());
    p().A(í().y());
    Æ();
    n();
  }

  private void J()
  {
    b().setText(u());
    é().A(í().Y());
  }

  private void v()
  {
    ÿ();
    T();
    h().A(í().B());
    Z();
  }

  private void û()
  {
    I();
    ë();
    º();
  }

  private void I()
  {
    if (!this.¢)
    {
      int i1 = this.M.size() - 1;
      this.M.remove(i1);
      Ü().removeElementAt(i1);
      this.¢ = true;
    }
    if (í().N().D() != null)
    {
      this.M.add(í().N());
      Ü().addElement(í().N().D());
      Ð().setSelectedIndex(this.M.size() - 1);
      this.¢ = false;
    }
    else
    {
      Ð().setSelectedIndex(0);
    }
  }

  private void n()
  {
    w().setMinimum(í().µ());
    w().setMaximum(í().Á());
    w().setValue(í().V());
    P().setValue(new Integer(í().V()));
    Ā();
    a();
    Ä();
    Ï();
    j();
  }

  private void Ñ()
  {
    s().setValue(new Integer(í().H()));
    s().setMinimum(new Integer(1));
    s().setMaximum(new Integer(120));
    à().removeAllElements();
    for (int i2 = 0; i2 <= 2; i2++)
      à().addElement(e.I(i2));
    int i1 = í().L();
    à().setSelectedItem(e.I(i1));
  }

  private void Ó()
  {
    Integer localInteger = new Integer(í().H());
    s().setValue(localInteger);
    s().setMinimum(localInteger);
    s().setMaximum(localInteger);
    à().removeAllElements();
    int i1 = í().L();
    à().addElement(e.I(i1));
  }

  private void T()
  {
    if (í().x())
      Ñ();
    else
      Ó();
  }

  public void j()
  {
    B(P().B());
    try
    {
      Ë().commitEdit();
    }
    catch (ParseException localParseException1)
    {
    }
    try
    {
      ã().commitEdit();
    }
    catch (ParseException localParseException2)
    {
    }
    try
    {
      Ù().commitEdit();
    }
    catch (ParseException localParseException3)
    {
    }
  }

  private void ô()
  {
    File localFile = com.biotools.poker.E.K("payouts.xml");
    if (localFile == null)
      com.biotools.A.d.A("Error: No Payouts Found");
    A(localFile);
  }

  private void A(File paramFile)
  {
    try
    {
      A(b.A(paramFile));
    }
    catch (Exception localException)
    {
      com.biotools.A.d.A(localException);
    }
  }

  private void A(String paramString)
    throws Exception
  {
    if (paramString == null)
      return;
    this.M = new ArrayList();
    com.biotools.poker.E.H("START: Loading Payouts from XML");
    DocumentBuilder localDocumentBuilder = null;
    DocumentBuilderFactory localDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
    try
    {
      localDocumentBuilder = localDocumentBuilderFactory.newDocumentBuilder();
    }
    catch (ParserConfigurationException localParserConfigurationException)
    {
      I.A(com.biotools.poker.E.D("TournamentSettingsPanel.ErorrCouldNotMakeXML"), localParserConfigurationException);
    }
    Document localDocument = null;
    try
    {
      synchronized (localDocumentBuilder)
      {
        localDocument = localDocumentBuilder.parse(new InputSource(new StringReader(paramString)));
      }
    }
    catch (Exception localException)
    {
    }
    if (localDocument == null)
      return;
    Element localElement1 = localDocument.getDocumentElement();
    if (localElement1 == null)
      return;
    NodeList localNodeList1 = localElement1.getElementsByTagName("payout_structure");
    for (int i1 = 0; i1 < localNodeList1.getLength(); i1++)
    {
      Element localElement2 = (Element)localNodeList1.item(i1);
      com.biotools.poker.G.A localA = new com.biotools.poker.G.A();
      String str = localElement2.getAttribute("name");
      localA.A(str);
      NodeList localNodeList2 = localElement2.getElementsByTagName("payouts_by_num_entrants");
      for (int i2 = 0; i2 < localNodeList2.getLength(); i2++)
      {
        Element localElement3 = (Element)localNodeList2.item(i2);
        a locala = a.A(localElement3);
        localA.A(locala);
      }
      System.out.println("found " + str);
      this.M.add(localA);
      Ü().addElement(localA.D());
    }
    Ð().setSelectedIndex(0);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.L
 * JD-Core Version:    0.6.2
 */