package com.biotools.poker.C;

import com.biotools.poker.C.A.D;
import com.biotools.poker.E;
import com.biotools.poker.S.E.N;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.List;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JViewport;
import javax.swing.Timer;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.JTableHeader;

public class I extends JPanel
  implements S
{
  private N Ǝ = new N();
  private JTabbedPane Ɗ;
  private F Ɖ = new F();
  private F ƌ = new F();
  private F Ƈ = new F();
  private F ƍ = new F();
  private F Ɠ = new F();
  private F Ƒ = new F();
  private F Ə = new F();
  private com.biotools.poker.S.E.K Ɔ = null;
  private K ƒ;
  private A Ɛ;
  private Timer ƈ;
  private HashMap Ƌ = new HashMap();

  public I(A paramA)
  {
    this.Ɛ = paramA;
    setLayout(new BorderLayout(3, 3));
    add(ĕ(), "Center");
    add(Ē(), "South");
    A(null, true);
  }

  private K Ē()
  {
    if (this.ƒ == null)
      this.ƒ = new K();
    return this.ƒ;
  }

  private JComponent ĕ()
  {
    if (this.Ɗ == null)
    {
      this.Ɗ = new JTabbedPane();
      this.Ɗ.setFont(this.Ɗ.getFont().deriveFont(10.0F));
      this.Ɗ.add(E.D("OnlineRoomBrowser.All"), A(this.Ɖ));
      this.Ɗ.add(E.D("OnlineRoomBrowser.Limit"), A(this.Ƈ));
      this.Ɗ.add(E.D("OnlineRoomBrowser.NoLimit"), A(this.ƌ));
      this.Ɗ.add(E.D("OnlineRoomBrowser.Tournament"), A(this.ƍ));
      this.Ɗ.add(E.D("OnlineRoomBrowser.Scheduled"), A(this.Ə));
      this.Ɗ.add(E.D("OnlineRoomBrowser.Freerolls"), A(this.Ɠ));
      this.Ɗ.add(E.D("OnlineRoomBrowser.Private"), A(this.Ƒ));
      this.Ɗ.addChangeListener(new ChangeListener()
      {
        public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
        {
          int i = I.this.Ɗ.getSelectedIndex();
          if (i == 0)
            I.this.Ɖ.A();
          if (i == 1)
            I.this.Ƈ.A();
          if (i == 2)
            I.this.ƌ.A();
          if (i == 3)
            I.this.ƍ.A();
          if (i == 4)
            I.this.Ə.A();
          if (i == 5)
            I.this.Ɠ.A();
          if (i == 6)
            I.this.Ƒ.A();
        }
      });
    }
    return this.Ɗ;
  }

  private JScrollPane A(F paramF)
  {
    paramF.addMouseListener(new MouseAdapter()
    {
      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        if (paramAnonymousMouseEvent.getClickCount() == 2)
        {
          F localF = (F)paramAnonymousMouseEvent.getComponent();
          if (localF.getSelectedRow() >= 0)
            I.this.Ɛ.E(I.this.Ɔ);
        }
      }
    });
    paramF.A(this);
    paramF.A(this.Ɛ);
    JScrollPane localJScrollPane = new JScrollPane(paramF);
    int i = 2 + (int)paramF.getTableHeader().getPreferredSize().getHeight() + paramF.getRowHeight() * 10;
    localJScrollPane.setPreferredSize(new Dimension(380, i));
    localJScrollPane.getViewport().setBackground(Color.WHITE);
    return localJScrollPane;
  }

  public void A(com.biotools.poker.S.E.K paramK, boolean paramBoolean)
  {
    if (paramBoolean)
    {
      this.Ɔ = paramK;
      this.ƒ.B(paramK);
    }
  }

  protected com.biotools.poker.S.E.K a(String paramString)
  {
    com.biotools.poker.S.E.K localK = null;
    localK = this.Ɖ.A(paramString);
    if (localK != null)
      return localK;
    localK = this.Ƈ.A(paramString);
    if (localK != null)
      return localK;
    localK = this.ƌ.A(paramString);
    if (localK != null)
      return localK;
    localK = this.ƍ.A(paramString);
    if (localK != null)
      return localK;
    localK = this.Ə.A(paramString);
    if (localK != null)
      return localK;
    localK = this.Ɠ.A(paramString);
    if (localK != null)
      return localK;
    localK = this.Ƒ.A(paramString);
    if (localK != null)
      return localK;
    return localK;
  }

  protected F D(com.biotools.poker.S.E.K paramK)
  {
    if (paramK.c())
      return this.Ƒ;
    if (paramK.b())
      return this.Ƈ;
    if (paramK.X())
      return this.ƌ;
    if (paramK.C())
      return this.Ə;
    if (paramK.h())
    {
      if (paramK.E())
        return this.Ɠ;
      return this.ƍ;
    }
    return this.Ɖ;
  }

  protected void đ()
  {
    this.Ƌ.clear();
    this.Ɖ.B().B();
    this.Ƈ.B().B();
    this.ƌ.B().B();
    this.ƍ.B().B();
    this.Ə.B().B();
    this.Ɠ.B().B();
    this.Ƒ.B().B();
    this.ƒ.B(null);
  }

  public void B(String paramString, int paramInt, List paramList)
  {
    com.biotools.poker.S.E.K localK = this.ƒ.A();
    if ((ē() != null) && (ē().a().equals(paramString)))
    {
      localK.A(paramList);
      localK.B(paramInt);
      A(localK, true);
    }
  }

  public synchronized void B(com.biotools.poker.S.E.K paramK)
  {
    this.ƒ.B(paramK);
    C(paramK);
  }

  public synchronized void C(com.biotools.poker.S.E.K paramK)
  {
    this.Ƌ.put(paramK.a(), paramK);
    D(paramK).B(paramK);
    this.Ɖ.B(paramK);
    if ((this.Ɔ != null) && (paramK.a().equals(this.Ɔ.a())))
    {
      D(paramK).A(paramK);
      paramK.A(this.Ɔ.U());
      this.ƒ.B(paramK);
      this.Ɖ.A(paramK);
    }
  }

  public synchronized void b(String paramString)
  {
    com.biotools.poker.S.E.K localK1 = this.ƒ.A();
    if ((localK1 != null) && (localK1.a().equals(paramString)))
    {
      this.Ɔ = null;
      this.ƒ.B(null);
    }
    com.biotools.poker.S.E.K localK2 = (com.biotools.poker.S.E.K)this.Ƌ.remove(paramString);
    if (localK2 != null)
    {
      D(localK2).C(localK2);
      this.Ɖ.C(localK2);
    }
  }

  public com.biotools.poker.S.E.K ē()
  {
    return this.Ɔ;
  }

  private Timer Ĕ()
  {
    if (this.ƈ == null)
    {
      this.ƈ = new Timer(10000, new ActionListener()
      {
        boolean A = false;

        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          if (I.this.Ɛ.ę())
            this.A = (!this.A);
          else
            this.A = true;
          if ((this.A) && (I.this.isVisible()))
            I.this.Ɛ.ĩ();
        }
      });
      this.ƈ.setCoalesce(true);
      this.ƈ.setRepeats(true);
      this.ƈ.setInitialDelay(0);
    }
    return this.ƈ;
  }

  public void A(boolean paramBoolean)
  {
    A(null, true);
    if (paramBoolean)
    {
      Ĕ().start();
    }
    else
    {
      đ();
      Ĕ().stop();
    }
  }

  public void A(D paramD)
  {
    this.Ɖ.A(paramD);
    this.ƌ.A(paramD);
    this.Ƈ.A(paramD);
    this.ƍ.A(paramD);
    this.Ə.A(paramD);
    this.Ɠ.A(paramD);
    this.Ƒ.A(paramD);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.I
 * JD-Core Version:    0.6.2
 */