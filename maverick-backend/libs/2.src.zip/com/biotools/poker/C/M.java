package com.biotools.poker.C;

import B.A.A.B;
import com.biotools.B.J;
import com.biotools.poker.E;
import com.biotools.poker.P.N;
import com.biotools.poker.PokerApp;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.util.Iterator;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class M extends JPanel
{
  private Vector E = new Vector();
  private Vector F = new Vector();
  private JComboBox A;
  private JButton C;
  private JButton G;
  private boolean D = false;
  private JLabel B = new JLabel(new ImageIcon(E.K("pix/lobby/profile.png").getPath()), 4);

  public M()
  {
    setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    setLayout(new B(4, 4));
    add("vcenter", this.B);
    add(Box.createHorizontalStrut(4));
    add("hfill", C());
    add(Box.createHorizontalStrut(1));
    add(A());
    add(Box.createHorizontalStrut(1));
    add(E());
  }

  public JLabel F()
  {
    return this.B;
  }

  public void B(ChangeListener paramChangeListener)
  {
    this.E.add(paramChangeListener);
  }

  public void A(ChangeListener paramChangeListener)
  {
    this.E.remove(paramChangeListener);
  }

  public void H()
  {
    if (this.D)
      return;
    ChangeEvent localChangeEvent = new ChangeEvent(this);
    Iterator localIterator = this.E.iterator();
    while (localIterator.hasNext())
      ((ChangeListener)localIterator.next()).stateChanged(localChangeEvent);
  }

  public String I()
  {
    return (String)this.A.getSelectedItem();
  }

  public void setEnabled(boolean paramBoolean)
  {
    this.A.setEnabled(paramBoolean);
    this.C.setEnabled(paramBoolean);
    this.G.setEnabled((paramBoolean) && (this.F.size() > 0));
  }

  public void G()
  {
    this.D = true;
    this.F.clear();
    this.F.addAll(N.Ñ());
    this.A.setModel(new DefaultComboBoxModel(this.F));
    this.A.invalidate();
    this.D = false;
    A(PokerApp.Ȅ().ɬ());
  }

  private JComponent C()
  {
    this.A = new JComboBox();
    this.A.setOpaque(false);
    G();
    this.A.addItemListener(new ItemListener()
    {
      public void itemStateChanged(ItemEvent paramAnonymousItemEvent)
      {
        M.this.H();
      }
    });
    return this.A;
  }

  private JComponent A()
  {
    this.C = new J("add.png", E.D("ProfileSelectorWidget.AddProfileToolTip"));
    this.C.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        M.this.D();
      }
    });
    return this.C;
  }

  private JComponent E()
  {
    this.G = new J("del.png", E.D("ProfileSelectorWidget.DeleteProfileToolTip"));
    this.G.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        M.this.B();
      }
    });
    return this.G;
  }

  private void D()
  {
    String str = N.A(this.C);
    if (str != null)
    {
      this.F.addElement(str);
      A(str);
      this.G.setEnabled(true);
      this.A.setEnabled(true);
    }
  }

  private void B()
  {
    String str = (String)this.A.getSelectedItem();
    if ((str != null) && (N.B(this.G, str)))
    {
      this.A.setSelectedIndex(0);
      this.F.removeElement(str);
      if (this.F.size() == 0)
      {
        this.G.setEnabled(false);
        this.A.setEnabled(false);
      }
      else
      {
        this.A.setSelectedIndex(0);
      }
    }
  }

  public void A(String paramString)
  {
    if ((paramString != null) && (this.F.indexOf(paramString) >= 0))
      this.A.setSelectedItem(paramString);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.M
 * JD-Core Version:    0.6.2
 */