package com.biotools.poker.C.B;

import B.A.A.B;
import com.biotools.B.K;
import com.biotools.B.O;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.io.File;
import java.text.ParseException;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

public class F extends JPanel
{
  private JPanel I;
  private JPanel U;
  private JPanel P;
  private JPanel O;
  private JPanel R;
  private JPanel K;
  private JPanel J;
  private JLabel E;
  private JButton C;
  private com.biotools.poker.C.A D;
  private JTextField W;
  private JTextField F;
  private JSpinner L;
  private JDialog V;
  private JComboBox B;
  private JComboBox Q;
  private JComboBox M;
  private O T;
  private A H;
  private E S;
  private D N;
  private String[] G = { com.biotools.poker.E.D("CreateRoomWizard.NoLimit"), com.biotools.poker.E.D("CreateRoomWizard.FixedLimit") };
  private String[] A = { com.biotools.poker.E.D("CreateRoomWizard.RingGame"), com.biotools.poker.E.D("CreateRoomWizard.Tournament") };
  private String[] X = { com.biotools.poker.E.D("CreateRoomWizard.PlayMoney"), com.biotools.poker.E.D("CreateRoomWizard.PAX") };

  public F(JFrame paramJFrame, com.biotools.poker.C.A paramA)
  {
    this.D = paramA;
    _();
  }

  public void a()
  {
    W().setEnabled(true);
    this.V = new F.1(this, this.D, true);
    this.V.setTitle(com.biotools.poker.E.D("CreateRoomWizard.CreateCustomRoomHeading"));
    this.V.getContentPane().add(this);
    this.V.pack();
    this.V.setLocationRelativeTo(this.D);
    this.V.setVisible(true);
  }

  public void Y()
  {
    if (this.V != null)
      this.V.dispose();
  }

  public void _()
  {
    setLayout(new BorderLayout(4, 4));
    add(R(), "Center");
    if (com.biotools.poker.E.¤())
      A(R());
  }

  private void A(JComponent paramJComponent)
  {
    float f = 10.0F;
    paramJComponent.setFont(paramJComponent.getFont().deriveFont(f));
    for (int i = 0; i < paramJComponent.getComponentCount(); i++)
    {
      Component localComponent = paramJComponent.getComponent(i);
      if ((localComponent instanceof JComponent))
        A((JComponent)localComponent);
    }
  }

  private JPanel R()
  {
    if (this.I == null)
    {
      this.I = new JPanel(new BorderLayout(4, 4));
      this.I.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
      this.I.add(M(), "West");
      this.I.add(E(), "Center");
    }
    return this.I;
  }

  private JPanel E()
  {
    if (this.O == null)
    {
      this.O = new JPanel(new BorderLayout(4, 4));
      this.O.setBorder(BorderFactory.createEtchedBorder());
      this.O.add(B(), "North");
      this.O.add(K(), "Center");
    }
    return this.O;
  }

  private JPanel K()
  {
    if (this.J == null)
    {
      this.J = new JPanel(new BorderLayout(3, 0));
      this.J.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
      this.J.add(F(), "North");
      this.J.add(D(), "Center");
    }
    return this.J;
  }

  private O D()
  {
    if (this.T == null)
    {
      this.T = new O();
      this.T.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
      this.T.A(S(), "RingRoomPanel");
      this.T.A(H(), "TourneyRoomPanel");
      this.T.A(O(), "TourneyAdvancedPanel");
    }
    return this.T;
  }

  private A S()
  {
    if (this.H == null)
      this.H = new A();
    return this.H;
  }

  private E H()
  {
    if (this.S == null)
      this.S = new E(T());
    return this.S;
  }

  private D O()
  {
    if (this.N == null)
      this.N = new D();
    return this.N;
  }

  private JPanel B()
  {
    if (this.P == null)
    {
      JLabel localJLabel = new JLabel(com.biotools.poker.E.D("CreateRoomWizard.CreateRoom"), 0);
      localJLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
      localJLabel.setFont(localJLabel.getFont().deriveFont(1));
      localJLabel.setForeground(Color.WHITE);
      this.P = new JPanel(new BorderLayout(4, 4));
      this.P.setBackground(Color.GRAY);
      this.P.setBorder(BorderFactory.createEtchedBorder());
      this.P.add(localJLabel, "Center");
    }
    return this.P;
  }

  private JPanel M()
  {
    if (this.U == null)
    {
      this.U = new JPanel();
      this.U.setLayout(new BorderLayout(8, 8));
      this.U.setBackground(Color.LIGHT_GRAY);
      this.U.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(), BorderFactory.createEmptyBorder(6, 6, 6, 6)));
      this.U.add(C(), "North");
      this.U.add(Q(), "South");
    }
    return this.U;
  }

  private JLabel C()
  {
    if (this.E == null)
    {
      this.E = new JLabel("<html><div align=\"center\"<br><b>" + com.biotools.poker.E.D("CreateRoomWizard.CreateCustomRoom") + "</b></div>" + "<div width=\"190\" align=\"justify\"><br>" + com.biotools.poker.E.D("CreateRoomWizard.CustomRoomDirections") + "&nbsp; &nbsp; &nbsp; &nbsp;</div>" + "</html>", new ImageIcon(com.biotools.poker.E.K("pix/palogo-150x129.png").getPath()), 0);
      this.E.setVerticalTextPosition(3);
      this.E.setHorizontalTextPosition(0);
    }
    return this.E;
  }

  private JButton W()
  {
    if (this.C == null)
    {
      this.C = new K("create-room.png", com.biotools.poker.E.D("CreateRoomWizard.CreateOnlineRoom"));
      this.C.addActionListener(new F.2(this));
      if (com.biotools.poker.E.¤())
        this.C.setOpaque(false);
    }
    return this.C;
  }

  private void A()
  {
    if (com.biotools.poker.E.Ô())
      return;
    W().requestFocusInWindow();
    boolean bool = V().getSelectedItem().equals(com.biotools.poker.E.D("CreateRoomWizard.PAX"));
    long l = -1L;
    if (this.B.getSelectedIndex() == 2)
    {
      JOptionPane.showMessageDialog(null, "Please first change game type to ring game or tournament.");
      return;
    }
    String str1;
    if (this.B.getSelectedIndex() == 0)
    {
      str1 = S().A(T(), !bool);
    }
    else
    {
      str1 = H().A(T(), !bool);
      l = H().S();
    }
    String str2 = X().getText();
    String str3 = L().getText();
    String str4 = O().F();
    A(false);
    this.D.A(str3, str2, str2, str1, U(), bool, l, str4);
  }

  private int U()
  {
    try
    {
      I().commitEdit();
    }
    catch (ParseException localParseException)
    {
      localParseException.printStackTrace();
    }
    return ((Integer)I().getValue()).intValue();
  }

  public JPanel Q()
  {
    if (this.K == null)
    {
      this.K = new JPanel();
      this.K.setOpaque(false);
      this.K.setLayout(new B());
      this.K.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
      this.K.add("br", new JLabel(com.biotools.poker.E.D("CreateRoomWizard.RoomNameTitle")));
      this.K.add("br", L());
      this.K.add("br", new JLabel(com.biotools.poker.E.D("CreateRoomWizard.PasswordTitle")));
      this.K.add("br", X());
      this.K.add("p center", W());
    }
    return this.K;
  }

  public JPanel F()
  {
    if (this.R == null)
    {
      this.R = new JPanel();
      this.R.setLayout(new B());
      this.R.add("tab", Z());
      this.R.add("tab", G());
    }
    return this.R;
  }

  public JPanel G()
  {
    JPanel localJPanel = new JPanel(new B());
    localJPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("CreateRoomWizard.PlayersTitle")), BorderFactory.createEmptyBorder(5, 5, 5, 5)));
    localJPanel.add(new JLabel(com.biotools.poker.E.D("CreateRoomWizard.TimeoutTitle")));
    localJPanel.add("tab", I());
    return localJPanel;
  }

  public JPanel Z()
  {
    JPanel localJPanel = new JPanel(new B());
    localJPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("CreateRoomWizard.GameTypeTitle")), BorderFactory.createEmptyBorder(5, 5, 5, 5)));
    localJPanel.add("tab", P());
    localJPanel.add("tab", J());
    localJPanel.add("tab", V());
    return localJPanel;
  }

  public JTextField L()
  {
    if (this.W == null)
      this.W = new JTextField(16);
    return this.W;
  }

  public JTextField X()
  {
    if (this.F == null)
      this.F = new JTextField(16);
    return this.F;
  }

  public JSpinner I()
  {
    if (this.L == null)
    {
      SpinnerNumberModel localSpinnerNumberModel = new SpinnerNumberModel(30, 15, 3000, 5);
      this.L = new JSpinner(localSpinnerNumberModel);
    }
    return this.L;
  }

  private JComboBox P()
  {
    if (this.M == null)
    {
      this.M = new JComboBox(this.G);
      this.M.addActionListener(new F.3(this));
    }
    return this.M;
  }

  public boolean T()
  {
    return P().getSelectedIndex() != 0;
  }

  public void N()
  {
    if (J().getItemCount() <= 2)
      J().addItem("Advanced");
  }

  private JComboBox J()
  {
    if (this.B == null)
    {
      this.B = new JComboBox(this.A);
      this.B.addActionListener(new F.4(this));
    }
    return this.B;
  }

  private JComboBox V()
  {
    if (this.Q == null)
    {
      this.Q = new JComboBox(this.X);
      this.Q.addActionListener(new F.5(this));
    }
    return this.Q;
  }

  public void A(String paramString)
  {
    Object[] arrayOfObject = { paramString };
    L().setText(com.biotools.poker.E.A("CreateRoomWizard.DefaultRoomNamePattern", arrayOfObject));
  }

  public void A(boolean paramBoolean)
  {
    W().setEnabled(paramBoolean);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.B.F
 * JD-Core Version:    0.6.2
 */