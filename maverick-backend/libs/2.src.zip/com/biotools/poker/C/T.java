package com.biotools.poker.C;

import com.biotools.B.N;
import com.biotools.poker.C.A.A;
import com.biotools.poker.C.A.D;
import com.biotools.poker.E;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.ListSelectionModel;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

public class T extends JPanel
{
  private N D;
  private _B C;
  private JScrollPane B;
  private D A;
  public static final String[] E = { E.D("OnlineUsersList.Players"), E.D("OnlineUsersList.Location") };

  public T()
  {
    setLayout(new BorderLayout());
    add(B(), "Center");
  }

  protected void A(D paramD)
  {
    this.A = paramD;
    if (paramD != null)
      D().setEnabled(true);
  }

  private JScrollPane B()
  {
    if (this.B == null)
    {
      this.B = new JScrollPane(D());
      this.B.setPreferredSize(new Dimension(200, 200));
      this.B.getViewport().setBackground(Color.WHITE);
    }
    return this.B;
  }

  private JTable D()
  {
    if (this.D == null)
    {
      this.D = new N(A())
      {
        public Component prepareRenderer(TableCellRenderer paramAnonymousTableCellRenderer, int paramAnonymousInt1, int paramAnonymousInt2)
        {
          Component localComponent = super.prepareRenderer(paramAnonymousTableCellRenderer, paramAnonymousInt1, paramAnonymousInt2);
          return T.this.A(localComponent, paramAnonymousInt1, paramAnonymousInt2);
        }
      };
      this.D.setEnabled(false);
      this.D.getTableHeader().setDefaultRenderer(new F._C(this.D.getTableHeader().getDefaultRenderer()));
      this.D.getTableHeader().addMouseListener(new MouseAdapter()
      {
        int A = -1;

        public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
        {
          JTableHeader localJTableHeader = (JTableHeader)paramAnonymousMouseEvent.getSource();
          TableColumnModel localTableColumnModel = localJTableHeader.getColumnModel();
          int i = localTableColumnModel.getColumnIndexAtX(paramAnonymousMouseEvent.getX());
          int j = localTableColumnModel.getColumn(i).getModelIndex();
          if (j != -1)
          {
            T.this.A().C(j);
            localJTableHeader.repaint();
          }
        }
      });
      this.D.addMouseListener(new MouseAdapter()
      {
        public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
        {
          T.this.A(paramAnonymousMouseEvent);
        }
      });
    }
    return this.D;
  }

  public Component A(Component paramComponent, int paramInt1, int paramInt2)
  {
    _A local_A = A(paramInt1);
    if (local_A != null)
      if (local_A.A.equals("ADMIN"))
      {
        paramComponent.setForeground(Color.BLUE);
        paramComponent.setFont(paramComponent.getFont().deriveFont(1));
      }
      else if (local_A.A.equals("BOT"))
      {
        paramComponent.setForeground(Color.MAGENTA);
      }
      else
      {
        paramComponent.setForeground(Color.BLACK);
      }
    return paramComponent;
  }

  private void A(MouseEvent paramMouseEvent)
  {
    if ((paramMouseEvent.getButton() == 3) || (paramMouseEvent.isControlDown()))
    {
      int i = D().rowAtPoint(paramMouseEvent.getPoint());
      if (i >= 0)
      {
        if (!D().isRowSelected(i))
          D().getSelectionModel().setSelectionInterval(i, i);
        if (this.A != null)
        {
          A localA = new A(this.A, A(i).C);
          localA.show(D(), paramMouseEvent.getX(), paramMouseEvent.getY());
        }
      }
    }
  }

  private _A A(int paramInt)
  {
    return A().B(paramInt);
  }

  public void A(String paramString1, String paramString2, String paramString3)
  {
    if (paramString2.equals("null"))
      paramString2 = null;
    A().A(paramString1, paramString2, paramString3);
  }

  public void A(String paramString)
  {
    A().A(paramString);
  }

  public void C()
  {
    A().B();
  }

  private _B A()
  {
    if (this.C == null)
      this.C = new _B();
    return this.C;
  }

  public class _A
  {
    String C;
    String B;
    String A = "USER";

    public _A()
    {
    }

    public String A()
    {
      if (this.B != null)
        return " " + this.B;
      return E.D("OnlineUsersList.Lobby");
    }
  }

  public class _B extends AbstractTableModel
    implements Comparator
  {
    private List C = new Vector();
    private boolean B = false;
    int A = 0;

    public _B()
    {
    }

    public synchronized T._A B(int paramInt)
    {
      if ((paramInt < 0) || (paramInt >= this.C.size()))
        return null;
      return (T._A)this.C.get(paramInt);
    }

    public void C(int paramInt)
    {
      if (this.A == paramInt)
        this.B = (!this.B);
      else
        this.B = false;
      this.A = paramInt;
      A();
    }

    public synchronized void A()
    {
      Collections.sort(this.C, this);
      fireTableDataChanged();
    }

    public synchronized int getRowCount()
    {
      return this.C.size();
    }

    public int getColumnCount()
    {
      return T.E.length;
    }

    public String getColumnName(int paramInt)
    {
      return T.E[paramInt];
    }

    public synchronized Object getValueAt(int paramInt1, int paramInt2)
    {
      T._A local_A = B(paramInt1);
      if (local_A != null)
        switch (paramInt2)
        {
        case 0:
          return " " + local_A.C;
        case 1:
          return local_A.A();
        case 2:
          return " " + local_A.A;
        }
      return "";
    }

    public synchronized void A(String paramString1, String paramString2, String paramString3)
    {
      T._A local_A = B(paramString1);
      if (local_A == null)
      {
        local_A = new T._A(T.this);
        this.C.add(local_A);
      }
      local_A.C = paramString1;
      local_A.B = paramString2;
      local_A.A = paramString3;
      A();
    }

    public synchronized void A(String paramString)
    {
      T._A local_A = B(paramString);
      if (local_A != null)
      {
        this.C.remove(local_A);
        fireTableDataChanged();
      }
    }

    public synchronized T._A B(String paramString)
    {
      Iterator localIterator = this.C.iterator();
      while (localIterator.hasNext())
      {
        T._A local_A = (T._A)localIterator.next();
        if (local_A.C.equals(paramString))
          return local_A;
      }
      return null;
    }

    public synchronized void B()
    {
      this.C.clear();
    }

    public int compare(Object paramObject1, Object paramObject2)
    {
      T._A local_A1 = (T._A)paramObject1;
      T._A local_A2 = (T._A)paramObject2;
      int i = 0;
      if (this.A == 0)
      {
        i = local_A1.C.compareToIgnoreCase(local_A2.C);
        if (i == 0)
          i = local_A1.A().compareToIgnoreCase(local_A2.A());
      }
      else if (this.A == 1)
      {
        i = local_A1.A().compareToIgnoreCase(local_A2.A());
        if (i == 0)
          i = local_A1.C.compareToIgnoreCase(local_A2.C);
      }
      return i * (this.B ? -1 : 1);
    }

    public int A(int paramInt)
    {
      if (this.A != paramInt)
        return 0;
      return this.B ? 1 : 2;
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.T
 * JD-Core Version:    0.6.2
 */