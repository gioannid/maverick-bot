package com.biotools.poker.C;

import com.biotools.poker.E.B;
import com.biotools.poker.G.R;
import com.biotools.poker.G.T;
import com.biotools.poker.G._;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class O extends JTable
{
  private static final Color D = new Color(240, 240, 255);
  private Vector C = new Vector();
  private com.biotools.poker.E.E B = new com.biotools.poker.E.E();
  private Vector E;
  private boolean A = false;

  public O()
  {
    setSelectionMode(0);
    getTableHeader().setReorderingAllowed(false);
    setModel(this.B);
    setShowGrid(false);
    E();
    TableColumnModel localTableColumnModel = getColumnModel();
    DefaultTableCellRenderer localDefaultTableCellRenderer = new DefaultTableCellRenderer();
    localDefaultTableCellRenderer.setHorizontalAlignment(4);
    TableColumn localTableColumn = localTableColumnModel.getColumn(0);
    localTableColumn.setCellRenderer(localDefaultTableCellRenderer);
    localTableColumn.setMinWidth(40);
    localTableColumn.setMaxWidth(70);
    setBackground(Color.WHITE);
    addMouseListener(new MouseAdapter()
    {
      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        int i = O.this.getSelectedRow();
        if (paramAnonymousMouseEvent.getButton() == 3)
        {
          i = O.this.rowAtPoint(paramAnonymousMouseEvent.getPoint());
          if (i > 0)
            O.this.getSelectionModel().setSelectionInterval(i, i);
        }
        O.this.A(O.this.getSelectedRow(), paramAnonymousMouseEvent.getX(), paramAnonymousMouseEvent.getY());
      }
    });
  }

  public Component prepareRenderer(TableCellRenderer paramTableCellRenderer, int paramInt1, int paramInt2)
  {
    Component localComponent = super.prepareRenderer(paramTableCellRenderer, paramInt1, paramInt2);
    if (paramInt1 % 2 != 0)
      localComponent.setBackground(Color.WHITE);
    else
      localComponent.setBackground(D);
    if (getSelectedRow() == paramInt1)
      localComponent.setBackground(localComponent.getBackground().darker());
    return localComponent;
  }

  public void A(boolean paramBoolean)
  {
    this.A = paramBoolean;
    if (!paramBoolean)
      setModel(this.B);
  }

  public void A(R paramR)
  {
    _ local_ = new _(paramR);
    setModel(local_);
  }

  public void E()
  {
    TableColumnModel localTableColumnModel = getColumnModel();
    for (int i = 0; i < localTableColumnModel.getColumnCount(); i++)
    {
      TableColumn localTableColumn = localTableColumnModel.getColumn(i);
      localTableColumn.sizeWidthToFit();
    }
  }

  public com.biotools.poker.E.E D()
  {
    return this.B;
  }

  public Vector A()
  {
    if (this.E == null)
      this.E = B();
    return this.E;
  }

  private Vector B()
  {
    ArrayList localArrayList = B.B(com.biotools.poker.E.Ì());
    Vector localVector = new Vector();
    for (int i = 0; i < localArrayList.size(); i++)
    {
      B localB = (B)localArrayList.get(i);
      if (localB.B() == this.B.O())
        localVector.add(localB.C());
    }
    return localVector;
  }

  private Vector A(String paramString)
  {
    Vector localVector = new Vector();
    if ((paramString != null) && (!paramString.equals("RANDOM")))
      for (int i = 0; i < B.N().size(); i++)
      {
        B localB = (B)B.N().get(i);
        if ((localB.C() != null) && (localB.C().equals(paramString)))
          localVector.add(localB);
      }
    return localVector;
  }

  private String A(int paramInt)
  {
    if (this.B.B(paramInt))
      return this.B.F(paramInt).C();
    if (this.B.I(paramInt))
      return "RANDOM";
    if (this.B.D(paramInt))
      return "";
    if (this.B.E(paramInt))
      return com.biotools.poker.E.D("TableListView.Human");
    return null;
  }

  public void A(com.biotools.poker.E.E paramE)
  {
    setEnabled(paramE != null);
    this.E = null;
    this.B = paramE;
    if (this.B == null)
      this.B = new com.biotools.poker.E.E();
    setModel(this.B);
    this.B.fireTableDataChanged();
  }

  public void A(T paramT)
  {
    setEnabled(paramT != null);
    if (paramT != null)
      this.E = null;
  }

  private synchronized void C()
  {
    ChangeEvent localChangeEvent = new ChangeEvent(this);
    for (int i = 0; i < this.C.size(); i++)
      ((ChangeListener)this.C.get(i)).stateChanged(localChangeEvent);
  }

  public JPopupMenu B(int paramInt)
  {
    if ((paramInt == 0) || (this.B == null))
      return null;
    JPopupMenu localJPopupMenu = new JPopupMenu();
    if (this.B.F())
      localJPopupMenu.add(B(com.biotools.poker.E.D("TableListView.Empty"), paramInt));
    localJPopupMenu.add(B(com.biotools.poker.E.D("TableListView.Random"), paramInt));
    localJPopupMenu.addSeparator();
    for (int i = 0; i < A().size(); i++)
    {
      String str = (String)A().get(i);
      if (str != null)
        localJPopupMenu.add(A(str, paramInt));
    }
    return localJPopupMenu;
  }

  public JMenuItem A(String paramString, int paramInt)
  {
    int i = 20;
    JMenu localJMenu = new JMenu(paramString);
    Vector localVector = A(paramString);
    if (localVector.size() > 0)
    {
      localJMenu.add(A(paramString, com.biotools.poker.E.D("TableListView.Random"), paramInt));
      localJMenu.addSeparator();
      int j;
      if (localVector.size() > i)
      {
        j = 0;
        while (j < localVector.size())
        {
          localJMenu.add(A(localVector, j, i, paramString, paramInt));
          j += i;
        }
      }
      else
      {
        for (j = 0; j < localVector.size(); j++)
          localJMenu.add(A(paramString, localVector.get(j).toString(), paramInt));
      }
    }
    return localJMenu;
  }

  public JMenuItem A(List paramList, int paramInt1, int paramInt2, String paramString, int paramInt3)
  {
    StringBuffer localStringBuffer1 = new StringBuffer();
    int i = paramInt1 + paramInt2 - 1;
    if (i >= paramList.size())
      i = paramList.size() - 1;
    StringBuffer localStringBuffer2 = new StringBuffer(paramList.get(paramInt1).toString());
    StringBuffer localStringBuffer3 = new StringBuffer(paramList.get(i).toString());
    localStringBuffer1.append(localStringBuffer2.substring(0, 1).toUpperCase() + " - " + localStringBuffer3.substring(0, 1).toUpperCase());
    JMenu localJMenu = new JMenu(localStringBuffer1.toString());
    for (int j = paramInt1; j <= i; j++)
      localJMenu.add(A(paramString, paramList.get(j).toString(), paramInt3));
    return localJMenu;
  }

  public JMenuItem B(String paramString, int paramInt)
  {
    JMenuItem localJMenuItem = new JMenuItem(paramString);
    localJMenuItem.addActionListener(new O.2(this, paramInt));
    return localJMenuItem;
  }

  public JMenuItem A(String paramString1, String paramString2, int paramInt)
  {
    JMenuItem localJMenuItem = new JMenuItem(paramString2);
    localJMenuItem.addActionListener(new O.3(this, paramInt, paramString1));
    return localJMenuItem;
  }

  public void A(int paramInt, String paramString)
  {
    if (paramString.equals(com.biotools.poker.E.D("TableListView.Empty")))
      this.B.C(paramInt);
    else if (paramString.equals(com.biotools.poker.E.D("TableListView.Random")))
      this.B.A(paramInt);
    else
      for (int i = 0; i < B.N().size(); i++)
      {
        B localB = (B)B.N().get(i);
        if (localB.J().equals(paramString))
          this.B.A(paramInt, localB);
      }
  }

  private void A(int paramInt1, int paramInt2, int paramInt3)
  {
    if (this.A)
      return;
    JPopupMenu localJPopupMenu = B(getSelectedRow());
    if (localJPopupMenu != null)
      localJPopupMenu.show(this, paramInt2, paramInt3);
  }

  public synchronized void A(ChangeListener paramChangeListener)
  {
    this.C.add(paramChangeListener);
  }

  public synchronized void B(ChangeListener paramChangeListener)
  {
    this.C.remove(paramChangeListener);
  }

  public boolean F()
  {
    return this.B.C();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.O
 * JD-Core Version:    0.6.2
 */