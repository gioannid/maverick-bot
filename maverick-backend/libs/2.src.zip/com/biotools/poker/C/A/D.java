package com.biotools.poker.C.A;

import com.biotools.A.N;
import com.biotools.poker.S.B.B;
import com.biotools.poker.S.B.E;
import com.biotools.poker.S.E.K;

public class D
{
  private E A;

  public D(E paramE)
  {
    this.A = paramE;
  }

  public E A()
  {
    if ((this.A == null) || (this.A.H()))
      return B.l;
    return this.A;
  }

  public void A(K paramK, String paramString)
  {
    assert (A() != null);
    if (A() != null)
    {
      N localN = new N("adminSay");
      if (paramK == null)
        localN.A("port", -1);
      else
        localN.A("port", paramK.V());
      localN.A("message", paramString);
      A().B(localN.toString());
    }
  }

  public void A(K paramK, boolean paramBoolean)
  {
    assert (A() != null);
    if (A() != null)
    {
      N localN = new N("killRoom");
      localN.A("port", paramK.V());
      localN.A("immediate", paramBoolean);
      A().B(localN.toString());
    }
  }

  public void A(String paramString)
  {
    N localN = new N("admin");
    localN.A("command", paramString);
    A().B(localN.toString());
  }

  public boolean B()
  {
    return (this.A != null) && (!this.A.H());
  }

  public void D(String paramString)
  {
    A().B(paramString);
  }

  public void B(String paramString)
  {
    N localN = new N("boot");
    localN.A("name", paramString);
    A().B(localN.toString());
  }

  public void B(String paramString, boolean paramBoolean)
  {
    N localN = new N("setchat");
    localN.A("name", paramString);
    localN.A("chat", paramBoolean);
    A().B(localN.toString());
  }

  public void A(String paramString, double paramDouble)
  {
    N localN = new N("setpax");
    localN.A("name", paramString);
    localN.A("amount", paramDouble);
    A().B(localN.toString());
  }

  public void A(String paramString, boolean paramBoolean)
  {
    N localN = new N("setban");
    localN.A("name", paramString);
    localN.A("value", paramBoolean);
    A().B(localN.toString());
  }

  public void E(String paramString)
  {
    N localN = new N("getUserDetails");
    localN.A("name", paramString);
    A().B(localN.toString());
  }

  public void F(String paramString)
  {
    N localN = new N("fixpax");
    localN.A("name", paramString);
    A().B(localN.toString());
  }

  public void C(String paramString)
  {
    N localN = new N("release");
    localN.A("name", paramString);
    A().B(localN.toString());
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.A.D
 * JD-Core Version:    0.6.2
 */