package com.biotools.poker.C.A;

import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.G.T;
import com.biotools.poker.S.E.N;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;

public class F extends JPanel
{
  private static final N G = new N();
  private JTabbedPane E;
  private JTextField B;
  private com.biotools.B.D C;
  private D A;
  private E D;
  private List H = new ArrayList();
  private int F = -1;

  public F(D paramD)
  {
    this.A = paramD;
    setLayout(new BorderLayout(4, 4));
    setBorder(com.biotools.B.L.B(4));
    add(A(), "Center");
    B("Welcome to Admin Tool Console");
  }

  private JTabbedPane A()
  {
    if (this.E == null)
    {
      this.E = new JTabbedPane();
      this.E.addTab("Console", C());
      this.E.addTab("Users", D());
    }
    return this.E;
  }

  private E D()
  {
    if (this.D == null)
      this.D = new E(this.A);
    return this.D;
  }

  public void B(String paramString)
  {
    this.C.D(paramString + "\n");
  }

  private JPanel C()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BorderLayout(6, 6));
    localJPanel.setFocusable(false);
    this.C = new com.biotools.B.D(new Dimension(150, 150));
    this.C.D().setBackground(Color.black);
    this.C.D().setForeground(Color.yellow);
    this.C.setBackground(Color.black);
    this.C.setForeground(Color.yellow);
    this.C.setFocusable(false);
    Style localStyle = this.C.B("echo", this.C.A());
    StyleConstants.setForeground(localStyle, Color.ORANGE);
    this.B = new JTextField(20);
    this.B.setEditable(true);
    this.B.setFocusCycleRoot(true);
    this.B.addKeyListener(new F.1(this));
    this.B.addActionListener(new F.2(this));
    localJPanel.add(this.C, "Center");
    localJPanel.add(this.B, "South");
    return localJPanel;
  }

  protected synchronized void B()
  {
    String str = this.B.getText().trim();
    if (str.length() > 0)
    {
      this.B.setText("");
      this.C.A(">" + str + "\n", "echo");
      this.H.add(str);
      this.F = this.H.size();
      if (!this.A.B())
      {
        B("ERROR: null connection!");
        return;
      }
      if (!D(str))
        this.A.A(str);
    }
  }

  private boolean D(String paramString)
  {
    Object localObject;
    if (paramString.startsWith(C.B(C.B) + " "))
    {
      localObject = paramString.replaceFirst(C.B(C.B) + " ", "");
      A((String)localObject);
      return true;
    }
    if (paramString.startsWith(C.B(C.Q) + " "))
    {
      localObject = paramString.split(" ");
      if (localObject.length == 2)
      {
        File localFile = new File(localObject[1]);
        if (localFile.exists())
        {
          BufferedReader localBufferedReader = null;
          try
          {
            localBufferedReader = new BufferedReader(new FileReader(localFile));
          }
          catch (IOException localIOException1)
          {
            B(E("ERROR -- can't open file + (" + localObject[1] + ")\n"));
            return true;
          }
          String str = null;
          try
          {
            str = localBufferedReader.readLine();
          }
          catch (IOException localIOException2)
          {
            B(E("ERROR -- reading room line + (" + str + ")\n"));
          }
          while (str != null)
          {
            if ((!str.startsWith("#")) && (str.trim().length() != 0))
              A(str);
            try
            {
              str = localBufferedReader.readLine();
            }
            catch (IOException localIOException3)
            {
              B(E("ERROR -- reading room line + (" + str + ")\n"));
              return true;
            }
          }
          try
          {
            localBufferedReader.close();
          }
          catch (IOException localIOException4)
          {
            B(E("ERROR -- can't close file + (" + localObject[1] + ")\n"));
          }
        }
        else
        {
          B(E("ERROR -- file doesn't exist"));
          return true;
        }
      }
      else
      {
        B(E("ERROR -- usage:\n" + C.B(C.Q + 1)));
        return true;
      }
      B(E("createrooms command finished\n"));
      return true;
    }
    return false;
  }

  private String E(String paramString)
  {
    String str = paramString.replaceAll("<br>", "\n");
    return str;
  }

  private void A(String paramString)
  {
    if ((paramString != null) && (paramString.length() > 0))
    {
      Preferences localPreferences = new Preferences(paramString, ";");
      if (!localPreferences.empty())
      {
        String str = A(localPreferences);
        if (str != null)
        {
          com.biotools.poker.E.H("Sending create room request to Server: " + str);
          this.A.D(str);
          B(E("room creation request sent\n"));
          this.B.setText(null);
        }
        else
        {
          B(E("ERROR -- failure building create game message (" + paramString + ")\n"));
          this.B.setText(null);
        }
      }
      else
      {
        B(E("ERROR -- empty preferences (" + paramString + ")\n"));
        this.B.setText(null);
      }
    }
    else
    {
      B(E("ERROR -- empty preference string\n"));
      this.B.setText(null);
    }
  }

  private String A(Preferences paramPreferences)
  {
    String str = "» ";
    Object localObject1 = null;
    boolean bool = paramPreferences.getBooleanPreference(F._A.access$0(), true);
    long l = -1L;
    Object localObject2;
    if (paramPreferences.getBooleanPreference(F._A.access$1(), true))
    {
      localObject2 = A(paramPreferences.getBooleanPreference(F._A.access$2(), true));
      if (localObject2 == null)
        return null;
      double d1 = paramPreferences.getDoublePreference(F._A.access$3(), 10.0D);
      double d2 = paramPreferences.getDoublePreference(F._A.access$4(), 20.0D);
      ((com.biotools.poker.G.L)localObject2).B(d1, d2);
      ((com.biotools.poker.G.L)localObject2).V(paramPreferences.getIntPreference(F._A.access$5(), 2));
      ((com.biotools.poker.G.L)localObject2).B(paramPreferences.getIntPreference(F._A.access$6(), 10));
      ((com.biotools.poker.G.L)localObject2).S(paramPreferences.getIntPreference(F._A.access$7(), (int)(d2 * 10.0D)));
      ((com.biotools.poker.G.L)localObject2).F(paramPreferences.getIntPreference(F._A.access$8(), (int)(d2 * 100.0D)));
      ((com.biotools.poker.G.L)localObject2).W(paramPreferences.getIntPreference(F._A.access$9(), (int)(d2 * 100.0D)));
      ((com.biotools.poker.G.L)localObject2).A(paramPreferences.getBooleanPreference(F._A.access$10(), false));
      ((com.biotools.poker.G.L)localObject2).B(!bool);
      localObject1 = localObject2;
    }
    else
    {
      localObject2 = C(paramPreferences.getPreference(F._A.access$11(), com.biotools.poker.E.d() + "BTILTP.xml"));
      if (localObject2 == null)
        return null;
      ((T)localObject2).B(!bool);
      int i = paramPreferences.getIntPreference(F._A.access$5(), ((T)localObject2).µ());
      if (i > ((T)localObject2).µ())
        ((T)localObject2).V(i);
      ((T)localObject2).W(paramPreferences.getIntPreference(F._A.access$9(), ((T)localObject2).o()));
      int j = paramPreferences.getIntPreference(F._A.access$6(), ((T)localObject2).Á());
      if (j < ((T)localObject2).Á())
        ((T)localObject2).B(j);
      int k = paramPreferences.getIntPreference(F._A.access$9(), ((T)localObject2).o());
      if ((k != ((T)localObject2).o()) && (k >= ((T)localObject2).v()) && (k <= ((T)localObject2).¥()))
        ((T)localObject2).W(k);
      l = paramPreferences.getLongPreference(F._A.access$12(), -1L);
      int m = paramPreferences.getIntPreference(F._A.access$13(), 0);
      if ((m >= 0) && (m < ((T)localObject2).n()))
        ((T)localObject2).Q(m);
      int n = paramPreferences.getIntPreference(F._A.access$14(), 1);
      if ((n >= 1) && (n <= ((T)localObject2).l()))
        ((T)localObject2).L(n);
      if ((paramPreferences.getPreference(F._A.access$15()) != null) && (paramPreferences.getPreference(F._A.access$16()) != null))
      {
        int i1 = paramPreferences.getIntPreference(F._A.access$15(), 10);
        int i2 = paramPreferences.getIntPreference(F._A.access$16(), 1);
        if ((i2 >= 0) && (i2 < 2))
          ((T)localObject2).B(i1, i2);
      }
      localObject1 = localObject2;
    }
    return G.A(paramPreferences.getPreference(F._A.access$17(), "Admin's Table"), paramPreferences.getPreference(F._A.access$18(), ""), paramPreferences.getPreference(F._A.access$19(), ""), localObject1.F(), paramPreferences.getIntPreference(F._A.access$20(), 30), paramPreferences.getBooleanPreference(F._A.access$21(), true), bool, l, null);
  }

  private com.biotools.poker.G.L A(boolean paramBoolean)
  {
    File localFile = new File(com.biotools.poker.E.Z(), paramBoolean ? "RingL.xml" : "RingNL.xml");
    return (com.biotools.poker.G.L)T.C(localFile);
  }

  private T C(String paramString)
  {
    File localFile = new File(paramString);
    if (!localFile.exists())
    {
      System.out.println("Tournament structure file doesn't exist (" + paramString + ")");
      return null;
    }
    return T.C(localFile);
  }

  protected void A(KeyEvent paramKeyEvent)
  {
    String str;
    if (paramKeyEvent.getKeyCode() == 38)
    {
      this.F -= 1;
      if ((this.F >= 0) && (this.F < this.H.size()))
      {
        str = (String)this.H.get(this.F);
        this.B.setText(str);
      }
      else
      {
        this.F = 0;
      }
    }
    if (paramKeyEvent.getKeyCode() == 40)
    {
      this.F += 1;
      if ((this.F >= 0) && (this.F < this.H.size()))
      {
        str = (String)this.H.get(this.F);
        this.B.setText(str);
      }
      else
      {
        this.F = (this.H.size() - 1);
      }
    }
  }

  public void A(D paramD)
  {
    this.A = paramD;
    D().A(paramD);
  }

  public void A(B paramB)
  {
    D().A(paramB);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.A.F
 * JD-Core Version:    0.6.2
 */