package com.biotools.poker.C.A;

import com.biotools.poker.E;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

public class A extends JPopupMenu
{
  private String B;
  private D A;

  public A(D paramD, String paramString)
  {
    this.B = paramString;
    this.A = paramD;
    add(B());
    addSeparator();
    add(D());
    add(C());
    addSeparator();
    add(A());
  }

  private JMenuItem B()
  {
    JMenuItem localJMenuItem = new JMenuItem(this.B);
    localJMenuItem.setEnabled(false);
    return localJMenuItem;
  }

  private JMenuItem A()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("AdminUserMenu.BootUser"), 66);
    localJMenuItem.addActionListener(new A.1(this));
    return localJMenuItem;
  }

  private JMenuItem D()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("AdminUserMenu.ChatOn"));
    localJMenuItem.addActionListener(new A.2(this));
    return localJMenuItem;
  }

  private JMenuItem C()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("AdminUserMenu.ChatOff"));
    localJMenuItem.addActionListener(new A.3(this));
    return localJMenuItem;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.A.A
 * JD-Core Version:    0.6.2
 */