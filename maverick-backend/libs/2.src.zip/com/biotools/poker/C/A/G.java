package com.biotools.poker.C.A;

import com.biotools.poker.E;
import com.biotools.poker.S.E.K;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

public class G extends JPopupMenu
{
  private K B;
  private D A;

  public G(D paramD, K paramK)
  {
    this.B = paramK;
    this.A = paramD;
    add(A());
    addSeparator();
    add(D());
    addSeparator();
    add(B());
    add(C());
  }

  private JMenuItem A()
  {
    Object[] arrayOfObject = { new Integer(this.B.V()) };
    JMenuItem localJMenuItem = new JMenuItem(E.A("AdminRoomMenu.Port", arrayOfObject));
    localJMenuItem.setEnabled(false);
    return localJMenuItem;
  }

  private JMenuItem D()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("AdminRoomMenu.Announce"), 65);
    localJMenuItem.addActionListener(new G.1(this));
    return localJMenuItem;
  }

  private JMenuItem B()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("AdminRoomMenu.KillRoom"), 75);
    localJMenuItem.addActionListener(new G.2(this));
    return localJMenuItem;
  }

  private JMenuItem C()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("AdminRoomMenu.KillRoomEvil"));
    localJMenuItem.addActionListener(new G.3(this));
    return localJMenuItem;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.A.G
 * JD-Core Version:    0.6.2
 */