package com.biotools.poker.C.A;

import com.biotools.A.N;
import org.w3c.dom.Element;

public class B
{
  private String A;
  private String G;
  private String B;
  private String I;
  private boolean E;
  private boolean C;
  private boolean J;
  private double F;
  private double H;
  private String D;

  public B()
  {
  }

  public B(Element paramElement)
  {
    this.A = N.A(paramElement, "name");
    this.G = N.A(paramElement, "key");
    this.I = N.A(paramElement, "table");
    this.B = N.A(paramElement, "access");
    this.F = N.D(paramElement, "bankroll");
    this.H = N.D(paramElement, "inplay");
    this.A = N.A(paramElement, "name");
    this.A = N.A(paramElement, "name");
    this.E = N.C(paramElement, "online");
    this.C = N.C(paramElement, "banned");
    this.J = N.C(paramElement, "chat");
    this.D = N.A(paramElement, "aliases");
  }

  public String J()
  {
    return this.B;
  }

  public void A(String paramString)
  {
    this.B = paramString;
  }

  public double D()
  {
    return this.F;
  }

  public void A(double paramDouble)
  {
    this.F = paramDouble;
  }

  public boolean C()
  {
    return this.C;
  }

  public void C(boolean paramBoolean)
  {
    this.C = paramBoolean;
  }

  public boolean A()
  {
    return this.J;
  }

  public void B(boolean paramBoolean)
  {
    this.J = paramBoolean;
  }

  public double B()
  {
    return this.H;
  }

  public void B(double paramDouble)
  {
    this.H = paramDouble;
  }

  public String E()
  {
    return this.G;
  }

  public void B(String paramString)
  {
    this.G = paramString;
  }

  public String G()
  {
    return this.A;
  }

  public String K()
  {
    return this.D;
  }

  public void C(String paramString)
  {
    this.A = paramString;
  }

  public boolean H()
  {
    return this.E;
  }

  public void A(boolean paramBoolean)
  {
    this.E = paramBoolean;
  }

  public String F()
  {
    return this.I;
  }

  public void D(String paramString)
  {
    this.I = paramString;
  }

  public boolean I()
  {
    return (this.G == null) || (this.G.equals("null"));
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.A.B
 * JD-Core Version:    0.6.2
 */