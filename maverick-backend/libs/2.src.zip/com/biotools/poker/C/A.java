package com.biotools.poker.C;

import com.biotools.B.L;
import com.biotools.poker.PokerApp;
import com.biotools.poker.Q.J;
import com.biotools.poker.S.A.C;
import com.biotools.poker.S.E.N;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.PrintStream;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;

public class A extends JFrame
  implements com.biotools.poker.S.A.A, S, C
{
  private JButton ơ;
  private JButton Ɩ;
  private JPanel ƛ;
  private JPanel ƪ;
  private com.biotools.poker.C.B.F Ƭ;
  private U ƞ;
  private JLabel Ƣ;
  private E Ɵ;
  private T Ƨ;
  private com.A.B.A Ƥ;
  private volatile boolean ƫ = false;
  private volatile com.biotools.poker.S.B.E Ơ;
  private N ƙ = new N();
  private String Ɲ;
  private com.A.B.A Ɨ;
  private com.biotools.B.D Ƙ;
  private JTextField ƨ;
  private JTabbedPane Ư;
  private Q Ɣ;
  private long Ʈ = -1L;
  private long Ʃ = -1L;
  private J Ʀ;
  private com.biotools.poker.C.A.D Ɯ;
  private com.biotools.poker.C.A.F ƣ;
  private I ƕ;
  private Object ƥ = new Object();
  double ƭ = 0.0D;
  double ƚ = 0.0D;

  public A()
  {
    A(null, false);
    getContentPane().setLayout(new BorderLayout(4, 4));
    getContentPane().add(į(), "Center");
    if (!com.biotools.poker.E.¤())
      com.biotools.B.A.A(į(), new Color(217, 214, 199));
    setTitle(com.biotools.poker.E.D("OnlineLobby.OnlineLobbyHeading"));
    setResizable(false);
    setIconImage(com.biotools.poker.E.¢);
    Q localQ = Ī();
    if (!com.biotools.poker.E.¤())
    {
      localQ.add(Box.createHorizontalStrut(40));
      localQ.add(Ĝ());
      localQ.add(Box.createHorizontalStrut(40));
    }
    setJMenuBar(localQ);
    com.biotools.poker.E.A("PAO_WINDOW", this);
    com.biotools.poker.E.H("Online Lobby Size: " + getSize());
    setDefaultCloseOperation(0);
    addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent paramAnonymousWindowEvent)
      {
        A.this.ĺ();
      }
    });
  }

  private Q Ī()
  {
    if (this.Ɣ == null)
      this.Ɣ = new Q(this);
    return this.Ɣ;
  }

  private JPanel į()
  {
    if (this.ƛ == null)
    {
      this.ƛ = new JPanel();
      this.ƛ.setLayout(new BorderLayout(3, 3));
      this.ƛ.setBorder(BorderFactory.createEmptyBorder(2, 4, 4, 4));
      this.ƛ.add(ĵ(), "Center");
      this.ƛ.add(ħ(), "East");
    }
    return this.ƛ;
  }

  private JPanel ħ()
  {
    if (this.ƪ == null)
    {
      this.ƪ = new JPanel(new BorderLayout(4, 4));
      this.ƪ.add(Ĩ(), "North");
      this.ƪ.add(ĸ(), "Center");
    }
    return this.ƪ;
  }

  private JTabbedPane Ĩ()
  {
    if (this.Ư == null)
    {
      this.Ư = new JTabbedPane();
      this.Ư.addTab(com.biotools.poker.E.D("OnlineLobby.News"), ı());
      this.Ư.addTab(com.biotools.poker.E.D("OnlineLobby.Account"), ķ());
      this.Ư.addTab(com.biotools.poker.E.D("OnlineLobby.Ratings"), Ě());
      this.Ư.addTab(com.biotools.poker.E.D("OnlineLobby.Users"), ļ());
    }
    return this.Ư;
  }

  private JPanel ĸ()
  {
    this.Ƙ = new com.biotools.B.D(new Dimension(200, 185));
    this.Ƙ.A(new Font("Arial", 0, 11));
    Style localStyle1 = this.Ƙ.B("admin", this.Ƙ.A());
    StyleConstants.setForeground(localStyle1, Color.BLUE);
    Style localStyle2 = this.Ƙ.B("user", this.Ƙ.A());
    StyleConstants.setForeground(localStyle2, Color.DARK_GRAY);
    this.ƨ = new JTextField(20);
    this.ƨ.setEnabled(false);
    this.ƨ.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        synchronized (A.this.ƨ)
        {
          if (A.this.Ơ != null)
          {
            String str = A.this.ƨ.getText().trim();
            if (str.length() > 0)
            {
              if (str.length() > 501)
                str = str.substring(0, 500);
              A.this.Ơ.B(A.this.ƙ.C(A.this.ĥ(), str));
            }
          }
          A.this.ƨ.setText("");
        }
      }
    });
    JPanel localJPanel1 = new JPanel(new BorderLayout(3, 3));
    JLabel localJLabel = new JLabel(com.biotools.poker.E.D("OnlineLobby.ChatTitle"));
    localJPanel1.add(localJLabel, "West");
    localJPanel1.add(this.ƨ, "Center");
    JPanel localJPanel2 = new JPanel(new BorderLayout(3, 3));
    Border localBorder = BorderFactory.createEtchedBorder();
    localJPanel2.setBorder(L.A(localBorder, 3));
    localJPanel2.add(this.Ƙ, "Center");
    localJPanel2.add(localJPanel1, "South");
    return localJPanel2;
  }

  private com.biotools.poker.C.B.F Ķ()
  {
    if (this.Ƭ == null)
      this.Ƭ = new com.biotools.poker.C.B.F(null, this);
    return this.Ƭ;
  }

  private JPanel ĵ()
  {
    JPanel localJPanel = new JPanel(new BorderLayout(3, 3));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
    if (com.biotools.poker.E.¤())
      localJPanel.add(Ĝ(), "North");
    localJPanel.add(ė(), "Center");
    localJPanel.add(Ĺ(), "South");
    localJPanel.setOpaque(false);
    return localJPanel;
  }

  private I ė()
  {
    if (this.ƕ == null)
      this.ƕ = new I(this);
    return this.ƕ;
  }

  private JPanel Ĝ()
  {
    JPanel localJPanel = new JPanel(new BorderLayout(4, 4));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
    localJPanel.add(ğ(), "Center");
    localJPanel.setOpaque(false);
    return localJPanel;
  }

  private JLabel ğ()
  {
    if (this.Ƣ == null)
    {
      this.Ƣ = new com.biotools.B.F(0.5D, "<html> </html>", 0);
      this.Ƣ.setBackground(Color.BLACK);
      this.Ƣ.setForeground(Color.WHITE);
      this.Ƣ.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
      this.Ƣ.setFont(this.Ƣ.getFont().deriveFont(1));
      this.Ƣ.setText(com.biotools.poker.E.D("OnlineLobby.PAO"));
    }
    return this.Ƣ;
  }

  private JPanel ı()
  {
    this.Ɨ = new com.A.B.A();
    this.Ɨ.A(com.biotools.A.B.A(com.biotools.poker.E.K("help/login.html")));
    this.Ɨ.B().setFocusable(false);
    this.Ɨ.setPreferredSize(new Dimension(360, 230));
    return this.Ɨ;
  }

  public void ĺ()
  {
    if ((ę()) && (!Ĭ()))
      return;
    Ĵ();
    setVisible(false);
  }

  public boolean Ĭ()
  {
    synchronized (this.ƥ)
    {
      if (Ĥ())
      {
        int i = JOptionPane.showConfirmDialog(this, com.biotools.poker.E.D("OnlineLobby.DisconnectToolTip"), com.biotools.poker.E.D("OnlineLobby.Disconnect"), 0);
        if (i != 0)
          return false;
      }
    }
    return true;
  }

  private JButton Ę()
  {
    if (this.ơ == null)
    {
      this.ơ = new com.biotools.B.K("join-room.png", com.biotools.poker.E.D("OnlineLobby.JoinRoomToolTip"));
      this.ơ.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          A.this.E(A.this.ĳ());
        }
      });
    }
    return this.ơ;
  }

  private JButton ģ()
  {
    if (this.Ɩ == null)
    {
      this.Ɩ = new com.biotools.B.K("create-room.png", com.biotools.poker.E.D("OnlineLobby.CreateRoomToolTip"));
      this.Ɩ.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          A.this.ġ();
        }
      });
    }
    return this.Ɩ;
  }

  protected void İ()
  {
    Ķ().a();
  }

  protected void d(String paramString)
  {
    A(this, paramString);
  }

  protected void A(Component paramComponent, String paramString)
  {
    SwingUtilities.invokeLater(new A.5(this, paramComponent, paramString));
  }

  private int ě()
  {
    return com.biotools.poker.E.a() ? 51 : 50;
  }

  private String Ğ()
  {
    return com.biotools.poker.B.A.B();
  }

  public void ġ()
  {
    if (PokerApp.Ȅ().X(true))
      İ();
  }

  private JPanel Ĺ()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setBorder(BorderFactory.createEmptyBorder(1, 4, 1, 4));
    localJPanel.setOpaque(false);
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(Ę());
    localJPanel.add(Box.createHorizontalGlue());
    if (!com.biotools.poker.E.Ú())
    {
      localJPanel.add(ģ());
      localJPanel.add(Box.createHorizontalGlue());
    }
    return localJPanel;
  }

  public void A(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt, boolean paramBoolean, long paramLong, String paramString5)
  {
    this.Ơ.B(this.ƙ.A(paramString1, paramString2, paramString3, paramString4, paramInt, false, paramBoolean, paramLong, paramString5));
  }

  protected String ĥ()
  {
    return this.Ɲ;
  }

  protected void E(com.biotools.poker.S.E.K paramK)
  {
    if (ę())
    {
      if (PokerApp.Ȅ().ȗ().equals(paramK.a()))
      {
        PokerApp.Ȅ().setExtendedState(0);
        PokerApp.Ȅ().toFront();
        return;
      }
      if (!PokerApp.Ȅ().X(true))
        return;
    }
    if (paramK != null)
    {
      String str1 = "";
      if (paramK.f() != 13)
        str1 = Ĳ();
      if ((str1 != null) && (this.Ơ != null))
      {
        setCursor(Cursor.getPredefinedCursor(3));
        String str2 = this.ƙ.E(paramK.a(), str1);
        this.Ơ.B(str2);
      }
    }
  }

  private void Ģ()
  {
    Thread localThread = new Thread(new A.6(this), "Lobby Message Loop");
    localThread.start();
  }

  private void Į()
  {
    int i = 0;
    this.ƫ = false;
    while ((!this.ƫ) && (this.Ơ != null))
    {
      String str = this.Ơ.D();
      if (str == null)
      {
        System.err.println("ERR: null message from connection");
        i = this.ƫ ? 0 : 1;
        this.ƫ = true;
      }
      else
      {
        this.ƙ.A(str, this);
      }
    }
    ė().A(false);
    com.biotools.poker.E.H("lobby messageLoop exit");
    if (i != 0)
    {
      JOptionPane.showMessageDialog(isVisible() ? this : PokerApp.Ȅ(), com.biotools.poker.E.D("OnlineLobby.DisconnectedFromServerDescription"), com.biotools.poker.E.D("OnlineLobby.DisconnectedFromServer"), 1);
      Ĵ();
    }
  }

  public void A(com.biotools.poker.S.E.K paramK, boolean paramBoolean)
  {
    if (!paramBoolean)
      return;
    if ((paramK != null) && (this.Ơ != null) && (this.ƙ != null))
      this.Ơ.B(this.ƙ.H(paramK.a()));
    Ę().setEnabled(paramK != null);
  }

  public void A(String paramString1, String paramString2)
  {
    SwingUtilities.invokeLater(new A.7(this, paramString1, paramString2));
  }

  public void A(int paramInt, String paramString)
  {
    com.biotools.poker.E.H("BAD-LOGIN: [" + paramInt + "] [" + paramString + "]");
    String str = null;
    switch (paramInt)
    {
    case 3:
      str = com.biotools.poker.E.D("OnlineLobby.UsernameTaken");
      break;
    case 4:
      str = com.biotools.poker.E.D("OnlineLobby.SoftwareNotCompatible");
      break;
    case 6:
      str = com.biotools.poker.E.D("OnlineLobby.AlreadyLoggedIn");
      break;
    case 2:
      str = com.biotools.poker.E.D("OnlineLobby.LoggedInDifferentComputer");
      break;
    case 1:
      str = com.biotools.poker.E.D("OnlineLobby.InvalidCDKey");
      break;
    case 8:
      str = com.biotools.poker.E.D("OnlineLobby.UsernameNotAllowed");
      break;
    case 9:
      str = com.biotools.poker.E.D("OnlineLobby.ShutDown");
      break;
    case 10:
      str = com.biotools.poker.E.D("OnlineLobby.ServerFull");
      break;
    case 47:
      str = com.biotools.poker.E.D("OnlineLobby.DemoNotAllowed");
      break;
    default:
      com.biotools.poker.E.H("err: unknown login problem");
      str = com.biotools.poker.E.D("OnlineLobby.UnknownLoginError") + paramInt + ".\nPlease try again in a few minutes, and\ncontact technical support if the problem continues.";
    }
    Ĵ();
    JOptionPane.showMessageDialog(this, str, com.biotools.poker.E.D("OnlineLobby.Connect"), 1);
    if (paramInt == 4)
      PokerApp.Ȅ().ʞ();
  }

  public void A(String paramString1, int paramInt, String paramString2, String paramString3)
  {
    SwingUtilities.invokeLater(new A.8(this, paramString1, paramInt, paramString2, paramString3));
  }

  public void Z(String paramString)
  {
    SwingUtilities.invokeLater(new A.9(this, paramString));
  }

  private void e(String paramString)
  {
    SwingUtilities.invokeLater(new A.10(this, paramString));
  }

  public void A(String paramString, int paramInt, List paramList)
  {
    SwingUtilities.invokeLater(new A.11(this, paramString, paramInt, paramList));
  }

  public void X(String paramString)
  {
  }

  public void V(String paramString)
  {
    Ķ().Y();
  }

  private com.biotools.poker.S.E.K ĳ()
  {
    return ė().ē();
  }

  private String Ĳ()
  {
    String str = (String)JOptionPane.showInputDialog(this, com.biotools.poker.E.D("OnlineLobby.PasswordRequiredDescription"), com.biotools.poker.E.D("OnlineLobby.PasswordRequired"), -1, null, null, "");
    return str;
  }

  public void P(int paramInt)
  {
    setCursor(Cursor.getPredefinedCursor(0));
    com.biotools.poker.E.H("BAD-JOIN: [" + paramInt + "]");
    String str = null;
    switch (paramInt)
    {
    case 40:
      str = com.biotools.poker.E.D("OnlineLobby.ObserversOnly");
      break;
    case 42:
      str = com.biotools.poker.E.D("OnlineLobby.IncorrectRoomPassword");
      break;
    case 43:
      str = com.biotools.poker.E.D("OnlineLobby.RoomIsFull");
      break;
    case 44:
      str = com.biotools.poker.E.D("OnlineLobby.RoomDoesNotExist");
      if (ĳ() != null)
        W(ĳ().a());
      break;
    case 48:
      str = com.biotools.poker.E.D("OnlineLobby.NotInGuestList");
      break;
    case 49:
      str = com.biotools.poker.E.D("OnlineLobby.RegisteredUsersOnly");
      break;
    case 41:
    case 45:
    case 46:
    case 47:
    default:
      str = com.biotools.poker.E.D("OnlineLobby.UnknownReason");
    }
    JOptionPane.showMessageDialog(this, str, com.biotools.poker.E.D("OnlineLobby.RoomConnectionError"), 0);
  }

  public void Ħ()
  {
    String str = this.ƙ.C();
    this.Ơ.B(str);
    this.Ʈ = com.biotools.A.F.A();
  }

  public void Đ()
  {
    this.Ʃ = (com.biotools.A.F.A() - this.Ʈ);
    A(this.Ʃ, null, this.Ơ.C(), true);
  }

  public void O(int paramInt)
  {
    SwingUtilities.invokeLater(new A.12(this, paramInt));
  }

  public void B(String paramString1, String paramString2)
  {
    if ((paramString1 == null) || (paramString1.equals("Lobby")))
    {
      this.Ƙ.A(paramString2 + "\n", "admin");
    }
    else
    {
      this.Ƙ.A(paramString1 + ": ");
      if (paramString1.equals(this.Ɲ))
        this.Ƙ.A(paramString2 + "\n", "user");
      else
        this.Ƙ.D(paramString2 + "\n");
    }
  }

  private com.A.B.A Ě()
  {
    if (this.Ƥ == null)
    {
      this.Ƥ = new com.A.B.A();
      this.Ƥ.B().setFocusable(false);
      this.Ƥ.setPreferredSize(new Dimension(350, 250));
    }
    return this.Ƥ;
  }

  public T ļ()
  {
    if (this.Ƨ == null)
      this.Ƨ = new T();
    return this.Ƨ;
  }

  public E ķ()
  {
    if (this.Ɵ == null)
      this.Ɵ = new E();
    return this.Ɵ;
  }

  public void A(long paramLong, String paramString, double paramDouble, boolean paramBoolean)
  {
    long l = Math.round(paramLong / 1000.0D);
    String str1 = PokerApp.Ȅ().getTitle();
    int i = str1.indexOf('|');
    if (i > 0)
      str1 = str1.substring(0, i - 1);
    paramDouble = Math.round(paramDouble);
    double d;
    if (paramBoolean)
    {
      this.ƚ = (paramDouble > this.ƚ ? paramDouble : this.ƚ);
      d = this.ƚ;
    }
    else
    {
      this.ƭ = (paramDouble > this.ƭ ? paramDouble : this.ƭ);
      d = this.ƭ;
    }
    String str2 = "";
    if (com.biotools.poker.E.y())
      str2 = "   bps: " + (int)paramDouble + " (" + (int)d + " max)";
    if ((paramString != null) && (!paramBoolean))
      PokerApp.Ȅ().setTitle(str1 + " | " + paramString + " | Connected, Ping: " + l + str2);
    str1 = getTitle();
    i = str1.indexOf('|');
    if (i > 0)
      str1 = str1.substring(0, i - 1);
    if (paramBoolean)
    {
      setTitle(str1 + " | Connected, Ping: " + l + str2);
      return;
    }
  }

  public void ĩ()
  {
    if ((this.Ơ != null) && (isVisible()))
    {
      Ħ();
      if (ė().ē() != null)
        this.Ơ.B(this.ƙ.H(ė().ē().a()));
    }
  }

  public boolean Ĥ()
  {
    return this.Ơ != null;
  }

  public boolean ę()
  {
    return this.Ʀ != null;
  }

  public J ĝ()
  {
    return this.Ʀ;
  }

  public void Ĵ()
  {
    com.biotools.poker.E.H("OnlineLobby.disconnect()");
    PokerApp.Ȅ().X(false);
    this.ƫ = true;
    if (this.Ơ != null)
    {
      this.Ơ.I();
      this.Ơ = null;
    }
    this.Ɯ = null;
    PokerApp.Ȅ().ʜ();
    PokerApp.Ȅ().ȃ().q();
    this.ƨ.setEnabled(false);
    ļ().C();
    ė().A(false);
    setVisible(false);
    PokerApp.Ȅ().ʃ();
  }

  public void ĭ()
  {
    if (this.Ʀ != null)
    {
      this.Ʀ.ü();
      this.Ʀ = null;
    }
  }

  public void C(String paramString1, String paramString2)
  {
    if (paramString2 == null)
      return;
    if (paramString2.length() > 0)
    {
      J localJ = ĝ();
      if (localJ != null)
        try
        {
          localJ.B(paramString1, paramString2);
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
        }
    }
  }

  public void A(String paramString1, String paramString2, com.biotools.poker.S.E.K paramK)
  {
    PokerApp localPokerApp = PokerApp.Ȅ();
    if (this.Ʀ != null)
      ĭ();
    this.Ʀ = new J(paramK, localPokerApp.ǽ(), paramString1);
    PokerApp.Ȅ().A(this.Ʀ, paramString1, paramK);
    this.Ʀ.L(paramString2);
  }

  public void A(double paramDouble1, double paramDouble2, long paramLong)
  {
    SwingUtilities.invokeLater(new A.13(this, paramDouble1, paramDouble2, paramLong));
  }

  public void A(com.biotools.poker.S.B.E paramE, String paramString, U paramU)
  {
    this.ƞ = paramU;
    this.Ơ = paramE;
    this.Ɲ = paramString;
    String str = this.ƙ.A(paramString, Ğ(), ě(), com.biotools.poker.S.F.A.s, com.biotools.poker.E.Ï);
    this.Ơ.B(str);
    Ģ();
    this.ƨ.setEnabled(true);
    Ķ().A(paramString);
  }

  public void A(com.biotools.poker.S.E.K paramK)
  {
    SwingUtilities.invokeLater(new A.14(this, paramK));
  }

  public void W(String paramString)
  {
    SwingUtilities.invokeLater(new A.15(this, paramString));
  }

  private com.biotools.poker.C.A.F ī()
  {
    if ((this.ƣ == null) && (this.Ɯ != null))
      this.ƣ = new com.biotools.poker.C.A.F(this.Ɯ);
    return this.ƣ;
  }

  public void Ė()
  {
    this.Ɯ = new com.biotools.poker.C.A.D(this.Ơ);
    if (this.ƣ == null)
      Ĩ().addTab(com.biotools.poker.E.D("OnlineLobby.Admin"), ī());
    ī().A(this.Ɯ);
    ė().A(this.Ɯ);
    ļ().A(this.Ɯ);
    Ķ().N();
  }

  public boolean Ļ()
  {
    return (this.Ɯ != null) && (this.Ɯ.B());
  }

  public void c(String paramString)
  {
    if (ī() != null)
      ī().B(paramString);
  }

  public void A(String paramString1, String paramString2, String paramString3)
  {
    ļ().A(paramString1, paramString2, paramString3);
  }

  public void Y(String paramString)
  {
    ļ().A(paramString);
  }

  public void Ġ()
  {
    if (Ĥ())
    {
      setExtendedState(0);
      setVisible(true);
      toFront();
    }
  }

  public void A(com.biotools.poker.C.A.B paramB)
  {
    if (ī() != null)
      ī().A(paramB);
  }

  public void _(String paramString)
  {
    A localA = this;
    SwingUtilities.invokeLater(new A.16(this, localA, paramString));
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.A
 * JD-Core Version:    0.6.2
 */