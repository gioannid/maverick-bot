package com.biotools.poker.C;

import com.biotools.A.B;
import com.biotools.A.I;
import com.biotools.A.b;
import com.biotools.A.d;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.StringReader;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class W extends AbstractTableModel
{
  protected com.biotools.poker.E.E R;
  protected com.biotools.poker.E.E T;
  protected ArrayList P;
  private int N;
  private String B = new String();
  private File A;
  private boolean O;
  private String[] F = { com.biotools.poker.E.D("TournamentDistroModel.BotEngine"), com.biotools.poker.E.D("TournamentDistroModel.BotName"), com.biotools.poker.E.D("TournamentDistroModel.Percentage") };
  private static final int H = 100;
  private static final int G = 1;
  public static final int U = 0;
  public static final int C = 1;
  public static final int E = 2;
  private static final String K = com.biotools.poker.E.D("TournamentDistroModel.Random");
  private static final String I = "player_distribution";
  private static final String J = "distribution";
  private static final String L = "name";
  private static final String Q = "no_limit";
  private static final String D = "engine";
  private static final String S = "bot_name";
  private static final String M = "value";

  public W()
  {
    O();
  }

  public void O()
  {
    H();
    this.P = new ArrayList();
    this.N = 0;
    A(com.biotools.poker.E.D("TournamentDistroModel.InitialDistribution"));
    this.O = false;
  }

  public void I()
  {
    H();
    this.P = new ArrayList();
    D(1);
    A(com.biotools.poker.E.D("TournamentDistroModel.InitialDistribution"));
    fireTableDataChanged();
  }

  public String getColumnName(int paramInt)
  {
    return L()[paramInt].toString();
  }

  public int getRowCount()
  {
    return H().R();
  }

  public int getColumnCount()
  {
    return L().length;
  }

  public String[] L()
  {
    return this.F;
  }

  public Object getValueAt(int paramInt1, int paramInt2)
  {
    int i = paramInt1;
    switch (paramInt2)
    {
    case 0:
      return new String((String)this.R.getValueAt(paramInt1, paramInt2 + 1));
    case 1:
      return new String((String)this.R.getValueAt(paramInt1, paramInt2 + 1));
    case 2:
      return (Integer)this.P.get(paramInt1);
    }
    return "";
  }

  public Class getColumnClass(int paramInt)
  {
    Object localObject = getValueAt(0, paramInt);
    if (localObject == null)
      return Object.class;
    return localObject.getClass();
  }

  public boolean isCellEditable(int paramInt1, int paramInt2)
  {
    return paramInt2 == 2;
  }

  public void setValueAt(Object paramObject, int paramInt1, int paramInt2)
  {
    Integer localInteger = null;
    localInteger = (Integer)paramObject;
    if (localInteger.intValue() < 0)
      localInteger = new Integer(-localInteger.intValue());
    if (localInteger != null)
    {
      this.P.set(paramInt1, localInteger);
      fireTableRowsUpdated(paramInt1, paramInt1);
      fireTableDataChanged();
    }
  }

  private void D(int paramInt)
  {
    this.N = paramInt;
    this.R.H(this.N);
    while (this.P.size() > this.N)
      this.P.remove(this.P.size() - 1);
    while (this.P.size() < this.N)
      this.P.add(new Integer(100));
  }

  public void E(int paramInt)
  {
    this.N += 1;
    this.R.V();
    B();
    fireTableRowsInserted(paramInt, paramInt);
  }

  public void A(int paramInt)
  {
    this.N -= 1;
    this.R.K(paramInt);
    this.P.remove(paramInt);
    fireTableRowsDeleted(paramInt, paramInt);
  }

  private void B()
  {
    int j = K();
    int i;
    if (j > 100)
      i = 0;
    else
      i = 100 - j;
    this.P.add(new Integer(i));
  }

  public com.biotools.poker.E.E B(int paramInt)
  {
    if (this.T == null)
    {
      this.T = new com.biotools.poker.E.E();
      this.T.C(H().O());
      this.T.M();
      this.T.H(paramInt);
      int i = 1;
      int j = K();
      for (int k = 0; k < M(); k++)
      {
        int m = C(k) * paramInt / j;
        for (int n = 0; n < m; n++)
          if (i < this.T.R())
            this.T.A(i++, H().J(k));
      }
    }
    return this.T;
  }

  public int K()
  {
    int i = 0;
    for (int j = 0; j < M(); j++)
      i += C(j);
    return i;
  }

  public int C(int paramInt)
  {
    if (paramInt >= this.P.size())
      return 0;
    return ((Integer)this.P.get(paramInt)).intValue();
  }

  public int M()
  {
    return H().R();
  }

  public com.biotools.poker.E.E H()
  {
    if (this.R == null)
      this.R = new com.biotools.poker.E.E();
    return this.R;
  }

  public void F()
  {
    this.T = null;
  }

  public void A(String paramString)
  {
    this.B = paramString;
  }

  public String G()
  {
    if (this.B == null)
      this.B = "Unknown Distro";
    return this.B;
  }

  public String toString()
  {
    return G();
  }

  public File C()
  {
    return this.A;
  }

  public void A(File paramFile)
  {
    this.A = paramFile;
  }

  public void A(boolean paramBoolean)
  {
    H().C(paramBoolean);
  }

  public boolean J()
  {
    return H().O();
  }

  public boolean A()
  {
    return this.O;
  }

  private String E()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<player_distribution name=\"" + this.B + "\" ");
    localStringBuffer.append("no_limit=\"" + this.R.O() + "\" >");
    for (int i = 0; i < M(); i++)
    {
      localStringBuffer.append("<distribution engine=\"" + this.R.getValueAt(i, 1) + "\" ");
      localStringBuffer.append("bot_name=\"" + this.R.getValueAt(i, 2) + "\" ");
      localStringBuffer.append("value=\"" + this.P.get(i) + "\" />");
    }
    localStringBuffer.append("</player_distribution>");
    return localStringBuffer.toString();
  }

  public void D()
  {
    com.biotools.poker.E.H("Writing Distribution to Disk: " + G());
    if (C() != null)
      try
      {
        B.A(E().getBytes(), C());
      }
      catch (IOException localIOException)
      {
        d.A(localIOException);
      }
  }

  public void A(String paramString, boolean paramBoolean)
    throws Exception
  {
    if (paramString == null)
      return;
    com.biotools.poker.E.H("START: Loading Distribution from XML");
    DocumentBuilder localDocumentBuilder = null;
    DocumentBuilderFactory localDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
    try
    {
      localDocumentBuilder = localDocumentBuilderFactory.newDocumentBuilder();
    }
    catch (ParserConfigurationException localParserConfigurationException)
    {
      I.A(com.biotools.poker.E.D("TournamentDistroModel.CouldNotMakeXML"), localParserConfigurationException);
    }
    Document localDocument = null;
    try
    {
      synchronized (localDocumentBuilder)
      {
        localDocument = localDocumentBuilder.parse(new InputSource(new StringReader(paramString)));
      }
    }
    catch (Exception localException)
    {
    }
    if (localDocument == null)
      return;
    Element localElement1 = localDocument.getDocumentElement();
    if (localElement1 == null)
      return;
    A(localElement1.getAttribute("name"));
    A(Boolean.valueOf(localElement1.getAttribute("no_limit")).booleanValue());
    if (J() != paramBoolean)
      return;
    NodeList localNodeList = localElement1.getElementsByTagName("distribution");
    for (int i = 0; i < localNodeList.getLength(); i++)
    {
      Element localElement2 = (Element)localNodeList.item(i);
      String str1 = localElement2.getAttribute("engine");
      String str2 = localElement2.getAttribute("bot_name");
      Integer localInteger;
      try
      {
        localInteger = new Integer(localElement2.getAttribute("value"));
      }
      catch (NumberFormatException localNumberFormatException)
      {
        localInteger = new Integer(0);
      }
      A(str1, str2, localInteger);
    }
    this.O = true;
    com.biotools.poker.E.H("ENDDD: Loading Distribution from XML");
  }

  private void A(String paramString1, String paramString2, Integer paramInteger)
  {
    System.out.println("Adding new distribution: Engine: " + paramString1 + " Bot: " + paramString2 + " Value:" + paramInteger);
    if (paramString1.equalsIgnoreCase(K))
      this.R.V();
    else if (paramString2.equalsIgnoreCase(K))
      this.R.A(paramString1);
    else
      this.R.C(paramString1, paramString2);
    this.P.add(paramInteger);
    this.N += 1;
  }

  public void A(W paramW)
  {
    this.R = paramW.H();
    this.P = paramW.N();
    this.N = paramW.M();
    this.B = paramW.G();
    this.A = paramW.C();
    A(paramW.J());
  }

  private ArrayList N()
  {
    return this.P;
  }

  public void A(File paramFile, boolean paramBoolean)
  {
    try
    {
      A(b.A(paramFile), paramBoolean);
    }
    catch (Exception localException)
    {
      d.A(localException);
    }
    if (C() == null)
      A(paramFile);
  }

  public void D(File paramFile)
  {
    try
    {
      B.A(E().getBytes(), paramFile);
    }
    catch (IOException localIOException)
    {
      d.A(localIOException);
    }
  }

  public void B(File paramFile)
  {
    try
    {
      A(File.createTempFile("dtm", ".xml", paramFile));
    }
    catch (IOException localIOException)
    {
      d.A(localIOException);
    }
  }

  public void C(File paramFile)
  {
    File localFile = C();
    String str = localFile.getName();
    A(new File(paramFile, str));
    D();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.W
 * JD-Core Version:    0.6.2
 */