package com.biotools.poker.C;

import com.biotools.B.F;
import com.biotools.B.N;
import com.biotools.meerkat.Action;
import com.biotools.poker.E;
import com.biotools.poker.S.F.B;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.Date;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JViewport;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class K extends JPanel
{
  private com.biotools.poker.S.E.K D;
  private N B;
  private JLabel C = new F(0.5D, "<html> </html>");
  private _A A;

  public K()
  {
    this.C.setPreferredSize(new Dimension(200, 100));
    this.C.setBackground(Color.BLACK);
    this.C.setForeground(Color.WHITE);
    this.C.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    this.A = new _A();
    this.B = new N(this.A);
    this.B.getTableHeader().setReorderingAllowed(false);
    this.B.setEnabled(false);
    TableColumnModel localTableColumnModel = this.B.getColumnModel();
    DefaultTableCellRenderer localDefaultTableCellRenderer = new DefaultTableCellRenderer();
    localDefaultTableCellRenderer.setHorizontalAlignment(4);
    localTableColumnModel.getColumn(1).setCellRenderer(localDefaultTableCellRenderer);
    JScrollPane localJScrollPane = new JScrollPane(this.B);
    localJScrollPane.setPreferredSize(new Dimension(200, 120));
    localJScrollPane.getViewport().setBackground(Color.WHITE);
    setOpaque(false);
    setBackground(Color.WHITE);
    setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    setLayout(new GridLayout(1, 2, 4, 4));
    add(this.C, "West");
    add(localJScrollPane, "Center");
  }

  public com.biotools.poker.S.E.K A()
  {
    return this.D;
  }

  public void B(com.biotools.poker.S.E.K paramK)
  {
    this.D = paramK;
    if (paramK == null)
    {
      this.C.setText("<html><table width=" + (this.C.getWidth() - 10) + ">" + "<tr><td align=\"center\">" + "<i>" + E.D("RoomInfoPanel.NoRoomSelected") + "</i>" + "</td></tr></table></div></html>");
      this.A.fireTableDataChanged();
      return;
    }
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<html><div align=\"center\">");
    localStringBuffer.append("<table width=" + (this.C.getWidth() - 10) + ">");
    localStringBuffer.append("<tr><td align=\"center\">");
    localStringBuffer.append("<b><u>" + paramK.a() + "</u></b><br><br>");
    localStringBuffer.append(paramK.G() + " " + paramK.P() + "<br>");
    Object[] arrayOfObject1 = { new Integer(paramK.T()) };
    if (paramK.T() == 1)
      localStringBuffer.append(E.A("RoomInfoPanel.PlayerPattern", arrayOfObject1));
    else
      localStringBuffer.append(E.A("RoomInfoPanel.PlayersPattern", arrayOfObject1));
    Object[] arrayOfObject2 = { new Integer(paramK.R()) };
    if (paramK.R() == 1)
      localStringBuffer.append(E.A("RoomInfoPanel.ObserverPattern", arrayOfObject2));
    else
      localStringBuffer.append(E.A("RoomInfoPanel.ObserversPattern", arrayOfObject2));
    if ((paramK.K() != null) && (!paramK.K().equals("null")))
      localStringBuffer.append("<br><i>" + paramK.K() + "</i>");
    if (paramK.Q() > 0L)
    {
      long l = paramK.Q() - System.currentTimeMillis();
      if (l > 0L)
        localStringBuffer.append("<br><i>" + new Date(paramK.Q()) + "</i>");
    }
    localStringBuffer.append("</td></tr></table></div></html>");
    this.C.setText(localStringBuffer.toString());
    this.A.fireTableDataChanged();
  }

  private String A(com.biotools.poker.S.E.K paramK)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<table border=\"0\" cellspacing=1 cellpadding=1>");
    localStringBuffer.append("<tr bgcolor=\"black\" color=\"white\">");
    localStringBuffer.append("<td align=\"center\"><b>" + E.D("RoomInfoPanel.Seat") + "</b></td>");
    localStringBuffer.append("<td align=\"center\"><b>" + E.D("RoomInfoPanel.Name") + "</b></td>");
    localStringBuffer.append("<td align=\"center\"><b>" + E.D("RoomInfoPanel.Stack") + "</b></td>");
    localStringBuffer.append("<td align=\"center\"><b>" + E.D("RoomInfoPanel.Status") + "</b></td>");
    localStringBuffer.append("</tr>");
    if (paramK.U() != null)
      for (int i = 0; i < paramK.U().size(); i++)
      {
        B localB = (B)paramK.U().get(i);
        String str = i % 2 == 0 ? "eeeeff" : "#ffffff";
        localStringBuffer.append("<tr bgcolor=\"" + str + "\">");
        localStringBuffer.append("<td align=\"right\">&nbsp;" + (1 + localB.B()) + "&nbsp;</td>");
        localStringBuffer.append("<td>&nbsp;&nbsp;" + localB.E() + "&nbsp;&nbsp;</td>");
        localStringBuffer.append("<td align=\"right\">&nbsp;" + Action.formatCashFull(localB.D()) + "&nbsp;</td>");
        localStringBuffer.append("<td align=\"center\">&nbsp;" + localB.A() + "&nbsp;</td>");
        localStringBuffer.append("</tr>");
      }
    localStringBuffer.append("</table>");
    return localStringBuffer.toString();
  }

  public class _A extends AbstractTableModel
  {
    private static final int D = 0;
    private static final int B = 1;
    private static final int A = 2;
    private static final int C = 3;

    public _A()
    {
    }

    public int getRowCount()
    {
      if (K.this.D == null)
        return 0;
      return K.this.D.T();
    }

    public int getColumnCount()
    {
      return 2;
    }

    public B A(int paramInt)
    {
      if (K.this.D == null)
        return null;
      if (K.this.D.U() == null)
        return null;
      if (paramInt >= K.this.D.U().size())
        return null;
      return (B)K.this.D.U().get(paramInt);
    }

    public Object getValueAt(int paramInt1, int paramInt2)
    {
      B localB = A(paramInt1);
      if (localB != null)
        switch (paramInt2)
        {
        case 3:
          return new Integer(localB.B() + 1);
        case 0:
          return localB.E();
        case 1:
          if (localB.F() == 3)
            return E.D("Seat.SittingOut");
          if (localB.D() >= 0.0D)
            return Action.formatCashFull(localB.D());
          return E.D("NA");
        case 2:
          return localB.A();
        }
      return null;
    }

    public String getColumnName(int paramInt)
    {
      if (paramInt == 0)
        return E.D("RoomInfoPanel.Name");
      if (paramInt == 1)
        return E.D("RoomInfoPanel.Stack");
      if (paramInt == 3)
        return E.D("RoomInfoPanel.Seat");
      if (paramInt == 2)
        return E.D("RoomInfoPanel.Status");
      return "";
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.K
 * JD-Core Version:    0.6.2
 */