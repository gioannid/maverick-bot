package com.biotools.poker.C;

import com.biotools.poker.E;
import com.biotools.poker.PokerApp;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

public class Q extends JMenuBar
{
  private JMenu B = new JMenu(E.D("OnlineLobbyMenu.File"));
  private JMenu A = new JMenu(E.D("OnlineLobbyMenu.Help"));
  private A C;

  public Q(A paramA)
  {
    this.C = paramA;
    add(E());
    add(C());
  }

  protected JMenu E()
  {
    this.B.add(B());
    this.B.addSeparator();
    this.B.add(D());
    this.B.add(F());
    return this.B;
  }

  protected JMenu C()
  {
    this.A.add(A());
    return this.A;
  }

  protected KeyStroke A(int paramInt)
  {
    return KeyStroke.getKeyStroke(paramInt, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask());
  }

  protected JMenuItem B()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("OnlineLobbyMenu.Disconnect"), 68);
    localJMenuItem.setAccelerator(A(68));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        Q.this.C.Ĵ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem D()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("OnlineLobbyMenu.Close"), 67);
    localJMenuItem.setAccelerator(A(87));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        Q.this.C.ĺ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem F()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("OnlineLobbyMenu.QuitProgram"), 81);
    localJMenuItem.setAccelerator(A(81));
    localJMenuItem.setToolTipText(E.D("OnlineLobbyMenu.QuitProgramDescription"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        Q.this.C.ĺ();
        PokerApp.Ȅ().ʠ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem A()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("OnlineLobbyMenu.Help"), 72);
    localJMenuItem.setAccelerator(A(47));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        PokerApp.Ȅ().Ȗ();
      }
    });
    return localJMenuItem;
  }

  private void G()
  {
    setBorder(null);
    com.biotools.B.A.A(this);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.Q
 * JD-Core Version:    0.6.2
 */