package com.biotools.poker.C;

import java.awt.BorderLayout;
import javax.swing.JPanel;

public class N extends JPanel
{
  public N()
  {
    setLayout(new BorderLayout(6, 6));
    setOpaque(false);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.N
 * JD-Core Version:    0.6.2
 */