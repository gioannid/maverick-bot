package com.biotools.poker.C;

import com.biotools.B.K;
import com.biotools.poker.A;
import com.biotools.poker.E;
import com.biotools.poker.F.J;
import com.biotools.poker.F.O;
import com.biotools.poker.O.M;
import com.biotools.poker.PokerApp;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JPanel;

public class P extends JPanel
  implements MouseListener, MouseMotionListener
{
  private static final File R = E.K("pix/lobby/lobby_main.png");
  private static final File F = E.K("pix/lobby/compact_lobby_main.png");
  private static final File K = E.K("pix/lobby/lobby_main_std.png");
  private static final File U = E.K("pix/lobby/compact_lobby_main_std.png");
  private static final String B = "pix/lobby/";
  private Image J;
  private PokerApp I;
  private JButton M;
  private ArrayList Q = new ArrayList();
  private O L;
  private O O;
  private O G;
  private O N;
  private O T;
  private O C;
  private O S;
  private O P;
  private O H;
  private O D;
  int A = 0;
  int E = 0;

  public P(PokerApp paramPokerApp)
  {
    this.I = paramPokerApp;
    setLayout(null);
    addMouseListener(this);
    addMouseMotionListener(this);
    addComponentListener(new ComponentAdapter()
    {
      public void componentShown(ComponentEvent paramAnonymousComponentEvent)
      {
        P.this.A().setVisible(PokerApp.Ȅ().ɕ());
      }
    });
    add(A());
    File localFile = E.Ð() ? F : R;
    if (E.Ú())
      localFile = E.Ð() ? U : K;
    this.J = A(localFile);
    this.L = new O(null, E.K("pix/lobby/01-ring_games.png"), PokerApp.Ȅ());
    this.L.A(G.g);
    this.Q.add(this.L);
    this.L.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        P.this.I.ȍ();
      }
    });
    this.O = new O(null, E.K("pix/lobby/02-tournaments.png"), PokerApp.Ȅ());
    this.O.A(G.m);
    this.Q.add(this.O);
    this.O.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        P.this.I.ʇ();
      }
    });
    this.G = new O(null, E.K("pix/lobby/03-poker_academy_online.png"), PokerApp.Ȅ());
    this.G.A(G.D);
    this.Q.add(this.G);
    this.G.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        P.this.I.ʟ();
      }
    });
    if (!E.Ú())
    {
      this.N = new O(null, E.K("pix/lobby/04-hand_evaluator.png"), PokerApp.Ȅ());
      this.N.A(G.n);
      this.Q.add(this.N);
      this.N.B(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          P.this.I.ɛ();
        }
      });
      this.C = new O(null, E.K("pix/lobby/05-showdown_calculator.png"), PokerApp.Ȅ());
      this.C.A(G.P);
      this.Q.add(this.C);
      this.C.B(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          P.this.I.ɥ();
        }
      });
    }
    else
    {
      this.S = new O(null, E.K("pix/lobby/11-tournament_clock.png"), PokerApp.Ȅ());
      this.S.A(G.R);
      this.Q.add(this.S);
      this.S.B(new P.7(this));
      this.C = new O(null, E.K("pix/lobby/12-showdown_calc.png"), PokerApp.Ȅ());
      this.C.A(G.C);
      this.Q.add(this.C);
      this.C.B(new P.8(this));
    }
    this.T = new O(null, E.K("pix/lobby/06-player_statistics.png"), PokerApp.Ȅ());
    this.T.A(G.O);
    this.Q.add(this.T);
    this.T.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        P.this.I.ɹ();
      }
    });
    this.P = new O(null, E.K("pix/lobby/07-help_manual.png"), PokerApp.Ȅ());
    this.P.A(G.u);
    this.Q.add(this.P);
    this.P.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        P.this.I.Ȗ();
      }
    });
    this.H = new O(null, E.K("pix/lobby/08-tutorial.png"), PokerApp.Ȅ());
    this.H.A(G.q);
    this.Q.add(this.H);
    this.H.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        P.this.I.ɚ();
      }
    });
    this.D = new O(null, E.K("pix/lobby/09-about_poker_academy.png"), PokerApp.Ȅ());
    this.D.A(G.s);
    this.Q.add(this.D);
    this.D.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        P.this.I.ɧ();
      }
    });
    setBackground(Color.BLACK);
  }

  public void update(Graphics paramGraphics)
  {
  }

  public void paintComponent(Graphics paramGraphics)
  {
    paramGraphics.translate(this.A, this.E);
    paramGraphics.drawImage(this.J, 0, 0, null);
    Graphics2D localGraphics2D = (Graphics2D)paramGraphics;
    for (int i = 0; i < this.Q.size(); i++)
    {
      J localJ = (J)this.Q.get(i);
      localJ.I(localGraphics2D);
    }
  }

  private Image A(File paramFile)
  {
    return PokerApp.Ȅ().ʋ().Ǩ().B(paramFile);
  }

  public void mouseReleased(MouseEvent paramMouseEvent)
  {
    for (int i = 0; i < this.Q.size(); i++)
    {
      J localJ = (J)this.Q.get(i);
      if (localJ.E(paramMouseEvent.getX() - this.A, paramMouseEvent.getY() - this.E))
        repaint();
    }
  }

  public void mouseMoved(MouseEvent paramMouseEvent)
  {
    for (int i = 0; i < this.Q.size(); i++)
    {
      J localJ = (J)this.Q.get(i);
      if (localJ.G(paramMouseEvent.getX() - this.A, paramMouseEvent.getY() - this.E))
        repaint(5L);
    }
  }

  public void mouseDragged(MouseEvent paramMouseEvent)
  {
    for (int i = 0; i < this.Q.size(); i++)
    {
      J localJ = (J)this.Q.get(i);
      if (localJ.G(paramMouseEvent.getX() - this.A, paramMouseEvent.getY() - this.E))
        repaint(5L);
    }
  }

  public void mouseClicked(MouseEvent paramMouseEvent)
  {
  }

  public void mouseEntered(MouseEvent paramMouseEvent)
  {
  }

  public void mouseExited(MouseEvent paramMouseEvent)
  {
  }

  public void mousePressed(MouseEvent paramMouseEvent)
  {
    for (int i = 0; i < this.Q.size(); i++)
    {
      J localJ = (J)this.Q.get(i);
      if (localJ.I(paramMouseEvent.getX() - this.A, paramMouseEvent.getY() - this.E))
        repaint();
    }
  }

  protected JButton A()
  {
    if (this.M == null)
    {
      this.M = new K("resume-game.png", E.D("FrontPage.ResumeGameToolTip"));
      this.M.setVisible(false);
      this.M.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          PokerApp.Ȅ().ʎ();
        }
      });
      this.M.setBounds(G.S.x, G.S.y, 158, 33);
    }
    return this.M;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.P
 * JD-Core Version:    0.6.2
 */