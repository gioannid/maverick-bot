package com.biotools.poker.C;

import com.biotools.meerkat.Action;
import java.text.DecimalFormat;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class E extends JPanel
{
  private JLabel F;
  private double B = -1.0D;
  private double A = -1.0D;
  private long D = -1L;
  public static final DecimalFormat G = new DecimalFormat(com.biotools.poker.E.D("OnlineAccount.DecimalFormat"));
  private static final int C = 3600000;
  private static final int E = 60000;

  public E()
  {
    setLayout(new BoxLayout(this, 0));
    setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    add(Box.createHorizontalGlue());
    add(A());
    add(Box.createHorizontalGlue());
  }

  public double G()
  {
    return this.B;
  }

  public void A(double paramDouble1, double paramDouble2, long paramLong)
  {
    this.B = paramDouble1;
    this.A = paramDouble2;
    this.D = paramLong;
    A().setText(B());
  }

  private JLabel A()
  {
    if (this.F == null)
      this.F = new JLabel(B(), 0);
    return this.F;
  }

  private String F()
  {
    double d = this.B + this.A;
    if (d >= 0.0D)
      return Action.formatCash(d);
    return "<i>" + com.biotools.poker.E.D("OnlineAccount.Unknown") + "</i>";
  }

  private String E()
  {
    if (this.B >= 0.0D)
      return Action.formatCash(this.B);
    return "<i>" + com.biotools.poker.E.D("OnlineAccount.Unknown") + "</i>";
  }

  private String D()
  {
    if (this.A >= 0.0D)
      return Action.formatCash(this.A);
    return "<i>" + com.biotools.poker.E.D("OnlineAccount.Unknown") + "</i>";
  }

  private String C()
  {
    if ((this.A == 0.0D) && (this.D > 0L))
    {
      String str = null;
      int i = (int)(this.D / 3600000L);
      this.D -= 3600000 * i;
      int j = (int)(this.D / 60000L);
      Object[] arrayOfObject;
      if (i == 0)
      {
        if (j == 0)
        {
          str = com.biotools.poker.E.D("OnlineAccount.PaxResetUnderMinute");
        }
        else
        {
          arrayOfObject = new Object[] { G.format(j) };
          str = com.biotools.poker.E.A("OnlineAccount.PaxResetMinutesPattern", arrayOfObject);
        }
      }
      else
      {
        arrayOfObject = new Object[] { G.format(i), G.format(j) };
        str = com.biotools.poker.E.A("OnlineAccount.PaxResetHourMinutesPattern", arrayOfObject);
      }
      return str;
    }
    return "";
  }

  private String B()
  {
    return "<html><div align=center><b>" + com.biotools.poker.E.D("OnlineAccount.PAXTitle") + "</b>" + "<br>" + E() + "<br>" + "<br>" + "<b>" + com.biotools.poker.E.D("OnlineAccount.PaxInPlayTitle") + "</b>" + "<br>" + D() + "<br>" + "<hr>" + "<br>" + "<b>" + com.biotools.poker.E.D("OnlineAccount.TotalPaxTitle") + "</b>" + "<br>" + F() + "<br><br>" + C() + "</html>";
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.E
 * JD-Core Version:    0.6.2
 */