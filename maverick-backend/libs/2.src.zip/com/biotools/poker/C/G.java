package com.biotools.poker.C;

import com.biotools.poker.E;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.ResourceBundle;

public class G
{
  private static final Point k = A("Poker.Lobby.Coords.FP_PlayRing_full");
  private static final Point f = A("Poker.Lobby.Coords.FP_PlayTourney_full");
  private static final Point o = A("Poker.Lobby.Coords.FP_PlayOnline_full");
  private static final Point a = A("Poker.Lobby.Coords.FP_HandEval_full");
  private static final Point H = A("Poker.Lobby.Coords.FP_Showdown_full");
  private static final Point V = A("Poker.Lobby.Coords.FP_Stats_full");
  private static final Point x = A("Poker.Lobby.Coords.FP_Help_full");
  private static final Point p = A("Poker.Lobby.Coords.FP_Tutorial_full");
  private static final Point i = A("Poker.Lobby.Coords.FP_About_full");
  private static final Point w = A("Poker.Lobby.Coords.FP_TourneyClock_full");
  private static final Point J = A("Poker.Lobby.Coords.FP_ShowdownCalc_full");
  private static final Point v = A("Poker.Lobby.Coords.FP_Compact_Translate");
  private static ResourceBundle K = E.i();
  private static final Rectangle Q = (Rectangle)K.getObject("Poker.Lobby.Coords.G_LeftBox_full");
  private static final Rectangle F = (Rectangle)K.getObject("Poker.Lobby.Coords.G_RightBox_full");
  public static Point D;
  public static Point m;
  public static Point g;
  public static Point n;
  public static Point P;
  public static Point O;
  public static Point u;
  public static Point q;
  public static Point s;
  public static Point R;
  public static Point C;
  private static final Point t = A("Poker.Lobby.Coords.G_Cancel_full");
  private static final Point X = A("Poker.Lobby.Coords.G_MainLobby_full");
  private static final Point G = A("Poker.Lobby.Coords.G_RingGames_full");
  private static final Point Y = A("Poker.Lobby.Coords.G_Tourneys_full");
  private static final Point b = A("Poker.Lobby.Coords.G_Onine_full");
  private static final Point M = A("Poker.Lobby.Coords.G_Profile_full");
  private static final Point W = A("Poker.Lobby.Coords.G_StartGame_full");
  private static final Point A = A("Poker.Lobby.Coords.G_Cancel_comp");
  private static final Point c = A("Poker.Lobby.Coords.G_MainLobby_comp");
  private static final Point L = A("Poker.Lobby.Coords.G_RingGames_comp");
  private static final Point e = A("Poker.Lobby.Coords.G_Tourneys_comp");
  private static final Point h = A("Poker.Lobby.Coords.G_Onine_comp");
  private static final Point T = A("Poker.Lobby.Coords.G_Profile_comp");
  private static final Point _ = A("Poker.Lobby.Coords.G_StartGame_comp");
  private static final Rectangle U = (Rectangle)K.getObject("Poker.Lobby.Coords.G_LeftBox_comp");
  private static final Rectangle I = (Rectangle)K.getObject("Poker.Lobby.Coords.G_RightBox_comp");
  public static Point S;
  public static Point N;
  public static Point r;
  public static Point B;
  public static Point d;
  public static Point j;
  public static Point l;
  public static Rectangle Z;
  public static Rectangle E;

  public static void A(boolean paramBoolean)
  {
    D = o;
    m = f;
    g = k;
    n = a;
    P = H;
    O = V;
    u = x;
    q = p;
    s = i;
    R = w;
    C = J;
    if (paramBoolean)
    {
      Point localPoint = v;
      D.translate(localPoint.x, localPoint.y);
      m.translate(localPoint.x, localPoint.y);
      g.translate(localPoint.x, localPoint.y);
      n.translate(localPoint.x, localPoint.y);
      P.translate(localPoint.x, localPoint.y);
      O.translate(localPoint.x, localPoint.y);
      u.translate(localPoint.x, localPoint.y);
      q.translate(localPoint.x, localPoint.y);
      s.translate(localPoint.x, localPoint.y);
      R.translate(localPoint.x, localPoint.y);
      C.translate(localPoint.x, localPoint.y);
    }
    S = paramBoolean ? A : t;
    N = paramBoolean ? c : X;
    r = paramBoolean ? L : G;
    B = paramBoolean ? e : Y;
    d = paramBoolean ? h : b;
    j = paramBoolean ? T : M;
    l = paramBoolean ? _ : W;
    Z = paramBoolean ? U : Q;
    E = paramBoolean ? I : F;
  }

  private static Point A(String paramString)
  {
    Integer localInteger1 = Integer.valueOf(E.D(paramString + "_X"));
    Integer localInteger2 = Integer.valueOf(E.D(paramString + "_Y"));
    return new Point(localInteger1.intValue(), localInteger2.intValue());
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.G
 * JD-Core Version:    0.6.2
 */