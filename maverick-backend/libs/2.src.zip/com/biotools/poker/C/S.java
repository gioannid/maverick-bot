package com.biotools.poker.C;

import com.biotools.poker.S.E.K;

public abstract interface S
{
  public abstract void A(K paramK, boolean paramBoolean);
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.S
 * JD-Core Version:    0.6.2
 */