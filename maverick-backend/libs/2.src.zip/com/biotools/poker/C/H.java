package com.biotools.poker.C;

import com.biotools.A.I;
import com.biotools.B.L;
import com.biotools.B.N;
import com.biotools.meerkat.util.Preferences;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;
import javax.swing.JViewport;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

public class H extends JPanel
{
  protected W D;
  protected N Y;
  private Vector R = new Vector();
  private Vector W;
  private JToolBar N;
  private JToolBar T;
  protected JButton O;
  protected JButton J;
  protected JButton E;
  protected JButton M;
  protected JButton G;
  protected JButton P;
  protected JButton C;
  private JLabel Q;
  private JPanel U;
  private JScrollPane B;
  protected JComboBox S;
  protected DefaultComboBoxModel X;
  protected boolean Z = true;
  private int H;
  private int L;
  private final String F = "limit_selected_item";
  private final String V = "nolimit_selected_item";
  protected int I = 0;
  private int[] A = { 20, 20, 20 };
  public static final Color K = new Color(20, 160, 0);

  public H()
  {
    setLayout(new BorderLayout(5, 2));
    setBorder(L.B(3));
    add(d(), "East");
    add(V(), "Center");
    add(T(), "South");
    add(Z(), "West");
    add(g(), "North");
  }

  private JToolBar d()
  {
    if (this.N == null)
    {
      this.N = new JToolBar(1);
      this.N.setRollover(true);
      this.N.setFloatable(false);
      this.N.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
      this.N.addSeparator(new Dimension(0, 50));
      this.N.add(G());
      this.N.add(W());
    }
    return this.N;
  }

  private JPanel Z()
  {
    if (this.U == null)
    {
      JLabel localJLabel = new JLabel("<html><table><tr><td valign=\"top\">" + com.biotools.poker.E.D("TournamentDistroPanel.SetPercentagesDescription") + "</td></tr></table></html>");
      localJLabel.setPreferredSize(new Dimension(170, 400));
      localJLabel.setFont(localJLabel.getFont().deriveFont(10.0F));
      this.U = new JPanel(new BorderLayout());
      this.U.setBorder(L.A(BorderFactory.createBevelBorder(1), 6));
      this.U.add(localJLabel, "Center");
    }
    return this.U;
  }

  public JScrollPane V()
  {
    if (this.B == null)
    {
      this.Y = new N(C())
      {
        public Component prepareRenderer(TableCellRenderer paramAnonymousTableCellRenderer, int paramAnonymousInt1, int paramAnonymousInt2)
        {
          Component localComponent = super.prepareRenderer(paramAnonymousTableCellRenderer, paramAnonymousInt1, paramAnonymousInt2);
          localComponent.setForeground(Color.BLACK);
          if (H.this.D.K() < 100)
            localComponent.setForeground(H.K);
          else if (H.this.D.K() > 100)
            localComponent.setForeground(Color.RED);
          return localComponent;
        }
      };
      this.Y.getTableHeader().setReorderingAllowed(false);
      this.Y.getSelectionModel().addListSelectionListener(new ListSelectionListener()
      {
        public void valueChanged(ListSelectionEvent paramAnonymousListSelectionEvent)
        {
          ListSelectionModel localListSelectionModel = (ListSelectionModel)paramAnonymousListSelectionEvent.getSource();
          H.this.W().setEnabled(!localListSelectionModel.isSelectionEmpty());
        }
      });
      this.Y.addMouseListener(new MouseAdapter()
      {
        public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
        {
          int i = H.this.Y.getSelectedRow();
          if (paramAnonymousMouseEvent.getButton() == 3)
          {
            i = H.this.Y.rowAtPoint(paramAnonymousMouseEvent.getPoint());
            if (i > 0)
              H.this.Y.getSelectionModel().setSelectionInterval(i, i);
          }
          if (H.this.Y.getSelectedColumn() != 2)
            H.this.A(H.this.Y.getSelectedRow(), paramAnonymousMouseEvent.getX(), paramAnonymousMouseEvent.getY());
        }
      });
      this.Y.addPropertyChangeListener(new PropertyChangeListener()
      {
        public void propertyChange(PropertyChangeEvent paramAnonymousPropertyChangeEvent)
        {
          H.this.P();
        }
      });
      this.B = new JScrollPane(this.Y);
      this.Y.setPreferredScrollableViewportSize(new Dimension(160, 180));
      this.Y.setSelectionMode(0);
      this.B.getViewport().setBackground(Color.WHITE);
      S();
    }
    return this.B;
  }

  private JLabel T()
  {
    if (this.Q == null)
      this.Q = new JLabel("", 0);
    P();
    return this.Q;
  }

  private JToolBar g()
  {
    if (this.T == null)
    {
      this.T = new JToolBar(0);
      this.T.setRollover(true);
      this.T.setFloatable(false);
      this.T.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
      this.T.add(a());
      this.T.add(X());
      this.T.add(N());
      this.T.addSeparator();
      this.T.add(B());
      this.T.addSeparator();
      this.T.add(D());
      this.T.add(Q());
    }
    return this.T;
  }

  private JComboBox B()
  {
    if (this.S == null)
    {
      this.S = new JComboBox();
      this.S.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          if (H.this.S.getSelectedIndex() >= 0)
            H.this.c();
          H.this.D.fireTableDataChanged();
        }
      });
      I();
      this.S.setToolTipText(com.biotools.poker.E.D("TournamentDistroPanel.SelectPlayerDistribution"));
    }
    return this.S;
  }

  private JButton a()
  {
    if (this.E == null)
    {
      this.E = new com.biotools.B.J("add.png", com.biotools.poker.E.D("TournamentDistroPanel.AddDistributionToolTip"));
      this.E.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          H.this.R();
        }
      });
    }
    return this.E;
  }

  private JButton X()
  {
    if (this.G == null)
    {
      this.G = new com.biotools.B.J("del.png", com.biotools.poker.E.D("TournamentDistroPanel.DeleteDistributionToolTip"));
      this.G.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          H.this.A();
        }
      });
    }
    return this.G;
  }

  private JButton N()
  {
    if (this.M == null)
    {
      this.M = new com.biotools.B.J("save.png", com.biotools.poker.E.D("TournamentDistroPanel.SaveDistributionAsToolTip"));
      this.M.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          H.this.f();
        }
      });
    }
    return this.M;
  }

  private JButton G()
  {
    if (this.O == null)
    {
      this.O = new com.biotools.B.J("plus.png", com.biotools.poker.E.D("TournamentDistroPanel.AddNewRowToolTip"));
      this.O.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          H.this.H();
        }
      });
    }
    return this.O;
  }

  private JButton W()
  {
    if (this.J == null)
    {
      this.J = new com.biotools.B.J("minus.png", com.biotools.poker.E.D("TournamentDistroPanel.MinusRowToolTip"));
      this.J.setEnabled(false);
      this.J.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          H.this.F();
        }
      });
    }
    return this.J;
  }

  private JButton D()
  {
    if (this.P == null)
    {
      this.P = new com.biotools.B.J("import.png", com.biotools.poker.E.D("TournamentDistroPanel.ImportToolTip"));
      this.P.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          H.this.J();
        }
      });
    }
    return this.P;
  }

  private JButton Q()
  {
    if (this.C == null)
    {
      this.C = new com.biotools.B.J("export.png", com.biotools.poker.E.D("TournamentDistroPanel.ExportToolTip"));
      this.C.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          H.this.M();
        }
      });
    }
    return this.C;
  }

  private AbstractTableModel C()
  {
    if (this.D == null)
    {
      this.D = new W();
      this.D.O();
    }
    return this.D;
  }

  private void S()
  {
    String[] arrayOfString = { com.biotools.poker.E.D("TournamentDistroPanel.ClickTournamentBot"), com.biotools.poker.E.D("TournamentDistroPanel.ClickTournamentBot"), com.biotools.poker.E.D("TournamentDistroPanel.DoubleClickToEdit") };
    TableColumnModel localTableColumnModel = this.Y.getColumnModel();
    assert (localTableColumnModel.getColumnCount() == arrayOfString.length);
    for (int i = 0; i < localTableColumnModel.getColumnCount(); i++)
    {
      DefaultTableCellRenderer localDefaultTableCellRenderer = new DefaultTableCellRenderer();
      localDefaultTableCellRenderer.setHorizontalAlignment(0);
      if (i > 0)
        localDefaultTableCellRenderer.setToolTipText(arrayOfString[i]);
      TableColumn localTableColumn = localTableColumnModel.getColumn(i);
      localTableColumn.setCellRenderer(localDefaultTableCellRenderer);
      localTableColumn.setPreferredWidth(this.A[i]);
    }
  }

  private void P()
  {
    int i = this.D.K();
    if (i == 100)
    {
      this.Q.setForeground(Color.BLACK);
      this.Q.setText(com.biotools.poker.E.D("TournamentDistroPanel.PercentAllocatedTitle") + i + "%");
    }
    else
    {
      int j;
      Object[] arrayOfObject;
      if (i < 100)
      {
        j = 100 - i;
        this.Q.setForeground(Color.RED);
        arrayOfObject = new Object[] { new Integer(i), new Integer(j) };
        this.Q.setText(com.biotools.poker.E.A("TournamentDistroPanel.PercentAllocatedRemainingPattern", arrayOfObject));
      }
      else
      {
        this.Q.setForeground(Color.RED);
        j = i - 100;
        arrayOfObject = new Object[] { new Integer(i), new Integer(j) };
        this.Q.setText(com.biotools.poker.E.A("TournamentDistroPanel.PercentAllocatedExtraPattern", arrayOfObject));
      }
    }
  }

  public com.biotools.poker.E.E E()
  {
    return this.D.H();
  }

  public boolean U()
  {
    return this.Z;
  }

  public void A(boolean paramBoolean)
  {
    if (U() != paramBoolean)
    {
      e();
      this.Z = paramBoolean;
      this.W = null;
      I();
      P();
    }
    this.D.A(paramBoolean);
  }

  private Vector b()
  {
    if (this.W == null)
      this.W = O();
    return this.W;
  }

  private Vector O()
  {
    ArrayList localArrayList = com.biotools.poker.E.B.B(com.biotools.poker.E.Ì());
    Vector localVector = new Vector();
    for (int i = 0; i < localArrayList.size(); i++)
    {
      com.biotools.poker.E.B localB = (com.biotools.poker.E.B)localArrayList.get(i);
      if ((localB.B() == this.D.H().O()) && (!localB.G()))
        localVector.add(localB.C());
    }
    return localVector;
  }

  private Vector B(String paramString)
  {
    Vector localVector = new Vector();
    if (!paramString.equals("RANDOM"))
      for (int i = 0; i < com.biotools.poker.E.B.N().size(); i++)
      {
        com.biotools.poker.E.B localB = (com.biotools.poker.E.B)com.biotools.poker.E.B.N().get(i);
        if (localB.C().equals(paramString))
          localVector.add(localB);
      }
    return localVector;
  }

  private JPopupMenu B(int paramInt)
  {
    if (this.D.H() == null)
      return null;
    JPopupMenu localJPopupMenu = new JPopupMenu();
    localJPopupMenu.add(B(com.biotools.poker.E.D("TournamentDistroPanel.Random"), paramInt));
    localJPopupMenu.addSeparator();
    for (int i = 0; i < b().size(); i++)
    {
      String str = (String)b().get(i);
      if (str != null)
        localJPopupMenu.add(A((String)b().get(i), paramInt));
    }
    return localJPopupMenu;
  }

  private JMenuItem A(String paramString, int paramInt)
  {
    int i = 20;
    JMenu localJMenu = new JMenu(paramString);
    Vector localVector = B(paramString);
    if (localVector.size() > 0)
    {
      localJMenu.add(A(paramString, com.biotools.poker.E.D("TournamentDistroPanel.Random"), paramInt));
      localJMenu.addSeparator();
      int j;
      if (localVector.size() > i)
      {
        j = 0;
        while (j < localVector.size())
        {
          localJMenu.add(A(localVector, j, i, paramString, paramInt));
          j += i;
        }
      }
      else
      {
        for (j = 0; j < localVector.size(); j++)
          localJMenu.add(A(paramString, localVector.get(j).toString(), paramInt));
      }
    }
    return localJMenu;
  }

  public JMenuItem A(List paramList, int paramInt1, int paramInt2, String paramString, int paramInt3)
  {
    StringBuffer localStringBuffer1 = new StringBuffer();
    int i = paramInt1 + paramInt2 - 1;
    if (i >= paramList.size())
      i = paramList.size() - 1;
    StringBuffer localStringBuffer2 = new StringBuffer(paramList.get(paramInt1).toString());
    StringBuffer localStringBuffer3 = new StringBuffer(paramList.get(i).toString());
    localStringBuffer1.append(localStringBuffer2.substring(0, 1).toUpperCase() + " - " + localStringBuffer3.substring(0, 1).toUpperCase());
    JMenu localJMenu = new JMenu(localStringBuffer1.toString());
    for (int j = paramInt1; j <= i; j++)
      localJMenu.add(A(paramString, paramList.get(j).toString(), paramInt3));
    return localJMenu;
  }

  private JMenuItem B(String paramString, int paramInt)
  {
    JMenuItem localJMenuItem = new JMenuItem(paramString);
    localJMenuItem.addActionListener(new H.13(this, paramInt));
    return localJMenuItem;
  }

  private JMenuItem A(String paramString1, String paramString2, int paramInt)
  {
    JMenuItem localJMenuItem = new JMenuItem(paramString2);
    localJMenuItem.addActionListener(new H.14(this, paramInt, paramString1));
    return localJMenuItem;
  }

  private void A(int paramInt, String paramString)
  {
    if (paramString.equals(com.biotools.poker.E.D("TournamentDistroPanel.Random")))
      this.D.H().A(paramInt);
    else
      for (int i = 0; i < com.biotools.poker.E.B.N().size(); i++)
      {
        com.biotools.poker.E.B localB = (com.biotools.poker.E.B)com.biotools.poker.E.B.N().get(i);
        if (localB.J().equals(paramString))
          this.D.H().A(paramInt, localB);
      }
  }

  private void A(int paramInt1, int paramInt2, int paramInt3)
  {
    JPopupMenu localJPopupMenu = B(this.Y.getSelectedRow());
    if (localJPopupMenu != null)
      localJPopupMenu.show(this.Y, paramInt2, paramInt3);
  }

  public com.biotools.poker.E.E A(int paramInt)
  {
    this.I = paramInt;
    e();
    return this.D.B(paramInt);
  }

  public void L()
  {
    this.D.F();
  }

  private File Y()
  {
    File localFile = new File(com.biotools.poker.E.n(), "distributions");
    if (!localFile.exists())
    {
      try
      {
        com.biotools.A.B.A(com.biotools.poker.E.K("logs/distributions"), localFile);
      }
      catch (IOException localIOException)
      {
        I.A(localFile + " is missing.", localIOException);
      }
      if (!localFile.exists())
        I.A(localFile + " is missing.", new FileNotFoundException());
    }
    return localFile;
  }

  private void I()
  {
    if (this.X == null)
      this.X = new DefaultComboBoxModel();
    this.X.removeAllElements();
    File localFile = Y();
    File[] arrayOfFile = localFile.listFiles();
    Object localObject = new W();
    if (arrayOfFile != null)
      for (int i = 0; i < arrayOfFile.length; i++)
        if ((arrayOfFile[i] != null) && (arrayOfFile[i].getName().endsWith(".xml")))
        {
          W localW = new W();
          localW.A(arrayOfFile[i], U());
          if (localW.A())
          {
            A(localW);
            if (localW.G().equals(com.biotools.poker.E.D("TournamentDistroPanel.Random")))
              localObject = localW;
          }
        }
    this.X.setSelectedItem(localObject);
    this.S.setModel(this.X);
    K();
    c();
  }

  private void c()
  {
    int i = this.S.getSelectedIndex();
    if ((i >= 0) && (i < this.S.getItemCount()))
    {
      this.D.A((W)this.S.getSelectedItem());
      X().setEnabled(true);
    }
    else
    {
      A(A(com.biotools.poker.E.D("TournamentDistroPanel.InitialDistribution")));
      c();
      X().setEnabled(false);
    }
    P();
  }

  private void R()
  {
    String str = JOptionPane.showInputDialog(this, com.biotools.poker.E.D("TournamentDistroPanel.UntitledStructureDescription"), com.biotools.poker.E.D("TournamentDistroPanel.UntitledStructure"));
    if (str != null)
    {
      W localW = A(str);
      localW.A(U());
      localW.D();
      A(localW);
      c();
    }
  }

  private W A(String paramString)
  {
    W localW = new W();
    localW.I();
    localW.B(Y());
    localW.A(paramString);
    localW.D();
    return localW;
  }

  private void A()
  {
    Object[] arrayOfObject = { this.D.G() };
    int i = JOptionPane.showConfirmDialog(this, com.biotools.poker.E.A("TournamentDistroPanel.DeleteDistrubutionDescriptionPattern", arrayOfObject), com.biotools.poker.E.D("TournamentDistroPanel.DeleteDistrubution"), 0);
    if (i == 0)
    {
      this.D.C().delete();
      this.X.removeElement(this.X.getSelectedItem());
      if (this.S.getItemCount() > 0)
        this.S.setSelectedIndex(0);
      c();
    }
  }

  private void f()
  {
    String str = JOptionPane.showInputDialog(this, com.biotools.poker.E.D("TournamentDistroPanel.SaveDistributionAs"), this.D.G());
    if (str != null)
      if (str.equalsIgnoreCase(this.D.G()))
      {
        _();
      }
      else
      {
        W localW = new W();
        localW.A(this.D);
        localW.A(str);
        localW.B(Y());
        A(localW);
        localW.D();
      }
  }

  private void H()
  {
    int i = this.Y.getRowCount();
    this.D.E(i);
    this.Y.setRowSelectionInterval(i, i);
    if (i < 0)
      S();
    W().setEnabled(true);
    P();
  }

  private void F()
  {
    int i = this.Y.getSelectedRow();
    this.D.A(i);
    if (i == this.Y.getRowCount())
      i--;
    if (i >= 0)
      this.Y.setRowSelectionInterval(i, i);
    if (this.D.M() <= 0)
      W().setEnabled(false);
    P();
  }

  private void _()
  {
    this.D.D();
  }

  private void e()
  {
    _();
    if (U())
      com.biotools.poker.E.£().putInt("nolimit_selected_item", this.S.getSelectedIndex());
    else
      com.biotools.poker.E.£().putInt("limit_selected_item", this.S.getSelectedIndex());
  }

  private void K()
  {
    int i;
    if (U())
      i = com.biotools.poker.E.£().getInt("nolimit_selected_item", 0);
    else
      i = com.biotools.poker.E.£().getInt("limit_selected_item", 0);
    if ((i >= 0) && (i < this.S.getItemCount()))
      this.S.setSelectedIndex(i);
  }

  public void J()
  {
    JFileChooser localJFileChooser = new JFileChooser();
    localJFileChooser.setFileFilter(new com.biotools.A.J());
    if (localJFileChooser.showOpenDialog(this) == 0)
    {
      File localFile = localJFileChooser.getSelectedFile();
      if (localFile != null)
      {
        W localW = new W();
        localW.A(localFile, U());
        if (localW.A())
        {
          A(localW);
          c();
          localW.C(Y());
        }
        else
        {
          JOptionPane.showMessageDialog(this, com.biotools.poker.E.D("TournamentDistroPanel.ErrorBadXML"), com.biotools.poker.E.D("TournamentDistroPanel.ErrorImportingDistribution"), 0);
        }
      }
    }
  }

  public void M()
  {
    e();
    if (this.D != null)
    {
      JFileChooser localJFileChooser = new JFileChooser();
      localJFileChooser.setFileFilter(new com.biotools.A.J());
      localJFileChooser.setSelectedFile(new File(this.D.G() + ".xml"));
      if (localJFileChooser.showSaveDialog(this) == 0)
      {
        File localFile = localJFileChooser.getSelectedFile();
        if (localFile != null)
          this.D.D(localFile);
      }
    }
  }

  private void A(W paramW)
  {
    if ((paramW != null) && (paramW.J() == U()))
    {
      this.X.addElement(paramW);
      this.S.setSelectedIndex(this.S.getItemCount() - 1);
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.H
 * JD-Core Version:    0.6.2
 */