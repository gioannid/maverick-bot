package com.biotools.poker.C;

import com.biotools.poker.E;
import com.biotools.poker.S.E.K;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class B extends AbstractTableModel
{
  public static final int H = 0;
  public static final int F = 1;
  public static final int A = 2;
  public static final int D = 3;
  public static final String[] G = { E.D("RoomTableModel.RoomName"), E.D("RoomTableModel.Type"), E.D("RoomTableModel.Stakes"), E.D("RoomTableModel.Players") };
  private List E;
  private boolean C = false;
  private int B = 3;

  public B(List paramList)
  {
    this.E = paramList;
  }

  public void B()
  {
    this.E.clear();
    fireTableDataChanged();
  }

  public void A(K paramK)
  {
    for (int i = 0; i < this.E.size(); i++)
    {
      K localK = (K)this.E.get(i);
      if (localK.a().equals(paramK.a()))
      {
        this.E.set(i, paramK);
        fireTableRowsUpdated(i, i);
        A();
        return;
      }
    }
    this.E.add(paramK);
    fireTableRowsInserted(this.E.size() - 1, this.E.size() - 1);
    A();
  }

  public void B(K paramK)
  {
    this.E.remove(paramK);
    fireTableDataChanged();
  }

  public K A(String paramString)
  {
    for (int i = 0; i < getRowCount(); i++)
    {
      K localK = C(i);
      if ((localK != null) && (localK.a().equals(paramString)))
        return localK;
    }
    return null;
  }

  public boolean C(K paramK)
  {
    boolean bool = false;
    for (int i = 0; i < getRowCount(); i++)
    {
      String str = (String)getValueAt(i, 0);
      if (str.equals(paramK.a()))
        return true;
    }
    return bool;
  }

  public boolean A(K paramK, List paramList)
  {
    boolean bool = false;
    for (int i = 0; i < paramList.size(); i++)
    {
      K localK = (K)paramList.get(i);
      if (paramK.a().equals(localK.a()))
        return true;
    }
    return bool;
  }

  public int getRowCount()
  {
    return C();
  }

  public int getColumnCount()
  {
    return G.length;
  }

  public int C()
  {
    return this.E.size();
  }

  public K C(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= this.E.size()))
      return null;
    return (K)this.E.get(paramInt);
  }

  public Object getValueAt(int paramInt1, int paramInt2)
  {
    K localK = C(paramInt1);
    if (localK != null)
    {
      Object[] arrayOfObject = { new Integer(localK.T()), new Integer(localK.g()) };
      switch (paramInt2)
      {
      case 0:
        return localK.a();
      case 1:
        return localK.P();
      case 2:
        return localK.G();
      case 3:
        return E.A("RoomTableModel.PlayersOfMaxPattern", arrayOfObject);
      }
    }
    return null;
  }

  public String getColumnName(int paramInt)
  {
    return G[paramInt];
  }

  public void D(int paramInt)
  {
    if (this.B == paramInt)
      this.C = (!this.C);
    else
      this.C = false;
    this.B = paramInt;
    A();
  }

  public void A()
  {
    Collections.sort(this.E, B(this.B));
    fireTableDataChanged();
  }

  public Comparator B(int paramInt)
  {
    if (paramInt == 0)
      return new B.1(this);
    if (paramInt == 1)
      return new B.2(this);
    if (paramInt == 2)
      return new B.3(this);
    if (paramInt == 3)
      return new B.4(this);
    return new B.5(this);
  }

  public int A(int paramInt)
  {
    if (this.B != paramInt)
      return 0;
    return this.C ? 1 : 2;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.B
 * JD-Core Version:    0.6.2
 */