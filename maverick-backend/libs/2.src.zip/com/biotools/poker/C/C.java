package com.biotools.poker.C;

import com.biotools.B.F;
import com.biotools.B.J;
import com.biotools.meerkat.Action;
import com.biotools.poker.E;
import com.biotools.poker.G.T;
import com.biotools.poker.PokerApp;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.io.File;
import java.text.DateFormat;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JViewport;
import javax.swing.table.JTableHeader;

public class C extends JPanel
{
  private J H;
  private O C;
  private JLabel G;
  private ImageIcon D = new ImageIcon(E.K("pix/shield-32x32.png").getPath());
  private JLabel B;
  private com.biotools.poker.G.R J;
  private D E;
  private com.A.B.A I = null;
  private com.A.B.A A = null;
  private com.A.B.A F = null;

  public C(D paramD)
  {
    this.E = paramD;
    if (paramD != null)
      setOpaque(false);
    setLayout(new BorderLayout(6, 6));
    setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
    add(C(), "North");
    JTabbedPane localJTabbedPane = new JTabbedPane();
    localJTabbedPane.add(E.D("UnfinishedTournamentPanel.Standings"), D());
    localJTabbedPane.add(E.D("UnfinishedTournamentPanel.Summary"), F());
    localJTabbedPane.add(E.D("UnfinishedTournamentPanel.Levels"), I());
    localJTabbedPane.add(E.D("UnfinishedTournamentPanel.Payouts"), H());
    add(localJTabbedPane, "Center");
  }

  protected void A(T paramT)
  {
    this.C.A(paramT);
  }

  private JComponent D()
  {
    this.C = new O();
    this.C.A(true);
    JScrollPane localJScrollPane = new JScrollPane(this.C);
    int i = 2 + (int)this.C.getTableHeader().getPreferredSize().getHeight() + this.C.getRowHeight() * 10;
    localJScrollPane.setMinimumSize(new Dimension(350, i));
    localJScrollPane.setPreferredSize(new Dimension(350, i));
    localJScrollPane.setBackground(Color.WHITE);
    localJScrollPane.getViewport().setBackground(Color.WHITE);
    return localJScrollPane;
  }

  private com.A.B.A I()
  {
    if (this.I == null)
    {
      this.I = new com.A.B.A();
      this.I.B().setFocusable(false);
      this.I.setPreferredSize(new Dimension(200, 100));
    }
    return this.I;
  }

  private com.A.B.A H()
  {
    if (this.A == null)
    {
      this.A = new com.A.B.A();
      this.A.B().setFocusable(false);
      this.A.setPreferredSize(new Dimension(200, 100));
    }
    return this.A;
  }

  private com.A.B.A F()
  {
    if (this.F == null)
    {
      this.F = new com.A.B.A();
      this.F.B().setFocusable(false);
      this.F.setPreferredSize(new Dimension(200, 100));
    }
    return this.F;
  }

  public void F(com.biotools.poker.G.R paramR)
  {
    this.J = paramR;
    A(paramR);
    D(paramR);
    B(paramR);
    E(paramR);
  }

  private void A(com.biotools.poker.G.R paramR)
  {
    this.C.A(paramR);
    this.G.setText(C(paramR));
    com.biotools.poker.R.A localA = com.biotools.poker.R.A.E(paramR.p());
    Date localDate = null;
    if (localA != null)
      localDate = new Date(localA.I());
    else
      localDate = new Date();
    DateFormat localDateFormat = DateFormat.getDateInstance(1);
    Object[] arrayOfObject = { localDateFormat.format(localDate) };
    this.B.setText("<html><div align=\"center\"><b>" + paramR.Q().ª() + "</b><br>" + E.A("UnfinishedTournamentPanel.StartedOnPattern", arrayOfObject) + "</div></html>");
  }

  private void D(com.biotools.poker.G.R paramR)
  {
    I().A(paramR.Q().M(paramR.A()));
  }

  private void B(com.biotools.poker.G.R paramR)
  {
    H().A(paramR.Q().A(paramR.V(), paramR.i()));
  }

  private void E(com.biotools.poker.G.R paramR)
  {
    F().A(paramR.G(paramR.£()));
  }

  public JPanel C()
  {
    JPanel localJPanel = new JPanel(new BorderLayout(4, 4));
    if (this.E != null)
      localJPanel.setOpaque(false);
    localJPanel.add(A(), "North");
    localJPanel.add(B(), "Center");
    return localJPanel;
  }

  public JComponent B()
  {
    if (this.G == null)
    {
      this.G = new F(0.5D, "<html></html>", 0);
      this.G.setBackground(Color.BLACK);
      this.G.setForeground(Color.WHITE);
      this.G.setPreferredSize(new Dimension(300, 100));
    }
    return this.G;
  }

  private JLabel G()
  {
    if (this.B == null)
    {
      this.B = new JLabel("<html><b></b></html>", 0);
      if (this.E != null)
        this.B.setForeground(Color.WHITE);
    }
    return this.B;
  }

  private JPanel A()
  {
    JPanel localJPanel = new JPanel(new BorderLayout(8, 8));
    if (this.E != null)
      localJPanel.setOpaque(false);
    localJPanel.add(G(), "Center");
    return localJPanel;
  }

  private JButton J()
  {
    if (this.H == null)
    {
      this.H = new J("del.png", E.D("UnfinishedTournamentPanel.DeleteToolTip"));
      this.H.addActionListener(new C.1(this));
    }
    return this.H;
  }

  private String C(com.biotools.poker.G.R paramR)
  {
    String str = paramR.£();
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<html>");
    localStringBuffer.append("<div align=\"center\">");
    localStringBuffer.append("<table width=\"100%\" align=\"center\" cellpadding=\"2\" cellspacing=\"2\">");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><b>" + E.D("UnfinishedTournamentPanel.PrizePoolTitle") + "</b></td>");
    localStringBuffer.append("<td>" + Action.formatCash(paramR.i()) + "</td>");
    localStringBuffer.append("<td>&nbsp;&nbsp;&nbsp;</td>");
    localStringBuffer.append("<td align=\"right\"><b>" + E.D("UnfinishedTournamentPanel.BuyInTitle") + "</b></td>");
    localStringBuffer.append("<td>" + paramR.n() + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr>");
    int i = paramR.H(str);
    if (i != -1)
    {
      localStringBuffer.append("<td align=\"right\"><b>" + E.D("UnfinishedTournamentPanel.RankingTitle") + "</b></td>");
      arrayOfObject1 = new Object[] { new Integer(i), new Integer(paramR.V()) };
      localStringBuffer.append("<td>" + E.A("UnfinishedTournamentPanel.OutOfPattern", arrayOfObject1) + "</td>");
    }
    else
    {
      localStringBuffer.append("<td align=\"right\">&nbsp;</td>");
      localStringBuffer.append("<td>&nbsp;</td>");
    }
    localStringBuffer.append("<td>&nbsp;&nbsp;&nbsp;</td>");
    localStringBuffer.append("<td align=\"right\"><b>" + E.D("UnfinishedTournamentPanel.ElapsedTimeTitle") + "</b></td>");
    Object[] arrayOfObject1 = { new Integer(paramR.M() / 60000) };
    localStringBuffer.append("<td>" + E.A("UnfinishedTournamentPanel.ElapsedTimePattern", arrayOfObject1));
    localStringBuffer.append("</td></tr>");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><b>" + E.D("UnfinishedTournamentPanel.PlayersLeftTitle") + "</b></td>");
    Object[] arrayOfObject2 = { new Integer(paramR.Y()), new Integer(paramR.V()) };
    localStringBuffer.append("<td>" + E.A("UnfinishedTournamentPanel.OutOfPattern", arrayOfObject2) + "</td>");
    localStringBuffer.append("<td>&nbsp;&nbsp;&nbsp;</td>");
    localStringBuffer.append("<td align=right><b>" + E.D("UnfinishedTournamentPanel.StartingChipsTitle") + "</b></td>");
    localStringBuffer.append("<td>" + Action.formatCash(paramR.m()) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("</table>");
    localStringBuffer.append("</div>");
    localStringBuffer.append("</html>");
    return localStringBuffer.toString();
  }

  public void E()
  {
    if (this.J == null)
      return;
    com.biotools.poker.R.A localA = com.biotools.poker.R.A.E(this.J.p());
    int i = PokerApp.Ȅ().ǳ() == localA ? 1 : 0;
    int j = 1;
    if (i != 0)
      j = JOptionPane.showConfirmDialog(this, E.D("UnfinishedTournamentPanel.DeleteCurrentlyPlaying"), E.D("UnfinishedTournamentPanel.Delete"), 0);
    else
      j = JOptionPane.showConfirmDialog(this, E.D("UnfinishedTournamentPanel.DeleteSelected"), E.D("UnfinishedTournamentPanel.Delete"), 0);
    if (j == 0)
    {
      if (i != 0)
      {
        E.H("Deleting currently active tournament!");
        PokerApp.Ȅ().ʒ();
      }
      if (localA != null)
        PokerApp.Ȅ().Ȇ().E(localA);
      else
        this.J.z();
      if (this.E != null)
      {
        this.E.A().setVisible(PokerApp.Ȅ().ɕ());
        this.E.À();
        this.E.ª();
      }
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.C
 * JD-Core Version:    0.6.2
 */