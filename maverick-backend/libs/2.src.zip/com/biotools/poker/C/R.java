package com.biotools.poker.C;

import com.biotools.B.K;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.PokerApp;
import com.biotools.poker.PokerApp._B;
import com.biotools.poker.Q.A.A;
import com.biotools.poker.Q.A.D;
import com.biotools.poker.Q.A.F;
import com.biotools.poker.Q.A.H;
import com.biotools.poker.Q.A.I;
import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Composite;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JViewport;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.JTableHeader;

public class R extends V
{
  public static final int T = 30;
  public static final int[] Z = { 10, 20, 30, 50, 70, 100, 150, 200, 250, 300, 400, 500, 600, 800, 1000 };
  private ArrayList _;
  private ArrayList W;
  private JButton P;
  private JButton S;
  private JComboBox a;
  private JComboBox R;
  private DefaultComboBoxModel Q;
  private JComboBox X;
  private J Y = new J(com.biotools.poker.E.E.S(), this);
  private JTextField L;
  private boolean M = false;
  private O U;
  private JPanel K;
  private JTextArea N;
  private JPanel V;
  private M O;

  public R()
  {
    this.Y.A(new ChangeListener()
    {
      public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
      {
        R.this.M();
      }
    });
    this.Y.setOpaque(false);
    JPanel localJPanel = new JPanel(new BorderLayout(12, 12));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    localJPanel.setOpaque(false);
    localJPanel.add(X(), "Center");
    localJPanel.add(a(), "South");
    setLayout(null);
    add(this.Y);
    this.Y.setBounds(G.Z);
    add(localJPanel, "Center");
    localJPanel.setBounds(G.E);
    add(P());
    P().setBounds(G.l.x, G.l.y, 158, 33);
    add(T());
    T().setBounds(G.j.x, G.j.y, 320, 42);
    f();
    add(A());
    addComponentListener(new ComponentAdapter()
    {
      public void componentShown(ComponentEvent paramAnonymousComponentEvent)
      {
        R.this.T().G();
        R.this.Y.H();
      }
    });
  }

  private void f()
  {
    if (this.Y.B != null)
      this.Y.A(this.Y.B);
  }

  private JButton P()
  {
    if (this.S == null)
    {
      this.S = new K("load-table.png", com.biotools.poker.E.D("RingGameLobby.LoadTableDescription"));
      this.S.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          R.this.W();
        }
      });
    }
    return this.S;
  }

  protected void W()
  {
    if (PokerApp.Ȅ().X(true))
      i();
    K();
  }

  private JComponent h()
  {
    this.N = new JTextArea()
    {
      public void paint(Graphics paramAnonymousGraphics)
      {
        Graphics2D localGraphics2D = (Graphics2D)paramAnonymousGraphics;
        Composite localComposite = localGraphics2D.getComposite();
        localGraphics2D.setComposite(AlphaComposite.getInstance(3, 0.5F));
        localGraphics2D.setColor(Color.BLACK);
        localGraphics2D.fillRect(0, 0, getWidth(), getHeight());
        localGraphics2D.setComposite(localComposite);
        super.paint(paramAnonymousGraphics);
      }
    };
    this.N.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    this.N.setEditable(true);
    this.N.setWrapStyleWord(true);
    this.N.setLineWrap(true);
    this.N.setOpaque(false);
    this.N.setForeground(Color.WHITE);
    this.N.addKeyListener(new KeyAdapter()
    {
      public void keyTyped(KeyEvent paramAnonymousKeyEvent)
      {
        R.this.A(true);
      }
    });
    JScrollPane localJScrollPane = new JScrollPane(this.N);
    localJScrollPane.setOpaque(false);
    localJScrollPane.getViewport().setOpaque(false);
    localJScrollPane.setPreferredSize(new Dimension(150, 60));
    localJScrollPane.setBorder(BorderFactory.createEtchedBorder());
    return localJScrollPane;
  }

  private void A(boolean paramBoolean)
  {
    this.P.setVisible(paramBoolean);
    this.M = paramBoolean;
  }

  private boolean Q()
  {
    if ((this.U.D() != null) && (this.U.F()))
      return true;
    return this.M;
  }

  private boolean R()
  {
    String str = this.L.getText().trim();
    if (A(str, 1, 30))
    {
      com.biotools.poker.E.E localE = this.U.D();
      localE.D(str);
      localE.C(this.N.getText());
      localE.L();
      this.Y.C(localE);
      A(false);
    }
    else
    {
      c();
      return false;
    }
    return true;
  }

  private boolean j()
  {
    if (Q())
    {
      Object[] arrayOfObject = { this.U.D().J() };
      int i = JOptionPane.showConfirmDialog(this, com.biotools.poker.E.A("RingGameLobby.SaveChangesDescriptionPattern", arrayOfObject), com.biotools.poker.E.D("RingGameLobby.SaveChanges"), 0);
      if (i == 0)
        return R();
      this.U.D().E();
    }
    return true;
  }

  public J Z()
  {
    return this.Y;
  }

  private Component S()
  {
    this.P = new com.biotools.B.J("save.png", com.biotools.poker.E.D("RingGameLobby.SaveChangesDescription"));
    this.P.setVisible(false);
    this.P.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        R.this.R();
      }
    });
    this.L = new JTextField(30);
    this.L.setEnabled(false);
    this.L.setToolTipText(com.biotools.poker.E.D("RingGameLobby.EditTableName"));
    this.L.addKeyListener(new KeyAdapter()
    {
      public void keyTyped(KeyEvent paramAnonymousKeyEvent)
      {
        R.this.A(true);
      }
    });
    JPanel localJPanel = new JPanel(new B.A.A.B());
    localJPanel.setOpaque(false);
    localJPanel.add("left", A(com.biotools.poker.E.D("RingGameLobby.TableNameTitle")));
    localJPanel.add("tab hfill", this.L);
    localJPanel.add("right", this.P);
    return localJPanel;
  }

  private JPanel X()
  {
    this.U = new O();
    this.U.A(null);
    this.U.A(new ChangeListener()
    {
      public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
      {
        if (R.this.U.F())
          R.this.A(true);
      }
    });
    JScrollPane localJScrollPane = new JScrollPane(this.U);
    int i = 2 + (int)this.U.getTableHeader().getPreferredSize().getHeight() + this.U.getRowHeight() * 10;
    localJScrollPane.setPreferredSize(new Dimension(250, i));
    JPanel localJPanel1 = new JPanel(new BorderLayout(6, 6));
    localJPanel1.setOpaque(false);
    localJPanel1.add(S(), "North");
    localJPanel1.add(localJScrollPane, "Center");
    this.V = new JPanel(new BorderLayout(6, 6));
    this.V.add(localJPanel1, "North");
    this.V.add(h(), "Center");
    this.V.setOpaque(false);
    JPanel localJPanel2 = new JPanel(new BorderLayout(6, 6));
    localJPanel2.setOpaque(false);
    localJPanel2.add(this.V, "Center");
    return localJPanel2;
  }

  private M T()
  {
    if (this.O == null)
    {
      this.O = new M();
      this.O.setOpaque(false);
      this.O.B(new ChangeListener()
      {
        public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
        {
          String str = R.this.O.I();
          if (str != null)
            R.this.U.D().C(0, str);
        }
      });
      this.O.F().setForeground(Color.WHITE);
    }
    return this.O;
  }

  private ArrayList L()
  {
    if (this.W == null)
      this.W = new ArrayList();
    return this.W;
  }

  private DefaultComboBoxModel g()
  {
    if (this.Q == null)
      this.Q = new DefaultComboBoxModel(L().toArray());
    return this.Q;
  }

  private JComboBox d()
  {
    if (this.a == null)
    {
      this.a = new JComboBox(PokerApp.Ȅ().ɭ());
      this.a.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          R.this.Y();
        }
      });
      this.a.setSelectedIndex(com.biotools.poker.E.£().getInt("LIMIT_LEVEL", 2));
      this.a.setOpaque(false);
    }
    return this.a;
  }

  private JComboBox e()
  {
    if (this.R == null)
    {
      this.R = new JComboBox(g());
      Y();
      this.R.setOpaque(false);
    }
    return this.R;
  }

  private void Y()
  {
    PokerApp._B local_B = k();
    b();
    double d1 = local_B.B;
    for (int i = 0; i < Z.length; i++)
    {
      double d2 = d1 * Z[i];
      this._.add(new Double(d2));
      Object[] arrayOfObject = { Action.formatCash(d2) };
      this.W.add(new String(com.biotools.poker.E.A("RingGameLobby.SetToPattern", arrayOfObject)));
    }
    g().removeAllElements();
    for (i = 0; i < this.W.size(); i++)
      g().addElement(this.W.get(i));
    e().setSelectedIndex(com.biotools.poker.E.£().getInt("BANKROLL_INIT", 6));
  }

  private void b()
  {
    this._ = new ArrayList();
    this.W = new ArrayList();
    this._.add(new Double(-1.0D));
    this.W.add(new String(com.biotools.poker.E.D("RingGameLobby.Unchanged")));
  }

  private JPanel a()
  {
    if (this.K == null)
    {
      JPanel localJPanel = new JPanel(new GridLayout(2, 3, 6, 1));
      localJPanel.setOpaque(false);
      localJPanel.add(A(com.biotools.poker.E.D("RingGameLobby.StartingBankrollsTitle"), 2));
      localJPanel.add(A(com.biotools.poker.E.D("RingGameLobby.StakesTitle"), 2));
      if (com.biotools.poker.E.Ú())
        localJPanel.add(Box.createGlue());
      else
        localJPanel.add(A(com.biotools.poker.E.D("RingGameLobby.HouseRakeTitle"), 2));
      localJPanel.add(e());
      localJPanel.add(d());
      if (com.biotools.poker.E.Ú())
        localJPanel.add(Box.createGlue());
      else
        localJPanel.add(N());
      this.K = localJPanel;
    }
    return this.K;
  }

  private void O()
  {
    this.L.setText("");
    this.L.setEnabled(false);
    P().setEnabled(false);
    this.N.setText("");
    this.N.setEnabled(false);
    this.V.setVisible(false);
    this.K.setVisible(false);
    P().setVisible(false);
  }

  private void M()
  {
    j();
    com.biotools.poker.E.E localE = this.Y.A();
    if (localE == null)
    {
      O();
    }
    else
    {
      this.V.setVisible(true);
      localE.A(true);
      this.L.setEnabled(true);
      P().setEnabled(true);
      this.N.setEnabled(true);
      this.L.setText(localE.J());
      this.N.setText(localE.A());
      this.N.setCaretPosition(0);
      this.K.setVisible(true);
      T().setVisible(true);
      P().setVisible(true);
      B(localE.O());
    }
    this.U.A(localE);
    A(false);
  }

  private void B(boolean paramBoolean)
  {
    for (int i = 0; i < PokerApp.Ȅ().ɭ().length; i++)
    {
      PokerApp._B local_B = PokerApp.Ȅ().ɭ()[i];
      local_B.A(paramBoolean);
    }
    d().updateUI();
  }

  public static boolean A(String paramString, int paramInt1, int paramInt2)
  {
    int i = (paramString.length() >= paramInt1) && (paramString.length() <= paramInt2) ? 1 : 0;
    int j = 1;
    if (i != 0)
      for (int k = 0; k < paramString.length(); k++)
      {
        char c = paramString.charAt(k);
        if ((!Character.isLetterOrDigit(c)) && (c != '_') && (c != '-') && (c != '\'') && (!Character.isSpaceChar(c)))
        {
          j = 0;
          break;
        }
      }
    return (i != 0) && (j != 0);
  }

  public void c()
  {
    JOptionPane.showMessageDialog(this, com.biotools.poker.E.D("RingGameLobby.IncorrectTableNameDescription"), com.biotools.poker.E.D("RingGameLobby.IncorrectTableName"), 0);
  }

  private int _()
  {
    int i = e().getSelectedIndex();
    Double localDouble = (Double)this._.get(i);
    return localDouble.intValue();
  }

  private PokerApp._B k()
  {
    return PokerApp.Ȅ().ɭ()[d().getSelectedIndex()];
  }

  public void i()
  {
    String str = T().I();
    if (str == null)
    {
      JOptionPane.showMessageDialog(this, com.biotools.poker.E.D("RingGameLobby.SelectProfileDescription"), com.biotools.poker.E.D("RingGameLobby.SelectProfile"), 0);
      return;
    }
    com.biotools.poker.E.E localE = this.U.D().D();
    if (localE != null)
    {
      Cursor localCursor = getCursor();
      setCursor(Cursor.getPredefinedCursor(3));
      localE.H();
      if (localE.Q() != null)
        com.biotools.poker.E.£().put("DEFAULT_TABLE", localE.Q().toString());
      com.biotools.poker.E.£().putInt("LIMIT_LEVEL", d().getSelectedIndex());
      com.biotools.poker.E.£().putInt("BANKROLL_INIT", this.R.getSelectedIndex());
      PokerApp.Ȅ().y(str);
      if (!com.biotools.poker.E.Ú())
        com.biotools.poker.E.£().put("RAKE", ((A)N().getSelectedItem()).A());
      PokerApp.Ȅ().A(localE, k(), _());
      setCursor(localCursor);
    }
  }

  public JComboBox N()
  {
    if (this.X == null)
    {
      String str = com.biotools.poker.E.£().get("RAKE", com.biotools.poker.E.D("RingGameLobby.NoRake"));
      Vector localVector = U();
      this.X = new JComboBox(localVector);
      this.X.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          A localA = (A)R.this.X.getSelectedItem();
          R.this.X.setToolTipText(localA.A(R.this.U.D().I(), R.this.U.D().O(), R.this.k().C));
        }
      });
      this.X.setOpaque(false);
      A localA = A(localVector, str);
      if (localA != null)
        this.X.setSelectedItem(localA);
    }
    return this.X;
  }

  public static A B(String paramString)
  {
    Vector localVector = U();
    return A(localVector, paramString);
  }

  public static A V()
  {
    String str = com.biotools.poker.E.£().get("RAKE", "");
    Vector localVector = U();
    return A(localVector, str);
  }

  public static A A(Vector paramVector, String paramString)
  {
    for (int i = 0; i < paramVector.size(); i++)
    {
      A localA = (A)paramVector.get(i);
      if (localA.A().equals(paramString))
        return localA;
    }
    return null;
  }

  public static Vector U()
  {
    Vector localVector = new Vector();
    localVector.add(new com.biotools.poker.Q.A.E());
    localVector.add(new com.biotools.poker.Q.A.G());
    localVector.add(new H());
    localVector.add(new F());
    localVector.add(new I());
    localVector.add(new D());
    localVector.add(new com.biotools.poker.Q.A.B());
    return localVector;
  }

  public File B()
  {
    return com.biotools.poker.E.K("pix/lobby/L_ring.png");
  }

  public Point G()
  {
    return new Point(468, 53);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.R
 * JD-Core Version:    0.6.2
 */