package com.biotools.poker.C;

import com.biotools.B.K;
import com.biotools.B.O;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.F.F;
import com.biotools.poker.P.N;
import com.biotools.poker.PokerApp;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class U extends V
{
  private static final String[] g = { "216.17.37.114", "216.17.37.120", "localhost", "trogdor", "gambit", "thecheat", "zorak" };
  private static final String h = "LOGIN_PANEL";
  private static final String l = "CONNECTED_PANEL";
  private A k;
  private JPanel i;
  private JPanel m;
  private com.A.B.A n;
  private O e;
  private JComboBox j = new JComboBox(g);
  private JTextField f = new JTextField(12);
  private JButton o;
  private F b;
  private boolean c = false;
  private JButton d;

  public U(A paramA)
  {
    this.k = paramA;
    setLayout(null);
    Rectangle localRectangle = G.Z;
    if (com.biotools.poker.E.Ð())
    {
      localRectangle = (Rectangle)localRectangle.clone();
      localRectangle.translate(0, 20);
    }
    add(t());
    t().setBounds(localRectangle);
    localRectangle = G.E;
    if (com.biotools.poker.E.Ð())
    {
      localRectangle = (Rectangle)localRectangle.clone();
      localRectangle.translate(0, 20);
    }
    add(s());
    s().setBounds(localRectangle);
  }

  public void q()
  {
    s().A("LOGIN_PANEL");
    r();
  }

  private com.A.B.A t()
  {
    if (this.n == null)
    {
      this.n = new com.A.B.A();
      this.n.A(com.biotools.A.B.A(com.biotools.poker.E.K("help/login.html")));
      this.n.B().setFocusable(false);
      this.n.setPreferredSize(new Dimension(350, 250));
    }
    return this.n;
  }

  private O s()
  {
    if (this.e == null)
    {
      this.e = new O();
      this.e.setOpaque(false);
      this.e.A(o(), "LOGIN_PANEL");
      this.e.A(p(), "CONNECTED_PANEL");
    }
    return this.e;
  }

  private JPanel p()
  {
    if (this.m == null)
    {
      this.m = new JPanel();
      this.m.setOpaque(false);
      this.m.setLayout(new B.A.A.B(4, 4));
      this.m.setBorder(BorderFactory.createEmptyBorder(90, 35, 35, 35));
      String str1 = "center";
      String str2 = "p";
      String str3 = "<html><div align=center><font color=white>" + com.biotools.poker.E.D("LoginPanel.CurrentlyConnected") + "</font></div></html>";
      this.m.add(str1, new JLabel(str3));
      this.m.add(str2 + " " + str1, Box.createVerticalStrut(10));
      this.m.add(str2 + " " + str1, l());
      this.m.add(str2 + " " + str1, Box.createVerticalStrut(5));
      this.m.setOpaque(false);
    }
    return this.m;
  }

  private JButton l()
  {
    if (this.d == null)
    {
      this.d = new K("disconnect.png", com.biotools.poker.E.D("LoginPanel.DisconnectToolTip"));
      this.d.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          U.this.k.Ĵ();
          U.this.s().A("LOGIN_PANEL");
        }
      });
    }
    return this.d;
  }

  private JPanel o()
  {
    if (this.i == null)
    {
      this.i = new JPanel();
      this.i.setOpaque(false);
      this.f.setText(com.biotools.poker.E.£().get("LAST_ONLINE_PROFILE", ""));
      this.i.setLayout(new B.A.A.B(6, 6));
      this.i.setBorder(BorderFactory.createEmptyBorder(90, 35, 35, 35));
      this.i.add("p br center", new JLabel(new ImageIcon(com.biotools.poker.E.K("pix/lobby/06-username.png").getPath())));
      this.i.add("center", this.f);
      if (com.biotools.poker.E.y())
      {
        this.i.add("center", new JLabel(com.biotools.poker.E.D("LoginPanel.ServerTitle"), 4));
        this.i.add("center", this.j);
      }
      this.i.add("p center", Box.createVerticalStrut(10));
      this.i.add("p center", u());
      this.i.add("p center", Box.createVerticalStrut(5));
      this.i.add("p center", v());
      this.i.add("p center", Box.createVerticalStrut(5));
    }
    return this.i;
  }

  private F u()
  {
    if (this.b == null)
      this.b = new F(PokerApp.Ȅ());
    return this.b;
  }

  private JButton v()
  {
    if (this.o == null)
    {
      this.o = new K("connect.png", com.biotools.poker.E.D("LoginPanel.ConnectToolTip"));
      this.o.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          U.this.c = ((paramAnonymousActionEvent.getModifiers() & 0x2) != 0);
          U.this.C(U.this.c);
        }
      });
    }
    return this.o;
  }

  protected void C(boolean paramBoolean)
  {
    if (this.k.Ĥ())
      this.k.Ĵ();
    String str = this.f.getText().trim();
    if (!N.A(str, 1, 12))
    {
      JOptionPane.showMessageDialog(this, com.biotools.poker.E.D("LoginPanel.IncorrectProfileNameText"), com.biotools.poker.E.D("LoginPanel.IncorrectProfileNameTitle"), 0);
      return;
    }
    v().setEnabled(false);
    this.b.A(50);
    Thread localThread = new Thread(new U.3(this), "Connection Thread");
    localThread.start();
  }

  private void r()
  {
    SwingUtilities.invokeLater(new Runnable()
    {
      public void run()
      {
        U.this.b.A();
        U.this.v().setEnabled(true);
      }
    });
  }

  public String w()
  {
    return (String)this.j.getSelectedItem();
  }

  private boolean m()
  {
    com.biotools.poker.S.B.E.A(false);
    String str = null;
    com.biotools.poker.S.B.E localE = new com.biotools.poker.S.B.E();
    try
    {
      str = localE.A(w(), this.c ? 11301 : 33345);
    }
    catch (Exception localException)
    {
      this.k.A(this, str);
      return false;
    }
    if (str != null)
    {
      this.k.A(this, str);
    }
    else
    {
      SwingUtilities.invokeLater(new U.5(this, localE));
      return true;
    }
    return false;
  }

  private void A(com.biotools.poker.S.B.E paramE)
  {
    this.k.A(paramE, this.f.getText().trim(), this);
  }

  public void n()
  {
    SwingUtilities.invokeLater(new U.6(this));
  }

  public File B()
  {
    return com.biotools.poker.E.K("pix/lobby/L_online.png");
  }

  public Point G()
  {
    return new Point(167, 53);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.U
 * JD-Core Version:    0.6.2
 */