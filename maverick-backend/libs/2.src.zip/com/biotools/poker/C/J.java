package com.biotools.poker.C;

import com.biotools.B.A;
import com.biotools.B.L;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.Enumeration;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.JViewport;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

public class J extends JPanel
  implements TreeSelectionListener
{
  private Vector H = new Vector();
  private com.biotools.poker.E.E D = null;
  private JTree M;
  private DefaultTreeModel K;
  private _B J;
  private _B G;
  private _B I;
  private JButton L;
  private JButton C;
  private JButton F;
  private JButton A;
  protected _A B = null;
  private R E;

  public J(Vector paramVector, R paramR)
  {
    this.E = paramR;
    setLayout(new BorderLayout(6, 6));
    setOpaque(false);
    add(E(), "West");
    add(A(paramVector), "Center");
  }

  public void H()
  {
    this.M.scrollRowToVisible(0);
  }

  public void valueChanged(TreeSelectionEvent paramTreeSelectionEvent)
  {
    DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)this.M.getLastSelectedPathComponent();
    if (localDefaultMutableTreeNode == null)
      return;
    if ((localDefaultMutableTreeNode instanceof _A))
    {
      this.D = ((_A)localDefaultMutableTreeNode).A;
      this.L.setEnabled(true);
      this.A.setEnabled(true);
      this.B = ((_A)localDefaultMutableTreeNode);
    }
    else
    {
      this.L.setEnabled(false);
      this.A.setEnabled(false);
      this.D = null;
    }
    D();
  }

  public com.biotools.poker.E.E A()
  {
    return this.D;
  }

  public void A(com.biotools.poker.E.E paramE)
  {
    _A local_A = new _A(paramE);
    if (this.B == null)
      this.B = local_A;
    if (paramE.O())
      this.K.insertNodeInto(local_A, this.I, this.I.getChildCount());
    else
      this.K.insertNodeInto(local_A, this.G, this.G.getChildCount());
    TreePath localTreePath = new TreePath(local_A.getPath());
    this.M.scrollPathToVisible(localTreePath);
  }

  private Component E()
  {
    this.L = new com.biotools.B.J("del.png", com.biotools.poker.E.D("TableBrowser.DeleteTableToolTip"));
    this.L.setEnabled(false);
    this.L.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        J.this.C();
      }
    });
    this.C = new com.biotools.B.J("add.png", com.biotools.poker.E.D("TableBrowser.AddTableToolTip"));
    this.C.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        J.this.F();
      }
    });
    this.F = new com.biotools.B.J("import.png", com.biotools.poker.E.D("TableBrowser.ImportToolTip"));
    this.F.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        J.this.G();
      }
    });
    this.A = new com.biotools.B.J("export.png", com.biotools.poker.E.D("TableBrowser.ExportToolTip"));
    this.A.setEnabled(false);
    this.A.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        J.this.B(J.this.D);
      }
    });
    JPanel localJPanel = new JPanel();
    localJPanel.setOpaque(false);
    localJPanel.setLayout(new BoxLayout(localJPanel, 1));
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.add(this.C);
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.add(this.L);
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.add(Box.createVerticalStrut(25));
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.add(this.F);
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.add(this.A);
    localJPanel.add(Box.createVerticalStrut(5));
    return localJPanel;
  }

  public synchronized void A(ChangeListener paramChangeListener)
  {
    this.H.add(paramChangeListener);
  }

  public synchronized void B(ChangeListener paramChangeListener)
  {
    this.H.remove(paramChangeListener);
  }

  private synchronized void D()
  {
    ChangeEvent localChangeEvent = new ChangeEvent(this);
    for (int i = 0; i < this.H.size(); i++)
      ((ChangeListener)this.H.get(i)).stateChanged(localChangeEvent);
  }

  public static JScrollPane A(JTree paramJTree)
  {
    paramJTree.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    paramJTree.setRootVisible(false);
    paramJTree.getSelectionModel().setSelectionMode(1);
    paramJTree.setFocusable(false);
    ImageIcon localImageIcon = new ImageIcon(com.biotools.poker.E.K("pix/chips-100.png").getPath());
    DefaultTreeCellRenderer local5 = new DefaultTreeCellRenderer()
    {
      public Color getBackground()
      {
        return null;
      }

      public Component getTreeCellRendererComponent(JTree paramAnonymousJTree, Object paramAnonymousObject, boolean paramAnonymousBoolean1, boolean paramAnonymousBoolean2, boolean paramAnonymousBoolean3, int paramAnonymousInt, boolean paramAnonymousBoolean4)
      {
        Component localComponent = super.getTreeCellRendererComponent(paramAnonymousJTree, paramAnonymousObject, paramAnonymousBoolean1, paramAnonymousBoolean2, paramAnonymousBoolean3, paramAnonymousInt, paramAnonymousBoolean4);
        if (!paramAnonymousBoolean3)
        {
          setBackgroundSelectionColor(null);
          setForeground(Color.ORANGE);
        }
        else
        {
          setBackgroundSelectionColor(new Color(225, 225, 255));
        }
        return localComponent;
      }
    };
    local5.setLeafIcon(null);
    local5.setOpenIcon(localImageIcon);
    local5.setClosedIcon(localImageIcon);
    local5.setBackground(null);
    local5.setBackgroundSelectionColor(new Color(225, 225, 255));
    local5.setBackgroundNonSelectionColor(null);
    local5.setTextSelectionColor(Color.BLACK);
    local5.setTextNonSelectionColor(Color.WHITE);
    local5.setBorderSelectionColor(Color.ORANGE);
    local5.setTextNonSelectionColor(new Color(225, 225, 255));
    Font localFont = new Font("Application", 1, 13);
    local5.setFont(localFont);
    paramJTree.setCellRenderer(local5);
    paramJTree.setRowHeight(20);
    paramJTree.setOpaque(false);
    JScrollPane localJScrollPane = new JScrollPane(paramJTree);
    localJScrollPane.setOpaque(false);
    localJScrollPane.setBorder(BorderFactory.createEmptyBorder());
    localJScrollPane.getViewport().setOpaque(false);
    localJScrollPane.setMinimumSize(new Dimension(250, 200));
    localJScrollPane.setPreferredSize(new Dimension(250, 200));
    A.A(localJScrollPane);
    return localJScrollPane;
  }

  private Component A(Vector paramVector)
  {
    this.J = new _B(com.biotools.poker.E.D("TableBrowser.Tables"));
    this.G = new _B(com.biotools.poker.E.D("TableBrowser.Limit"));
    this.I = new _B(com.biotools.poker.E.D("TableBrowser.NoLimit"));
    this.J.add(this.G);
    this.J.add(this.I);
    this.K = new DefaultTreeModel(this.J);
    this.M = new JTree(this.K);
    JScrollPane localJScrollPane = A(this.M);
    for (int i = 0; i < paramVector.size(); i++)
      A((com.biotools.poker.E.E)paramVector.get(i));
    L.A(this.M);
    this.M.addTreeSelectionListener(this);
    B();
    return localJScrollPane;
  }

  private void B()
  {
    MouseAdapter local6 = new MouseAdapter()
    {
      public void mousePressed(MouseEvent paramAnonymousMouseEvent)
      {
        int i = J.this.M.getRowForLocation(paramAnonymousMouseEvent.getX(), paramAnonymousMouseEvent.getY());
        TreePath localTreePath = J.this.M.getPathForLocation(paramAnonymousMouseEvent.getX(), paramAnonymousMouseEvent.getY());
        if ((i != -1) && (paramAnonymousMouseEvent.getClickCount() == 2))
        {
          TreeNode localTreeNode = (TreeNode)localTreePath.getLastPathComponent();
          if ((localTreeNode instanceof J._A))
          {
            J.this.D = ((J._A)localTreeNode).A;
            J.this.E.W();
          }
        }
      }
    };
    this.M.addMouseListener(local6);
  }

  public void F()
  {
    com.biotools.poker.E.q();
    com.biotools.poker.E.E localE = new com.biotools.poker.E.E();
    localE.C(false);
    localE.A(true);
    localE.M();
    for (int i = 1; i < 10; i++)
      localE.B();
    TreePath localTreePath = this.M.getSelectionPath();
    if (localTreePath != null)
    {
      TreeNode localTreeNode = (TreeNode)localTreePath.getLastPathComponent();
      if ((localTreeNode instanceof _A))
        localE.C(((_A)localTreeNode).A.O());
      else if (localTreeNode == this.I)
        localE.C(true);
      else if (localTreeNode == this.G)
        localE.C(false);
    }
    localE.T();
    A(localE);
  }

  private void C()
  {
    com.biotools.poker.E.q();
    if (this.D == null)
      return;
    Object[] arrayOfObject = { this.D.J() };
    int i = JOptionPane.showConfirmDialog(this, com.biotools.poker.E.A("TableBrowser.DeleteTableDescriptionPattern", arrayOfObject), com.biotools.poker.E.D("TableBrowser.DeleteTable"), 0);
    if (i == 0)
    {
      this.D.P();
      TreePath localTreePath = this.M.getSelectionPath();
      if (localTreePath != null)
      {
        TreeNode localTreeNode = (TreeNode)localTreePath.getLastPathComponent();
        if ((localTreeNode instanceof _A))
          this.K.removeNodeFromParent((_A)localTreeNode);
      }
    }
  }

  public void A(File paramFile)
  {
    Enumeration localEnumeration = this.J.breadthFirstEnumeration();
    while (localEnumeration.hasMoreElements())
    {
      Object localObject = localEnumeration.nextElement();
      if ((localObject instanceof _A))
      {
        File localFile = ((_A)localObject).A().Q();
        if (paramFile.equals(localFile))
        {
          TreePath localTreePath = new TreePath(((_A)localObject).getPath());
          this.B = ((_A)localObject);
          this.M.scrollPathToVisible(localTreePath);
          this.M.setSelectionPath(localTreePath);
          D();
          return;
        }
      }
    }
  }

  public void A(_A param_A)
  {
    Enumeration localEnumeration = this.J.breadthFirstEnumeration();
    while (localEnumeration.hasMoreElements())
    {
      Object localObject = localEnumeration.nextElement();
      if (((localObject instanceof _A)) && (localObject == param_A))
      {
        TreePath localTreePath = new TreePath(((_A)localObject).getPath());
        this.B = ((_A)localObject);
        this.M.setSelectionPath(localTreePath);
        this.M.scrollPathToVisible(localTreePath);
        D();
        return;
      }
    }
  }

  public void C(com.biotools.poker.E.E paramE)
  {
    Enumeration localEnumeration = this.J.breadthFirstEnumeration();
    while (localEnumeration.hasMoreElements())
    {
      Object localObject = localEnumeration.nextElement();
      if (((localObject instanceof _A)) && (((_A)localObject).A == paramE))
        this.K.nodeChanged((_A)localObject);
    }
  }

  public void B(com.biotools.poker.E.E paramE)
  {
    if (paramE != null)
    {
      JFileChooser localJFileChooser = new JFileChooser();
      localJFileChooser.setSelectedFile(new File(paramE.J() + ".tbl"));
      if (localJFileChooser.showSaveDialog(this) == 0)
      {
        File localFile = localJFileChooser.getSelectedFile();
        if (localFile != null)
          paramE.D(localFile);
      }
    }
  }

  public void G()
  {
    JFileChooser localJFileChooser = new JFileChooser();
    if (localJFileChooser.showOpenDialog(this) == 0)
    {
      File localFile = localJFileChooser.getSelectedFile();
      if (localFile != null)
      {
        com.biotools.poker.E.E localE = com.biotools.poker.E.E.A(localFile);
        if (localE != null)
        {
          A(localE);
          this.D = localE;
          A(localE.Q());
        }
        else
        {
          JOptionPane.showMessageDialog(this, com.biotools.poker.E.D("TableBrowser.ErrorInvalidFile"), com.biotools.poker.E.D("TableBrowser.ErrorImportingRingGame"), 0);
        }
      }
    }
  }

  private class _A extends DefaultMutableTreeNode
  {
    public com.biotools.poker.E.E A;

    public _A(com.biotools.poker.E.E arg2)
    {
      Object localObject;
      this.A = localObject;
    }

    public String toString()
    {
      return this.A.J();
    }

    public com.biotools.poker.E.E A()
    {
      return this.A;
    }
  }

  public class _B extends DefaultMutableTreeNode
  {
    public _B(Object arg2)
    {
      super();
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.J
 * JD-Core Version:    0.6.2
 */