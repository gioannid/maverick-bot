package com.biotools.poker.C;

import com.biotools.B.L;
import com.biotools.poker.C.A.D;
import com.biotools.poker.C.A.G;
import com.biotools.poker.E;
import com.biotools.poker.S.E.K;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

public class F extends JTable
{
  private static final Color E = new Color(240, 240, 255);
  private static final Color D = new Color(80, 150, 20);
  private static final Color F = new Color(40, 140, 40);
  private B B;
  private Vector C = new Vector();
  private D A;

  public F()
  {
    A(new ArrayList());
    setSelectionMode(0);
    getTableHeader().setReorderingAllowed(false);
    getTableHeader().setDefaultRenderer(new _C(getTableHeader().getDefaultRenderer()));
    setRowMargin(0);
    setShowGrid(false);
    setFocusable(false);
    getColumnModel().setColumnMargin(0);
    TableColumn localTableColumn1 = getColumnModel().getColumn(0);
    if (localTableColumn1 != null)
    {
      localTableColumn1.setCellRenderer(new _A());
      localTableColumn1.setMinWidth(140);
      localTableColumn1.setPreferredWidth(200);
    }
    getColumnModel().getColumn(1).setMinWidth(90);
    getColumnModel().getColumn(2).setMinWidth(90);
    getColumnModel().getColumn(3).setMinWidth(55);
    setFont(getFont().deriveFont(10.0F));
    setSelectionForeground(Color.BLACK);
    TableColumnModel localTableColumnModel = getColumnModel();
    DefaultTableCellRenderer localDefaultTableCellRenderer = new DefaultTableCellRenderer();
    for (int i = 1; i < localTableColumnModel.getColumnCount(); i++)
    {
      TableColumn localTableColumn2 = localTableColumnModel.getColumn(i);
      localDefaultTableCellRenderer.setHorizontalAlignment(0);
      localTableColumn2.setCellRenderer(localDefaultTableCellRenderer);
    }
    setRowHeight(24);
    addMouseListener(new MouseAdapter()
    {
      public void mouseReleased(MouseEvent paramAnonymousMouseEvent)
      {
        int i = F.this.getSelectedRow();
        if (i != -1)
          F.this.A(F.this.B.C(i), true);
      }

      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        F.this.A(paramAnonymousMouseEvent);
      }
    });
    getTableHeader().addMouseListener(new MouseAdapter()
    {
      int A = -1;

      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        JTableHeader localJTableHeader = (JTableHeader)paramAnonymousMouseEvent.getSource();
        TableColumnModel localTableColumnModel = localJTableHeader.getColumnModel();
        int i = localTableColumnModel.getColumnIndexAtX(paramAnonymousMouseEvent.getX());
        int j = localTableColumnModel.getColumn(i).getModelIndex();
        if (j != -1)
        {
          F.this.B().D(j);
          F.this.getTableHeader().repaint();
        }
      }
    });
  }

  protected void A()
  {
    K localK = B().C(getSelectedRow());
    A(localK, true);
  }

  private void A(MouseEvent paramMouseEvent)
  {
    if ((paramMouseEvent.getButton() == 3) || (paramMouseEvent.isControlDown()))
    {
      int i = rowAtPoint(paramMouseEvent.getPoint());
      if (i >= 0)
      {
        if (!isRowSelected(i))
          getSelectionModel().setSelectionInterval(i, i);
        if (this.A != null)
        {
          G localG = new G(this.A, this.B.C(i));
          localG.show(this, paramMouseEvent.getX(), paramMouseEvent.getY());
        }
      }
    }
  }

  public void A(K paramK)
  {
    for (int i = 0; i < getRowCount(); i++)
    {
      String str = this.B.C(i).a();
      if (str.equals(paramK.a()))
      {
        getSelectionModel().setSelectionInterval(i, i);
        A(this.B.C(i), false);
      }
    }
  }

  public Component prepareRenderer(TableCellRenderer paramTableCellRenderer, int paramInt1, int paramInt2)
  {
    Component localComponent = super.prepareRenderer(paramTableCellRenderer, paramInt1, paramInt2);
    if (paramInt1 % 2 == 0)
      localComponent.setBackground(Color.WHITE);
    else
      localComponent.setBackground(E);
    localComponent.setForeground(Color.BLACK);
    K localK = this.B.C(paramInt1);
    if (localK != null)
    {
      if (localK.L())
        localComponent.setForeground(D);
      if ((localK.K() != null) && (localK.h()) && ((localK.K().equals(E.D("Online.Room.InProgress"))) || (localK.K().equals(E.D("Online.Room.Finished")))))
        localComponent.setForeground(L.A(localComponent.getForeground(), localComponent.getBackground(), 0.5D));
    }
    if (getSelectedRow() == paramInt1)
      localComponent.setBackground(localComponent.getBackground().darker());
    return localComponent;
  }

  public K A(String paramString)
  {
    return this.B.A(paramString);
  }

  public void A(List paramList)
  {
    this.B = new B(paramList);
    super.setModel(this.B);
  }

  public B B()
  {
    return this.B;
  }

  public synchronized void A(S paramS)
  {
    this.C.add(paramS);
  }

  public synchronized void B(S paramS)
  {
    this.C.remove(paramS);
  }

  private synchronized void A(K paramK, boolean paramBoolean)
  {
    for (int i = 0; i < this.C.size(); i++)
      ((S)this.C.get(i)).A(paramK, paramBoolean);
  }

  public K C()
  {
    int i = getSelectedRow();
    if (i >= 0)
      return this.B.C(i);
    return null;
  }

  public void B(K paramK)
  {
    K localK = B().C(getSelectedRow());
    B().A(paramK);
    if (localK != null)
      A(localK);
  }

  protected void A(D paramD)
  {
    this.A = paramD;
  }

  public void C(K paramK)
  {
    K localK = B().C(getSelectedRow());
    B().B(paramK);
    if (localK != null)
      A(localK);
  }

  public class _A
    implements TableCellRenderer
  {
    ImageIcon D = new ImageIcon(E.K("pix/lock.png").getPath());
    ImageIcon E = new ImageIcon(E.K("pix/perm.png").getPath());
    ImageIcon C = new ImageIcon(E.K("pix/open.png").getPath());
    JLabel B = new JLabel(this.C, 2);
    JPanel A = new JPanel(new BorderLayout());

    public _A()
    {
      this.B.setHorizontalTextPosition(4);
      this.B.setIconTextGap(5);
      this.B.setFont(this.B.getFont().deriveFont(1, 10.0F));
      this.B.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
      this.A.add(this.B, "West");
    }

    public Component getTableCellRendererComponent(JTable paramJTable, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2)
    {
      K localK = F.this.B.C(paramInt1);
      ImageIcon localImageIcon = localK.A(this.B);
      if (localImageIcon != null)
        this.B.setIcon(localImageIcon);
      else if (localK.c())
        this.B.setIcon(this.D);
      else if (localK.B())
        this.B.setIcon(this.E);
      else
        this.B.setIcon(this.C);
      this.B.setText(localK.a());
      this.B.setForeground(Color.BLACK);
      if (paramBoolean1)
      {
        this.A.setForeground(paramJTable.getSelectionForeground());
        this.A.setBackground(paramJTable.getSelectionBackground());
      }
      else
      {
        this.A.setForeground(paramJTable.getForeground());
        this.A.setBackground(paramJTable.getBackground());
      }
      if (localK.L())
        this.B.setForeground(F.D);
      if ((localK.K() != null) && (localK.h()) && ((localK.K().equals(E.D("Online.Room.InProgress"))) || (localK.K().equals(E.D("Online.Room.Finished")))))
        this.B.setForeground(L.A(this.B.getForeground(), this.B.getBackground(), 0.5D));
      return this.A;
    }
  }

  public static class _B
    implements Icon
  {
    private boolean B;
    private int A;

    public _B(boolean paramBoolean, int paramInt)
    {
      this.B = paramBoolean;
      this.A = paramInt;
    }

    public void paintIcon(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2)
    {
      Color localColor = paramComponent == null ? Color.GRAY : paramComponent.getBackground();
      int i = this.A / 2;
      int j = this.B ? i : -i;
      paramInt2 = paramInt2 + 5 * this.A / 6 + (this.B ? -j : 0);
      int k = this.B ? 1 : -1;
      paramGraphics.translate(paramInt1, paramInt2);
      paramGraphics.setColor(localColor.darker());
      paramGraphics.drawLine(i / 2, j, 0, 0);
      paramGraphics.drawLine(i / 2, j + k, 0, k);
      paramGraphics.setColor(localColor.brighter());
      paramGraphics.drawLine(i / 2, j, i, 0);
      paramGraphics.drawLine(i / 2, j + k, i, k);
      if (this.B)
        paramGraphics.setColor(localColor.darker().darker());
      else
        paramGraphics.setColor(localColor.brighter().brighter());
      paramGraphics.drawLine(i, 0, 0, 0);
      paramGraphics.setColor(localColor);
      paramGraphics.translate(-paramInt1, -paramInt2);
    }

    public int getIconWidth()
    {
      return this.A;
    }

    public int getIconHeight()
    {
      return this.A;
    }
  }

  public static class _C
    implements TableCellRenderer
  {
    private TableCellRenderer A;

    public _C(TableCellRenderer paramTableCellRenderer)
    {
      this.A = paramTableCellRenderer;
    }

    public Component getTableCellRendererComponent(JTable paramJTable, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2)
    {
      Component localComponent = this.A.getTableCellRendererComponent(paramJTable, paramObject, paramBoolean1, paramBoolean2, paramInt1, paramInt2);
      if ((localComponent instanceof JLabel))
      {
        JLabel localJLabel = (JLabel)localComponent;
        localJLabel.setHorizontalTextPosition(2);
        int i = paramJTable.convertColumnIndexToModel(paramInt2);
        TableModel localTableModel = paramJTable.getModel();
        int j = 0;
        if ((localTableModel instanceof B))
          j = ((B)localTableModel).A(i);
        if ((localTableModel instanceof T._B))
          j = ((T._B)localTableModel).A(i);
        if (j != 0)
          localJLabel.setIcon(new F._B(j == 1, localJLabel.getFont().getSize()));
        else
          localJLabel.setIcon(null);
      }
      return localComponent;
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.F
 * JD-Core Version:    0.6.2
 */