package com.biotools.poker.C;

import com.biotools.A.B;
import com.biotools.A.F;
import com.biotools.A.I;
import com.biotools.B.K;
import com.biotools.B.P;
import com.biotools.poker.E;
import com.biotools.poker.G.R;
import com.biotools.poker.G.T;
import com.biotools.poker.G.Z;
import com.biotools.poker.PokerApp;
import com.biotools.poker.R.A;
import com.biotools.poker.R.U;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

public class D extends V
  implements TreeSelectionListener
{
  private static final String p = "unselected";
  private static final String À = "unfinished";
  private static final String Æ = "settings";
  private M v;
  private JButton q;
  private JButton Á;
  private JButton t;
  private JButton u;
  private JButton w;
  private JButton µ;
  private JButton r;
  private JTree ¢;
  private DefaultMutableTreeNode ¥ = null;
  private HashMap ª;
  private DefaultTreeModel z;
  private _C £;
  private _C Â;
  private DefaultMutableTreeNode º;
  private JPanel Å;
  private CardLayout s;
  private L Ã;
  private C ¤;
  private N Ä;

  public D()
  {
    setLayout(null);
    Component localComponent = Ì();
    add(localComponent);
    localComponent.setBounds(G.Z);
    add(A());
    add(z(), "Center");
    z().setBounds(G.E);
    add(º());
    º().setBounds(G.j.x, G.j.y, 320, 42);
    add(Ã());
    Ã().setBounds(G.l.x, G.l.y, 158, 33);
    add(Î());
    Î().setBounds(G.l.x, G.l.y, 158, 33);
    Î().setVisible(false);
    À();
    this.¢.scrollRowToVisible(0);
    ª();
    addComponentListener(new ComponentAdapter()
    {
      public void componentShown(ComponentEvent paramAnonymousComponentEvent)
      {
        D.this.º().G();
        D.this.ª();
      }
    });
    x();
  }

  private void x()
  {
    MouseAdapter local2 = new MouseAdapter()
    {
      public void mousePressed(MouseEvent paramAnonymousMouseEvent)
      {
        int i = D.this.¢.getRowForLocation(paramAnonymousMouseEvent.getX(), paramAnonymousMouseEvent.getY());
        TreePath localTreePath = D.this.¢.getPathForLocation(paramAnonymousMouseEvent.getX(), paramAnonymousMouseEvent.getY());
        if ((i != -1) && (paramAnonymousMouseEvent.getClickCount() == 2))
        {
          TreeNode localTreeNode = (TreeNode)localTreePath.getLastPathComponent();
          D.this.A((DefaultMutableTreeNode)localTreeNode);
          D.this.Ð();
        }
      }
    };
    this.¢.addMouseListener(local2);
  }

  public File B()
  {
    return E.K("pix/lobby/L_tournament.png");
  }

  public Point G()
  {
    return new Point(236, 53);
  }

  private JButton Ã()
  {
    if (this.q == null)
    {
      this.q = new K("start-game.png", E.D("TournamentLobby.StartGameDescription"));
      this.q.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          D.this.Ð();
        }
      });
    }
    return this.q;
  }

  private void Ð()
  {
    if (PokerApp.Ȅ().X(true))
      y();
    K();
  }

  private JButton Î()
  {
    if (this.Á == null)
    {
      this.Á = new K("resume-unfinished.png", E.D("TournamentLobby.ResumeUnfinishedDescription"));
      this.Á.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          D.this.Ð();
        }
      });
    }
    return this.Á;
  }

  private M º()
  {
    if (this.v == null)
    {
      this.v = new M();
      this.v.setOpaque(false);
      this.v.B(new ChangeListener()
      {
        public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
        {
          String str = D.this.v.I();
        }
      });
      this.v.F().setForeground(Color.WHITE);
    }
    return this.v;
  }

  private L Ç()
  {
    if (this.Ã == null)
      this.Ã = new L(this);
    return this.Ã;
  }

  private C Â()
  {
    if (this.¤ == null)
      this.¤ = new C(this);
    return this.¤;
  }

  private N £()
  {
    if (this.Ä == null)
      this.Ä = new N();
    return this.Ä;
  }

  private JPanel z()
  {
    if (this.Å == null)
    {
      this.Å = new JPanel();
      this.Å.setOpaque(false);
      this.Å.setLayout(Å());
      this.Å.add(Ç(), "settings");
      this.Å.add(Â(), "unfinished");
      this.Å.add(£(), "unselected");
    }
    return this.Å;
  }

  private CardLayout Å()
  {
    if (this.s == null)
      this.s = new CardLayout();
    return this.s;
  }

  private void Ñ()
  {
    File localFile = E.d();
    File[] arrayOfFile = localFile.listFiles();
    for (int i = 0; i < arrayOfFile.length; i++)
      if (arrayOfFile[i].getName().endsWith(".xml"))
        try
        {
          T localT = T.C(arrayOfFile[i]);
          if (localT != null)
            B(localT);
        }
        catch (Exception localException)
        {
          I.A(localException);
        }
  }

  public void ª()
  {
    E.H("START: loadUnfinishedTourneys() " + F.B());
    this.Â.removeAllChildren();
    Object localObject1;
    Object localObject2;
    for (int i = 0; i < U.K().size(); i++)
    {
      localObject1 = U.A(i);
      if (((U)localObject1).X())
      {
        localObject2 = (A)localObject1;
        R localR = ((A)localObject2).b();
        if ((localR != null) && (!localR.T()) && (localR.U() == 2))
          A(localR);
      }
    }
    if (this.Â.getChildCount() > 0)
      this.¢.expandPath(new TreePath(this.Â.getPath()));
    this.z.reload(this.Â);
    Enumeration localEnumeration = this.Â.breadthFirstEnumeration();
    while (localEnumeration.hasMoreElements())
    {
      localObject1 = localEnumeration.nextElement();
      if ((localObject1 instanceof _C))
      {
        localObject2 = new TreePath(((_C)localObject1).getPath());
        this.¢.expandPath((TreePath)localObject2);
      }
    }
    E.H("ENDDD: loadUnfinishedTourneys() " + F.B());
  }

  public _C A(Z paramZ, _C param_C)
  {
    Z localZ = paramZ.A();
    if (param_C.A().equals(paramZ.D()))
    {
      if (localZ != null)
        return A(localZ, param_C);
      return param_C;
    }
    for (int i = 0; i < param_C.getChildCount(); i++)
      if ((param_C.getChildAt(i) instanceof _C))
      {
        _C local_C2 = (_C)param_C.getChildAt(i);
        if (local_C2.A().equals(paramZ.D()))
          return A(paramZ, local_C2);
      }
    _C local_C1 = new _C(paramZ);
    this.z.insertNodeInto(local_C1, param_C, param_C.getChildCount());
    if (localZ != null)
      return A(localZ, local_C1);
    return local_C1;
  }

  public void B(T paramT)
  {
    if (paramT == null)
      return;
    _B local_B = new _B(paramT);
    if (this.¥ == null)
      this.¥ = local_B;
    _C local_C = this.£;
    if (paramT.s() != null)
    {
      Z localZ = paramT.s();
      local_C = A(localZ, this.£);
      this.z.insertNodeInto(local_B, local_C, local_C.getChildCount());
      TreePath localTreePath = new TreePath(local_B.getPath());
      this.¢.scrollPathToVisible(localTreePath);
      this.¢.setSelectionPath(localTreePath);
    }
  }

  public void C(T paramT)
  {
    if (paramT == null)
      return;
    _B local_B = new _B(paramT);
    _C local_C = this.£;
    if (paramT.s() != null)
    {
      Z localZ = paramT.s();
      local_C = A(localZ, this.£);
      this.z.insertNodeInto(local_B, local_C, local_C.getChildCount());
    }
  }

  public void A(R paramR)
  {
    if (paramR == null)
      return;
    D._A local_A = new D._A(this, paramR);
    Z localZ = paramR.Q().s();
    _C local_C = this.Â;
    if (localZ != null)
      local_C = A(localZ, this.Â);
    this.z.insertNodeInto(local_A, local_C, local_C.getChildCount());
  }

  private Component Ì()
  {
    this.£ = new _C(E.D("TournamentLobby.Tournaments"));
    this.Â = new _C(E.D("TournamentLobby.Unfinished"));
    this.£.add(this.Â);
    this.ª = new HashMap();
    this.z = new DefaultTreeModel(this.£);
    this.¢ = new JTree(this.z);
    JScrollPane localJScrollPane = J.A(this.¢);
    Ñ();
    A(this.¢);
    this.¢.addTreeSelectionListener(this);
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.setOpaque(false);
    localJPanel.add(Æ(), "West");
    localJPanel.add(localJScrollPane, "Center");
    return localJPanel;
  }

  private JPanel Æ()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setOpaque(false);
    localJPanel.setLayout(new BoxLayout(localJPanel, 1));
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.add(Ë());
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.add(É());
    localJPanel.add(¥());
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.add(Box.createVerticalStrut(25));
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.add(¢());
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.add(Ä());
    return localJPanel;
  }

  private JButton É()
  {
    if (this.u == null)
    {
      this.u = new com.biotools.B.J("del.png", E.D("TournamentLobby.DeleteDescription"));
      this.u.setVisible(true);
      this.u.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          if ((D.this.º instanceof D._B))
            D.this.Ç().S();
          else if ((D.this.º instanceof D._A))
            D.this.Â().E();
        }
      });
    }
    return this.u;
  }

  private JButton ¥()
  {
    if (this.r == null)
    {
      this.r = new com.biotools.B.J("prefs.png", E.D("TournamentLobby.RestoreDescription"));
      this.r.setVisible(false);
      this.r.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          D.this.Ê();
        }
      });
    }
    return this.r;
  }

  private void Ê()
  {
    if (È() != null)
    {
      Object[] arrayOfObject = { È().S() };
      int i = JOptionPane.showConfirmDialog(this, E.A("TournamentLobby.RestoreToDefaultDescriptionPattern", arrayOfObject), E.D("TournamentLobby.RestoreToDefault"), 0);
      if (i == 0)
        Í();
    }
  }

  private void Í()
  {
    T localT = È();
    File localFile1 = localT.G();
    File localFile2 = A(localT);
    if (localFile2 != null)
    {
      try
      {
        B.B(localFile2, localFile1);
      }
      catch (IOException localIOException)
      {
        E.H("Error restoring file");
      }
      Ç().C(false);
      int i = Ç().Ç();
      Á();
      localT = T.C(localFile1);
      B(localT);
      Ç().A(i);
    }
  }

  private File A(T paramT)
  {
    File localFile1 = paramT.G();
    String str = localFile1.getName();
    File localFile2 = E.K("logs/tourneys/tourneys");
    File[] arrayOfFile = localFile2.listFiles();
    for (int i = 0; i < arrayOfFile.length; i++)
    {
      File localFile3 = arrayOfFile[i];
      if (localFile3.getName().equals(str))
        return localFile3;
    }
    return null;
  }

  private JButton Ë()
  {
    if (this.t == null)
    {
      this.t = new com.biotools.B.J("add.png", E.D("TournamentLobby.AddDescription"));
      this.t.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          D.this.Ç().À();
        }
      });
    }
    return this.t;
  }

  private JButton ¢()
  {
    if (this.w == null)
    {
      this.w = new com.biotools.B.J("import.png", E.D("TournamentLobby.ImportDescription"));
      this.w.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          D.this.Ç().Ý();
        }
      });
    }
    return this.w;
  }

  private JButton Ä()
  {
    if (this.µ == null)
    {
      this.µ = new com.biotools.B.J("export.png", E.D("TournamentLobby.ExportDescription"));
      this.µ.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          D.this.Ç().D();
        }
      });
    }
    return this.µ;
  }

  private T È()
  {
    if (this.º == null)
      return null;
    if ((this.º instanceof _B))
      return ((_B)this.º).A;
    if ((this.º instanceof D._A))
      return ((D._A)this.º).A.Q();
    return null;
  }

  public void valueChanged(TreeSelectionEvent paramTreeSelectionEvent)
  {
    DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)this.¢.getLastSelectedPathComponent();
    A(localDefaultMutableTreeNode);
  }

  public void A(DefaultMutableTreeNode paramDefaultMutableTreeNode)
  {
    this.º = paramDefaultMutableTreeNode;
    if (paramDefaultMutableTreeNode == null)
    {
      ¤();
      return;
    }
    if ((paramDefaultMutableTreeNode instanceof _B))
    {
      Ç().C(((_B)paramDefaultMutableTreeNode).A);
      Ï();
      Ä().setEnabled(true);
      º().setEnabled(true);
      Å().show(z(), "settings");
      Ã().setVisible(true);
      Î().setVisible(false);
      º().setVisible(true);
      this.¥ = paramDefaultMutableTreeNode;
    }
    else if ((paramDefaultMutableTreeNode instanceof D._A))
    {
      Ç().U();
      T localT = ((D._A)paramDefaultMutableTreeNode).A.Q();
      Â().A(localT);
      Â().F(((D._A)paramDefaultMutableTreeNode).A);
      º().A(((D._A)paramDefaultMutableTreeNode).A.£());
      º().setEnabled(false);
      Å().show(z(), "unfinished");
      Ã().setVisible(false);
      Î().setVisible(true);
      º().setVisible(true);
      D(true);
      Ä().setEnabled(false);
      this.¥ = paramDefaultMutableTreeNode;
    }
    else
    {
      ¤();
    }
  }

  private void Ï()
  {
    if (A(È()) != null)
      D(false);
    else
      D(true);
  }

  private void D(boolean paramBoolean)
  {
    É().setVisible(paramBoolean);
    ¥().setVisible(!paramBoolean);
  }

  public void À()
  {
    if (this.¥ != null)
    {
      TreePath localTreePath = new TreePath(this.¥.getPath());
      this.¢.scrollPathToVisible(localTreePath);
      this.¢.setSelectionPath(localTreePath);
      A(this.¥);
    }
  }

  public void ¤()
  {
    Å().show(z(), "unselected");
    Ã().setVisible(false);
    Î().setVisible(false);
  }

  public void Á()
  {
    this.z.removeNodeFromParent(this.¥);
  }

  public void A(JTree paramJTree)
  {
    int i = 0;
    while (i < paramJTree.getRowCount())
      paramJTree.expandRow(i++);
  }

  private void y()
  {
    assert (this.º != null);
    String str = º().I();
    if (str == null)
    {
      JOptionPane.showMessageDialog(this, E.D("TournamentLobby.SelectProfileDescription"), E.D("TournamentLobby.SelectProfile"), 0);
      return;
    }
    if (((this.º instanceof D._A)) && (!((D._A)this.º).A.B().exists()))
    {
      JOptionPane.showMessageDialog(this, E.D("TournamentLobby.LaunchErrorDescription"), E.D("TournamentLobby.LaunchError"), 0);
      À();
      ª();
      return;
    }
    Cursor localCursor = getCursor();
    setCursor(Cursor.getPredefinedCursor(3));
    µ();
    setCursor(localCursor);
  }

  private void µ()
  {
    assert (this.º != null);
    Object localObject1;
    if ((this.º instanceof _B))
    {
      localObject1 = (_B)this.º;
      if (!Ç().A())
      {
        int i = Ç().Þ();
        localObject2 = Ç().C(i);
        localObject3 = new Object[] { new Integer(i + 1) };
        JOptionPane.showMessageDialog(this, "<html>" + E.A("TournamentLobby.InvalidTournamentStructureDescriptionPattern", (Object[])localObject3) + "<br>" + (String)localObject2, E.D("TournamentLobby.InvalidTournamentStructure"), 0);
        return;
      }
      P.A(E.D("TournamentLobby.ConfiguringTournamentStructure"));
      boolean bool = Ç().õ();
      Ç().ü();
      Object localObject2 = Ç().f();
      if (!bool)
        Ç().¥();
      Object localObject3 = º().I();
      PokerApp.Ȅ().y((String)localObject3);
      PokerApp.Ȅ().A((T)localObject2, Ç().O());
    }
    else if ((this.º instanceof D._A))
    {
      localObject1 = R.A(((D._A)this.º).A.B());
      if (localObject1 != null)
        PokerApp.Ȅ().A((R)localObject1);
    }
  }

  private class _B extends DefaultMutableTreeNode
  {
    public T A;

    public _B(T arg2)
    {
      Object localObject;
      this.A = localObject;
    }

    public String toString()
    {
      return this.A.ª();
    }
  }

  public class _C extends DefaultMutableTreeNode
  {
    String A;

    public _C(Z arg2)
    {
      super();
      this.A = localObject.D();
    }

    public _C(String arg2)
    {
      super();
      this.A = localObject;
    }

    public String toString()
    {
      return this.A;
    }

    public String A()
    {
      return this.A;
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.D
 * JD-Core Version:    0.6.2
 */