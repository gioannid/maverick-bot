package com.biotools.poker.C;

import com.biotools.B.K;
import com.biotools.poker.E;
import com.biotools.poker.F.J;
import com.biotools.poker.F.O;
import com.biotools.poker.PokerApp;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Insets;
import java.awt.MediaTracker;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public abstract class V extends JPanel
  implements MouseListener, MouseMotionListener
{
  private static final String A = "pix/lobby/";
  private static Image I = null;
  private Image D;
  private Image F;
  private JButton G;
  private ArrayList E;
  private O J;
  private O H;
  private O B;
  private O C;

  public V()
  {
    H();
    this.E = new ArrayList();
    this.E.add(J());
    this.E.add(I());
    this.E.add(E());
    this.E.add(D());
    addMouseListener(this);
    addMouseMotionListener(this);
    addComponentListener(new ComponentAdapter()
    {
      public void componentShown(ComponentEvent paramAnonymousComponentEvent)
      {
        V.this.K();
      }
    });
  }

  public void K()
  {
    A().setVisible(PokerApp.Ȅ().ɕ());
  }

  public Image A(File paramFile)
  {
    Image localImage = Toolkit.getDefaultToolkit().getImage(paramFile.getPath());
    MediaTracker localMediaTracker = new MediaTracker(this);
    localMediaTracker.addImage(localImage, 0);
    try
    {
      localMediaTracker.waitForAll();
    }
    catch (InterruptedException localInterruptedException)
    {
    }
    return localImage;
  }

  private Image H()
  {
    if (I == null)
      I = A(F());
    return I;
  }

  private Image C()
  {
    if (this.F == null)
      this.F = A(B());
    return this.F;
  }

  protected static void A(JButton paramJButton)
  {
    paramJButton.setOpaque(false);
    paramJButton.setFocusable(false);
    paramJButton.setMargin(new Insets(0, 0, 0, 0));
    paramJButton.setBorder(BorderFactory.createEmptyBorder());
    paramJButton.setBorderPainted(false);
    paramJButton.setContentAreaFilled(false);
  }

  private O J()
  {
    if (this.H == null)
    {
      this.H = new O(null, E.K("pix/lobby/01-ring_games.png"), PokerApp.Ȅ());
      this.H.A(G.r);
      this.H.B(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          PokerApp.Ȅ().ȍ();
        }
      });
    }
    return this.H;
  }

  private O I()
  {
    if (this.B == null)
    {
      this.B = new O(null, E.K("pix/lobby/02-tournaments.png"), PokerApp.Ȅ());
      this.B.A(G.B);
      this.B.B(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          PokerApp.Ȅ().ʇ();
        }
      });
    }
    return this.B;
  }

  private O E()
  {
    if (this.C == null)
    {
      this.C = new O(null, E.K("pix/lobby/03-poker_academy_online.png"), PokerApp.Ȅ());
      this.C.A(G.d);
      this.C.B(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          PokerApp.Ȅ().ʟ();
        }
      });
    }
    return this.C;
  }

  private O D()
  {
    if (this.J == null)
    {
      this.J = new O(null, E.K("pix/lobby/10-main_lobby.png"), PokerApp.Ȅ());
      this.J.A(G.N);
      this.J.B(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          PokerApp.Ȅ().ʝ();
        }
      });
    }
    return this.J;
  }

  protected JButton A()
  {
    if (this.G == null)
    {
      this.G = new K("resume-game.png", E.D("AbstractLobby.ResumeGameToolTip"));
      this.G.setVisible(false);
      this.G.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          PokerApp.Ȅ().ʎ();
        }
      });
      Point localPoint = G.S;
      this.G.setBounds(localPoint.x, localPoint.y, 158, 33);
    }
    return this.G;
  }

  public void paintComponent(Graphics paramGraphics)
  {
    paramGraphics.drawImage(H(), 0, 0, null);
    if (!E.Ð())
    {
      localObject = G();
      paramGraphics.drawImage(C(), ((Point)localObject).x, ((Point)localObject).y, null);
    }
    Object localObject = (Graphics2D)paramGraphics;
    for (int i = 0; i < this.E.size(); i++)
    {
      J localJ = (J)this.E.get(i);
      localJ.I((Graphics2D)localObject);
    }
  }

  protected JLabel A(String paramString)
  {
    JLabel localJLabel = new JLabel(paramString, 4);
    localJLabel.setForeground(Color.WHITE);
    return localJLabel;
  }

  protected JLabel A(String paramString, int paramInt)
  {
    JLabel localJLabel = new JLabel(paramString, paramInt);
    localJLabel.setForeground(Color.WHITE);
    return localJLabel;
  }

  public void mouseReleased(MouseEvent paramMouseEvent)
  {
    for (int i = 0; i < this.E.size(); i++)
    {
      J localJ = (J)this.E.get(i);
      if (localJ.E(paramMouseEvent.getX(), paramMouseEvent.getY()))
        repaint();
    }
  }

  public void mouseMoved(MouseEvent paramMouseEvent)
  {
    for (int i = 0; i < this.E.size(); i++)
    {
      J localJ = (J)this.E.get(i);
      if (localJ.G(paramMouseEvent.getX(), paramMouseEvent.getY()))
        repaint(5L);
    }
  }

  public void mouseDragged(MouseEvent paramMouseEvent)
  {
    for (int i = 0; i < this.E.size(); i++)
    {
      J localJ = (J)this.E.get(i);
      if (localJ.G(paramMouseEvent.getX(), paramMouseEvent.getY()))
        repaint(5L);
    }
  }

  public void mouseClicked(MouseEvent paramMouseEvent)
  {
  }

  public void mouseEntered(MouseEvent paramMouseEvent)
  {
  }

  public void mouseExited(MouseEvent paramMouseEvent)
  {
  }

  public void mousePressed(MouseEvent paramMouseEvent)
  {
    for (int i = 0; i < this.E.size(); i++)
    {
      J localJ = (J)this.E.get(i);
      if (localJ.I(paramMouseEvent.getX(), paramMouseEvent.getY()))
        repaint();
    }
  }

  public abstract File B();

  public abstract Point G();

  private File F()
  {
    if (E.Ú())
      return E.Ð() ? E.K("pix/lobby/compact_L_background_std.png") : E.K("pix/lobby/L_background_std.png");
    return E.Ð() ? E.K("pix/lobby/compact_L_background.png") : E.K("pix/lobby/L_background.png");
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.C.V
 * JD-Core Version:    0.6.2
 */