package com.biotools.poker.H;

import com.biotools.poker.E;
import com.biotools.poker.PokerApp;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

public class K extends AbstractAction
{
  private int A;

  public K(int paramInt)
  {
    super(E.D("Actions.SetBankroll"));
    this.A = paramInt;
    putValue("ShortDescription", E.D("Actions.SetBankrollDescription"));
    setEnabled(PokerApp.Ȅ().ʐ().H(paramInt));
    if ((PokerApp.Ȅ().Ǳ()) || (PokerApp.Ȅ().ʔ()))
      setEnabled(false);
  }

  public void actionPerformed(ActionEvent paramActionEvent)
  {
    PokerApp.Ȅ().p(this.A);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.H.K
 * JD-Core Version:    0.6.2
 */