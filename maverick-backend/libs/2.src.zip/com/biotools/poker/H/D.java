package com.biotools.poker.H;

import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JCheckBoxMenuItem;

public class D extends JCheckBoxMenuItem
  implements ActionListener
{
  private String A;
  boolean B;

  public D(String paramString1, String paramString2, String paramString3, boolean paramBoolean)
  {
    super(paramString1);
    this.A = paramString3;
    this.B = paramBoolean;
    setSelected(A());
    setToolTipText(paramString2);
    addActionListener(this);
  }

  public boolean A()
  {
    return E.£().getBoolean(this.A, this.B);
  }

  public void actionPerformed(ActionEvent paramActionEvent)
  {
    E.£().putBoolean(this.A, isSelected());
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.H.D
 * JD-Core Version:    0.6.2
 */