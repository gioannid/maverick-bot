package com.biotools.poker.H;

import com.biotools.poker.E;
import com.biotools.poker.PokerApp;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

public class I extends AbstractAction
{
  private int A;

  public I(int paramInt)
  {
    super(E.D("Actions.SetButton"));
    this.A = paramInt;
    putValue("ShortDescription", E.D("Actions.SetButtonDescription"));
    if ((PokerApp.Ȅ().Ǳ()) || (PokerApp.Ȅ().ʔ()))
      setEnabled(false);
  }

  public void actionPerformed(ActionEvent paramActionEvent)
  {
    PokerApp.Ȅ().A(this.A, false);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.H.I
 * JD-Core Version:    0.6.2
 */