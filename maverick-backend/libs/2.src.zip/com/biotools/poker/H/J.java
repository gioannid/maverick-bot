package com.biotools.poker.H;

import com.biotools.poker.E;
import com.biotools.poker.PokerApp;
import com.biotools.poker.Q.K;
import com.biotools.poker.R.R;
import com.biotools.poker.R.Z;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

public class J extends AbstractAction
{
  private int A;

  public J(int paramInt)
  {
    this.A = paramInt;
    Object[] arrayOfObject = { A() };
    putValue("Name", E.A("Actions.ShowPlayerStatsNamePattern", arrayOfObject));
    putValue("ShortDescription", E.A("Actions.ShowPlayerStatsDescriptionPattern", arrayOfObject));
  }

  public void actionPerformed(ActionEvent paramActionEvent)
  {
    R localR = PokerApp.Ȅ().Ȇ();
    Z localZ = Z.A(Z.A(PokerApp.Ȅ().ɴ(), A()));
    if (E.Ú())
    {
      localR.B(localZ, true);
      localR.setVisible(true);
    }
    else
    {
      localR.A(localZ, true);
    }
  }

  private String A()
  {
    return PokerApp.Ȅ().ʐ().F(this.A);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.H.J
 * JD-Core Version:    0.6.2
 */