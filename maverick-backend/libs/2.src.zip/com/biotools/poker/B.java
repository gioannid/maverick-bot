package com.biotools.poker;

import com.biotools.A.F;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.F.U;
import com.biotools.poker.G.A.I;
import com.biotools.poker.P.O;
import com.biotools.poker.P.R;
import com.biotools.poker.P.S;
import com.biotools.poker.P._;
import com.biotools.poker.Q.K;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.KeyStroke;
import javax.swing.MenuElement;

public class B extends JMenuBar
{
  protected PokerApp F;
  JMenu C = new JMenu(E.D("PokerAppMenu.LobbyMenu"));
  JMenu H = new JMenu(E.D("PokerAppMenu.OptionsMenu"));
  JMenu G = new JMenu(E.D("PokerAppMenu.DealerMenu"));
  JMenu K = new JMenu(E.D("PokerAppMenu.TableMenu"));
  JMenu L = new JMenu(E.D("PokerAppMenu.WindowMenu"));
  JMenu N = new JMenu(E.D("PokerAppMenu.HelpMenu"));
  JMenuItem E;
  JMenuItem M;
  JMenuItem A;
  JMenuItem I;
  JMenu J = new JMenu(E.D("PokerAppMenu.SetButton"));
  JMenuItem B;
  JMenuItem D;

  public B(PokerApp paramPokerApp)
  {
    this.F = paramPokerApp;
    add(A());
    add(F());
    if (!E.Â())
    {
      add(G());
      add(N());
      add(H());
    }
    add(a());
    f();
  }

  public B(PokerApp paramPokerApp, JPopupMenu paramJPopupMenu)
  {
    this.F = paramPokerApp;
    paramJPopupMenu.add(A());
    paramJPopupMenu.add(F());
    paramJPopupMenu.add(G());
    paramJPopupMenu.add(N());
    paramJPopupMenu.add(H());
    paramJPopupMenu.add(a());
    f();
  }

  protected void B(boolean paramBoolean)
  {
    A(this.H, paramBoolean);
    A(this.G, (paramBoolean) && (!this.F.Ǽ()));
    A(this.K, (paramBoolean) && (!this.F.Ǽ()) && (!this.F.ʓ()));
    C((paramBoolean) && (this.F.Ǳ()));
    D((paramBoolean) && (!this.F.Ǽ()) && (!this.F.ʓ()) && (this.F.Ǳ()));
    A((paramBoolean) && (!this.F.ʓ()) && (!this.F.Ǽ()) && (this.F.ɜ()));
  }

  public void E(boolean paramBoolean)
  {
    A(this.G, !paramBoolean);
    A(this.K, !paramBoolean);
  }

  public void D(boolean paramBoolean)
  {
    A(this.E, !paramBoolean);
    A(this.M, !paramBoolean);
    A(this.A, !paramBoolean);
    A(this.I, !paramBoolean);
    A(this.J, !paramBoolean);
  }

  private void A(JMenuItem paramJMenuItem, boolean paramBoolean)
  {
    if (paramJMenuItem != null)
      paramJMenuItem.setEnabled(paramBoolean);
  }

  protected JMenu A()
  {
    if (!E.Â())
    {
      this.C.add(o());
      this.C.addSeparator();
      this.C.add(O());
      this.C.add(s());
    }
    this.C.add(i());
    this.C.addSeparator();
    this.C.add(R());
    if (!E.¤())
    {
      this.C.addSeparator();
      this.C.add(x());
    }
    return this.C;
  }

  protected KeyStroke A(int paramInt)
  {
    return KeyStroke.getKeyStroke(paramInt, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask());
  }

  protected JMenuItem o()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.MainLobby"), 76);
    localJMenuItem.setAccelerator(A(76));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.ʝ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem O()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.RingGames"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.ȍ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem s()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.Tournaments"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.ʇ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem i()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.PokerAcademyOnline"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.ʟ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem R()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.TournamentInfo"), 73);
    localJMenuItem.setAccelerator(A(73));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.TournamentInfoToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.ȅ();
      }
    });
    this.B = localJMenuItem;
    return localJMenuItem;
  }

  protected void C(boolean paramBoolean)
  {
    A(this.B, paramBoolean);
  }

  protected boolean e()
  {
    return (this.B != null) && (this.B.isEnabled());
  }

  protected JMenuItem x()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.QuitProgram"), 81);
    localJMenuItem.setAccelerator(A(81));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.QuitProgramToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.ʠ();
      }
    });
    return localJMenuItem;
  }

  protected JMenu F()
  {
    this.H.add(E());
    this.H.add(c());
    this.H.add(w());
    this.H.add(l());
    this.H.add(v());
    this.H.add(g());
    this.H.add(j());
    this.H.add(M());
    this.H.add(r());
    this.H.add(L());
    if (E.z())
      this.H.add(b());
    this.H.addSeparator();
    this.H.add(B());
    this.H.add(K());
    this.H.add(d());
    this.H.add(u());
    this.H.add(S());
    return this.H;
  }

  protected JMenuItem w()
  {
    com.biotools.poker.H.D localD = new com.biotools.poker.H.D(E.D("PokerAppMenu.AutoDeal"), E.D("PokerAppMenu.AutoDealToolTip"), "AUTO_DEAL", this.F.ʗ());
    return localD;
  }

  protected JMenuItem l()
  {
    final JCheckBoxMenuItem localJCheckBoxMenuItem = new JCheckBoxMenuItem(E.D("PokerAppMenu.FreezeButton"), this.F.Ȑ());
    localJCheckBoxMenuItem.setToolTipText(E.D("PokerAppMenu.FreezeButtonToolTip"));
    localJCheckBoxMenuItem.addActionListener(new ActionListener()
    {
      private final JCheckBoxMenuItem val$item;

      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        E.£().putBoolean("FREEZE_BUTTON", localJCheckBoxMenuItem.isSelected());
        B.this.F.ʋ().ǋ();
      }
    });
    return localJCheckBoxMenuItem;
  }

  protected JMenuItem L()
  {
    final JCheckBoxMenuItem localJCheckBoxMenuItem = new JCheckBoxMenuItem(E.D("PokerAppMenu.4ColorDeck"), U.E());
    localJCheckBoxMenuItem.setToolTipText(E.D("PokerAppMenu.4ColorDeckToolTip"));
    localJCheckBoxMenuItem.addActionListener(new ActionListener()
    {
      private final JCheckBoxMenuItem val$item;

      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        E.£().putBoolean("FOUR_COLOR", localJCheckBoxMenuItem.isSelected());
        B.this.F.ʋ().Ǧ();
        B.this.F.ʋ().ǋ();
      }
    });
    return localJCheckBoxMenuItem;
  }

  protected JMenuItem b()
  {
    final JCheckBoxMenuItem localJCheckBoxMenuItem = new JCheckBoxMenuItem(E.D("PokerAppMenu.SuitSymbols"), E.B());
    localJCheckBoxMenuItem.setToolTipText(E.D("PokerAppMenu.SuitSymbolsToolTip"));
    localJCheckBoxMenuItem.addActionListener(new ActionListener()
    {
      private final JCheckBoxMenuItem val$item;

      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        E.D(localJCheckBoxMenuItem.isSelected());
      }
    });
    return localJCheckBoxMenuItem;
  }

  protected JMenuItem g()
  {
    com.biotools.poker.H.D localD = new com.biotools.poker.H.D(E.D("PokerAppMenu.MuckLosingHands"), E.D("PokerAppMenu.MuckLosingHandsToolTip"), "AUTO_MUCK", E._());
    return localD;
  }

  protected JMenuItem j()
  {
    com.biotools.poker.H.D localD = new com.biotools.poker.H.D(E.D("PokerAppMenu.Peeking"), E.D("PokerAppMenu.PeekingToolTip"), "PEEKING", this.F.ɡ());
    return localD;
  }

  protected JMenuItem r()
  {
    final JCheckBoxMenuItem localJCheckBoxMenuItem = new JCheckBoxMenuItem(E.D("PokerAppMenu.PlayFaceDown"), this.F.ʁ());
    localJCheckBoxMenuItem.setToolTipText(E.D("PokerAppMenu.PlayFaceDownToolTip"));
    localJCheckBoxMenuItem.addActionListener(new ActionListener()
    {
      private final JCheckBoxMenuItem val$item;

      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        E.£().putBoolean("FACE_DOWN", localJCheckBoxMenuItem.isSelected());
        B.this.F.ʖ();
      }
    });
    return localJCheckBoxMenuItem;
  }

  protected JMenuItem M()
  {
    final JCheckBoxMenuItem localJCheckBoxMenuItem = new JCheckBoxMenuItem(E.D("PokerAppMenu.PlayAllFaceUp"), this.F.Ȁ());
    localJCheckBoxMenuItem.setToolTipText(E.D("PokerAppMenu.PlayAllFaceUpToolTip"));
    localJCheckBoxMenuItem.addActionListener(new ActionListener()
    {
      private final JCheckBoxMenuItem val$item;

      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        E.£().putBoolean("ALL_FACE_UP", localJCheckBoxMenuItem.isSelected());
        if (B.this.F.Ȁ())
          B.this.F.ʋ().ǎ();
        else
          B.this.F.ʋ().L(true);
      }
    });
    return localJCheckBoxMenuItem;
  }

  protected JMenuItem v()
  {
    final JCheckBoxMenuItem localJCheckBoxMenuItem = new JCheckBoxMenuItem(E.D("PokerAppMenu.HideNames"), E.h());
    localJCheckBoxMenuItem.setToolTipText(E.D("PokerAppMenu.HideNamesToolTip"));
    localJCheckBoxMenuItem.addActionListener(new ActionListener()
    {
      private final JCheckBoxMenuItem val$item;

      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        E.A(localJCheckBoxMenuItem.isSelected());
        B.this.F.ʋ().ǋ();
      }
    });
    return localJCheckBoxMenuItem;
  }

  protected JMenuItem c()
  {
    final JCheckBoxMenuItem localJCheckBoxMenuItem = new JCheckBoxMenuItem(E.D("PokerAppMenu.Advisor"), E.Î());
    localJCheckBoxMenuItem.setToolTipText(E.D("PokerAppMenu.AdvisorToolTip"));
    localJCheckBoxMenuItem.addActionListener(new ActionListener()
    {
      private final JCheckBoxMenuItem val$item;

      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        E.C(localJCheckBoxMenuItem.isSelected());
        B.this.F.ɿ().B(localJCheckBoxMenuItem.isSelected());
      }
    });
    return localJCheckBoxMenuItem;
  }

  protected JMenuItem E()
  {
    final JCheckBoxMenuItem localJCheckBoxMenuItem = new JCheckBoxMenuItem(E.D("PokerAppMenu.AdvanceActions"), E.l());
    localJCheckBoxMenuItem.setToolTipText(E.D("PokerAppMenu.AdvanceActionsToolTip"));
    localJCheckBoxMenuItem.addActionListener(new ActionListener()
    {
      private final JCheckBoxMenuItem val$item;

      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        E.B(localJCheckBoxMenuItem.isSelected());
      }
    });
    return localJCheckBoxMenuItem;
  }

  protected JMenuItem K()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.BackgroundImage"));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.BackgroundImageToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.A(new com.biotools.poker.P.B());
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem B()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.AnimationAndSound"));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.AnimationAndSoundToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.A(new com.biotools.poker.P.D());
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem u()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.EditThrottles"));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.EditThrottlesToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.A(new com.biotools.poker.P.E());
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem d()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.EditHotKeys"));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.EditHotKeysToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.A(new R());
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem S()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.WindowOptions"));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.WindowOptionsToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.A(new O());
      }
    });
    return localJMenuItem;
  }

  protected JMenu G()
  {
    this.G.add(V());
    this.G.add(C());
    this.G.addSeparator();
    this.G.add(z());
    this.G.addSeparator();
    this.G.add(Y());
    return this.G;
  }

  protected JMenuItem V()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.DealHand"), 68);
    localJMenuItem.setAccelerator(A(68));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.DealHandToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.ǰ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem C()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.AbortHand"), 65);
    localJMenuItem.setAccelerator(A(65));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.AbortHandToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.ɓ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem z()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.ReplayHand"), 82);
    localJMenuItem.setAccelerator(A(82));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.ReplayHandToolTip"));
    localJMenuItem.setMnemonic('R');
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.Ȏ();
      }
    });
    this.D = localJMenuItem;
    return localJMenuItem;
  }

  protected void A(boolean paramBoolean)
  {
    A(this.D, paramBoolean);
  }

  protected JMenuItem Y()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.DealerOptions"));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.DealerOptionsToolTip"));
    localJMenuItem.setMnemonic('O');
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        if (!E.Ú())
          B.this.F.A(new S());
      }
    });
    return localJMenuItem;
  }

  protected JMenu N()
  {
    this.M = D();
    this.K.add(this.M);
    this.E = y();
    this.K.add(this.E);
    this.K.addSeparator();
    this.K.add(n());
    this.A = p();
    this.K.add(this.A);
    this.I = h();
    this.K.add(this.I);
    return this.K;
  }

  protected JMenuItem D()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.ShuffleSeats"));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.ShuffleSeatsToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        if (B.this.F.Ǽ())
          return;
        if (B.this.F.ɮ())
        {
          for (int i = 1; i < 10; i++)
            B.this.F.ʐ().B(i, 1 + (int)(Math.random() * 9.0D));
          B.this.n();
          B.this.F.ʋ().ǋ();
        }
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem y()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.SaveTableAs"));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.SaveTableAsToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.ɷ();
      }
    });
    return localJMenuItem;
  }

  protected JMenu n()
  {
    this.J.removeAll();
    for (int i = 0; i < this.F.ɞ().getNumSeats(); i++)
      if (!this.F.ɞ().E(i))
        this.J.add(A(this.F.ɞ().getPlayerName(i), i));
    com.biotools.B.A.A(this.J);
    return this.J;
  }

  protected void B(int paramInt)
  {
    String str = this.F.ɞ().getPlayerName(paramInt);
    for (int i = 0; i < this.J.getItemCount(); i++)
    {
      JCheckBoxMenuItem localJCheckBoxMenuItem = (JCheckBoxMenuItem)this.J.getItem(i);
      if (localJCheckBoxMenuItem != null)
        localJCheckBoxMenuItem.setState(localJCheckBoxMenuItem.getText().equals(str));
    }
  }

  protected JMenuItem A(String paramString, final int paramInt)
  {
    JCheckBoxMenuItem localJCheckBoxMenuItem = new JCheckBoxMenuItem(paramString);
    localJCheckBoxMenuItem.addActionListener(new ActionListener()
    {
      private final int val$seat;

      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        if (B.this.F.Ǽ())
          return;
        B.this.F.A(paramInt, false);
      }
    });
    return localJCheckBoxMenuItem;
  }

  protected JMenuItem p()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.SetBankroll"), 66);
    localJMenuItem.setAccelerator(A(66));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.SetBankrollToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        if (B.this.F.Ǽ())
          return;
        B.this.F.p(PokerApp.χ);
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem h()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.SetAllBankrolls"));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.SetAllBankrollsToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        if (B.this.F.Ǽ())
          return;
        B.this.F.ȉ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem W()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.OpponentManager"), 79);
    localJMenuItem.setAccelerator(A(79));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.OpponentManagerToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        E.H("Opponent Editor: Menu Clicked " + F.B());
        B.this.F.ɨ();
      }
    });
    return localJMenuItem;
  }

  protected JMenu H()
  {
    this.L.add(T());
    this.L.add(Q());
    this.L.add(t());
    this.L.add(J());
    this.L.add(W());
    return this.L;
  }

  protected JMenuItem T()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.HandEvaluator"), 69);
    localJMenuItem.setAccelerator(A(69));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.HandEvaluatorToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.ɛ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem J()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.TournamentClock"), 84);
    localJMenuItem.setAccelerator(A(84));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.TournamentClockToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        I.K().setVisible(true);
        E.q();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem t()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.PlayerStatistics"), 83);
    localJMenuItem.setAccelerator(A(83));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.PlayerStatisticsToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.ȕ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem Q()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.ShowdownCalculator"), 67);
    localJMenuItem.setAccelerator(A(67));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.ShowdownCalculatorToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.ɥ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem Z()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.HandHistory"), 71);
    localJMenuItem.setAccelerator(A(71));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.HandHistoryToolTip"));
    localJMenuItem.addActionListener(new B.34(this));
    return localJMenuItem;
  }

  protected JMenu a()
  {
    this.N.add(X());
    if (!E.p())
    {
      this.N.add(q());
    }
    else
    {
      this.N.addSeparator();
      this.N.add(I());
    }
    this.N.addSeparator();
    this.N.add(U());
    this.N.add(k());
    this.N.addSeparator();
    this.N.add(m());
    this.N.addSeparator();
    this.N.add(P());
    return this.N;
  }

  protected JMenuItem X()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.Help"), 72);
    localJMenuItem.setAccelerator(A(72));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.HelpToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.Ȗ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem _()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.HoldemTutorial"));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.HoldemTutorialToolTip"));
    localJMenuItem.addActionListener(new B.36(this));
    return localJMenuItem;
  }

  protected JMenuItem U()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.CheckForUpdates"));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.CheckForUpdatesToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.Ȋ().Ƥ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem k()
  {
    final JCheckBoxMenuItem localJCheckBoxMenuItem = new JCheckBoxMenuItem(E.D("PokerAppMenu.UpdatesOnStartup"), this.F.ɗ());
    localJCheckBoxMenuItem.setToolTipText(E.D("PokerAppMenu.UpdatesOnStartupToolTip"));
    localJCheckBoxMenuItem.addActionListener(new ActionListener()
    {
      private final JCheckBoxMenuItem val$item;

      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        E.£().putBoolean("AUTO_UPDATE", localJCheckBoxMenuItem.isSelected());
      }
    });
    return localJCheckBoxMenuItem;
  }

  protected JMenuItem m()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.ProxySetup"));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.ProxySetupToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        _ local_ = new _(B.this.F);
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem P()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.About"));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.AboutToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.ɧ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem q()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("PokerAppMenu.Register"));
    localJMenuItem.setToolTipText(E.D("PokerAppMenu.RegisterToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.F.ɯ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem I()
  {
    JMenuItem localJMenuItem = new JMenuItem("Buy now!");
    localJMenuItem.setToolTipText("Purchase Poker Academy Pro right now!");
    localJMenuItem.addActionListener(new B.42(this));
    return localJMenuItem;
  }

  private void A(MenuElement paramMenuElement, boolean paramBoolean)
  {
    if (paramMenuElement == null)
      return;
    if ((paramMenuElement instanceof JMenuItem))
      ((JMenuItem)paramMenuElement).setEnabled(paramBoolean);
    MenuElement[] arrayOfMenuElement = paramMenuElement.getSubElements();
    for (int i = 0; i < arrayOfMenuElement.length; i++)
      A(arrayOfMenuElement[i], paramBoolean);
  }

  private void f()
  {
    setBorder(null);
    com.biotools.B.A.A(this);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.B
 * JD-Core Version:    0.6.2
 */