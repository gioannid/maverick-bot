package com.biotools.poker.I;

import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import javax.swing.JFrame;

public class B
{
  private JFrame A;
  private String B;

  public static void A()
  {
    File localFile1 = E.K("update.dat");
    if (localFile1 == null)
      return;
    int i = E.£().getInt("MEERKAT_BUILD_NUM", 0);
    E.H("Last Build Ran: " + i);
    try
    {
      BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(localFile1)));
      for (String str1 = localBufferedReader.readLine(); str1 != null; str1 = localBufferedReader.readLine())
        if (!str1.startsWith("#"))
        {
          String[] arrayOfString = str1.split(",");
          int j = Integer.parseInt(arrayOfString[0]);
          if (j > i)
          {
            String str2 = arrayOfString[1];
            File localFile2 = new File(arrayOfString[2]);
            File localFile3 = new File(E.Y() + arrayOfString[2]);
            if (str2.equals("+"))
            {
              if (localFile2.isDirectory())
              {
                E.H("COPYING  DIR: \n\t" + localFile2 + "\n\t" + localFile3);
                com.biotools.A.B.A(localFile2, localFile3);
              }
              else
              {
                E.H("COPYING FILE: \n\t" + localFile2 + "\n\t" + localFile3);
                com.biotools.A.B.B(localFile2, localFile3);
              }
            }
            else if (str2.equals("-"))
            {
              if (localFile2.exists())
              {
                E.H("REMOVING FILE: \n\t" + localFile2);
                localFile2.delete();
              }
              if (localFile3.exists())
              {
                E.H("REMOVING FILE: \n\t" + localFile3);
                localFile2.delete();
              }
            }
          }
        }
      localBufferedReader.close();
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
    E.£().putInt("MEERKAT_BUILD_NUM", 197);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.I.B
 * JD-Core Version:    0.6.2
 */