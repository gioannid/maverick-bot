package com.biotools.poker.I;

import com.biotools.B.G;
import com.biotools.B.L;
import com.biotools.B.O;
import com.biotools.poker.E;
import com.biotools.poker.F.F;
import com.biotools.poker.PokerApp;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class A extends JFrame
  implements G
{
  private static final String ʤ = "UPDATE";
  private static final String ʕ = "CHECK";
  private JPanel ʒ;
  private JPanel ʡ;
  private JPanel ʘ;
  private JPanel ʗ;
  private JPanel ʦ;
  private JPanel ʙ;
  private JPanel ʧ;
  private JPanel ʏ;
  private JPanel ʍ;
  private O ʜ;
  private JButton ʠ;
  private JLabel ʐ;
  private String ʟ;
  private int ʛ = 0;
  private boolean ʔ = false;
  private JButton ʞ;
  private F ʑ;
  private D ʋ;
  private File ʝ;
  private C ʥ;
  private A.A.A.B ʣ;
  private JButton ʖ;
  private JPanel ʓ;
  private JButton ʚ;
  private JLabel ʌ;
  private JButton ʰ;
  private JButton ʢ;
  private JTextField ʎ;
  private JButton ʨ;

  public A()
  {
    setTitle(getTitle());
    getContentPane().setLayout(new BorderLayout(4, 4));
    getContentPane().add(ƺ(), "Center");
    setResizable(false);
    setIconImage(E.¢);
    setDefaultCloseOperation(1);
    pack();
    L.B(this);
  }

  public void Ƥ()
  {
    setVisible(true);
    toFront();
  }

  private JPanel ƺ()
  {
    if (this.ʒ == null)
    {
      this.ʒ = new JPanel(new BorderLayout(4, 4));
      this.ʒ.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
      this.ʒ.add(Ƶ(), "West");
      this.ʒ.add(ƨ(), "Center");
    }
    return this.ʒ;
  }

  private JPanel ƨ()
  {
    if (this.ʗ == null)
    {
      this.ʗ = new JPanel(new BorderLayout(4, 4));
      this.ʗ.setBorder(BorderFactory.createEtchedBorder());
      this.ʗ.add(Ƣ(), "North");
      this.ʗ.add(Ƨ(), "Center");
    }
    return this.ʗ;
  }

  private O Ƨ()
  {
    if (this.ʜ == null)
    {
      this.ʜ = new O();
      this.ʜ.A(Ƴ(), "CHECK");
      this.ʜ.A(ƣ(), "UPDATE");
      this.ʜ.A(Ʊ(), "DOWNLOAD");
      this.ʜ.A(ƻ(), "INSTALL");
      this.ʜ.A(Ʒ(), "ERROR");
    }
    return this.ʜ;
  }

  private JPanel Ƣ()
  {
    if (this.ʘ == null)
    {
      JLabel localJLabel = new JLabel(getTitle(), 0);
      localJLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
      localJLabel.setFont(localJLabel.getFont().deriveFont(1));
      localJLabel.setForeground(Color.WHITE);
      this.ʘ = new JPanel(new BorderLayout(4, 4));
      this.ʘ.setBackground(Color.GRAY);
      this.ʘ.setBorder(BorderFactory.createEtchedBorder());
      this.ʘ.add(localJLabel, "Center");
    }
    return this.ʘ;
  }

  private JPanel Ƶ()
  {
    if (this.ʡ == null)
    {
      this.ʡ = new JPanel();
      this.ʡ.setLayout(new BorderLayout(8, 8));
      this.ʡ.setBackground(Color.LIGHT_GRAY);
      this.ʡ.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(), BorderFactory.createEmptyBorder(8, 8, 8, 8)));
      this.ʡ.add(ƥ(), "North");
    }
    return this.ʡ;
  }

  private JLabel ƥ()
  {
    if (this.ʐ == null)
    {
      Object[] arrayOfObject1 = { E.Ò };
      Object[] arrayOfObject2 = { new Integer(197) };
      this.ʐ = new JLabel("<html><div align=\"center\"<b>" + E.Ò() + "</b><br>" + E.A("AutoUpdater.VersionPattern", arrayOfObject1) + E.A("AutoUpdater.BuildPattern", arrayOfObject2) + "</div></html>", new ImageIcon(E.K("pix/palogo-150x129.png").getPath()), 0);
      this.ʐ.setVerticalTextPosition(3);
      this.ʐ.setHorizontalTextPosition(0);
    }
    return this.ʐ;
  }

  public String getTitle()
  {
    return E.D("AutoUpdater.AutoUpdater");
  }

  public void dispose()
  {
    ƭ().A();
    super.dispose();
  }

  public void ƴ()
  {
    Ơ();
  }

  private void Ư()
  {
    if ((Ƹ().K() != null) && (!this.ʔ))
    {
      this.ʜ.A(ƹ(), "ASK_ONCE");
      pack();
      Ƨ().A("ASK_ONCE");
      Ƥ();
      this.ʔ = true;
    }
    else if (Ƹ().L() != null)
    {
      F(Ƹ().L().toString(), null);
    }
    else
    {
      URL localURL = Ƹ().M();
      if (localURL != null)
      {
        Ƨ().A("UPDATE");
        Ƥ();
      }
      else if (isVisible())
      {
        if (Ƹ().L() != null)
          E(Ƹ().L().toString(), "CHECK");
        E(E.D("AutoUpdater.NoNewUpdatesFound"), null);
      }
    }
  }

  private synchronized void Ơ()
  {
    ƫ().setEnabled(false);
    ƭ().B();
    L.A(Ƹ(), new A.1(this));
  }

  private JButton ƫ()
  {
    if (this.ʞ == null)
    {
      this.ʞ = new JButton(E.D("AutoUpdater.CheckForUpdatesButton"));
      this.ʞ.setEnabled(true);
      this.ʞ.addActionListener(new A.2(this));
    }
    return this.ʞ;
  }

  public Image B(File paramFile)
  {
    Image localImage = Toolkit.getDefaultToolkit().getImage(paramFile.getPath());
    MediaTracker localMediaTracker = new MediaTracker(this);
    localMediaTracker.addImage(localImage, 0);
    try
    {
      localMediaTracker.waitForAll();
    }
    catch (InterruptedException localInterruptedException)
    {
    }
    return localImage;
  }

  private F ƭ()
  {
    if (this.ʑ == null)
      this.ʑ = new F(this);
    return this.ʑ;
  }

  private JPanel Ƴ()
  {
    if (this.ʦ == null)
    {
      this.ʦ = new JPanel();
      this.ʦ.setLayout(new B.A.A.B());
      this.ʦ.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
      this.ʦ.add("p center", Box.createRigidArea(new Dimension(270, 10)));
      this.ʦ.add("p center", ƫ());
      this.ʦ.add("p center vcenter", ƭ());
    }
    return this.ʦ;
  }

  private D Ƹ()
  {
    if (this.ʋ == null)
      this.ʋ = new D();
    return this.ʋ;
  }

  private File ƪ()
  {
    if (this.ʝ == null)
      try
      {
        this.ʝ = File.createTempFile("meerkatPatch", ".zip");
      }
      catch (IOException localIOException)
      {
        localIOException.printStackTrace();
      }
    return this.ʝ;
  }

  private C Ʈ()
  {
    if (this.ʥ == null)
      this.ʥ = new C(Ƹ().M(), ƪ());
    return this.ʥ;
  }

  private A.A.A.B ƽ()
  {
    if (this.ʣ == null)
    {
      this.ʣ = new A.A.A.B();
      this.ʣ.B(new A.3(this));
    }
    return this.ʣ;
  }

  private JPanel Ʊ()
  {
    if (this.ʙ == null)
    {
      this.ʙ = new JPanel();
      this.ʙ.setLayout(new B.A.A.B());
      this.ʙ.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    }
    return this.ʙ;
  }

  private void Ʀ()
  {
    URL localURL = Ƹ().M();
    if (localURL != null)
    {
      Ƨ().A("UPDATE");
      ƽ().A(Ʈ());
    }
  }

  private JButton ư()
  {
    if (this.ʖ == null)
    {
      this.ʖ = new JButton(E.D("AutoUpdater.DownloadUpdateButton"));
      this.ʖ.setEnabled(true);
      this.ʖ.addActionListener(new A.4(this));
    }
    return this.ʖ;
  }

  private JPanel ƣ()
  {
    if (this.ʓ == null)
    {
      this.ʓ = new JPanel();
      this.ʓ.setLayout(new B.A.A.B());
      this.ʓ.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
      this.ʓ.add("p center hfill", new JLabel(E.D("AutoUpdater.NewUpdateFound"), 0));
      this.ʓ.add("p center", ư());
      this.ʓ.add("p center", ƽ());
    }
    return this.ʓ;
  }

  private JButton ƾ()
  {
    if (this.ʚ == null)
    {
      this.ʚ = new JButton(E.D("AutoUpdater.QuitAndInstall"));
      this.ʚ.setEnabled(true);
      this.ʚ.addActionListener(new A.5(this));
    }
    return this.ʚ;
  }

  private void Ʋ()
  {
    if ((PokerApp.Ȅ() != null) && (PokerApp.Ȅ().ɔ().ę()) && (!PokerApp.Ȅ().ɔ().Ĭ()))
      return;
    try
    {
      if (ƪ().exists())
      {
        Runtime.getRuntime().exec(E.º() + " -jar " + this.ʝ + " " + this.ʝ);
        System.exit(0);
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      E(localException.toString(), "INSTALL");
    }
  }

  private JPanel ƻ()
  {
    if (this.ʧ == null)
    {
      this.ʧ = new JPanel();
      this.ʧ.setLayout(new B.A.A.B());
      this.ʧ.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
      this.ʧ.add("p center hfill", new JLabel(E.D("AutoUpdater.DownloadSuccessful"), 0));
      this.ʧ.add("p center", ƾ());
    }
    return this.ʧ;
  }

  private JLabel Ʃ()
  {
    if (this.ʌ == null)
      this.ʌ = new JLabel("<html><table width=\"300\"><tr><td>&nbsp;</td></tr></table>", 0);
    return this.ʌ;
  }

  private JPanel Ʒ()
  {
    if (this.ʏ == null)
    {
      this.ʏ = new JPanel();
      this.ʏ.setLayout(new B.A.A.B());
      this.ʏ.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
      this.ʏ.add("p center hfill", Ʃ());
      this.ʏ.add("p center", Ƭ());
    }
    return this.ʏ;
  }

  private void F(String paramString1, String paramString2)
  {
    Ʃ().setText("<html><table width=\"300\"><tr><td align=\"center\">" + paramString1 + "<p><br>" + E.D("AutoUpdater.ContactSupport") + "</td></tr></table></html>");
    this.ʟ = paramString2;
    this.ʜ.A("ERROR");
  }

  private void E(String paramString1, String paramString2)
  {
    Ʃ().setText("<html><table width=\"300\"><tr><td align=\"center\">" + paramString1 + "</td></tr></table></html>");
    this.ʟ = paramString2;
    this.ʜ.A("ERROR");
  }

  private JButton Ƭ()
  {
    if (this.ʰ == null)
    {
      this.ʰ = new JButton("OK");
      this.ʰ.setEnabled(true);
      this.ʰ.addActionListener(new A.6(this));
    }
    return this.ʰ;
  }

  private JPanel ƹ()
  {
    if (this.ʍ == null)
    {
      this.ʍ = new JPanel();
      this.ʍ.setLayout(new B.A.A.B());
      this.ʍ.setBorder(BorderFactory.createEmptyBorder(2, 8, 8, 8));
      String str = Ƹ().K();
      if (str.equals("REGISTER"))
      {
        this.ʍ.add("p center", new JLabel("<html><div width='300'>" + E.D("AutoUpdater.Registration") + "</center></html>", 0));
        this.ʍ.add("p center", Ƽ());
        this.ʍ.add("center", ơ());
        Ƽ().setText(E.D("AutoUpdater.RegisterNowButton"));
        ơ().setText(E.D("AutoUpdater.RegisterLaterButton"));
      }
      else if (str.equals("EMAIL_UPDATES"))
      {
        this.ʍ.add("center", new JLabel("<html><center><b>" + E.D("AutoUpdater.Newsletter") + "</b></center><br><div width='300'>" + E.D("AutoUpdater.NewsletterDescription") + "</div></html>", 0));
        this.ʍ.add("p center", new JLabel(E.D("AutoUpdater.EmailTitle")));
        this.ʍ.add("center", ƶ());
        this.ʍ.add("p center", Ƽ());
        this.ʍ.add("center", ơ());
        Ƽ().setText(E.D("AutoUpdater.OKButton"));
        ơ().setText(E.D("AutoUpdater.NoThanksButton"));
      }
    }
    return this.ʍ;
  }

  public void F(boolean paramBoolean)
  {
    String str = Ƹ().K();
    if ((paramBoolean) && (str.equals("REGISTER")))
      E.A(this, Ƹ().J().toString());
    Ƹ().A(paramBoolean, this);
  }

  private JButton Ƽ()
  {
    if (this.ʢ == null)
    {
      this.ʢ = new JButton(E.D("AutoUpdater.AcceptButton"));
      this.ʢ.setEnabled(true);
      this.ʢ.addActionListener(new A.7(this));
    }
    return this.ʢ;
  }

  public JTextField ƶ()
  {
    if (this.ʎ == null)
    {
      this.ʎ = new JTextField(20);
      this.ʎ.setEnabled(true);
    }
    return this.ʎ;
  }

  private JButton ơ()
  {
    if (this.ʨ == null)
    {
      this.ʨ = new JButton(E.D("AutoUpdater.DeclineButton"));
      this.ʨ.setEnabled(true);
      this.ʨ.addActionListener(new A.8(this));
    }
    return this.ʨ;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.I.A
 * JD-Core Version:    0.6.2
 */