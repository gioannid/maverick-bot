package com.biotools.poker.J;

import com.biotools.A.I;
import com.biotools.B.L;
import com.biotools.meerkat.Card;
import com.biotools.poker.G.R;
import com.biotools.poker.PokerApp;
import com.biotools.poker.Q.J;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class B extends JPanel
{
  private PokerApp D;
  private D E = new D();
  private F I = new F();
  private E A = new E();
  private G K = new G();
  private com.biotools.poker.G.K J = new com.biotools.poker.G.K();
  private C B;
  private C F;
  private A H = new A();
  private JFrame C;
  private com.biotools.B.B G;

  public B(PokerApp paramPokerApp)
  {
    this.D = paramPokerApp;
    setPreferredSize(new Dimension(212, 520));
  }

  public void A(Card paramCard1, Card paramCard2)
  {
    this.I.A(paramCard1, paramCard2);
  }

  public void C()
  {
    this.D.A(null);
    this.A.B();
    this.I.A(null, null);
    this.H.A();
  }

  public void C(boolean paramBoolean)
  {
    setBackground(com.biotools.B.A.M);
    setForeground(com.biotools.B.A.D);
    removeAll();
    setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(), BorderFactory.createEmptyBorder(1, 2, 1, 2)));
    J();
    revalidate();
    A(null, null);
  }

  private void J()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setBackground(com.biotools.B.A.M);
    localJPanel.setLayout(new BoxLayout(localJPanel, 1));
    if (!com.biotools.poker.E.Â())
    {
      localJPanel.add(Box.createVerticalStrut(3));
      localJPanel.add(F());
    }
    localJPanel.add(Box.createVerticalStrut(3));
    C localC1 = new C("SIDEBAR_SESSION_STATE", this.H, com.biotools.poker.E.D("SideBar.SessionStatsHeader"));
    localJPanel.add(localC1);
    localJPanel.add(Box.createVerticalStrut(2));
    this.J.setPreferredSize(new Dimension(165, 120));
    this.B = new C("SIDEBAR_TOURNEY_STATE");
    this.B.A(this.J, com.biotools.poker.E.D("SideBar.TournamentStacksHeader"));
    this.B.A(this.K, com.biotools.poker.E.D("SideBar.TournamentHeader"));
    localJPanel.add(this.B);
    localJPanel.add(Box.createVerticalStrut(2));
    this.F = new C("SIDEBAR_HANDEVAL_STATE", this.I, com.biotools.poker.E.D("SideBar.HandEvaluatorHeader"));
    localJPanel.add(this.F);
    localJPanel.add(Box.createVerticalStrut(2));
    localJPanel.add(this.E);
    localJPanel.add(Box.createVerticalStrut(2));
    B(com.biotools.poker.E.Î());
    C localC2 = new C("SIDEBAR_TRANSCRIPT_STATE", this.A, com.biotools.poker.E.D("SideBar.TranscriptHeader"));
    localC2.A(false);
    setLayout(new BorderLayout(2, 2));
    add(localJPanel, "North");
    add(localC2, "Center");
  }

  private JButton A(String paramString1, String paramString2)
  {
    ImageIcon localImageIcon1;
    ImageIcon localImageIcon2;
    try
    {
      localImageIcon1 = new ImageIcon(com.biotools.poker.E.C(paramString1 + "-off.png"));
      localImageIcon2 = new ImageIcon(com.biotools.poker.E.C(paramString1 + "-on.png"));
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      I.A("", localFileNotFoundException);
      return new JButton();
    }
    ImageIcon localImageIcon3 = A(localImageIcon2);
    JButton localJButton = new JButton(localImageIcon1);
    localJButton.setRolloverIcon(localImageIcon2);
    localJButton.setPressedIcon(localImageIcon3);
    localJButton.setToolTipText(paramString2);
    localJButton.setBackground(com.biotools.B.A.M);
    localJButton.setFocusable(false);
    localJButton.setMargin(new Insets(0, 0, 0, 0));
    localJButton.setBorder(BorderFactory.createEmptyBorder(0, 0, 3, 3));
    localJButton.setBorderPainted(false);
    localJButton.setContentAreaFilled(false);
    return localJButton;
  }

  private JComponent F()
  {
    JButton localJButton1 = A("pix/toprow-handev", com.biotools.poker.E.D("SideBar.HandEvaluatorHeader"));
    localJButton1.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.D.ɛ();
      }
    });
    JButton localJButton2 = A("pix/toprow-stats", com.biotools.poker.E.D("SideBar.PlayerStatisticsHeader"));
    localJButton2.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.D.ȕ();
      }
    });
    JButton localJButton3 = A("pix/toprow-lobby", com.biotools.poker.E.D("SideBar.ReturnToLobbyHeader"));
    localJButton3.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.D.ʃ();
      }
    });
    JButton localJButton4 = A("pix/toprow-calc", com.biotools.poker.E.D("SideBar.ShowdownCalculatorHeader"));
    localJButton4.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        B.this.D.ɥ();
      }
    });
    JPanel localJPanel = new JPanel();
    localJPanel.setBackground(com.biotools.B.A.M);
    localJPanel.setForeground(com.biotools.B.A.D);
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(localJButton3);
    if (!com.biotools.poker.E.Ú())
      localJPanel.add(localJButton1);
    localJPanel.add(localJButton4);
    localJPanel.add(localJButton2);
    localJPanel.add(Box.createHorizontalGlue());
    return localJPanel;
  }

  private ImageIcon A(ImageIcon paramImageIcon)
  {
    int i = 2;
    Image localImage = L.A(paramImageIcon.getIconWidth() + i, paramImageIcon.getIconHeight() + i);
    Graphics2D localGraphics2D = (Graphics2D)localImage.getGraphics();
    paramImageIcon.paintIcon(null, localGraphics2D, i, i);
    localGraphics2D.dispose();
    return new ImageIcon(localImage);
  }

  public com.biotools.poker.M.C A()
  {
    return this.E.J();
  }

  public D E()
  {
    return this.E;
  }

  public E G()
  {
    return this.A;
  }

  public G K()
  {
    return this.K;
  }

  public com.biotools.poker.G.K I()
  {
    return this.J;
  }

  public void E(boolean paramBoolean)
  {
    final boolean bool = paramBoolean;
    SwingUtilities.invokeLater(new Runnable()
    {
      private final boolean val$visibleVal;

      public void run()
      {
        B.this.B.setVisible(bool);
      }
    });
  }

  public void B(boolean paramBoolean)
  {
    boolean bool1 = true;
    if (PokerApp.Ȅ().Ǽ())
      bool1 = ((J)PokerApp.Ȅ().ʐ()).ê().I();
    final boolean bool2 = (paramBoolean) && (bool1);
    SwingUtilities.invokeLater(new Runnable()
    {
      private final boolean val$visibleVal;

      public void run()
      {
        B.this.E.setVisible(bool2);
      }
    });
  }

  public void D(boolean paramBoolean)
  {
    final boolean bool = paramBoolean;
    SwingUtilities.invokeLater(new Runnable()
    {
      private final boolean val$visibleVal;

      public void run()
      {
        B.this.F.setVisible(bool);
      }
    });
  }

  public void A(boolean paramBoolean)
  {
    final boolean bool1 = paramBoolean;
    if (paramBoolean)
    {
      boolean bool2 = ((J)PokerApp.Ȅ().ʐ()).ê().I();
      D(bool2);
      B((com.biotools.poker.E.Î()) && (bool2));
    }
    else
    {
      D(true);
      B(com.biotools.poker.E.Î());
    }
    SwingUtilities.invokeLater(new Runnable()
    {
      private final boolean val$visibleVal;

      public void run()
      {
        B.this.A.A(bool1);
      }
    });
  }

  public void A(R paramR)
  {
    if (paramR == null)
    {
      E(false);
    }
    else
    {
      E(true);
      I().A(paramR);
      K().A(paramR);
      this.D.A(com.biotools.poker.R.A.E(paramR.p()));
      this.H.A();
    }
  }

  public void B()
  {
    if (this.C == null)
    {
      this.C = new JFrame(com.biotools.poker.E.D("SideBar.AdviceAndInfoHeader"));
      this.C.setIconImage(com.biotools.poker.E.¢);
      this.C.getContentPane().add(this);
      com.biotools.poker.E.A("SIDEBAR", this.C);
      this.C.setDefaultCloseOperation(0);
      this.C.addWindowListener(new B.9(this));
    }
    this.C.setVisible(true);
  }

  private void D()
  {
    if (this.C != null)
      SwingUtilities.invokeLater(new B.10(this));
  }

  public void H()
  {
    if (this.C != null)
      this.C.setVisible(false);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.J.B
 * JD-Core Version:    0.6.2
 */