package com.biotools.poker.J;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.poker.D.G;
import com.biotools.poker.N.B.K;
import com.biotools.poker.PokerApp;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class F extends JPanel
{
  private PokerApp E;
  private volatile JLabel D;
  private double B = 0.0D;
  private double C = 0.0D;
  private int F = -1;
  private com.biotools.poker.D.E A = new com.biotools.poker.D.E();

  public F()
  {
    setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    this.E = PokerApp.Ȅ();
    setLayout(new BorderLayout());
    add(A(), "Center");
  }

  public double C(Card paramCard1, Card paramCard2)
  {
    int i = this.E.ɞ().getNumActivePlayers() - 1;
    if (i == 0)
      i = 1;
    return HandEvaluator.handRank(paramCard1, paramCard2, this.E.ɞ().getBoard(), i);
  }

  private JLabel A()
  {
    if (this.D == null)
    {
      StringBuffer localStringBuffer = new StringBuffer();
      localStringBuffer.append("<html>");
      localStringBuffer.append("<table>");
      localStringBuffer.append("<tr><td><font face=\"Arial\" size=\"-1\">");
      localStringBuffer.append("<br>&nbsp;");
      localStringBuffer.append("<br>&nbsp;<br>&nbsp;");
      localStringBuffer.append("<br>&nbsp;<br>&nbsp;");
      localStringBuffer.append("<br>&nbsp;<br>");
      localStringBuffer.append("</font></td></tr></table>");
      localStringBuffer.append("</html>");
      this.D = new JLabel(localStringBuffer.toString());
      this.D.setFont(new Font("Arial", 0, 11));
      this.D.setPreferredSize(new Dimension(165, Math.max(100, this.D.getPreferredSize().height)));
    }
    return this.D;
  }

  public void A(Card paramCard1, Card paramCard2)
  {
    try
    {
      if ((paramCard1 == null) || (paramCard2 == null))
      {
        A(false);
        return;
      }
      StringBuffer localStringBuffer = new StringBuffer();
      localStringBuffer.append("<html>");
      localStringBuffer.append("<table>");
      localStringBuffer.append("<tr><td>");
      if (this.E.ɞ().isPostFlop())
      {
        localStringBuffer.append("<b>&nbsp;" + com.biotools.poker.E.D("HandInfoPanel.HandTitle") + "</b> [" + paramCard1.toTranslatedString() + " " + paramCard2.toTranslatedString() + "]<br>&nbsp;&nbsp;&nbsp;&nbsp;");
        localStringBuffer.append(com.biotools.poker.K.D.B(B(paramCard1, paramCard2)));
        double d1 = -1.0D;
        if ((com.biotools.poker.E.Å()) && (!this.E.ɞ().isZipMode()))
        {
          long l1 = System.currentTimeMillis();
          com.biotools.poker.N.D.B localB = new com.biotools.poker.N.D.B();
          d1 = localB.B(PokerApp.χ, paramCard1, paramCard2, this.E.ɞ());
          long l2 = System.currentTimeMillis() - l1;
          if (d1 >= 0.0D)
            com.biotools.poker.E.H("AIE: " + d1 + " (" + l2 + " ms)");
        }
        if (d1 < 0.0D)
          if (this.E.ɞ().getNumActivePlayers() > 1)
          {
            if (this.E.ɞ().inGame(PokerApp.χ))
              d1 = G.A(this.E.ɞ()).Q(PokerApp.χ).A(paramCard1, paramCard2);
          }
          else
            d1 = C(paramCard1, paramCard2);
        localStringBuffer.append("<br><b>&nbsp;" + com.biotools.poker.E.D("HandInfoPanel.StrengthTitle") + " </b><br>&nbsp;&nbsp;&nbsp;&nbsp;" + A(100.0D * d1, 1) + "%");
        if (this.E.ɞ().getStage() < 3)
        {
          if (this.F != this.E.ɞ().getStage())
          {
            double[] arrayOfDouble = com.biotools.poker.D.A.B(paramCard1, paramCard2, this.E.ɞ().getBoard(), this.A);
            this.B = arrayOfDouble[0];
            this.C = arrayOfDouble[1];
          }
          localStringBuffer.append("<br><b>&nbsp;" + com.biotools.poker.E.D("HandInfoPanel.PotentialTitle") + "</b><br>&nbsp;&nbsp;&nbsp;&nbsp;");
          localStringBuffer.append("+" + A(100.0D * this.B, 1));
          localStringBuffer.append("%,&nbsp; &nbsp;-" + A(100.0D * this.C, 1) + "%");
        }
        else
        {
          this.B = (this.C = 0.0D);
          localStringBuffer.append("<br><b>&nbsp;" + com.biotools.poker.E.D("HandInfoPanel.PotentialTitle") + " </b><br>&nbsp;&nbsp;&nbsp;&nbsp;" + com.biotools.poker.E.D("HandInfoPanel.PotentialNA"));
        }
      }
      else
      {
        i = K.A(paramCard1, paramCard2, this.E.ɞ().getNumPlayers());
        localStringBuffer.append("<b>&nbsp;" + com.biotools.poker.E.D("HandInfoPanel.HandValueTitle") + " </b>[" + paramCard1.toTranslatedString() + " " + paramCard2.toTranslatedString() + "]<br>&nbsp;&nbsp;&nbsp;&nbsp;");
        localStringBuffer.append(A(100.0D * D(paramCard1, paramCard2), 1) + "%" + " (" + i + " / 169 " + com.biotools.poker.E.D("HandInfoPanel.HandValueTypes") + ")");
      }
      localStringBuffer.append("<br><b>&nbsp;" + com.biotools.poker.E.D("HandInfoPanel.PotOddsTitle") + " </b><br>&nbsp;&nbsp;&nbsp;&nbsp;");
      int i = this.E.ɞ().getPlayerSeat(this.E.ɬ());
      double d2 = this.E.ɞ().getAmountToCall(i);
      if (d2 == 0.0D)
      {
        localStringBuffer.append(com.biotools.poker.E.D("HandInfoPanel.PotOddsNA"));
      }
      else
      {
        double d3 = this.E.ɞ().getEligiblePot(i);
        localStringBuffer.append(A(d2 / (d3 + d2), 3) + " (" + A(d3 / d2, 2) + " " + com.biotools.poker.E.D("HandInfoPanel.PotOddsTo") + " 1)");
      }
      if (this.E.ɞ().isPreFlop())
      {
        localStringBuffer.append("<br>&nbsp;<br>&nbsp;");
        localStringBuffer.append("<br>&nbsp;<br>&nbsp;");
      }
      localStringBuffer.append("</td></tr></table>");
      localStringBuffer.append("</html>");
      A(localStringBuffer.toString());
      A(true);
      this.F = this.E.ɞ().getStage();
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  public Hand B(Card paramCard1, Card paramCard2)
  {
    if ((paramCard1 == null) || (paramCard2 == null))
      return null;
    Hand localHand = new Hand(this.E.ɞ().getBoard());
    localHand.addCard(paramCard1);
    localHand.addCard(paramCard2);
    return localHand;
  }

  private void A(final String paramString)
  {
    SwingUtilities.invokeLater(new Runnable()
    {
      private final String val$str;

      public void run()
      {
        if (F.this.D != null)
        {
          F.this.D.setText(paramString);
          F.this.D.setPreferredSize(new Dimension(165, F.this.D.getPreferredSize().height));
        }
      }
    });
  }

  private void A(final boolean paramBoolean)
  {
    SwingUtilities.invokeLater(new Runnable()
    {
      private final boolean val$val;

      public void run()
      {
        if (F.this.D != null)
          F.this.D.setForeground(paramBoolean ? com.biotools.B.A.D : com.biotools.B.A.M);
      }
    });
  }

  public double D(Card paramCard1, Card paramCard2)
  {
    return K.B(paramCard1, paramCard2, this.E.ɞ().getNumPlayers());
  }

  public static double A(double paramDouble, int paramInt)
  {
    if (Double.isNaN(paramDouble))
      return paramDouble;
    double d = 1.0D;
    for (int i = 0; i < paramInt; i++)
      d *= 10.0D;
    return Math.round(paramDouble * d) / d;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.J.F
 * JD-Core Version:    0.6.2
 */