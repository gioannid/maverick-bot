package com.biotools.poker.J;

import com.biotools.B.A;
import com.biotools.B.D;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.P.F;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;

public class E extends JPanel
{
  private volatile JTextField A;
  private volatile D B = new D(new Dimension(165, 60));

  public void setForeground(Color paramColor)
  {
    super.setForeground(paramColor);
  }

  public E()
  {
    this.B.A(new Font("Arial", 0, 11));
    this.B.D().addMouseListener(new MouseAdapter()
    {
      public void mousePressed(MouseEvent paramAnonymousMouseEvent)
      {
        if (paramAnonymousMouseEvent.isPopupTrigger())
        {
          F localF = new F();
          localF.show(E.this.B.D(), paramAnonymousMouseEvent.getX(), paramAnonymousMouseEvent.getY());
        }
      }

      public void mouseReleased(MouseEvent paramAnonymousMouseEvent)
      {
        if (paramAnonymousMouseEvent.isPopupTrigger())
        {
          F localF = new F();
          localF.show(E.this.B.D(), paramAnonymousMouseEvent.getX(), paramAnonymousMouseEvent.getY());
        }
      }
    });
    this.B.setFocusable(false);
    this.B.C().setFocusable(false);
    this.B.D().setFocusable(false);
    Style localStyle1 = this.B.B("chat", this.B.A());
    StyleConstants.setForeground(localStyle1, A.D.brighter());
    Style localStyle2 = this.B.B("chatname", localStyle1);
    StyleConstants.setBold(localStyle2, true);
    Style localStyle3 = this.B.B("admin", localStyle1);
    StyleConstants.setForeground(localStyle3, A.F);
    Style localStyle4 = this.B.B("dev", localStyle1);
    StyleConstants.setForeground(localStyle4, A.F);
    Style localStyle5 = this.B.B("devname", localStyle4);
    StyleConstants.setBold(localStyle5, true);
    this.A = new JTextField();
    this.A.addFocusListener(new FocusListener()
    {
      public void focusGained(FocusEvent paramAnonymousFocusEvent)
      {
        E.this.A.setBackground(Color.WHITE);
        E.this.A.setForeground(Color.BLACK);
      }

      public void focusLost(FocusEvent paramAnonymousFocusEvent)
      {
        E.this.A.setBackground(A.M.darker());
        E.this.A.setForeground(A.D.brighter());
      }
    });
    this.A.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        E.this.D();
      }
    });
    this.B.C().setForeground(A.D);
    this.B.C().setBackground(A.M);
    this.B.C().setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
    this.B.D().setBackground(A.M);
    this.B.D().setForeground(A.D);
    setLayout(new BorderLayout());
    add(this.B, "Center");
    add(this.A, "South");
    this.A.setVisible(false);
    this.A.setBackground(A.M.darker());
    this.A.setForeground(A.D.brighter());
  }

  private void D()
  {
    SwingUtilities.invokeLater(new E.4(this));
  }

  public void A(boolean paramBoolean)
  {
    this.A.setVisible(paramBoolean);
    this.A.invalidate();
    this.A.getParent().invalidate();
    this.A.getParent().validate();
    this.A.getParent().doLayout();
    invalidate();
    validate();
    doLayout();
  }

  public void B()
  {
    this.A.setText(null);
    this.B.B();
  }

  public void A(String paramString, int paramInt)
  {
    if (paramInt == 1)
    {
      if (com.biotools.poker.E.£().getBoolean("TRANSCRIPT_DISPLAY_GAME_ACTIONS", true))
        this.B.D(paramString);
      return;
    }
    if (paramInt == 2)
    {
      if (com.biotools.poker.E.£().getBoolean("TRANSCRIPT_DISPLAY_GAME_EVENTS", true))
        this.B.A(paramString);
      return;
    }
    if (paramInt == 3)
    {
      if (com.biotools.poker.E.£().getBoolean("TRANSCRIPT_DISPLAY_GAME_SUMMARY", true))
        this.B.A(paramString);
      return;
    }
    if (paramInt == 4)
    {
      if (com.biotools.poker.E.£().getBoolean("TRANSCRIPT_DISPLAY_CHAT", true))
        this.B.A(paramString, "chat");
      return;
    }
    if (paramInt == 6)
    {
      this.B.A(paramString, "admin");
      return;
    }
    if (paramInt == 5)
    {
      if (com.biotools.poker.E.£().getBoolean("TRANSCRIPT_DISPLAY_CHAT", true))
        this.B.A(paramString, "chatname");
      return;
    }
    if (paramInt > 5)
      this.B.A(paramString);
  }

  public void C()
  {
    if (this.A.isVisible())
      this.A.requestFocus();
  }

  public boolean A()
  {
    if (this.A.isVisible())
      return this.A.isFocusOwner();
    return false;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.J.E
 * JD-Core Version:    0.6.2
 */