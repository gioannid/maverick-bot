package com.biotools.poker.J;

import com.biotools.poker.PokerApp;
import com.biotools.poker.R.D;
import com.biotools.poker.R.N;
import com.biotools.poker.R.R;
import com.biotools.poker.R.U;
import com.biotools.poker.R.V;
import com.biotools.poker.R.X;
import com.biotools.poker.R.Z;
import com.biotools.poker.R.a;
import com.biotools.poker.R.j;
import com.biotools.poker.R.s;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class A extends JPanel
  implements N
{
  private JButton A;
  private JButton B;
  private JLabel C;

  public A()
  {
    setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    PokerApp.Ȅ().ʣ().B(this);
    this.C = new JLabel("<html><br><br><br></html>");
    this.C.setFont(new Font("Arial", 0, 11));
    M();
    this.C.setPreferredSize(new Dimension(165, this.C.getPreferredSize().height));
    setLayout(new BorderLayout(1, 1));
    add(this.C, "Center");
    if (!com.biotools.poker.E.Â())
      add(H(), "South");
  }

  private JPanel H()
  {
    JPanel localJPanel = new JPanel(new GridLayout(1, 1));
    localJPanel.add(I());
    localJPanel.add(F());
    return localJPanel;
  }

  private JButton I()
  {
    if (this.B == null)
    {
      this.B = new JButton(com.biotools.poker.E.D("SessionStats.HistoryButton"));
      this.B.setToolTipText(com.biotools.poker.E.D("SessionStats.HistoryButtonToolTip"));
      this.B.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          A.this.D();
          A.this.B.setBackground(com.biotools.B.A.M);
        }
      });
      A(this.B);
    }
    return this.B;
  }

  private JButton F()
  {
    if (this.A == null)
    {
      this.A = new JButton(com.biotools.poker.E.D("SessionStats.ChartButton"));
      this.A.setToolTipText(com.biotools.poker.E.D("SessionStats.ChartButtonToolTip"));
      this.A.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          A.this.G();
          A.this.A.setBackground(com.biotools.B.A.M);
        }
      });
      A(this.A);
    }
    return this.A;
  }

  private boolean B(JButton paramJButton)
  {
    if ((paramJButton.equals(this.A)) && (C() != null))
      return true;
    return (paramJButton.equals(this.B)) && (N() != null);
  }

  private void A(final JButton paramJButton)
  {
    paramJButton.addMouseListener(new MouseAdapter()
    {
      private final JButton val$btn;

      public void mouseEntered(MouseEvent paramAnonymousMouseEvent)
      {
        if (A.this.B(paramJButton))
          paramJButton.setBackground(com.biotools.B.A.M.brighter());
      }

      public void mouseExited(MouseEvent paramAnonymousMouseEvent)
      {
        if (A.this.B(paramJButton))
          paramJButton.setBackground(com.biotools.B.A.M);
      }

      public void mousePressed(MouseEvent paramAnonymousMouseEvent)
      {
        if (A.this.B(paramJButton))
          paramJButton.setBackground(com.biotools.B.A.M.darker());
      }
    });
    paramJButton.setFont(paramJButton.getFont().deriveFont(10.0F));
    paramJButton.setFocusable(false);
    paramJButton.setBorder(BorderFactory.createEmptyBorder());
    paramJButton.setBorderPainted(false);
    paramJButton.setMargin(new Insets(0, 0, 0, 0));
  }

  protected void G()
  {
    if (C() == null)
      return;
    if (com.biotools.poker.E.Ú())
    {
      PokerApp.Ȅ().Ȇ().B(J(), true);
      PokerApp.Ȅ().Ȇ().setVisible(true);
    }
    else
    {
      s locals = new s(J(), E());
      locals.g();
      if (N().X())
        locals.C(2);
      else
        locals.C(0);
      locals.u();
    }
  }

  private void D()
  {
    if (N() == null)
      return;
    X localX = new X(E(), J());
    localX.ł();
    localX.G(N());
  }

  private Z J()
  {
    if ((N() != null) && (N().W() != null))
      return N().W().B();
    return null;
  }

  private a C()
  {
    if (N() != null)
      return N().W();
    return null;
  }

  private U N()
  {
    return PokerApp.Ȅ().ǳ();
  }

  private ArrayList K()
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(N());
    return localArrayList;
  }

  private D E()
  {
    D localD = new D(PokerApp.Ȅ().ʣ());
    localD.C(K());
    return localD;
  }

  private void L()
  {
    SwingUtilities.invokeLater(new Runnable()
    {
      public void run()
      {
        A.this.M();
      }
    });
  }

  private void M()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<html>");
    localStringBuffer.append("<table cellpadding=\"2\" cellspacing=\"0\">");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><b>" + com.biotools.poker.E.D("SessionStats.HandsTitle") + "</b></td>");
    localStringBuffer.append("<td>" + (C() == null ? 0 : C().Z()) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><b>" + com.biotools.poker.E.D("SessionStats.HandsPlayedTitle") + "</b></td>");
    localStringBuffer.append("<td>" + (C() == null ? "" : j.H.format(C().N() / C().Z())) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><b>" + com.biotools.poker.E.D("SessionStats.HandsWonTitle") + "</b></td>");
    localStringBuffer.append("<td>" + (C() == null ? "" : j.H.format(C().U())) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><b>" + com.biotools.poker.E.D("SessionStats.WinRateTitle") + "</b></td>");
    localStringBuffer.append("<td>" + (C() == null ? "" : j.B.format(C().a())) + " " + com.biotools.poker.E.D("SessionStats.WinRateSmallBetsPerHour") + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("</table>");
    localStringBuffer.append("</html>");
    this.C.setText(localStringBuffer.toString());
    this.C.setPreferredSize(new Dimension(165, this.C.getPreferredSize().height));
  }

  public void B()
  {
    L();
  }

  public void A()
  {
    L();
  }

  public void A(com.biotools.poker.R.E paramE)
  {
    L();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.J.A
 * JD-Core Version:    0.6.2
 */