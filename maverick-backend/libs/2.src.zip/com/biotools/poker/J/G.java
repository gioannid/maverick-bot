package com.biotools.poker.J;

import com.biotools.meerkat.Action;
import com.biotools.poker.E;
import com.biotools.poker.G.R;
import com.biotools.poker.PokerApp;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class G extends JPanel
{
  private JLabel A = new JLabel("<html></html>");

  public G()
  {
    this.A.setFont(new Font("Arial", 0, 11));
    this.A.setPreferredSize(new Dimension(165, this.A.getPreferredSize().height));
    setLayout(new BorderLayout());
    setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    add(this.A, "Center");
  }

  public void A(R paramR)
  {
    String str = PokerApp.Ȅ().ɬ();
    StringBuffer localStringBuffer = new StringBuffer();
    if (paramR != null)
      localStringBuffer.append(A(paramR, str));
    SwingUtilities.invokeLater(new G.1(this, localStringBuffer));
  }

  private String A(R paramR, String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<html>");
    localStringBuffer.append("<table cellspacing=\"0\">");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><b>" + E.D("TournamentSummary.PrizePoolTitle") + "</b></td>");
    localStringBuffer.append("<td>" + Action.formatCash(paramR.i()) + "</td>");
    localStringBuffer.append("</tr>");
    int i = paramR.H(paramString);
    if (i != -1)
    {
      localStringBuffer.append("<tr>");
      localStringBuffer.append("<td align=\"right\"><b>" + E.D("TournamentSummary.RankingTitle") + "</b></td>");
      arrayOfObject = new Object[] { new Integer(i), new Integer(paramR.V()) };
      localStringBuffer.append("<td>" + E.A("TournamentSummary.RankingOutOfPattern", arrayOfObject) + "</td>");
      localStringBuffer.append("</tr>");
    }
    else
    {
      localStringBuffer.append("<tr>");
      localStringBuffer.append("<td align=\"right\">&nbsp;</td>");
      localStringBuffer.append("<td>&nbsp;</td>");
      localStringBuffer.append("</tr>");
    }
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><b>" + E.D("TournamentSummary.PlayersLeftTitle") + "</b></td>");
    Object[] arrayOfObject = { new Integer(paramR.Y()), new Integer(paramR.V()) };
    localStringBuffer.append("<td>" + E.A("TournamentSummary.RankingOutOfPattern", arrayOfObject) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><b>" + E.D("TournamentSummary.LargestStackTitle") + "</b></td>");
    localStringBuffer.append("<td>" + Action.formatCash(paramR.N()) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><b>" + E.D("TournamentSummary.AverageStackTitle") + "</b></td>");
    localStringBuffer.append("<td>" + Action.formatCash(paramR.H()) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><b>" + E.D("TournamentSummary.SmallestStackTitle") + "</b></td>");
    localStringBuffer.append("<td>" + Action.formatCash(paramR.¤()) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("</table>");
    localStringBuffer.append("</html>");
    return localStringBuffer.toString();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.J.G
 * JD-Core Version:    0.6.2
 */