package com.biotools.poker.J;

public class D extends C
{
  private com.biotools.poker.M.C P = new com.biotools.poker.M.C();
  private com.biotools.poker.M.E R = new com.biotools.poker.M.E();
  private com.biotools.poker.M.D Q = new com.biotools.poker.M.D(this.P);

  public D()
  {
    super("SIDEBAR_ADVISOR_STATE");
    A(this.Q, com.biotools.poker.E.D("AdvicePanel.AdvisorProfilesHeading"));
    A(this.R, com.biotools.poker.E.D("AdvicePanel.PopupAdviceHeading"));
    A(this.P, com.biotools.poker.E.D("AdvicePanel.AdvisorHeading"));
  }

  public com.biotools.poker.M.C J()
  {
    return this.P;
  }

  public void H()
  {
    this.R.A();
  }

  public void I()
  {
    this.Q.B();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.J.D
 * JD-Core Version:    0.6.2
 */