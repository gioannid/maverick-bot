package com.biotools.poker.J;

import com.biotools.B.A;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class C extends JPanel
{
  private static final int D = -1;
  private static final int N = 0;
  private static final int J = 1;
  private static ImageIcon L = new ImageIcon(E.K("pix/zoom16.png").getPath());
  private static ImageIcon M = new ImageIcon(E.K("pix/full16.png").getPath());
  private JPanel B = new JPanel();
  private CardLayout C;
  private int G = 0;
  private Vector H = new Vector();
  private Vector I = new Vector();
  private JLabel K;
  private JButton F;
  private JButton E;
  private String O;
  private boolean A = true;

  public C(String paramString)
  {
    this.O = paramString;
    this.K = new JLabel("", 0);
    this.K.setFont(this.K.getFont().deriveFont(1));
    setLayout(new BorderLayout());
    add(B(), "North");
    add(F(), "Center");
    A.A(this);
    if (E.£().getInt(paramString, 1) == 0)
      C();
  }

  public void A(boolean paramBoolean)
  {
    this.F.setVisible(paramBoolean);
    this.A = paramBoolean;
  }

  public C(String paramString1, JComponent paramJComponent, String paramString2)
  {
    this(paramString1);
    A(paramJComponent, paramString2);
  }

  private JPanel B()
  {
    this.F = new JButton(L);
    this.F.setFocusable(false);
    this.F.setMargin(new Insets(0, 0, 0, 0));
    this.F.setBorder(BorderFactory.createEmptyBorder());
    this.F.setBorderPainted(false);
    this.F.setContentAreaFilled(false);
    this.F.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        C.this.E();
      }
    });
    this.E = A();
    final JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.addMouseListener(new MouseAdapter()
    {
      private final JPanel val$jp;

      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        if (paramAnonymousMouseEvent.getClickCount() == 2)
          C.this.E();
      }

      public void mouseEntered(MouseEvent paramAnonymousMouseEvent)
      {
        localJPanel.setBackground(A.M.darker());
      }

      public void mouseExited(MouseEvent paramAnonymousMouseEvent)
      {
        localJPanel.setBackground(A.M);
      }
    });
    localJPanel.setBorder(BorderFactory.createEtchedBorder(1));
    localJPanel.setBackground(A.M.darker());
    localJPanel.add(Box.createHorizontalStrut(1));
    localJPanel.add(this.E);
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(this.K);
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(this.F);
    return localJPanel;
  }

  public void E()
  {
    if (this.B.isVisible())
      C();
    else
      G();
  }

  public void C()
  {
    if (this.A)
    {
      this.B.setVisible(false);
      this.F.setIcon(M);
      E.£().putInt(this.O, 0);
    }
  }

  public void G()
  {
    this.B.setVisible(true);
    this.F.setIcon(L);
    E.£().putInt(this.O, 1);
  }

  private JPanel F()
  {
    this.B = new JPanel();
    this.B.setBorder(BorderFactory.createBevelBorder(1));
    this.C = new CardLayout();
    this.B.setLayout(this.C);
    return this.B;
  }

  public void A(JComponent paramJComponent, String paramString)
  {
    this.H.add(paramJComponent);
    this.I.add(paramString);
    A.A(paramJComponent);
    this.B.add(paramJComponent, paramString);
    this.E.setVisible(this.H.size() > 1);
    A(this.H.size() - 1);
  }

  private JButton A()
  {
    JButton localJButton = new JButton(new ImageIcon("data/pix/arrowR.png"));
    localJButton.setVisible(false);
    localJButton.setFocusable(false);
    localJButton.setMargin(new Insets(0, 0, 0, 0));
    localJButton.setBorder(BorderFactory.createEmptyBorder());
    localJButton.setBorderPainted(false);
    localJButton.setContentAreaFilled(false);
    localJButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        C.this.D();
      }
    });
    return localJButton;
  }

  private void D()
  {
    A((this.G + 1) % this.H.size());
  }

  void A(int paramInt)
  {
    this.G = paramInt;
    JComponent localJComponent = (JComponent)this.H.get(this.G);
    String str = (String)this.I.get(this.G);
    this.C.show(this.B, str);
    this.K.setText(str);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.J.C
 * JD-Core Version:    0.6.2
 */