package com.biotools.poker.D;

import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.GameObserver;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.util.NChoose2IntTable;
import com.biotools.poker.E;
import java.util.HashMap;
import java.util.WeakHashMap;

public class G
  implements GameObserver
{
  private B[] ȑ = new B[10];
  private GameInfo ȍ;
  private NChoose2IntTable Ȑ;
  private HashMap ȋ = new HashMap();
  private boolean Ȏ = true;
  private static WeakHashMap Ȍ = new WeakHashMap();
  private int ȏ = 0;
  private int Ȋ = 0;

  public static G A(GameInfo paramGameInfo)
  {
    G localG = (G)Ȍ.get(paramGameInfo);
    if (localG == null)
    {
      localG = new G();
      Ȍ.put(paramGameInfo, localG);
    }
    return localG;
  }

  public static void B(GameInfo paramGameInfo)
  {
    Ȍ.remove(paramGameInfo);
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    this.ȍ = paramGameInfo;
    Ÿ();
    Ȍ.put(paramGameInfo, this);
    for (int i = 0; i < paramGameInfo.getNumSeats(); i++)
      if (paramGameInfo.inGame(i))
      {
        B localB = null;
        if ((this.ȑ[i] != null) && (this.ȑ[i].Ů().equals(paramGameInfo.getPlayerName(i))))
          localB = this.ȑ[i];
        if (localB == null)
        {
          if (this.ȑ[i] != null)
            this.ȑ[i].Ŭ();
          this.ȑ[i] = new B(paramGameInfo.getPlayerName(i), this);
          E.H("LOAD MODEL: " + paramGameInfo.getPlayerName(i));
        }
      }
      else
      {
        if (this.ȑ[i] != null)
          this.ȑ[i].Ŭ();
        this.ȑ[i] = null;
      }
    for (i = 0; i < paramGameInfo.getNumSeats(); i++)
      if (paramGameInfo.inGame(i))
        this.ȑ[i].gameStartEvent(paramGameInfo);
  }

  public B Q(int paramInt)
  {
    return this.ȑ[paramInt];
  }

  public void gameStateChanged()
  {
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
    if (this.Ȏ)
      this.ȑ[paramInt].actionEvent(paramInt, paramAction);
  }

  public void stageEvent(int paramInt)
  {
    Ÿ();
    if (this.Ȏ)
      for (int i = 0; i < this.ȍ.getNumSeats(); i++)
        if (this.ȍ.inGame(i))
          this.ȑ[i].stageEvent(paramInt);
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
  }

  public void dealHoleCardsEvent()
  {
  }

  public void gameOverEvent()
  {
    if (this.Ȏ)
    {
      if (this.ȍ == null)
        return;
      for (int i = 0; i < this.ȍ.getNumSeats(); i++)
        if ((this.ȍ.inGame(i)) && (this.ȑ[i] != null))
          this.ȑ[i].gameOverEvent();
    }
    Ÿ();
  }

  public void Ź()
  {
    for (int i = 0; i < this.ȑ.length; i++)
      if (this.ȑ[i] != null)
        this.ȑ[i].Ŭ();
  }

  public synchronized NChoose2IntTable ŷ()
  {
    if ((this.Ȑ == null) && (this.ȍ != null) && (this.ȍ.isPostFlop()))
      this.Ȑ = HandEvaluator.getRanks(this.ȍ.getBoard());
    return this.Ȑ;
  }

  public synchronized NChoose2IntTable A(Hand paramHand, String paramString)
  {
    NChoose2IntTable localNChoose2IntTable = (NChoose2IntTable)this.ȋ.get(paramString);
    if (localNChoose2IntTable == null)
    {
      localNChoose2IntTable = HandEvaluator.getRanks(paramHand);
      this.ȋ.put(paramString, localNChoose2IntTable);
      this.Ȋ += 1;
    }
    else
    {
      this.ȏ += 1;
    }
    return localNChoose2IntTable;
  }

  private void Ÿ()
  {
    this.ȋ.clear();
    this.Ȑ = null;
    this.ȏ = 0;
    this.Ȋ = 0;
  }

  public void D(boolean paramBoolean)
  {
    this.Ȏ = paramBoolean;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.D.G
 * JD-Core Version:    0.6.2
 */