package com.biotools.poker.D;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.util.NChoose2IntTable;
import java.io.Serializable;

public class E extends F
  implements Serializable
{
  private static transient HandEvaluator E = new HandEvaluator();
  private transient Deck F = new Deck();

  public E()
  {
    super(52, 1.0D);
  }

  public E(String paramString)
  {
    super(paramString);
  }

  public E(int paramInt)
  {
    super(52, paramInt);
  }

  public void A(Card paramCard)
  {
    int i = paramCard.getIndex();
    for (int j = 0; j < 52; j++)
      if (j != i)
        A(i, j, 0.0D);
  }

  public double A(Card paramCard1, Card paramCard2)
  {
    return B(paramCard1.getIndex(), paramCard2.getIndex());
  }

  public double C(int paramInt1, int paramInt2)
  {
    return B(paramInt1, paramInt2);
  }

  public double A(Hand paramHand)
  {
    return B(paramHand.getCard(1).getIndex(), paramHand.getCard(2).getIndex());
  }

  public void A(Card paramCard1, Card paramCard2, double paramDouble)
  {
    A(paramCard1.getIndex(), paramCard2.getIndex(), paramDouble);
  }

  public double B(Card paramCard1, Card paramCard2, double paramDouble)
  {
    return super.B(paramCard1.getIndex(), paramCard2.getIndex(), paramDouble);
  }

  public double A(Card paramCard1, Card paramCard2, Hand paramHand, Deck paramDeck)
  {
    Hand localHand1 = new Hand(paramHand);
    Hand localHand2 = new Hand(paramHand);
    localHand1.addCard(paramCard1);
    localHand1.addCard(paramCard2);
    int i = HandEvaluator.rankHand(localHand1);
    double d1 = 0.0D;
    double d2 = 0.0D;
    double d3 = 0.0D;
    for (int j = paramDeck.getTopCardIndex(); j < 52; j++)
    {
      Card localCard1 = paramDeck.getCard(j);
      localHand2.addCard(localCard1);
      for (int k = j + 1; k < 52; k++)
      {
        Card localCard2 = paramDeck.getCard(k);
        localHand2.addCard(localCard2);
        int m = HandEvaluator.compareHands(i, localHand2);
        if (m == 1)
          d1 += B(localCard1.getIndex(), localCard2.getIndex());
        else if (m == 2)
          d2 += B(localCard1.getIndex(), localCard2.getIndex());
        else
          d3 += B(localCard1.getIndex(), localCard2.getIndex());
        localHand2.removeCard();
      }
      localHand2.removeCard();
    }
    return (d1 + d3 / 2.0D) / (d1 + d2 + d3);
  }

  public synchronized double A(Card paramCard1, Card paramCard2, Hand paramHand)
  {
    this.F.reset();
    this.F.extractCard(paramCard1);
    this.F.extractCard(paramCard2);
    this.F.extractHand(paramHand);
    return A(paramCard1, paramCard2, paramHand, this.F);
  }

  public synchronized double A(Card paramCard1, Card paramCard2, Hand paramHand, NChoose2IntTable paramNChoose2IntTable)
  {
    this.F.reset();
    this.F.extractCard(paramCard1);
    this.F.extractCard(paramCard2);
    this.F.extractHand(paramHand);
    return A(paramCard1, paramCard2, paramNChoose2IntTable, this.F);
  }

  public double A(Card paramCard1, Card paramCard2, NChoose2IntTable paramNChoose2IntTable, Deck paramDeck)
  {
    int i = paramNChoose2IntTable.get(paramCard1.getIndex(), paramCard2.getIndex());
    double d1 = 0.0D;
    double d2 = 0.0D;
    double d3 = 0.0D;
    for (int j = paramDeck.getTopCardIndex(); j < 52; j++)
    {
      int k = paramDeck.getCard(j).getIndex();
      for (int m = j + 1; m < 52; m++)
      {
        int n = paramDeck.getCard(m).getIndex();
        int i1 = paramNChoose2IntTable.get(k, n);
        if (i > i1)
          d1 += B(k, n);
        else if (i < i1)
          d2 += B(k, n);
        else
          d3 += B(k, n);
      }
    }
    return (d1 + d3 / 2.0D) / (d1 + d2 + d3);
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i < 52; i++)
    {
      Card localCard1 = new Card(i);
      for (int j = 0; j < 52; j++)
        if (i > j)
        {
          Card localCard2 = new Card(j);
          localStringBuffer.append(A(localCard1, localCard2) + "\n");
        }
        else
        {
          localStringBuffer.append("0.0\n");
        }
      localStringBuffer.append("\n");
    }
    return localStringBuffer.toString();
  }

  public String H()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("     2     3     4     5     6     7     8     9     T     J     Q     K     A    (u)\n");
    for (int i = 0; i < 13; i++)
    {
      localStringBuffer.append(" " + Card.getRankChar(i) + "| ");
      for (int j = 0; j < 13; j++)
      {
        double d = A(i, j, i > j);
        String str = A(d, 2);
        localStringBuffer.append(str);
        int k = str.length();
        while (k++ < 6)
          localStringBuffer.append(" ");
      }
      localStringBuffer.append("| " + Card.getRankChar(i) + "\n");
    }
    localStringBuffer.append("(s)  2     3     4     5     6     7     8     9     T     J     Q     K     A\n\n");
    return localStringBuffer.toString();
  }

  public double B(Card paramCard1, Card paramCard2)
  {
    return A(paramCard1.getRank(), paramCard2.getRank(), paramCard1.getSuit() == paramCard2.getSuit());
  }

  public double A(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    double d = 0.0D;
    int i;
    if (paramBoolean)
    {
      for (i = 0; i < 4; i++)
        d += A(new Card(paramInt1, i), new Card(paramInt2, i));
      d /= 4.0D;
    }
    else if (paramInt1 == paramInt2)
    {
      d += A(new Card(paramInt1, 1), new Card(paramInt2, 2));
      d += A(new Card(paramInt1, 3), new Card(paramInt2, 2));
      d += A(new Card(paramInt1, 0), new Card(paramInt2, 2));
      d += A(new Card(paramInt1, 3), new Card(paramInt2, 1));
      d += A(new Card(paramInt1, 0), new Card(paramInt2, 1));
      d += A(new Card(paramInt1, 3), new Card(paramInt2, 0));
      d /= 6.0D;
    }
    else
    {
      for (i = 0; i < 4; i++)
        for (int j = 0; j < 4; j++)
          if (i != j)
            d += A(new Card(paramInt1, i), new Card(paramInt2, j));
      d /= 12.0D;
    }
    return d;
  }

  public Hand B(double paramDouble)
  {
    double d = 0.0D;
    Card localCard1 = new Card();
    Card localCard2 = new Card();
    paramDouble *= A();
    for (int i = 1; i < 52; i++)
    {
      localCard1.setIndex(i);
      for (int j = 0; j < i; j++)
      {
        localCard2.setIndex(j);
        d += A(localCard1, localCard2);
        if (paramDouble < d)
        {
          Hand localHand = new Hand();
          localHand.addCard(localCard1);
          localHand.addCard(localCard2);
          return localHand;
        }
      }
    }
    return null;
  }

  public void I()
  {
    Card localCard1 = new Card();
    Card localCard2 = new Card();
    for (int i = 0; i < 51; i++)
    {
      localCard1.setIndex(i);
      for (int j = i + 1; j < 52; j++)
      {
        localCard2.setIndex(j);
        A(localCard1, localCard2, 0.01D * D(i, j));
      }
    }
  }

  public static E G()
  {
    E localE = new E();
    localE.I();
    return localE;
  }

  private int D(int paramInt1, int paramInt2)
  {
    int[][] arrayOfInt = { { 70, 10, 1, 1, 1, 1, 1, 1, 1, 1, 1, 10, 50 }, { 50, 70, 10, 1, 1, 1, 1, 1, 1, 1, 1, 10, 50 }, { 20, 60, 70, 10, 1, 1, 1, 1, 1, 1, 1, 10, 60 }, { 20, 20, 70, 70, 10, 1, 1, 1, 1, 1, 1, 10, 60 }, { 10, 10, 20, 70, 70, 10, 1, 1, 1, 1, 1, 10, 70 }, { 10, 10, 10, 30, 70, 70, 20, 10, 1, 1, 10, 20, 70 }, { 10, 10, 10, 10, 30, 70, 70, 60, 30, 20, 30, 40, 80 }, { 10, 10, 10, 10, 20, 30, 80, 80, 60, 60, 60, 60, 80 }, { 20, 20, 20, 20, 20, 30, 40, 90, 90, 90, 90, 90, 90 }, { 20, 20, 20, 20, 20, 30, 50, 80, 100, 100, 90, 90, 90 }, { 50, 50, 50, 50, 60, 60, 70, 80, 100, 100, 100, 90, 100 }, { 70, 70, 70, 70, 80, 80, 80, 80, 100, 100, 100, 100, 100 }, { 90, 90, 90, 90, 90, 90, 90, 90, 100, 100, 100, 100, 100 } };
    int i = paramInt1 % 13;
    int j = paramInt2 % 13;
    if (i < j)
    {
      int k = i;
      i = j;
      j = k;
    }
    int m;
    if (paramInt1 / 13 == paramInt2 / 13)
      m = arrayOfInt[i][j];
    else
      m = arrayOfInt[j][i];
    return m;
  }

  private static double A(double paramDouble, int paramInt)
  {
    double d = 1.0D;
    for (int i = 0; i < paramInt; i++)
      d *= 10.0D;
    return Math.round(paramDouble * d) / d;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.D.E
 * JD-Core Version:    0.6.2
 */