package com.biotools.poker.D;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.Serializable;

public class F
  implements Serializable
{
  private double[] B;
  private int C;
  private double A;
  private boolean D = true;

  public F(int paramInt)
  {
    A(paramInt, 0.0D);
  }

  public F(String paramString)
  {
    try
    {
      RandomAccessFile localRandomAccessFile = new RandomAccessFile(paramString, "r");
      this.C = localRandomAccessFile.readInt();
      A(this.C, 0.0D);
      int i = 0;
      while (i < this.C)
        this.B[(i++)] = localRandomAccessFile.readDouble();
      localRandomAccessFile.close();
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }

  public void A(String paramString)
  {
    try
    {
      RandomAccessFile localRandomAccessFile = new RandomAccessFile(paramString, "rw");
      localRandomAccessFile.writeInt(this.C);
      int i = 0;
      while (i < this.C)
        localRandomAccessFile.writeDouble(this.B[(i++)]);
      localRandomAccessFile.close();
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }

  public F(int paramInt, double paramDouble)
  {
    A(paramInt, paramDouble);
  }

  protected void A(int paramInt, double paramDouble)
  {
    this.C = paramInt;
    this.B = new double[paramInt * (paramInt - 1) / 2];
    for (int i = 0; i < this.B.length; i++)
      this.B[i] = paramDouble;
    this.A = (paramDouble * this.B.length);
    this.D = false;
  }

  public void A(double paramDouble)
  {
    for (int i = 0; i < this.B.length; i++)
      this.B[i] = paramDouble;
    this.A = (paramDouble * this.B.length);
    this.D = false;
  }

  public void A(F paramF)
  {
    if (this.C != paramF.C)
      return;
    for (int i = 0; i < this.B.length; i++)
      this.B[i] = paramF.B[i];
    this.A = paramF.A;
    this.D = paramF.D;
  }

  public void D()
  {
    double d = A();
    for (int i = 0; i < this.B.length; i++)
      this.B[i] /= d;
    this.A = 1.0D;
  }

  public void B()
  {
    double d = 1.0D / E();
    for (int i = 0; i < this.B.length; i++)
      this.B[i] *= d;
    this.D = true;
  }

  public double E()
  {
    double d = (-1.0D / 0.0D);
    for (int i = 0; i < this.B.length; i++)
      if (this.B[i] > d)
        d = this.B[i];
    return d;
  }

  public void B(F paramF)
  {
    if (this.C != paramF.C)
      return;
    double d = A();
    for (int i = 0; i < this.B.length; i++)
      this.B[i] = (this.B[i] / d + paramF.B[i] / paramF.A());
    this.D = true;
  }

  public double A()
  {
    if (this.D)
    {
      this.A = 0.0D;
      for (int i = 0; i < this.B.length; i++)
        this.A += this.B[i];
    }
    return this.A;
  }

  public double A(int paramInt)
  {
    return this.B[paramInt];
  }

  public void B(int paramInt, double paramDouble)
  {
    this.B[paramInt] = paramDouble;
    this.D = true;
  }

  public final int F()
  {
    return this.B.length;
  }

  public final int A(int paramInt1, int paramInt2)
  {
    if (paramInt1 > paramInt2)
      return paramInt1 * (paramInt1 - 1) / 2 + paramInt2;
    if (paramInt1 < paramInt2)
      return paramInt2 * (paramInt2 - 1) / 2 + paramInt1;
    return -1;
  }

  public final double B(int paramInt1, int paramInt2)
  {
    if (paramInt1 > paramInt2)
      return this.B[(paramInt1 * (paramInt1 - 1) / 2 + paramInt2)];
    if (paramInt1 < paramInt2)
      return this.B[(paramInt2 * (paramInt2 - 1) / 2 + paramInt1)];
    return -1.0D;
  }

  public final void A(int paramInt1, int paramInt2, double paramDouble)
  {
    if (paramInt1 > paramInt2)
      this.B[(paramInt1 * (paramInt1 - 1) / 2 + paramInt2)] = paramDouble;
    else if (paramInt1 < paramInt2)
      this.B[(paramInt2 * (paramInt2 - 1) / 2 + paramInt1)] = paramDouble;
    this.D = true;
  }

  public double B(int paramInt1, int paramInt2, double paramDouble)
  {
    this.D = true;
    A(paramInt1, paramInt2, B(paramInt1, paramInt2) * paramDouble);
    return B(paramInt1, paramInt2);
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 1; i < this.C; i++)
    {
      for (int j = 0; j < i; j++)
        localStringBuffer.append(" " + B(i, j) + " ");
      localStringBuffer.append("\n");
    }
    return localStringBuffer.toString();
  }

  public double[] C()
  {
    return this.B;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.D.F
 * JD-Core Version:    0.6.2
 */