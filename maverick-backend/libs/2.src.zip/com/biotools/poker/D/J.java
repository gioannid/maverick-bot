package com.biotools.poker.D;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;

public class J
  implements Serializable
{
  private Hashtable B = new Hashtable();
  private boolean A = false;

  public J(String paramString)
  {
    B(paramString);
  }

  public J()
  {
  }

  public void A(String paramString)
  {
    try
    {
      ObjectOutputStream localObjectOutputStream = new ObjectOutputStream(new FileOutputStream(paramString));
      localObjectOutputStream.writeObject(this);
      localObjectOutputStream.close();
    }
    catch (Exception localException)
    {
      if (!$assertionsDisabled)
        throw new AssertionError();
    }
    this.A = false;
  }

  public void C(String paramString)
  {
    try
    {
      ObjectInputStream localObjectInputStream = new ObjectInputStream(new FileInputStream(paramString));
      J localJ = (J)localObjectInputStream.readObject();
      this.B = localJ.B;
      localObjectInputStream.close();
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
    }
    catch (Exception localException)
    {
    }
    this.A = false;
  }

  public void E(String paramString)
  {
    try
    {
      BufferedWriter localBufferedWriter = new BufferedWriter(new FileWriter(paramString));
      Enumeration localEnumeration = this.B.keys();
      while (localEnumeration.hasMoreElements())
      {
        String str = (String)localEnumeration.nextElement();
        localBufferedWriter.write(((I)this.B.get(str)).toString() + "\n");
      }
      localBufferedWriter.close();
    }
    catch (Exception localException)
    {
      if (!$assertionsDisabled)
        throw new AssertionError();
    }
    this.A = false;
  }

  public void B(String paramString)
  {
    try
    {
      BufferedReader localBufferedReader = new BufferedReader(new FileReader(paramString));
      for (String str = localBufferedReader.readLine(); str != null; str = localBufferedReader.readLine())
        try
        {
          I localI = new I();
          localI.A(str);
          this.B.put(localI.A(), localI);
        }
        catch (Exception localException2)
        {
        }
      localBufferedReader.close();
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
    }
    catch (Exception localException1)
    {
    }
    this.A = false;
  }

  public void A(J paramJ)
  {
    Enumeration localEnumeration = paramJ.B.elements();
    while (localEnumeration.hasMoreElements())
    {
      I localI = new I((I)localEnumeration.nextElement());
      this.B.put(localI.A(), localI);
    }
    this.A = false;
  }

  public C F(String paramString)
  {
    I localI = (I)this.B.get(paramString);
    if (localI != null)
      return localI.B();
    return new C();
  }

  public double A(String paramString, int paramInt)
  {
    I localI = (I)this.B.get(paramString);
    if (localI != null)
      return localI.C(paramInt);
    return 0.0D;
  }

  public int D(String paramString)
  {
    I localI = (I)this.B.get(paramString);
    if (localI != null)
      return localI.C();
    return 0;
  }

  public void A(int paramInt, String paramString)
  {
    I localI = (I)this.B.get(paramString);
    if (localI == null)
    {
      localI = new I(paramString);
      this.B.put(paramString, localI);
    }
    localI.B(paramInt);
    this.A = true;
  }

  public boolean A()
  {
    return this.A;
  }

  public void A(int paramInt)
  {
    Enumeration localEnumeration = this.B.elements();
    while (localEnumeration.hasMoreElements())
    {
      I localI = (I)localEnumeration.nextElement();
      localI.A(paramInt);
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.D.J
 * JD-Core Version:    0.6.2
 */