package com.biotools.poker.D;

import com.biotools.A.W;
import java.io.Serializable;

public class C
  implements Serializable
{
  public static final C E = new C(1.0D, 0.0D, 0.0D);
  public static final C G = new C(0.0D, 1.0D, 0.0D);
  public static final C B = new C(0.0D, 0.0D, 1.0D);
  private static transient W D = W.A();
  private float A;
  private float C;
  private float F;

  public C()
  {
  }

  public C(int paramInt)
  {
    if (paramInt == 0)
      this.A = 1.0F;
    if (paramInt == 1)
      this.C = 1.0F;
    if (paramInt == 2)
      this.F = 1.0F;
  }

  public C(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    this.A = ((float)paramDouble1);
    this.C = ((float)paramDouble2);
    this.F = ((float)paramDouble3);
  }

  public C(C paramC)
  {
    this.A = paramC.A;
    this.C = paramC.C;
    this.F = paramC.F;
  }

  public C(double[] paramArrayOfDouble)
  {
    this.A = ((float)paramArrayOfDouble[0]);
    this.C = ((float)paramArrayOfDouble[1]);
    this.F = ((float)paramArrayOfDouble[2]);
  }

  public void B(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    this.A = ((float)paramDouble1);
    this.C = ((float)paramDouble2);
    this.F = ((float)paramDouble3);
  }

  public double J()
  {
    return this.A;
  }

  public double C()
  {
    return this.C;
  }

  public double D()
  {
    return this.F;
  }

  public double A(int paramInt)
  {
    switch (paramInt)
    {
    case 0:
      return this.A;
    case 1:
      return this.C;
    case 2:
      return this.F;
    }
    return 0.0D;
  }

  public void E()
  {
    double d = this.A + this.C + this.F;
    this.A = ((float)(this.A / d));
    this.C = ((float)(this.C / d));
    this.F = ((float)(this.F / d));
  }

  public boolean F()
  {
    double d = this.A + this.C + this.F;
    if ((this.A < 0.0F) || (this.C < 0.0F) || (this.F < 0.0F))
      return false;
    return (d > 0.9999900000000001D) && (d < 1.00001D);
  }

  public void B(C paramC)
  {
    this.A = ((float)(this.A + paramC.J()));
    this.C = ((float)(this.C + paramC.C()));
    this.F = ((float)(this.F + paramC.D()));
  }

  public void A(C paramC)
  {
    this.A *= paramC.A;
    this.C *= paramC.C;
    this.F *= paramC.F;
  }

  public void A(double paramDouble)
  {
    this.A = ((float)(this.A * paramDouble));
    this.C = ((float)(this.C * paramDouble));
    this.F = ((float)(this.F * paramDouble));
  }

  public void B(double paramDouble)
  {
    this.A = ((float)paramDouble);
  }

  public void D(double paramDouble)
  {
    this.C = ((float)paramDouble);
  }

  public void F(double paramDouble)
  {
    this.F = ((float)paramDouble);
  }

  public double A()
  {
    return this.A + this.C + this.F;
  }

  public double H()
  {
    return A(K());
  }

  public int A(double paramDouble, boolean paramBoolean)
  {
    if (paramBoolean)
      return E(paramDouble);
    return C(paramDouble);
  }

  public int C(double paramDouble)
  {
    if (paramDouble < this.A)
      return 0;
    if (paramDouble < this.A + this.C)
      return 1;
    return 2;
  }

  public int E(double paramDouble)
  {
    if ((this.A > this.C) && (this.A > this.F))
      return 0;
    if ((this.C > this.A) && (this.C > this.F))
      return 1;
    if ((this.F > this.A) && (this.F > this.C))
      return 2;
    if ((this.F > this.A) && (this.F == this.C))
      return paramDouble > 0.5D ? 1 : 2;
    if ((this.C > this.F) && (this.C == this.A))
      return paramDouble > 0.5D ? 0 : 1;
    if ((this.F > this.C) && (this.F == this.A))
      return paramDouble > 0.5D ? 0 : 2;
    return 1;
  }

  public int K()
  {
    return E(D.nextDouble());
  }

  public int L()
  {
    return C(D.nextDouble());
  }

  public String toString()
  {
    return new String("{" + A(this.A, 3) + ", " + A(this.C, 3) + ", " + A(this.F, 3) + "}");
  }

  private static double A(double paramDouble, int paramInt)
  {
    double d = 1.0D;
    for (int i = 0; i < paramInt; i++)
      d *= 10.0D;
    return Math.round(paramDouble * d) / d;
  }

  public static int A(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    double d = Math.random();
    if (d < paramDouble1)
      return 0;
    if (d < paramDouble1 + paramDouble2)
      return 1;
    return 2;
  }

  public static int A(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    if (paramDouble4 < paramDouble1)
      return 0;
    if (paramDouble4 < paramDouble1 + paramDouble2)
      return 1;
    return 2;
  }

  public boolean I()
  {
    return (this.A == 1.0D) && (this.C == 0.0D) && (this.F == 0.0D);
  }

  public boolean B()
  {
    return (this.A == 0.0D) && (this.C == 1.0D) && (this.F == 0.0D);
  }

  public boolean G()
  {
    return (this.A == 0.0D) && (this.C == 0.0D) && (this.F == 1.0D);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.D.C
 * JD-Core Version:    0.6.2
 */