package com.biotools.poker.D;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;

public class A
{
  private static final int O = 0;
  private static final int N = 1;
  private static final int C = 2;
  private static final int B = 4;
  private static final int F = 13;
  private static final int G = 0;
  private static final int J = 12;
  private double E = -1.0D;
  private double M = -1.0D;
  private double I = 0.0D;
  private Deck H = new Deck();
  private int[][] A;
  private int[] D;
  private int[] K;
  private int[] L;

  public static double A(Card paramCard1, Card paramCard2, Hand paramHand, E paramE)
  {
    A localA = new A();
    return localA.A(paramCard1, paramCard2, paramHand, paramE, false);
  }

  public static double[] B(Card paramCard1, Card paramCard2, Hand paramHand, E paramE)
  {
    A localA = new A();
    localA.A(paramCard1, paramCard2, paramHand, paramE, false);
    double[] arrayOfDouble = { localA.E, localA.M };
    return arrayOfDouble;
  }

  public double B()
  {
    return this.E;
  }

  public double A()
  {
    return this.M;
  }

  public double A(Card paramCard1, Card paramCard2, Hand paramHand, E paramE, boolean paramBoolean)
  {
    double[][] arrayOfDouble = new double[3][3];
    double[] arrayOfDouble1 = new double[3];
    double d1 = 0.0D;
    Hand localHand1 = new Hand(paramHand);
    Hand localHand2 = new Hand(localHand1);
    Hand localHand3 = new Hand(localHand1);
    int i4 = (localHand1.size() == 3) && (paramBoolean) ? 1 : 0;
    int[] arrayOfInt = new int[4];
    int n;
    if ((this.D != null) || (this.A != null))
      for (m = 0; m < 52; m++)
      {
        this.D[m] = 0;
        if ((i4 != 0) && (this.A != null))
          for (n = 0; n < 51; n++)
            this.A[m][n] = 0;
      }
    if ((this.K != null) || (this.L != null))
      if ((i4 != 0) && (this.K != null))
      {
        for (m = 0; m < 22100; m++)
        {
          this.L[m] = 0;
          this.K[m] = 0;
        }
        for (m = 22100; m < 270725; m++)
          this.K[m] = 0;
      }
      else
      {
        for (m = 0; m < 22100; m++)
          this.L[m] = 0;
      }
    if (this.D == null)
      this.D = new int[52];
    if ((this.A == null) && (i4 != 0))
      this.A = new int[52][51];
    if ((this.K == null) && (i4 != 0))
      this.K = new int[270725];
    if (this.L == null)
      this.L = new int[22100];
    localHand2.addCard(paramCard1);
    localHand2.addCard(paramCard2);
    int i = HandEvaluator.rankHand(localHand2);
    this.H.reset();
    this.H.extractCard(paramCard1);
    this.H.extractCard(paramCard2);
    this.H.extractHand(localHand1);
    for (int m = this.H.getTopCardIndex(); m < 52; m++)
    {
      int i5 = this.H.getCard(m).getIndex();
      localHand3.addCard(i5);
      arrayOfInt[0] = i5;
      for (n = m + 1; n < 52; n++)
      {
        int i6 = this.H.getCard(n).getIndex();
        localHand3.addCard(i6);
        arrayOfInt[1] = i6;
        int k = HandEvaluator.rankHand(localHand3);
        int i3;
        if (i > k)
          i3 = 0;
        else if (i == k)
          i3 = 1;
        else
          i3 = 2;
        d1 = paramE.B(i5, i6);
        arrayOfDouble1[i3] += d1;
        for (int i1 = this.H.getTopCardIndex(); i1 < 52; i1++)
          if ((i1 != m) && (i1 != n))
          {
            int j;
            if (i4 != 0)
            {
              for (int i2 = i1 + 1; i2 < 52; i2++)
                if ((i2 != m) && (i2 != n))
                {
                  j = A(this.H.getCard(i1).getIndex(), this.H.getCard(i2).getIndex(), localHand2);
                  arrayOfInt[0] = i5;
                  arrayOfInt[1] = i6;
                  arrayOfInt[2] = this.H.getCard(i1).getIndex();
                  arrayOfInt[3] = this.H.getCard(i2).getIndex();
                  k = A(arrayOfInt, localHand1);
                  if (j > k)
                    arrayOfDouble[i3][0] += d1;
                  else if (j == k)
                    arrayOfDouble[i3][1] += d1;
                  else
                    arrayOfDouble[i3][2] += d1;
                }
            }
            else
            {
              j = A(this.H.getCard(i1).getIndex(), localHand2);
              k = A(i5, i6, this.H.getCard(i1).getIndex(), localHand1);
              if (j > k)
                arrayOfDouble[i3][0] += d1;
              else if (j == k)
                arrayOfDouble[i3][1] += d1;
              else
                arrayOfDouble[i3][2] += d1;
            }
          }
        localHand3.removeCard();
      }
      localHand3.removeCard();
    }
    int i7 = i4 != 0 ? 990 : 48 - paramHand.size();
    double d2 = i7 * (arrayOfDouble1[2] + arrayOfDouble1[1] / 2.0D);
    double d3 = i7 * (arrayOfDouble1[0] + arrayOfDouble1[1] / 2.0D);
    if (d2 > 0.0D)
      this.E = ((arrayOfDouble[2][0] + arrayOfDouble[2][1] / 2.0D + arrayOfDouble[1][0] / 2.0D) / d2);
    else
      this.E = 0.0D;
    if (d3 > 0.0D)
      this.M = ((arrayOfDouble[0][2] + arrayOfDouble[0][1] / 2.0D + arrayOfDouble[1][2] / 2.0D) / d3);
    else
      this.M = 0.0D;
    return this.E;
  }

  private int A(int paramInt, Hand paramHand)
  {
    if (this.D[paramInt] > 0)
      return this.D[paramInt];
    paramHand.addCard(paramInt);
    this.D[paramInt] = HandEvaluator.rankHand(paramHand);
    paramHand.removeCard();
    return this.D[paramInt];
  }

  private int A(int paramInt1, int paramInt2, Hand paramHand)
  {
    if (paramInt1 < paramInt2)
    {
      int i = paramInt1;
      paramInt1 = paramInt2;
      paramInt2 = i;
    }
    if (this.A[paramInt1][paramInt2] > 0)
      return this.A[paramInt1][paramInt2];
    paramHand.addCard(paramInt1);
    paramHand.addCard(paramInt2);
    this.A[paramInt1][paramInt2] = HandEvaluator.rankHand(paramHand);
    paramHand.removeCard();
    paramHand.removeCard();
    return this.A[paramInt1][paramInt2];
  }

  private int A(int paramInt1, int paramInt2, int paramInt3, Hand paramHand)
  {
    if (paramInt1 < paramInt3)
    {
      i = paramInt1;
      paramInt1 = paramInt3;
      paramInt3 = i;
    }
    if (paramInt2 < paramInt3)
    {
      i = paramInt2;
      paramInt2 = paramInt3;
      paramInt3 = i;
    }
    if (paramInt1 < paramInt2)
    {
      i = paramInt1;
      paramInt1 = paramInt2;
      paramInt2 = i;
    }
    int i = paramInt3 + A(paramInt2, 2) + A(paramInt1, 3);
    int j = this.L[i];
    if (j > 0)
      return j;
    paramHand.addCard(paramInt1);
    paramHand.addCard(paramInt2);
    paramHand.addCard(paramInt3);
    int tmp105_102 = HandEvaluator.rankHand(paramHand);
    j = tmp105_102;
    this.L[i] = tmp105_102;
    paramHand.removeCard();
    paramHand.removeCard();
    paramHand.removeCard();
    return j;
  }

  private int A(int[] paramArrayOfInt, Hand paramHand)
  {
    int i = 1;
    while (i != 0)
    {
      i = 0;
      if (paramArrayOfInt[0] < paramArrayOfInt[1])
      {
        A(paramArrayOfInt, 0, 1);
        i = 1;
      }
      if (paramArrayOfInt[1] < paramArrayOfInt[2])
      {
        A(paramArrayOfInt, 1, 2);
        i = 1;
      }
      if (paramArrayOfInt[2] < paramArrayOfInt[3])
      {
        A(paramArrayOfInt, 2, 3);
        i = 1;
      }
    }
    int j = paramArrayOfInt[3] + A(paramArrayOfInt[2], 2) + A(paramArrayOfInt[1], 3) + A(paramArrayOfInt[0], 4);
    int k = this.K[j];
    if (k > 0)
      return k;
    paramHand.addCard(paramArrayOfInt[0]);
    paramHand.addCard(paramArrayOfInt[1]);
    paramHand.addCard(paramArrayOfInt[2]);
    paramHand.addCard(paramArrayOfInt[3]);
    int tmp156_153 = HandEvaluator.rankHand7(paramHand);
    k = tmp156_153;
    this.K[j] = tmp156_153;
    paramHand.removeCard();
    paramHand.removeCard();
    paramHand.removeCard();
    paramHand.removeCard();
    return k;
  }

  private final int A(int paramInt1, int paramInt2)
  {
    if (paramInt2 == 1)
      return paramInt1;
    return (paramInt1 - (paramInt2 - 1)) * A(paramInt1, paramInt2 - 1) / paramInt2;
  }

  private final void A(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    int i = paramArrayOfInt[paramInt1];
    paramArrayOfInt[paramInt1] = paramArrayOfInt[paramInt2];
    paramArrayOfInt[paramInt2] = i;
  }

  public static double A(Card paramCard1, Card paramCard2, Hand paramHand)
  {
    Hand localHand = new Hand();
    double d = 0.0D;
    int j = 0;
    int n = -1;
    int i1 = paramHand.size();
    int[] arrayOfInt1 = new int[4];
    int[] arrayOfInt2 = new int[13];
    localHand.addCard(paramCard1);
    localHand.addCard(paramCard2);
    for (int i = 0; i < paramHand.size(); i++)
      localHand.addCard(paramHand.getCard(i + 1));
    for (i = 2; i < localHand.size(); i++)
    {
      k = localHand.getCard(i + 1).getRank();
      if (k > j)
        j = k;
      arrayOfInt2[k] += 1;
      if (arrayOfInt2[k] > 1)
        n = k;
      arrayOfInt1[localHand.getCard(i + 1).getSuit()] += 1;
    }
    if (localHand.getCard(1).getRank() != localHand.getCard(2).getRank())
    {
      for (i = 0; i < 2; i++)
      {
        int i2 = i == 0 ? 1 : 0;
        k = localHand.getCard(i + 1).getRank();
        if (k > j)
          d += 2.7D;
        else if ((j > localHand.getCard(i2 + 1).getRank()) && (j > k) && (arrayOfInt2[localHand.getCard(i2 + 1).getRank()] > 0) && (arrayOfInt2[k] == 0))
          d += 2.85D;
        else if ((k < j) && (arrayOfInt2[k] == 0))
          d += 1.8D;
        else if ((arrayOfInt2[k] == 1) && (n < k))
          d += 0.95D * (3 - arrayOfInt2[k]);
        else if ((arrayOfInt2[k] == 2) && (n == k))
          d += 2.85D * (i1 - 2);
      }
    }
    else if (arrayOfInt2[localHand.getCard(1).getRank()] != 0)
    {
      if (n == 0)
        d += 2.7D * (i1 - 1);
    }
    else
    {
      d += 1.98D;
      if ((j < localHand.getCard(1).getRank()) && (n == 0))
        d += 0.75D * i1;
    }
    int[] arrayOfInt3 = new int[4];
    int[] arrayOfInt4 = new int[4];
    for (i = 0; i < 2; i++)
    {
      arrayOfInt3[localHand.getCard(i + 1).getSuit()] += 1;
      arrayOfInt4[localHand.getCard(i + 1).getSuit()] = localHand.getCard(i + 1).getRank();
    }
    for (int m = 0; m < 4; m++)
      if (arrayOfInt1[m] + arrayOfInt3[m] == 4)
        if (arrayOfInt3[m] == 1)
          d += (0.5D + 0.5D * arrayOfInt4[m] / 13.0D) * 9.0D;
        else if (arrayOfInt3[m] == 2)
          d += 9.0D;
    int i3 = 0;
    int i4 = 0;
    int i5 = 0;
    int i6 = 0;
    int i7 = localHand.getCard(1).getRank();
    int i8 = localHand.getCard(2).getRank();
    if (arrayOfInt2[12] != 0)
    {
      i3++;
    }
    else if ((i7 == 12) || (i8 == 12))
    {
      i3++;
      i4++;
    }
    else
    {
      i5 = 1;
    }
    for (int k = 0; k < 13; k++)
      if (arrayOfInt2[k] != 0)
      {
        i3++;
        i5++;
      }
      else if ((i7 == k) || (i8 == k))
      {
        i3++;
        i5++;
        i4++;
        i6++;
      }
      else
      {
        if ((i5 >= 5) && (i6 != 0))
          if (i6 == 1)
            d += 2.8D;
          else
            d += 4.0D;
        if (k == 12)
        {
          i5 = i3;
          i6 = i4;
        }
        else
        {
          i5 = i3 + 1;
          i6 = i4;
        }
        i3 = 0;
        i4 = 0;
      }
    if ((i5 >= 5) && (i6 != 0))
      if (i6 == 1)
        d += 2.8D;
      else
        d += 4.0D;
    return d / (52 - localHand.size());
  }

  public int A(int paramInt1, int paramInt2, int paramInt3, Hand paramHand, int[] paramArrayOfInt)
  {
    if (paramInt1 > paramInt3)
    {
      i = paramInt1;
      paramInt1 = paramInt3;
      paramInt3 = i;
    }
    if (paramInt2 > paramInt3)
    {
      i = paramInt2;
      paramInt2 = paramInt3;
      paramInt3 = i;
    }
    if (paramInt1 > paramInt2)
    {
      i = paramInt1;
      paramInt1 = paramInt2;
      paramInt2 = i;
    }
    int i = paramInt1 + A(paramInt2, 2) + A(paramInt3, 3);
    if (paramArrayOfInt[i] <= 0)
    {
      paramHand.addCard(paramInt1);
      paramHand.addCard(paramInt2);
      paramHand.addCard(paramInt3);
      paramArrayOfInt[i] = HandEvaluator.rankHand(paramHand);
      paramHand.removeCard();
      paramHand.removeCard();
      paramHand.removeCard();
    }
    return paramArrayOfInt[i];
  }

  public int A(int paramInt1, int paramInt2, int paramInt3, int paramInt4, Hand paramHand, int[] paramArrayOfInt)
  {
    int i = 1;
    while (i != 0)
    {
      i = 0;
      if (paramInt1 > paramInt2)
      {
        j = paramInt1;
        paramInt1 = paramInt2;
        paramInt2 = j;
        i = 1;
      }
      if (paramInt2 > paramInt3)
      {
        j = paramInt2;
        paramInt2 = paramInt3;
        paramInt3 = j;
        i = 1;
      }
      if (paramInt3 > paramInt4)
      {
        j = paramInt4;
        paramInt4 = paramInt3;
        paramInt3 = j;
        i = 1;
      }
    }
    int j = paramInt1 + A(paramInt2, 2) + A(paramInt3, 3) + A(paramInt4, 4);
    if (paramArrayOfInt[j] <= 0)
    {
      paramHand.addCard(paramInt1);
      paramHand.addCard(paramInt2);
      paramHand.addCard(paramInt3);
      paramHand.addCard(paramInt4);
      paramArrayOfInt[j] = HandEvaluator.rankHand(paramHand);
      paramHand.removeCard();
      paramHand.removeCard();
      paramHand.removeCard();
      paramHand.removeCard();
    }
    return paramArrayOfInt[j];
  }

  public double A(Card paramCard1, Card paramCard2, Hand paramHand, boolean paramBoolean)
  {
    double[][] arrayOfDouble = new double[3][3];
    double[] arrayOfDouble1 = new double[3];
    int i3 = (paramHand.size() == 3) && (paramBoolean) ? 1 : 0;
    int i6 = HandEvaluator.rankHand(paramCard1, paramCard2, paramHand);
    int[] arrayOfInt = new int[i3 != 0 ? 270725 : 22100];
    this.H.reset();
    this.H.extractCard(paramCard1);
    this.H.extractCard(paramCard2);
    this.H.extractHand(paramHand);
    for (int k = this.H.getTopCardIndex(); k < 52; k++)
    {
      int i4 = this.H.getCard(k).getIndex();
      for (int m = k + 1; m < 52; m++)
      {
        int i5 = this.H.getCard(m).getIndex();
        int j = HandEvaluator.rankHand(i4, i5, paramHand);
        int i2;
        if (i6 > j)
          i2 = 0;
        else if (i6 == j)
          i2 = 1;
        else
          i2 = 2;
        arrayOfDouble1[i2] += 1.0D;
        for (int n = this.H.getTopCardIndex(); n < 52; n++)
          if ((k != n) && (m != n))
          {
            int i;
            if (i3 != 0)
            {
              for (int i1 = n + 1; i1 < 52; i1++)
                if ((k != i1) && (m != i1))
                {
                  i = A(paramCard1.getIndex(), paramCard2.getIndex(), this.H.getCard(n).getIndex(), this.H.getCard(i1).getIndex(), paramHand, arrayOfInt);
                  j = A(i4, i5, this.H.getCard(n).getIndex(), this.H.getCard(i1).getIndex(), paramHand, arrayOfInt);
                  if (i > j)
                    arrayOfDouble[i2][0] += 1.0D;
                  else if (i == j)
                    arrayOfDouble[i2][1] += 1.0D;
                  else
                    arrayOfDouble[i2][2] += 1.0D;
                }
            }
            else
            {
              i = A(paramCard1.getIndex(), paramCard2.getIndex(), this.H.getCard(n).getIndex(), paramHand, arrayOfInt);
              j = A(i4, i5, this.H.getCard(n).getIndex(), paramHand, arrayOfInt);
              if (i > j)
                arrayOfDouble[i2][0] += 1.0D;
              else if (i == j)
                arrayOfDouble[i2][1] += 1.0D;
              else
                arrayOfDouble[i2][2] += 1.0D;
            }
          }
      }
    }
    int i7 = i3 != 0 ? 990 : 48 - paramHand.size();
    double d1 = i7 * (arrayOfDouble1[2] + arrayOfDouble1[1] / 2.0D);
    double d2 = i7 * (arrayOfDouble1[0] + arrayOfDouble1[1] / 2.0D);
    if (d1 > 0.0D)
      this.E = ((arrayOfDouble[2][0] + arrayOfDouble[2][1] / 2.0D + arrayOfDouble[1][0] / 2.0D) / d1);
    else
      this.E = 0.0D;
    if (d2 > 0.0D)
      this.M = ((arrayOfDouble[0][2] + arrayOfDouble[0][1] / 2.0D + arrayOfDouble[1][2] / 2.0D) / d2);
    else
      this.M = 0.0D;
    return this.E;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.D.A
 * JD-Core Version:    0.6.2
 */