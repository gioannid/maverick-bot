package com.biotools.poker.D;

import java.io.Serializable;
import java.util.StringTokenizer;

public class I
  implements Serializable
{
  private int B = 3;
  private int E = 40;
  private byte[] A;
  private int[] G;
  private int D;
  private int F;
  private String C;

  public I()
  {
    D();
  }

  public I(I paramI)
  {
    D();
    for (int i = 0; i < this.E; i++)
      this.A[i] = paramI.A[i];
    for (i = 0; i < this.B; i++)
      this.G[i] = paramI.G[i];
    this.D = paramI.D;
    this.F = paramI.F;
    this.C = paramI.C;
  }

  public I(String paramString)
  {
    this.C = paramString;
    this.F = 0;
    this.D = 0;
    D();
  }

  public I(String paramString, int paramInt)
  {
    this.C = paramString;
    this.F = 0;
    this.D = 0;
    this.E = paramInt;
    D();
  }

  private void D()
  {
    this.A = new byte[this.E];
    this.G = new int[this.B];
  }

  public String A()
  {
    return this.C;
  }

  public void B(int paramInt)
  {
    if (this.D >= this.E)
      this.G[this.A[this.F]] -= 1;
    this.A[this.F] = ((byte)paramInt);
    this.G[paramInt] += 1;
    this.F = ((this.F + 1) % this.E);
    if (this.D < this.E)
      this.D += 1;
  }

  public void A(int paramInt)
  {
    while (this.D > paramInt)
    {
      if (--this.F < 0)
        this.F = (this.E - 1);
      this.G[this.A[this.F]] -= 1;
      this.D -= 1;
    }
  }

  public C B()
  {
    return new C(this.G[0] / this.D, this.G[1] / this.D, this.G[2] / this.D);
  }

  public double C(int paramInt)
  {
    return this.G[paramInt] / this.D;
  }

  public int C()
  {
    return this.D;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append(this.C);
    localStringBuffer.append(":");
    localStringBuffer.append(this.E);
    localStringBuffer.append(":");
    for (int i = 0; i < this.A.length; i++)
    {
      localStringBuffer.append(this.A[i]);
      localStringBuffer.append(',');
    }
    localStringBuffer.append(":");
    localStringBuffer.append(this.G[0]);
    localStringBuffer.append(":");
    localStringBuffer.append(this.G[1]);
    localStringBuffer.append(":");
    localStringBuffer.append(this.G[2]);
    localStringBuffer.append(":");
    localStringBuffer.append(this.D);
    localStringBuffer.append(":");
    localStringBuffer.append(this.F);
    return localStringBuffer.toString();
  }

  public void A(String paramString)
  {
    StringTokenizer localStringTokenizer1 = new StringTokenizer(paramString, ":");
    this.C = localStringTokenizer1.nextToken();
    this.E = Integer.parseInt(localStringTokenizer1.nextToken());
    this.A = new byte[this.E];
    String str = localStringTokenizer1.nextToken();
    StringTokenizer localStringTokenizer2 = new StringTokenizer(str, ",");
    for (int i = 0; i < this.E; i++)
      this.A[i] = ((byte)Integer.parseInt(localStringTokenizer2.nextToken()));
    this.G[0] = Integer.parseInt(localStringTokenizer1.nextToken());
    this.G[1] = Integer.parseInt(localStringTokenizer1.nextToken());
    this.G[2] = Integer.parseInt(localStringTokenizer1.nextToken());
    this.D = Integer.parseInt(localStringTokenizer1.nextToken());
    this.F = Integer.parseInt(localStringTokenizer1.nextToken());
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.D.I
 * JD-Core Version:    0.6.2
 */