package com.biotools.poker.D;

import com.biotools.A.b;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.GameObserver;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.poker.Q.F;
import java.io.File;
import java.io.PrintStream;
import java.util.Arrays;

public class B
  implements GameObserver
{
  private static int Ǭ = 0;
  private static boolean ȃ = false;
  protected static final double ǿ = 0.01D;
  protected static final String Ȉ = com.biotools.poker.E.u() + "default_limit.opp";
  protected static final String ǲ = com.biotools.poker.E.u() + "default_nolimit.opp";
  protected static J ǻ = new J(Ȉ);
  protected static J Ǳ = new J(ǲ);
  private String ȉ;
  private G ǫ = null;
  private E Ǩ = new E();
  private E Ǵ = new E();
  private J Ǿ;
  private double Ȁ = 1.0D;
  private double ǯ = 0.0D;
  private double[] Ȃ;
  private boolean ȇ = false;
  private Deck ȅ = new Deck();
  private GameInfo ȁ;
  private int ǩ = 0;
  private boolean Ǫ = false;
  private boolean Ǽ = false;
  private boolean Ǯ = false;
  private boolean ǽ = false;
  private boolean ǵ = false;
  private boolean ǳ = false;
  private boolean ǧ = false;
  private boolean Ȇ = false;
  private int Ǻ = 0;
  private int Ȅ = 0;
  private int ǰ = 0;
  private int ǭ = 0;

  public B(String paramString, G paramG)
  {
    this.ȉ = paramString;
    this.ǫ = paramG;
    Ǭ += 1;
  }

  private J š()
  {
    if (this.Ǿ == null)
    {
      if (this.ȁ.isNoLimit())
      {
        this.Ǿ = new J(ǲ);
        this.ȇ = true;
      }
      else
      {
        this.Ǿ = new J(Ȉ);
        this.ȇ = false;
      }
      this.Ǿ.A(6);
      this.Ǿ.B(ű());
    }
    if (this.ȇ != this.ȁ.isNoLimit())
    {
      Ŭ();
      this.Ǿ = null;
      return š();
    }
    return this.Ǿ;
  }

  private J ŵ()
  {
    if (this.ȁ.isNoLimit())
      return Ǳ;
    return ǻ;
  }

  public void B(int paramInt, String paramString)
  {
    š().A(paramInt, paramString);
    ŵ().A(paramInt, paramString);
  }

  public void Ŭ()
  {
    if ((this.Ǿ != null) && (this.Ǿ.A()))
    {
      com.biotools.poker.E.H("Saving: " + ű());
      this.Ǿ.E(ű());
    }
    if (ǻ.A())
    {
      com.biotools.poker.E.H("Saving: " + Ȉ);
      ǻ.E(Ȉ);
    }
    if (Ǳ.A())
    {
      com.biotools.poker.E.H("Saving: " + ǲ);
      Ǳ.E(ǲ);
    }
  }

  protected String ű()
  {
    File localFile = new File(com.biotools.poker.E.u());
    if (!localFile.exists())
      localFile.mkdir();
    String str = this.ȇ ? "_N" : "_L";
    return com.biotools.poker.E.u() + this.ȉ.toLowerCase() + str + ".opp";
  }

  public String Ů()
  {
    return this.ȉ;
  }

  public E Ŧ()
  {
    return this.Ǩ;
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    this.ȁ = paramGameInfo;
    this.ǯ = 0.0D;
    this.Ȁ = 1.0D;
    this.ǽ = (this.ǵ = this.ǳ = this.Ȇ = this.ǧ = 0);
    this.Ǫ = (this.Ǯ = this.Ǽ = 0);
    this.Ǩ.A(1.0D);
  }

  public void gameStateChanged()
  {
  }

  public void gameOverEvent()
  {
    int i = this.ȁ.getPlayerSeat(this.ȉ);
    int j = 0;
    if ((this.ȁ.isPreFlop()) && (this.ȁ.isActive(i)))
      j = 1;
    B(j != 0 ? 1 : 0, "STEAL");
    B(this.Ȇ ? 1 : 0, "VP$IP");
    B(this.ǽ ? 1 : 0, "PFOPEN");
    B(this.ǵ ? 1 : 0, "PFRAISE");
    B(this.ǳ ? 1 : 0, "PFBIG");
    B(this.Ǫ ? 1 : 0, "PFFOLD");
    if (this.ȁ.getBigBlindSeat() == i)
      B(this.Ǽ ? 1 : 0, "FOLDBB");
    else if (this.ȁ.getSmallBlindSeat() == i)
      B(this.Ǽ ? 1 : 0, "FOLDSB");
  }

  private int D(double paramDouble1, double paramDouble2)
  {
    int i = 0;
    if (paramDouble1 > 0.0D)
      if (paramDouble1 < paramDouble2 * 0.5D)
        i = 1;
      else if ((paramDouble1 >= paramDouble2 * 0.5D) && (paramDouble1 < paramDouble2 * 1.5D))
        i = 2;
      else if ((paramDouble1 >= paramDouble2 * 1.5D) && (paramDouble1 < paramDouble2 * 4.0D))
        i = 3;
      else
        i = 4;
    return i;
  }

  private String[] ū()
  {
    int i = this.ȁ.getPlayerSeat(this.ȉ);
    int j = this.ȁ.isPreFlop() ? 1 : 0;
    double d = this.ȁ.getBetsToCall(i);
    if ((d > 0.0D) && (d < 1.0D))
    {
      d = 0.5D;
    }
    else
    {
      d = (int)d;
      if (d > 2.0D)
        d = 2.0D;
    }
    F localF = (F)this.ȁ.getPlayer(i);
    int k = localF.isCommitted() ? 1 : 0;
    String[] arrayOfString = new String[7];
    String str = this.ȁ.isNoLimit() ? "N" : "L";
    int m = 0;
    arrayOfString[(m++)] = (str + "B" + d + "F" + j);
    arrayOfString[(m++)] = (str + "B" + d + "C" + k + "F" + j);
    arrayOfString[(m++)] = (str + "B" + d + "S" + this.ȁ.getStage());
    arrayOfString[(m++)] = (str + "B" + d + "S" + this.ȁ.getStage() + "#" + this.ȁ.getNumActivePlayers());
    arrayOfString[(m++)] = (str + "B" + d + "S" + this.ȁ.getStage() + "C" + k);
    arrayOfString[(m++)] = (str + "B" + d + "F" + j + "L" + localF.M());
    arrayOfString[(m++)] = (str + "B" + d + "S" + this.ȁ.getStage() + "L" + localF.M());
    return arrayOfString;
  }

  public C ţ()
  {
    C localC1 = new C();
    String[] arrayOfString = ū();
    for (int i = 0; i < arrayOfString.length; i++)
    {
      C localC2 = š().F(arrayOfString[i]);
      localC2.A(š().D(arrayOfString[i]));
      localC1.B(localC2);
    }
    if (localC1.A() == 0.0D)
      localC1.D(1.0D);
    localC1.E();
    return localC1;
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
    int i = paramAction.getActionIndex();
    if (i == -1)
      return;
    String[] arrayOfString = ū();
    for (int j = 0; j < arrayOfString.length; j++)
      B(i, arrayOfString[j]);
    this.ȅ.reset();
    this.ȅ.extractHand(this.ȁ.getBoard());
    if (this.ȁ.isPreFlop())
      B(i, paramAction.getAmount());
    else if (!this.ȁ.isSimulation())
      A(i, paramAction.getAmount());
    C localC = ţ();
    this.Ȁ *= (1.0D - localC.J());
    if (paramInt == 0)
      com.biotools.poker.E.H("\t" + this.ȉ + " : " + localC + " : " + (int)(100.0D * b.A(this.Ȁ, 2)));
    A(paramInt, paramAction);
  }

  private double M(double paramDouble)
  {
    if (this.Ȃ == null)
      return paramDouble;
    int i = Arrays.binarySearch(this.Ȃ, paramDouble);
    if (i < 0)
    {
      i = -i + 1;
      if (i >= this.Ȃ.length)
        i = this.Ȃ.length - 1;
    }
    return i / this.Ȃ.length;
  }

  public static C A(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7)
  {
    double d1 = 0.0D;
    double d2 = 0.0D;
    double d3 = 0.0D;
    double d4 = paramDouble2 + (1.0D - paramDouble2) * paramDouble3;
    if (d4 > paramDouble7)
    {
      d3 = 1.0D;
      d2 = 0.5D;
      d1 = paramDouble1 + Math.pow(paramDouble1, paramDouble5 + 1.0D);
      if (paramDouble3 > paramDouble4)
        d1 = 0.0D;
    }
    else if (d4 > paramDouble6)
    {
      d3 = 0.5D;
      d2 = 1.0D;
      d1 = paramDouble1 + Math.pow(paramDouble1, paramDouble5 + 1.0D);
      if (paramDouble3 > paramDouble4)
        d1 = 0.0D;
    }
    else
    {
      if (paramDouble5 > 0.0D)
      {
        d3 = paramDouble1;
        d2 = paramDouble1 * 2.0D;
      }
      else
      {
        d3 = paramDouble1;
        d2 = 1.0D - paramDouble1;
      }
      d1 = 1.0D;
      if (paramDouble3 > paramDouble4)
      {
        d3 = 0.35D;
        d2 = 1.0D;
        d1 = 0.0D;
      }
      else
      {
        d2 += paramDouble3;
        d3 += paramDouble3 * paramDouble3;
      }
    }
    if (paramDouble5 == 0.0D)
      d1 = 0.0D;
    return new C(d1, d2, d3);
  }

  public double A(Card paramCard1, Card paramCard2, Deck paramDeck)
  {
    double d = HandEvaluator.handRank(paramCard1, paramCard2, G.A(this.ȁ).ŷ(), paramDeck);
    return Math.pow(d, this.ȁ.getNumActivePlayers() - 1);
  }

  public double B(Card paramCard1, Card paramCard2, Deck paramDeck)
  {
    int i = this.ȁ.getPlayerSeat(this.ȉ);
    double d1 = 1.0D;
    for (int j = 0; j < this.ȁ.getNumSeats(); j++)
      if ((this.ȁ.inGame(j)) && (this.ȁ.isActive(j)) && (j != i))
      {
        double d2 = this.ǫ.Q(j).C(paramCard1, paramCard2, paramDeck);
        d1 *= d2;
      }
    return d1;
  }

  public double C(Card paramCard1, Card paramCard2, Deck paramDeck)
  {
    double d = this.Ǵ.A(paramCard1, paramCard2);
    if (d < 0.0D)
    {
      d = this.Ǩ.A(paramCard1, paramCard2, G.A(this.ȁ).ŷ(), paramDeck);
      this.Ǵ.A(paramCard1, paramCard2, d);
    }
    return d;
  }

  public void Ţ()
  {
    this.Ǵ.A(-1.0D);
  }

  public double A(Card paramCard1, Card paramCard2)
  {
    int i = this.ȁ.getPlayerSeat(this.ȉ);
    double d = 1.0D;
    Deck localDeck = new Deck();
    localDeck.extractCard(paramCard1);
    localDeck.extractCard(paramCard2);
    localDeck.extractHand(this.ȁ.getBoard());
    for (int j = 0; j < this.ȁ.getNumSeats(); j++)
      if ((this.ȁ.inGame(j)) && (this.ȁ.isActive(j)) && (j != i))
        d *= this.ǫ.Q(j).C(paramCard1, paramCard2, localDeck);
    return d;
  }

  public double[] ũ()
  {
    int i = this.ȁ.getPlayerSeat(this.ȉ);
    C localC = ţ();
    this.Ȃ = null;
    if (this.ȁ.isSimulation())
    {
      double[] arrayOfDouble1 = { localC.J(), 1.0D - localC.D() };
      if (this.ȁ.getBetsToCall(i) == 0.0D)
        arrayOfDouble1[0] = 0.0D;
      return arrayOfDouble1;
    }
    int j = 0;
    this.Ȃ = new double[this.ȅ.cardsLeft() * (this.ȅ.cardsLeft() - 1) / 2];
    for (int k = this.ȅ.getTopCardIndex(); k < 52; k++)
    {
      Card localCard1 = this.ȅ.getCard(k);
      for (int n = k + 1; n < 52; n++)
      {
        Card localCard2 = this.ȅ.getCard(n);
        d2 = this.ȁ.isRiver() ? 0.0D : A.A(localCard1, localCard2, this.ȁ.getBoard());
        double d3 = this.ȁ.isSimulation() ? A(localCard1, localCard2, this.ȅ) : B(localCard1, localCard2, this.ȅ);
        double d4 = d3 + (1.0D - d3) * d2;
        this.Ȃ[(j++)] = d4;
      }
    }
    Arrays.sort(this.Ȃ);
    k = (int)(j * (1.0D - this.Ȁ) + (localC.J() + localC.C()) * j * this.Ȁ);
    int m = (int)(j * (1.0D - this.Ȁ) + localC.J() * j * this.Ȁ);
    if (k >= j)
      k = j - 1;
    if (m >= j)
      m = j - 1;
    double d1 = this.Ȃ[k];
    double d2 = this.Ȃ[m];
    d2 = (d2 + localC.J()) * 0.5D;
    d1 = (d1 + (1.0D - localC.D())) * 0.5D;
    if (this.ȁ.getBetsToCall(i) == 0.0D)
      d2 = 0.0D;
    double[] arrayOfDouble2 = { d2, d1 };
    return arrayOfDouble2;
  }

  public void A(int paramInt, double paramDouble)
  {
    int i = this.ȁ.getPlayerSeat(this.ȉ);
    PlayerInfo localPlayerInfo = this.ȁ.getPlayer(i);
    double d1 = localPlayerInfo.getAmountToCall() / (localPlayerInfo.getAmountToCall() + this.ȁ.getEligiblePot(i));
    int j = (int)this.ȁ.getBetsToCall(i);
    double[] arrayOfDouble = ũ();
    double d2 = 0.0D;
    double d3 = 0.0D;
    this.ǯ = 0.0D;
    for (int k = this.ȅ.getTopCardIndex(); k < 52; k++)
    {
      Card localCard1 = this.ȅ.getCard(k);
      for (int m = k + 1; m < 52; m++)
      {
        Card localCard2 = this.ȅ.getCard(m);
        double d4 = this.ȁ.isRiver() ? 0.0D : A.A(localCard1, localCard2, this.ȁ.getBoard());
        if (!this.ȁ.isSimulation());
        double d5 = A(localCard1, localCard2, this.ȅ);
        double d6 = d5 + (1.0D - d5) * d4;
        C localC = A(0.01D, d5, d4, d1, j, arrayOfDouble[0], arrayOfDouble[1]);
        double d7 = this.Ǩ.B(localCard1, localCard2, 0.01D + 0.99D * localC.A(paramInt));
        d3 += d7 * d6;
        d2 += d7;
      }
    }
    this.ǯ = (d3 / d2);
    Ţ();
  }

  public void B(int paramInt, double paramDouble)
  {
    double d1 = 0.0D;
    double d2 = 0.0D;
    this.ǯ = 0.0D;
    int i = 7;
    int j = this.ȁ.getPlayerSeat(this.ȉ);
    int k = D.A(12, 12, false, i);
    C localC1 = ţ();
    for (int m = this.ȅ.getTopCardIndex(); m < 52; m++)
    {
      Card localCard1 = this.ȅ.getCard(m);
      for (int n = m + 1; n < 52; n++)
      {
        Card localCard2 = this.ȅ.getCard(n);
        int i1 = D.A(localCard1.getRank(), localCard2.getRank(), localCard1.getSuit() == localCard2.getSuit(), i);
        C localC2 = D.A(i1, localC1.J(), 1.0D - localC1.D(), 0.01D);
        double d3 = this.Ǩ.B(localCard1, localCard2, 0.01D + 0.99D * localC2.A(paramInt));
        d2 += d3 * (i1 / k);
        d1 += d3;
      }
    }
    this.ǯ = (d2 / d1);
  }

  public void stageEvent(int paramInt)
  {
    Ţ();
    for (int i = 1; i <= this.ȁ.getBoard().size(); i++)
      this.Ǩ.A(this.ȁ.getBoard().getCard(i));
    if (this.ȁ.isFlop())
      this.Ȁ = 1.0D;
    else
      this.Ȁ = (0.25D + this.Ȁ * 0.75D);
    i = this.ȁ.getPlayerSeat(this.ȉ);
    if ((ȃ) && (!this.ȁ.isSimulation()) && (!this.ȁ.isZipMode()) && (this.ȁ.isPostFlop()) && (this.ȁ.isActive(i)))
      Ų();
  }

  private void Ų()
  {
    double d1 = 0.0D;
    double d2 = 0.0D;
    this.ǯ = 0.0D;
    for (int i = this.ȅ.getTopCardIndex(); i < 52; i++)
    {
      Card localCard1 = this.ȅ.getCard(i);
      for (int j = i + 1; j < 52; j++)
      {
        Card localCard2 = this.ȅ.getCard(j);
        double d3 = this.ȁ.isRiver() ? 0.0D : A.A(localCard1, localCard2, this.ȁ.getBoard());
        double d4 = B(localCard1, localCard2, this.ȅ);
        double d5 = d4 + (1.0D - d4) * d3;
        double d6 = this.Ǩ.A(localCard1, localCard2);
        d2 += d6 * d5;
        d1 += d6;
      }
    }
    this.ǯ = (d2 / d1);
  }

  public double Ū()
  {
    if ((this.ȁ != null) && (this.ȁ.isPreFlop()))
      return 1.0D - this.Ȁ;
    return this.ǯ;
  }

  private void ŭ()
  {
    int i = this.ȁ.getPlayerSeat(this.ȉ);
    PlayerInfo localPlayerInfo = this.ȁ.getPlayer(i);
    com.biotools.poker.E.H(this.ȉ + ": " + this.ǩ + " hands, VP$IP: " + b.A(100.0D * Ť(), 1) + "%" + " Steals: " + b.A(100.0D * ŧ(), 1) + "%" + " POOL:" + b.A(100.0D * this.Ȁ, 2));
    com.biotools.poker.E.H("    PreFlop | open: " + b.A(100.0D * Ű(), 1) + ", raise: " + b.A(100.0D * ų(), 1) + ", big: " + b.A(100.0D * ů(), 1));
    com.biotools.poker.E.H("    PreFlop | fold: " + b.A(100.0D * ť(), 1) + ", foldSB: " + b.A(100.0D * Ũ(), 1) + ", foldBB: " + b.A(100.0D * Š(), 1));
  }

  public int Ŷ()
  {
    return this.ǩ;
  }

  public double Ť()
  {
    return š().A("VP$IP", 1);
  }

  public double ŧ()
  {
    return š().A("STEAL", 1);
  }

  public double Ű()
  {
    return š().A("PFOPEN", 1);
  }

  public double ų()
  {
    return š().A("PFRAISE", 1);
  }

  public double ů()
  {
    return š().A("PFBIG", 1);
  }

  public double ť()
  {
    return š().A("PFFOLD", 1);
  }

  public double Š()
  {
    return š().A("FOLDBB", 1);
  }

  public double Ũ()
  {
    return š().A("FOLDSB", 1);
  }

  private void A(int paramInt, Action paramAction)
  {
    if (!paramAction.isVoluntary())
      return;
    PlayerInfo localPlayerInfo = this.ȁ.getPlayer(paramInt);
    if (!this.ǧ)
      this.ǩ += 1;
    this.ǧ = true;
    if ((!paramAction.isFold()) && (paramAction.getAmount() + paramAction.getToCall() > 0.0D))
      this.Ȇ = true;
    double d;
    if (this.ȁ.isPreFlop())
    {
      if (paramAction.isFold())
      {
        if (this.ȁ.getBigBlindSeat() == paramInt)
          this.Ǽ = true;
        else if (this.ȁ.getSmallBlindSeat() == paramInt)
          this.Ǯ = true;
        this.Ǫ = true;
      }
      if (paramAction.isBetOrRaise())
      {
        d = this.ȁ.getMainPotSize() + paramAction.getToCall();
        if ((paramAction.getAmount() > this.ȁ.getBigBlindSize()) && (paramAction.getAmount() > d) && (paramAction.getAmount() > localPlayerInfo.getBankRoll() / 3.0D))
          this.ǳ = true;
        if (this.ȁ.getNumRaises() == 1)
          this.ǽ = true;
        else if (!localPlayerInfo.isCommitted())
          this.ǵ = true;
      }
    }
    else
    {
      this.Ǻ += 1;
      if (paramAction.isBetOrRaise())
      {
        d = this.ȁ.getMainPotSize() + paramAction.getToCall();
        if ((paramAction.getAmount() > this.ȁ.getBigBlindSize()) && (paramAction.getAmount() > d) && (paramAction.getAmount() > localPlayerInfo.getBankRoll() / 3.0D))
          this.ǭ += 1;
        if (this.ȁ.getNumRaises() == 0)
          this.Ȅ += 1;
        else if (!localPlayerInfo.isCommitted())
          this.ǰ += 1;
      }
    }
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
  }

  public void dealHoleCardsEvent()
  {
  }

  public void finalize()
  {
    Ǭ -= 1;
  }

  public static void Ŵ()
  {
    System.out.println(Ǭ + " OppModels");
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.D.B
 * JD-Core Version:    0.6.2
 */