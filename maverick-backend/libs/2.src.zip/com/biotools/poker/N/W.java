package com.biotools.poker.N;

import com.biotools.B.L;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.Player;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.A;
import com.biotools.poker.F.H;
import com.biotools.poker.F.J;
import com.biotools.poker.M.C;
import com.biotools.poker.PokerApp;
import com.biotools.poker.Q.K;

public class W
  implements Player
{
  private int ƅ = 0;
  private PokerApp ƃ;
  private GameInfo Ɓ;
  private volatile Action Ƃ;
  private volatile boolean Ƅ = false;

  public W(PokerApp paramPokerApp)
  {
    this.ƃ = paramPokerApp;
  }

  public int Ď()
  {
    return this.ƅ;
  }

  public void init(Preferences paramPreferences)
  {
  }

  public void holeCards(Card paramCard1, Card paramCard2, int paramInt)
  {
    this.ƅ = paramInt;
    this.ƃ.A(paramCard1, paramCard2, paramInt);
    this.ƃ.ʑ().holeCards(paramCard1, paramCard2, paramInt);
  }

  public void A(Action paramAction)
  {
    this.Ƃ = paramAction;
    this.Ƅ = false;
  }

  public boolean ċ()
  {
    return this.Ƅ;
  }

  public void gameStateChanged()
  {
    ĉ();
    this.ƃ.ʑ().gameStateChanged();
  }

  public Action getAction()
  {
    this.Ƃ = ď().A(this, this.ƃ.ɞ());
    if (this.Ƃ != null)
    {
      if ((this.Ƃ.isFold()) && (!this.ƃ.Ǽ()))
        if (this.ƃ.Ǻ())
          this.ƃ.ȑ();
        else
          this.ƃ.ʋ().Ǣ().G(true);
      ď().B();
      return this.Ƃ;
    }
    this.Ƅ = true;
    this.ƃ.O(true);
    Č();
    while ((this.Ƅ) && (this.ƃ.ʐ().R()))
      L.C(50L);
    this.Ƅ = false;
    return this.Ƃ;
  }

  private void Č()
  {
    Thread localThread = new Thread(new Runnable()
    {
      public void run()
      {
        W.this.ƃ.ʑ().getAction();
      }
    }
    , "Human Action");
    localThread.start();
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
    ĉ();
    this.ƃ.ʑ().actionEvent(paramInt, paramAction);
  }

  public void stageEvent(int paramInt)
  {
    ĉ();
    this.ƃ.ʑ().stageEvent(paramInt);
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
    ď().D(false);
    this.ƃ.ʑ().showdownEvent(paramInt, paramCard1, paramCard2);
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    this.Ɓ = paramGameInfo;
    this.ƃ.ʑ().gameStartEvent(paramGameInfo);
  }

  public void gameOverEvent()
  {
    ĉ();
    this.ƃ.ʑ().gameOverEvent();
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
    ď().D(false);
    this.ƃ.ʑ().winEvent(paramInt, paramDouble, paramString);
  }

  private void ĉ()
  {
    if (this.ƃ.ʔ())
      ď().D(false);
    else
      ď().A(this.Ɓ, this.ƅ);
  }

  public H ď()
  {
    return this.ƃ.ʋ().Ǆ();
  }

  public Action Ċ()
  {
    this.Ƃ = null;
    this.Ƅ = true;
    this.ƃ.o(this.ƅ);
    if ((ď() != null) && (ď().D()))
    {
      this.Ƃ = Action.sitout();
      ď().A(true);
      ď().C(true);
    }
    else
    {
      this.ƃ.ʋ().J(true);
      while ((this.Ƅ) && (this.ƃ.ʐ().R()))
        L.C(50L);
    }
    this.Ƅ = false;
    return this.Ƃ;
  }

  public void dealHoleCardsEvent()
  {
    this.ƃ.ʑ().dealHoleCardsEvent();
  }

  public GameInfo č()
  {
    return this.Ɓ;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.W
 * JD-Core Version:    0.6.2
 */