package com.biotools.poker.N;

import com.biotools.A.W;
import com.biotools.A.b;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.D.A;
import com.biotools.poker.D.C;
import com.biotools.poker.E;
import com.biotools.poker.N.D.B;

public class P extends G
{
  private boolean r = false;
  private double p = -1.0D;
  protected C q;

  public P()
  {
  }

  public P(Preferences paramPreferences)
  {
    init(paramPreferences);
  }

  public void init(Preferences paramPreferences)
  {
    super.init(paramPreferences);
    this.p = this.o.getDoublePreference("PT_MIX");
    J("    THRESH=" + Q() + "/" + T());
  }

  public double b()
  {
    return this.o.getDoublePreference("PF_DECEPTION", 0.025D);
  }

  public double e()
  {
    return this.o.getDoublePreference("HANDRANK", 0.2D);
  }

  public double _()
  {
    return this.o.getDoublePreference("CHECK_RAISE", 0.2D);
  }

  public double c()
  {
    return this.o.getDoublePreference("CHECK_RAISE", 0.85D);
  }

  public boolean a()
  {
    return this.o.getBooleanPreference("USE_IMPLIED_ODDS", false);
  }

  public boolean d()
  {
    return this.o.getBooleanPreference("USE_AIE", false);
  }

  public void stageEvent(int paramInt)
  {
    super.stageEvent(paramInt);
    this.r = false;
  }

  public synchronized Action getAction()
  {
    int i = this.k.getAmountToCall(this.e) == 0.0D ? 1 : 0;
    double d2;
    if (this.k.isPreFlop())
    {
      i = R();
      this.q = new C(i);
      d1 = b();
      d2 = this.k.getBetsToCall(this.e);
      if ((i == 0) && (d2 == 1.0D) && (this.k.getNumToAct() < 5) && (m.nextDouble() < d1))
      {
        if ((this.h.getSuit() == this.g.getSuit()) || (this.h.getRank() == this.g.getRank()) || (m.nextDouble() < d1))
        {
          J("*** DECEPTION ***");
          if (m.nextDouble() < d1)
            i = 1;
          this.q.B(new C(0.0D, d1, 0.0D));
          this.q.E();
        }
      }
      else if ((i == 0) && (this.k.getPlayer(this.e).isCommitted()))
      {
        if (m.nextDouble() < d1)
          i = 1;
        this.q.B(new C(0.0D, d1, 0.0D));
        this.q.E();
      }
      else if (i == 2)
      {
        if (m.nextDouble() < d1)
          i = 1;
        this.q.B(new C(0.0D, d1, 0.0D));
        this.q.E();
        J("*** DECEPTION ***");
      }
      else if ((i == 1) && (d2 > 0.0D) && ((this.h.getSuit() == this.g.getSuit()) || (this.h.getRank() == this.g.getRank()) || (m.nextDouble() < d1)))
      {
        if (m.nextDouble() < d1)
          i = 2;
        this.q.B(new C(0.0D, 0.0D, d1));
        this.q.E();
        J("*** DECEPTION ***");
      }
      if ((i == 2) && (this.k.getNumRaises() >= 4))
        i = 1;
    }
    else
    {
      A(this.e);
      this.l.reset();
      this.l.extractCard(this.h);
      this.l.extractCard(this.g);
      this.l.extractHand(this.k.getBoard());
      d1 = B(this.e, this.h, this.g, this.l);
      d2 = d1;
      if (!this.k.isSimulation())
        d2 = (1.0D - e()) * A(this.e, this.h, this.g, this.l) + e() * d1;
      double d3 = 0.0D;
      double d4 = 0.0D;
      if (this.k.getStage() != 3)
        if ((this.k.isSimulation()) || (this.k.isZipMode()) || (this.o.getBooleanPreference("CRUDE_PPOT")))
        {
          d3 = A.A(this.h, this.g, this.k.getBoard());
        }
        else
        {
          double[] arrayOfDouble = A.B(this.h, this.g, this.k.getBoard(), this.n);
          d3 = arrayOfDouble[0];
          d4 = arrayOfDouble[1];
        }
      double d5 = d2 + (1.0D - d2) * d3;
      double d7;
      if (d())
      {
        long l1 = System.currentTimeMillis();
        B localB = new B();
        d7 = localB.B(this.e, this.h, this.g, this.k);
        long l2 = System.currentTimeMillis() - l1;
        d5 = d7;
      }
      if (HandEvaluator.isTheNuts(this.h, this.g, this.k.getBoard(), com.biotools.poker.D.G.A(this.k).ŷ()))
        d1 = d2 = d5 = 1.0D;
      C localC = A(d3, d4, d2, d5);
      this.d = m.nextDouble();
      if (this.p > 0.0D)
        A(localC, (this.k.getAmountToCall(this.e) > 0.0D) && (d5 < 0.2D), this.p);
      J(" | HSn = " + b.A(d2, 3) + " PPot = " + b.A(d3, 3) + " EHS = " + b.A(d5, 3));
      J(" | HRn = " + b.A(d1, 3) + " SPIN = " + b.A(this.d, 3) + " " + localC.toString());
      if ((localC.G()) && (this.k.getAmountToCall(this.e) == 0.0D) && (this.k.getUnacted() > 1))
      {
        double d6 = c();
        d7 = _();
        if ((d2 > d6) || ((d2 >= 0.47D) && (d2 <= 0.5D)))
        {
          i = 1;
          localC.B(new C(0.0D, d7 / (1.0D - d7), 0.0D));
          localC.E();
          this.r = true;
        }
      }
      if ((d1 < 1.0D) && (i == 2) && (this.k.getNumRaises() > 4))
      {
        localC.D(localC.C() + localC.D());
        localC.F(0.0D);
        localC.E();
      }
      i = localC.C(this.d);
      this.q = localC;
      if ((i == 2) && (this.k.getNumRaises() >= 4) && ((d1 != 1.0D) || (!this.k.isRiver())))
        i = 1;
    }
    double d1 = this.k.getAmountToCall(this.e);
    Action localAction = Action.getAction(i, d1, this.k.getCurrentBetSize());
    return S.A(localAction, this.e, this.h, this.g, this.k);
  }

  public C h()
  {
    return this.q;
  }

  public void A(C paramC, boolean paramBoolean, double paramDouble)
  {
    double d = paramBoolean ? 3 : 2;
    if (paramBoolean)
      paramC.B(paramC.J() - paramC.J() * paramDouble + paramDouble / d);
    paramC.D(paramC.C() - paramC.C() * paramDouble + paramDouble / d);
    paramC.F(paramC.D() - paramC.D() * paramDouble + paramDouble / d);
  }

  public double f()
  {
    return 0.3D * _();
  }

  public C A(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    double d1 = Q();
    double d2 = T();
    double d3 = this.k.getBigBlindSize();
    double d4 = this.k.getEligiblePot(this.e);
    boolean bool = this.k.getPlayer(this.e).isCommitted();
    double d5 = this.k.getAmountToCall(this.e);
    double d6 = f();
    double d7 = d5 / (d4 + d5);
    double d8 = d5 / (d4 + d5 * (this.k.isFlop() ? 4 : 2));
    if (a())
      d7 = d8;
    double d9 = d5 / this.k.getCurrentBetSize();
    if (this.k.isRiver())
    {
      paramDouble4 = paramDouble3;
      paramDouble1 = paramDouble2 = 0.0D;
    }
    double d10 = 1.0D;
    double d11 = 0.0D;
    double d12 = 0.0D;
    double d13;
    if (paramDouble4 >= d2)
    {
      d10 = 0.0D;
      if (this.k.getNumRaises() < 2)
      {
        d12 = 1.0D;
        if ((paramDouble2 < 0.11D) && (!this.k.isRiver()))
          d12 = 1.0D - d6;
      }
      else
      {
        d12 = 0.0D;
        if (paramDouble4 >= 0.9D)
          d12 = 10.0D * (paramDouble4 - 0.9D);
      }
      if (d12 > 1.0D)
        d12 = 1.0D;
      d11 = 1.0D - d12;
    }
    else if (paramDouble4 >= d1)
    {
      if (d9 == 0.0D)
      {
        d10 = 0.0D;
        d12 = paramDouble1;
        d13 = d1 + 0.05D - d6;
        if (this.k.isRiver())
          d13 += 0.1D;
        if (paramDouble4 >= d13)
        {
          d12 = 5.0D * (paramDouble4 - d13);
          d12 *= (0.25D + 0.75D / this.k.getNumToAct());
        }
        if (d12 > 1.0D)
          d12 = 1.0D;
        d11 = 1.0D - d12;
      }
      else if ((d9 == 1.0D) || (bool))
      {
        d12 = paramDouble1 * 0.5D;
        d13 = d2 - (0.05D + d6);
        if ((paramDouble4 >= d13) && (d9 <= 1.0D))
        {
          d12 = 5.0D * (paramDouble4 - d13);
          d12 *= (0.25D + 0.75D / this.k.getNumToAct());
        }
        if (d12 > 1.0D)
          d12 = 1.0D;
        d10 = 0.0D;
        d11 = 1.0D - d12;
      }
    }
    else if (d9 == 0.0D)
    {
      d12 = paramDouble1;
      if (this.k.isRiver())
        d1 = d1 * 0.75D + d2 * 0.25D;
      d13 = d1 - (0.1D + d6);
      if (paramDouble4 >= d13)
      {
        d12 = 4.0D * (paramDouble4 - d13);
        d12 *= (0.25D + 0.75D / this.k.getNumToAct());
      }
      if (d12 > 1.0D)
        d12 = 1.0D;
      d10 = 0.0D;
      d11 = 1.0D - d12;
    }
    if (d10 == 1.0D)
      if (((this.k.isRiver()) && (paramDouble4 * 0.75D >= d7)) || (paramDouble1 >= d7))
      {
        d10 = 0.0D;
        d11 = 1.0D - paramDouble1 * paramDouble1;
        d12 = paramDouble1 * paramDouble1;
      }
      else if (N())
      {
        d13 = 0.0D;
        if (this.k.isFlop())
          d13 = d3 * 4.0D;
        else if (this.k.isTurn())
          d13 = d3;
        double d14 = (d5 + d13) / (d4 + d5 + 2.0D * d13);
        if (!this.k.isRiver())
          paramDouble4 -= paramDouble3 * paramDouble2;
        if (paramDouble4 * 0.75D >= d14)
        {
          E.H("Showdown Odds: " + d14);
          d10 = 0.1D;
          d11 = 0.9D;
          d12 = 0.0D;
        }
      }
    C localC = new C(d10, d11, d12);
    assert (localC.F()) : ("Invalid Triple: " + localC);
    return localC;
  }

  public double g()
  {
    return this.k.getCurrentBetSize();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.P
 * JD-Core Version:    0.6.2
 */