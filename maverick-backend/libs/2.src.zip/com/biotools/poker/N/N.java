package com.biotools.poker.N;

import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import com.biotools.poker.N.B.A;
import javax.swing.JPanel;

public class N
  implements com.biotools.poker.E.D
{
  int ħ;
  Card Ħ;
  Card ĥ;
  GameInfo ģ;
  Preferences Ĥ;

  public void init(Preferences paramPreferences)
  {
    this.Ĥ = paramPreferences;
  }

  public void holeCards(Card paramCard1, Card paramCard2, int paramInt)
  {
    this.ħ = paramInt;
    this.Ħ = paramCard1;
    this.ĥ = paramCard2;
  }

  public void dealHoleCardsEvent()
  {
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
  }

  public void stageEvent(int paramInt)
  {
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    this.ģ = paramGameInfo;
  }

  public void gameStateChanged()
  {
  }

  public void gameOverEvent()
  {
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
  }

  public Action getAction()
  {
    if (this.ģ.isNoLimit())
      return ð();
    return ñ();
  }

  private double A(Card paramCard1, Card paramCard2, Hand paramHand)
  {
    if (E.¤())
      return Math.random();
    int i = 0;
    int j = 50;
    int k = 0;
    int m = HandEvaluator.rankHand(paramCard1, paramCard2, this.ģ.getBoard());
    Deck localDeck = new Deck();
    localDeck.extractHand(this.ģ.getBoard());
    for (int n = 0; n < j; n++)
    {
      Card localCard1 = localDeck.extractRandomCard();
      Card localCard2 = localDeck.extractRandomCard();
      int i1 = HandEvaluator.rankHand(localCard1, localCard2, this.ģ.getBoard());
      if (m > i1)
        i++;
      if (m == i1)
        k++;
      localDeck.replaceCard(localCard1);
      localDeck.replaceCard(localCard2);
    }
    return (i + k / 2.0D) / j;
  }

  public Action ð()
  {
    if (this.ģ.isPreFlop())
    {
      int i = A.A(this.Ħ, this.ĥ, this.ħ, this.ģ);
      return Action.getAction(i, this.ģ.getAmountToCall(this.ħ), this.ģ.getMinRaise());
    }
    if (this.ģ.isPostFlop())
    {
      double d = A(this.Ħ, this.ĥ, this.ģ.getBoard());
      if (this.ģ.getAmountToCall(this.ħ) == 0.0D)
      {
        if ((d >= 0.95D) && (Math.random() < 0.5D))
          return Action.betAction(this.ģ.getMainPotSize());
        if (d >= 0.85D)
        {
          if (Math.random() < 0.2D)
            return Action.betAction(0.5D * this.ģ.getMainPotSize());
          if (Math.random() < 0.2D)
            return Action.betAction(2.0D * this.ģ.getMinRaise());
        }
        if ((d >= 0.8D) && (Math.random() < 0.25D))
          return Action.betAction(this.ģ.getMinRaise());
        if ((d >= 0.65D) && (Math.random() < 0.25D))
          return Action.betAction(this.ģ.getMinRaise());
      }
      else
      {
        if ((d >= 0.9D) && (Math.random() < 0.25D))
          return Action.raiseAction(this.ģ.getAmountToCall(this.ħ), 0.5D * this.ģ.getMainPotSize());
        if (d >= 0.8D)
          return Action.callAction(this.ģ.getAmountToCall(this.ħ));
        if ((d >= 0.7D) && (this.ģ.getAmountToCall(this.ħ) <= 10.0D * this.ģ.getBigBlindSize()))
          return Action.callAction(this.ģ.getAmountToCall(this.ħ));
      }
    }
    return Action.checkOrFoldAction(this.ģ.getAmountToCall(this.ħ));
  }

  public Action ñ()
  {
    if (this.ģ.isPreFlop())
    {
      int i = A.A(this.Ħ, this.ĥ, this.ħ, this.ģ);
      return Action.getAction(i, this.ģ.getAmountToCall(this.ħ), this.ģ.getCurrentBetSize());
    }
    if (this.ģ.isPostFlop())
    {
      Hand localHand = new Hand(this.ģ.getBoard());
      localHand.addCard(this.Ħ);
      localHand.addCard(this.ĥ);
      assert (localHand.size() >= 5);
      int j = com.biotools.poker.K.D.D(localHand);
      if (this.ģ.getAmountToCall(this.ħ) == 0.0D)
      {
        if (j >= 1)
          return Action.betAction(this.ģ.getCurrentBetSize());
      }
      else
      {
        if (j >= 3)
          return Action.raiseAction(this.ģ.getAmountToCall(this.ħ), this.ģ.getCurrentBetSize());
        if (j >= 2)
          return Action.callAction(this.ģ.getAmountToCall(this.ħ));
        if ((j >= 1) && (this.ģ.getAmountToCall(this.ħ) <= this.ģ.getBigBlindSize()))
          return Action.callAction(this.ģ.getAmountToCall(this.ħ));
      }
    }
    return Action.checkOrFoldAction(this.ģ.getAmountToCall(this.ħ));
  }

  public JPanel A()
  {
    return new JPanel();
  }

  public Preferences B()
  {
    return this.Ĥ;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.N
 * JD-Core Version:    0.6.2
 */