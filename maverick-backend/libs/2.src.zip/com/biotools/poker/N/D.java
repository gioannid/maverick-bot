package com.biotools.poker.N;

import com.biotools.B.R;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import com.biotools.poker.M.B;
import com.biotools.poker.M.C;
import com.biotools.poker.PokerApp;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Polygon;
import java.util.Hashtable;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;

public final class D extends P
  implements com.biotools.poker.E.D, B
{
  private _A z;
  private String[] w = { E.D("Brains.Tight"), E.D("Brains.Moderate"), E.D("Brains.Loose"), E.D("Brains.LoosePassive"), E.D("Brains.Advisor") };

  public String q()
  {
    return this.o.getPreference("PLAYER_NAME");
  }

  public void init(Preferences paramPreferences)
  {
    super.init(paramPreferences);
  }

  public double Q()
  {
    double d1 = super.Q();
    if (this.k == null)
      return d1;
    if (this.k.getNumPlayers() == 2)
    {
      double d2 = 1.0D - this.k.getNumPlayers() / 10.0D;
      double d3 = 1.0D - d2 * 0.4D;
      d1 *= d3;
    }
    return d1;
  }

  public double T()
  {
    double d1 = super.T();
    if (this.k == null)
      return d1;
    if (this.k.getNumPlayers() == 2)
    {
      double d2 = 1.0D - this.k.getNumPlayers() / 10.0D;
      double d3 = 1.0D - d2 * 0.4D;
      d1 *= d3;
    }
    return d1;
  }

  public JSlider o()
  {
    int i = (int)(100.0D * (b() / 0.25D));
    JSlider localJSlider = new JSlider(0, 100, i);
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(new Integer(0), new JLabel(E.D("Brains.Honest")));
    localHashtable.put(new Integer(100), new JLabel(E.D("Brains.Tricky")));
    localJSlider.setLabelTable(localHashtable);
    localJSlider.setPaintLabels(true);
    localJSlider.setMajorTickSpacing(25);
    localJSlider.setMinorTickSpacing(5);
    localJSlider.setPaintTicks(true);
    localJSlider.addChangeListener(new D.1(this, localJSlider));
    return localJSlider;
  }

  public JPanel u()
  {
    JCheckBox localJCheckBox1 = new JCheckBox(E.D("Brains.DefendLargePots"), N());
    localJCheckBox1.addItemListener(new D.2(this, localJCheckBox1));
    localJCheckBox1.setToolTipText("<html>" + E.D("Brains.DefendLargePotsToolTip") + "</html>");
    JCheckBox localJCheckBox2 = new JCheckBox(E.D("Brains.UseImpliedOdds"), a());
    localJCheckBox2.addItemListener(new D.3(this, localJCheckBox2));
    localJCheckBox2.setToolTipText("<html>" + E.D("Brains.UseImpliedOddsToolTip") + "</html>");
    JPanel localJPanel = new JPanel();
    localJPanel.setBorder(BorderFactory.createTitledBorder(E.D("Brains.PostFlopCallingTitle")));
    localJPanel.setLayout(new BoxLayout(localJPanel, 1));
    localJPanel.add(Box.createVerticalStrut(3));
    localJPanel.add(localJCheckBox2);
    localJPanel.add(Box.createVerticalStrut(3));
    localJPanel.add(localJCheckBox1);
    localJPanel.add(Box.createVerticalStrut(3));
    return localJPanel;
  }

  public JPanel p()
  {
    JComboBox localJComboBox = new JComboBox(this.w);
    localJComboBox.setSelectedIndex(W());
    localJComboBox.addActionListener(new D.4(this, localJComboBox));
    JPanel localJPanel = new JPanel();
    localJPanel.add(localJComboBox);
    return localJPanel;
  }

  public JPanel s()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 1));
    localJPanel.add(Box.createHorizontalStrut(5));
    localJPanel.add(p());
    localJPanel.add(Box.createHorizontalStrut(5));
    localJPanel.add(o());
    localJPanel.add(Box.createHorizontalStrut(5));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(E.D("Brains.PreFlopTitle")), BorderFactory.createEmptyBorder(4, 4, 4, 4)));
    return localJPanel;
  }

  public JSlider t()
  {
    int i = (int)(99.0D * Q());
    JSlider localJSlider = new JSlider(0, 99, i);
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(new Integer(0), new JLabel(E.D("Brains.Loose")));
    localHashtable.put(new Integer(99), new JLabel(E.D("Brains.Tight")));
    localJSlider.setLabelTable(localHashtable);
    localJSlider.setPaintLabels(true);
    localJSlider.setMajorTickSpacing(25);
    localJSlider.setMinorTickSpacing(5);
    localJSlider.setPaintTicks(true);
    localJSlider.addChangeListener(new D.5(this, localJSlider));
    return localJSlider;
  }

  public double m()
  {
    return (T() - Q()) / (1.00001D - Q());
  }

  public JSlider y()
  {
    int i = 99 - (int)(99.0D * m());
    JSlider localJSlider = new JSlider(0, 99, i);
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(new Integer(0), new JLabel(E.D("Brains.Passive")));
    localHashtable.put(new Integer(99), new JLabel(E.D("Brains.Aggressive")));
    localJSlider.setLabelTable(localHashtable);
    localJSlider.setPaintLabels(true);
    localJSlider.setMajorTickSpacing(25);
    localJSlider.setMinorTickSpacing(5);
    localJSlider.setPaintTicks(true);
    localJSlider.addChangeListener(new D.6(this, localJSlider));
    return localJSlider;
  }

  public JSlider v()
  {
    int i = (int)(100.0D * (_() / 0.5D));
    JSlider localJSlider = new JSlider(0, 100, i);
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(new Integer(0), new JLabel(E.D("Brains.Honest")));
    localHashtable.put(new Integer(100), new JLabel(E.D("Brains.Tricky")));
    localJSlider.setLabelTable(localHashtable);
    localJSlider.setPaintLabels(true);
    localJSlider.setMajorTickSpacing(25);
    localJSlider.setMinorTickSpacing(5);
    localJSlider.setPaintTicks(true);
    localJSlider.addChangeListener(new D.7(this, localJSlider));
    return localJSlider;
  }

  public JSlider r()
  {
    int i = 100 - (int)(100.0D * e());
    JSlider localJSlider = new JSlider(0, 100, i);
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(new Integer(0), new JLabel(E.D("Brains.Math")));
    localHashtable.put(new Integer(100), new JLabel(E.D("Brains.Model")));
    localJSlider.setLabelTable(localHashtable);
    localJSlider.setPaintLabels(true);
    localJSlider.setMajorTickSpacing(25);
    localJSlider.setMinorTickSpacing(5);
    localJSlider.setPaintTicks(true);
    localJSlider.addChangeListener(new D.8(this, localJSlider));
    return localJSlider;
  }

  public JPanel x()
  {
    this.z = new _A();
    this.z.setPreferredSize(new Dimension(50, 40));
    JPanel localJPanel1 = new JPanel(new GridLayout(5, 1, 8, 8));
    localJPanel1.add(this.z);
    localJPanel1.add(t());
    localJPanel1.add(y());
    localJPanel1.add(v());
    localJPanel1.add(r());
    JPanel localJPanel2 = new JPanel(new BorderLayout());
    localJPanel2.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(E.D("Brains.PostFlopTitle")), BorderFactory.createEmptyBorder(4, 4, 4, 4)));
    localJPanel2.add(localJPanel1, "Center");
    return localJPanel2;
  }

  public JPanel A()
  {
    JLabel localJLabel = new JLabel(E.D("Brains.PokiConfigurationOptions"), 0);
    localJLabel.setFont(new Font("Application", 1, 14));
    JButton localJButton = PokerApp.ɩ();
    localJButton.addActionListener(new D.9(this));
    JPanel localJPanel1 = new JPanel(new BorderLayout());
    localJPanel1.add(localJLabel, "Center");
    JPanel localJPanel2 = new JPanel(new BorderLayout());
    localJPanel2.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    localJPanel2.add(s(), "Center");
    localJPanel2.add(u(), "South");
    JPanel localJPanel3 = new JPanel(new BorderLayout());
    localJPanel3.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    localJPanel3.add(localJPanel1, "North");
    localJPanel3.add(localJPanel2, "West");
    localJPanel3.add(x(), "East");
    return localJPanel3;
  }

  public Preferences B()
  {
    return this.o;
  }

  public void n()
  {
    R localR = R.B(E.D("Brains.Help"));
    localR.A("poki.html");
  }

  public double l()
  {
    this.l.reset();
    this.l.extractCard(this.h);
    this.l.extractCard(this.g);
    this.l.extractHand(this.k.getBoard());
    return A(this.e, this.h, this.g, this.l);
  }

  public double w()
  {
    return Math.pow(_() * 1.9D, 3.0D);
  }

  public double B(double paramDouble)
  {
    double d1 = T();
    double d2 = Q();
    double d3 = T() / (T() - Q());
    double d4 = w();
    double d5 = 1.0D - A(d1 - paramDouble, 10.0D + (1.0D - d4) * 100.0D);
    d5 += 0.25D * d4 * d4 * A(d2 / (10.0D / d3) - paramDouble, 40.0D);
    return d5;
  }

  public double A(double paramDouble)
  {
    double d1 = T();
    double d2 = Q();
    double d3 = w();
    if (paramDouble > d1)
      return 1.0D;
    double d4 = 1.0D - A(d2 - paramDouble, 5.0D + (1.0D - d3) * 100.0D);
    d4 += 0.5D * d3 * d3 * A(d2 / 4.0D - paramDouble, 40.0D);
    return d4;
  }

  public double A(double paramDouble1, double paramDouble2)
  {
    try
    {
      return 1.0D / (1.0D + Math.exp(-paramDouble2 * paramDouble1));
    }
    catch (ArithmeticException localArithmeticException)
    {
    }
    return 1.0D;
  }

  public class _A extends JComponent
  {
    public _A()
    {
    }

    public void paint(Graphics paramGraphics)
    {
      int i = getWidth();
      int j = getHeight();
      double d1 = D.this.T();
      double d2 = D.this.Q();
      paramGraphics.setColor(C.ŏ);
      paramGraphics.fill3DRect(0, 0, i, j, true);
      paramGraphics.setColor(C.ŕ);
      Polygon localPolygon = new Polygon();
      localPolygon.addPoint(0, j);
      for (int k = 0; k < i; k++)
        localPolygon.addPoint(k, (int)((1.0D - D.this.A(k / i)) * j));
      localPolygon.addPoint(i, 0);
      localPolygon.addPoint(i, j);
      localPolygon.addPoint(0, j);
      paramGraphics.fillPolygon(localPolygon);
      paramGraphics.setColor(C.Ŕ);
      localPolygon = new Polygon();
      localPolygon.addPoint(0, j);
      for (k = 0; k < i; k++)
        localPolygon.addPoint(k, (int)((1.0D - D.this.B(k / i)) * j));
      localPolygon.addPoint(i, 0);
      localPolygon.addPoint(i, j);
      localPolygon.addPoint(0, j);
      paramGraphics.fillPolygon(localPolygon);
      paramGraphics.setColor(Color.BLACK);
      paramGraphics.drawLine((int)(i * d1), 0, (int)(i * d1), j);
      paramGraphics.drawLine((int)(i * d2), 0, (int)(i * d2), j);
      paramGraphics.drawRect(0, 0, i - 1, j - 1);
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.D
 * JD-Core Version:    0.6.2
 */