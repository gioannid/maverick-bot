package com.biotools.poker.N;

import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.D.A;
import com.biotools.poker.D.G;
import com.biotools.poker.E.D;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class M
  implements D
{
  private String[] ē = { "Sklansky-1", "Sklansky-2" };
  private Preferences ġ;
  protected int Ğ;
  protected Card ę;
  protected Card ė;
  protected GameInfo ě;
  protected boolean ĝ = false;
  private static final com.biotools.poker.D.E Ě = com.biotools.poker.D.E.G();
  private static String[] Ė = { "AA", "KK", "AKs" };
  private static String[] Ĝ = { "AA" };
  private static String[] Ĕ = { "KK" };
  private static String[] ĕ = { "QQ", "AKs", "AKo" };
  private static String[] Ģ = { "JJ", "TT", "AQs", "AQo", "KQs", "KQo" };
  private static String[] ğ = { "99", "88", "77", "66", "55", "44", "33", "22", "AJs", "ATs", "A9s", "A8s", "A7s", "A6s", "A5s", "A4s", "A3s", "A2s", "QJs", "JTs", "T9s", "98s", "87s", "76s", "65s", "54s" };
  private static String[] Ę = { "AJo", "ATo", "A9o", "A8o", "A7o", "A6o", "A5o", "A4o", "A3o", "A2o", "KJs", "KTs", "K9s", "K8s", "K7s", "K6s", "K5s", "K4s", "K3s", "K2s", "43s", "32s", "QTs", "J9s", "T8s", "97s", "86s", "75s", "64s", "53s", "42s" };
  private static String[] Ē = { "KJo", "KTo", "K9o", "K8o", "K7o", "K6o", "K5o", "K4o", "K3o", "K2o" };
  private static String[] Ġ = { "J8s", "J7s", "J6s", "J5s", "J4s", "J3s", "J2s", "T7s", "T6s", "T5s", "T4s", "T3s", "T2s", "96s", "95s", "94s", "93s", "92s", "85s", "84s", "83s", "82s", "74s", "73s", "72s", "63s", "62s", "52s" };

  public JPanel A()
  {
    JLabel localJLabel = new JLabel(com.biotools.poker.E.D("Brains.SklanskyConfigurationOptions"), 0);
    localJLabel.setFont(new Font("Application", 1, 14));
    JPanel localJPanel = new JPanel(new BorderLayout(4, 4));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    localJPanel.add(localJLabel, "North");
    localJPanel.add(ï(), "Center");
    return localJPanel;
  }

  public JPanel ï()
  {
    JComboBox localJComboBox = new JComboBox(this.ē);
    localJComboBox.setSelectedIndex(ì());
    localJComboBox.addActionListener(new M.1(this, localJComboBox));
    JPanel localJPanel = new JPanel();
    localJPanel.add(new JLabel(com.biotools.poker.E.D("Brains.SystemType"), 4));
    localJPanel.add(localJComboBox);
    return localJPanel;
  }

  public void init(Preferences paramPreferences)
  {
    this.ġ = paramPreferences;
  }

  public Preferences B()
  {
    return this.ġ;
  }

  public int ì()
  {
    return this.ġ.getIntPreference("SYSTEM", 1);
  }

  public boolean î()
  {
    return ì() == 0;
  }

  public void holeCards(Card paramCard1, Card paramCard2, int paramInt)
  {
    if (paramCard1.getRank() >= paramCard2.getRank())
    {
      this.ę = paramCard1;
      this.ė = paramCard2;
    }
    else
    {
      this.ę = paramCard2;
      this.ė = paramCard1;
    }
    this.Ğ = paramInt;
    this.ĝ = false;
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
    if (paramAction.isBetOrRaise())
      this.ĝ = true;
  }

  public void dealHoleCardsEvent()
  {
  }

  public void stageEvent(int paramInt)
  {
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    this.ě = paramGameInfo;
  }

  public void gameOverEvent()
  {
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
  }

  public Action getAction()
  {
    if (this.ě.getStage() == 0)
    {
      if (î())
        return ë();
      return ê();
    }
    return í();
  }

  private boolean B(String[] paramArrayOfString)
  {
    for (int i = 0; i < paramArrayOfString.length; i++)
      if (S(paramArrayOfString[i]))
        return true;
    return false;
  }

  public boolean S(String paramString)
  {
    if (this.ę.getRank() != Card.getRankFromChar(paramString.charAt(0)))
      return false;
    if (this.ė.getRank() != Card.getRankFromChar(paramString.charAt(1)))
      return false;
    if (paramString.length() > 2)
      if (paramString.charAt(2) == 's')
      {
        if (this.ę.getSuit() != this.ė.getSuit())
          return false;
      }
      else if (this.ę.getSuit() == this.ė.getSuit())
        return false;
    return true;
  }

  public Action ê()
  {
    double d1 = this.ě.getBankRoll(this.Ğ);
    double d2 = this.ě.getAmountToCall(this.Ğ);
    if (d2 > d1)
      d2 = d1;
    double d3 = this.ě.getBankRollAtRisk(this.Ğ);
    int i = this.ě.getNumToAct() - 1;
    int j = this.ě.getNumPlayers() <= 4 ? 1 : 0;
    int k = this.ě.getNumPlayers() == 2 ? 1 : 0;
    int m = 0;
    for (int n = 0; n < this.ě.getNumSeats(); n++)
      if ((this.ě.isActive(n)) && (this.ě.isCommitted(n)) && (n != this.Ğ))
        m++;
    double d4 = (m + 1) * (d3 / (this.ě.getSmallBlindSize() + this.ě.getBigBlindSize()));
    if (i != 0)
      d4 *= i;
    com.biotools.poker.E.H("KeyNum: " + d4);
    int i1 = 0;
    if (this.ĝ)
    {
      if (B(Ė))
        i1 = 1;
    }
    else if (d4 >= 400.0D)
    {
      if (B(Ĝ))
      {
        com.biotools.poker.E.H(this.ę + "-" + this.ė + ": GROUP_400");
        i1 = 1;
      }
    }
    else if (d4 >= 200.0D)
    {
      if ((B(Ĝ)) || (B(Ĕ)))
      {
        com.biotools.poker.E.H(this.ę + "-" + this.ė + ": GROUP_200+");
        i1 = 1;
      }
    }
    else if (d4 >= 150.0D)
    {
      if ((B(Ĝ)) || (B(Ĕ)) || (B(ĕ)))
      {
        com.biotools.poker.E.H(this.ę + "-" + this.ė + ": GROUP_150+");
        i1 = 1;
      }
    }
    else if (d4 >= 100.0D)
    {
      if ((B(Ĝ)) || (B(Ĕ)) || (B(ĕ)) || (B(Ģ)))
      {
        com.biotools.poker.E.H(this.ę + "-" + this.ė + ": GROUP_100+");
        i1 = 1;
      }
    }
    else if (d4 >= 80.0D)
    {
      if ((B(Ĝ)) || (B(Ĕ)) || (B(ĕ)) || (B(Ģ)) || (B(ğ)))
      {
        com.biotools.poker.E.H(this.ę + "-" + this.ė + ": GROUP_80+");
        i1 = 1;
      }
    }
    else if (d4 >= 60.0D)
    {
      if ((B(Ĝ)) || (B(Ĕ)) || (B(ĕ)) || (B(Ģ)) || (B(ğ)) || (B(Ę)))
      {
        com.biotools.poker.E.H(this.ę + "-" + this.ė + ": GROUP_60+");
        i1 = 1;
      }
    }
    else if (d4 >= 40.0D)
    {
      if ((B(Ĝ)) || (B(Ĕ)) || (B(ĕ)) || (B(Ģ)) || (B(ğ)) || (B(Ę)) || (B(Ē)))
      {
        com.biotools.poker.E.H(this.ę + "-" + this.ė + ": GROUP_40+");
        i1 = 1;
      }
    }
    else if (d4 >= 20.0D)
    {
      if ((B(Ĝ)) || (B(Ĕ)) || (B(ĕ)) || (B(Ģ)) || (B(ğ)) || (B(Ę)) || (B(Ē)) || (B(Ġ)))
      {
        com.biotools.poker.E.H(this.ę + "-" + this.ė + ": GROUP_20+");
        i1 = 1;
      }
    }
    else
      i1 = 1;
    if (i1 != 0)
    {
      com.biotools.poker.E.H(this.ę + "-" + this.ė + ": JAM");
      double d5 = d1 - d2;
      if (d5 == 0.0D)
        return Action.callAction(d2);
      return Action.raiseAction(d2, d5);
    }
    return Action.checkOrFoldAction(d2);
  }

  private Action í()
  {
    double d1 = this.ě.getBankRoll(this.Ğ);
    double d2 = this.ě.getAmountToCall(this.Ğ);
    if (d2 > d1)
      d2 = d1;
    double d3 = this.ě.getBankRollAtRisk(this.Ğ);
    double d4 = this.ě.getEligiblePot(this.Ğ);
    int i = this.ě.getNumToAct() - 1;
    int j = this.ě.getNumPlayers() <= 4 ? 1 : 0;
    int k = this.ě.getNumPlayers() == 2 ? 1 : 0;
    int m = 0;
    for (int n = 0; n < this.ě.getNumSeats(); n++)
      if ((this.ě.isActive(n)) && (this.ě.isCommitted(n)) && (n != this.Ğ))
        m++;
    Deck localDeck = new Deck();
    localDeck.extractCard(this.ę);
    localDeck.extractCard(this.ė);
    localDeck.extractHand(this.ě.getBoard());
    double d5 = HandEvaluator.handRank(this.ę, this.ė, G.A(this.ě).ŷ(), localDeck);
    d5 = Math.pow(d5, this.ě.getNumActivePlayers() - 1);
    double d6 = 0.0D;
    if (this.ě.getStage() != 3)
      d6 = A.A(this.ę, this.ė, this.ě.getBoard(), Ě);
    if (d2 == 0.0D)
    {
      if (d5 > 0.85D)
        return H(d1 - d2);
    }
    else if (d5 > 0.925D)
      return H(d1 - d2);
    if ((this.ě.getNumRaises() == 0) && (d6 > 0.2D) && (Math.random() < d6))
      return H(d1 - d2);
    if ((d2 > 0.0D) && (d6 > d2 / (d4 + d2)))
    {
      if (d2 > d1 / 3.0D)
        return H(d1 - d2);
      return Action.callAction(d2);
    }
    return d2 == 0.0D ? Action.checkAction() : Action.foldAction(d2);
  }

  private Action H(double paramDouble)
  {
    double d1 = this.ě.getBankRoll(this.Ğ);
    double d2 = this.ě.getAmountToCall(this.Ğ);
    if (d2 > d1)
      d2 = d1;
    if (d2 > d1)
      return Action.callAction(d2);
    if (paramDouble + d2 > d1 / 2.0D)
      paramDouble = d1;
    return Action.raiseAction(d2, paramDouble);
  }

  public Action ë()
  {
    double d1 = this.ě.getAmountToCall(this.Ğ);
    int i = 0;
    if (this.ĝ)
    {
      if ((this.ę.getRank() == 12) && (this.ė.getRank() == 12))
        i = 1;
      if ((this.ę.getRank() == 11) && (this.ė.getRank() == 11))
        i = 1;
      if (this.ę.getSuit() == this.ė.getSuit())
      {
        if ((this.ę.getRank() == 12) && (this.ė.getRank() == 11))
          i = 1;
        if ((this.ę.getRank() == 11) && (this.ė.getRank() == 12))
          i = 1;
      }
      if ((d1 <= this.ě.getSmallBlindSize() * 4.0D) || (this.ě.getNumPlayers() <= 2))
      {
        if ((this.ę.getRank() == 10) && (this.ė.getRank() == 10))
          i = 1;
        if ((this.ę.getRank() == 9) && (this.ė.getRank() == 9))
          i = 1;
        if ((this.ę.getRank() == 8) && (this.ė.getRank() == 8))
          i = 1;
      }
      if ((d1 <= this.ě.getSmallBlindSize() * 2.0D) || (this.ě.getNumPlayers() <= 3))
      {
        if ((this.ę.getRank() == 12) && (this.ė.getRank() == 11))
          i = 1;
        if ((this.ę.getRank() == 11) && (this.ė.getRank() == 12))
          i = 1;
        if ((this.ę.getRank() == 7) && (this.ė.getRank() == 7))
          i = 1;
        if ((this.ę.getRank() == 6) && (this.ė.getRank() == 6))
          i = 1;
      }
    }
    else
    {
      if (this.ę.getRank() == this.ė.getRank())
        i = 1;
      if ((this.ę.getRank() == 12) && (this.ė.getRank() == 11))
        i = 1;
      if ((this.ę.getRank() == 11) && (this.ė.getRank() == 12))
        i = 1;
      if (this.ę.getSuit() == this.ė.getSuit())
      {
        if ((this.ę.getRank() == 12) || (this.ė.getRank() == 12))
          i = 1;
        if ((Math.abs(this.ę.getRank() - this.ė.getRank()) <= 1) && ((this.ę.getRank() > 2) || (this.ė.getRank() > 2)))
          i = 1;
      }
    }
    if (i != 0)
    {
      double d2 = this.ě.getBankRoll(this.Ğ);
      double d3 = d2 - d1;
      if (d3 == 0.0D)
        return Action.callAction(d1);
      return Action.raiseAction(d1, d3);
    }
    return Action.checkOrFoldAction(d1);
  }

  public void gameStateChanged()
  {
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.M
 * JD-Core Version:    0.6.2
 */