package com.biotools.poker.N;

import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import com.biotools.poker.E.D;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

public final class V extends U
  implements D
{
  private String[] ņ = { E.D("Brains.Tight"), E.D("Brains.Moderate"), E.D("Brains.Loose"), E.D("Brains.LoosePassive"), E.D("Brains.SmallStakesAdvisor") };
  private Preferences Ň;

  public JPanel A()
  {
    JLabel localJLabel = new JLabel(E.D("Brains.JagbotConfigurationOptionsHeading"), 0);
    localJLabel.setFont(new Font("Application", 1, 14));
    JPanel localJPanel = new JPanel(new BorderLayout(4, 4));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    localJPanel.add(localJLabel, "North");
    localJPanel.add(ā(), "Center");
    return localJPanel;
  }

  public JPanel ā()
  {
    JComboBox localJComboBox = new JComboBox(this.ņ);
    localJComboBox.setSelectedIndex(ý());
    localJComboBox.addActionListener(new V.1(this, localJComboBox));
    JPanel localJPanel = new JPanel();
    localJPanel.add(new JLabel(E.D("Brains.PreflopSelectionTitle"), 4));
    localJPanel.add(localJComboBox);
    return localJPanel;
  }

  public void init(Preferences paramPreferences)
  {
    this.Ň = paramPreferences;
    super.init(paramPreferences);
  }

  public Preferences B()
  {
    return this.Ň;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.V
 * JD-Core Version:    0.6.2
 */