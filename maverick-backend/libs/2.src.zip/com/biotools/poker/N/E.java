package com.biotools.poker.N;

import com.biotools.B.R;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.D.C;
import com.biotools.poker.E.D;
import com.biotools.poker.M.B;
import com.biotools.poker.PokerApp;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.Hashtable;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;

public final class E extends Y
  implements D, B
{
  private String[] â = { com.biotools.poker.E.D("Brains.Tight"), com.biotools.poker.E.D("Brains.Moderate"), com.biotools.poker.E.D("Brains.Loose"), com.biotools.poker.E.D("Brains.LoosePassive"), com.biotools.poker.E.D("Brains.SmallStakesAdvisor") };

  public E()
  {
    if (com.biotools.poker.E.Ú())
      throw new RuntimeException("AI Not Available");
  }

  public String Ö()
  {
    return this.o.getPreference("PLAYER_NAME");
  }

  public void init(Preferences paramPreferences)
  {
    super.init(paramPreferences);
  }

  public JSlider Ñ()
  {
    int i = (int)(100.0D * (b() / 0.25D));
    JSlider localJSlider = new JSlider(0, 100, i);
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(new Integer(0), new JLabel(com.biotools.poker.E.D("Brains.Honest")));
    localHashtable.put(new Integer(100), new JLabel(com.biotools.poker.E.D("Brains.Tricky")));
    localJSlider.setLabelTable(localHashtable);
    localJSlider.setPaintLabels(true);
    localJSlider.setMajorTickSpacing(25);
    localJSlider.setMinorTickSpacing(5);
    localJSlider.setPaintTicks(true);
    localJSlider.addChangeListener(new E.1(this, localJSlider));
    return localJSlider;
  }

  public JPanel Ó()
  {
    JComboBox localJComboBox = new JComboBox(this.â);
    localJComboBox.setSelectedIndex(W());
    localJComboBox.addActionListener(new E.2(this, localJComboBox));
    JPanel localJPanel = new JPanel();
    localJPanel.add(localJComboBox);
    return localJPanel;
  }

  public JPanel Ô()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 1));
    localJPanel.add(Box.createHorizontalStrut(5));
    localJPanel.add(Ó());
    localJPanel.add(Box.createHorizontalStrut(5));
    localJPanel.add(Ñ());
    localJPanel.add(Box.createHorizontalStrut(5));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("Brains.PreFlopTitle")), BorderFactory.createEmptyBorder(4, 4, 4, 4)));
    return localJPanel;
  }

  public JSlider Ò()
  {
    int i = 100 - (int)(100.0D * k());
    JSlider localJSlider = new JSlider(0, 100, i);
    localJSlider.setToolTipText(com.biotools.poker.E.D("Brains.PokiSimModelToolTip"));
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(new Integer(0), new JLabel(com.biotools.poker.E.D("Brains.Math")));
    localHashtable.put(new Integer(100), new JLabel(com.biotools.poker.E.D("Brains.Model")));
    localJSlider.setLabelTable(localHashtable);
    localJSlider.setPaintLabels(true);
    localJSlider.setMajorTickSpacing(25);
    localJSlider.setMinorTickSpacing(5);
    localJSlider.setPaintTicks(true);
    localJSlider.addChangeListener(new E.3(this, localJSlider));
    return localJSlider;
  }

  public JSlider Ð()
  {
    int i = 100 - (int)(100.0D * j());
    JSlider localJSlider = new JSlider(0, 100, i);
    localJSlider.setToolTipText(com.biotools.poker.E.D("Brains.PokiSimSimSliderToolTip"));
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(new Integer(0), new JLabel(com.biotools.poker.E.D("Brains.Call")));
    localHashtable.put(new Integer(100), new JLabel(com.biotools.poker.E.D("Brains.Predict")));
    localJSlider.setLabelTable(localHashtable);
    localJSlider.setPaintLabels(true);
    localJSlider.setMajorTickSpacing(25);
    localJSlider.setMinorTickSpacing(5);
    localJSlider.setPaintTicks(true);
    localJSlider.addChangeListener(new E.4(this, localJSlider));
    return localJSlider;
  }

  public JPanel Ø()
  {
    JPanel localJPanel1 = new JPanel(new GridLayout(2, 1, 4, 4));
    localJPanel1.add(Ò());
    localJPanel1.add(Ð());
    JPanel localJPanel2 = new JPanel(new BorderLayout());
    localJPanel2.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("Brains.PostFlopTitle")), BorderFactory.createEmptyBorder(4, 4, 4, 4)));
    localJPanel2.add(localJPanel1, "Center");
    return localJPanel2;
  }

  public JPanel A()
  {
    JLabel localJLabel = new JLabel(com.biotools.poker.E.D("Brains.PokiSimConfigurationOptions"), 0);
    localJLabel.setFont(new Font("Application", 1, 14));
    JButton localJButton = PokerApp.ɩ();
    localJButton.addActionListener(new E.5(this));
    JPanel localJPanel1 = new JPanel(new BorderLayout());
    localJPanel1.add(localJLabel, "Center");
    JPanel localJPanel2 = new JPanel(new BorderLayout());
    localJPanel2.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    localJPanel2.add(localJPanel1, "North");
    localJPanel2.add(Ô(), "West");
    localJPanel2.add(Ø(), "East");
    return localJPanel2;
  }

  public Preferences B()
  {
    return this.o;
  }

  public void Õ()
  {
    R localR = R.B(com.biotools.poker.E.D("Brains.Help"));
    localR.A("simbot.html");
  }

  public com.biotools.poker.D.E P(String paramString)
  {
    return null;
  }

  public double l()
  {
    return 0.0D;
  }

  public C h()
  {
    return null;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.E
 * JD-Core Version:    0.6.2
 */