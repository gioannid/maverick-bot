package com.biotools.poker.N;

import com.biotools.A.W;
import com.biotools.A.b;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.Player;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.D.B;
import com.biotools.poker.D.C;
import com.biotools.poker.N.B.I;
import com.biotools.poker.N.B.J;
import com.biotools.poker.N.B.K;

public class G
  implements Player
{
  protected static W m = W.A();
  protected Card h;
  protected Card g;
  protected int e;
  protected GameInfo k;
  protected com.biotools.poker.D.E n = new com.biotools.poker.D.E();
  protected double d;
  protected Deck l = new Deck();
  protected Preferences o;
  protected K i;
  protected I j;
  protected J f;

  public G()
  {
  }

  public G(Preferences paramPreferences)
  {
    init(paramPreferences);
  }

  public void init(Preferences paramPreferences)
  {
    this.o = paramPreferences;
    J("BasicPlayer:  MODEL=" + O() + " " + (X() ? "[Max]" : "Avg") + W());
  }

  public int W()
  {
    return this.o.getIntPreference("PREFLOP_TIGHTNESS", 1);
  }

  public boolean Z()
  {
    return this.o.getBooleanPreference("USE_LOW_LIMIT_PREFLOP", false);
  }

  public boolean S()
  {
    return this.o.getBooleanPreference("USE_SSH_PREFLOP", false);
  }

  public boolean X()
  {
    return this.o.getBooleanPreference("FIELD_USES_MAX", true);
  }

  public boolean P()
  {
    return this.o.getBooleanPreference("PREFLOP_SIM", false);
  }

  public boolean O()
  {
    return this.o.getBooleanPreference("OM", true);
  }

  public boolean V()
  {
    return this.o.getBooleanPreference("DEBUG", false);
  }

  public boolean N()
  {
    return this.o.getBooleanPreference("USE_SHOWDOWN_ODDS", false);
  }

  public double Q()
  {
    return this.o.getDoublePreference("POSTFLOP_CALL", 0.45D);
  }

  public double T()
  {
    return this.o.getDoublePreference("POSTFLOP_RAISE", 0.8D);
  }

  public void J(String paramString)
  {
    if (V())
      com.biotools.poker.E.H(paramString);
  }

  public void K(String paramString)
  {
    if (V())
      com.biotools.poker.E.J(paramString);
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    this.k = paramGameInfo;
    this.d = m.nextDouble();
  }

  public void gameStateChanged()
  {
  }

  public synchronized void holeCards(Card paramCard1, Card paramCard2, int paramInt)
  {
    this.h = paramCard1;
    this.g = paramCard2;
    this.e = paramInt;
  }

  private String Y()
  {
    return this.k.getPlayerName(this.e);
  }

  public synchronized void actionEvent(int paramInt, Action paramAction)
  {
  }

  public synchronized void gameOverEvent()
  {
  }

  public synchronized Action getAction()
  {
    int i1 = this.k.getNumRaises() == 0 ? 1 : 0;
    if (this.k.getStage() == 0)
    {
      i1 = R();
    }
    else
    {
      A(this.e);
      this.l.reset();
      this.l.extractCard(this.h);
      this.l.extractCard(this.g);
      this.l.extractHand(this.k.getBoard());
      d1 = this.k.isSimulation() ? B(this.e, this.h, this.g, this.l) : A(this.e, this.h, this.g, this.l);
      double d2 = 0.0D;
      double d3 = 0.0D;
      if (this.k.getStage() != 3)
        if ((this.k.isZipMode()) || (this.o.getBooleanPreference("CRUDE_PPOT")))
        {
          d2 = com.biotools.poker.D.A.A(this.h, this.g, this.k.getBoard());
        }
        else
        {
          localObject = com.biotools.poker.D.A.B(this.h, this.g, this.k.getBoard(), this.n);
          d2 = localObject[0];
          d3 = localObject[1];
        }
      Object localObject = X.A(d2, d3, d1, this.k.getAmountToCall(this.e), this.k.getNumToAct(), this.k.getStage(), this.k.getNumRaises(), this.k.getPlayer(this.e).isCommitted(), this.k.getEligiblePot(this.e), this.k.getBigBlindSize(), N(), Q(), T());
      J("SPIN = " + b.A(this.d, 3) + "   " + ((C)localObject).toString());
      i1 = ((C)localObject).C(this.d);
    }
    double d1 = this.k.getAmountToCall(this.e);
    Action localAction = Action.getAction(i1, d1, this.k.getCurrentBetSize());
    return S.A(localAction, this.e, this.h, this.g, this.k);
  }

  public synchronized int R()
  {
    int i1 = -1;
    K(" [" + this.h.toString() + "-" + this.g.toString() + "] ");
    if (this.k.getNumPlayers() == 2)
    {
      if (this.j == null)
        this.j = new I();
      i1 = this.j.A(this.h, this.g, this.k);
    }
    else if (Z())
    {
      i1 = com.biotools.poker.N.B.A.B(this.h, this.g, this.e, this.k);
    }
    else if (S())
    {
      if (this.f == null)
        this.f = new J();
      i1 = this.f.A(this.h, this.g, this.e, this.k);
    }
    else
    {
      U().A(W());
      i1 = U().B(this.h, this.g, this.k);
    }
    return i1;
  }

  protected K U()
  {
    if (this.i == null)
      this.i = new K();
    return this.i;
  }

  protected com.biotools.poker.D.E C(int paramInt)
  {
    return com.biotools.poker.D.G.A(this.k).Q(paramInt).Ŧ();
  }

  protected B B(int paramInt)
  {
    return com.biotools.poker.D.G.A(this.k).Q(paramInt);
  }

  protected void A(int paramInt)
  {
    double[] arrayOfDouble = new double[this.k.getNumSeats()];
    for (int i1 = 0; i1 < this.k.getNumSeats(); i1++)
      if (this.k.isActive(i1))
        arrayOfDouble[i1] = C(i1).A();
    Card localCard1 = new Card();
    Card localCard2 = new Card();
    for (i1 = 0; i1 < 52; i1++)
    {
      localCard1.setIndex(i1);
      for (int i2 = i1 + 1; i2 < 52; i2++)
      {
        localCard2.setIndex(i2);
        double d1 = 0.0D;
        double d2 = 0.0D;
        for (int i3 = 0; i3 < this.k.getNumSeats(); i3++)
          if ((this.k.isActive(i3)) && (i3 != paramInt))
          {
            double d3 = C(i3).A(localCard1, localCard2) / arrayOfDouble[i3];
            d1 += d3;
            if (d3 > d2)
              d2 = d3;
          }
        this.n.A(localCard1, localCard2, X() ? d2 : d1);
      }
    }
  }

  public double A(int paramInt, Card paramCard1, Card paramCard2, Deck paramDeck)
  {
    double d1 = 1.0D;
    for (int i1 = 0; i1 < this.k.getNumSeats(); i1++)
      if ((i1 != paramInt) && (this.k.isActive(i1)))
        d1 *= B(i1).C(paramCard1, paramCard2, paramDeck);
    return d1;
  }

  public double B(int paramInt, Card paramCard1, Card paramCard2, Deck paramDeck)
  {
    double d1 = HandEvaluator.handRank(paramCard1, paramCard2, com.biotools.poker.D.G.A(this.k).ŷ(), paramDeck);
    return Math.pow(d1, this.k.getNumActivePlayers() - 1);
  }

  public void stageEvent(int paramInt)
  {
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
  }

  public void dealHoleCardsEvent()
  {
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.G
 * JD-Core Version:    0.6.2
 */