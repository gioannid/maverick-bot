package com.biotools.poker.N;

import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.D.C;
import com.biotools.poker.D.G;
import com.biotools.poker.E.D;
import java.awt.Font;
import java.awt.Rectangle;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.ListIterator;
import java.util.Random;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;

public class K
  implements D
{
  private static final String ă = "ALWAYS_CALL_MODE";
  GameInfo ĉ = null;
  Card Ć = null;
  Card ą = null;
  int Ċ = 0;
  int ċ = 20;
  com.biotools.poker.D.E ć = new com.biotools.poker.D.E();
  Preferences Č = null;
  int[] ā = { 100, 100, 100, 100, 100, 100, 100, 100, 100, 100 };
  static final int Ă = 20;
  boolean Ā = false;
  boolean Ĉ = false;
  Action[] Ą = new Action[10];

  public void init(Preferences paramPreferences)
  {
    this.ć.I();
    this.Č = paramPreferences;
  }

  public JPanel A()
  {
    JPanel localJPanel1 = new JPanel();
    localJPanel1.setLayout(new BoxLayout(localJPanel1, 3));
    JLabel localJLabel = new JLabel(com.biotools.poker.E.D("Brains.AveryConfigurationOptionsHeading"), 0);
    localJLabel.setAlignmentX(0.5F);
    Font localFont = new Font("Dialog", 1, 14);
    localJLabel.setFont(localFont);
    Rectangle localRectangle = localJLabel.getBounds();
    JPanel localJPanel2 = new JPanel();
    localJPanel2.add(localJLabel);
    localJPanel2.setBounds(localRectangle.x, localRectangle.y, localRectangle.width, localRectangle.height + 242);
    localJPanel1.add(localJPanel2);
    JPanel localJPanel3 = new JPanel();
    localJPanel3.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("Brains.PreflopDispositionTitle")), BorderFactory.createEmptyBorder(5, 5, 5, 5)));
    int i = (int)(100.0D * this.Č.getDoublePreference("PREFLOP_TIGHTNESS", 0.5D));
    JSlider localJSlider1 = new JSlider(0, 100, i);
    localJSlider1.addChangeListener(new K.1(this, localJSlider1));
    localJSlider1.setMajorTickSpacing(25);
    localJSlider1.setMinorTickSpacing(5);
    localJSlider1.setPaintTicks(true);
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(new Integer(0), new JLabel(com.biotools.poker.E.D("Brains.Loose")));
    localHashtable.put(new Integer(50), new JLabel(com.biotools.poker.E.D("Brains.Typical")));
    localHashtable.put(new Integer(100), new JLabel(com.biotools.poker.E.D("Brains.Tight")));
    localJSlider1.setLabelTable(localHashtable);
    localJSlider1.setPaintLabels(true);
    localJPanel3.add(localJSlider1);
    localJPanel1.add(localJPanel3);
    JPanel localJPanel4 = new JPanel();
    localJPanel4.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("Brains.PostflopDispositionTitle")), BorderFactory.createEmptyBorder(5, 5, 5, 5)));
    i = (int)(100.0D * this.Č.getDoublePreference("POSTFLOP_TIGHTNESS", 0.5D));
    JSlider localJSlider2 = new JSlider(0, 100, i);
    localJSlider2.addChangeListener(new K.2(this, localJSlider2));
    localJSlider2.setMajorTickSpacing(25);
    localJSlider2.setMinorTickSpacing(5);
    localJSlider2.setPaintTicks(true);
    localJSlider2.setLabelTable(localHashtable);
    localJSlider2.setPaintLabels(true);
    localJPanel4.add(localJSlider2);
    localJPanel1.add(localJPanel4);
    return localJPanel1;
  }

  public void holeCards(Card paramCard1, Card paramCard2, int paramInt)
  {
    this.Ć = paramCard1;
    this.ą = paramCard2;
    this.Ċ = paramInt;
    æ();
    this.Ā = false;
    this.Ĉ = false;
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
    Random localRandom = new Random();
    int i;
    if (paramAction.isBetOrRaise())
    {
      i = 1;
      Action localAction = this.Ą[paramInt];
      if ((localAction != null) && (localAction.isCheckOrCall()))
      {
        i = 3;
        this.ā[paramInt] -= (100 - this.ā[paramInt]) / i;
        this.ā[paramInt] = Math.max(0, this.ā[paramInt]);
      }
      i = localRandom.nextInt(3) + 3;
      this.ā[paramInt] -= (this.ā[paramInt] - 0) / i;
    }
    else if (paramAction.isCheckOrCall())
    {
      i = localRandom.nextInt(3) + 3;
      this.ā[paramInt] += (100 - this.ā[paramInt]) / i;
    }
    this.Ą[paramInt] = paramAction;
  }

  public void stageEvent(int paramInt)
  {
    if (paramInt == 3)
      this.Ā = true;
    for (int i = 0; i < this.Ą.length; i++)
      this.Ą[i] = null;
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    this.ĉ = paramGameInfo;
  }

  public void gameOverEvent()
  {
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
    if (this.Ā)
      this.ā[paramInt] = 100;
  }

  public void gameStateChanged()
  {
  }

  public Action getAction()
  {
    double d = this.ĉ.getAmountToCall(this.Ċ);
    int i = ä();
    if (i < 0)
      return Action.raiseAction(d, -1 * i);
    if (i == 1)
      return Action.callAction(d);
    return Action.checkOrFoldAction(d);
  }

  public int ä()
  {
    int i = 1;
    if (this.ĉ.getStage() == 0)
      i = è();
    else
      i = é();
    if (i == 0)
      if (this.ĉ.getAmountToCall(this.Ċ) == 0.0D)
      {
        i = 1;
      }
      else
      {
        double d = this.ĉ.getAmountToCall(this.Ċ) / this.ĉ.getEligiblePot(this.Ċ);
        boolean bool = this.ĉ.getPlayer(this.Ċ).isCommitted();
        if (d < 0.05D * (bool ? 2 : 1))
          i = 1;
      }
    if ((this.ĉ.getStage() == 0) && (this.ĉ.getAmountToCall(this.Ċ) == 0.0D))
      this.Ĉ = true;
    return i;
  }

  private int è()
  {
    int i = 0;
    for (int j = 0; j < this.ĉ.getNumSeats(); j++)
      if ((this.ĉ.inGame(j)) && (this.ĉ.getPlayer(j).getBankRoll() > 0.0D))
        i++;
    if ((this.ĉ.getPlayer(this.Ċ).getLastAction() != 1) && (this.ĉ.getPlayer(this.Ċ).getLastAction() != 2))
      return H(i);
    j = â();
    if (this.ċ >= F(200))
      return A(0.0D, 0.3D, 0.7D, false);
    if (ç() > ã())
    {
      double d1 = this.ĉ.getPlayer(this.Ċ).getBankRoll();
      double d2 = Math.max(this.ĉ.getAmountToCall(this.Ċ), d1);
      double d3 = d2 / (this.ĉ.getMainPotSize() - d2);
      double d4 = d2 / d1;
      if (d3 > 2.0D)
      {
        if (this.ċ >= F(200))
          return A(0.0D, 0.0D, 1.0D, false);
        if ((i < 4) && (this.ċ >= F(100)))
          return A(0.5D, 0.0D, 0.5D, false);
        return 0;
      }
      if (this.ċ >= F(100))
        return ã();
      if ((i < 4) && (this.ċ >= F(50)))
        return 1;
      if (j < 20)
      {
        int n = this.ĉ.getNumToAct();
        Random localRandom2 = new Random();
        int i1 = localRandom2.nextInt(n);
        if (i1 == 0)
          return A(0.05D, 0.7D, 0.25D, false);
      }
      return 0;
    }
    if ((i > 4) || (this.ċ < F(50)))
    {
      if (j < 20)
      {
        int k = this.ĉ.getNumToAct();
        Random localRandom1 = new Random();
        int m = localRandom1.nextInt(k);
        if (m == 0)
          return A(0.8D, 0.0D, 0.2D, false);
      }
      return 0;
    }
    return ç();
  }

  private int H(int paramInt)
  {
    if ((paramInt == 2) && (this.ĉ.getAmountToCall(this.Ċ) == this.ĉ.getBigBlindSize() - this.ĉ.getSmallBlindSize()))
    {
      if (this.ċ >= F(21))
      {
        C localC1 = new C(0.0D, 0.5D, 0.5D);
        int j = localC1.L();
        if (j == 2)
          return ã();
        return 1;
      }
      return 1;
    }
    if (this.ĉ.getNumRaises() > 1)
    {
      i = â();
      double d1 = this.ĉ.getPlayer(this.Ċ).getBankRoll();
      double d2 = Math.max(this.ĉ.getAmountToCall(this.Ċ), d1);
      double d3 = d2 / (this.ĉ.getMainPotSize() - d2);
      double d4 = d2 / d1;
      if (d3 > 2.0D)
      {
        if (this.ċ >= F(200))
          return A(0.0D, 0.0D, 1.0D, false);
        if ((paramInt < 4) && (this.ċ >= F(100)))
          return A(0.5D, 0.0D, 0.5D, false);
        return 0;
      }
      if (this.ċ >= F(200))
        return A(0.0D, 0.1D, 0.9D, false);
      if ((paramInt < 4) && (this.ċ >= F(100)))
        return A(0.05D, 0.7D, 0.25D, false);
      if (i < 20)
      {
        int i1 = this.ĉ.getNumToAct();
        Random localRandom = new Random();
        int i2 = localRandom.nextInt(i1);
        if (i2 == 0)
          return A(0.05D, 0.7D, 0.25D, false);
      }
      return 0;
    }
    int i = 0;
    int k = this.ĉ.nextPlayer(this.ĉ.nextPlayer(this.ĉ.getButtonSeat()));
    if (this.ĉ.nextActivePlayer(k) != this.Ċ)
      for (int m = this.ĉ.nextActivePlayer(k); m != this.Ċ; m = this.ĉ.nextActivePlayer(m))
        i++;
    if (i > 0)
    {
      if (this.ċ >= F(100))
        return ã();
      return 0;
    }
    C localC2 = new C(0.95D, 0.0D, 0.05D);
    if (localC2.L() == 2)
      return ã();
    if (this.ĉ.getNumActivePlayers() > 7)
    {
      if (this.ċ >= F(200))
        return ã();
    }
    else if (this.ĉ.getNumActivePlayers() > 4)
    {
      if (this.ċ >= F(100))
        return ã();
    }
    else if (this.ċ >= F(21))
      return ã();
    if (paramInt < 4)
    {
      localC2.B(0.4D, 0.1D, 0.5D);
      int n = localC2.L();
      if (n == 2)
        return ã();
      if (n == 1)
        return 1;
    }
    if (paramInt == 2)
      return 1;
    return 0;
  }

  private int é()
  {
    double d1 = this.ć.A(this.Ć, this.ą, this.ĉ.getBoard(), G.A(this.ĉ).ŷ());
    d1 = Math.pow(d1, this.ĉ.getNumActivePlayers() - 1);
    System.out.println(this.Ć.toString() + this.ą + " " + this.ĉ.getBoard() + ", handstrength = " + d1);
    if ((this.Ĉ) && (this.ĉ.getBigBlindSize() < this.ĉ.getPlayer(this.Ċ).getBankRoll() / 8.0D))
    {
      if (d1 > G(0.6D))
        return A(0.0D, 0.2D, 0.8D, true);
      return 0;
    }
    if (this.ĉ.getAmountToCall(this.Ċ) == 0.0D)
    {
      if (d1 > G(0.5D))
      {
        localC = new C(0.0D, 0.1D, 0.9D);
        if (localC.L() == 2)
          return å();
        return 1;
      }
      if (d1 > G(0.25D))
      {
        localC = new C(0.0D, 0.6D, 0.4D);
        if (localC.L() == 2)
          return å();
        return 1;
      }
      C localC = new C(0.0D, 0.9D, 0.1D);
      if (localC.L() == 2)
        return å();
      return 1;
    }
    double d2 = this.ĉ.getPlayer(this.Ċ).getBankRoll();
    double d3 = Math.max(this.ĉ.getAmountToCall(this.Ċ), d2);
    double d4 = d3 / (this.ĉ.getEligiblePot(this.Ċ) - d3);
    double d5 = d3 / d2;
    if (d4 > 2.0D)
    {
      if (d1 > G(0.6D))
        return A(0.0D, 0.0D, 1.0D, false);
      return 0;
    }
    int i = 0;
    if (d1 > G(0.6D))
      i = A(0.0D, 0.1D, 0.9D, true);
    if (d1 > G(0.35D))
      i = A(0.5D, 0.1D, 0.4D, true);
    int j = â();
    if (j < 20)
      i = A(0.1D, 0.4D, 0.5D, true);
    if (i == 0)
    {
      double d6 = d3 / (this.ĉ.getEligiblePot(this.Ċ) + d3);
      if ((d1 > 0.4D) && (d1 * 0.75D > d6))
        return 1;
    }
    return i;
  }

  private int F(int paramInt)
  {
    int i = paramInt;
    double d = this.Č.getDoublePreference("PREFLOP_TIGHTNESS", 0.5D);
    if (d > 0.5D)
      i = (int)((d - 0.5D) / 0.5D * (220 - paramInt)) + paramInt;
    else if (d < 0.5D)
      i = (int)(paramInt - (0.5D - d) / 0.5D * paramInt);
    return i;
  }

  private double G(double paramDouble)
  {
    double d1 = paramDouble;
    double d2 = this.Č.getDoublePreference("POSTFLOP_TIGHTNESS", 0.5D);
    if (d2 > 0.5D)
      d1 = (int)((d2 - 0.5D) / 0.5D * (1.0D - paramDouble)) + paramDouble;
    else if (d2 < 0.5D)
      d1 = (int)(paramDouble - (0.5D - d2) / 0.5D * paramDouble);
    return d1;
  }

  private int ç()
  {
    return -1 * (int)(this.ĉ.getPlayer(this.Ċ).getBankRoll() - this.ĉ.getAmountToCall(this.Ċ));
  }

  private int å()
  {
    double d1 = this.ĉ.getAmountToCall(this.Ċ) + this.ĉ.getMainPotSize();
    double d2 = (int)this.ĉ.getPlayer(this.Ċ).getBankRoll() - this.ĉ.getAmountToCall(this.Ċ);
    if (d2 < d1 * 2.0D)
      return -1 * (int)d2;
    return -1 * (int)d1;
  }

  private int ã()
  {
    int i = (int)(1.25D * (this.ĉ.getAmountToCall(this.Ċ) + this.ĉ.getMainPotSize()));
    int j = (int)(this.ĉ.getPlayer(this.Ċ).getBankRoll() - this.ĉ.getAmountToCall(this.Ċ));
    if (j < i * 2)
      return -1 * j;
    return -1 * i;
  }

  private int A(double paramDouble1, double paramDouble2, double paramDouble3, boolean paramBoolean)
  {
    C localC = new C(paramDouble1, paramDouble2, paramDouble3);
    int i = localC.L();
    if (i == 2)
    {
      if (paramBoolean)
        return å();
      return ã();
    }
    return i;
  }

  private int â()
  {
    int i = 0;
    if (((this.ĉ.getStage() == 0) && (this.ĉ.getNumRaises() < 2)) || ((this.ĉ.getStage() != 0) && (this.ĉ.getNumRaises() < 1)))
      return -1;
    ArrayList localArrayList = new ArrayList();
    for (int j = this.ĉ.nextActivePlayer(this.Ċ); j != this.Ċ; j = this.ĉ.nextActivePlayer(j))
      if (localArrayList.size() == 0)
      {
        if (this.ĉ.getPlayer(j).getLastAction() == 2)
          localArrayList.add(new Integer(j));
      }
      else if ((this.ĉ.getPlayer(j).getLastAction() == 2) || (this.ĉ.getPlayer(j).getLastAction() == 1))
        localArrayList.add(new Integer(j));
    ListIterator localListIterator = localArrayList.listIterator();
    while (localListIterator.hasNext())
    {
      int k = this.ā[((Integer)localListIterator.next()).intValue()];
      System.out.println("tmpRespect=" + k);
      if (k > i)
        i = k;
    }
    return i;
  }

  private int G(int paramInt)
  {
    double d1 = 200.0D;
    if ((paramInt == 2) && (this.ĉ.getAmountToCall(this.Ċ) == this.ĉ.getBigBlindSize() - this.ĉ.getSmallBlindSize()))
    {
      if (this.ċ >= F(21))
        return A(0.0D, 0.5D, 0.5D, false);
      return 1;
    }
    if (this.ĉ.getNumRaises() > 1)
    {
      d1 = â() * 2 * this.ĉ.getNumToAct();
      if (d1 > 200.0D)
        d1 = 200.0D;
    }
    else
    {
      int i = 0;
      double d3 = 0.0D;
      for (int j = 0; j < this.ĉ.getNumActivePlayersNotAllIn(); j++)
        if (j != this.Ċ)
        {
          if (this.ĉ.getPlayer(this.Ċ).getBankRoll() < this.ĉ.getPlayer(j).getBankRoll())
            i = 1;
          if (this.ĉ.getPlayer(j).getBankRoll() > d3)
            d3 = this.ĉ.getPlayer(j).getBankRoll();
        }
      double d4 = 0.0D;
      if (i != 0)
        d4 = this.ĉ.getPlayer(this.Ċ).getBankRoll();
      else
        d4 = d3;
      double d5 = d4 / (this.ĉ.getSmallBlindSize() * 3.0D);
      int k = 0;
      int m = this.ĉ.nextPlayer(this.ĉ.nextPlayer(this.ĉ.getButtonSeat()));
      for (int n = this.Ċ; n != m; n = this.ĉ.nextPlayer(n))
        k++;
      d1 = d5 * k;
      n = 0;
      if (this.ĉ.nextActivePlayer(m) != this.Ċ)
      {
        for (int i1 = this.ĉ.nextActivePlayer(m); i1 != this.Ċ; i1 = this.ĉ.nextActivePlayer(i1))
          n++;
        d1 *= (n + 1);
      }
      d1 /= 3.0D;
    }
    double d2 = this.ċ / d1;
    if (d2 > 1.5D)
      return A(0.0D, 0.1D, 0.9D, false);
    if (d2 > 1.25D)
      return A(0.0D, 0.2D, 0.8D, false);
    if (d2 > 1.0D)
      return A(0.0D, 0.3D, 0.7D, false);
    if (d2 > 0.75D)
      return A(0.8D, 0.1D, 0.1D, false);
    if (d2 > 0.5D)
      return A(0.9D, 0.0D, 0.1D, false);
    return A(1.0D, 0.0D, 0.0D, false);
  }

  private void æ()
  {
    if (this.Ć.getRank() < this.ą.getRank())
    {
      Card localCard = new Card();
      localCard = this.Ć;
      this.Ć = this.ą;
      this.ą = localCard;
    }
    this.ċ = 20;
    if (this.Ć.getRank() == this.ą.getRank())
      switch (this.Ć.getRank())
      {
      case 12:
        this.ċ = 2147483647;
        break;
      case 11:
        this.ċ = 400;
        break;
      case 10:
        this.ċ = 200;
        break;
      case 9:
        this.ċ = 150;
        break;
      case 8:
        this.ċ = 150;
        break;
      case 7:
        this.ċ = 100;
        break;
      case 6:
        this.ċ = 100;
        break;
      case 5:
        this.ċ = 100;
        break;
      case 4:
        this.ċ = 100;
        break;
      case 3:
        this.ċ = 100;
        break;
      default:
        this.ċ = 100;
        break;
      }
    else if (this.Ć.getSuit() == this.ą.getSuit())
      switch (this.Ć.getRank())
      {
      case 12:
        switch (this.ą.getRank())
        {
        case 11:
          this.ċ = 200;
          break;
        case 10:
          this.ċ = 150;
          break;
        case 9:
          this.ċ = 100;
          break;
        case 8:
          this.ċ = 100;
          break;
        default:
          this.ċ = 100;
        }
        break;
      case 11:
        switch (this.ą.getRank())
        {
        case 10:
          this.ċ = 150;
          break;
        case 9:
          this.ċ = 80;
          break;
        case 8:
          this.ċ = 80;
          break;
        case 7:
          this.ċ = 80;
          break;
        default:
          this.ċ = 80;
        }
        break;
      case 10:
        switch (this.ą.getRank())
        {
        case 9:
          this.ċ = 100;
          break;
        case 8:
          this.ċ = 80;
          break;
        case 7:
          this.ċ = 40;
          break;
        case 6:
          this.ċ = 40;
          break;
        default:
          this.ċ = 40;
        }
        break;
      case 9:
        switch (this.ą.getRank())
        {
        case 8:
          this.ċ = 100;
          break;
        case 7:
          this.ċ = 80;
          break;
        case 6:
          this.ċ = 40;
          break;
        case 5:
          this.ċ = 40;
          break;
        default:
          this.ċ = 40;
        }
        break;
      case 8:
        switch (this.ą.getRank())
        {
        case 7:
          this.ċ = 100;
          break;
        case 6:
          this.ċ = 80;
          break;
        case 5:
          this.ċ = 40;
          break;
        default:
          this.ċ = 40;
        }
        break;
      case 7:
        switch (this.ą.getRank())
        {
        case 6:
          this.ċ = 100;
          break;
        case 5:
          this.ċ = 80;
          break;
        case 4:
          this.ċ = 40;
          break;
        default:
          this.ċ = 40;
        }
        break;
      case 6:
        switch (this.ą.getRank())
        {
        case 5:
          this.ċ = 100;
          break;
        case 4:
          this.ċ = 80;
          break;
        case 3:
          this.ċ = 40;
          break;
        default:
          this.ċ = 40;
        }
        break;
      case 5:
        switch (this.ą.getRank())
        {
        case 4:
          this.ċ = 100;
          break;
        case 3:
          this.ċ = 80;
          break;
        case 2:
          this.ċ = 40;
          break;
        default:
          this.ċ = 40;
        }
        break;
      case 4:
        switch (this.ą.getRank())
        {
        case 3:
          this.ċ = 100;
          break;
        case 2:
          this.ċ = 80;
          break;
        default:
          this.ċ = 40;
        }
        break;
      case 3:
        switch (this.ą.getRank())
        {
        case 2:
          this.ċ = 100;
          break;
        case 1:
          this.ċ = 80;
          break;
        default:
          this.ċ = 40;
        }
        break;
      case 2:
        switch (this.ą.getRank())
        {
        case 1:
          this.ċ = 80;
          break;
        case 0:
          this.ċ = 80;
          break;
        default:
          this.ċ = 40;
        }
        break;
      case 1:
        switch (this.ą.getRank())
        {
        case 0:
          this.ċ = 80;
          break;
        default:
          this.ċ = 40;
        }
        break;
      default:
        break;
      }
    else
      switch (this.Ć.getRank())
      {
      case 12:
        switch (this.ą.getRank())
        {
        case 11:
          this.ċ = 200;
          break;
        case 10:
          this.ċ = 150;
          break;
        case 9:
          this.ċ = 80;
          break;
        case 8:
          this.ċ = 80;
          break;
        case 7:
          this.ċ = 80;
          break;
        default:
          this.ċ = 80;
        }
        break;
      case 11:
        switch (this.ą.getRank())
        {
        case 10:
          this.ċ = 150;
          break;
        case 9:
          this.ċ = 60;
          break;
        case 8:
          this.ċ = 60;
          break;
        case 7:
          this.ċ = 60;
          break;
        default:
          this.ċ = 60;
        }
        break;
      case 10:
        switch (this.ą.getRank())
        {
        case 9:
          this.ċ = 20;
          break;
        case 8:
          this.ċ = 20;
          break;
        case 7:
          this.ċ = 20;
          break;
        default:
          this.ċ = 20;
        }
        break;
      case 9:
        switch (this.ą.getRank())
        {
        case 8:
          this.ċ = 20;
          break;
        case 7:
          this.ċ = 20;
          break;
        case 6:
          this.ċ = 20;
          break;
        default:
          this.ċ = 20;
        }
        break;
      case 8:
        switch (this.ą.getRank())
        {
        case 7:
          this.ċ = 20;
          break;
        case 6:
          this.ċ = 20;
          break;
        default:
          this.ċ = 20;
        }
        break;
      case 7:
        switch (this.ą.getRank())
        {
        case 6:
          this.ċ = 20;
          break;
        default:
          this.ċ = 20;
        }
        break;
      case 6:
        switch (this.ą.getRank())
        {
        case 5:
          this.ċ = 20;
          break;
        default:
          this.ċ = 20;
        }
        break;
      case 5:
        switch (this.ą.getRank())
        {
        case 4:
          this.ċ = 20;
          break;
        default:
          this.ċ = 20;
        }
        break;
      case 4:
        switch (this.ą.getRank())
        {
        case 3:
          this.ċ = 20;
          break;
        default:
          this.ċ = 20;
        }
        break;
      case 3:
        switch (this.ą.getRank())
        {
        case 2:
          this.ċ = 20;
          break;
        default:
          this.ċ = 20;
        }
        break;
      }
  }

  public void dealHoleCardsEvent()
  {
  }

  public Preferences B()
  {
    return this.Č;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.K
 * JD-Core Version:    0.6.2
 */