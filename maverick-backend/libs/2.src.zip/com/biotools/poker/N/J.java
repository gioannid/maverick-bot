package com.biotools.poker.N;

import com.biotools.A.W;
import com.biotools.A.b;
import com.biotools.B.P;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.D.A;
import com.biotools.poker.D.C;
import com.biotools.poker.D.G;
import com.biotools.poker.E.D;
import java.awt.BorderLayout;
import java.awt.Font;
import java.io.PrintStream;
import java.util.Hashtable;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;

public final class J
  implements D
{
  private Preferences ë;
  private Card ó;
  private Card ò;
  private int í;
  private GameInfo ø;
  private int ï = 0;
  private StringBuffer ä;
  private StringBuffer ã;
  private H ÿ;
  private H ý;
  private boolean ù;
  private String è;
  private volatile boolean ê;
  private static W þ = W.A();
  private boolean û = true;
  private static final int ü = 0;
  private static final int é = 1;
  private static final int å = 2;
  private int ö = 0;
  private com.biotools.poker.D.E ô = new com.biotools.poker.D.E();
  private static final boolean î = true;
  public static final double æ = 0.7D;
  public static final double ñ = 0.7D;
  public static final double õ = 1.0E-008D;
  private static HandEvaluator ç = new HandEvaluator();
  private Deck ì = new Deck();
  private Deck ð = new Deck();
  private double ú = 0.0D;

  public J()
  {
    if (com.biotools.poker.E.Ú())
      throw new RuntimeException("AI Not Available");
  }

  public JPanel A()
  {
    JLabel localJLabel = new JLabel(com.biotools.poker.E.D("Brains.OptiConfigurationOptionsHeading"), 0);
    localJLabel.setFont(new Font("Application", 1, 14));
    JPanel localJPanel = new JPanel(new BorderLayout(4, 4));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    localJPanel.add(localJLabel, "North");
    localJPanel.add(á(), "Center");
    return localJPanel;
  }

  public JSlider á()
  {
    int i = (int)(100.0D * Ý());
    JSlider localJSlider = new JSlider(0, 100, i);
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(new Integer(0), new JLabel(com.biotools.poker.E.D("Brains.Passive")));
    localHashtable.put(new Integer(100), new JLabel(com.biotools.poker.E.D("Brains.Aggressive")));
    localJSlider.setLabelTable(localHashtable);
    localJSlider.setPaintLabels(true);
    localJSlider.setMajorTickSpacing(25);
    localJSlider.setMinorTickSpacing(5);
    localJSlider.setPaintTicks(true);
    localJSlider.addChangeListener(new J.1(this, localJSlider));
    return localJSlider;
  }

  private double Ý()
  {
    return this.ë.getDoublePreference("HYBRID", 0.0D);
  }

  private boolean Ü()
  {
    return this.ë.getBooleanPreference("BUCKET_SPLIT", false);
  }

  private boolean Û()
  {
    return this.ë.getBooleanPreference("OVERLORD", true);
  }

  public void init(Preferences paramPreferences)
  {
    this.ë = paramPreferences;
    Q("BUCKET_SPLIT = " + Ü());
  }

  public Preferences B()
  {
    return this.ë;
  }

  public void gameOverEvent()
  {
  }

  private synchronized H Þ()
  {
    if (((Ý() < 1.0D) && (this.ÿ == null)) || ((Ý() > 0.0D) && (this.ý == null)))
    {
      P.A(null, "Loading Sparbot...", new J.2(this));
      System.out.println("DONE LOADING");
    }
    if (this.û)
      return this.ÿ;
    return this.ý;
  }

  public synchronized void holeCards(Card paramCard1, Card paramCard2, int paramInt)
  {
    if (this.ø.getNumPlayers() > 2)
      JOptionPane.showMessageDialog(null, "Error: " + this.ø.getPlayerName(paramInt) + " is a heads-up only player.\n" + " It cannot play at this table, so it will just check and call.\n");
    this.ó = paramCard1;
    this.ò = paramCard2;
    this.í = paramInt;
    this.û = (þ.nextDouble() > Ý());
    this.ï = 0;
    this.è = null;
    this.ù = false;
    this.ä = new StringBuffer();
    this.ã = new StringBuffer();
    A(this.ô);
    this.ú = -1.0D;
    Ù();
  }

  public void stageEvent(int paramInt)
  {
    if (paramInt == 1)
      this.è = this.ä.toString();
    if (paramInt > 0)
    {
      this.ù = true;
      this.ï = 0;
      this.ä.append('/');
      Ù();
    }
  }

  public void gameStateChanged()
  {
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
    switch (paramAction.getType())
    {
    case 0:
      this.ä.append('f');
      break;
    case 1:
      this.ä.append('k');
      break;
    case 2:
      if (!this.ù)
        this.ä.append('k');
      else
        this.ä.append('c');
      break;
    case 3:
      this.ï += 1;
      if (this.ï < 4)
      {
        if (!this.ù)
          this.ù = true;
        this.ä.append('b');
      }
      break;
    case 4:
      this.ï += 1;
      if (this.ï < 4)
        if (!this.ù)
        {
          this.ù = true;
          this.ä.append('b');
        }
        else
        {
          this.ä.append('r');
        }
      break;
    }
  }

  private com.biotools.poker.D.E à()
  {
    int i = this.ø.getButtonSeat() != this.í ? 2 : 1;
    return Þ().A(i + this.è);
  }

  private int E(int paramInt)
  {
    return 7;
  }

  private void Ù()
  {
    if (this.ø.getNumPlayers() > 2)
      return;
    if ((this.ø.getNumActivePlayers() - this.ø.getNumberOfAllInPlayers() < 2) || (this.ó == null) || (this.ò == null))
      return;
    this.ö = 0;
    if (this.ø.getStage() == 0)
    {
      int i = this.ø.getButtonSeat() == this.í ? 2 : 1;
      int j = (int)Þ().A(i).A(this.ó, this.ò);
      this.ã.append(j);
    }
    else
    {
      if (this.ø.getStage() == 1)
      {
        this.ã.setLength(0);
        this.ã.append("1");
      }
      this.ê = true;
      Thread localThread = new Thread(new J.3(this), "Opti-AHS Thread");
      localThread.start();
    }
  }

  private String Ú()
  {
    while (this.ê)
      try
      {
        Thread.sleep(10L);
      }
      catch (InterruptedException localInterruptedException)
      {
      }
    return this.ã.toString();
  }

  public void Q(String paramString)
  {
    if (com.biotools.poker.E.y())
      System.out.println(paramString);
  }

  public Action getAction()
  {
    int i = ß();
    Action localAction = Action.getAction(i, this.ø.getAmountToCall(this.í), this.ø.getCurrentBetSize());
    return S.A(localAction, this.í, this.ó, this.ò, this.ø);
  }

  public int ß()
  {
    if (com.biotools.poker.E.Ú())
      throw new RuntimeException("AI Not Available");
    if (this.ø.getNumPlayers() > 2)
      return 1;
    String str = Ú();
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append(this.ø.getButtonSeat() == this.í ? '2' : '1');
    localStringBuffer.append(this.ä.toString());
    Q(" | Optimal: " + this.ó + "-" + this.ò + " [" + localStringBuffer + " : " + str + "]");
    C localC = null;
    if ((Ü()) && (this.ö != 0))
    {
      localC = Þ().D(localStringBuffer.toString(), str);
      Q(" | Optimal: pt (before split) = " + localC);
      if (localC != null)
      {
        localC = A(localC, this.ö);
        Q(" | Optimal: pt (after split) = " + localC);
      }
    }
    else
    {
      localC = Þ().D(localStringBuffer.toString(), str);
      Q(" | Optimal: pt = " + localC);
    }
    int i = 0;
    if (localC == null)
      Q("ERROR: COULD NOT FIND STRATEGY");
    else
      i = localC.C(þ.nextDouble());
    if (Û())
    {
      double d1 = this.ø.getAmountToCall(this.í);
      if (this.ø.getStage() > 0)
      {
        double d2 = this.ú;
        if (HandEvaluator.isTheNuts(this.ó, this.ò, this.ø.getBoard(), G.A(this.ø).ŷ()))
          d2 = 1.0D;
        double d3;
        if (i == 0)
        {
          if (this.ø.getStage() < 3)
          {
            d3 = d1 / (this.ø.getEligiblePot(this.í) + d1);
            if (A.A(this.ó, this.ò, this.ø.getBoard()) > d3)
            {
              i = 1;
              System.err.println("[overlord] calling with draw odds");
            }
          }
          if (d2 > 0.5D)
          {
            i = 1;
            System.err.println("[overlord] calling with strength");
          }
          if (this.ø.canRaise(this.í))
            if (d2 > 0.9D)
            {
              i = 2;
              System.err.println("[overlord] raising with strength");
            }
            else if ((d2 > 0.65D) && (d1 == 0.0D))
            {
              i = 2;
              System.err.println("[overlord] betting with strength");
            }
        }
        if ((i == 1) && (this.ø.isRiver()))
          if (d2 > 0.999D)
          {
            if ((this.ø.getNumToAct() == 1) && (this.ø.canRaise(this.í)))
            {
              com.biotools.poker.E.H("[overlord] raising with nuts");
              i = 2;
            }
          }
          else if (d1 > 0.0D)
          {
            d3 = d1 / (this.ø.getEligiblePot(this.í) + d1);
            if (d2 < d3)
            {
              com.biotools.poker.E.H("[overlord] folding weak hand with poor odds");
              i = 0;
            }
          }
      }
      if ((i == 0) && (d1 == 0.0D))
        i = 1;
    }
    return i;
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    this.ø = paramGameInfo;
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
  }

  public C A(C paramC, int paramInt)
  {
    if (paramC == null)
      return null;
    double[] arrayOfDouble = new double[3];
    arrayOfDouble[0] = paramC.A(0);
    arrayOfDouble[1] = paramC.A(1);
    arrayOfDouble[2] = paramC.A(2);
    double d;
    int i;
    if (paramInt == 1)
    {
      Q(" | in top half of bucket:");
      d = 0.5D;
      for (i = 2; i >= 0; i--)
        if (arrayOfDouble[i] >= d)
        {
          arrayOfDouble[i] = (2.0D * d);
          d = 0.0D;
        }
        else
        {
          d -= arrayOfDouble[i];
          arrayOfDouble[i] *= 2.0D;
        }
    }
    else if (paramInt == 2)
    {
      Q(" | in bottom half of bucket:");
      d = 0.5D;
      for (i = 0; i <= 2; i++)
        if (arrayOfDouble[i] >= d)
        {
          arrayOfDouble[i] = (2.0D * d);
          d = 0.0D;
        }
        else
        {
          d -= arrayOfDouble[i];
          arrayOfDouble[i] *= 2.0D;
        }
    }
    else
    {
      Q(" | whole bucket:");
    }
    return new C(arrayOfDouble[0], arrayOfDouble[1], arrayOfDouble[2]);
  }

  public synchronized int A(int paramInt, double paramDouble, boolean paramBoolean)
  {
    int i = 0;
    if ((this.ø.getStage() == 3) || (!paramBoolean))
      i = E(paramDouble);
    else if (paramInt == 0)
      i = 0;
    else
      i = F(paramDouble);
    return i;
  }

  public static synchronized int E(double paramDouble)
  {
    int i = 0;
    if (paramDouble < 0.0D)
      paramDouble = 0.0D;
    if (paramDouble < 0.125D)
    {
      if (paramDouble - 0.0D < 0.125D - paramDouble)
        i = 2;
      else
        i = 1;
    }
    else if (paramDouble < 0.25D)
    {
      if (paramDouble - 0.125D < 0.25D - paramDouble)
        i = 2;
      else
        i = 1;
    }
    else if (paramDouble < 0.5D)
    {
      if (paramDouble - 0.25D < 0.5D - paramDouble)
        i = 2;
      else
        i = 1;
    }
    else if (paramDouble < 0.75D)
    {
      if (paramDouble - 0.5D < 0.75D - paramDouble)
        i = 2;
      else
        i = 1;
    }
    else if (paramDouble < 0.875D)
    {
      if (paramDouble - 0.75D < 0.875D - paramDouble)
        i = 2;
      else
        i = 1;
    }
    else if (paramDouble < 0.9375D)
    {
      if (paramDouble - 0.875D < 0.9375D - paramDouble)
        i = 2;
      else
        i = 1;
    }
    else if (paramDouble - 0.9375D < 1.0D - paramDouble)
      i = 2;
    else
      i = 1;
    return i;
  }

  public static synchronized int F(double paramDouble)
  {
    int i = 0;
    if (paramDouble < 0.0D)
      paramDouble = 0.0D;
    if (paramDouble < 0.125D)
      i = 2;
    else if (paramDouble < 0.25D)
      i = 1;
    else if (paramDouble < 0.5D)
    {
      if (paramDouble - 0.25D < 0.5D - paramDouble)
        i = 2;
      else
        i = 1;
    }
    else if (paramDouble < 0.75D)
    {
      if (paramDouble - 0.5D < 0.75D - paramDouble)
        i = 2;
      else
        i = 1;
    }
    else if (paramDouble < 0.875D)
    {
      if (paramDouble - 0.75D < 0.875D - paramDouble)
        i = 2;
      else
        i = 1;
    }
    else if (paramDouble < 0.9375D)
    {
      if (paramDouble - 0.875D < 0.9375D - paramDouble)
        i = 2;
      else
        i = 1;
    }
    else if (paramDouble - 0.9375D < 1.0D - paramDouble)
      i = 2;
    else
      i = 1;
    return i;
  }

  private synchronized int A(Card paramCard1, Card paramCard2, Hand paramHand, int paramInt1, int paramInt2, com.biotools.poker.D.E paramE1, boolean paramBoolean, int paramInt3, double paramDouble, com.biotools.poker.D.E paramE2)
  {
    double d = 0.0D;
    if (paramInt2 == 1)
      return 0;
    int i = A(paramDouble, paramInt2);
    com.biotools.poker.E.H(" | bkt = " + i);
    if ((paramInt1 == 0) || (!paramBoolean))
      return i;
    if (i == 0)
      i = 1;
    if (paramDouble > 0.6999999899999999D)
      return i;
    d = A(paramCard1, paramCard2, paramHand, paramInt1, paramE1, paramDouble, paramBoolean, paramInt3, paramE2);
    com.biotools.poker.E.H(" | potential = " + b.A(d, 5));
    if (d > 1.0E-008D)
      i = 0;
    return i;
  }

  private synchronized double A(Card paramCard1, Card paramCard2, Hand paramHand, int paramInt1, com.biotools.poker.D.E paramE1, double paramDouble, boolean paramBoolean, int paramInt2, com.biotools.poker.D.E paramE2)
  {
    int i = 1;
    double d1 = 0.0D;
    double d2 = 0.0D;
    double d3 = -1.0D;
    for (int j = 0; j < paramInt1; j++)
      i *= (50 - paramHand.size() - j);
    for (j = 2; j <= paramInt1; j++)
      i /= j;
    this.ì.reset();
    this.ì.extractHand(paramHand);
    this.ì.extractCard(paramCard1);
    this.ì.extractCard(paramCard2);
    if (paramInt1 == 1)
      for (j = this.ì.getTopCardIndex(); j < 52; j++)
      {
        paramHand.addCard(this.ì.getCard(j));
        d3 = paramE2.A(paramHand.getCard(paramHand.size() - 1), paramHand.getCard(paramHand.size()));
        if (d3 != -1.0D)
        {
          d2 = d3 - 1.0E-008D;
        }
        else
        {
          d2 = paramE1.A(paramCard1, paramCard2, paramHand) - 1.0E-008D;
          com.biotools.poker.E.H("HS should be cached!");
          if (!$assertionsDisabled)
            throw new AssertionError(d3);
        }
        if ((d2 > 0.7D) && (d2 > paramDouble))
          d1 += d2 * d2;
        paramHand.removeCard();
      }
    else if (paramInt1 == 2)
      for (j = this.ì.getTopCardIndex(); j < 51; j++)
      {
        paramHand.addCard(this.ì.getCard(j));
        for (int k = j + 1; k < 52; k++)
        {
          paramHand.addCard(this.ì.getCard(k));
          d3 = paramE2.A(paramHand.getCard(paramHand.size() - 1), paramHand.getCard(paramHand.size()));
          if (d3 != -1.0D)
          {
            d2 = d3 - 1.0E-008D;
          }
          else
          {
            d2 = paramE1.A(paramCard1, paramCard2, paramHand) - 1.0E-008D;
            com.biotools.poker.E.H("HS should be cached!");
            if (!$assertionsDisabled)
              throw new AssertionError(d3);
          }
          if ((d2 > 0.7D) && (d2 > paramDouble))
            d1 += d2 * d2;
          paramHand.removeCard();
        }
        paramHand.removeCard();
      }
    d1 /= i;
    if (paramInt1 == 1)
      d1 -= 2.0D / (paramInt2 + 8.0D);
    else
      d1 -= 2.0D / (paramInt2 + 4.0D);
    return d1;
  }

  private synchronized double A(Card paramCard1, Card paramCard2, Hand paramHand, int paramInt, com.biotools.poker.D.E paramE1, com.biotools.poker.D.E paramE2)
  {
    int i = 0;
    double d1 = 0.0D;
    double d2 = -1.0D;
    if (paramHand.size() < 3)
    {
      com.biotools.poker.E.H("NOT ENOUGH BOARD CARDS!");
      return -1.0D;
    }
    if ((paramInt < 0) || (paramInt > 2))
    {
      com.biotools.poker.E.H("CAN'T ROLLOUT THAT " + paramInt + " CARDS!");
      return -1.0D;
    }
    this.ð.reset();
    this.ð.extractHand(paramHand);
    this.ð.extractCard(paramCard1);
    this.ð.extractCard(paramCard2);
    int j;
    if (paramInt == 1)
    {
      for (j = this.ð.getTopCardIndex(); j < 52; j++)
      {
        paramHand.addCard(this.ð.getCard(j));
        d2 = paramE1.A(paramCard1, paramCard2, paramHand, HandEvaluator.getRanks(paramHand));
        d1 += d2;
        paramE2.A(paramHand.getCard(paramHand.size() - 1), paramHand.getCard(paramHand.size()), d2);
        i++;
        paramHand.removeCard();
      }
    }
    else if (paramInt == 2)
    {
      for (j = this.ð.getTopCardIndex(); j < 51; j++)
      {
        paramHand.addCard(this.ð.getCard(j));
        for (int k = j + 1; k < 52; k++)
        {
          paramHand.addCard(this.ð.getCard(k));
          d2 = paramE1.A(paramCard1, paramCard2, paramHand, HandEvaluator.getRanks(paramHand));
          d1 += d2;
          paramE2.A(paramHand.getCard(paramHand.size() - 1), paramHand.getCard(paramHand.size()), d2);
          i++;
          paramHand.removeCard();
        }
        paramHand.removeCard();
      }
    }
    else
    {
      d2 = paramE1.A(paramCard1, paramCard2, paramHand);
      d1 += d2;
      paramE2.A(paramHand.getCard(paramHand.size() - 1), paramHand.getCard(paramHand.size()), d2);
      i++;
    }
    if (i == 1)
      return d1;
    return d1 / i;
  }

  private void A(com.biotools.poker.D.E paramE)
  {
    paramE.A(-1.0D);
  }

  public static synchronized int A(double paramDouble, int paramInt)
  {
    int i;
    if (paramInt != 7)
      i = (int)(paramDouble * paramInt - 1.0E-008D);
    else if (paramDouble < 0.125D)
      i = 0;
    else if (paramDouble < 0.25D)
      i = 1;
    else if (paramDouble < 0.5D)
      i = 2;
    else if (paramDouble < 0.75D)
      i = 3;
    else if (paramDouble < 0.875D)
      i = 4;
    else if (paramDouble < 0.9375D)
      i = 5;
    else
      i = 6;
    return i;
  }

  public void dealHoleCardsEvent()
  {
  }

  private int R(String paramString)
  {
    String[] arrayOfString = { "kk", "bc", "brc", "kbc", "kbrc", "brrc", "brrrc", "kbrrc" };
    int[] arrayOfInt = { 2, 4, 6, 4, 6, 8, 10, 8 };
    int i = 0;
    int j = -1;
    for (i = 0; i < 8; i++)
      if (paramString.equalsIgnoreCase(arrayOfString[i]))
      {
        j = i;
        break;
      }
    if (j != -1)
      return arrayOfInt[j];
    com.biotools.poker.E.H("Can't find preflop string when looking for the number of bets in the pot");
    if (!$assertionsDisabled)
      throw new AssertionError(paramString);
    return 2;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.J
 * JD-Core Version:    0.6.2
 */