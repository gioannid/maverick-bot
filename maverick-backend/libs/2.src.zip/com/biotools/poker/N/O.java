package com.biotools.poker.N;

import com.biotools.A.b;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.D.A;
import com.biotools.poker.D.B;
import com.biotools.poker.D.C;
import com.biotools.poker.D.G;
import com.biotools.poker.E.D;
import com.biotools.poker.F.P;
import com.biotools.poker.N.B.K;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class O
  implements D
{
  public static final String Ĩ = "TIGHTNESS";
  public static final String ķ = "AGGRESSION";
  public static final String ĩ = "DECEPTION";
  public static final String İ = "COSTSENS";
  public static final String Ĳ = "POSITION";
  private Preferences Ī;
  private GameInfo Ĵ;
  private Card ĭ;
  private Card ī;
  private int ı;
  double[] Ĭ = { 0.4D, 0.45D, 0.45D, 0.55D };
  double[] ĳ = { 0.35D, 0.25D, 0.2D, 0.1D };
  double[] Į = { 0.75D, 0.9D, 0.8D, 0.5D };
  double[] Ĺ = { 0.25D, 0.15D, 0.15D, 0.15D };
  double[] į = { 0.5D, 0.15D, 0.15D, 0.15D };
  int ĸ;
  int ĵ;
  double Ķ;

  public void dealHoleCardsEvent()
  {
  }

  private void K(int paramInt)
  {
    this.Ĭ[paramInt] = this.Ī.getDoublePreference("TIGHTNESS" + paramInt, this.Ĭ[paramInt]);
    this.ĳ[paramInt] = this.Ī.getDoublePreference("AGGRESSION" + paramInt, this.ĳ[paramInt]);
    this.Į[paramInt] = this.Ī.getDoublePreference("DECEPTION" + paramInt, this.Į[paramInt]);
    this.Ĺ[paramInt] = this.Ī.getDoublePreference("POSITION" + paramInt, this.Ĺ[paramInt]);
    this.į[paramInt] = this.Ī.getDoublePreference("COSTSENS" + paramInt, this.į[paramInt]);
  }

  public JPanel A()
  {
    JTabbedPane localJTabbedPane = new JTabbedPane();
    localJTabbedPane.add(com.biotools.poker.E.D("Brains.PreFlop"), I(0));
    localJTabbedPane.add(com.biotools.poker.E.D("Brains.Flop"), I(1));
    localJTabbedPane.add(com.biotools.poker.E.D("Brains.Turn"), I(2));
    localJTabbedPane.add(com.biotools.poker.E.D("Brains.River"), I(3));
    JPanel localJPanel = new JPanel();
    localJPanel.add(localJTabbedPane);
    return localJPanel;
  }

  public JComponent I(int paramInt)
  {
    return new P(this.Ī, paramInt);
  }

  public Preferences B()
  {
    return this.Ī;
  }

  public void init(Preferences paramPreferences)
  {
    this.Ī = paramPreferences;
    for (int i = 0; i <= 3; i++)
      K(i);
  }

  public void holeCards(Card paramCard1, Card paramCard2, int paramInt)
  {
    this.ĭ = paramCard1;
    this.ī = paramCard2;
    this.ı = paramInt;
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    this.Ĵ = paramGameInfo;
  }

  private int ó()
  {
    int i = 0;
    int j = (this.Ĵ.getCurrentPlayerSeat() + 1) % this.Ĵ.getNumSeats();
    assert (this.Ĵ.getSmallBlindSeat() != -1);
    int k = 0;
    while ((j != this.Ĵ.getSmallBlindSeat()) && (k++ < this.Ĵ.getNumSeats()))
    {
      j = (j + 1) % this.Ĵ.getNumSeats();
      if (this.Ĵ.isActive(j))
        i++;
    }
    return i;
  }

  public Action getAction()
  {
    this.ĸ = this.Ĵ.getStage();
    this.Ķ = this.Ĵ.getBetsToCall(this.ı);
    double d1 = 0.0D;
    if (this.Ĵ.isPreFlop())
    {
      d1 = K.B(this.ĭ, this.ī, this.Ĵ.getNumPlayers());
      this.ĵ = ó();
    }
    else
    {
      this.ĵ = ó();
      double d2 = ö();
      double d3 = 0.0D;
      double d4 = 0.0D;
      if (!this.Ĵ.isRiver())
        if (this.Ĵ.isZipMode())
        {
          d3 = A.A(this.ĭ, this.ī, this.Ĵ.getBoard());
        }
        else
        {
          double[] arrayOfDouble = A.B(this.ĭ, this.ī, this.Ĵ.getBoard(), J(this.ı));
          d3 = arrayOfDouble[0];
          d4 = arrayOfDouble[1];
        }
      double d5 = d2 + (1.0D - d2) * d3;
      if (HandEvaluator.isTheNuts(this.ĭ, this.ī, this.Ĵ.getBoard(), G.A(this.Ĵ).ŷ()))
        d2 = d5 = 1.0D;
      d1 = d5;
    }
    C localC = I(d1);
    com.biotools.poker.E.H(" | " + this.ĵ + " : " + b.A(ò(), 3) + "/" + b.A(ô(), 3));
    com.biotools.poker.E.H(" | " + b.A(d1, 3) + " " + localC);
    Action localAction = Action.getAction(localC.L(), this.Ķ, this.Ĵ.getMinRaise());
    return S.A(localAction, this.ı, this.ĭ, this.ī, this.Ĵ);
  }

  protected com.biotools.poker.D.E L(int paramInt)
  {
    return G.A(this.Ĵ).Q(paramInt).Ŧ();
  }

  protected com.biotools.poker.D.E J(int paramInt)
  {
    com.biotools.poker.D.E localE = new com.biotools.poker.D.E();
    double[] arrayOfDouble = new double[this.Ĵ.getNumSeats()];
    for (int i = 0; i < this.Ĵ.getNumSeats(); i++)
      if (this.Ĵ.isActive(i))
        arrayOfDouble[i] = L(i).A();
    Card localCard1 = new Card();
    Card localCard2 = new Card();
    for (i = 0; i < 52; i++)
    {
      localCard1.setIndex(i);
      for (int j = i + 1; j < 52; j++)
      {
        localCard2.setIndex(j);
        double d1 = 0.0D;
        double d2 = 0.0D;
        for (int k = 0; k < this.Ĵ.getNumSeats(); k++)
          if ((this.Ĵ.isActive(k)) && (k != paramInt))
          {
            double d3 = L(k).A(localCard1, localCard2) / arrayOfDouble[k];
            d1 += d3;
            if (d3 > d2)
              d2 = d3;
          }
        localE.A(localCard1, localCard2, d2);
      }
    }
    return localE;
  }

  public double ö()
  {
    return A(this.ı, this.ĭ, this.ī);
  }

  public double A(int paramInt, Card paramCard1, Card paramCard2)
  {
    double d = 1.0D;
    for (int i = 0; i < this.Ĵ.getNumSeats(); i++)
      if ((i != paramInt) && (this.Ĵ.isActive(i)))
        d *= L(i).A(paramCard1, paramCard2, this.Ĵ.getBoard(), G.A(this.Ĵ).ŷ());
    return d;
  }

  public double C(double paramDouble1, double paramDouble2)
  {
    try
    {
      return 1.0D / (1.0D + Math.exp(-paramDouble2 * paramDouble1));
    }
    catch (ArithmeticException localArithmeticException)
    {
    }
    return 1.0D;
  }

  public double õ()
  {
    double d = Math.pow(this.Ĭ[this.ĸ], 1.0D + this.Ĺ[this.ĸ] * this.ĵ + this.į[this.ĸ] * (this.Ķ - 1.0D));
    return d;
  }

  public double ò()
  {
    double d = 1.0D - õ();
    if (this.Ķ < 1.0D)
      d *= this.Ķ;
    return d;
  }

  public double ô()
  {
    double d = 1.0D - õ() * this.ĳ[this.ĸ];
    if (this.Ķ == 0.0D)
      d = (ò() + d) * 0.5D;
    return d;
  }

  public double ø()
  {
    return Math.pow(this.Į[this.ĸ], 1.0D + this.Ĺ[this.ĸ] * this.ĵ + this.į[this.ĸ] * this.Ķ);
  }

  public double K(double paramDouble)
  {
    double d1 = ô();
    double d2 = ò();
    double d3 = ø();
    double d4 = 1.0D - C(d1 - paramDouble, 10.0D + (1.0D - d3) * 200.0D);
    d4 += 0.5D * d3 * d3 * C(this.Ĭ[this.ĸ] / (4.0D / this.ĳ[this.ĸ]) - paramDouble, 20.0D);
    if (d4 > 1.0D)
      d4 = 1.0D;
    return d4;
  }

  public double J(double paramDouble)
  {
    double d1 = ô();
    double d2 = ò();
    double d3 = ø();
    if (paramDouble > d1)
      return 1.0D;
    double d4 = 1.0D - C(d2 - paramDouble, 5.0D + (1.0D - d3) * 100.0D);
    d4 += 0.5D * d3 * d3 * C(this.Ĭ[this.ĸ] / 4.0D - paramDouble, 20.0D);
    if (d4 > 1.0D)
      d4 = 1.0D;
    return d4;
  }

  public C I(double paramDouble)
  {
    C localC = new C();
    localC.F(K(paramDouble));
    localC.D(J(paramDouble) - localC.D());
    localC.B(1.0D - (localC.C() + localC.D()));
    localC.E();
    return localC;
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
  }

  public void stageEvent(int paramInt)
  {
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
  }

  public void gameOverEvent()
  {
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
  }

  public void gameStateChanged()
  {
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.O
 * JD-Core Version:    0.6.2
 */