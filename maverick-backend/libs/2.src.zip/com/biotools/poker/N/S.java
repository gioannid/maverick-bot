package com.biotools.poker.N;

import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.poker.D.G;

public class S
{
  public static Action A(Action paramAction, int paramInt, Card paramCard1, Card paramCard2, GameInfo paramGameInfo)
  {
    double d = paramGameInfo.getAmountToCall(paramInt);
    if ((paramAction.isFold()) && (d == 0.0D))
      paramAction = Action.checkAction();
    else if ((paramAction.isBetOrRaise()) && (!paramGameInfo.canRaise(paramInt)))
      paramAction = Action.callAction(d);
    if ((paramAction.isRaise()) && (paramGameInfo.getNumRaises() >= 4))
      if (paramGameInfo.isPreFlop())
        paramAction = Action.callAction(d);
      else if ((!HandEvaluator.isTheNuts(paramCard1, paramCard2, paramGameInfo.getBoard(), G.A(paramGameInfo).ŷ())) || (!paramGameInfo.isRiver()))
        paramAction = Action.callAction(d);
    return paramAction;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.S
 * JD-Core Version:    0.6.2
 */