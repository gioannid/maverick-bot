package com.biotools.poker.N;

import com.biotools.B.P;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import com.biotools.poker.E.D;
import com.biotools.poker.N.C.G;
import java.awt.BorderLayout;
import java.awt.Font;
import java.util.Hashtable;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;

public final class A extends G
  implements D
{
  private Preferences c;

  public A()
  {
    if (E.Ú())
      throw new RuntimeException("AI Not Available");
  }

  public JPanel A()
  {
    JLabel localJLabel = new JLabel(E.D("Brains.MiximaxConfigurationOptionsHeading"), 0);
    localJLabel.setFont(new Font("Application", 1, 14));
    JCheckBox localJCheckBox = new JCheckBox(E.D("Brains.MiximaxFastPreflopStrategy"));
    localJCheckBox.setSelected(this.c.getBooleanPreference("USE_PREFLOP_EXPERT", true));
    localJCheckBox.setToolTipText("<html>" + E.D("Brains.MiximaxFastPreflopStrategyToolTip").replaceAll("\n", "<br>") + "</html>");
    localJCheckBox.addActionListener(new A.1(this, localJCheckBox));
    JPanel localJPanel = new JPanel(new BorderLayout(4, 4));
    localJPanel.setLayout(new BoxLayout(localJPanel, 1));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    localJPanel.add(localJLabel, "North");
    localJPanel.add(Box.createVerticalStrut(20));
    localJPanel.add(localJCheckBox);
    localJPanel.add(Box.createVerticalStrut(10));
    localJPanel.add(J());
    localJPanel.add(Box.createVerticalStrut(10));
    localJPanel.add(L());
    localJPanel.add(Box.createVerticalGlue());
    localJPanel.add(Box.createVerticalStrut(10));
    return localJPanel;
  }

  public JSlider J()
  {
    int i = (int)(100.0D * K());
    JSlider localJSlider = new JSlider(0, 100, i);
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(new Integer(0), new JLabel(E.D("Brains.Passive")));
    localHashtable.put(new Integer(100), new JLabel(E.D("Brains.Aggressive")));
    localJSlider.setLabelTable(localHashtable);
    localJSlider.setPaintLabels(true);
    localJSlider.setMajorTickSpacing(25);
    localJSlider.setMinorTickSpacing(5);
    localJSlider.setPaintTicks(true);
    localJSlider.addChangeListener(new A.2(this, localJSlider));
    return localJSlider;
  }

  private double K()
  {
    return this.c.getDoublePreference("FOLD_SCALE", 0.6D);
  }

  public JSlider L()
  {
    int i = (int)(100.0D * this.c.getDoublePreference("EXPLORATION_MU", 0.05D) / 0.1D);
    JSlider localJSlider = new JSlider(0, 100, i);
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(new Integer(0), new JLabel(E.D("Brains.Exploitation")));
    localHashtable.put(new Integer(100), new JLabel(E.D("Brains.Exploration")));
    localJSlider.setLabelTable(localHashtable);
    localJSlider.setPaintLabels(true);
    localJSlider.setMajorTickSpacing(25);
    localJSlider.setMinorTickSpacing(5);
    localJSlider.setPaintTicks(true);
    localJSlider.addChangeListener(new A.3(this, localJSlider));
    return localJSlider;
  }

  public void I()
  {
    P.A(null, E.D("Brains.MiximaxLoading"), new A.4(this));
  }

  public void M()
  {
    super.I();
  }

  public void init(Preferences paramPreferences)
  {
    this.c = paramPreferences;
    super.init(paramPreferences);
  }

  public Preferences B()
  {
    return this.c;
  }

  public synchronized void holeCards(Card paramCard1, Card paramCard2, int paramInt)
  {
    if (this.a.getNumPlayers() > 2)
    {
      Object[] arrayOfObject = { this.a.getPlayerName(paramInt) };
      JOptionPane.showMessageDialog(null, E.A("Brains.ErrorHeadsUpOnlyPattern", arrayOfObject));
    }
    super.holeCards(paramCard1, paramCard2, paramInt);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.A
 * JD-Core Version:    0.6.2
 */