package com.biotools.poker.N;

import com.biotools.meerkat.Action;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.D.C;

public class Y extends P
{
  protected int t = 100;
  protected int u = 1500;
  protected int v = 3;

  public Y()
  {
  }

  public Y(Preferences paramPreferences)
  {
    init(paramPreferences);
  }

  public void init(Preferences paramPreferences)
  {
    super.init(paramPreferences);
    this.t = paramPreferences.getIntPreference("SIM_MIN_TRIALS");
    this.u = paramPreferences.getIntPreference("SIM_MAX_TIME");
    this.v = paramPreferences.getIntPreference("SIM_PREDICTOR");
  }

  public double b()
  {
    return this.o.getDoublePreference("PF_DECEPTION", 0.025D);
  }

  public double k()
  {
    return this.o.getDoublePreference("NOISE_FACTOR", 0.5D);
  }

  public double j()
  {
    return this.o.getDoublePreference("SIM_NOISE_FACTOR", 0.5D);
  }

  public synchronized Action getAction()
  {
    int i = this.k.getNumRaises() == 0 ? 1 : 0;
    if (this.k.getStage() == 0)
    {
      i = R();
    }
    else
    {
      A(-1);
      if ((this.k.isZipMode()) || (this.k.isSimulation()))
        return super.getAction();
      T localT = new T(this.e, this.h, this.g, this.n, this.k);
      localT.A(j());
      this.q = localT.B(this.t, this.u, this.v);
      i = this.q.L();
      localT = null;
    }
    double d = this.k.getAmountToCall(this.e);
    Action localAction = Action.getAction(i, d, this.k.getCurrentBetSize());
    return S.A(localAction, this.e, this.h, this.g, this.k);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.Y
 * JD-Core Version:    0.6.2
 */