package com.biotools.poker.N.C.A;

import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.D.C;
import com.biotools.poker.N.C.D;

public abstract class F
{
  public abstract void B();

  public abstract void A(Preferences paramPreferences);

  public abstract void A(double paramDouble);

  public abstract void C(String paramString);

  public abstract void B(String paramString);

  public abstract void A(J paramJ);

  public abstract Object A(String paramString);

  public abstract Object A(Object paramObject, String paramString);

  public abstract Object A(Object paramObject, int paramInt);

  public abstract Object A(Object paramObject, char paramChar);

  public abstract C A(D paramD, Object paramObject);

  public abstract double[] B(Object paramObject);

  public abstract double A(double paramDouble, D paramD, Object paramObject);

  public abstract void A();

  public abstract void A(Object paramObject);
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.C.A.F
 * JD-Core Version:    0.6.2
 */