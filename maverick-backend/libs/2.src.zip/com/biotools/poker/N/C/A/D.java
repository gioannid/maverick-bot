package com.biotools.poker.N.C.A;

import com.biotools.A.b;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.D.C;
import com.biotools.poker.N.C.A.A.E;
import com.biotools.poker.N.C.A.A.G;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.RandomAccessFile;

public class D extends F
{
  E M;
  H R;
  M P;
  private static final boolean N = false;
  private static final int Q = 5;
  private static final boolean L = false;
  private static final boolean O = true;
  private static b K = b.D();

  public void B()
  {
    this.M = new E();
    this.R = new H();
    this.P = new M();
  }

  public void A(double paramDouble)
  {
    assert ((this.M != null) && (this.R != null) && (this.P != null));
    this.M.C(paramDouble);
    this.R.A(paramDouble);
    this.P.A(paramDouble);
  }

  public void A(Preferences paramPreferences)
  {
    B();
  }

  public E G()
  {
    return this.M;
  }

  public void A(J paramJ)
  {
    this.M.A(paramJ);
    if ((!paramJ.C().endsWith("F")) && (!paramJ.C().endsWith("f")))
    {
      this.R.A(paramJ);
      this.P.A(paramJ);
    }
  }

  public Object A(String paramString)
  {
    return this.M.B(paramString);
  }

  public Object A(Object paramObject, String paramString)
  {
    return this.M.A((G)paramObject, paramString);
  }

  public Object A(Object paramObject, int paramInt)
  {
    return this.M.A((G)paramObject, paramInt);
  }

  public Object A(Object paramObject, char paramChar)
  {
    return this.M.A((G)paramObject, paramChar);
  }

  public C A(com.biotools.poker.N.C.D paramD, Object paramObject)
  {
    C localC1 = this.M.B((G)paramObject);
    if (localC1 == null)
      return D(paramD);
    double d1 = ((G)paramObject).B();
    if (d1 == 0.0D)
      d1 = 1.0D;
    double d2 = Math.pow(0.6D, d1);
    if (d2 < 0.05D)
      return localC1;
    C localC2 = D(paramD);
    localC2.B(d2 * localC2.J() + (1.0D - d2) * localC1.J());
    localC2.D(d2 * localC2.C() + (1.0D - d2) * localC1.C());
    localC2.F(d2 * localC2.D() + (1.0D - d2) * localC1.D());
    return localC2;
  }

  private C D(com.biotools.poker.N.C.D paramD)
  {
    double[] arrayOfDouble = new double[3];
    arrayOfDouble[0] = 0.0D;
    if (paramD.Y())
    {
      arrayOfDouble[1] = 1.0D;
      arrayOfDouble[2] = 0.0D;
    }
    else
    {
      arrayOfDouble[1] = 0.75D;
      arrayOfDouble[2] = 0.25D;
    }
    C localC = new C(arrayOfDouble[0], arrayOfDouble[1], arrayOfDouble[2]);
    return localC;
  }

  public double[] B(Object paramObject)
  {
    return this.M.C((G)paramObject);
  }

  public double B(double paramDouble, com.biotools.poker.N.C.D paramD, Object paramObject)
  {
    double d1 = 0.0D;
    G localG = (G)paramObject;
    String str1 = paramD.p();
    if ((localG == null) || (localG.B() < 5.0D))
    {
      int[] arrayOfInt = D(str1);
      int i = arrayOfInt[0];
      int j = arrayOfInt[1];
      String str2 = "(" + i + ", " + j + ")";
      double d2 = this.P.A(str2);
      double d3 = this.P.A(paramDouble, str2);
      if ((d3 < 0.0D) || (d2 < 5.0D))
      {
        double d4 = this.R.A(paramDouble, i);
        if ((d4 < 0.0D) || (this.R.A(i) < 3.0D))
        {
          double d5 = paramD.q() / paramD.l();
          d1 = Math.pow(paramDouble, 1.0D + 0.1D * d5 + 0.1D * paramD.e());
        }
        else
        {
          d1 = d4;
        }
      }
      else
      {
        d1 = d3;
      }
    }
    else
    {
      d1 = this.M.A(paramDouble, paramD, localG);
    }
    return d1;
  }

  public double A(double paramDouble, com.biotools.poker.N.C.D paramD, Object paramObject)
  {
    G localG = (G)paramObject;
    String str1 = paramD.p();
    double d1 = 0.0D;
    double d2 = 1.0D;
    if (localG != null)
    {
      double d3 = d2 * (1.0D - Math.pow(0.95D, localG.B()));
      d2 -= d3;
      d1 += d3 * this.M.A(paramDouble, paramD, localG);
    }
    int[] arrayOfInt = D(str1);
    int i = arrayOfInt[0];
    int j = arrayOfInt[1];
    String str2 = "(" + i + ", " + j + ")";
    double d4 = this.P.A(str2);
    double d5 = this.P.A(paramDouble, str2);
    if (d5 >= 0.0D)
    {
      d6 = d2 * (1.0D - Math.pow(0.95D, d4));
      d2 -= d6;
      d1 += d6 * d5;
    }
    double d6 = this.R.A(paramDouble, i);
    if (d6 >= 0.0D)
    {
      d7 = d2 * (1.0D - Math.pow(0.95D, this.R.A(i)));
      d2 -= d7;
      d1 += d7 * d6;
    }
    double d7 = paramD.q() / paramD.l();
    double d8 = 0.1D * (paramD.e() - 1);
    d1 += d2 * Math.pow(paramDouble, 1.0D + 0.1D * d7 + d8);
    return d1;
  }

  public double C(double paramDouble, com.biotools.poker.N.C.D paramD, Object paramObject)
  {
    G localG = (G)paramObject;
    String str1 = paramD.p();
    double d1 = 0.0D;
    int i = 0;
    if ((localG != null) && (localG.B() >= 5.0D))
    {
      d1 += this.M.A(paramDouble, paramD, localG);
      i++;
    }
    int[] arrayOfInt = D(str1);
    int j = arrayOfInt[0];
    int k = arrayOfInt[1];
    String str2 = "(" + j + ", " + k + ")";
    double d2 = this.P.A(str2);
    double d3 = this.P.A(paramDouble, str2);
    if ((d3 >= 0.0D) && (d2 >= 5.0D))
    {
      d1 += d3;
      i++;
    }
    double d4 = this.R.A(paramDouble, j);
    if ((d4 >= 0.0D) && (this.R.A(j) >= 5.0D))
    {
      d1 += d4;
      i++;
    }
    double d5 = paramD.q() / paramD.l();
    d1 += Math.pow(paramDouble, 1.0D + 0.125D * d5 + 0.1D * (paramD.e() - 1));
    i++;
    return d1 / i;
  }

  public void A()
  {
    K.K("\nContext trie: ");
    K.K("Number of 5 pt. leaves = " + this.M.A(5.0D));
    this.M.B(5.0D);
    K.K("\n Bet trie: ");
    this.R.B();
    K.K("\n Bet Trie 2d: ");
    this.P.B();
  }

  public void A(Object paramObject)
  {
    K.K(((G)paramObject).toString());
  }

  public void B(String paramString)
  {
    this.M.A(paramString);
  }

  public void C(String paramString)
  {
    try
    {
      RandomAccessFile localRandomAccessFile = new RandomAccessFile(paramString, "r");
      for (String str = localRandomAccessFile.readLine(); str != null; str = localRandomAccessFile.readLine())
      {
        J localJ = new J(str);
        A(localJ);
      }
      localRandomAccessFile.close();
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      System.out.println("File Not Found: [" + paramString + "]");
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }

  private int[] D(String paramString)
  {
    int[] arrayOfInt = new int[2];
    for (int j = 0; j < paramString.length(); j++)
    {
      int i = paramString.charAt(j);
      if ((i == 98) || (i == 114))
        arrayOfInt[0] += 1;
      else if ((i == 66) || (i == 82))
        arrayOfInt[1] += 1;
    }
    return arrayOfInt;
  }

  public static void F()
  {
    D localD = new D();
    localD.B();
    localD.C("/usr/scratch/terence/logs/seededMixi1dp/Opti.ctx");
    b localb = b.D();
    localb.I("hierarchyModel.beforeScale");
    localb.K("Before scaling...");
    localD.A();
    localb.I("hierarchyModel.afterScale");
    localb.K("After scaling...");
    localD.A(1.0D);
    localD.A();
  }

  public static void C(String[] paramArrayOfString)
  {
    F();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.C.A.D
 * JD-Core Version:    0.6.2
 */