package com.biotools.poker.N.C;

import com.biotools.A.W;
import com.biotools.A.b;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.Player;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import com.biotools.poker.N.C.A.D;
import com.biotools.poker.N.C.A.J;
import java.io.File;

public class G
  implements Player
{
  protected Card Z;
  protected Card Y;
  protected Hand S;
  protected int V;
  protected GameInfo a;
  private StringBuffer M;
  private double L;
  protected W U = W.A();
  protected b X = b.D();
  protected Preferences R;
  private K _ = null;
  private com.biotools.poker.N.C.A.F b = null;
  private String Q = null;
  private String N = null;
  private String T = "model.log.ctx";
  private boolean O = false;
  private boolean P = true;
  protected static final boolean W = false;

  public G()
  {
  }

  public G(Preferences paramPreferences)
  {
    init(paramPreferences);
  }

  public void init(Preferences paramPreferences)
  {
    this.R = paramPreferences;
    this.X.K("Creating Miximax Player:");
    this.b = new D();
    this.N = paramPreferences.getPreference("DEFAULT_MODEL", null);
    this.O = paramPreferences.getBooleanPreference("FREEZE_LEARNING", false);
    this.P = paramPreferences.getBooleanPreference("LOG_GAME", true);
    this._ = new K(this.b, this.U);
    this._.A(paramPreferences);
  }

  private String A(GameInfo paramGameInfo, String paramString1, String paramString2)
  {
    String str = paramGameInfo.getLogDirectory() + paramString1;
    File localFile = new File(str);
    if ((!localFile.exists()) || (!localFile.isDirectory()))
    {
      localFile.mkdir();
      this.X.K("Creating Opponent Model Directory: " + str);
    }
    return str + '/' + paramString2 + ".ctx";
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    this.a = paramGameInfo;
    this._.A(paramGameInfo);
  }

  public synchronized void holeCards(Card paramCard1, Card paramCard2, int paramInt)
  {
    try
    {
      this.Z = paramCard1;
      this.Y = paramCard2;
      this.V = paramInt;
      this.M = new StringBuffer();
      this.L = this.a.getPlayer(paramInt).getBankRoll();
      int i = this.a.nextPlayer(paramInt);
      String str = this.a.getPlayerName(i).toLowerCase();
      if ((this.Q == null) || (!this.Q.equals(str)))
        I();
      this._.A(paramCard1, paramCard2, paramInt);
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  public void I()
  {
    int i = this.a.nextPlayer(this.V);
    String str1 = this.a.getPlayerName(i).toLowerCase();
    String str2 = this.a.getPlayerName(this.V);
    this.T = A(this.a, str2, str1);
    this.b.B();
    if (this.N != null)
    {
      this.X.K("Loading default model file");
      this.b.C(this.N);
    }
    else
    {
      this.X.K("Not loading any default model");
    }
    this.X.K("Loading opp. model file " + this.T + " for " + str1);
    this.b.C(this.T);
    System.gc();
    this.Q = str1;
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
    switch (paramAction.getType())
    {
    case 0:
      this.M.append(this.V == paramInt ? 'F' : 'f');
      break;
    case 1:
      this.M.append(this.V == paramInt ? 'K' : 'k');
      break;
    case 2:
      this.M.append(this.V == paramInt ? 'C' : 'c');
      break;
    case 3:
      this.M.append(this.V == paramInt ? 'B' : 'b');
      break;
    case 4:
      this.M.append(this.V == paramInt ? 'R' : 'r');
    }
  }

  public void stageEvent(int paramInt)
  {
    if (paramInt > 0)
    {
      this.M.append('/');
      this._.A().A(paramInt);
      this._.B();
    }
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
  }

  public void gameStateChanged()
  {
  }

  public void gameOverEvent()
  {
    H();
    I.A();
  }

  public synchronized Action getAction()
  {
    if (E.Ú())
      throw new RuntimeException("AI Not Available");
    if (this.a.getNumPlayers() != 2)
    {
      this.X.K("ERROR: More than two players!");
      return Action.foldAction(this.a.getAmountToCall(this.V));
    }
    int i = this._.A(this.a, this.M.toString());
    boolean bool = false;
    if (this.a.isPostFlop())
      bool = HandEvaluator.isTheNuts(this.Z, this.Y, this.a.getBoard(), com.biotools.poker.D.G.A(this.a).ŷ());
    if (i == 2)
    {
      if ((this.a.getNumRaises() >= 4) && (!bool))
        i = 1;
    }
    else if ((bool) && (this.a.isRiver()) && (this.a.getNumToAct() == 1))
      i = 2;
    return Action.getAction(i, this.a.getAmountToCall(this.V), this.a.getCurrentBetSize());
  }

  public void H()
  {
    int i = this.a.nextPlayer(this.V);
    int j = (int)((this.a.getPlayer(this.V).getBankRoll() - this.L) / this.a.getBigBlindSize());
    Hand localHand = this.a.getPlayer(i).getRevealedHand();
    Card localCard1 = null;
    Card localCard2 = null;
    if (localHand != null)
    {
      localCard1 = localHand.getCard(1);
      localCard2 = localHand.getCard(2);
    }
    J localJ = new J(this.a, this.V, j, this.Z, this.Y, localCard1, localCard2, this.M.toString());
    if (!this.O)
      this.b.A(localJ);
    if (this.P)
      b.A(localJ + "\n", this.T);
  }

  public void dealHoleCardsEvent()
  {
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.C.G
 * JD-Core Version:    0.6.2
 */