package com.biotools.poker.N;

import com.biotools.A.W;
import com.biotools.A.b;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.Player;
import com.biotools.meerkat.util.NChoose2IntTable;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.D.G;
import com.biotools.poker.N.B.I;
import com.biotools.poker.N.B.J;
import com.biotools.poker.N.B.K;
import com.biotools.poker.N.D.B;

public class U
  implements Player
{
  protected int Ń;
  protected Card Ľ;
  protected Card ļ;
  protected GameInfo ł;
  protected Preferences Ņ;
  protected K Ŀ;
  protected I Ł;
  protected J Ļ;
  protected static W ń = W.A();
  protected static final com.biotools.poker.D.E ŀ = com.biotools.poker.D.E.G();
  protected boolean ĺ = false;
  protected double ľ = 0.3D;

  public void dealHoleCardsEvent()
  {
  }

  public void init(Preferences paramPreferences)
  {
    this.Ņ = paramPreferences;
  }

  public int ý()
  {
    return this.Ņ.getIntPreference("PREFLOP_TIGHTNESS", 1);
  }

  public boolean ÿ()
  {
    return this.Ņ.getBooleanPreference("USE_AIE", false);
  }

  public boolean Ā()
  {
    return this.Ņ.getBooleanPreference("USE_LOW_LIMIT_PREFLOP", false);
  }

  public boolean ú()
  {
    return this.Ņ.getBooleanPreference("USE_SSH_PREFLOP", false);
  }

  public void gameStateChanged()
  {
  }

  public boolean ü()
  {
    return false;
  }

  private boolean û()
  {
    return this.Ņ.getBooleanPreference("IMPLIED_ODDS", true);
  }

  public void T(String paramString)
  {
    if (ü())
      com.biotools.poker.E.H(paramString);
  }

  public void U(String paramString)
  {
    if (ü())
      com.biotools.poker.E.J(paramString);
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    this.ł = paramGameInfo;
  }

  public synchronized void holeCards(Card paramCard1, Card paramCard2, int paramInt)
  {
    this.Ľ = paramCard1;
    this.ļ = paramCard2;
    this.Ń = paramInt;
  }

  public void gameOverEvent()
  {
  }

  public void stageEvent(int paramInt)
  {
    this.ĺ = false;
  }

  public synchronized Action getAction()
  {
    Action localAction = null;
    if (this.ł.getStage() == 0)
      localAction = ù();
    else
      localAction = þ();
    return S.A(localAction, this.Ń, this.Ľ, this.ļ, this.ł);
  }

  private boolean L(double paramDouble)
  {
    double d1 = paramDouble * paramDouble;
    if (this.ł.getNumActivePlayers() == 2)
    {
      double d2 = this.ł.getCurrentBetSize() / this.ł.getMainPotSize();
      d1 += d2 * d2;
    }
    return ń.nextDouble() < d1;
  }

  public double B(int paramInt, Card paramCard1, Card paramCard2, NChoose2IntTable paramNChoose2IntTable)
  {
    double d = 1.0D;
    for (int i = 0; i < this.ł.getNumSeats(); i++)
      if ((this.ł.isActive(i)) && (i != paramInt))
        d *= ŀ.A(paramCard1, paramCard2, this.ł.getBoard(), paramNChoose2IntTable);
    return d;
  }

  public double C(int paramInt, Card paramCard1, Card paramCard2, NChoose2IntTable paramNChoose2IntTable)
  {
    double d = ŀ.A(paramCard1, paramCard2, this.ł.getBoard(), paramNChoose2IntTable);
    return Math.pow(d, this.ł.getNumActivePlayers() - 1);
  }

  private Action þ()
  {
    int i = this.ł.getNumActivePlayers();
    int j = this.ł.getNumToAct();
    double d1 = this.ł.getAmountToCall(this.Ń);
    double d2 = this.ł.getEligiblePot(this.Ń);
    double d3 = d1 / (d2 + d1);
    double d4 = d1 / (d2 + d1 * (this.ł.isFlop() ? 4 : 2));
    double d5 = C(this.Ń, this.Ľ, this.ļ, G.A(this.ł).ŷ());
    double d6 = 0.0D;
    if (this.ł.getStage() < 3)
      d6 = com.biotools.poker.D.A.A(this.Ľ, this.ļ, this.ł.getBoard());
    double d7 = 1.0D - (this.ł.getNumToAct() - 1) / (this.ł.getNumActivePlayers() - 1);
    if (û())
      d3 = d4;
    if (ÿ())
    {
      long l1 = System.currentTimeMillis();
      B localB = new B();
      double d9 = localB.B(this.Ń, this.Ľ, this.ļ, this.ł);
      long l2 = System.currentTimeMillis() - l1;
      d5 = d9;
    }
    T("\n | HRN = " + b.A(d5, 3) + " PPot = " + b.A(d6, 3) + " PO = " + b.A(d3, 3) + " PS = " + b.A(d7, 3));
    int k = 4 - this.ł.getStage();
    if (HandEvaluator.isTheNuts(this.Ľ, this.ļ, this.ł.getBoard(), G.A(this.ł).ŷ()))
      d5 = 1.0D;
    if (d5 == 1.0D)
    {
      T(" | DAH NUTZ!...");
      return Action.raiseAction(d1, this.ł.getCurrentBetSize());
    }
    double d8 = 0.75D + 0.25D * d7;
    if (this.ł.isRiver())
      d8 *= 0.9D;
    if (d1 == 0.0D)
    {
      if ((d5 > 0.9D) || (d8 * d5 * (d2 + this.ł.getStakes()) > 2.0D * this.ł.getStakes()))
      {
        if ((j >= 2) && (ń.nextDouble() < d5 * d5 * this.ľ))
        {
          this.ĺ = true;
          T(" | check raising...");
          return Action.checkAction();
        }
        T(" | strong bet...");
        return Action.betAction(this.ł.getCurrentBetSize());
      }
      if ((d8 * d5 * d2 > this.ł.getStakes()) && (ń.nextDouble() < d8 * d5))
      {
        T(" | weak bet...");
        return Action.betAction(this.ł.getCurrentBetSize());
      }
      if (L(d6))
      {
        T(" | bluffing...");
        return Action.betAction(this.ł.getCurrentBetSize());
      }
      T(" | checking...");
      return Action.checkAction();
    }
    if ((d5 > 0.95D) || (d8 * d5 * (d2 + d1) > d1 + 2.0D * this.ł.getStakes()))
    {
      if ((!this.ł.isRiver()) && (ń.nextDouble() < d5 * this.ľ))
      {
        T(" | slow playing...");
        return Action.callAction(d1);
      }
      if (ń.nextDouble() < Math.pow(d5, 2.0D + 0.15D * (this.ł.getNumActivePlayers() + 2 * this.ł.getNumRaises())))
      {
        T(" | strong raise...");
        return Action.raiseAction(d1, this.ł.getCurrentBetSize());
      }
    }
    if ((this.ł.getNumRaises() == 1) && (this.ĺ))
    {
      T(" | check raise...");
      return Action.raiseAction(d1, this.ł.getCurrentBetSize());
    }
    if (((this.ł.getNumRaises() == 1) || (i == 2)) && (L(d6)))
    {
      T(" | bluffing...");
      return Action.raiseAction(d1, this.ł.getCurrentBetSize());
    }
    if ((d5 * d5 * d2 > d1) || (d6 > d3))
    {
      T(" | calling...");
      return Action.callAction(d1);
    }
    if ((this.ł.getStage() == 3) && (i == 2) && (d5 * 0.5D * (d1 + d2) >= d1))
    {
      T(" | keeping honest...");
      return Action.callAction(d1);
    }
    T(" | folding...");
    return Action.foldAction(d1);
  }

  public synchronized Action ù()
  {
    int i = -1;
    U(" [" + this.Ľ.toString() + "-" + this.ļ.toString() + "] ");
    if (this.ł.getNumPlayers() == 2)
    {
      if (this.Ł == null)
        this.Ł = new I();
      i = this.Ł.A(this.Ľ, this.ļ, this.ł);
    }
    else if (Ā())
    {
      i = com.biotools.poker.N.B.A.B(this.Ľ, this.ļ, this.Ń, this.ł);
    }
    else if (ú())
    {
      if (this.Ļ == null)
        this.Ļ = new J();
      i = this.Ļ.A(this.Ľ, this.ļ, this.Ń, this.ł);
    }
    else
    {
      if (this.Ŀ == null)
        this.Ŀ = new K();
      this.Ŀ.A(ý());
      i = this.Ŀ.B(this.Ľ, this.ļ, this.ł);
    }
    double d = this.ł.getAmountToCall(this.Ń);
    return Action.getAction(i, d, this.ł.getCurrentBetSize());
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.U
 * JD-Core Version:    0.6.2
 */