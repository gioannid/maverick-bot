package com.biotools.poker.N;

import com.biotools.A.W;
import com.biotools.A.b;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.Player;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.meerkat.util.NChoose2IntTable;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.D.A;
import com.biotools.poker.D.G;
import com.biotools.poker.N.B.K;
import java.io.PrintStream;

public class R
  implements Player
{
  protected int º;
  protected Card ¤;
  protected Card ¢;
  protected GameInfo ª;
  protected Preferences Á;
  protected HandEvaluator £ = new HandEvaluator();
  protected A Â = new A();
  protected static W À = W.A();
  protected Deck µ = new Deck();
  protected static final com.biotools.poker.D.E ¥ = com.biotools.poker.D.E.G();

  public void init(Preferences paramPreferences)
  {
    this.Á = paramPreferences;
  }

  public int µ()
  {
    return this.Á.getIntPreference("PREFLOP_TIGHTNESS", 1);
  }

  public double £()
  {
    return this.Á.getDoublePreference("PREFLOP_POSITIONAL", 0.925D);
  }

  public double ¢()
  {
    return this.Á.getDoublePreference("PREFLOP_AGGRESSIVE", 0.925D);
  }

  public boolean ª()
  {
    return this.Á.getBooleanPreference("DEBUG", false);
  }

  public void L(String paramString)
  {
    com.biotools.poker.E.H(paramString);
  }

  public void dealHoleCardsEvent()
  {
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    this.ª = paramGameInfo;
  }

  public synchronized void holeCards(Card paramCard1, Card paramCard2, int paramInt)
  {
    if (paramCard1.getRank() >= paramCard2.getRank())
    {
      this.¤ = paramCard1;
      this.¢ = paramCard2;
    }
    else
    {
      this.¤ = paramCard2;
      this.¢ = paramCard1;
    }
    this.º = paramInt;
  }

  protected String À()
  {
    return this.ª.getPlayerName(this.º);
  }

  public void gameOverEvent()
  {
  }

  public void stageEvent(int paramInt)
  {
  }

  public synchronized Action getAction()
  {
    Action localAction = this.ª.isPreFlop() ? z() : º();
    double d = this.ª.getAmountToCall(this.º);
    if ((localAction.isFold()) && (d == 0.0D))
      localAction = Action.checkAction();
    else if ((localAction.isBetOrRaise()) && (!this.ª.canRaise(this.º)))
      localAction = Action.callAction(d);
    return localAction;
  }

  private boolean C(double paramDouble)
  {
    double d1 = paramDouble * paramDouble;
    if (this.ª.getNumActivePlayers() == 2)
    {
      double d2 = this.ª.getCurrentBetSize() / this.ª.getMainPotSize();
      d1 += d2 * d2;
    }
    return À.nextDouble() < d1;
  }

  public double A(int paramInt, com.biotools.poker.D.E paramE, Card paramCard1, Card paramCard2, NChoose2IntTable paramNChoose2IntTable)
  {
    double d = 1.0D;
    for (int i = 0; i < this.ª.getNumSeats(); i++)
      if ((this.ª.isActive(i)) && (i != paramInt))
        d *= paramE.A(paramCard1, paramCard2, this.ª.getBoard(), paramNChoose2IntTable);
    return d;
  }

  public double A(int paramInt, Card paramCard1, Card paramCard2, NChoose2IntTable paramNChoose2IntTable)
  {
    G localG = G.A(this.ª);
    double d1 = 1.0D;
    this.µ.reset();
    this.µ.extractCard(paramCard1);
    this.µ.extractCard(paramCard2);
    this.µ.extractHand(this.ª.getBoard());
    for (int i = 0; i < this.ª.getNumSeats(); i++)
      if ((this.ª.isActive(i)) && (i != paramInt))
      {
        double d2 = localG.Q(i).C(paramCard1, paramCard2, this.µ);
        if (Double.isNaN(d2))
        {
          com.biotools.poker.E.H(" *** NAN HS FROM SEAT" + i + " ***");
          d2 = ¥.A(paramCard1, paramCard2, this.ª.getBoard(), paramNChoose2IntTable);
        }
        d1 *= d2;
      }
    return d1;
  }

  protected Action º()
  {
    int i = this.ª.getNumActivePlayers();
    int j = this.ª.getNumToAct();
    double d1 = this.ª.getAmountToCall(this.º);
    double d2 = this.ª.getMainPotSize();
    double d3 = d1 / (d2 + d1);
    double d4 = this.ª.getPlayer(this.º).getBankRollAtRisk();
    double d5 = A(this.º, ¥, this.¤, this.¢, G.A(this.ª).ŷ());
    double d6 = A(this.º, this.¤, this.¢, G.A(this.ª).ŷ());
    if (HandEvaluator.isTheNuts(this.¤, this.¢, this.ª.getBoard(), G.A(this.ª).ŷ()))
      d6 = d5 = 1.0D;
    double d7 = 0.0D;
    double d8 = 0.0D;
    if (!this.ª.isRiver())
      if (this.ª.isZipMode())
      {
        d7 = A.A(this.¤, this.¢, this.ª.getBoard());
      }
      else
      {
        double[] arrayOfDouble = A.B(this.¤, this.¢, this.ª.getBoard(), ¥);
        d7 = arrayOfDouble[0];
        d8 = arrayOfDouble[1];
        if ((d1 == d4) && (this.ª.isFlop()))
        {
          A localA = new A();
          localA.A(this.¤, this.¢, this.ª.getBoard(), ¥, true);
          d7 = localA.B();
          d8 = localA.A();
          com.biotools.poker.E.H("Full PPOT: " + d7);
        }
      }
    double d9 = 1.0D - (this.ª.getNumToAct() - 1) / (this.ª.getNumActivePlayers() - 1);
    L(this.¤ + "-" + this.¢ + " | HRN = " + b.A(d5, 3) + " HSN = " + b.A(d6, 3) + " PPot = " + b.A(d7, 3) + " PO = " + b.A(d3, 3) + " PS = " + b.A(d9, 3));
    int k = 4 - this.ª.getStage();
    return B(d6 + (1.0D - d6) * d7, d7);
  }

  protected Action z()
  {
    double d1 = K.B(this.¤, this.¢, this.ª.getNumPlayers());
    double d2 = 1.0D / this.ª.getNumPlayers();
    for (int i = 0; i < this.ª.getNumToAct() - 1; i++)
      d2 *= £();
    for (i = 0; i < this.ª.getNumRaises(); i++)
      d2 *= ¢();
    System.out.println(this.¤ + "-" + this.¢ + ": HR=" + b.A(d1, 3) + ", " + b.A(d2, 3));
    double d3 = this.ª.getAmountToCall(this.º);
    double d4 = this.ª.getPlayer(this.º).getBankRoll();
    if (d3 > d4)
      d3 = d4;
    double d5 = this.ª.getEligiblePot(this.º);
    double d6 = 0.0D;
    int j = 0;
    double d7 = d3 / (d5 + d3);
    if (d7 < 0.05D)
      j = 1;
    else if ((d4 < this.ª.getBigBlindSize() * 6.0D) && (d7 < 0.1D))
      j = 1;
    double d8 = d4 / (d5 + d4);
    if (d8 < 0.1D)
      j = 1;
    if (d1 > 1.0D - d2)
    {
      if (d1 > 1.0D - d2 / 2.0D)
      {
        if ((Math.random() < d2) || (this.ª.getNumRaises() > 1))
          d6 = d4 - d3;
      }
      else if (Math.random() < d2 / 2.0D)
        d6 = d4 - d3;
      if (Math.random() > d3 / d5)
      {
        d6 = this.ª.getMinRaise() * 3.0D;
        do
        {
          d6 += this.ª.getMinRaise();
          if (Math.random() <= d3 / d5)
            break;
        }
        while (d6 < d4 - d3);
      }
    }
    else if (d1 > 1.0D - d2 * 2.0D)
    {
      if ((Math.random() < d2 / 2.0D) && (d3 < this.ª.getSmallBlindSize() * 10.0D))
        d6 = d4 - d3;
      if (Math.random() > d3 / d5)
        for (d6 = this.ª.getMinRaise() * 3.0D; (Math.random() < d1) && (d6 < d4 - d3) && (Math.random() > d3 / d5); d6 += this.ª.getMinRaise());
      if ((d3 > d4 / 10.0D) && (j == 0))
        return Action.foldAction(d3);
    }
    else if (d1 > 1.0D - d2 * 3.0D)
    {
      if ((Math.random() < d2 / 3.0D) && (d3 < this.ª.getSmallBlindSize() * 6.0D))
        d6 = d4 - d3;
      if ((d3 > this.ª.getSmallBlindSize() * 6.0D) && (j == 0))
        return Action.foldAction(d3);
    }
    else if (d1 > 1.0D - d2 * 4.0D)
    {
      if ((d3 > this.ª.getSmallBlindSize() * 4.0D) && (this.¤.getRank() != this.¢.getRank()) && (j == 0))
        return Action.foldAction(d3);
    }
    else if (this.¤.getRank() == this.¢.getRank())
    {
      if ((d3 > this.ª.getSmallBlindSize() * 6.0D) && (j == 0))
        return Action.foldAction(d3);
    }
    else if (j == 0)
    {
      return Action.foldAction(d3);
    }
    if (d6 + d3 > d4 / 1.5D)
      d6 = d4 - d3;
    if (d6 == 0.0D)
      return Action.callAction(d3);
    return D(d6);
  }

  private com.biotools.poker.L.B D(int paramInt)
  {
    int i = this.ª.getNumActivePlayers();
    if (i < 2)
      i = 2;
    Hand[] arrayOfHand = new Hand[i];
    arrayOfHand[0] = new Hand();
    arrayOfHand[0].addCard(this.¤);
    arrayOfHand[0].addCard(this.¢);
    for (int j = 1; j < i; j++)
    {
      arrayOfHand[j] = new Hand();
      arrayOfHand[j].addCard(new Card());
      arrayOfHand[j].addCard(new Card());
    }
    com.biotools.poker.L.B localB = new com.biotools.poker.L.B(this.ª.getBoard(), arrayOfHand);
    localB.G(paramInt);
    localB.D();
    return localB;
  }

  public Action B(double paramDouble1, double paramDouble2)
  {
    double d1 = this.ª.getAmountToCall(this.º);
    double d2 = this.ª.getPlayer(this.º).getBankRoll();
    if (d1 > d2)
      d1 = d2;
    double d3 = this.ª.getPlayer(this.º).getBankRollAtRisk();
    double d4 = this.ª.getEligiblePot(this.º);
    if (this.ª.getStage() == 0)
      d4 += this.ª.getBigBlindSize() * this.ª.getNumActivePlayers();
    double d5 = 1.0D / this.ª.getNumActivePlayers();
    double d6 = 0.5D;
    for (int i = 0; i < this.ª.getNumToAct() - 1; i++)
      d5 *= 0.95D;
    for (i = 0; i < this.ª.getNumActivePlayers() - 1; i++)
      d6 *= 1.05D;
    double d7 = 0.0D;
    double[] arrayOfDouble;
    if (paramDouble1 > 0.95D)
    {
      arrayOfDouble = new double[] { 0.2D, 0.05D, 0.1D, 0.15D, 0.15D, 0.15D, 0.2D };
      d7 = A(arrayOfDouble, d4, d2);
      if (d1 >= d7)
        return ¤();
      if ((d1 > 0.0D) && (d7 - d1 < this.ª.getMinRaise()))
        return D(d2 - d1);
      return D(d7 - d1);
    }
    if (paramDouble1 > 0.9D)
    {
      arrayOfDouble = new double[] { 0.1D, 0.1D, 0.25D, 0.25D, 0.2D, 0.05D, 0.05D };
      d7 = A(arrayOfDouble, d4, d2);
      if (d1 >= d7)
        return ¤();
      return D(d7 - d1);
    }
    if (paramDouble1 > 0.85D)
    {
      arrayOfDouble = new double[] { 0.05D, 0.1D, 0.25D, 0.35D, 0.2D, 0.025D, 0.025D };
      d7 = A(arrayOfDouble, d4, d2);
      if (d1 > d7)
      {
        if (this.ª.getStage() == 3)
        {
          if ((d1 < d2 / 2.0D) || (d1 < d4))
            return ¥();
          return ¥();
        }
        if ((d1 < d2 / 3.0D) || (d1 < d4))
          return ¤();
        return ¥();
      }
      if ((d1 > this.ª.getSmallBlindSize() * 6.0D) && (d7 - d1 < this.ª.getMinRaise()))
        return ¥();
      return D(d7 - d1);
    }
    if (paramDouble1 > 0.8D)
    {
      arrayOfDouble = new double[] { 0.1D, 0.1D, 0.35D, 0.3D, 0.1D, 0.025D, 0.025D };
      d7 = A(arrayOfDouble, d4, d2);
      if (d1 > d7)
      {
        if ((d1 < d2 / 4.0D) || (d1 < d4 / 2.0D))
          return ¤();
        return ¥();
      }
      if ((d1 > this.ª.getSmallBlindSize() * 4.0D) && (d7 - d1 < this.ª.getMinRaise()))
        return ¥();
      return D(d7 - d1);
    }
    if (paramDouble1 > 0.7D)
    {
      arrayOfDouble = new double[] { 0.1D, 0.225D, 0.3D, 0.3D, 0.04D, 0.025D, 0.01D };
      d7 = A(arrayOfDouble, d4, d2);
      if (d1 > d7)
        return ¥();
      if ((d1 > this.ª.getSmallBlindSize() * 4.0D) && (d7 - d1 < this.ª.getMinRaise()))
      {
        if (((d1 <= d4) && (d1 < d2 / 4.0D)) || (d1 < d4 / 3.0D))
          return ¤();
        return ¥();
      }
      return D(d7 - d1);
    }
    if (paramDouble1 > 0.6D)
    {
      arrayOfDouble = new double[] { 0.23D, 0.35D, 0.45D, 0.2D, 0.05D, 0.01D, 0.01D };
      d7 = A(arrayOfDouble, d4, d2);
      if (d1 > d7)
        return ¥();
      if ((d1 > 0.0D) && (d7 - d1 < this.ª.getMinRaise()))
      {
        if (((d1 <= d4 / 2.0D) && (d1 < d2 / 4.0D)) || (d1 < d4 / 5.0D))
          return ¤();
        return ¥();
      }
      return D(d7 - d1);
    }
    if (paramDouble1 > 0.5D)
    {
      arrayOfDouble = new double[] { 0.3D, 0.25D, 0.4D, 0.025D, 0.0D, 0.0D, 0.025D };
      d7 = A(arrayOfDouble, d4, d2);
      if (d1 > d7)
        return ¥();
      if ((d1 > 0.0D) && (d7 - d1 < this.ª.getMinRaise()))
      {
        if ((d1 < d4 / 2.0D) && (d1 < d2 / 6.0D))
          return ¤();
        return ¥();
      }
      return D(d7 - d1);
    }
    if (paramDouble1 < 0.075D)
    {
      arrayOfDouble = new double[] { 0.9D, 0.0D, 0.0D, 0.0D, 0.025D, 0.025D, 0.05D };
      d7 = A(arrayOfDouble, d4, d2);
      if (d1 > d7)
        return ¥();
      if ((d1 > 0.0D) && (d7 - d1 < this.ª.getMinRaise()))
        return ¥();
      return D(d7 - d1);
    }
    if ((paramDouble2 > d1 / (d4 + d1)) || (d1 == 0.0D))
      return ¤();
    return ¥();
  }

  private double A(double[] paramArrayOfDouble, double paramDouble1, double paramDouble2)
  {
    double d1 = 0.0D;
    double d2 = Math.random();
    if (d2 < paramArrayOfDouble[0])
      d1 = 0.0D;
    if (d2 < paramArrayOfDouble[0] + paramArrayOfDouble[1])
      d1 = this.ª.getMinRaise();
    else if (d2 < paramArrayOfDouble[0] + paramArrayOfDouble[1] + paramArrayOfDouble[2])
      d1 = this.ª.getMinRaise() * 3.0D;
    else if (d2 < paramArrayOfDouble[0] + paramArrayOfDouble[1] + paramArrayOfDouble[2] + paramArrayOfDouble[3])
      d1 = paramDouble1 / 2.0D;
    else if (d2 < paramArrayOfDouble[0] + paramArrayOfDouble[1] + paramArrayOfDouble[2] + paramArrayOfDouble[3] + paramArrayOfDouble[4])
      d1 = paramDouble1;
    else if (d2 < paramArrayOfDouble[0] + paramArrayOfDouble[1] + paramArrayOfDouble[2] + paramArrayOfDouble[3] + paramArrayOfDouble[4] + paramArrayOfDouble[5])
      d1 = paramDouble1 * 2.0D;
    else
      d1 = paramDouble2;
    if (d1 * 2.0D + paramDouble1 > paramDouble2 - d1)
      d1 = paramDouble2;
    return d1;
  }

  protected Action ¤()
  {
    return Action.callAction(this.ª.getAmountToCall(this.º));
  }

  protected Action ¥()
  {
    return Action.foldAction(this.ª.getAmountToCall(this.º));
  }

  protected Action D(double paramDouble)
  {
    double d1 = this.ª.getPlayer(this.º).getBankRoll();
    double d2 = this.ª.getAmountToCall(this.º);
    if (d2 >= d1)
      return ¤();
    if ((paramDouble + d2 < d1) && (paramDouble % this.ª.getSmallBlindSize() != 0.0D))
      paramDouble = this.ª.getSmallBlindSize() * (int)((paramDouble + this.ª.getSmallBlindSize()) / this.ª.getSmallBlindSize());
    if (paramDouble < this.ª.getMinRaise())
      paramDouble = this.ª.getMinRaise();
    if (paramDouble + d2 > d1 * 0.5D)
      paramDouble = d1;
    if (paramDouble + d2 > d1)
      paramDouble = d1 - d2;
    return Action.raiseAction(d2, paramDouble);
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
  }

  public void gameStateChanged()
  {
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.R
 * JD-Core Version:    0.6.2
 */