package com.biotools.poker.N.D;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.util.NChoose2IntTable;
import com.biotools.poker.D.E;
import com.biotools.poker.D.G;

public class B
{
  private NChoose2IntTable D;
  private int[][] C;
  private double[] B;
  private E[] A;
  private double F = 0.0D;
  private double E = 0.0D;

  private void A(int paramInt, GameInfo paramGameInfo)
  {
    int i = paramGameInfo.getNumActivePlayers() - 1;
    G localG = G.A(paramGameInfo);
    this.C = new int[i][2];
    this.B = new double[i];
    this.A = new E[i];
    int j = 0;
    for (int k = 0; (k < paramGameInfo.getNumSeats()) && (j < i); k++)
      if ((k != paramInt) && (paramGameInfo.isActive(k)))
      {
        this.A[j] = localG.Q(k).Ŧ();
        this.B[j] = this.A[j].E();
        j++;
      }
  }

  public void A(E paramE, int paramInt)
  {
    this.C = new int[paramInt][2];
    this.B = new double[paramInt];
    this.A = new E[paramInt];
    double d = paramE.E();
    for (int i = 0; i < paramInt; i++)
    {
      this.A[i] = paramE;
      this.B[i] = d;
    }
  }

  public double A(int paramInt, E paramE, Card paramCard1, Card paramCard2, Hand paramHand)
  {
    A(paramE, paramInt);
    return A(paramInt, paramCard1, paramCard2, paramHand);
  }

  public double B(int paramInt, Card paramCard1, Card paramCard2, GameInfo paramGameInfo)
  {
    int i = paramGameInfo.getNumActivePlayers() - 1;
    if ((i <= 0) || (!paramGameInfo.isActive(paramInt)))
      return -1.0D;
    A(paramInt, paramGameInfo);
    if (paramGameInfo.isPreFlop())
      return A(i, paramCard1, paramCard2, paramGameInfo.getBoard());
    return A(i, paramCard1, paramCard2, paramGameInfo);
  }

  public double A(int paramInt, Card paramCard1, Card paramCard2, GameInfo paramGameInfo)
  {
    this.E = (this.F = 0.0D);
    int i = 30000;
    int j = 500;
    Hand localHand1 = paramGameInfo.getBoard();
    Deck localDeck1 = new Deck();
    Deck localDeck2 = new Deck();
    localDeck1.extractCard(paramCard1);
    localDeck1.extractCard(paramCard2);
    localDeck1.extractHand(localHand1);
    int k = 5 - localHand1.size();
    int m = 0;
    int n = 0;
    while (m == 0)
    {
      Hand localHand2 = new Hand();
      for (int i1 = 0; i1 < k; i1++)
      {
        int i2 = localDeck1.dealCard().getIndex();
        localHand1.addCard(i2);
        localHand2.addCard(i2);
      }
      localHand2.sort();
      this.D = G.A(paramGameInfo).A(localHand1, localHand2.toString());
      for (i1 = 0; i1 < j; i1++)
      {
        localDeck2.copy(localDeck1);
        double d = 1.0D;
        for (int i3 = 0; i3 < paramInt; i3++)
        {
          this.C[i3][0] = localDeck2.dealCard().getIndex();
          this.C[i3][1] = localDeck2.dealCard().getIndex();
          d *= this.A[i3].C(this.C[i3][0], this.C[i3][1]) / this.B[i3];
        }
        this.F += d * B(paramCard1.getIndex(), paramCard2.getIndex(), localHand1);
        this.E += d;
        n++;
      }
      for (i1 = 0; i1 < k; i1++)
      {
        localDeck1.replaceCard(localHand1.getLastCardIndex());
        localHand1.removeCard();
      }
      if (n > i)
        m = 1;
    }
    return this.F / this.E;
  }

  public double A()
  {
    return this.F / this.E;
  }

  private double A(int paramInt, Card paramCard1, Card paramCard2, Hand paramHand)
  {
    int i = 12500;
    this.F = 0.0D;
    this.E = 0.0D;
    Hand localHand = paramHand;
    Deck localDeck1 = new Deck();
    localDeck1.extractCard(paramCard1);
    localDeck1.extractCard(paramCard2);
    localDeck1.extractHand(localHand);
    Deck localDeck2 = new Deck();
    this.D = null;
    int j = 5 - localHand.size();
    int k = 0;
    int m = 0;
    while (k == 0)
    {
      localDeck2.copy(localDeck1);
      for (int n = 0; n < j; n++)
      {
        int i1 = localDeck2.dealCard().getIndex();
        localHand.addCard(i1);
      }
      double d = 1.0D;
      for (int i2 = 0; i2 < paramInt; i2++)
      {
        this.C[i2][0] = localDeck2.dealCard().getIndex();
        this.C[i2][1] = localDeck2.dealCard().getIndex();
        d *= this.A[i2].C(this.C[i2][0], this.C[i2][1]) / this.B[i2];
      }
      this.F += d * B(paramCard1.getIndex(), paramCard2.getIndex(), localHand);
      this.E += d;
      m++;
      for (i2 = 0; i2 < j; i2++)
        localHand.removeCard();
      if (m > i)
        k = 1;
    }
    return this.F / this.E;
  }

  protected final double B(int paramInt1, int paramInt2, Hand paramHand)
  {
    int i = 0;
    int j = A(paramInt1, paramInt2, paramHand);
    for (int k = 0; k < this.C.length; k++)
    {
      int m = A(this.C[k][0], this.C[k][1], paramHand);
      if (m > j)
        return 0.0D;
      if (m == j)
        i++;
    }
    return 1.0D / (i + 1);
  }

  protected final int A(int paramInt1, int paramInt2, Hand paramHand)
  {
    if (this.D != null)
      return this.D.get(paramInt1, paramInt2);
    return HandEvaluator.rankHand(paramInt1, paramInt2, paramHand);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.D.B
 * JD-Core Version:    0.6.2
 */