package com.biotools.poker.N;

public class C
{
  public static void A()
  {
    com.biotools.poker.E.F localF = com.biotools.poker.E.B.L();
    localF.put("com/biotools/poker/opponent/OptiOpponent", J.class);
    localF.put("com/biotools/poker/opponent/MiximaxOpponent", A.class);
    localF.put("com/biotools/poker/opponent/PokiOpponent", D.class);
    localF.put("com/biotools/poker/opponent/PokiSimOpponent", E.class);
    localF.put("com/biotools/poker/opponent/JagOpponent", V.class);
    localF.put("com/biotools/poker/opponent/NLOpponent", F.class);
    localF.put("com/biotools/poker/opponent/DPSOpponent", Z.class);
    localF.put("com/biotools/poker/opponent/SklanskyOpponent", M.class);
    localF.put("com/biotools/poker/opponent/AveryBot", K.class);
    localF.put("com/biotools/poker/opponent/Sigmind", O.class);
    localF.put("com/biotools/poker/opponent/HybridOpponent", B.class);
    localF.put("OptiOpponent", J.class);
    localF.put("MiximaxOpponent", A.class);
    localF.put("PokiOpponent", D.class);
    localF.put("PokiSimOpponent", E.class);
    localF.put("JagOpponent", V.class);
    localF.put("NLOpponent", F.class);
    localF.put("DPSOpponent", Z.class);
    localF.put("SklanskyOpponent", M.class);
    localF.put("AveryBot", K.class);
    localF.put("Sigmind", O.class);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.C
 * JD-Core Version:    0.6.2
 */