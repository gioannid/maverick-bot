package com.biotools.poker.N.B;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.poker.D.C;

public class K
{
  public static final double G = 0.6D;
  public static final String[] O = { "TIGHT", "MODERATE", "LOOSE" };
  public static final int I = 0;
  public static final int D = 1;
  public static final int A = 2;
  public static final int H = 110;
  public static final int F = 300;
  private int M = 0;
  private static int[][][][] B = { { { { 0, 70 }, { 450, 50 }, { 900 } }, { { 0, 30 }, { 450, 10 }, { 900 } }, { { -100, 10 }, { 450, 10 }, { 900 } } }, { { { 50, 50 }, { 200, 50 }, { 580 } }, { { 50, 10 }, { 200, 10 }, { 580 } }, { { -100, 10 }, { 200, 10 }, { 580 } } }, { { { -50, 50 }, { 150, 50 }, { 300 } }, { { -50, 50 }, new int[2], { 300 } }, { { -50, 50 }, new int[2], { 300 } } } };
  private int E = 0;
  static int[][] N = { { 7, -351, -334, -314, -318, -308, -264, -217, -166, -113, -53, 10, 98 }, { -279, 74, -296, -274, -277, -267, -251, -201, -148, -93, -35, 27, 116 }, { -263, -225, 142, -236, -240, -231, -209, -185, -130, -75, -17, 46, 134 }, { -244, -206, -169, 207, -201, -189, -169, -148, -114, -55, 2, 68, 153 }, { -247, -208, -171, -138, 264, -153, -134, -108, -78, -43, 19, 85, 154 }, { -236, -200, -162, -125, -91, 324, -99, -72, -43, -6, 37, 104, 176 }, { -192, -182, -143, -108, -75, -43, 384, -39, -4, 29, 72, 120, 197 }, { -152, -134, -122, -84, -50, -17, 16, 440, 28, 65, 106, 155, 215 }, { -104, -86, -69, -56, -19, 12, 47, 81, 499, 102, 146, 195, 254 }, { -52, -35, -19, 0, 11, 46, 79, 113, 149, 549, 161, 212, 271 }, { 2, 21, 34, 55, 72, 86, 121, 153, 188, 204, 598, 228, 289 }, { 63, 79, 98, 116, 132, 151, 168, 200, 235, 249, 268, 647, 305 }, { 146, 164, 180, 198, 198, 220, 240, 257, 291, 305, 323, 339, 704 } };
  static int[][] K = { { -121, -440, -409, -382, -411, -432, -394, -357, -301, -259, -194, -116, 16 }, { -271, -42, -345, -312, -340, -358, -371, -328, -277, -231, -165, -87, 54 }, { -245, -183, 52, -246, -269, -287, -300, -308, -252, -204, -135, -55, 84 }, { -219, -151, -91, 152, -200, -211, -227, -236, -227, -169, -104, -24, 118 }, { -247, -177, -113, -52, 256, -145, -152, -158, -152, -145, -74, 9, 99 }, { -261, -201, -129, -65, 3, 376, -76, -79, -68, -66, -44, 48, 148 }, { -226, -204, -140, -73, -2, 66, 503, 0, 15, 24, 45, 84, 194 }, { -191, -166, -147, -79, -5, 68, 138, 647, 104, 113, 136, 177, 241 }, { -141, -116, -91, -69, -4, 75, 150, 235, 806, 226, 255, 295, 354 }, { -89, -67, -41, -12, 7, 82, 163, 248, 349, 965, 301, 348, 410 }, { -29, -3, 22, 51, 80, 108, 185, 274, 379, 423, 1141, 403, 473 }, { 47, 76, 101, 128, 161, 199, 230, 318, 425, 473, 529, 1325, 541 }, { 175, 211, 237, 266, 249, 295, 338, 381, 491, 539, 594, 655, 1554 } };
  static int[][] J = { { -6, -462, -422, -397, -459, -495, -469, -433, -383, -336, -274, -188, -39 }, { -180, 21, -347, -304, -365, -418, -447, -414, -356, -308, -248, -163, -1 }, { -148, -69, 67, -227, -273, -323, -362, -391, -334, -287, -223, -133, 32 }, { -121, -38, 31, 122, -198, -230, -270, -303, -309, -259, -200, -103, 64 }, { -174, -95, -10, 64, 206, -151, -175, -204, -217, -235, -164, -72, 23 }, { -208, -135, -47, 35, 108, 298, -87, -106, -112, -128, -124, -26, 72 }, { -184, -164, -83, 2, 93, 168, 420, -5, 6, -10, -10, 22, 126 }, { -146, -128, -111, -26, 64, 153, 245, 565, 134, 118, 118, 151, 189 }, { -88, -68, -46, -29, 59, 155, 268, 383, 765, 299, 305, 336, 373 }, { -38, -15, 1, 30, 51, 147, 256, 377, 536, 996, 380, 420, 462 }, { 35, 49, 72, 99, 127, 162, 268, 384, 553, 628, 1279, 529, 574 }, { 117, 141, 167, 190, 223, 261, 304, 423, 591, 669, 764, 1621, 712 }, { 269, 304, 333, 363, 313, 365, 416, 475, 644, 720, 815, 934, 2043 } };
  private static final int P = 50;
  private static final int L = 100;
  public static int[] C = { 2043, 2043, 2043, 2043, 2043, 2043, 1621, 1621, 1621, 1621, 1621, 1621, 1279, 1279, 1279, 1279, 1279, 1279, 996, 996, 996, 996, 996, 996, 934, 934, 934, 934, 815, 815, 815, 815, 765, 765, 765, 765, 765, 765, 764, 764, 764, 764, 720, 720, 720, 720, 712, 712, 712, 712, 712, 712, 712, 712, 712, 712, 712, 712, 669, 669, 669, 669, 644, 644, 644, 644, 628, 628, 628, 628, 591, 591, 591, 591, 574, 574, 574, 574, 574, 574, 574, 574, 574, 574, 574, 574, 565, 565, 565, 565, 565, 565, 553, 553, 553, 553, 536, 536, 536, 536, 529, 529, 529, 529, 529, 529, 529, 529, 529, 529, 529, 529, 475, 475, 475, 475, 462, 462, 462, 462, 462, 462, 462, 462, 462, 462, 462, 462, 423, 423, 423, 423, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 420, 416, 416, 416, 416, 384, 384, 384, 384, 383, 383, 383, 383, 380, 380, 380, 380, 380, 380, 380, 380, 380, 380, 380, 380, 377, 377, 377, 377, 373, 373, 373, 373, 373, 373, 373, 373, 373, 373, 373, 373, 365, 365, 365, 365, 363, 363, 363, 363, 336, 336, 336, 336, 336, 336, 336, 336, 336, 336, 336, 336, 333, 333, 333, 333, 313, 313, 313, 313, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 305, 304, 304, 304, 304, 304, 304, 304, 304, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 299, 298, 298, 298, 298, 298, 298, 269, 269, 269, 269, 268, 268, 268, 268, 268, 268, 268, 268, 261, 261, 261, 261, 256, 256, 256, 256, 245, 245, 245, 245, 223, 223, 223, 223, 206, 206, 206, 206, 206, 206, 190, 190, 190, 190, 189, 189, 189, 189, 189, 189, 189, 189, 189, 189, 189, 189, 168, 168, 168, 168, 167, 167, 167, 167, 162, 162, 162, 162, 155, 155, 155, 155, 153, 153, 153, 153, 151, 151, 151, 151, 151, 151, 151, 151, 151, 151, 151, 151, 147, 147, 147, 147, 141, 141, 141, 141, 134, 134, 134, 134, 134, 134, 134, 134, 134, 134, 134, 134, 127, 127, 127, 127, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 122, 122, 122, 122, 122, 122, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 118, 117, 117, 117, 117, 108, 108, 108, 108, 99, 99, 99, 99, 93, 93, 93, 93, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 72, 67, 67, 67, 67, 67, 67, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 59, 59, 59, 59, 51, 51, 51, 51, 49, 49, 49, 49, 35, 35, 35, 35, 35, 35, 35, 35, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 31, 31, 31, 31, 30, 30, 30, 30, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 21, 21, 21, 21, 21, 21, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 2, 2, 2, 2, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -6, -6, -6, -6, -6, -6, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -10, -15, -15, -15, -15, -26, -26, -26, -26, -26, -26, -26, -26, -26, -26, -26, -26, -26, -26, -26, -26, -29, -29, -29, -29, -38, -38, -38, -38, -38, -38, -38, -38, -39, -39, -39, -39, -39, -39, -39, -39, -39, -39, -39, -39, -46, -46, -46, -46, -47, -47, -47, -47, -68, -68, -68, -68, -69, -69, -69, -69, -72, -72, -72, -72, -72, -72, -72, -72, -72, -72, -72, -72, -83, -83, -83, -83, -87, -87, -87, -87, -87, -87, -87, -87, -87, -87, -87, -87, -88, -88, -88, -88, -95, -95, -95, -95, -103, -103, -103, -103, -103, -103, -103, -103, -103, -103, -103, -103, -106, -106, -106, -106, -106, -106, -106, -106, -106, -106, -106, -106, -111, -111, -111, -111, -112, -112, -112, -112, -112, -112, -112, -112, -112, -112, -112, -112, -121, -121, -121, -121, -124, -124, -124, -124, -124, -124, -124, -124, -124, -124, -124, -124, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -133, -133, -133, -133, -133, -133, -133, -133, -133, -133, -133, -133, -135, -135, -135, -135, -146, -146, -146, -146, -148, -148, -148, -148, -151, -151, -151, -151, -151, -151, -151, -151, -151, -151, -151, -151, -163, -163, -163, -163, -163, -163, -163, -163, -163, -163, -163, -163, -164, -164, -164, -164, -164, -164, -164, -164, -164, -164, -164, -164, -164, -164, -164, -164, -174, -174, -174, -174, -175, -175, -175, -175, -175, -175, -175, -175, -175, -175, -175, -175, -180, -180, -180, -180, -184, -184, -184, -184, -188, -188, -188, -188, -188, -188, -188, -188, -188, -188, -188, -188, -198, -198, -198, -198, -198, -198, -198, -198, -198, -198, -198, -198, -200, -200, -200, -200, -200, -200, -200, -200, -200, -200, -200, -200, -204, -204, -204, -204, -204, -204, -204, -204, -204, -204, -204, -204, -208, -208, -208, -208, -217, -217, -217, -217, -217, -217, -217, -217, -217, -217, -217, -217, -223, -223, -223, -223, -223, -223, -223, -223, -223, -223, -223, -223, -227, -227, -227, -227, -227, -227, -227, -227, -227, -227, -227, -227, -230, -230, -230, -230, -230, -230, -230, -230, -230, -230, -230, -230, -235, -235, -235, -235, -235, -235, -235, -235, -235, -235, -235, -235, -248, -248, -248, -248, -248, -248, -248, -248, -248, -248, -248, -248, -259, -259, -259, -259, -259, -259, -259, -259, -259, -259, -259, -259, -270, -270, -270, -270, -270, -270, -270, -270, -270, -270, -270, -270, -273, -273, -273, -273, -273, -273, -273, -273, -273, -273, -273, -273, -274, -274, -274, -274, -274, -274, -274, -274, -274, -274, -274, -274, -287, -287, -287, -287, -287, -287, -287, -287, -287, -287, -287, -287, -303, -303, -303, -303, -303, -303, -303, -303, -303, -303, -303, -303, -304, -304, -304, -304, -304, -304, -304, -304, -304, -304, -304, -304, -308, -308, -308, -308, -308, -308, -308, -308, -308, -308, -308, -308, -309, -309, -309, -309, -309, -309, -309, -309, -309, -309, -309, -309, -323, -323, -323, -323, -323, -323, -323, -323, -323, -323, -323, -323, -334, -334, -334, -334, -334, -334, -334, -334, -334, -334, -334, -334, -336, -336, -336, -336, -336, -336, -336, -336, -336, -336, -336, -336, -347, -347, -347, -347, -347, -347, -347, -347, -347, -347, -347, -347, -356, -356, -356, -356, -356, -356, -356, -356, -356, -356, -356, -356, -362, -362, -362, -362, -362, -362, -362, -362, -362, -362, -362, -362, -365, -365, -365, -365, -365, -365, -365, -365, -365, -365, -365, -365, -383, -383, -383, -383, -383, -383, -383, -383, -383, -383, -383, -383, -391, -391, -391, -391, -391, -391, -391, -391, -391, -391, -391, -391, -397, -397, -397, -397, -397, -397, -397, -397, -397, -397, -397, -397, -414, -414, -414, -414, -414, -414, -414, -414, -414, -414, -414, -414, -418, -418, -418, -418, -418, -418, -418, -418, -418, -418, -418, -418, -422, -422, -422, -422, -422, -422, -422, -422, -422, -422, -422, -422, -433, -433, -433, -433, -433, -433, -433, -433, -433, -433, -433, -433, -447, -447, -447, -447, -447, -447, -447, -447, -447, -447, -447, -447, -459, -459, -459, -459, -459, -459, -459, -459, -459, -459, -459, -459, -462, -462, -462, -462, -462, -462, -462, -462, -462, -462, -462, -462, -469, -469, -469, -469, -469, -469, -469, -469, -469, -469, -469, -469, -495, -495, -495, -495, -495, -495, -495, -495, -495, -495, -495, -495 };

  public static int A(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3)
  {
    if (paramInt2 > paramInt1)
    {
      int i = paramInt1;
      paramInt1 = paramInt2;
      paramInt2 = i;
    }
    switch (paramInt3)
    {
    case 2:
      return paramBoolean ? N[paramInt1][paramInt2] : N[paramInt2][paramInt1];
    case 4:
      return paramBoolean ? K[paramInt1][paramInt2] : K[paramInt2][paramInt1];
    case 7:
      return paramBoolean ? J[paramInt1][paramInt2] : J[paramInt2][paramInt1];
    case 3:
    case 5:
    case 6:
    }
    return 0;
  }

  public static int A(int paramInt1, int paramInt2, boolean paramBoolean, int[][] paramArrayOfInt)
  {
    if (paramInt2 > paramInt1)
    {
      int i = paramInt1;
      paramInt1 = paramInt2;
      paramInt2 = i;
    }
    return paramBoolean ? paramArrayOfInt[paramInt1][paramInt2] : paramArrayOfInt[paramInt2][paramInt1];
  }

  public void A(int paramInt)
  {
    if ((paramInt >= 0) && (paramInt <= 2))
      this.M = paramInt;
  }

  public int B(Card paramCard1, Card paramCard2, GameInfo paramGameInfo)
  {
    double d = paramGameInfo.getAmountToCall(paramGameInfo.getCurrentPlayerSeat());
    int i1 = A(paramCard1, paramCard2, paramGameInfo);
    int i2 = 0;
    int i3 = (paramGameInfo.getCurrentPlayerSeat() + 1) % paramGameInfo.getNumSeats();
    assert (paramGameInfo.getSmallBlindSeat() != -1);
    int i4 = 0;
    while ((i3 != paramGameInfo.getSmallBlindSeat()) && (i4++ < paramGameInfo.getNumSeats()))
    {
      if (paramGameInfo.isActive(i3))
        i2++;
      i3 = (i3 + 1) % paramGameInfo.getNumSeats();
    }
    int n = B[this.E][this.M][2][0] + B[this.E][this.M][2][1] * i2;
    int m;
    int k = m = B[this.E][this.M][1][0] + B[this.E][this.M][1][1] * i2;
    int j;
    int i = j = B[this.E][this.M][0][0] + B[this.E][this.M][0][1] * i2;
    if (paramGameInfo.getCurrentPlayerSeat() == paramGameInfo.getSmallBlindSeat())
      if (this.E == 0)
      {
        i = 0;
        k = 450;
      }
      else if (this.E == 1)
      {
        i = -75;
        k = 200;
      }
    if (i1 >= n)
      return B(d, paramGameInfo);
    if (i1 >= m)
      return A(paramGameInfo);
    if (i1 >= k)
      return d == 0.0D ? 1 : 1;
    if (i1 >= j)
      return A(d, paramGameInfo);
    if (i1 >= i)
      return d == 0.0D ? 1 : d > paramGameInfo.getBigBlindSize() ? 0 : 1;
    return d == 0.0D ? 1 : 0;
  }

  public int A(Card paramCard1, Card paramCard2, GameInfo paramGameInfo)
  {
    double d = paramGameInfo.getNumActivePlayers();
    if ((paramGameInfo.getNumActivePlayers() > 2) && (paramGameInfo.getUnacted() > 0))
      d = paramGameInfo.getNumActivePlayers() - paramGameInfo.getUnacted() + (paramGameInfo.getUnacted() - 1) * 0.6D;
    this.E = (d > 4.5D ? 0 : paramGameInfo.getNumPlayers() == 2 ? 2 : 1);
    return A(paramCard1.getRank(), paramCard2.getRank(), paramCard1.getSuit() == paramCard2.getSuit(), this.E == 0 ? 7 : this.E == 2 ? 2 : 4);
  }

  public static double A(Card paramCard1, Card paramCard2)
  {
    int i = A(paramCard1.getRank(), paramCard2.getRank(), paramCard1.getSuit() == paramCard2.getSuit(), 4);
    if (i < 110)
      return 0.01D;
    if (i >= 300)
      return 1.0D;
    return 0.01D + 0.99D * ((i - 110) / 190.0D);
  }

  private int B(double paramDouble, GameInfo paramGameInfo)
  {
    if (paramGameInfo.getNumRaises() == 0)
      return 2;
    if (paramGameInfo.getNumRaises() < 4)
      return 2;
    return paramDouble > 0.0D ? 1 : 1;
  }

  private int A(GameInfo paramGameInfo)
  {
    if (paramGameInfo.getNumRaises() < 2)
      return paramGameInfo.getNumRaises() > 0 ? 2 : 2;
    return 1;
  }

  private int A(double paramDouble, GameInfo paramGameInfo)
  {
    int i = paramDouble > 0.0D ? 1 : paramDouble > paramGameInfo.getBigBlindSize() ? 2 : 0;
    if (i == 0)
      return paramGameInfo.getNumRaises() > 0 ? 1 : 2;
    if ((i == 1) || (paramGameInfo.getPlayer(paramGameInfo.getCurrentPlayerSeat()).isCommitted()))
      return 1;
    return 0;
  }

  private static boolean A(double paramDouble1, double paramDouble2)
  {
    if (paramDouble1 > paramDouble2)
      return paramDouble1 - paramDouble2 < 0.01D;
    return paramDouble2 - paramDouble1 < 0.01D;
  }

  public static C A(int paramInt, double paramDouble1, double paramDouble2)
  {
    double d1 = 1.0D - paramDouble2;
    double d2 = 0.0D;
    double d3 = 0.0D;
    double d6;
    double d5;
    double d4 = d5 = d6 = 0.0D;
    if (A(paramDouble1, 0.0D))
    {
      if (paramInt <= 500)
      {
        d4 = 0.0D;
        d5 = 1.0D - 0.2D * paramDouble2;
        d6 = 0.2D * paramDouble2;
      }
      else
      {
        d2 = (paramInt - 600) / 500;
        if (d2 > d1)
          d2 = d1;
        if (d2 < paramDouble2)
          d2 = paramDouble2;
        d4 = 0.0D;
        d5 = 1.0D - d2;
        d6 = d2;
      }
    }
    else if (A(paramDouble1, 0.5D))
    {
      if (paramInt <= 500)
      {
        d3 = 1 - (paramInt + 400) / 500;
        if (d3 > d1)
          d3 = d1;
        if (d3 < 0.0D)
          d3 = 0.0D;
        d4 = d3;
        d5 = 1.0D - d3 - 0.2D * paramDouble2;
        d6 = 0.2D * paramDouble2;
      }
      else
      {
        d2 = (paramInt - 600) / 500;
        if (d2 > d1)
          d2 = d1;
        if (d2 < paramDouble2)
          d2 = paramDouble2;
        d4 = 0.0D;
        d5 = 1.0D - d2;
        d6 = d2;
      }
    }
    else if (A(paramDouble1, 1.0D))
    {
      if (paramInt <= 500)
      {
        d3 = 1 - (paramInt + 100) / 600;
        if (d3 > d1)
          d3 = d1;
        if (d3 < 0.0D)
          d3 = 0.0D;
        d4 = d3;
        d5 = 0.8D * (1.0D - d3);
        d6 = 0.2D * (1.0D - d3);
      }
      else
      {
        d2 = (paramInt - 340) / 800;
        if (d2 > 1.0D - 0.2D * paramDouble2)
          d2 = 1.0D - 2.0D * paramDouble2;
        if (d2 < 2.0D * paramDouble2)
          d2 = 2.0D * paramDouble2;
        d4 = 0.0D;
        d5 = 1.0D - d2;
        d6 = d2;
      }
    }
    else if (paramDouble1 >= 2.0D)
      if (paramInt <= 700)
      {
        d3 = 1 - (paramInt - 200) / 500;
        if (d3 > d1)
          d3 = d1;
        if (d3 < 0.0D)
          d3 = 0.0D;
        d4 = d3;
        d5 = 0.8D * (1.0D - d3);
        d6 = 0.2D * (1.0D - d3);
      }
      else
      {
        d2 = (paramInt - 580) / 800;
        if (d2 > 1.0D - 0.2D * paramDouble2)
          d2 = 1.0D - 2.0D * paramDouble2;
        if (d2 < 2.0D * paramDouble2)
          d2 = 2.0D * paramDouble2;
        d4 = 0.0D;
        d5 = 1.0D - d2;
        d6 = d2;
      }
    return new C(d4, d5, d6);
  }

  public static C A(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3)
  {
    int m = 100;
    int n = 200;
    double d4 = 3.0D;
    double d5 = Math.exp(-d4) / 2.0D;
    int k = (int)(1326.0D * (1.0D - paramDouble1));
    if (k < 0)
      k = 0;
    if (k > 1325)
      k = 1325;
    int i = C[k];
    double d1;
    double d6;
    if (Math.abs(i - C[1325]) < m)
    {
      d1 = d5;
    }
    else
    {
      d6 = Math.abs(paramInt - i) / m;
      if (d6 < 0.0D)
        d6 = 0.0D;
      if (d6 > d4)
        d6 = d4;
      if (paramInt < i)
        d1 = 1.0D - Math.exp(-d6) / 2.0D;
      else
        d1 = Math.exp(-d6) / 2.0D;
    }
    k = (int)(1326.0D * (1.0D - paramDouble2));
    if (k < 0)
      k = 0;
    if (k > 1325)
      k = 1325;
    int j = C[k];
    double d3;
    if (Math.abs(j - C[0]) < n)
    {
      d3 = d5;
    }
    else
    {
      d6 = Math.abs(paramInt - j) / n;
      if (d6 < 0.0D)
        d6 = 0.0D;
      if (d6 > d4)
        d6 = d4;
      if (paramInt < j)
        d3 = Math.exp(-d6) / 2.0D;
      else
        d3 = 1.0D - Math.exp(-d6) / 2.0D;
    }
    d1 *= (1.0D - d3);
    double d2 = 1.0D - (d1 + d3);
    if ((paramInt > j) && (d3 > d2))
    {
      d2 += (d3 - d2) * 0.4D;
      d3 -= (d3 - d2) * 0.4D;
    }
    return new C(d1, d2, d3);
  }

  public static double B(Card paramCard1, Card paramCard2, int paramInt)
  {
    int[][] arrayOfInt = N;
    if ((paramInt > 2) && (paramInt < 6))
      arrayOfInt = K;
    else if (paramInt >= 6)
      arrayOfInt = J;
    int i = A(paramCard1.getRank(), paramCard2.getRank(), paramCard1.getSuit() == paramCard2.getSuit(), arrayOfInt);
    int j = 0;
    int k = 0;
    for (int m = 0; m < 13; m++)
      for (int n = 0; n < 13; n++)
      {
        int i1 = 6;
        if (m > n)
          i1 = 4;
        else if (m < n)
          i1 = 12;
        if (arrayOfInt[m][n] > i)
          j += i1;
        else if (arrayOfInt[m][n] == i)
          j = (int)(j + i1 / 2.0D);
        k += i1;
      }
    return 1.0D - j / k;
  }

  public static int A(Card paramCard1, Card paramCard2, int paramInt)
  {
    int[][] arrayOfInt = N;
    if ((paramInt > 2) && (paramInt < 6))
      arrayOfInt = K;
    else if (paramInt >= 6)
      arrayOfInt = J;
    int i = A(paramCard1.getRank(), paramCard2.getRank(), paramCard1.getSuit() == paramCard2.getSuit(), arrayOfInt);
    int j = 0;
    int k = 0;
    for (int m = 0; m < 13; m++)
      for (int n = 0; n < 13; n++)
        if (arrayOfInt[m][n] > i)
          j++;
    return j + 1;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.B.K
 * JD-Core Version:    0.6.2
 */