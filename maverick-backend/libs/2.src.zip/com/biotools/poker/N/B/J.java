package com.biotools.poker.N.B;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import java.io.File;
import java.io.PrintStream;
import java.util.List;

public class J
{
  protected int N;
  protected int H;
  protected int J;
  protected int G;
  protected int B;
  protected int Q;
  protected static String K = "late position";
  protected static String M = "middle position";
  protected static String O = "early position";
  protected static String U = "the small blind";
  protected static String D = "the big blind";
  public static int X = 0;
  public static int W = 1;
  public static int F = 2;
  public static int E = 3;
  public static int R = 4;
  protected static double T = 4.0D;
  protected static double S = 5.5D;
  protected static double A = 7.0D;
  protected static double C = 10.5D;
  protected static File V = E.K("SmallStakesPreFlop.dat");
  protected Preferences P;
  protected static String[] I = { O, M, K, U, D };
  protected static String[] L = { "FOLD", "CALL", "RAISE" };

  public J()
  {
    B();
  }

  public int A(Card paramCard1, Card paramCard2, int paramInt, GameInfo paramGameInfo)
  {
    this.N = paramInt;
    this.H = A(paramGameInfo);
    this.B = (paramGameInfo.getPlayersInPot(paramGameInfo.getBigBlindSize()).size() - 1);
    double d1 = B(paramGameInfo);
    double d2 = paramGameInfo.getAmountToCall(paramInt);
    double d3 = paramGameInfo.getEligiblePot(paramInt) / d2;
    PlayerInfo localPlayerInfo = paramGameInfo.getPlayer(paramInt);
    double d4 = localPlayerInfo.getBankRoll();
    double d5 = localPlayerInfo.getBankRollAtRisk();
    boolean bool = localPlayerInfo.isCommitted();
    int i = paramGameInfo.getNumToAct() == 1 ? 1 : 0;
    E.H("I am in " + I[this.H]);
    E.H("There have been " + d1 + " Raises");
    E.H("My Pot Odds Are: " + d3 + "-1");
    E.H("My Max Risk: " + d5);
    int j = B(paramCard1, paramCard2, this.H, (int)d1, this.B);
    if (j == 0)
      if (bool)
      {
        if (d2 == paramGameInfo.getBigBlindSize())
        {
          j = 1;
        }
        else if (d3 > T)
        {
          E.H("Overriding Advice: we have already voluntarily put money in, and have good Pot Odds: " + d3 + "-1");
          j = 1;
        }
      }
      else if ((this.H == R) || (this.H == E))
      {
        if (d3 > C)
        {
          E.H("Overriding Advice: Huge Pot odds in the Blinds: " + d3 + "-1  vs " + C);
          j = 1;
        }
      }
      else if ((d2 == d4) && (d3 > T))
      {
        E.H("Overriding Advice due to: Small Stack (we're all-in) & Pot Odds: " + d3 + "-1");
        j = 1;
      }
      else if (d5 <= paramGameInfo.getBigBlindSize())
      {
        E.H("Overriding Advice due to: Low Risk, most we can lose is: " + d5);
        j = 1;
      }
      else if ((i != 0) && (d3 > S))
      {
        E.H("Overriding Advice, becuase we close the betting, and good pot odds: " + d3 + "-1");
        j = 1;
      }
      else if (d3 > A)
      {
        E.H("Overriding Advice: due to Huge pot odds: " + d3 + "-1");
        j = 1;
      }
    E.H("Returning Action: " + L[j]);
    return j;
  }

  public int B(Card paramCard1, Card paramCard2, int paramInt1, int paramInt2, int paramInt3)
  {
    String str = A(paramCard1, paramCard2, paramInt1, paramInt2, paramInt3);
    E.H("Getting Action for: " + str);
    return this.P.getIntPreference(str, 0);
  }

  public void A(Card paramCard1, Card paramCard2, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    String str = A(paramCard1, paramCard2, paramInt1, paramInt2, paramInt3);
    System.out.println("Adding Hand: " + str + " Action: " + paramInt4);
    this.P.setPreference(str, paramInt4);
  }

  public String A(Card paramCard1, Card paramCard2, int paramInt1, int paramInt2, int paramInt3)
  {
    String str = new String();
    if (paramCard1.getRank() >= paramCard2.getRank())
      str = str + Card.getRankChar(paramCard1.getRank()) + Card.getRankChar(paramCard2.getRank()) + (paramCard1.getSuit() == paramCard2.getSuit() ? "s" : "o");
    else
      str = str + Card.getRankChar(paramCard2.getRank()) + Card.getRankChar(paramCard1.getRank()) + (paramCard1.getSuit() == paramCard2.getSuit() ? "s" : "o");
    str = str + ",pos" + paramInt1;
    if (paramInt2 > 2)
      paramInt2 = 2;
    str = str + ",nr" + paramInt2;
    if (paramInt1 == F)
    {
      if (paramInt2 >= 1)
      {
        if (paramInt3 >= 4)
          paramInt3 = 4;
        if (paramInt3 < 3)
          paramInt3 = 0;
      }
      else
      {
        paramInt3 = 0;
      }
    }
    else
      paramInt3 = 0;
    str = str + ",npi" + paramInt3;
    return str;
  }

  private int A(int paramInt1, int paramInt2)
  {
    if (paramInt1 < 0)
      return paramInt1;
    int i = paramInt1 - paramInt2;
    if (i < 0)
      i += 10;
    return i;
  }

  private int A(GameInfo paramGameInfo)
  {
    int i = 0;
    int j = this.N;
    while ((j != paramGameInfo.getButtonSeat()) && (i <= 9))
    {
      j = paramGameInfo.nextSeat(j);
      if (paramGameInfo.isActive(j))
        i++;
    }
    if (paramGameInfo.getBigBlindSeat() == this.N)
      return R;
    if (paramGameInfo.getSmallBlindSeat() == this.N)
      return E;
    if (i <= 1)
      return F;
    if (i <= 4)
      return W;
    if (i <= 7)
      return X;
    if (!$assertionsDisabled)
      throw new AssertionError();
    return i;
  }

  private void B()
  {
    this.P = new Preferences(V);
  }

  public void A()
  {
    this.P.savePreferences();
  }

  private double B(GameInfo paramGameInfo)
  {
    int i = paramGameInfo.getNumRaises();
    double d1 = paramGameInfo.getBigBlindSize();
    double d2 = paramGameInfo.getSmallBlindSize();
    double d3 = paramGameInfo.getAmountToCall(this.N) / paramGameInfo.getBigBlindSize();
    if (this.H == E)
      d3 -= (d1 - d2) / d1;
    if ((d3 < 0.4D) && (d3 > 0.3D))
      d3 = 1.0D;
    long l = Math.round(d3);
    if (l == i)
      l -= 1L;
    E.H("Found " + i + " Total Raises, but it is only " + l + " Raise(s) to call. (raise_amnount " + d3 + ")");
    return l;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.B.J
 * JD-Core Version:    0.6.2
 */