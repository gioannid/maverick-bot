package com.biotools.poker.N.B;

import com.biotools.B.I;
import com.biotools.poker.E;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Insets;
import java.io.File;
import java.util.Vector;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class F extends JPanel
  implements ChangeListener
{
  private Vector D = new Vector();
  private C G;
  private JComboBox C;
  private JButton F;
  private JButton H;
  private I B;
  private Vector A = new Vector();
  private G E = new G(E.D("HandGroupEditor.NoGroup"), Color.WHITE);

  public F()
  {
    setLayout(new BorderLayout(4, 4));
    for (int i = 0; i < 13; i++)
      for (int j = 0; j < 13; j++)
        this.E.C[i][j] = 1;
    this.A.add(this.E);
    this.G = new C(this.A);
    this.G.A(this);
    add(this.G, "Center");
    add(D(), "North");
    A(this.E);
  }

  public void A(ChangeListener paramChangeListener)
  {
    this.D.add(paramChangeListener);
  }

  public void B(ChangeListener paramChangeListener)
  {
    this.D.remove(paramChangeListener);
  }

  public void E()
  {
    for (int i = 0; i < this.D.size(); i++)
    {
      ChangeEvent localChangeEvent = new ChangeEvent(this);
      ((ChangeListener)this.D.get(i)).stateChanged(localChangeEvent);
    }
  }

  public String B()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i < this.A.size(); i++)
    {
      localStringBuffer.append(A(i).A());
      localStringBuffer.append('|');
    }
    return localStringBuffer.toString();
  }

  public void I()
  {
    this.F.setVisible(false);
    this.H.setVisible(false);
  }

  public void H()
  {
    this.F.setVisible(true);
    this.H.setVisible(true);
  }

  public void A(String paramString)
  {
    if (paramString == null)
      return;
    this.A.clear();
    String[] arrayOfString1 = paramString.split("\\|");
    for (int i = 0; i < arrayOfString1.length; i++)
    {
      String[] arrayOfString2 = arrayOfString1[i].split(",");
      if (arrayOfString2.length >= 2)
      {
        G localG = new G(arrayOfString2[(arrayOfString2.length - 1)], new Color(Integer.parseInt(arrayOfString2[0])));
        for (int j = 1; j < arrayOfString2.length - 1; j++)
          localG.A(arrayOfString2[j]);
        if (localG.A.equals(this.E.A))
          this.E = localG;
        this.A.add(localG);
      }
    }
    this.C.setSelectedIndex(0);
  }

  public G A(int paramInt)
  {
    return (G)this.A.get(paramInt);
  }

  private void G()
  {
    String str = JOptionPane.showInputDialog(this, E.D("HandGroupEditor.ChooseNewProfileNameTitle"));
    if (str != null)
    {
      str = str.trim();
      str = str.replace(',', ';');
      str = str.replace('|', ';');
      str = str.replace('=', ';');
      str = str.replace('\n', ' ');
      Color localColor = new Color((int)(Math.random() * 255.0D), (int)(Math.random() * 255.0D), (int)(Math.random() * 255.0D));
      G localG = new G(str, localColor);
      this.A.add(localG);
      this.C.setSelectedItem(localG);
      this.G.B(localG);
      E();
    }
  }

  public JPanel D()
  {
    this.C = new JComboBox(this.A);
    this.C.addItemListener(new F.1(this));
    this.F = new JButton(new ImageIcon(E.K("pix/Delete24.gif").getPath()));
    this.F.setToolTipText(E.D("HandGroupEditor.DeleteCurrentGroup"));
    this.F.setMargin(new Insets(0, 0, 0, 0));
    this.F.addActionListener(new F.2(this));
    this.H = new JButton(new ImageIcon(E.K("pix/Add24.gif").getPath()));
    this.H.setToolTipText(E.D("HandGroupEditor.CreateNewGroup"));
    this.H.setMargin(new Insets(0, 0, 0, 0));
    this.H.addActionListener(new F.3(this));
    this.B = new I();
    this.B.setToolTipText(E.D("HandGroupEditor.ChangeGroupColor"));
    this.B.A(24, 24);
    this.B.addMouseListener(new F.4(this));
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(Box.createHorizontalStrut(5));
    localJPanel.add(this.C);
    localJPanel.add(Box.createHorizontalStrut(5));
    localJPanel.add(this.B);
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(Box.createHorizontalStrut(5));
    localJPanel.add(this.F);
    localJPanel.add(Box.createHorizontalStrut(10));
    localJPanel.add(this.H);
    localJPanel.add(Box.createHorizontalStrut(5));
    return localJPanel;
  }

  private void A(G paramG)
  {
    this.G.B(paramG);
    this.B.setBackground(paramG.B);
    this.F.setEnabled(paramG != this.E);
  }

  private void A()
  {
    G localG = C();
    Object[] arrayOfObject = { localG };
    int i = JOptionPane.showConfirmDialog(this, E.A("HandGroupEditor.DeleteGroupPattern", arrayOfObject), E.D("HandGroupEditor.Delete"), 0);
    if (i == 0)
    {
      this.G.A(localG, this.E);
      this.A.remove(localG);
      this.C.setSelectedIndex(0);
      E();
    }
  }

  private void J()
  {
    Color localColor = JColorChooser.showDialog(this, E.D("HandGroupEditor.ChooseBackgroundColor"), this.B.getBackground());
    if (localColor != null)
    {
      this.B.setBackground(localColor);
      C().B = localColor;
      E();
      this.G.repaint();
    }
  }

  private G C()
  {
    return (G)this.C.getSelectedItem();
  }

  public static void F()
  {
    JFrame localJFrame = new JFrame(E.D("HandGroupEditor.HandGroupEditor"));
    localJFrame.getContentPane().add(new F());
    localJFrame.pack();
    localJFrame.setVisible(true);
    localJFrame.setDefaultCloseOperation(3);
  }

  public void stateChanged(ChangeEvent paramChangeEvent)
  {
    E();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.B.F
 * JD-Core Version:    0.6.2
 */