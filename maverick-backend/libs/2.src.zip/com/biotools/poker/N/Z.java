package com.biotools.poker.N;

import com.A.B.A;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import com.biotools.poker.E.D;
import com.biotools.poker.M.B;
import com.biotools.poker.N.B.F;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.util.Hashtable;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTabbedPane;

public class Z extends I
  implements D, B
{
  private F á;

  public JPanel A()
  {
    JLabel localJLabel = new JLabel(E.D("Brains.XenbotConfigurationOptions"), 0);
    localJLabel.setFont(new Font("Application", 1, 14));
    JPanel localJPanel = new JPanel(new BorderLayout(4, 4));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
    localJPanel.add(localJLabel, "North");
    JTabbedPane localJTabbedPane = new JTabbedPane();
    localJTabbedPane.add(E.D("Brains.Preflop"), Ì());
    localJTabbedPane.add(E.D("Brains.Postflop"), Í());
    localJPanel.add(localJTabbedPane, "Center");
    return localJPanel;
  }

  public JPanel Ì()
  {
    this.á = new F();
    this.á.I();
    this.á.A(B().getPreference("PREFLOP"));
    this.á.A(new Z.1(this));
    A localA = new A();
    localA.A(E.K("help/xenbot_inline.html"));
    localA.setPreferredSize(new Dimension(250, 200));
    JPanel localJPanel = new JPanel(new BorderLayout(4, 4));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
    localJPanel.add(this.á, "Center");
    localJPanel.add(localA, "East");
    return localJPanel;
  }

  public JPanel Í()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 1));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.add(Ï());
    localJPanel.add(Box.createVerticalStrut(10));
    localJPanel.add(Ë());
    localJPanel.add(Box.createVerticalStrut(10));
    localJPanel.add(Î());
    localJPanel.add(Box.createVerticalStrut(10));
    localJPanel.add(Box.createVerticalGlue());
    return localJPanel;
  }

  public JSlider Ï()
  {
    int i = (int)(100.0D * Â());
    JSlider localJSlider = new JSlider(0, 100, i);
    localJSlider.setBorder(BorderFactory.createTitledBorder(E.D("Brains.AggressionTitle")));
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(new Integer(0), new JLabel(E.D("Brains.Passive")));
    localHashtable.put(new Integer(100), new JLabel(E.D("Brains.Aggressive")));
    localJSlider.setLabelTable(localHashtable);
    localJSlider.setPaintLabels(true);
    localJSlider.setMajorTickSpacing(25);
    localJSlider.setMinorTickSpacing(5);
    localJSlider.setPaintTicks(true);
    localJSlider.addChangeListener(new Z.2(this, localJSlider));
    return localJSlider;
  }

  public JSlider Ë()
  {
    int i = (int)(100.0D * É());
    JSlider localJSlider = new JSlider(0, 100, i);
    localJSlider.setBorder(BorderFactory.createTitledBorder(E.D("Brains.ImpliedOddsEstimationTitle")));
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(new Integer(0), new JLabel(E.D("Brains.Conservative")));
    localHashtable.put(new Integer(100), new JLabel(E.D("Brains.Liberal")));
    localJSlider.setLabelTable(localHashtable);
    localJSlider.setPaintLabels(true);
    localJSlider.setMajorTickSpacing(25);
    localJSlider.setMinorTickSpacing(5);
    localJSlider.setPaintTicks(true);
    localJSlider.addChangeListener(new Z.3(this, localJSlider));
    return localJSlider;
  }

  public JSlider Î()
  {
    int i = (int)(100.0D * Ã());
    JSlider localJSlider = new JSlider(40, 100, i);
    localJSlider.setBorder(BorderFactory.createTitledBorder(E.D("Brains.ShowdownOddsEstimationTitle")));
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(new Integer(40), new JLabel(E.D("Brains.Conservative")));
    localHashtable.put(new Integer(100), new JLabel(E.D("Brains.Liberal")));
    localJSlider.setLabelTable(localHashtable);
    localJSlider.setPaintLabels(true);
    localJSlider.setMajorTickSpacing(15);
    localJSlider.setMinorTickSpacing(5);
    localJSlider.setPaintTicks(true);
    localJSlider.addChangeListener(new Z.4(this, localJSlider));
    return localJSlider;
  }

  public void init(Preferences paramPreferences)
  {
    this.Á = paramPreferences;
    super.init(paramPreferences);
  }

  public Preferences B()
  {
    return this.Á;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.Z
 * JD-Core Version:    0.6.2
 */