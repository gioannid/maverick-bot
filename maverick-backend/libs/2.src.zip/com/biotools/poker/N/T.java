package com.biotools.poker.N;

import com.biotools.A.W;
import com.biotools.A.b;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.util.NChoose2IntTable;
import com.biotools.poker.D.A;
import com.biotools.poker.D.B;
import com.biotools.poker.D.C;
import com.biotools.poker.D.G;
import com.biotools.poker.Q.D;
import com.biotools.poker.Q.F;
import java.util.Hashtable;

public class T
{
  public static final int h = 1;
  public static final int p = 2;
  public static final int R = 3;
  public static final int C = 4;
  public static boolean _ = false;
  public static boolean j = false;
  private int L = 4;
  private double d = 0.0D;
  private D r;
  private int Z;
  private b k = b.D();
  private Deck q = new Deck();
  private HandEvaluator t = new HandEvaluator();
  private static W o = W.A();
  private Card J;
  private Card I;
  private Card Q;
  private Card H;
  private Hand[] W;
  private com.biotools.poker.D.E M;
  private G X;
  private Hand O;
  private int N;
  private double e;
  private double b;
  private double c;
  private int s;
  private int K;
  private int U;
  private int S;
  private int f;
  private int i;
  private int B;
  private boolean n;
  private double E = 0.0D;
  private double V = 0.0D;
  private boolean[] A;
  private boolean[] m;
  private double[] a;
  private int[] G;
  private long l = System.currentTimeMillis();
  private Hashtable T = new Hashtable(15000);
  private Hashtable F = new Hashtable(10000);
  private int D = 0;
  private int g = 0;
  private int Y = 0;
  private int P = 0;

  public T(int paramInt, Card paramCard1, Card paramCard2, com.biotools.poker.D.E paramE, GameInfo paramGameInfo)
  {
    this.r = ((D)paramGameInfo);
    this.J = paramCard1;
    this.I = paramCard2;
    this.X = G.A(paramGameInfo);
    this.M = paramE;
    this.Z = paramInt;
    this.q.shuffle();
  }

  private void B()
  {
    this.i = this.r.getUnacted();
    this.B = this.r.getNumActivePlayers();
    this.K = this.r.getNumPlayers();
    this.U = this.r.M();
    this.N = this.r.getStage();
    this.b = this.r.getTotalPotSize();
    this.e = this.r.c();
    this.f = this.r.getNumRaises();
    this.c = 0.0D;
    this.S = 0;
    for (int i1 = 0; i1 < this.r.getNumSeats(); i1++)
      if (this.r.inGame(i1))
      {
        this.A[i1] = (this.r.isActive(i1) ? 0 : true);
        this.m[i1] = this.r.G(i1).isCommitted();
        this.a[i1] = this.r.getAmountToCall(i1);
        this.G[i1] = this.r.G(i1).M();
      }
      else
      {
        this.A[i1] = true;
        this.m[i1] = false;
        this.a[i1] = 0.0D;
        this.G[i1] = 0;
      }
    this.O = new Hand(this.r.getBoard());
  }

  public boolean B(int paramInt)
  {
    int i1;
    switch (paramInt)
    {
    case 0:
      this.B -= 1;
      this.i -= 1;
      this.A[this.s] = true;
      if (this.B == 1)
        return true;
      break;
    case 1:
      if (this.s == this.Z)
        this.c += this.a[this.Z];
      this.b += this.a[this.s];
      if (this.a[this.s] > 0.0D)
        this.m[this.s] = true;
      this.G[this.s] = A(1, this.a[this.s]);
      this.a[this.s] = 0.0D;
      this.i -= 1;
      break;
    case 2:
      for (i1 = 0; i1 < this.r.getNumSeats(); i1++)
        if (this.A[i1] == 0)
          this.a[i1] += this.e;
      if (this.s == this.Z)
        this.c += this.a[this.Z];
      this.b += this.a[this.s];
      this.a[this.s] = 0.0D;
      this.m[this.s] = true;
      this.f += 1;
      this.i = (this.B - 1);
      this.G[this.s] = A(2, this.a[this.s]);
    }
    if (this.i <= 0)
    {
      this.i = this.B;
      this.S = this.f;
      this.s = this.U;
      if (++this.s >= this.r.getNumSeats())
        this.s = 0;
      while (this.A[this.s] != 0)
        if (++this.s >= this.r.getNumSeats())
          this.s = 0;
      switch (this.N)
      {
      case 1:
        for (i1 = 0; i1 < this.r.getNumSeats(); i1++)
          this.m[i1] = false;
        this.O.addCard(this.Q);
        if (_)
          this.k.K(" * Turn = " + this.Q.toString());
        this.N += 1;
        break;
      case 2:
        for (i1 = 0; i1 < this.r.getNumSeats(); i1++)
          this.m[i1] = false;
        this.O.addCard(this.H);
        if (_)
          this.k.K(" * River = " + this.H.toString());
        this.e = this.r.N();
        this.N += 1;
        break;
      case 3:
        if (_)
          this.k.K("SHOWDOWN");
        return true;
      }
      this.n = false;
    }
    else
    {
      if (++this.s >= this.r.getNumSeats())
        this.s = 0;
      while (this.A[this.s] != 0)
        if (++this.s >= this.r.getNumSeats())
          this.s = 0;
    }
    return false;
  }

  public double C(int paramInt)
  {
    int i1 = 1;
    int i2 = 1;
    double d1 = this.r.G(this.Z).getAmountInPot();
    this.n = true;
    this.s = this.Z;
    B();
    while (i2 != 0)
    {
      int i3;
      if (i1 != 0)
      {
        i3 = paramInt;
        i1 = 0;
      }
      else
      {
        i3 = A(this.s);
      }
      if ((i3 == 2) && (this.f >= 4))
        i3 = 1;
      if ((this.s == this.Z) && (i3 == 0))
        if ((this.N == this.r.getStage()) || (o.nextDouble() < this.d / 4.0D))
        {
          i3 = 1;
        }
        else
        {
          if (_)
            this.k.K("FOLDED");
          return -1.0D * (this.c + d1);
        }
      i2 = B(i3) ? 0 : 1;
    }
    Hand localHand = new Hand(this.O);
    localHand.addCard(this.J);
    localHand.addCard(this.I);
    int i4 = HandEvaluator.rankHand(localHand);
    localHand.removeCard();
    localHand.removeCard();
    int i5 = this.Z + 1;
    if (i5 >= this.r.getNumSeats())
      i5 = 0;
    int i6 = 1;
    while ((i5 != this.Z) && (i5 < this.r.getNumSeats()))
    {
      if (this.A[i5] == 0)
      {
        localHand.addCard(this.W[i5].getCard(1));
        localHand.addCard(this.W[i5].getCard(2));
        int i7 = HandEvaluator.rankHand(localHand);
        if (i7 > i4)
          return -1.0D * (this.c + d1);
        if (i4 == i7)
          i6++;
        localHand.removeCard();
        localHand.removeCard();
      }
      i5++;
      if (i5 >= this.r.getNumSeats())
        i5 = 0;
    }
    return this.b / i6 - (this.c + d1);
  }

  private int A(int paramInt)
  {
    int i1 = 1;
    if (this.L == 1)
      return 1;
    try
    {
      double d1 = A(this.W[paramInt].getCard(1), this.W[paramInt].getCard(2), this.O);
      double d2 = A.A(this.W[paramInt].getCard(1), this.W[paramInt].getCard(2), this.O);
      C localC = X.A(d2, 0.0D, d1, this.a[paramInt], this.i, this.N, this.f, this.m[paramInt], this.b, this.r.K(), true, 0.3D + this.K * 0.01D, 0.6D + this.K * 0.015D);
      i1 = localC.L();
    }
    catch (Exception localException)
    {
      i1 = 1;
    }
    if ((i1 == 0) && (this.a[paramInt] == 0.0D))
      i1 = 1;
    return i1;
  }

  public double A()
  {
    double d1 = 1.0D;
    this.q.reset();
    this.O = new Hand(this.r.getBoard());
    this.q.extractHand(this.O);
    this.q.extractCard(this.J);
    this.q.extractCard(this.I);
    if (this.r.getStage() == 1)
    {
      this.Q = this.q.extractRandomCard();
      this.H = this.q.extractRandomCard();
    }
    else if (this.r.getStage() == 2)
    {
      this.H = this.q.extractRandomCard();
    }
    for (int i1 = 0; i1 < this.r.getNumSeats(); i1++)
      if (this.r.inGame(i1))
      {
        if (i1 != this.Z)
        {
          this.W[i1].setCard(1, this.q.extractRandomCard());
          this.W[i1].setCard(2, this.q.extractRandomCard());
          d1 *= this.X.Q(i1).Ŧ().A(this.W[i1].getCard(1), this.W[i1].getCard(2));
        }
        else
        {
          this.W[i1].setCard(1, this.J);
          this.W[i1].setCard(2, this.I);
        }
        if (_)
          this.k.K(this.r.G(i1).getName() + ": " + this.A[i1] + ": " + this.W[i1].getCard(1) + "-" + this.W[i1].getCard(2));
      }
    return 0.02D + 0.98D * d1;
  }

  private double A(Card paramCard1, Card paramCard2, Hand paramHand)
  {
    double d1 = -1.0D;
    StringBuffer localStringBuffer = new StringBuffer(16);
    localStringBuffer.append(this.N);
    if (paramCard1.getIndex() > paramCard2.getIndex())
    {
      localStringBuffer.append(paramCard1);
      localStringBuffer.append(paramCard2);
    }
    else
    {
      localStringBuffer.append(paramCard2);
      localStringBuffer.append(paramCard1);
    }
    if (this.r.getStage() == 1)
    {
      if (this.N == 3)
      {
        if (this.Q.getIndex() >= this.H.getIndex())
        {
          localStringBuffer.append(this.Q);
          localStringBuffer.append(this.H);
        }
        else
        {
          localStringBuffer.append(this.H);
          localStringBuffer.append(this.Q);
        }
      }
      else if (this.N == 2)
        localStringBuffer.append(this.Q);
    }
    else if (this.N == 3)
      localStringBuffer.append(this.H);
    String str1 = localStringBuffer.toString();
    if (this.T.containsKey(str1))
    {
      d1 = ((Double)this.T.get(str1)).doubleValue();
    }
    else
    {
      if (this.N == this.r.getStage())
      {
        d1 = this.M.A(paramCard1, paramCard2, paramHand, G.A(this.r).ŷ());
        this.P += 1;
      }
      else
      {
        Hand localHand = new Hand(paramHand);
        localHand.sort();
        String str2 = localHand.toString();
        NChoose2IntTable localNChoose2IntTable = (NChoose2IntTable)this.F.get(str2);
        if (localNChoose2IntTable == null)
        {
          localNChoose2IntTable = HandEvaluator.getRanks(paramHand);
          this.F.put(str2, localNChoose2IntTable);
          this.Y += 1;
        }
        this.P += 1;
        d1 = this.M.A(paramCard1, paramCard2, paramHand, localNChoose2IntTable);
      }
      this.T.put(str1, new Double(d1));
      this.g += 1;
    }
    this.D += 1;
    double d2 = d1;
    for (int i1 = 0; i1 < this.B - 2; i1++)
      d1 *= d2;
    return d1;
  }

  public double[] A(int paramInt1, int paramInt2, int paramInt3)
  {
    double d2 = 0.0D;
    double d3 = 0.0D;
    int i1 = 0;
    int i2 = 0;
    double d4 = 0.0D;
    this.L = paramInt3;
    this.W = new Hand[this.r.getNumSeats()];
    this.A = new boolean[this.r.getNumSeats()];
    this.m = new boolean[this.r.getNumSeats()];
    this.a = new double[this.r.getNumSeats()];
    this.G = new int[this.r.getNumSeats()];
    for (int i3 = 0; i3 < this.r.getNumSeats(); i3++)
      if (this.r.inGame(i3))
        this.W[i3] = new Hand();
    while ((i2 < paramInt1) || ((i2 >= paramInt1) && (System.currentTimeMillis() - this.l < paramInt2)))
    {
      if (_)
        b.F();
      if (_)
        this.k.K("##################" + i2);
      d5 = A();
      if (_)
        this.k.K("");
      if (_)
        this.k.K("{c}");
      double d1 = d5 * C(1);
      if (_)
        this.k.K("EV: " + d1);
      d2 += d1;
      if (_)
        this.k.K("{r}");
      d1 = d5 * C(2);
      if (_)
        this.k.K("EV: " + d1);
      d3 += d1;
      i2++;
      d4 += d5;
      this.Q = (this.H = null);
    }
    double d5 = d2 / d4;
    double d6 = d3 / d4;
    double d7 = d5 / this.r.getTotalPotSize();
    double d8 = d6 / this.r.getTotalPotSize();
    this.l = (System.currentTimeMillis() - this.l);
    com.biotools.poker.E.H(" | " + i2 + " Trials in " + b.A(this.l / 1000.0D, 2) + "s (" + b.A(i2 / (this.l / 1000.0D), 1) + " t/s)");
    com.biotools.poker.E.H(" | {" + b.A(d7, 2) + ", " + b.A(d8, 2) + "}");
    double[] arrayOfDouble = new double[3];
    arrayOfDouble[0] = 0.0D;
    arrayOfDouble[1] = d7;
    arrayOfDouble[2] = d8;
    this.T.clear();
    this.T = null;
    this.F.clear();
    this.F = null;
    return arrayOfDouble;
  }

  public C B(int paramInt1, int paramInt2, int paramInt3)
  {
    double[] arrayOfDouble = A(paramInt1, paramInt2, paramInt3);
    this.E = arrayOfDouble[1];
    this.V = arrayOfDouble[2];
    if ((this.E > 0.01D) && (this.V < 0.0D))
      return C.G;
    if ((this.E < 0.0D) && (this.V > 0.01D))
      return C.B;
    if ((this.E > 0.01D) && (this.V > 0.01D))
    {
      if ((this.V > this.E) && (this.r.isRiver()) && (this.r.getNumToAct() == 1))
        return C.B;
      C localC = new C(0.0D, this.E * this.E * this.E, this.V * this.V * this.V);
      localC.E();
      com.biotools.poker.E.H(" | pt = " + localC);
      return localC;
    }
    return this.r.getAmountToCall(this.Z) > 0.0D ? C.E : C.G;
  }

  public void A(double paramDouble)
  {
    this.d = paramDouble;
  }

  private int A(int paramInt, double paramDouble)
  {
    int i1 = -1;
    if ((paramInt == 1) && (paramDouble == 0.0D))
      i1 = 0;
    else if ((paramInt == 1) && (paramDouble > 0.0D))
      i1 = 1;
    else if ((paramInt == 2) && (paramDouble == 0.0D))
      i1 = 2;
    else if ((paramInt == 2) && (paramDouble > 0.0D))
      i1 = 3;
    return i1;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.T
 * JD-Core Version:    0.6.2
 */