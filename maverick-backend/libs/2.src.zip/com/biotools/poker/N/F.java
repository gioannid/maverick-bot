package com.biotools.poker.N;

import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import com.biotools.poker.E.D;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class F extends R
  implements D
{
  private String[] Ã = { E.D("Brains.Tight"), E.D("Brains.Moderate"), E.D("Brains.Loose") };

  public JPanel A()
  {
    JLabel localJLabel = new JLabel(E.D("Brains.NLConfigurationOptionsHeading"), 0);
    localJLabel.setFont(new Font("Application", 1, 14));
    JPanel localJPanel = new JPanel(new BorderLayout(4, 4));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    localJPanel.add(localJLabel, "North");
    return localJPanel;
  }

  public JPanel Á()
  {
    JComboBox localJComboBox = new JComboBox(this.Ã);
    localJComboBox.setSelectedIndex(µ());
    localJComboBox.addActionListener(new F.1(this, localJComboBox));
    JPanel localJPanel = new JPanel();
    localJPanel.add(new JLabel(E.D("Brains.PreflopSelectionTitle"), 4));
    localJPanel.add(localJComboBox);
    return localJPanel;
  }

  public void init(Preferences paramPreferences)
  {
    this.Á = paramPreferences;
    super.init(paramPreferences);
  }

  public Preferences B()
  {
    return this.Á;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.F
 * JD-Core Version:    0.6.2
 */