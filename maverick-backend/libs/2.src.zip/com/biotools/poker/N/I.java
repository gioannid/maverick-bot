package com.biotools.poker.N;

import com.biotools.A.b;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.D.A;
import com.biotools.poker.D.C;
import com.biotools.poker.D.G;
import com.biotools.poker.Q.D;
import java.util.HashMap;

public class I extends R
{
  public static final String Ó = "PREFLOP";
  public static final String É = "IMPLIED_ODDS";
  public static final String Þ = "AGGRESSION";
  public static final String Å = "SHOWDOWN_ODDS_FACTOR";
  public static final String Ð = "IMPLIED_ODDS_FACTOR";
  public static final String ß = "POKE_FACTOR";
  public static final String à = "STEAL_FLAG";
  private C Ä;
  private double Ù;
  private int Í = -1;
  private int Ò = 0;
  private int Æ = 0;
  private HashMap Ý = new HashMap();
  private boolean Ê = false;
  private boolean Ì = false;
  private boolean Ö = false;
  private static final String Ô = "Group One";
  private static final String Ë = "Group Two";
  private static final String Ï = "Group Two-A";
  private static final String Ü = "Group Three";
  private static final String È = "Group Four";
  private static final String Ñ = "Group Five";
  private static final String Ø = "Group Six";
  private static final String Ç = "Group Six-A";
  private static final String Ú = "Group Seven";
  private static final String Î = "Group Eight";
  private static final String Û = "Group Nine";
  private static final String Õ = "Bluffs";

  public void init(Preferences paramPreferences)
  {
    this.Á = paramPreferences;
    Å();
    String str = paramPreferences.getPreference("PREFLOP");
    if (str != null)
      N(str);
  }

  private boolean Ä()
  {
    return this.Á.getBooleanPreference("IMPLIED_ODDS", true);
  }

  protected double É()
  {
    return this.Á.getDoublePreference("IMPLIED_ODDS_FACTOR", 0.25D);
  }

  protected double Æ()
  {
    return this.Á.getDoublePreference("POKE_FACTOR", 0.25D);
  }

  protected double Ã()
  {
    return this.Á.getDoublePreference("SHOWDOWN_ODDS_FACTOR", 0.6D);
  }

  protected double Â()
  {
    return this.Á.getDoublePreference("AGGRESSION", 0.5D);
  }

  public void A(D paramD)
  {
    super.gameStartEvent(paramD);
    this.Í = -1;
    this.Æ = 0;
    this.Ò = 0;
    this.Ì = false;
    this.Ö = false;
  }

  public void stageEvent(int paramInt)
  {
    super.stageEvent(paramInt);
    if (paramInt == 1)
      this.Ê = true;
    this.Ö = false;
    this.Í = -1;
    this.Ò = 0;
    this.Æ = 0;
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
    super.actionEvent(paramInt, paramAction);
    if (paramAction.isBetOrRaise())
    {
      if ((paramInt != this.Í) && (paramInt != this.º))
        this.Ò += 1;
      this.Í = paramInt;
      this.Æ = 0;
      if (this.ª.isPostFlop())
        if ((this.Ö) && (paramInt != this.º))
          this.Ì = true;
        else if (paramInt == this.º)
          this.Ö = true;
      if (this.ª.isFlop())
        this.Ê = false;
    }
    if ((paramAction.isCall()) && (this.Í >= 0))
      this.Æ += 1;
  }

  protected boolean Ç()
  {
    G localG = G.A(this.ª);
    if ((this.Í < 0) || (this.Ò != 1) || (this.Æ > 0))
      return false;
    com.biotools.poker.D.B localB = localG.Q(this.Í);
    if (localB.Ŷ() < 8)
      return false;
    if (this.ª.getNumPlayers() == 2)
    {
      if ((localB.Ť() > 0.8D) && (localB.ŧ() > 0.25D))
      {
        if (localB.Ű() + localB.ų() > 0.65D)
          return true;
        if (localB.ů() > 0.35D)
          return true;
      }
    }
    else if ((localB.Ť() > 0.45D) && (localB.ŧ() > 0.125D))
    {
      if (localB.Ű() + localB.ų() > 0.35D)
        return true;
      if (localB.ů() > 0.25D)
        return true;
    }
    return false;
  }

  protected Action z()
  {
    this.Ä = null;
    double d1 = this.ª.getPlayer(this.º).getBankRoll();
    double d2 = this.ª.getAmountToCall(this.º);
    if (d2 > d1)
      d2 = d1;
    double d3 = this.ª.getPlayer(this.º).getBankRollAtRisk();
    double d4 = this.ª.getEligiblePot(this.º);
    int i = this.ª.getNumToAct() - 1;
    int j = this.ª.getNumPlayers() <= 4 ? 1 : 0;
    int k = d3 <= this.ª.getBigBlindSize() * 8.0D ? 1 : 0;
    int m = this.ª.getNumPlayers() == 2 ? 1 : 0;
    int n = 0;
    for (int i1 = 0; i1 < this.ª.getNumSeats(); i1++)
      if ((this.ª.isActive(i1)) && (this.ª.getPlayer(i1).isCommitted()) && (i1 != this.º))
        n++;
    i1 = (this.ª.getPlayer(this.º).getAmountInPotThisRound() > 0.0D) && (n <= 1) ? 1 : 0;
    boolean bool1 = this.ª.getPlayer(this.º).isCommitted();
    boolean bool2 = Ç();
    if (bool2)
      com.biotools.poker.E.H("MANIAC MODE");
    com.biotools.poker.E.H(À() + " | " + this.¤ + "-" + this.¢);
    if ((!this.ª.isZipMode()) && (!this.ª.isSimulation()) && (d2 > 0.0D) && (d3 * 0.8D <= d2))
    {
      Action localAction = È();
      if (localAction.isCall())
        return localAction;
    }
    double d5;
    if (A(O("Group One")))
    {
      if (Math.random() < 0.1D * (m != 0 ? 2 : 1) * (bool1 ? 2 : 1))
        return ¤();
      if ((d2 > this.ª.getBigBlindSize() * 3.0D) && (k == 0) && (Math.random() < 0.5D * this.ª.getNumRaises()))
        return ¤();
      d5 = (d4 + d2) * (Math.random() < 0.25D ? 2 : 1);
      return D(d5);
    }
    if (A(O("Group Two")))
    {
      if (d2 <= this.ª.getBigBlindSize() * 3.0D)
        if (Math.random() < 0.1D * (m != 0 ? 2 : 1) * (j != 0 ? 2 : 1))
          return ¤();
      if ((bool1) && (k == 0) && (Math.random() < 0.75D))
        return ¤();
      if (d2 <= this.ª.getBigBlindSize())
      {
        if ((n <= 2) || (j != 0))
        {
          d5 = (d4 + d2) * ((n == 0) && (Math.random() < 0.25D) ? 2 : 1);
          return D(d5);
        }
        return ¤();
      }
      if (d2 < d1 * 0.15D * (j != 0 ? 2 : 1) * (bool1 ? 2 : 1) * (this.Æ == 0 ? 1.0D : 0.5D))
      {
        if ((Math.random() < (12 - this.ª.getNumPlayers()) * 0.05D) && (this.Æ == 0))
        {
          d5 = (d4 + d2) * (Math.random() < 0.25D ? 2 : 1);
          return D(d5);
        }
        return ¤();
      }
      if (d1 < 5.0D * this.ª.getBigBlindSize())
        return D(d1);
      if (d1 < 10.0D * this.ª.getBigBlindSize())
        return ¤();
      if (bool2)
      {
        com.biotools.poker.E.H("MANIAC CONTROL");
        return D(d4 + d2);
      }
    }
    if (A(O("Group Two-A")))
    {
      if ((k != 0) && (n == 0))
        return D(d1);
      if ((n < 2) && (i <= 6) && (this.Ò == 0))
        return D(d4 + d2);
      if ((i <= 3) && (d2 <= this.ª.getBigBlindSize()))
      {
        if (Math.random() < 0.25D)
          return D(d4 + d2);
        if ((n >= 2) && (Math.random() < 0.1D))
          return ¤();
      }
      if (bool1)
        if ((d2 < d1 * 0.1D * (j != 0 ? 2 : 1)) && (d2 / d4 < 1.0D / n))
          return ¤();
      if ((bool2) && (j != 0))
      {
        com.biotools.poker.E.H("MANIAC CONTROL");
        return D(d4 + d2);
      }
    }
    if (A(O("Group Three")))
    {
      if (d2 <= this.ª.getBigBlindSize() * 3.0D)
        if (Math.random() < 0.05D * (m != 0 ? 3 : 1) * (j != 0 ? 2 : 1))
          return ¤();
      if (d2 <= this.ª.getBigBlindSize())
      {
        if ((n == 0) && (i <= 2))
        {
          d5 = (d4 + d2) * (Math.random() < 0.25D ? 2 : 1);
          return D(d5);
        }
        return ¤();
      }
      if (this.Æ == 0)
      {
        if (i <= 5)
          if (d2 < d1 * 0.1D * (j != 0 ? 2 : 1) * (bool1 ? 2 : 1))
          {
            if ((i < 3) && (Math.random() < (12 - this.ª.getNumPlayers()) * 0.025D))
            {
              d5 = (d4 + d2) * (Math.random() < 0.25D ? 2 : 1);
              return D(d5);
            }
            return ¤();
          }
        if (d1 < 10.0D * this.ª.getBigBlindSize())
          return ¤();
      }
      if (bool2)
      {
        com.biotools.poker.E.H("MANIAC CONTROL");
        return D(d4 + d2);
      }
    }
    if (A(O("Group Four")))
    {
      if (d2 <= this.ª.getBigBlindSize())
      {
        if ((n == 0) && (i <= 1))
        {
          d5 = (d4 + d2) * (Math.random() < 0.25D ? 2 : 1);
          return D(d5);
        }
        if (i <= 4)
          return ¤();
      }
      if (this.Æ == 0)
      {
        if (d1 < 5.0D * this.ª.getBigBlindSize())
          return ¤();
        if (i < 5)
          if (d2 < d1 * 0.05D * (j != 0 ? 2 : 1) * (bool1 ? 2 : 1))
          {
            if ((i == 1) && (Math.random() < (12 - this.ª.getNumPlayers()) * 0.025D))
            {
              d5 = (d4 + d2) * (Math.random() < 0.25D ? 2 : 1);
              return D(d5);
            }
            return ¤();
          }
        if (d2 <= this.ª.getBigBlindSize())
          if (d2 < d1 * 0.02D * (j != 0 ? 2 : 1) * (bool1 ? 2 : 1))
            return ¤();
      }
      if (bool2)
      {
        com.biotools.poker.E.H("MANIAC CONTROL");
        if (Math.random() < 0.5D)
          return D(d4 + d2);
        return ¤();
      }
    }
    if (A(O("Group Five")))
    {
      if (d2 <= this.ª.getBigBlindSize())
      {
        if (m != 0)
        {
          d5 = (d4 + d2) * (Math.random() < 0.25D ? 2 : 1);
          return D(d5);
        }
        if ((j != 0) && (n == 0))
          return D(d4 + d2);
        return ¤();
      }
      if ((this.Æ == 0) && (i1 != 0))
      {
        if (d1 < 5.0D * this.ª.getBigBlindSize())
          return ¤();
        if (i < 5)
          if (d2 < d1 * 0.05D * (j != 0 ? 2 : 1) * (bool1 ? 2 : 1))
            return ¤();
      }
      if ((bool2) && (j != 0))
      {
        com.biotools.poker.E.H("MANIAC CONTROL");
        if (Math.random() < 0.5D)
          return D(d4 + d2);
        return ¤();
      }
    }
    if (A(O("Group Six")))
    {
      if ((k != 0) && (n == 0))
        return D(d1);
      if ((m != 0) && (n == 0))
        return D(d4 + d2);
      if (d2 < this.ª.getBigBlindSize())
        return ¤();
      if (this.Æ == 0)
      {
        if ((d2 <= this.ª.getBigBlindSize() * 3.0D) && (((n == 0) && (i <= 1)) || (m != 0)))
          return ¤();
        if (i < 5)
          if (d2 < d1 * 0.025D * (j != 0 ? 2 : 1) * (bool1 ? 2 : 1))
            return ¤();
      }
      if ((bool2) && (j != 0))
      {
        com.biotools.poker.E.H("MANIAC CONTROL");
        if ((Math.random() < 0.5D) && (m != 0))
          return D(d4 + d2);
        return ¤();
      }
    }
    if (A(O("Group Six-A")))
    {
      if ((k != 0) && (n == 0))
        return D(d1);
      if ((n == 0) && (i <= 3))
      {
        d5 = d4 + d2;
        return D(d5);
      }
      if ((i <= 3) && (d2 <= this.ª.getBigBlindSize()))
      {
        if (Math.random() < 0.2D)
        {
          d5 = d4 + d2;
          return D(d5);
        }
        if ((n >= 2) && (Math.random() < 0.25D))
          return ¤();
      }
      if (bool1)
        if ((d2 < d1 * 0.1D * (j != 0 ? 2 : 1)) && (d2 / d4 < 1.0D / n))
          return ¤();
      if ((bool2) && (j != 0))
      {
        com.biotools.poker.E.H("MANIAC CONTROL");
        return ¤();
      }
    }
    if (A(O("Group Seven")))
    {
      if ((d1 < 8.0D * this.ª.getBigBlindSize()) && (i1 != 0))
        return D(d1);
      if ((m != 0) && (n == 0))
        return D(d4 + d2);
      if (d2 < this.ª.getBigBlindSize())
        return ¤();
      if ((m != 0) && (d2 <= 3.0D * this.ª.getBigBlindSize()))
        return ¤();
      if ((this.Æ == 0) && (i < 5))
        if (d2 < d1 * 0.025D * (j != 0 ? 2 : 1) * (bool1 ? 2 : 1))
          return ¤();
      if ((bool2) && (m != 0))
      {
        com.biotools.poker.E.H("MANIAC CONTROL");
        if (Math.random() < 0.5D)
          return D(d4 + d2);
        return ¤();
      }
    }
    if ((A(O("Group Eight"))) && ((m != 0) || (Ç())))
    {
      if (d1 < 5.0D * this.ª.getBigBlindSize())
        return D(d1);
      if (n == 0)
        return D(d4 + d2);
      if (d2 <= 5.0D * this.ª.getBigBlindSize())
        return ¤();
      if ((this.Æ == 0) && (i < 5))
        if (d2 < d1 * 0.01D * (j != 0 ? 2 : 1) * (bool1 ? 2 : 1))
          return ¤();
      if ((bool2) && (m != 0))
      {
        com.biotools.poker.E.H("MANIAC CONTROL");
        if (Math.random() < 0.25D)
          return D(d4 + d2);
        return ¤();
      }
    }
    if ((A(O("Bluffs"))) && (!bool1) && (d2 <= this.ª.getBigBlindSize() * 6.0D) && (d1 > d4 * 5.0D))
    {
      d5 = this.ª.getNumToAct() / (this.ª.getNumActivePlayers() + 1.0D);
      if ((m != 0) || ((Math.random() > d5) && (this.Í < 0)))
      {
        double d6 = (d4 + d2) * (Math.random() < 0.25D ? 2 : 1);
        this.Ä = new C();
        this.Ä.F(0.25D);
        this.Ä.D(d2 > 0.0D ? 0.0D : 0.75D);
        this.Ä.B(d2 > 0.0D ? 0.75D : 0.0D);
        return D(d6);
      }
    }
    if (bool2)
    {
      if (this.¤.getRank() == this.¢.getRank())
      {
        com.biotools.poker.E.H("MANIAC CONTROL");
        return D(d1 - d2);
      }
      if (((this.¤.getRank() == 12) && (this.¤.getSuit() == this.¢.getSuit())) || ((this.¢.getRank() == 12) && (this.¤.getSuit() == this.¢.getSuit()) && ((j != 0) || (k != 0))))
      {
        com.biotools.poker.E.H("MANIAC CONTROL");
        return D(d1 - d2);
      }
    }
    if (d2 < this.ª.getBigBlindSize())
    {
      if (d2 < d1 * 0.05D * (m != 0 ? 2 : 1) * (bool1 ? 2 : 1))
        return ¤();
      if (d2 > d1 * 0.5D)
        return D(d1);
    }
    if (bool1)
      if (d2 <= this.ª.getBigBlindSize() * 1.0D * (m != 0 ? 2 : 1))
        return ¤();
    if (d2 / (d4 + d2) < 0.075D)
    {
      com.biotools.poker.E.H("Seeing flop with excellent pot odds");
      return ¤();
    }
    return d2 > 0.0D ? ¥() : ¤();
  }

  protected Action D(double paramDouble)
  {
    double d1 = this.ª.getPlayer(this.º).getBankRoll();
    double d2 = this.ª.getAmountToCall(this.º);
    if (d2 >= d1)
      return ¤();
    if (paramDouble < this.ª.getMinRaise())
      paramDouble = this.ª.getMinRaise();
    if (paramDouble + d2 > d1 * 0.5D)
      paramDouble = d1;
    if (paramDouble + d2 > d1)
      paramDouble = d1 - d2;
    if ((paramDouble + d2 < d1) && (paramDouble % this.ª.getSmallBlindSize() != 0.0D))
      paramDouble = this.ª.getSmallBlindSize() * (int)((paramDouble + this.ª.getSmallBlindSize()) / this.ª.getSmallBlindSize());
    if ((this.Ä == null) || (!this.Ä.F()))
      this.Ä = new C(0.0D, 0.0D, 1.0D);
    this.Ù = paramDouble;
    return Action.raiseAction(d2, paramDouble);
  }

  protected Action ¤()
  {
    if ((this.Ä == null) || (!this.Ä.F()))
      this.Ä = new C(0.0D, 1.0D, 0.0D);
    return super.¤();
  }

  protected Action ¥()
  {
    if ((this.Ä == null) || (!this.Ä.F()))
      this.Ä = new C(1.0D, 0.0D, 0.0D);
    return super.¥();
  }

  private String[] O(String paramString)
  {
    return (String[])this.Ý.get(paramString);
  }

  private void Å()
  {
    String[] arrayOfString1 = { "AA", "KK", "QQ", "JJ", "AKs" };
    this.Ý.put("Group One", arrayOfString1);
    String[] arrayOfString2 = { "TT", "AQs", "AKo", "AJs", "KQs" };
    this.Ý.put("Group Two", arrayOfString2);
    String[] arrayOfString3 = { "A8s", "KTs", "K9s", "QTs", "JTs" };
    this.Ý.put("Group Two-A", arrayOfString3);
    String[] arrayOfString4 = { "99", "AQo", "ATs", "KJs", "QJs", "AJo" };
    this.Ý.put("Group Three", arrayOfString4);
    String[] arrayOfString5 = { "88", "77", "KQo", "ATo", "KJo" };
    this.Ý.put("Group Four", arrayOfString5);
    String[] arrayOfString6 = { "66", "55", "44", "33", "22" };
    this.Ý.put("Group Five", arrayOfString6);
    String[] arrayOfString7 = { "T9s", "98s", "87s", "76s", "A5s", "A2s" };
    this.Ý.put("Group Six", arrayOfString7);
    String[] arrayOfString8 = { "QJo", "A9s", "65s", "54s", "T9o" };
    this.Ý.put("Group Six-A", arrayOfString8);
    String[] arrayOfString9 = { "A7s", "KTo", "K9o", "K8s", "JTo" };
    this.Ý.put("Group Seven", arrayOfString9);
    String[] arrayOfString10 = { "A7o", "A5o", "QTo", "A6s", "A4s", "A3s", "A9o", "A8o" };
    this.Ý.put("Group Eight", arrayOfString10);
    String[] arrayOfString11 = { "52s", "32o", "T4o", "92o", "A2s" };
    this.Ý.put("Bluffs", arrayOfString11);
  }

  public void N(String paramString)
  {
    if (paramString == null)
      return;
    String[] arrayOfString1 = paramString.split("\\|");
    for (int i = 0; i < arrayOfString1.length; i++)
    {
      String[] arrayOfString2 = arrayOfString1[i].split(",");
      if (arrayOfString2.length >= 2)
      {
        String str = arrayOfString2[(arrayOfString2.length - 1)];
        String[] arrayOfString3 = new String[arrayOfString2.length - 2];
        for (int j = 1; j < arrayOfString2.length - 1; j++)
          arrayOfString3[(j - 1)] = arrayOfString2[j];
        this.Ý.put(str, arrayOfString3);
      }
    }
  }

  private boolean A(String[] paramArrayOfString)
  {
    for (int i = 0; i < paramArrayOfString.length; i++)
      if (M(paramArrayOfString[i]))
        return true;
    return false;
  }

  public boolean M(String paramString)
  {
    if (this.¤.getRank() != Card.getRankFromChar(paramString.charAt(0)))
      return false;
    if (this.¢.getRank() != Card.getRankFromChar(paramString.charAt(1)))
      return false;
    if (paramString.length() > 2)
      if (paramString.charAt(2) == 's')
      {
        if (this.¤.getSuit() != this.¢.getSuit())
          return false;
      }
      else if (this.¤.getSuit() == this.¢.getSuit())
        return false;
    return true;
  }

  protected double A(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6)
  {
    double d1 = paramDouble1 + paramDouble2 + paramDouble3 + paramDouble4 + paramDouble5 + paramDouble6;
    paramDouble1 /= d1;
    paramDouble2 /= d1;
    paramDouble3 /= d1;
    paramDouble4 /= d1;
    paramDouble5 /= d1;
    paramDouble6 /= d1;
    double d2 = Math.random();
    double d3 = this.ª.getPlayer(this.º).getBankRoll();
    double d4 = this.ª.getAmountToCall(this.º);
    double d5 = this.ª.getEligiblePot(this.º) + d4;
    double d6 = d3;
    if (d2 <= paramDouble1)
      d6 = d5 / 4.0D;
    else if (d2 <= paramDouble1 + paramDouble2)
      d6 = d5 / 3.0D;
    else if (d2 <= paramDouble1 + paramDouble2 + paramDouble3)
      d6 = d5 / 2.0D;
    else if (d2 <= paramDouble1 + paramDouble2 + paramDouble3 + paramDouble4)
      d6 = d5;
    else if (d2 <= paramDouble1 + paramDouble2 + paramDouble3 + paramDouble4 + paramDouble5)
      d6 = d5 * 2.0D;
    if (d6 < this.ª.getMinRaise())
      d6 = this.ª.getMinRaise();
    if (d6 > d3)
      d6 = d3;
    return d6;
  }

  protected Action º()
  {
    double d1 = this.ª.getPlayer(this.º).getBankRoll();
    double d2 = this.ª.getPlayer(this.º).getBankRollAtRisk();
    double d3 = this.ª.getAmountToCall(this.º);
    if (d3 > d1)
      d3 = d1;
    double d4 = this.ª.getEligiblePot(this.º);
    int i = this.ª.getNumToAct() - 1;
    int j = this.ª.getNumPlayers() <= 4 ? 1 : 0;
    int k = this.ª.getNumPlayers() == 2 ? 1 : 0;
    int m = 0;
    for (int n = 0; n < this.ª.getNumSeats(); n++)
      if ((this.ª.isActive(n)) && (this.ª.getPlayer(n).isCommitted()) && (n != this.º))
        m++;
    this.Ä = new C();
    if ((!this.ª.isZipMode()) && (!this.ª.isSimulation()) && (d3 > 0.0D) && (d2 * 0.85D <= d3))
    {
      if (HandEvaluator.isTheNuts(this.¤, this.¢, this.ª.getBoard(), G.A(this.ª).ŷ()))
      {
        com.biotools.poker.E.H("Handling all-in situation: jamming with the nuts");
        return D(d1 - d3);
      }
      com.biotools.poker.E.H("Handling all-in situation: doing all-in equity calculation");
      return È();
    }
    this.µ.reset();
    this.µ.extractCard(this.¤);
    this.µ.extractCard(this.¢);
    this.µ.extractHand(this.ª.getBoard());
    double d5 = ¥.A(this.¤, this.¢, G.A(this.ª).ŷ(), this.µ);
    d5 = Math.pow(d5, this.ª.getNumActivePlayers() - 1);
    double d6 = A(this.º, this.¤, this.¢, G.A(this.ª).ŷ());
    if (HandEvaluator.isTheNuts(this.¤, this.¢, this.ª.getBoard(), G.A(this.ª).ŷ()))
      d6 = d5 = 1.0D;
    double d7 = 0.0D;
    double d8 = 0.0D;
    if (!this.ª.isRiver())
      if (this.ª.isZipMode())
      {
        d7 = A.A(this.¤, this.¢, this.ª.getBoard());
      }
      else
      {
        double[] arrayOfDouble = A.B(this.¤, this.¢, this.ª.getBoard(), ¥);
        d7 = arrayOfDouble[0];
        d8 = arrayOfDouble[1];
        if ((d3 == d2) && (this.ª.isFlop()))
        {
          A localA = new A();
          localA.A(this.¤, this.¢, this.ª.getBoard(), ¥, true);
          d7 = localA.B();
          d8 = localA.A();
          com.biotools.poker.E.H("Full PPOT: " + d7);
        }
      }
    com.biotools.poker.E.H(À() + " | " + this.¤ + "-" + this.¢ + " | " + " HRN = " + b.A(d5, 3) + " HSN = " + b.A(d6, 3) + " PP1 = " + b.A(d7, 3) + " NP1 = " + b.A(d8, 3));
    double d9 = 0.1D * Â() + (k != 0 ? 0.05D : 0.0D) - 0.05D;
    if (this.Ì)
      d9 = -0.02D;
    if ((!this.ª.isFlop()) && (this.Ê))
      d9 += 0.05D;
    double d10;
    double d13;
    double d15;
    double d14;
    double d11;
    if (d3 == 0.0D)
    {
      if (d6 > 0.9D - d9)
      {
        if ((this.ª.getStage() != 3) && (d8 < 0.125D))
        {
          d10 = 0.2D * (k != 0 ? 2 : 1) * (i + 1);
          this.Ä.D(d10);
          this.Ä.F(1.0D - d10);
          if (Math.random() < d10)
          {
            com.biotools.poker.E.H("Check-raising very strong hand");
            return ¤();
          }
        }
        com.biotools.poker.E.H("Betting very strong hand");
        d10 = A(this.ª.isRiver() ? 1 : 15, this.ª.isRiver() ? 1 : 15, 25.0D, 20.0D, 10.0D, 1.0D);
        this.Ä.F(1.0D - this.Ä.C());
        return D(d10);
      }
      if (d6 > 0.85D - d9)
      {
        if ((this.ª.getStage() != 3) && (d8 < 0.1D))
        {
          d10 = 0.15D * (k != 0 ? 2 : 1) * (i + 1);
          this.Ä.D(d10);
          this.Ä.F(1.0D - d10);
          if (Math.random() < d10)
          {
            com.biotools.poker.E.H("Check-raising strong hand");
            return ¤();
          }
        }
        com.biotools.poker.E.H("Betting strong hand");
        d10 = A(this.ª.isRiver() ? 1 : 10, this.ª.isRiver() ? 5 : 2, 25.0D, 25.0D, 2.0D, 1.0D);
        this.Ä.F(1.0D - this.Ä.C());
        return D(d10);
      }
      if (d6 > 0.8D - d9)
      {
        if ((!this.ª.isRiver()) && (d8 < 0.1D))
        {
          d10 = 0.15D * (k != 0 ? 2 : 1) * (i + 1);
          this.Ä.D(d10);
          this.Ä.F(1.0D - d10);
          if (Math.random() < d10)
          {
            com.biotools.poker.E.H("Check-raising strong hand");
            return ¤();
          }
        }
        com.biotools.poker.E.H("Betting strong hand");
        d10 = A(this.ª.isRiver() ? 5 : 15, this.ª.isRiver() ? 5 : 25, 25.0D, 20.0D, 5.0D, 0.0D);
        this.Ä.F(1.0D - this.Ä.C());
        return D(d10);
      }
      if (d6 > 0.7D - d9)
      {
        if ((d8 < 0.125D) && (d3 < 0.24D * d1))
        {
          d10 = 0.1D * (k != 0 ? 2 : 1) * (i + 1);
          this.Ä.D(d10);
          this.Ä.F(1.0D - d10);
          if (Math.random() < d10)
          {
            com.biotools.poker.E.H("checking medium strength hand");
            return ¤();
          }
        }
        d10 = A(this.ª.isRiver() ? 5 : 20, this.ª.isRiver() ? 5 : 20, 25.0D, 10.0D, 1.0D, 0.0D);
        d13 = 1.0D - i * 0.15D;
        if (this.ª.isRiver())
          d13 *= 0.75D;
        this.Ä.F(d13);
        this.Ä.D(1.0D - d13);
        if (Math.random() < d13)
        {
          com.biotools.poker.E.H("Betting medium-strong hand");
          return D(d10);
        }
      }
      if ((d6 > 0.5D - d9) && (d4 < d1 * 0.15D))
      {
        d10 = 0.25D;
        this.Ä.D(d10);
        this.Ä.F(1.0D - d10);
        if (Math.random() < d10)
        {
          com.biotools.poker.E.H("checking medium hand");
          return ¤();
        }
        d13 = A(this.ª.isRiver() ? 10 : 20, 20.0D, 20.0D, 50.0D, 1.0D, 0.0D);
        d15 = 1.0D - i * 0.15D;
        if (this.ª.isRiver())
          d15 *= 0.5D;
        this.Ä.F(d15);
        this.Ä.D(1.0D - d15);
        if (Math.random() < d15)
        {
          com.biotools.poker.E.H("Betting medium hand");
          return D(d13);
        }
      }
      else if ((d4 < d1 * 0.1D) && (!this.ª.isRiver()))
      {
        d10 = d6 / (i + 1.0D);
        this.Ä.D(1.0D - d10);
        this.Ä.F(d10);
        if (Math.random() < d10)
        {
          com.biotools.poker.E.H("Betting weak hand");
          d13 = A(5.0D, 5.0D, 10.0D, 15.0D, 1.0D, 0.0D);
          return D(d13);
        }
      }
      if ((d4 < d1 * 0.2D) && (((this.ª.getStage() >= 2) && (this.Ê)) || (i == 0)))
      {
        d10 = Æ();
        this.Ä.D(1.0D - d10);
        this.Ä.F(d10);
        if (Math.random() < d10)
        {
          com.biotools.poker.E.H("poking with weak hand");
          d13 = A(5.0D, 10.0D, 10.0D, 15.0D, 0.0D, 0.0D);
          return D(d13);
        }
      }
    }
    else
    {
      if (d6 >= 0.95D - d9)
      {
        if ((!this.ª.isRiver()) && (d8 < 0.125D))
        {
          d10 = 0.25D * (i + 1);
          if (d10 > 1.0D)
            d10 = 1.0D;
          this.Ä.D(d10);
          this.Ä.F(1.0D - d10);
          if (Math.random() < d10)
          {
            com.biotools.poker.E.H("Slow-playing very strong hand");
            return ¤();
          }
        }
        this.Ä.F(1.0D - this.Ä.C());
        com.biotools.poker.E.H("Re-Raise with very strong hand");
        d10 = A(1.0D, 2.0D, 5.0D, 15.0D, 15.0D, 10.0D);
        return D(d10);
      }
      if (d6 >= 0.85D - d9)
      {
        if ((!this.ª.isRiver()) && (d8 < 0.1D))
        {
          d10 = 0.1D * (k != 0 ? 2 : 1) * (i + 1);
          this.Ä.D(d10);
          this.Ä.F(1.0D - d10);
          if (Math.random() < d10)
          {
            com.biotools.poker.E.H("Slow-playing strong hand");
            return ¤();
          }
        }
        this.Ä.F(1.0D - this.Ä.C());
        com.biotools.poker.E.H("Re-Raise with Strong Hand");
        d10 = A(1.0D, 2.0D, 10.0D, 25.0D, 5.0D, 1.0D);
        return D(d10);
      }
      int i1;
      double d12;
      if (d6 >= 0.75D - d9)
      {
        i1 = 0;
        if (this.ª.isRiver())
        {
          if ((k != 0) || ((Math.random() < 0.85D) && (d3 < d1 * (0.5D / (i + 1.0D)))))
            i1 = 1;
        }
        else if (((Math.random() < 0.75D) && (d3 < d1 * 0.2D)) || (d2 < this.ª.getSmallBlindSize() * 6.0D))
          i1 = 1;
        d12 = 0.2D;
        if (k != 0)
          d12 += 0.2D;
        if (this.ª.isFlop())
          d12 += 0.15D;
        if ((this.ª.isTurn()) && (this.Ê))
          d12 += 0.1D;
        if (i == 0)
          d12 += 0.2D;
        if (d3 > d1 * 0.1D)
          d12 *= 0.5D;
        if (d3 + d4 > 0.33D * d1)
          d12 *= 0.5D;
        this.Ä.F(d12);
        if (i1 != 0)
          this.Ä.D(1.0D - d12);
        if (Math.random() < d12)
        {
          com.biotools.poker.E.H("Re-Raise with Strong Hand");
          d14 = A(1.0D, 1.0D, 10.0D, 25.0D, 2.0D, 1.0D);
          return D(d14);
        }
        if (i1 != 0)
        {
          com.biotools.poker.E.H("Call with Strong Hand");
          return ¤();
        }
      }
      else if (d6 >= 0.65D - d9)
      {
        i1 = 0;
        if (((d3 < d1 * (k != 0 ? 0.1D : 0.25D)) && (d6 * d6 * d4 > d3)) || (d2 < this.ª.getSmallBlindSize() * 6.0D))
          i1 = 1;
        d12 = A(1.0D, 5.0D, 25.0D, 50.0D, 5.0D, 1.0D);
        d14 = 0.1D;
        if (i == 0)
          d14 += 0.1D;
        if (k != 0)
          d14 += 0.1D;
        if (this.ª.isFlop())
          d14 += 0.1D;
        if ((this.ª.isTurn()) && (this.Ê))
          d14 += 0.1D;
        if (d3 > d1 * 0.1D)
          d14 *= 0.5D;
        if (d3 + d4 > 0.33D * d1)
          d14 *= 0.5D;
        this.Ä.F(d14);
        if (i1 != 0)
          this.Ä.D(1.0D - d14);
        if (Math.random() < d14)
        {
          com.biotools.poker.E.H("Re-Raise with Medium Hand");
          return D(d12);
        }
        if (i1 != 0)
        {
          com.biotools.poker.E.H("Call with Medium Hand");
          return ¤();
        }
      }
      else if (d6 >= 0.5D - d9)
      {
        if (((k != 0) && (d3 < d1 * 0.1D)) || ((i == 0) && (d3 < d1 * 0.05D)))
        {
          d11 = A(1.0D, 5.0D, 10.0D, 20.0D, 1.0D, 1.0D);
          return D(d11);
        }
        if ((d3 < d1 * (k != 0 ? 0.1D : 0.2D)) && ((k != 0) || ((d7 + d6) * 0.5D * d4 > d3)) && (i == 0))
        {
          com.biotools.poker.E.H("Call with Medium-low Hand");
          return ¤();
        }
      }
      else if (d6 >= 0.4D - d9)
      {
        if ((k != 0) && (d3 < d1 * 0.1D))
        {
          d11 = A(1.0D, 1.0D, 10.0D, 25.0D, 1.0D, 1.0D);
          return D(d11);
        }
        if ((d3 < d1 * (k != 0 ? 0.075D : 0.15D)) && ((k != 0) || ((d7 + d6) * 0.5D * d4 > d3)))
        {
          com.biotools.poker.E.H("Call with weak Hand");
          return ¤();
        }
      }
    }
    if (d2 - d3 > d4)
    {
      d11 = k != 0 ? d7 * 1.5D : d7;
      if (this.ª.getNumRaises() == 0)
      {
        if (d7 < 0.2D)
          d11 = this.Æ == 0 ? 0.05D : 0.0D;
      }
      else
      {
        if (d7 > 0.2D)
          d11 += 0.35D;
        if ((Ê()) && (m == 0))
        {
          com.biotools.poker.E.H("Bluffing on a raggy board");
          d11 += Æ();
        }
      }
      if (d11 > 1.0D)
        d11 = 1.0D;
      if (Math.random() < d11)
      {
        d13 = (d4 + d3) * ((m == 0) && (Math.random() < d7) ? 2 : 1);
        if (Math.random() < 0.75D)
        {
          d13 = A(5.0D, 5.0D, 10.0D, 5.0D, 5.0D, 0.0D);
          if ((this.ª.isFlop()) && (Math.random() < 0.5D))
            d13 = A(5.0D, 5.0D, 10.0D, 5.0D, 0.0D, 0.0D);
        }
        if (((d3 <= 0.0D) || (d13 <= d1 / 4.0D)) && ((k != 0) || (d13 < d1 * 0.25D)))
        {
          this.Ä.F(d11);
          this.Ä.D(1.0D - d11);
          com.biotools.poker.E.H("Semi Bluff");
          return D(d13);
        }
      }
    }
    if (d3 > 0.0D)
    {
      d11 = d3 / (d4 + d3);
      com.biotools.poker.E.H("POT ODDS: " + d11);
      if (d7 > d11)
      {
        com.biotools.poker.E.H("Draw Odds: " + d7 + ">" + d11);
        return ¤();
      }
      if (Ä())
      {
        d13 = d4 * É() + d3;
        if (d13 > d2 - d3)
          d13 = d2 - d3;
        d15 = d3 / (d4 + d3 + d13);
        if (d7 > d15)
        {
          com.biotools.poker.E.H("Implied Draw Odds: " + d13);
          return ¤();
        }
      }
      if (this.ª.getStage() == 3)
      {
        if ((d3 <= d1 * (k != 0 ? 1.0D : 0.5D)) && (d6 * Ã() > d11))
        {
          com.biotools.poker.E.H("Showdown odds");
          return ¤();
        }
        if (d6 * Ã() > 5.0D * d11)
        {
          com.biotools.poker.E.H("Showdown odds");
          return ¤();
        }
      }
      else if (d5 > 0.45D)
      {
        com.biotools.poker.N.D.B localB = new com.biotools.poker.N.D.B();
        d14 = d6 - d8 + d7;
        if ((!this.ª.isZipMode()) && (!this.ª.isSimulation()))
          d14 = localB.B(this.º, this.¤, this.¢, this.ª);
        double d16 = 1.0D;
        if (d1 > this.ª.getBigBlindSize() * 25.0D)
          d16 = 2.0D;
        else if (d1 < this.ª.getBigBlindSize() * 8.0D)
          d16 = 0.75D;
        if (d3 / d1 > 0.5D)
          d16 *= 2.0D;
        if (d14 * Ã() > d16 * d11)
        {
          com.biotools.poker.E.H("Showdown odds");
          return ¤();
        }
      }
    }
    return d3 == 0.0D ? ¤() : ¥();
  }

  private boolean Ê()
  {
    for (int i = 0; i < this.ª.getBoard().size(); i++)
      if (this.ª.getBoard().getCard(i + 1).getRank() > 8)
        return false;
    return true;
  }

  public double l()
  {
    return A(this.º, this.¤, this.¢, G.A(this.ª).ŷ());
  }

  public C h()
  {
    return this.Ä;
  }

  public double g()
  {
    return this.Ù;
  }

  private Action È()
  {
    com.biotools.poker.N.D.B localB = new com.biotools.poker.N.D.B();
    double d1 = localB.B(this.º, this.¤, this.¢, this.ª);
    double d2 = this.ª.getAmountToCall(this.º);
    double d3 = this.ª.getEligiblePot(this.º);
    double d4 = d2 / (d2 + d3);
    double d5 = 0.5D + 0.5D * Ã();
    double d6 = this.ª.getPlayer(this.º).getBankRoll();
    if (d2 < 0.25D * d6)
      d5 = 1.0D;
    if (this.Æ > 0)
      d5 *= Math.pow(0.8D, this.Æ);
    if (d2 > this.ª.getBigBlindSize() * 15.0D)
      d5 *= 0.75D;
    if (d1 * d5 > d4)
    {
      com.biotools.poker.E.H("Calling with showdown odds (AIE=" + d1 + ", PO=" + d4 + ", gear=" + d5 + ")");
      return ¤();
    }
    com.biotools.poker.E.H("Odds not good enough to call(AIE=" + d1 + ", PO=" + d4 + ", gear=" + d5 + ")");
    return ¥();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.I
 * JD-Core Version:    0.6.2
 */