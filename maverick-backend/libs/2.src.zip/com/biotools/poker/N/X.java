package com.biotools.poker.N;

import com.biotools.poker.D.C;

public class X
{
  public static boolean A = false;

  public void A(String paramString)
  {
  }

  public void B(String paramString)
  {
  }

  public static C A(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, double paramDouble5, double paramDouble6, boolean paramBoolean2, double paramDouble7, double paramDouble8)
  {
    double d1 = paramDouble4 / (paramDouble5 + paramDouble4);
    double d2 = paramDouble4 / (paramInt2 < 2 ? paramDouble6 : paramDouble6 * 2.0D);
    double d3 = paramDouble3 + (1.0D - paramDouble3) * paramDouble1;
    if (paramInt2 == 3)
    {
      d3 = paramDouble3;
      paramDouble1 = paramDouble2 = 0.0D;
    }
    double d4 = 1.0D;
    double d5 = 0.0D;
    double d6 = 0.0D;
    double d7;
    if (d3 >= paramDouble8)
    {
      d4 = 0.0D;
      if (paramInt3 <= 1)
      {
        d5 = 0.0D;
        d6 = 1.0D;
      }
      else
      {
        d6 = 0.0D;
        if (d3 >= 0.9D)
          d6 = 10.0D * (d3 - 0.9D);
        d5 = 1.0D - d6;
      }
      if ((paramDouble2 < 0.1D) && ((paramInt2 < 3) || (paramInt1 > 1)))
      {
        d7 = 0.125D - paramDouble2 + paramDouble3 * paramDouble1 * 0.5D;
        d5 += d6 * d7;
        d6 *= (1.0D - d7);
      }
    }
    else if (d3 >= paramDouble7)
    {
      if (d2 == 0.0D)
      {
        d4 = 0.0D;
        if (paramInt3 >= 0)
        {
          d6 = 0.0D;
          d7 = paramDouble8 - 0.2D;
          if (d3 >= d7)
            d6 = 5.0D * (d3 - d7);
          d5 = 1.0D - d6;
        }
        else
        {
          d5 = 0.0D;
          d6 = 1.0D;
        }
      }
      else if ((d2 == 1.0D) || (paramBoolean1))
      {
        d6 = 0.0D;
        d7 = paramDouble8 - 0.2D;
        if ((d3 >= d7) && (d2 <= 1.0D))
        {
          d6 = 5.0D * (d3 - d7);
          d6 *= (0.75D + 0.25D / paramInt1);
        }
        d4 = 0.0D;
        d5 = 1.0D - d6;
      }
    }
    else if (d2 == 0.0D)
    {
      d6 = 0.0D;
      d7 = paramDouble7 - 0.25D;
      if (d3 >= d7)
      {
        d6 = 4.0D * (d3 - d7);
        d6 *= (0.25D + 0.75D / paramInt1);
      }
      d4 = 0.0D;
      d5 = 1.0D - d6;
    }
    if (d4 == 1.0D)
      if (((paramInt2 == 3) && (d3 >= d1)) || (paramDouble1 >= d1))
      {
        d4 = 0.0D;
        d5 = 1.0D;
        d6 = 0.0D;
      }
      else if (paramBoolean2)
      {
        if (paramInt2 == 1)
          d7 = paramDouble6 * 4.0D;
        else if (paramInt2 == 2)
          d7 = paramDouble6;
        else
          d7 = 0.0D;
        double d8 = (paramDouble4 + d7) / (paramDouble5 + paramDouble4 + 2.0D * d7);
        if (paramInt2 != 3)
          d3 -= paramDouble3 * paramDouble2;
        if (d3 >= d8)
        {
          d4 = 0.0D;
          d5 = 1.0D;
          d6 = 0.0D;
        }
      }
    return new C(d4, d5, d6);
  }

  public static C A(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt, double paramDouble5, double paramDouble6)
  {
    double d1 = 1.0D - paramDouble1;
    double d9 = paramDouble2 + (1.0D - paramDouble2) * paramDouble3;
    double d10 = !A(paramDouble4, 0.0D) ? paramDouble3 / paramDouble4 : paramDouble3 / 0.001D;
    double d5;
    double d4;
    double d3;
    double d2 = d3 = d4 = d5 = 0.0D;
    double d8;
    double d7;
    double d6 = d7 = d8 = 0.0D;
    if (paramInt > 2)
      paramInt = 2;
    switch (paramInt)
    {
    case 0:
      if (d9 > paramDouble6 + 0.25D)
      {
        d8 = d1;
        d7 = 1.0D - d8;
        d6 = 0.0D;
      }
      else if (d9 > paramDouble6 - 0.25D)
      {
        d4 = 2.0D * (d9 - (paramDouble6 - 0.25D));
        d4 = d4 > d1 ? d1 : d4 < paramDouble1 ? paramDouble1 : d4;
        d8 = d4;
        d7 = 1.0D - d8;
        d6 = 0.0D;
      }
      else
      {
        d8 = paramDouble1;
        d7 = 1.0D - d8;
        d6 = 0.0D;
      }
      break;
    case 1:
      if (d9 > paramDouble6 + 0.1D)
      {
        d8 = d1;
        d7 = 1.0D - d8;
        d6 = 0.0D;
      }
      else if (d9 > paramDouble6 - 0.1D)
      {
        d4 = 5.0D * (d9 - (paramDouble6 - 0.1D));
        d4 = d4 > d1 ? d1 : d4 < paramDouble1 ? paramDouble1 : d4;
        d8 = d4;
        d7 = 1.0D - d8;
        d6 = 0.0D;
      }
      else if (d9 > paramDouble5 + 0.125D)
      {
        d8 = paramDouble1;
        d7 = 1.0D - 2.0D * paramDouble1;
        d6 = paramDouble1;
      }
      else
      {
        if (d9 > paramDouble5 - 0.125D)
          d3 = 4.0D * (d9 - (paramDouble5 - 0.125D));
        else
          d3 = 0.0D;
        if (d10 >= 1.0D)
          d5 = 1.0D;
        else if (d10 <= 0.5D)
          d5 = 0.0D;
        else
          d5 = 2.0D * (d10 - 0.5D);
        d3 = 1.0D - (1.0D - d3) * (1.0D - d5);
        d6 = (1.0D - d3) * (d1 - 2.0D * paramDouble1) + paramDouble1;
        d7 = d3 * (d1 - 2.0D * paramDouble1) + paramDouble1;
        d8 = paramDouble1;
      }
      break;
    case 2:
    default:
      if (d9 > paramDouble6 + 0.05D)
      {
        d8 = d1;
        d7 = 1.0D - d8;
        d6 = 0.0D;
      }
      else if (d9 > paramDouble6 - 0.05D)
      {
        d4 = 10.0D * (d9 - (paramDouble6 - 0.05D));
        d4 = d4 > d1 ? d1 : d4 < paramDouble1 ? paramDouble1 : d4;
        d8 = d4;
        d7 = 1.0D - d8;
        d6 = 0.0D;
      }
      else if (d9 > paramDouble5 + 0.1D)
      {
        d8 = paramDouble1;
        d7 = 1.0D - 2.0D * paramDouble1;
        d6 = paramDouble1;
      }
      else
      {
        if (d9 > paramDouble5 - 0.1D)
          d3 = 5.0D * (d9 - (paramDouble5 - 0.1D));
        else
          d3 = 0.0D;
        if (d10 >= 1.0D)
          d5 = 1.0D;
        else if (d10 <= 0.5D)
          d5 = 0.0D;
        else
          d5 = 2.0D * (d10 - 0.5D);
        d3 = 1.0D - (1.0D - d3) * (1.0D - d5);
        d6 = (1.0D - d3) * (d1 - 2.0D * paramDouble1) + paramDouble1;
        d7 = d3 * (d1 - 2.0D * paramDouble1) + paramDouble1;
        d8 = paramDouble1;
      }
      break;
    }
    return new C(d6, d7, d8);
  }

  private static boolean A(double paramDouble1, double paramDouble2)
  {
    if (paramDouble1 > paramDouble2)
      return paramDouble1 - paramDouble2 < 0.01D;
    return paramDouble2 - paramDouble1 < 0.01D;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.X
 * JD-Core Version:    0.6.2
 */