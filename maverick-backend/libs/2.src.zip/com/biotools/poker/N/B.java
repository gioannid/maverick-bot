package com.biotools.poker.N;

import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.Player;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.N.B.K;

public class B
  implements Player
{
  J ƀ = new J();
  D ſ = new D();
  GameInfo ž;

  public void init(Preferences paramPreferences)
  {
    this.ƀ.init(paramPreferences);
    this.ſ.init(paramPreferences);
  }

  public void holeCards(Card paramCard1, Card paramCard2, int paramInt)
  {
    if (this.ž.getNumPlayers() == 2)
      this.ƀ.holeCards(paramCard1, paramCard2, paramInt);
    this.ſ.holeCards(paramCard1, paramCard2, paramInt);
  }

  public Action getAction()
  {
    if (this.ž.getNumPlayers() == 2)
      return this.ƀ.getAction();
    if (this.ž.getNumPlayers() <= 4)
      this.ſ.U().A(2);
    else
      this.ſ.U().A(this.ſ.W());
    return this.ſ.getAction();
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
    if (this.ž.getNumPlayers() == 2)
      this.ƀ.actionEvent(paramInt, paramAction);
    this.ſ.actionEvent(paramInt, paramAction);
  }

  public void stageEvent(int paramInt)
  {
    if (this.ž.getNumPlayers() == 2)
      this.ƀ.stageEvent(paramInt);
    this.ſ.stageEvent(paramInt);
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
    if (this.ž.getNumPlayers() == 2)
      this.ƀ.showdownEvent(paramInt, paramCard1, paramCard2);
    this.ſ.showdownEvent(paramInt, paramCard1, paramCard2);
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    this.ž = paramGameInfo;
    if (paramGameInfo.getNumPlayers() == 2)
      this.ƀ.gameStartEvent(paramGameInfo);
    this.ſ.gameStartEvent(paramGameInfo);
  }

  public void gameOverEvent()
  {
    if (this.ž.getNumPlayers() == 2)
      this.ƀ.gameOverEvent();
    this.ſ.gameOverEvent();
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
    if (this.ž.getNumPlayers() == 2)
      this.ƀ.winEvent(paramInt, paramDouble, paramString);
    this.ſ.winEvent(paramInt, paramDouble, paramString);
  }

  public void gameStateChanged()
  {
    if (this.ž.getNumPlayers() == 2)
      this.ƀ.gameStateChanged();
    this.ſ.gameStateChanged();
  }

  public void dealHoleCardsEvent()
  {
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.N.B
 * JD-Core Version:    0.6.2
 */