package com.biotools.poker.G;

import com.biotools.poker.E;
import org.w3c.dom.Element;
import org.xml.sax.Attributes;

public class N
{
  public static final String O = "payout_by_finish";
  public static final String H = "min_finish";
  public static final String J = "max_finish";
  public static final String E = "payout_value";
  public static final String N = "payout_units";
  public static final String G = "UNKNOWN";
  public static final int L = -1;
  public static final String A = "%";
  public static final int D = 0;
  public static final String M = "$";
  public static final int B = 1;
  int K = 0;
  int I = 0;
  double F = 0.0D;
  int C = 0;

  public N(int paramInt1, int paramInt2, double paramDouble, int paramInt3)
  {
    this.K = paramInt1;
    this.I = paramInt2;
    this.F = paramDouble;
    this.C = paramInt3;
  }

  public boolean B(int paramInt)
  {
    return (paramInt >= this.K) && (paramInt <= this.I);
  }

  public int A()
  {
    return this.K;
  }

  public int C()
  {
    return this.I;
  }

  public int E()
  {
    return C() - A() + 1;
  }

  public double F()
  {
    return this.F;
  }

  public void A(double paramDouble)
  {
    this.F = paramDouble;
  }

  public int D()
  {
    return this.C;
  }

  public void C(int paramInt)
  {
    switch (paramInt)
    {
    case 0:
      this.C = paramInt;
      break;
    case 1:
      this.C = paramInt;
    }
  }

  public static String A(int paramInt)
  {
    String str = "UNKNOWN";
    switch (paramInt)
    {
    case 0:
      str = "%";
      break;
    case 1:
      str = "$";
    }
    return str;
  }

  public static int A(String paramString)
  {
    if (paramString.equals("%"))
      return 0;
    if (paramString.equals("$"))
      return 1;
    return -1;
  }

  public com.biotools.A.N B()
  {
    com.biotools.A.N localN = new com.biotools.A.N("payout_by_finish");
    localN.A("min_finish", this.K);
    localN.A("max_finish", this.I);
    localN.A("payout_value", this.F);
    localN.A("payout_units", A(this.C));
    return localN;
  }

  public static N A(Element paramElement, int paramInt1, int paramInt2)
  {
    int i = 1;
    int j = paramInt1;
    if (paramElement.hasAttribute("min_finish"))
      try
      {
        j = Integer.parseInt(paramElement.getAttribute("min_finish"));
        if (j != paramInt1)
        {
          E.H("min_finish should be " + paramInt1);
          j = paramInt1;
        }
        else
        {
          i = 0;
        }
      }
      catch (NumberFormatException localNumberFormatException1)
      {
        E.H(localNumberFormatException1.toString());
        localNumberFormatException1.printStackTrace();
      }
    int k = paramInt2;
    if (paramElement.hasAttribute("max_finish"))
      try
      {
        k = Integer.parseInt(paramElement.getAttribute("max_finish"));
        if (k > paramInt2)
        {
          E.H("max_finish cannot be greater than " + paramInt2);
          k = paramInt2;
        }
        else if (k < j)
        {
          E.H("max_finish cannot be less than min_finish");
          k = j;
        }
        else
        {
          i = 0;
        }
      }
      catch (NumberFormatException localNumberFormatException2)
      {
        E.H(localNumberFormatException2.toString());
        localNumberFormatException2.printStackTrace();
      }
    double d = 0.0D;
    if (paramElement.hasAttribute("payout_value"))
      try
      {
        d = Double.parseDouble(paramElement.getAttribute("payout_value"));
      }
      catch (NumberFormatException localNumberFormatException3)
      {
        E.H(localNumberFormatException3.toString());
        localNumberFormatException3.printStackTrace();
      }
    int m = 0;
    if (paramElement.hasAttribute("payout_units"))
      try
      {
        m = A(paramElement.getAttribute("payout_units"));
        if (m == 0)
          if ((d < 0.0D) || (d > 100.0D))
          {
            E.H("payout_value has to be between 0.0 and 100.0 inclusive");
            d = 0.0D;
          }
          else
          {
            i = 0;
          }
      }
      catch (NumberFormatException localNumberFormatException4)
      {
        E.H(localNumberFormatException4.toString());
        localNumberFormatException4.printStackTrace();
      }
    if (i != 0)
      E.H("Creating a payout with nothing but the default values!!");
    return new N(j, k, d, m);
  }

  public static N A(Element paramElement)
  {
    int i = 1;
    if (paramElement.hasAttribute("min_finish"))
      try
      {
        i = Integer.parseInt(paramElement.getAttribute("min_finish"));
      }
      catch (NumberFormatException localNumberFormatException1)
      {
        E.H(localNumberFormatException1.toString());
        localNumberFormatException1.printStackTrace();
      }
    int j = 1;
    if (paramElement.hasAttribute("max_finish"))
      try
      {
        j = Integer.parseInt(paramElement.getAttribute("max_finish"));
      }
      catch (NumberFormatException localNumberFormatException2)
      {
        E.H(localNumberFormatException2.toString());
        localNumberFormatException2.printStackTrace();
      }
    double d = 0.0D;
    if (paramElement.hasAttribute("payout_value"))
      try
      {
        d = Double.parseDouble(paramElement.getAttribute("payout_value"));
      }
      catch (NumberFormatException localNumberFormatException3)
      {
        E.H(localNumberFormatException3.toString());
        localNumberFormatException3.printStackTrace();
      }
    int k = 0;
    if (paramElement.hasAttribute("payout_units"))
      try
      {
        k = A(paramElement.getAttribute("payout_units"));
        if ((k == 0) && ((d < 0.0D) || (d > 100.0D)))
        {
          E.H("payout_value has to be between 0.0 and 100.0 inclusive");
          d = 0.0D;
        }
      }
      catch (NumberFormatException localNumberFormatException4)
      {
        E.H(localNumberFormatException4.toString());
        localNumberFormatException4.printStackTrace();
      }
    return new N(i, j, d, k);
  }

  public static N A(Attributes paramAttributes, int paramInt1, int paramInt2)
  {
    int i = 1;
    int j = paramInt1;
    int k = paramInt2;
    double d = 0.0D;
    int m = 0;
    String str = paramAttributes.getValue("min_finish");
    if (str != null)
      j = Integer.parseInt(str);
    if (j != paramInt1)
    {
      E.H("min_finish should be " + paramInt1);
      j = paramInt1;
    }
    else
    {
      i = 0;
    }
    str = paramAttributes.getValue("max_finish");
    if (str != null)
      k = Integer.parseInt(str);
    if (k > paramInt2)
    {
      E.H("max_finish cannot be greater than " + paramInt2);
      k = paramInt2;
    }
    else if (k < j)
    {
      E.H("max_finish cannot be less than min_finish");
      k = j;
    }
    else
    {
      i = 0;
    }
    str = paramAttributes.getValue("payout_value");
    if (str != null)
      d = Double.parseDouble(str);
    str = paramAttributes.getValue("payout_units");
    if (str != null)
      m = A(str);
    if (m == 0)
      if (d < 0.0D)
      {
        E.H("payout_value has to be between 0.0 and 100.0 inclusive");
        d = 0.0D;
      }
      else if (d > 100.0D)
      {
        E.H("payout_value has to be between 0.0 and 100.0 inclusive");
        d = 100.0D;
      }
      else
      {
        i = 0;
      }
    if (i != 0)
      E.H("Creating a payout with nothing but the default values!!");
    return new N(j, k, d, m);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.N
 * JD-Core Version:    0.6.2
 */