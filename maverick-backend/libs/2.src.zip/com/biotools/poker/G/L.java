package com.biotools.poker.G;

import com.biotools.meerkat.Action;
import com.biotools.poker.Q.D;
import com.biotools.poker.Q.K;

public class L extends T
{
  public L()
  {
    this.B = true;
  }

  public L(T paramT)
  {
    this.D = paramT.D;
    this.I = paramT.I;
    this.H = paramT.H;
    this.E = paramT.E;
    this.B = true;
  }

  public void A(K paramK)
  {
    D localD = paramK.C();
    e locale = G(0);
    double d1 = locale.R();
    double d2 = locale.M();
    double d3 = Y() ? d2 : d2 * 2.0D;
    localD.A(d1, d2, d3);
  }

  public void B(double paramDouble1, double paramDouble2)
  {
    e locale = G(0);
    locale.C(paramDouble1);
    locale.B(paramDouble2);
  }

  public String q()
  {
    e locale = G(0);
    if (Y())
      return Action.formatCash(locale.R()) + " / " + Action.formatCash(locale.M());
    return Action.formatCash(locale.M()) + " / " + Action.formatCash(locale.M() * 2.0D);
  }

  public double Â()
  {
    e locale = G(0);
    return locale.M();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.L
 * JD-Core Version:    0.6.2
 */