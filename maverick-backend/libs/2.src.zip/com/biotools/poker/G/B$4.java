package com.biotools.poker.G;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

final class B$4
  implements ActionListener
{
  final B this$0;

  B$4(B paramB)
  {
  }

  public void actionPerformed(ActionEvent paramActionEvent)
  {
    B.access$4(this.this$0);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.B.4
 * JD-Core Version:    0.6.2
 */