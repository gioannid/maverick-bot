package com.biotools.poker.G;

import com.biotools.meerkat.Action;
import com.biotools.poker.E;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class A
{
  public static final String B = "tourn_payouts";
  private String C;
  List A = new ArrayList();
  private static final boolean D = true;

  public A()
  {
  }

  public A(A paramA)
  {
    this.C = new String(paramA.D());
    for (int i = 0; i < paramA.B().size(); i++)
      A(new a((a)paramA.B().get(i)));
  }

  public void A(a parama)
  {
    if (parama == null)
      return;
    this.A.add(parama);
  }

  public List B()
  {
    return this.A;
  }

  public void D(int paramInt)
  {
    if (!this.A.isEmpty())
      if (paramInt < 2)
      {
        E.H("Has to be at least 2 players in a tournament!");
      }
      else
      {
        Iterator localIterator = this.A.iterator();
        while (localIterator.hasNext())
        {
          a locala = (a)localIterator.next();
          if (!locala.C(paramInt))
            if ((this.A.size() == 1) && (!localIterator.hasNext()))
            {
              if (locala.E() > paramInt)
                localIterator.remove();
              E.H("Tried to prune entire payout struct");
            }
            else
            {
              localIterator.remove();
            }
        }
      }
    if (this.A.isEmpty())
    {
      E.H("Pruned away the entire payouts table!");
      this.A.add(A());
    }
  }

  private a A()
  {
    N localN = new N(1, 1, 100.0D, 0);
    a locala = new a(2, 10000);
    locala.A(localN);
    return locala;
  }

  public void B(int paramInt)
  {
    if (this.A.isEmpty())
      return;
    if (paramInt < 2)
    {
      E.H("Has to be at least 2 players in a tournament!");
      return;
    }
    Iterator localIterator = this.A.iterator();
    while (localIterator.hasNext())
    {
      a locala = (a)localIterator.next();
      if (locala.E() > paramInt)
        localIterator.remove();
    }
    if (this.A.isEmpty())
    {
      E.H("Pruned away the entire payouts table!");
      this.A.add(A());
      if (!$assertionsDisabled)
        throw new AssertionError();
    }
  }

  public void E()
  {
    if (this.A.isEmpty())
      return;
    Iterator localIterator = this.A.iterator();
    while (localIterator.hasNext())
    {
      a locala = (a)localIterator.next();
      locala.C();
    }
  }

  public double A(int paramInt1, int paramInt2)
  {
    if (this.A == null)
      return 0.0D;
    Iterator localIterator = this.A.iterator();
    while (localIterator.hasNext())
    {
      a locala = (a)localIterator.next();
      if ((locala.C(paramInt1)) || (!localIterator.hasNext()))
        return locala.B(paramInt2);
    }
    return 0.0D;
  }

  public int C(int paramInt)
  {
    if (this.A == null)
      return 0;
    Iterator localIterator = this.A.iterator();
    while (localIterator.hasNext())
    {
      a locala = (a)localIterator.next();
      if ((locala.C(paramInt)) || (!localIterator.hasNext()))
        return locala.D();
    }
    return 0;
  }

  public a A(int paramInt)
  {
    if (this.A != null)
    {
      Iterator localIterator = this.A.iterator();
      while (localIterator.hasNext())
      {
        a locala = (a)localIterator.next();
        if ((locala.C(paramInt)) || (!localIterator.hasNext()))
          return locala;
      }
    }
    return A();
  }

  public com.biotools.A.N C()
  {
    com.biotools.A.N localN = new com.biotools.A.N("tourn_payouts");
    if (this.A != null)
    {
      Iterator localIterator = this.A.iterator();
      while (localIterator.hasNext())
      {
        a locala = (a)localIterator.next();
        localN.A(locala.B());
      }
    }
    return localN;
  }

  public void A(String paramString)
  {
    this.C = paramString;
  }

  public String D()
  {
    return this.C;
  }

  public String toString()
  {
    return D();
  }

  public String A(int paramInt, double paramDouble)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<html>");
    String str1 = "#aaaacc";
    String str2 = "#ddddff";
    String str3 = "white";
    localStringBuffer.append("<center><table border=\"0\" width=\"100%\"><tr bgcolor=" + str1 + "><td align=center>" + "<font face=Arial size=3>" + E.D("TournamentPayouts.Place") + "</td>" + "<td align=center>" + "<font face=Arial size=3>" + E.D("TournamentPayouts.Payout") + "</td>" + "<td align=center>" + "<font face=Arial size=3>" + E.D("TournamentPayouts.Prize") + "</td></tr>");
    localStringBuffer.append("<ol>");
    a locala = A(paramInt);
    List localList = null;
    if (locala != null)
      localList = locala.A();
    if (localList != null)
    {
      int i = 1;
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        N localN = (N)localIterator.next();
        int j = localN.A();
        int k = localN.C();
        double d1 = localN.F();
        int m = localN.D();
        if (m == 0)
        {
          double d2 = paramDouble * (d1 / 100.0D);
          localStringBuffer.append("<tr bgcolor=" + (i % 2 == 0 ? str2 : str3) + ">");
          localStringBuffer.append("<td align=center><font face=Arial size=3>");
          if (k != j)
            localStringBuffer.append(j + " - " + k);
          else
            localStringBuffer.append(j);
          localStringBuffer.append("</td><td align=center><font face=Arial size=3>");
          localStringBuffer.append(Math.round(d1 * 1000.0D) / 1000.0D);
          localStringBuffer.append("%</td><td align=center><font face=Arial size=3>");
          localStringBuffer.append(Action.formatCashFull(d2));
          localStringBuffer.append("</td></tr>");
          i++;
        }
      }
    }
    localStringBuffer.append("</table></center>");
    localStringBuffer.append("</html>");
    return localStringBuffer.toString();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.A
 * JD-Core Version:    0.6.2
 */