package com.biotools.poker.G;

import java.io.File;
import java.io.FileReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class I extends DefaultHandler
{
  private T D = null;
  private List C = new ArrayList();
  private boolean B = false;
  private boolean E = false;
  boolean A = false;

  public void A(String paramString)
  {
    try
    {
      InputSource localInputSource = new InputSource(new StringReader(paramString));
      A(localInputSource);
    }
    catch (Exception localException)
    {
      com.biotools.A.d.A(localException);
    }
  }

  public void A(File paramFile)
  {
    try
    {
      InputSource localInputSource = new InputSource(new FileReader(paramFile));
      A(localInputSource);
      if (B() != null)
        B().A = paramFile;
    }
    catch (Exception localException)
    {
      com.biotools.A.d.A(localException);
    }
  }

  private void A(InputSource paramInputSource)
  {
    try
    {
      SAXParserFactory localSAXParserFactory = SAXParserFactory.newInstance();
      localSAXParserFactory.setValidating(false);
      SAXParser localSAXParser = localSAXParserFactory.newSAXParser();
      localSAXParser.parse(paramInputSource, this);
    }
    catch (Exception localException)
    {
      com.biotools.A.d.A(localException);
    }
  }

  public void startElement(String paramString1, String paramString2, String paramString3, Attributes paramAttributes)
    throws SAXException
  {
    if (paramString3.equals("breaks"))
    {
      this.E = true;
      return;
    }
    if (paramString3.equals("tourn_struct"))
    {
      this.D = new T();
      this.B = true;
      return;
    }
    if (paramString3.equals("details"))
    {
      this.D.E(paramAttributes);
      return;
    }
    if (paramString3.equals("category"))
    {
      this.D.D.C(paramAttributes);
      return;
    }
    if (paramString3.equals("buy_in"))
    {
      this.D.D.B(paramAttributes);
      return;
    }
    if (paramString3.equals("levels"))
    {
      this.D.A(paramAttributes);
      return;
    }
    if (paramString3.equals("level"))
    {
      this.D.H(paramAttributes);
      return;
    }
    if (paramString3.equals("play"))
    {
      this.D.I.G().E(paramAttributes);
      return;
    }
    if (paramString3.equals("add_on"))
    {
      this.D.I.G().G(paramAttributes);
      return;
    }
    if (paramString3.equals("color_up"))
    {
      this.D.I.G().A(paramAttributes);
      return;
    }
    if (paramString3.equals("chip_race"))
    {
      this.D.I.G().D(paramAttributes);
      return;
    }
    if (paramString3.equals("break"))
    {
      if (this.E)
        this.D.G(paramAttributes);
      else
        this.D.I.G().B(paramAttributes);
      return;
    }
    if (paramString3.equals("tourn_payouts"))
    {
      this.D.C(paramAttributes);
      return;
    }
    if (paramString3.equals("payouts_by_num_entrants"))
    {
      this.D.F(paramAttributes);
      return;
    }
    if (paramString3.equals("payout_by_finish"))
    {
      this.D.B(paramAttributes);
      return;
    }
    if (paramString3.equals("isring"))
    {
      this.D.D(paramAttributes);
      return;
    }
    if (paramString3.equals("rebuy"))
      this.D.I.G().F(paramAttributes);
  }

  public void endElement(String paramString1, String paramString2, String paramString3)
    throws SAXException
  {
    if (paramString3.equals("tourn_struct"))
    {
      this.D = this.D.W();
      this.C.add(this.D);
      this.B = false;
      this.D = null;
    }
    if (paramString3.equals("breaks"))
    {
      this.E = false;
      return;
    }
  }

  public void characters(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws SAXException
  {
    String str1 = String.valueOf(paramArrayOfChar, paramInt1, paramInt2);
    if ((str1.trim().length() == 0) || (this.D == null))
      return;
    if ((this.A) && (!str1.startsWith(" ")))
      str1 = " " + str1;
    this.A = str1.endsWith(" ");
    String str2 = this.D.i();
    if (str2 != null)
      str1 = str2 + str1;
    this.D.B(str1);
  }

  public boolean C()
  {
    return this.B;
  }

  public T B()
  {
    if (this.C.size() == 0)
      return null;
    return (T)this.C.get(this.C.size() - 1);
  }

  public List A()
  {
    return this.C;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.I
 * JD-Core Version:    0.6.2
 */