package com.biotools.poker.G;

import javax.swing.JButton;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

final class B$2
  implements ListSelectionListener
{
  final B this$0;

  B$2(B paramB)
  {
  }

  public void valueChanged(ListSelectionEvent paramListSelectionEvent)
  {
    ListSelectionModel localListSelectionModel = (ListSelectionModel)paramListSelectionEvent.getSource();
    B.access$2(this.this$0).setEnabled(!localListSelectionModel.isSelectionEmpty());
    this.this$0.K();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.B.2
 * JD-Core Version:    0.6.2
 */