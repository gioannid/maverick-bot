package com.biotools.poker.G;

import com.biotools.A.I;
import com.biotools.A.b;
import com.biotools.A.d;
import com.biotools.B.L;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.poker.E;
import com.biotools.poker.Q.D;
import com.biotools.poker.Q.K;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.xml.sax.Attributes;

public class R
{
  T Y = null;
  e H = null;
  int K = -1;
  int Q = -1;
  int D = 0;
  int S = 0;
  int T = 0;
  int M = 0;
  int N = 0;
  int R = -1;
  double L = 0.0D;
  double O = 1.7976931348623157E+308D;
  double Z = 0.0D;
  int X = 0;
  List U = new ArrayList();
  List E = new ArrayList();
  HashMap I = new HashMap();
  boolean P;
  String G = null;
  int W = -1;
  String J = null;
  File B = null;
  public static final int A = -1;
  public static final int V = 0;
  public static final int _ = 1;
  public static final int C = 2;
  double F = 0.0D;

  public static R A(T paramT, int paramInt)
  {
    R localR = new R();
    localR.B(paramT);
    localR.B(true);
    localR.F(paramInt);
    localR.B(paramInt);
    return localR;
  }

  public static R G(int paramInt)
  {
    R localR = new R();
    localR.B(new T());
    localR.B(paramInt);
    return localR;
  }

  public static String A(T paramT)
  {
    R localR = new R();
    localR.B(paramT);
    localR.B = paramT.A;
    return localR.A(true);
  }

  public void H(int paramInt)
  {
    this.D = this.Y.a();
    this.T = this.Y.g();
    this.S = this.Y.U();
    this.W = 2;
    this.M = (this.X = paramInt);
    this.R = (this.M + 1);
    I(this.Y.I() - 1);
    this.Y.C(paramInt);
    this.Y.D();
    a();
  }

  public void B(K paramK)
  {
    double d1 = k();
    double d2 = u();
    double d3 = g();
    if (paramK.C().isNoLimit())
      paramK.C().A(d2, d3, d3);
    else
      paramK.C().A(d2, d3, d3 * 2.0D);
    paramK.C().D(d1);
  }

  public int A(R._A param_A, K paramK)
  {
    int i = 0;
    Set localSet = A(paramK);
    Iterator localIterator = localSet.iterator();
    while (localIterator.hasNext())
    {
      G localG = (G)localIterator.next();
      double d = localG.F();
      if (d > 0.0D)
      {
        K localK = param_A.A(localG.I());
        if (localK != paramK)
          d.A("dealer player mismatch for " + localG.I() + " other dealer is " + (localK == null ? "null" : "not null"));
        PlayerInfo localPlayerInfo = localK.C().getPlayer(localG.I());
        if ((localPlayerInfo != null) && (localPlayerInfo.isAllIn()))
          i++;
      }
    }
    return i;
  }

  private Set A(K paramK)
  {
    if (paramK == null)
      return null;
    HashSet localHashSet = new HashSet();
    for (int i = 0; i < 10; i++)
    {
      PlayerInfo localPlayerInfo = paramK.C().getPlayer(i);
      if (localPlayerInfo != null)
      {
        G localG = T(localPlayerInfo.getName());
        if (localG != null)
          localHashSet.add(localG);
        else
          d.A("could not find tournament player info for " + localPlayerInfo.getName());
      }
    }
    return localHashSet;
  }

  public int F(String paramString)
  {
    for (int i = 0; i < this.U.size(); i++)
    {
      W localW = (W)this.U.get(i);
      if (localW.A(paramString))
        return i;
    }
    return -1;
  }

  public void A(int paramInt, R._A param_A)
  {
    A(paramInt, param_A, null);
  }

  public void A(int paramInt, R._A param_A, K paramK)
  {
    int i = w() - paramInt;
    L(i);
    double d1 = 0.0D;
    double d2 = 1.7976931348623157E+308D;
    double d3 = 0.0D;
    int j = 0;
    Set localSet = A(paramK);
    List localList = R();
    ArrayList localArrayList = new ArrayList();
    G localG;
    double d4;
    for (int k = 0; k < localList.size(); k++)
    {
      localG = (G)localList.get(k);
      d4 = localG.F();
      if (d4 > 0.0D)
      {
        K localK = param_A.A(localG.I());
        double d5 = d4;
        if (paramK != null)
        {
          if (localSet.contains(localG))
          {
            if (localK != paramK)
              d.A("dealer player mismatch (updateAtGameEnd) for " + localG.I() + " other dealer is " + (localK == null ? "null" : "not null"));
            PlayerInfo localPlayerInfo = localK.C().getPlayer(localG.I());
            if (localPlayerInfo != null)
              d5 = localPlayerInfo.getBankRoll();
            if (localPlayerInfo == null)
              d.A("playerinfo is null for " + localG.I());
          }
        }
        else
          d5 = localK == null ? 0.0D : localK.C().getPlayer(localG.I()).getBankRoll();
        if (d5 == 0.0D)
        {
          localG.A(A(), d4);
          localG.A(i);
          localArrayList.add(localG);
        }
        else
        {
          if (d5 > d1)
            d1 = d5;
          if (d5 < d2)
            d2 = d5;
          d3 += d5;
          j++;
        }
        localG.B(d5);
      }
    }
    C(d1);
    B(d2);
    A(d3);
    K(j);
    f();
    c();
    x();
    a();
    C(V() + Q().U() - Y());
    L();
    Iterator localIterator = localArrayList.iterator();
    while (localIterator.hasNext())
    {
      localG = (G)localIterator.next();
      param_A.B(localG.I());
      d4 = A(localG);
      if (d4 > 0.0D)
        param_A.A(localG.I(), d4);
    }
    if (I())
    {
      localG = (G)localList.get(0);
      assert (K(localG.I()));
      d4 = A(localG);
      if (d4 > 0.0D)
        param_A.A(localG.I(), d4);
    }
  }

  public void z()
  {
    if (this.B != null)
      this.B.delete();
  }

  public void F(G paramG)
  {
    if (paramG == null)
      return;
    this.E.add(paramG);
    this.I.put(paramG.I(), paramG);
  }

  public void E(G paramG)
  {
    if (paramG == null)
      return;
    this.E.remove(paramG);
    this.I.remove(paramG.I());
  }

  public List R()
  {
    return this.E;
  }

  public List h()
  {
    return this.U;
  }

  public G T(String paramString)
  {
    return (G)this.I.get(paramString);
  }

  void e()
  {
    this.I.clear();
    for (int i = 0; i < this.E.size(); i++)
    {
      G localG = (G)this.E.get(i);
      if ((localG != null) && (localG.I() != null))
        this.I.put(localG.I(), localG);
    }
  }

  public double I(String paramString)
  {
    return C(T(paramString));
  }

  public double C(G paramG)
  {
    if (paramG == null)
      return -1.0D;
    double d = Q().M() + Q().P();
    List localList1 = paramG.D();
    if (localList1 != null)
      for (int i = 0; i < localList1.size(); i++)
      {
        F localF = (F)localList1.get(i);
        d += localF.B() * localF.C();
      }
    List localList2 = paramG.A();
    if (localList2 != null)
      for (int j = 0; j < localList2.size(); j++)
      {
        O localO = (O)localList2.get(j);
        d += localO.B() * localO.C();
      }
    return d;
  }

  public double Q(String paramString)
  {
    return A(T(paramString));
  }

  public double A(G paramG)
  {
    if (paramG == null)
      return -1.0D;
    return paramG.N() / 100.0D * this.F;
  }

  public double N(String paramString)
  {
    return G(T(paramString));
  }

  public double G(G paramG)
  {
    if (paramG == null)
      return 0.0D;
    return A(paramG) - C(paramG);
  }

  public double i()
  {
    return this.F;
  }

  public double a()
  {
    if (Q() != null)
    {
      this.F = Q().A(this.E.size());
      for (int i = 0; i < this.E.size(); i++)
      {
        G localG = (G)this.E.get(i);
        this.F += C(localG) - Q().M();
      }
    }
    return this.F;
  }

  public boolean F()
  {
    return this.N <= this.Y.j();
  }

  public int q()
  {
    return this.E.size();
  }

  public int V()
  {
    return this.M;
  }

  public int Y()
  {
    return this.X;
  }

  public int Z()
  {
    return this.S;
  }

  public void I(int paramInt)
  {
    if (paramInt < 0)
    {
      if (!$assertionsDisabled)
        throw new AssertionError("Trying to set bad tournament level: " + paramInt + ", valid range[0," + (this.Y.w() - 1) + "]");
      paramInt = 0;
    }
    if (paramInt >= this.Y.w())
    {
      if (!$assertionsDisabled)
        throw new AssertionError("Trying to set bad tournament level: " + paramInt + ", valid range[0," + (this.Y.w() - 1) + "]");
      paramInt = this.Y.w() - 1;
    }
    this.N = paramInt;
    this.H = this.Y.G(this.N);
    this.H.J(this.D);
  }

  public e X()
  {
    if (this.H == null)
    {
      I(this.N);
      if (this.H == null)
        this.H = new e();
    }
    return this.H;
  }

  public int A()
  {
    return this.N;
  }

  public void A(int paramInt)
  {
    this.D = paramInt;
  }

  public int E()
  {
    return this.D;
  }

  public void A(long paramLong)
  {
    this.T = (this.Y.g() + (int)paramLong);
  }

  public int J()
  {
    return this.T;
  }

  public int M()
  {
    return this.T - this.Y.g();
  }

  public void C(int paramInt)
  {
    this.S = paramInt;
  }

  public int s()
  {
    return this.S;
  }

  public void L(int paramInt)
  {
    this.R = paramInt;
  }

  public int w()
  {
    return this.R;
  }

  public void L()
  {
    if (this.W == -1)
      return;
    if (this.X == 1)
      this.W = 0;
    else if ((this.G != null) && (D(this.G)))
      this.W = 1;
    else
      this.W = 2;
  }

  public int U()
  {
    return this.W;
  }

  public void t()
  {
    this.J = A(true);
  }

  public String l()
  {
    return this.J;
  }

  public boolean I()
  {
    if ((U() == 0) && (!$assertionsDisabled) && (this.X != 1))
      throw new AssertionError();
    if ((this.X == 1) && (!$assertionsDisabled) && (U() != 0))
      throw new AssertionError();
    return U() == 0;
  }

  public boolean D(String paramString)
  {
    return B(T(paramString));
  }

  public boolean B(G paramG)
  {
    if (paramG == null)
      return true;
    return paramG.F() == 0.0D;
  }

  public int H(String paramString)
  {
    return D(T(paramString));
  }

  public int D(G paramG)
  {
    if (paramG != null)
      return paramG.L();
    return -1;
  }

  public double N()
  {
    return this.L;
  }

  public void C(double paramDouble)
  {
    this.L = paramDouble;
  }

  public double ¤()
  {
    if (this.O > this.L)
      return this.L;
    return this.O;
  }

  public void B(double paramDouble)
  {
    this.O = paramDouble;
  }

  public double H()
  {
    return this.Z / (this.X == 0 ? 1 : this.X);
  }

  public double d()
  {
    return this.Z;
  }

  public void A(double paramDouble)
  {
    this.Z = paramDouble;
  }

  public void K(int paramInt)
  {
    this.X = paramInt;
  }

  public void f()
  {
    Collections.sort(this.E, G.K());
  }

  public void c()
  {
    int i = 0;
    Object localObject = null;
    for (int j = 0; j < this.E.size(); j++)
    {
      G localG = (G)this.E.get(j);
      if (localObject == null)
      {
        i = j + 1;
      }
      else
      {
        if (localG.L() < localObject.L())
          localG.A(localObject.L());
        if (G.E().compare(localG, localObject) > 0)
          i = j + 1;
      }
      localG.A(i);
      localObject = localG;
    }
  }

  public void x()
  {
    int i = 0;
    double d = 0.0D;
    int j = 0;
    G localG = null;
    a locala = Q().J(this.M);
    List localList = null;
    if (locala != null)
      localList = locala.A();
    int k = 0;
    N localN = null;
    if (localList != null)
      localN = (N)localList.get(k);
    int m = 0;
    while (m < this.E.size())
    {
      localG = (G)this.E.get(m);
      j = localG.L();
      d = 0.0D;
      i = 0;
      for (int n = m; n < this.E.size(); n++)
      {
        localG = (G)this.E.get(n);
        if (localG.L() != j)
          break;
        if (localList != null)
          while (((localN == null) || (!localN.B(j + i))) && (k < localList.size() - 1))
          {
            k++;
            localN = (N)localList.get(k);
          }
        if ((localN != null) && (localN.B(j + i)))
          d += localN.F();
        i++;
        continue;
        break;
      }
      d /= i;
      assert ((i >= 1) && (i <= this.M));
      for (n = 0; n < i; n++)
      {
        localG = (G)this.E.get(m + n);
        localG.A(d);
        A(localG);
      }
      m += i;
    }
  }

  public void A(List paramList)
  {
    this.U.clear();
    for (int i = 0; i < paramList.size(); i++)
    {
      K localK = (K)paramList.get(i);
      if (localK == null)
      {
        if (!$assertionsDisabled)
          throw new AssertionError();
      }
      else
        this.U.add(new W(localK));
    }
  }

  public void A(com.biotools.poker.S.D.A.B paramB, boolean paramBoolean)
  {
    int i = 0;
    int j = 0;
    Iterator localIterator = this.U.iterator();
    while (localIterator.hasNext())
    {
      W localW = (W)localIterator.next();
      if (localW.F() == paramB.ô)
      {
        j = 1;
        break;
      }
      i++;
    }
    if (j != 0)
    {
      if (paramBoolean)
        this.U.remove(i);
      else
        this.U.set(i, new W(paramB));
    }
    else
      d.A("could not find dealerInfo with id=" + paramB.ô + " no update done");
  }

  public String o()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    Object[] arrayOfObject1 = { new Integer(this.N + 1) };
    localStringBuffer.append(E.A("TournamentInfo.LevelPattern", arrayOfObject1));
    if (k() > 0.0D)
    {
      arrayOfObject2 = new Object[] { Action.formatCash(k()) };
      localStringBuffer.append(E.A("TournamentInfo.AntePattern", arrayOfObject2));
    }
    Object[] arrayOfObject2 = new Object[2];
    if (this.Y.Y())
    {
      arrayOfObject2[0] = Action.formatCash(u());
      arrayOfObject2[1] = Action.formatCash(g());
    }
    else
    {
      arrayOfObject2[0] = Action.formatCash(g());
      arrayOfObject2[1] = Action.formatCash(g() * 2.0D);
    }
    localStringBuffer.append(E.A("TournamentInfo.StakesPattern", arrayOfObject2));
    String str = "";
    localStringBuffer.append(", " + X().A(this.D, this.T / 60000, this.S) + str);
    return localStringBuffer.toString();
  }

  private void C()
  {
    System.runFinalization();
    System.gc();
    E.H("MEM: " + L.B());
  }

  public double k()
  {
    return X().J();
  }

  public double u()
  {
    return X().R();
  }

  public double g()
  {
    return X().M();
  }

  public boolean _()
  {
    return this.Y.Y();
  }

  public static void A(String[] paramArrayOfString)
  {
    File localFile1 = E.Á();
    File[] arrayOfFile = localFile1.listFiles();
    long l1 = 0L;
    long l2 = 0L;
    long l3 = 0L;
    for (int i = 0; i < arrayOfFile.length; i++)
    {
      File localFile2 = arrayOfFile[i];
      long l4 = com.biotools.A.F.A();
      long l5 = com.biotools.A.F.A();
      R localR = A(localFile2);
      long l6 = com.biotools.A.F.A();
      long l7 = com.biotools.A.F.A();
      l7 -= l6;
      l6 -= l5;
      l5 -= l4;
      l2 += l5;
      l1 += l6;
      l3 += l7;
    }
    System.out.println(" Fdom: " + L.B(l3));
    System.out.println(" Fsax: " + L.B(l1));
    System.out.println(" Ssax: " + L.B(l2));
    System.out.println("  inc: " + L.A(l3 / l1));
    System.out.println(" inc2: " + L.A(l1 / l2));
  }

  private void S()
  {
    G();
    W();
  }

  public String O()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    f();
    if (!I())
      localStringBuffer.append("Tournament is unfinshed\n");
    for (int i = 0; i < this.E.size(); i++)
    {
      G localG = (G)this.E.get(i);
      if (I())
      {
        if (A(localG) <= 0.0D)
          break;
        localStringBuffer.append("Place " + localG.L() + " (" + Action.formatCash(A(localG)) + "): " + localG.I() + "\n");
        continue;
        break;
      }
      else if (B(localG))
      {
        if (A(localG) <= 0.0D)
          break;
        localStringBuffer.append("Place " + localG.L() + " (" + Action.formatCash(A(localG)) + "): " + localG.I() + "\n");
        continue;
        break;
      }
      else
      {
        localStringBuffer.append("Place " + localG.L() + " (" + localG.F() + " TChips): " + localG.I() + " (payout " + Action.formatCash(A(localG)) + ")\n");
      }
    }
    return localStringBuffer.toString();
  }

  public void G()
  {
    for (int i = 0; i < this.E.size(); i++)
      E.H(((G)this.E.get(i)).toString());
    E.H("");
  }

  public void W()
  {
    int i = this.U.size();
    int j = 0;
    E.H("================= Tournament Stats =================");
    E.H("Hands played: " + this.D);
    E.H("Time played: " + this.T / 60000 + " min.");
    E.H("Num busts: " + this.S);
    E.H(o());
    E.H("NumPlayersWithChips: " + j + ", NumTables: " + i);
    E.H("====================================================");
  }

  private boolean j()
  {
    return this.M > 0;
  }

  public boolean K(String paramString)
  {
    G localG = T(paramString);
    return (I()) && (localG != null) && (localG.F() != 0.0D);
  }

  public int v()
  {
    return this.U.size();
  }

  public boolean b()
  {
    int i = this.Y.Á();
    int j = this.Y.¢();
    return i > j;
  }

  public int p()
  {
    return D();
  }

  public int y()
  {
    return this.Q;
  }

  public int D()
  {
    return this.K;
  }

  public void F(int paramInt)
  {
    this.Q = paramInt;
  }

  public void B(int paramInt)
  {
    this.K = paramInt;
  }

  public String n()
  {
    return Q().q();
  }

  public int m()
  {
    return this.Y.o();
  }

  public String £()
  {
    return this.G;
  }

  public void E(String paramString)
  {
    this.G = paramString;
  }

  public boolean T()
  {
    return this.P;
  }

  public void B(boolean paramBoolean)
  {
    this.P = paramBoolean;
  }

  public String E(int paramInt)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<font face=Arial size=3>");
    if (Q().i() != null)
    {
      localStringBuffer.append(Q().i());
      localStringBuffer.append("<br>");
    }
    Object[] arrayOfObject1 = { Action.formatCash(Q().o()) };
    localStringBuffer.append(E.A("TournamentInfo.StartsChipsPattern", arrayOfObject1));
    Object[] arrayOfObject2;
    if (Q().x())
    {
      arrayOfObject2 = new Object[] { new Integer(Q().H()), e.I(Q().L()) };
      localStringBuffer.append(Q().H() > 1 ? E.A("TournamentInfo.LevelsIncreaseEveryPluralPattern", arrayOfObject2) : E.A("TournamentInfo.LevelsIncreaseEverySingularPattern", arrayOfObject2));
    }
    if (paramInt == 1)
    {
      arrayOfObject2 = new Object[] { new Integer(A() + 1) };
      localStringBuffer.append(E.A("TournamentInfo.CurrentLevelPattern", arrayOfObject2));
      if (k() != 0.0D)
      {
        arrayOfObject3 = new Object[] { Action.formatCash(k()) };
        localStringBuffer.append(E.A("TournamentInfo.AnteSentencePattern", arrayOfObject3));
      }
      Object[] arrayOfObject3 = { Action.formatCash(u()), Action.formatCash(g()) };
      localStringBuffer.append(E.A("TournamentInfo.BlindsSentencePattern", arrayOfObject3));
    }
    return localStringBuffer.toString();
  }

  public boolean ¢()
  {
    return U() != -1;
  }

  public void A(String paramString, int paramInt)
  {
    if ((this.J == null) || (paramInt == 0))
      return;
    if (U() == -1)
    {
      E.H("trying to save tournament in prestart state");
      return;
    }
    File localFile = new File(paramString + "/" + p());
    if (!localFile.exists())
      localFile.mkdirs();
    this.B = new File(localFile, p() + "." + E() % paramInt + ".xml");
    E.H("SAVING TOURNAMENT: " + p() + ": " + this.B);
    try
    {
      BufferedWriter localBufferedWriter = new BufferedWriter(new FileWriter(this.B));
      localBufferedWriter.write(this.J);
      localBufferedWriter.close();
    }
    catch (IOException localIOException)
    {
      Object[] arrayOfObject = { this.B.getPath() };
      I.A(E.A("TournamentInfo.ErrorWritingToDiskPattern", arrayOfObject), localIOException);
    }
  }

  public synchronized void K()
  {
    if (this.J == null)
      return;
    if (U() == -1)
    {
      E.H("trying to save tournament in prestart state");
      return;
    }
    File localFile = null;
    if (U() == 2)
      localFile = new File(E.x(), p() + ".xml");
    else
      localFile = new File(E.Á(), p() + ".xml");
    if (this.B == null)
    {
      this.B = localFile;
    }
    else if (!this.B.equals(localFile))
    {
      if ((localFile.getParentFile().equals(E.x())) && (this.B.getParentFile().equals(E.Á())))
        d.A("Moving a finished tournament to an unfinished tournament: " + this.B.getPath() + " to " + localFile.getPath());
      try
      {
        boolean bool = this.B.renameTo(localFile);
        if (!bool)
        {
          d.A("Trying to save tournament and couldn't rename " + this.B.getPath() + " to " + localFile.getPath());
        }
        else
        {
          E.H("Successfully renamed tournament save file from " + this.B.getPath() + " to " + localFile.getPath());
          this.B = localFile;
        }
      }
      catch (Exception localException)
      {
        d.A("Problem trying to rename tournament from " + this.B.getPath() + " to " + localFile.getPath(), localException);
      }
    }
    E.H("SAVING TOURNAMENT: " + p() + ": " + this.B);
    try
    {
      BufferedWriter localBufferedWriter = new BufferedWriter(new FileWriter(this.B));
      localBufferedWriter.write(this.J);
      localBufferedWriter.close();
    }
    catch (IOException localIOException)
    {
      Object[] arrayOfObject = { this.B.getPath() };
      I.A(E.A("TournamentInfo.ErrorWritingToDiskPattern", arrayOfObject), localIOException);
    }
  }

  public void S(String paramString)
  {
    if (this.J == null)
    {
      d.A("trying to save tourney with XML of null!");
      return;
    }
    if (U() == -1)
    {
      d.A("trying to save tourney which hasn't started!");
      return;
    }
    this.B = new File(paramString, p() + ".xml");
    try
    {
      BufferedWriter localBufferedWriter = new BufferedWriter(new FileWriter(this.B));
      localBufferedWriter.write(this.J);
      localBufferedWriter.close();
    }
    catch (IOException localIOException)
    {
      d.A("Problem trying to write tournament information to disk (" + this.B.getPath() + ")", localIOException);
    }
  }

  public String A(boolean paramBoolean)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<tournament");
    localStringBuffer.append(" curLevel=\"" + this.N + "\"");
    localStringBuffer.append(" elapsedPlayTime=\"" + this.T + "\"");
    localStringBuffer.append(" handsPlayed=\"" + this.D + "\"");
    localStringBuffer.append(" bustedPlayers=\"" + this.S + "\"");
    if (this.G != null)
      localStringBuffer.append(" profile=\"" + com.biotools.A.B.B(this.G) + "\"");
    localStringBuffer.append(" onlineID=\"" + this.Q + "\"");
    localStringBuffer.append(" localID=\"" + this.K + "\"");
    localStringBuffer.append(" status=\"" + this.W + "\"");
    localStringBuffer.append(" isOnline=\"" + (this.P ? "t" : "f") + "\"");
    localStringBuffer.append(">");
    if (paramBoolean)
      localStringBuffer.append(this.Y.F());
    G localG = null;
    localStringBuffer.append("<players>");
    Object localObject = this.E.iterator();
    while (((Iterator)localObject).hasNext())
    {
      localG = (G)((Iterator)localObject).next();
      if (localG != null)
        localStringBuffer.append(localG.J());
    }
    localStringBuffer.append("</players>");
    localObject = null;
    localStringBuffer.append("<dealers>");
    Iterator localIterator = this.U.iterator();
    while (localIterator.hasNext())
    {
      localObject = (W)localIterator.next();
      if (localObject != null)
      {
        localStringBuffer.append("<dealer");
        localStringBuffer.append(" id=\"" + ((W)localObject).F() + "\"");
        localStringBuffer.append(" button=\"" + ((W)localObject).B() + "\"");
        localStringBuffer.append(" smallBlind=\"" + ((W)localObject).E() + "\"");
        localStringBuffer.append(" bigBlind=\"" + ((W)localObject).D() + "\"");
        localStringBuffer.append(">");
        for (int i = 0; i < 10; i++)
          if (((W)localObject).C(i))
          {
            localStringBuffer.append("<seat");
            localStringBuffer.append(" num=\"" + i + "\"");
            localStringBuffer.append(" name=\"" + com.biotools.A.B.B(((W)localObject).B(i)) + "\"");
            localStringBuffer.append(" />");
          }
        localStringBuffer.append("</dealer>");
      }
    }
    localStringBuffer.append("</dealers>");
    localStringBuffer.append("</tournament>");
    return localStringBuffer.toString();
  }

  public static R D(int paramInt)
  {
    File localFile = J(paramInt);
    if ((localFile != null) && (localFile.exists()))
      return B(localFile);
    E.H("ERROR! Can't create tournament file from XML: " + paramInt);
    return null;
  }

  private static File J(int paramInt)
  {
    try
    {
      File localFile = new File(E.Á(), paramInt + ".xml");
      localObject = new File(E.x(), paramInt + ".xml");
      if ((localFile.exists()) && (!((File)localObject).exists()))
        return localFile;
      if ((!localFile.exists()) && (((File)localObject).exists()))
        return localObject;
      if ((!localFile.exists()) && (!((File)localObject).exists()))
      {
        d.A("Trying to get saved tournament information file (" + paramInt + ") that doesn't exist in either the finished or unfinished directories");
        return null;
      }
      d.A("Trying to get saved tournament information file (" + paramInt + ") that exists in both the finished and unfinished directories");
      return localFile;
    }
    catch (Exception localException)
    {
      Object localObject = { new Integer(paramInt) };
      I.A(E.A("TournamentInfo.ErrorCantGetIDPattern", (Object[])localObject), localException);
    }
    return null;
  }

  public static R C(String paramString)
  {
    return Y.A(paramString);
  }

  public static R A(File paramFile)
  {
    R localR = Y.C(paramFile);
    if (localR != null)
      localR.C(paramFile);
    return localR;
  }

  public static R B(File paramFile)
  {
    R localR = Y.D(paramFile);
    if (localR != null)
      localR.C(paramFile);
    return localR;
  }

  public void C(File paramFile)
  {
    this.B = paramFile;
  }

  public File B()
  {
    return this.B;
  }

  public T Q()
  {
    return this.Y;
  }

  public void B(T paramT)
  {
    this.Y = paramT;
  }

  public void A(Attributes paramAttributes)
  {
    String str = paramAttributes.getValue("curLevel");
    if (str != null)
      this.N = Integer.parseInt(str);
    else
      E.H("missing curLevel");
    str = paramAttributes.getValue("elapsedPlayTime");
    if (str != null)
      this.T = Integer.parseInt(str);
    else
      E.H("missing elpasedPlayTime");
    str = paramAttributes.getValue("handsPlayed");
    if (str != null)
      this.D = Integer.parseInt(str);
    else
      E.H("missing handsPlayed");
    str = paramAttributes.getValue("bustedPlayers");
    if (str != null)
      this.S = Integer.parseInt(str);
    else
      E.H("missing bustedPlayers");
    str = paramAttributes.getValue("status");
    if (str != null)
      this.W = Integer.parseInt(str);
    else
      E.H("missing status");
    str = paramAttributes.getValue("isOnline");
    if (str != null)
      this.P = str.equals("t");
    else
      E.H("missing isOnline");
    str = paramAttributes.getValue("onlineID");
    if (str != null)
      this.Q = Integer.parseInt(str);
    str = paramAttributes.getValue("localID");
    if (str != null)
      this.K = Integer.parseInt(str);
    this.G = paramAttributes.getValue("profile");
  }

  public void F(Attributes paramAttributes)
  {
    this.E = new ArrayList();
  }

  public void C(Attributes paramAttributes)
  {
    G localG = G.A(paramAttributes);
    if (localG == null)
      return;
    if (localG.F() > 0.0D)
    {
      this.X += 1;
      this.Z += localG.F();
      if (localG.F() > this.L)
        this.L = localG.F();
      if (localG.F() < this.O)
        this.O = localG.F();
    }
    else if (localG.L() < this.R)
    {
      this.R = localG.L();
    }
    this.M += 1;
    this.E.add(localG);
  }

  public G r()
  {
    return (G)this.E.get(this.E.size() - 1);
  }

  public void D(Attributes paramAttributes)
  {
    this.U = new ArrayList();
  }

  public void E(Attributes paramAttributes)
  {
    int i = -1;
    int j = -1;
    int k = -1;
    int m = -1;
    String str = paramAttributes.getValue("id");
    if (str != null)
      m = Integer.parseInt(str);
    str = paramAttributes.getValue("button");
    if (str != null)
      i = Integer.parseInt(str);
    str = paramAttributes.getValue("smallBlind");
    if (str != null)
      j = Integer.parseInt(str);
    str = paramAttributes.getValue("bigBlind");
    if (str != null)
      k = Integer.parseInt(str);
    W localW = new W();
    localW.A(i, j, k, true);
    localW.A(m);
    this.U.add(localW);
  }

  public void B(Attributes paramAttributes)
  {
    int i = -1;
    Object localObject = null;
    String str = paramAttributes.getValue("num");
    if (str != null)
      i = Integer.parseInt(str);
    str = paramAttributes.getValue("name");
    if (str != null)
      localObject = str;
    W localW = (W)this.U.get(this.U.size() - 1);
    localW.A(i, localObject);
  }

  private String B(String paramString)
  {
    String str1 = "#aaaacc";
    String str2 = "#ddddff";
    String str3 = "white";
    StringBuffer localStringBuffer = new StringBuffer();
    double d1 = i();
    localStringBuffer.append("<table align=center cellspacing=0 width=100%>");
    localStringBuffer.append("<tr bgcolor=" + str2 + ">");
    localStringBuffer.append("<td align=right><b><font face=Arial size=3>" + E.D("TournamentInfo.BuyInTitle") + "</b></td>");
    localStringBuffer.append("<td><font face=Arial size=3>" + n() + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr><td align=center colspan=2>");
    localStringBuffer.append("<table align=center width=100%");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><font face=Arial size=3><b>" + E.D("TournamentInfo.PrizePoolTitle") + "</b></td>");
    localStringBuffer.append("<td><font face=Arial size=3>" + Action.formatCash(d1) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr bgcolor=" + str2 + ">");
    localStringBuffer.append("<td align=\"right\"><font face=Arial size=3><b>" + E.D("TournamentInfo.PositionsPaidTitle") + "</b></td>");
    localStringBuffer.append("<td><font face=Arial size=3>" + Q().R(this.M) + "</td>");
    localStringBuffer.append("</tr>");
    G localG = T(paramString);
    int i = D(localG);
    if (i != -1)
    {
      localStringBuffer.append("<tr>");
      localStringBuffer.append("<td align=\"right\"><font face=Arial size=3><b>" + E.D("TournamentInfo.RankingTitle") + "</b></td>");
      arrayOfObject1 = new Object[] { new Integer(i), new Integer(this.M) };
      localStringBuffer.append("<td><font face=Arial size=3>" + E.A("TournamentInfo.OutOfWithBoldPattern", arrayOfObject1) + "</td>");
      localStringBuffer.append("</tr>");
    }
    else
    {
      localStringBuffer.append("<tr>");
      localStringBuffer.append("<td align=\"right\">&nbsp;</td>");
      localStringBuffer.append("<td>&nbsp;</td>");
      localStringBuffer.append("</tr>");
    }
    localStringBuffer.append("<tr bgcolor=" + str2 + ">");
    localStringBuffer.append("<td align=\"right\"><font face=Arial size=3><b>" + E.D("TournamentInfo.PlayersLeftTitle") + "</b></td>");
    Object[] arrayOfObject1 = { new Integer(this.X), new Integer(this.M) };
    localStringBuffer.append("<td><font face=Arial size=3>" + E.A("TournamentInfo.OutOfPattern", arrayOfObject1) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><font face=Arial size=3><b>" + E.D("TournamentInfo.TablesLeftTitle") + "</b></td>");
    double d2 = this.X;
    double d3 = this.Y.¢();
    int j = new Double(Math.ceil(d2 / d3)).intValue();
    Object[] arrayOfObject2 = { new Integer(j), new Integer(this.Y.¢()) };
    localStringBuffer.append("<td><font face=Arial size=3>" + E.A("TournamentInfo.TablesLeftPattern", arrayOfObject2) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr bgcolor=" + str2 + ">");
    localStringBuffer.append("<td align=\"right\"><font face=Arial size=3><b>" + E.D("TournamentInfo.NextPositionPaysTitle") + "</b></td>");
    localStringBuffer.append("<td><font face=Arial size=3>" + Action.formatCash(Q().C(this.M, this.X) * (d1 / 100.0D)) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><font face=Arial size=3><b>" + E.D("TournamentInfo.ChipsInPlayTitle") + "</b></td>");
    if (d() > 0.0D)
      localStringBuffer.append("<td><font face=Arial size=3>" + Action.formatCash(d()) + "</td>");
    else
      localStringBuffer.append("<td></td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("</table></td></tr>");
    localStringBuffer.append("<tr><td colspan=2><hr></td></tr>");
    localStringBuffer.append(L(str2));
    localStringBuffer.append("<tr><td colspan=2><hr></td></tr>");
    localStringBuffer.append(P(paramString));
    localStringBuffer.append("<tr><td colspan=2><hr></td></tr>");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td colspan=2 align=center><font face=Arial size=3><b>" + E.D("TournamentInfo.CurrentLevelTitle") + " </b>" + (A() + 1) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append(A(null));
    localStringBuffer.append("</table>");
    return localStringBuffer.toString();
  }

  private String P(String paramString)
  {
    String str = "#ddddff";
    StringBuffer localStringBuffer = new StringBuffer();
    G localG = T(paramString);
    if (localG != null)
    {
      localStringBuffer.append("<tr>");
      localStringBuffer.append("<td colspan=2 align=center>");
      localStringBuffer.append("<table align=center width=69%>");
      localStringBuffer.append("<tr>");
      localStringBuffer.append("<td valign=center align=right><b><font face=Arial size=4>" + Action.formatCash(localG.F()) + "</b></font></td>");
      localStringBuffer.append("<td valign=center align=left><font face=Arial size=4><b>" + E.D("TournamentInfo.StackSize") + "</b></font></td>");
      localStringBuffer.append("</tr>");
      localStringBuffer.append("<tr bgcolor=" + str + ">");
      if (d() > 0.0D)
        localStringBuffer.append("<td align=right><b><font face=Arial size=3>" + b.A(localG.F() / d() * 100.0D, 2) + "</b>%</td>");
      else
        localStringBuffer.append("<td></td>");
      localStringBuffer.append("<td align=left><font face=Arial size=3>" + E.D("TournamentInfo.OfTotalChips") + "</td>");
      localStringBuffer.append("</tr>");
      localStringBuffer.append("<tr>");
      Object[] arrayOfObject;
      if (H() > 0.0D)
      {
        arrayOfObject = new Object[] { new Double(b.A(localG.F() / H(), 3)) };
        localStringBuffer.append("<td align=right><b><font face=Arial size=3>" + E.A("TournamentInfo.NumberTimesPattern", arrayOfObject) + "</td>");
      }
      else
      {
        localStringBuffer.append("<td></td>");
      }
      localStringBuffer.append("<td align=left><font face=Arial size=3>" + E.D("TournamentInfo.AverageChips") + "</td>");
      localStringBuffer.append("</tr>");
      localStringBuffer.append("<tr bgcolor=" + str + ">");
      if ((X() != null) && (X().M() > 0.0D))
      {
        arrayOfObject = new Object[] { new Double(b.A(localG.F() / X().M(), 3)) };
        localStringBuffer.append("<td align=right><b><font face=Arial size=3>" + E.A("TournamentInfo.NumberTimesPattern", arrayOfObject) + "</td>");
      }
      else
      {
        localStringBuffer.append("<td></td>");
      }
      localStringBuffer.append("<td align=left><font face=Arial size=3>" + E.D("TournamentInfo.BigBlind") + "</td>");
      localStringBuffer.append("</tr>");
      localStringBuffer.append("</table>");
      localStringBuffer.append("</td>");
      localStringBuffer.append("</tr>");
    }
    return localStringBuffer.toString();
  }

  public String M(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<html>");
    localStringBuffer.append("<b><center><font face=Arial size=4>" + Q().ª() + "</center></b></font>");
    localStringBuffer.append("<hr><br>");
    localStringBuffer.append(B(paramString));
    localStringBuffer.append("<hr><br>");
    localStringBuffer.append(E(0));
    localStringBuffer.append("</font>");
    localStringBuffer.append("</html>");
    return localStringBuffer.toString();
  }

  public String J(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<html>");
    localStringBuffer.append(O(paramString));
    localStringBuffer.append("<br><hr><br>");
    localStringBuffer.append(E(0));
    localStringBuffer.append("</html>");
    return localStringBuffer.toString();
  }

  public String G(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<html>");
    localStringBuffer.append(E(1));
    localStringBuffer.append("<br><hr>");
    localStringBuffer.append(R(paramString));
    localStringBuffer.append("</html>");
    return localStringBuffer.toString();
  }

  private String R(String paramString)
  {
    String str1 = "#aaaacc";
    String str2 = "#ddddff";
    String str3 = "white";
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<table align=center cellspacing=0 width=90%>");
    G localG = T(paramString);
    if (localG != null)
    {
      localStringBuffer.append("<tr><td>");
      localStringBuffer.append("<table width=100%>");
      localStringBuffer.append("<tr><td align=center>");
      localStringBuffer.append("<table align=center width=80%>");
      localStringBuffer.append("<tr bgcolor=" + str2 + "><td valign=center align=center ><b>" + "<font face=Arial size=3>" + E.D("TournamentInfo.MyStackTitle") + "</b></td></tr>");
      localStringBuffer.append("<tr bgcolor=" + str2 + "><td valign=center align=center ><b>" + "<font face=Arial size=3>" + Action.formatCash(localG.F()) + "</b></td></tr>");
      localStringBuffer.append("</table></td>");
      localStringBuffer.append("<td>");
      localStringBuffer.append("<table align=center width=80%>");
      localStringBuffer.append("<tr bgcolor=" + str2 + " width=80%>");
      localStringBuffer.append("<td align=right><b><font face=Arial size=3>" + b.A(localG.F() / d() * 100.0D, 2) + "</b>%</td>");
      if (d() > 0.0D)
        localStringBuffer.append("<td><font face=Arial size=3>" + E.D("TournamentInfo.OfTotalChips") + "</td>");
      else
        localStringBuffer.append("<td></td>");
      localStringBuffer.append("</tr>");
      localStringBuffer.append("<tr>");
      Object[] arrayOfObject1 = { new Double(b.A(localG.F() / H(), 3)) };
      localStringBuffer.append("<td align=right><b><font face=Arial size=3>" + E.A("TournamentInfo.NumberTimesPattern", arrayOfObject1) + "</td>");
      if (H() > 0.0D)
        localStringBuffer.append("<td><font face=Arial size=3>" + E.D("TournamentInfo.AverageChips") + "</td>");
      else
        localStringBuffer.append("<td></td>");
      localStringBuffer.append("</tr>");
      localStringBuffer.append("<tr bgcolor=" + str2 + ">");
      Object[] arrayOfObject2 = { new Double(b.A(localG.F() / X().M(), 3)) };
      localStringBuffer.append("<td align=right><b><font face=Arial size=3>" + E.A("TournamentInfo.NumberTimesPattern", arrayOfObject1) + "</td>");
      if ((X() != null) && (X().M() > 0.0D))
        localStringBuffer.append("<td><font face=Arial size=3>" + E.D("TournamentInfo.BigBlind") + "</td>");
      else
        localStringBuffer.append("<td></td>");
      localStringBuffer.append("</tr>");
    }
    localStringBuffer.append("</table>");
    localStringBuffer.append("</td>");
    localStringBuffer.append("</table>");
    localStringBuffer.append("</td></tr>");
    localStringBuffer.append("<tr><td><hr></td></tr>");
    localStringBuffer.append("<tr><td>");
    localStringBuffer.append("<table align=center width=100%>");
    localStringBuffer.append("<tr><td>");
    localStringBuffer.append("<table align=center width=80%>");
    localStringBuffer.append("<tr bgcolor=" + str2 + "><td align=center>" + "<font face=Arial size=3>" + "<b>" + E.D("TournamentInfo.Stack") + "</b></td></tr>");
    localStringBuffer.append("<tr bgcolor=" + str2 + "><td align=center>" + "<font face=Arial size=3>" + "<b>" + E.D("TournamentInfo.Sizes") + "</b></td></tr>");
    localStringBuffer.append("</table>");
    localStringBuffer.append("</td><td>");
    localStringBuffer.append("<table align=center valign=top width=80% cellspacing=3 border=0");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=center><b><font face=Arial size=3>" + E.D("TournamentInfo.Largest") + "</b></td>");
    localStringBuffer.append("<td align=center><b><font face=Arial size=3>" + E.D("TournamentInfo.Average") + "</b></td>");
    localStringBuffer.append("<td align=center><b><font face=Arial size=3>" + E.D("TournamentInfo.Smallest") + "</b></td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=center bgcolor=" + str2 + ">" + "<font face=Arial size=3>" + Action.formatCash(N()) + "</td>");
    localStringBuffer.append("<td align=center bgcolor=" + str2 + ">" + "<font face=Arial size=3>" + Action.formatCash(H()) + "</td>");
    localStringBuffer.append("<td align=center bgcolor=" + str2 + ">" + "<font face=Arial size=3>" + Action.formatCash(¤()) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("</table>");
    localStringBuffer.append("</td></tr>");
    localStringBuffer.append("</table>");
    localStringBuffer.append("</td></tr>");
    localStringBuffer.append("</table>");
    return localStringBuffer.toString();
  }

  private String O(String paramString)
  {
    String str1 = "#aaaacc";
    String str2 = "#ddddff";
    String str3 = "white";
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<table align=center cellspacing=0 width=100%>");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td>");
    localStringBuffer.append("<table align=center width=100%>");
    localStringBuffer.append("<tr bgcolor=" + str2 + ">");
    localStringBuffer.append("<td align=right><b><font face=Arial size=3>" + E.D("TournamentInfo.BuyIn") + "</b></td>");
    localStringBuffer.append("<td><font face=Arial size=3>" + n() + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><font face=Arial size=3><b>" + E.D("TournamentInfo.PrizePoolTitle") + "</b></td>");
    localStringBuffer.append("<td><font face=Arial size=3>" + Action.formatCash(i()) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr bgcolor=" + str2 + ">");
    localStringBuffer.append("<td align=\"right\"><font face=Arial size=3><b>" + E.D("TournamentInfo.ChipsInPlayTitle") + "</b></td>");
    if (d() > 0.0D)
      localStringBuffer.append("<td><font face=Arial size=3>" + Action.formatCash(d()) + "</td>");
    else
      localStringBuffer.append("<td></td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=right>");
    localStringBuffer.append("<font face=Arial size=3><b>Current Level:</b></td><td><font face=Arial size=3>" + (A() + 1) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("</table>");
    localStringBuffer.append("</td><td>");
    localStringBuffer.append("<table align=center>");
    G localG = T(paramString);
    int i = D(localG);
    if (i != -1)
    {
      localStringBuffer.append("<tr bgcolor=" + str2 + ">");
      localStringBuffer.append("<td align=\"right\"><font face=Arial size=3><b>" + E.D("TournamentInfo.RankingTitle") + "</b></td>");
      arrayOfObject = new Object[] { new Integer(i), new Integer(this.M) };
      localStringBuffer.append("<td><font face=Arial size=3>" + E.A("TournamentInfo.OutOfPattern", arrayOfObject) + "</td>");
      localStringBuffer.append("</tr>");
    }
    else
    {
      localStringBuffer.append("<tr bgcolor=" + str2 + ">");
      localStringBuffer.append("<td align=\"right\">&nbsp;</td>");
      localStringBuffer.append("<td>&nbsp;</td>");
      localStringBuffer.append("</tr>");
    }
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><font face=Arial size=3><b>" + E.D("TournamentInfo.PlayersLeftTitle") + "</b></td>");
    Object[] arrayOfObject = { new Integer(this.X), new Integer(this.M) };
    localStringBuffer.append("<td><font face=Arial size=3>" + E.A("TournamentInfo.OutOfPattern", arrayOfObject) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr bgcolor=" + str2 + ">");
    localStringBuffer.append("<td align=\"right\"><font face=Arial size=3><b>" + E.D("TournamentInfo.StartingChipsTitle") + "</b></td>");
    localStringBuffer.append("<td><font face=Arial size=3>" + Action.formatCash(m()) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append(A(null));
    localStringBuffer.append("</table></td></tr>");
    localStringBuffer.append("<tr><td colspan=2><hr></td></tr>");
    localStringBuffer.append("<tr><td colspan=2>");
    localStringBuffer.append(R(paramString));
    localStringBuffer.append("</td></tr>");
    localStringBuffer.append("</font></table>");
    return localStringBuffer.toString();
  }

  private String A(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    if (k() > 0.0D)
    {
      localStringBuffer.append("<tr bgcolor=" + paramString + ">");
      localStringBuffer.append("<td align=center><font face=Arial size=3><b>" + E.D("TournamentInfo.AnteTitle") + "</b> " + Action.formatCash(k()) + "</td>");
      localStringBuffer.append("<td><font face=Arial size=3><b>" + E.D("TournamentInfo.BlindsTitle") + "</b> " + Action.formatCash(u()) + "/" + Action.formatCash(g()) + "</td>");
      localStringBuffer.append("</tr>");
    }
    else
    {
      localStringBuffer.append("<tr bgcolor=" + paramString + ">");
      localStringBuffer.append("<td align=right><font face=Arial size=3><b>" + E.D("TournamentInfo.BlindsTitle") + "</b></td><td>" + Action.formatCash(u()) + "/" + Action.formatCash(g()) + "</td>");
      localStringBuffer.append("</tr>");
    }
    return localStringBuffer.toString();
  }

  private String L(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=center colspan=2>");
    localStringBuffer.append("<table align=center cellspacing=3 border=0");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=center><font face=Arial size=3><b>" + E.D("TournamentInfo.Largest") + "</b></td>");
    localStringBuffer.append("<td align=center><font face=Arial size=3><b>" + E.D("TournamentInfo.Average") + "</b></td>");
    localStringBuffer.append("<td align=center><font face=Arial size=3><b>" + E.D("TournamentInfo.Smallest") + "</b></td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<font face=Arial size=3><tr>");
    localStringBuffer.append("<td align=center bgcolor=" + paramString + ">" + "<font face=Arial size=3>" + Action.formatCash(N()) + "</td>");
    localStringBuffer.append("<td align=center bgcolor=" + paramString + ">" + "<font face=Arial size=3>" + Action.formatCash(H()) + "</td>");
    localStringBuffer.append("<td align=center bgcolor=" + paramString + ">" + "<font face=Arial size=3>" + Action.formatCash(¤()) + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("</table>");
    localStringBuffer.append("</td>");
    localStringBuffer.append("</tr>");
    return localStringBuffer.toString();
  }

  public List P()
  {
    if (this.U != null)
      return this.U;
    return new ArrayList();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.R
 * JD-Core Version:    0.6.2
 */