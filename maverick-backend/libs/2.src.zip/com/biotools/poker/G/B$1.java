package com.biotools.poker.G;

import com.biotools.B.N;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.ListSelectionModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;

final class B$1 extends N
{
  final B this$0;

  B$1(B paramB, TableModel paramTableModel)
  {
    super(paramTableModel);
  }

  public Component prepareRenderer(TableCellRenderer paramTableCellRenderer, int paramInt1, int paramInt2)
  {
    Component localComponent = super.prepareRenderer(paramTableCellRenderer, paramInt1, paramInt2);
    if (getSelectionModel().isSelectedIndex(paramInt1))
    {
      localComponent.setBackground(B.access$1().darker());
      localComponent.setFont(localComponent.getFont().deriveFont(1));
    }
    else
    {
      localComponent.setForeground(Color.BLACK);
    }
    return localComponent;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.B.1
 * JD-Core Version:    0.6.2
 */