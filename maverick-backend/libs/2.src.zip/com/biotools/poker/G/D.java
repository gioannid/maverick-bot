package com.biotools.poker.G;

public class D
{
  protected volatile int B = -1;
  protected volatile boolean A = false;

  public int A(U paramU, String paramString, int paramInt)
  {
    return paramInt;
  }

  public void A(int paramInt)
  {
    this.B = paramInt;
  }

  public void A(boolean paramBoolean)
  {
    this.A = paramBoolean;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.D
 * JD-Core Version:    0.6.2
 */