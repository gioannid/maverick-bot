package com.biotools.poker.G.A;

import com.biotools.poker.G.d;
import javax.swing.table.AbstractTableModel;

public abstract class G extends AbstractTableModel
{
  protected d A;

  public G(d paramd)
  {
    this.A = paramd;
  }

  public abstract String[] A();

  public String getColumnName(int paramInt)
  {
    return A()[paramInt].toString();
  }

  public int getRowCount()
  {
    return this.A.I();
  }

  public int getColumnCount()
  {
    return A().length;
  }

  public abstract Object getValueAt(int paramInt1, int paramInt2);

  public Class getColumnClass(int paramInt)
  {
    Object localObject = getValueAt(0, paramInt);
    if (localObject == null)
      return Object.class;
    return localObject.getClass();
  }

  public abstract boolean isCellEditable(int paramInt1, int paramInt2);

  public abstract void setValueAt(Object paramObject, int paramInt1, int paramInt2);

  public d B()
  {
    return this.A;
  }

  public void A(d paramd)
  {
    this.A = paramd;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.A.G
 * JD-Core Version:    0.6.2
 */