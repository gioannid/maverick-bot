package com.biotools.poker.G.A;

import com.biotools.B.J;
import com.biotools.B.N;
import com.biotools.poker.E;
import com.biotools.poker.G.d;
import com.biotools.poker.G.e;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.text.DecimalFormat;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

public class C extends JPanel
{
  protected d D = new d(d.F());
  protected _A B;
  protected N Q;
  private JToolBar H;
  private JLabel O;
  protected JButton J;
  protected JButton E;
  protected boolean F = false;
  protected int S = -1;
  protected int R = 60;
  protected int K = 15;
  public static final int P = 0;
  public static final int N = 1;
  public static final int C = 2;
  public static final int M = 3;
  private int[] A = { 10, 15, 35, 35 };
  private Vector L = new Vector();
  public static final DecimalFormat I = new DecimalFormat(E.D("TournamentClock.TournamentLevelEditor.DecimalFormat"));
  private static final Color G = new Color(200, 220, 200);

  public C()
  {
    setLayout(new BorderLayout(3, 3));
    add(A(), "East");
    add(O(), "Center");
    add(D(), "South");
  }

  private JToolBar A()
  {
    if (this.H == null)
    {
      this.H = new JToolBar(1);
      this.H.setRollover(true);
      this.H.setFloatable(false);
      this.H.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
      this.H.add(F());
      this.H.add(J());
    }
    return this.H;
  }

  private JLabel D()
  {
    if (this.O == null)
      this.O = new JLabel(E.D("TournamentClock.TournamentLevelEditor.StatusBar"), 0);
    L();
    return this.O;
  }

  public void L()
  {
    int i = I();
    if (i < 0)
    {
      this.O.setForeground(Color.BLACK);
      this.O.setText(E.D("TournamentClock.TournamentLevelEditor.StatusOK"));
    }
    else
    {
      this.O.setForeground(Color.RED);
      Object[] arrayOfObject = { new Integer(i + 1) };
      this.O.setText("<html" + E.A("TournamentClock.TournamentLevelEditor.ErrorBadLevelPattern", arrayOfObject) + " " + C(i) + "</html>");
    }
  }

  private JScrollPane O()
  {
    J().setEnabled(false);
    this.Q = new N(N())
    {
      public Component prepareRenderer(TableCellRenderer paramAnonymousTableCellRenderer, int paramAnonymousInt1, int paramAnonymousInt2)
      {
        Component localComponent = super.prepareRenderer(paramAnonymousTableCellRenderer, paramAnonymousInt1, paramAnonymousInt2);
        if (paramAnonymousInt1 == C.this.E())
        {
          localComponent.setBackground(C.G);
          if (getSelectionModel().isSelectedIndex(paramAnonymousInt1))
            localComponent.setBackground(C.G.darker());
          localComponent.setFont(localComponent.getFont().deriveFont(1));
        }
        if (C.this.D.A(paramAnonymousInt1, paramAnonymousInt2))
          localComponent.setForeground(Color.RED);
        else
          localComponent.setForeground(Color.BLACK);
        return localComponent;
      }
    };
    this.Q.getSelectionModel().addListSelectionListener(new ListSelectionListener()
    {
      public void valueChanged(ListSelectionEvent paramAnonymousListSelectionEvent)
      {
        if (!C.this.F)
        {
          ListSelectionModel localListSelectionModel = (ListSelectionModel)paramAnonymousListSelectionEvent.getSource();
          C.this.J().setEnabled(!localListSelectionModel.isSelectionEmpty());
        }
      }
    });
    this.Q.addPropertyChangeListener(new PropertyChangeListener()
    {
      public void propertyChange(PropertyChangeEvent paramAnonymousPropertyChangeEvent)
      {
        C.this.L();
      }
    });
    JScrollPane localJScrollPane = new JScrollPane(this.Q);
    this.Q.setPreferredScrollableViewportSize(new Dimension(160, 180));
    C();
    return localJScrollPane;
  }

  private void C()
  {
    String[] arrayOfString = { "", E.D("TournamentClock.TournamentLevelEditor.EditAnte"), E.D("TournamentClock.TournamentLevelEditor.EditSmallBlind"), E.D("TournamentClock.TournamentLevelEditor.EditBigBlind") };
    TableColumnModel localTableColumnModel = this.Q.getColumnModel();
    assert (localTableColumnModel.getColumnCount() == arrayOfString.length);
    for (int i = 0; i < localTableColumnModel.getColumnCount(); i++)
    {
      DefaultTableCellRenderer localDefaultTableCellRenderer = new DefaultTableCellRenderer();
      localDefaultTableCellRenderer.setHorizontalAlignment(0);
      if (i > 0)
        localDefaultTableCellRenderer.setToolTipText(arrayOfString[i]);
      TableColumn localTableColumn = localTableColumnModel.getColumn(i);
      localTableColumn.setCellRenderer(localDefaultTableCellRenderer);
      localTableColumn.setPreferredWidth(this.A[i]);
    }
  }

  private AbstractTableModel N()
  {
    this.B = new _A(this.D);
    return this.B;
  }

  public void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener)
  {
    this.L.add(paramPropertyChangeListener);
  }

  public void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener)
  {
    this.L.remove(paramPropertyChangeListener);
  }

  public void K()
  {
    PropertyChangeEvent localPropertyChangeEvent = new PropertyChangeEvent(this, E.D("TournamentClock.TournamentLevelEditor.Levels"), null, null);
    for (int i = 0; i < this.L.size(); i++)
    {
      PropertyChangeListener localPropertyChangeListener = (PropertyChangeListener)this.L.get(i);
      localPropertyChangeListener.propertyChange(localPropertyChangeEvent);
    }
  }

  protected void B(int paramInt)
  {
    if (paramInt >= 0)
    {
      this.D.B(paramInt);
      this.B.fireTableRowsInserted(paramInt, paramInt);
    }
    else
    {
      paramInt = this.B.getRowCount() - 1;
      if (paramInt < 0)
        paramInt = 0;
      this.D.B(paramInt);
      this.B.fireTableRowsInserted(paramInt, paramInt);
    }
    K();
  }

  protected void A(int paramInt)
  {
    if (paramInt >= 0)
    {
      this.D.D(paramInt);
      this.B.fireTableRowsDeleted(paramInt, paramInt);
    }
    K();
  }

  private JButton F()
  {
    if (this.J == null)
    {
      this.J = new J("plus.png", E.D("TournamentClock.TournamentLevelEditor.InsertLevel"));
      this.J.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          C.this.G();
        }
      });
    }
    return this.J;
  }

  private JButton J()
  {
    if (this.E == null)
    {
      this.E = new J("minus.png", E.D("TournamentClock.TournamentLevelEditor.RemoveLevel"));
      this.E.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          C.this.M();
        }
      });
    }
    return this.E;
  }

  private void A(Double paramDouble, int paramInt1, int paramInt2)
  {
    e locale = this.D.C(paramInt1);
    if (paramInt2 == 1)
    {
      locale.A(paramDouble.doubleValue());
    }
    else if (paramInt2 == 2)
    {
      locale.C(paramDouble.doubleValue());
      locale.B(paramDouble.doubleValue() * 2.0D);
    }
    else if (paramInt2 == 3)
    {
      locale.B(paramDouble.doubleValue());
    }
    this.D.A(paramInt1, locale);
  }

  public d B()
  {
    return new d(this.D);
  }

  public void A(d paramd)
  {
    this.D = new d(paramd);
    this.B.A(this.D);
    this.B.fireTableDataChanged();
  }

  public void A(boolean paramBoolean)
  {
    this.F = paramBoolean;
    this.J.setEnabled(!paramBoolean);
    this.E.setEnabled(!paramBoolean);
  }

  public void B(boolean paramBoolean)
  {
    this.E.setEnabled(paramBoolean);
  }

  public void D(int paramInt)
  {
    this.S = (paramInt - 1);
  }

  public int E()
  {
    return this.S;
  }

  private void M()
  {
    int[] arrayOfInt = this.Q.getSelectedRows();
    int i = this.Q.getSelectedRow();
    if (arrayOfInt.length == 0)
      A(this.Q.getRowCount() - 1);
    else
      for (int j = arrayOfInt.length - 1; j >= 0; j--)
        A(arrayOfInt[j]);
    if (i == this.Q.getRowCount())
      i--;
    if ((i >= 0) && (this.Q.getRowCount() > 0))
      this.Q.setRowSelectionInterval(i, i);
    if (this.Q.getRowCount() == 0)
      J().setEnabled(false);
  }

  private void G()
  {
    int i = this.Q.getSelectedRow();
    B(i);
    this.Q.setRowSelectionInterval(i + 1, i + 1);
    J().setEnabled(true);
  }

  public boolean H()
  {
    return I() < 0;
  }

  public int I()
  {
    for (int i = 0; i < this.D.I(); i++)
    {
      e locale = this.D.C(i);
      if (locale.R() > locale.M())
        return i;
      if ((locale.R() == 0.0D) || (locale.M() == 0.0D))
        return i;
    }
    return -1;
  }

  public String C(int paramInt)
  {
    e locale = this.D.C(paramInt);
    if (locale.R() > locale.M())
      return E.D("TournamentClock.TournamentLevelEditor.SmallBlindBiggerThanBigBlind");
    if (locale.M() == 0.0D)
      return E.D("TournamentClock.TournamentLevelEditor.BigBlindGreaterThan0");
    if (locale.R() == 0.0D)
      return E.D("TournamentClock.TournamentLevelEditor.SmallBlindGreaterThan0");
    return null;
  }

  private class _A extends G
  {
    private String[] B = { E.D("TournamentClock.TournamentLevelEditor.Level"), E.D("TournamentClock.TournamentLevelEditor.Ante"), E.D("TournamentClock.TournamentLevelEditor.SmallBlind"), E.D("TournamentClock.TournamentLevelEditor.BigBlind") };

    public _A(d arg2)
    {
      super();
    }

    public String[] A()
    {
      return this.B;
    }

    public Object getValueAt(int paramInt1, int paramInt2)
    {
      int i = paramInt1;
      e locale = this.A.C(paramInt1);
      switch (paramInt2)
      {
      case 0:
        return new Integer(paramInt1 + 1);
      case 1:
        return C.I.format(new Double(locale.J()));
      case 2:
        return C.I.format(new Double(locale.R()));
      case 3:
        return C.I.format(new Double(locale.M()));
      }
      return "";
    }

    public void setValueAt(Object paramObject, int paramInt1, int paramInt2)
    {
      Double localDouble = null;
      if (paramObject.getClass() == String.class)
        try
        {
          StringBuffer localStringBuffer = new StringBuffer((String)paramObject);
          while (localStringBuffer.indexOf(",") != -1)
            localStringBuffer.deleteCharAt(localStringBuffer.indexOf(","));
          localDouble = new Double(localStringBuffer.toString());
        }
        catch (NumberFormatException localNumberFormatException)
        {
          localDouble = null;
        }
      else
        localDouble = (Double)paramObject;
      if (localDouble != null)
      {
        if (localDouble.doubleValue() < 0.0D)
          localDouble = new Double(-localDouble.doubleValue());
        C.this.A(localDouble, paramInt1, paramInt2);
        fireTableDataChanged();
        C.this.K();
      }
      C.this.Q.setRowSelectionInterval(paramInt1, paramInt1);
    }

    public boolean isCellEditable(int paramInt1, int paramInt2)
    {
      return (paramInt2 != 0) && (!C.this.F);
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.A.C
 * JD-Core Version:    0.6.2
 */