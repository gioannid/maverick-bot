package com.biotools.poker.G;

import com.biotools.A.N;

public class V
{
  public static final String C = "buy_in";
  private double A = 0.0D;
  private double B = 0.0D;

  public V(double paramDouble1, double paramDouble2)
  {
    this.A = paramDouble1;
    this.B = paramDouble2;
  }

  public double A()
  {
    return this.A;
  }

  public void A(double paramDouble)
  {
    this.A = paramDouble;
  }

  public double C()
  {
    return this.B;
  }

  public void B(double paramDouble)
  {
    this.B = paramDouble;
  }

  public N B()
  {
    N localN = new N("buy_in");
    localN.A("toPrize", A());
    localN.A("toHouse", C());
    return localN;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.V
 * JD-Core Version:    0.6.2
 */