package com.biotools.poker.G;

import com.biotools.A.N;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.xml.sax.Attributes;

public class E
{
  private List A;
  public static final String B = "buy_ins";

  public E()
  {
    this.A = null;
  }

  public E(List paramList)
  {
    this.A = paramList;
  }

  public E(E paramE)
  {
    this.A = new ArrayList(paramE.B());
  }

  public void A(double paramDouble1, double paramDouble2)
  {
    B().add(new V(paramDouble1, paramDouble2));
  }

  public void A(V paramV)
  {
    B().add(paramV);
  }

  public List B()
  {
    if (this.A == null)
      this.A = new ArrayList();
    return this.A;
  }

  public V B(int paramInt)
  {
    assert (paramInt < B().size());
    assert (paramInt >= 0);
    return (V)B().get(paramInt);
  }

  public void C(int paramInt)
  {
    assert (paramInt < B().size());
    assert (paramInt >= 0);
    B().remove(paramInt);
  }

  public void A(List paramList)
  {
    this.A = paramList;
  }

  public int C()
  {
    return B().size();
  }

  public V F(int paramInt)
  {
    ArrayList localArrayList = new ArrayList();
    V localV = new V(E(paramInt), A(paramInt));
    localArrayList.add(localV);
    this.A = localArrayList;
    return localV;
  }

  public double E(int paramInt)
  {
    if ((paramInt >= 0) && (paramInt < B().size()))
      return ((V)B().get(paramInt)).A();
    return 0.0D;
  }

  public double A(int paramInt)
  {
    if ((paramInt >= 0) && (paramInt < B().size()))
      return ((V)B().get(paramInt)).C();
    return 0.0D;
  }

  public N A()
  {
    N localN = new N("buy_ins");
    Iterator localIterator = B().iterator();
    while (localIterator.hasNext())
    {
      V localV = (V)localIterator.next();
      localN.A(localV.B());
    }
    return localN;
  }

  public void A(Attributes paramAttributes)
  {
    double d1 = -1.0D;
    double d2 = -1.0D;
    String str = paramAttributes.getValue("toPrize");
    if (str != null)
      d1 = Double.parseDouble(str);
    str = paramAttributes.getValue("toHouse");
    if (str != null)
      d2 = Double.parseDouble(str);
    if (d1 != -1.0D)
      A(d1, d2);
  }

  public void A(int paramInt, double paramDouble)
  {
    assert (paramInt < B().size());
    V localV = (V)B().get(paramInt);
    localV.A(paramDouble);
    B().set(paramInt, localV);
  }

  public void B(int paramInt, double paramDouble)
  {
    assert (paramInt < B().size());
    V localV = (V)B().get(paramInt);
    localV.B(paramDouble);
    B().set(paramInt, localV);
  }

  public void D(int paramInt)
  {
    V localV1 = new V(1.0D, 0.0D);
    if (B().size() <= 0)
    {
      B().add(localV1);
      return;
    }
    if (paramInt >= B().size())
      paramInt = B().size() - 1;
    if (paramInt < 0)
      paramInt = 0;
    V localV2 = (V)B().get(paramInt);
    localV1 = new V(localV2.A(), localV2.C());
    B().add(paramInt, localV1);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.E
 * JD-Core Version:    0.6.2
 */