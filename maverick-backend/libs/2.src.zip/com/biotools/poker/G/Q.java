package com.biotools.poker.G;

import com.biotools.poker.P.H;
import com.biotools.poker.PokerApp;

public class Q extends D
{
  PokerApp C = null;

  public Q(PokerApp paramPokerApp)
  {
    this.C = paramPokerApp;
  }

  public int A(U paramU, String paramString, int paramInt)
  {
    this.B = -1;
    if (paramU.X().£().equals(paramString))
    {
      H localH = new H(this, paramU.X(), paramString, paramInt, false);
      this.C.A(localH);
      while ((!this.A) && (this.B == -1))
        try
        {
          Thread.sleep(25L);
        }
        catch (InterruptedException localInterruptedException)
        {
          localInterruptedException.printStackTrace();
        }
      if (this.A)
      {
        A(0);
        localH.B(false);
      }
    }
    else
    {
      this.B = paramInt;
    }
    return this.B;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.Q
 * JD-Core Version:    0.6.2
 */