package com.biotools.poker.G;

import com.biotools.A.B;
import com.biotools.meerkat.Action;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.List;
import java.util.Vector;
import org.xml.sax.Attributes;

public class T
{
  public static final String G = "tourn_struct";
  private static final String F = "break";
  private static final String J = "breaks";
  private static final String C = "isring";
  protected M D = null;
  protected d I = null;
  List H = null;
  A E = null;
  boolean B = false;
  File A;

  public T()
  {
    this.D = new M();
    this.I = new d();
    this.E = new A();
  }

  public T(T paramT)
  {
    this.D = new M(paramT.p());
    this.I = new d(paramT.B());
    this.E = new A(paramT.N());
    this.B = paramT.k();
    B(paramT.G());
  }

  public static T C(File paramFile)
  {
    I localI = new I();
    localI.A(paramFile);
    return localI.B();
  }

  public static T A(String paramString)
  {
    I localI = new I();
    localI.A(paramString);
    return localI.B();
  }

  public T W()
  {
    if (k())
      return new L(this);
    return this;
  }

  public com.biotools.A.N À()
  {
    com.biotools.A.N localN1 = new com.biotools.A.N("tourn_struct");
    localN1.A(this.D.Y());
    localN1.A(this.I.C());
    localN1.A(r());
    localN1.A(this.E.C());
    com.biotools.A.N localN2 = new com.biotools.A.N("isring");
    localN2.A("val", this.B ? "t" : "f");
    localN1.A(localN2);
    return localN1;
  }

  public String F()
  {
    return À().toString();
  }

  public com.biotools.A.N r()
  {
    com.biotools.A.N localN = new com.biotools.A.N("breaks");
    return localN;
  }

  public String ª()
  {
    return this.D.X();
  }

  public boolean R()
  {
    return this.D.a();
  }

  public e G(int paramInt)
  {
    return this.I.C(paramInt);
  }

  public int j()
  {
    return this.I.D();
  }

  public boolean t()
  {
    return this.D.L();
  }

  public void B(boolean paramBoolean)
  {
    this.D.B(paramBoolean);
  }

  public boolean T()
  {
    return this.D.F();
  }

  public void A(boolean paramBoolean)
  {
    this.D.C(paramBoolean);
  }

  public boolean Y()
  {
    return this.D.W();
  }

  public int ¢()
  {
    return this.D.e();
  }

  public int Á()
  {
    return this.D.d();
  }

  public int µ()
  {
    return this.D.Z();
  }

  public int o()
  {
    return this.D.g();
  }

  public int v()
  {
    return this.D.H();
  }

  public void S(int paramInt)
  {
    this.D.B(paramInt);
  }

  public int ¥()
  {
    return this.D.S();
  }

  public void F(int paramInt)
  {
    this.D.J(paramInt);
  }

  public double X()
  {
    return this.D.b();
  }

  public double A(int paramInt)
  {
    double d = this.D.b();
    if (this.D.E())
      d *= paramInt;
    return d;
  }

  public List u()
  {
    return this.D.I();
  }

  public E J()
  {
    return this.D.K();
  }

  public void A(E paramE)
  {
    this.D.A(paramE);
  }

  public void A(double paramDouble1, double paramDouble2)
  {
    this.D.A(paramDouble1, paramDouble2);
  }

  public void A(List paramList)
  {
    this.D.A(paramList);
  }

  public void N(int paramInt)
  {
    this.D.H(paramInt);
  }

  public int y()
  {
    return this.D.G();
  }

  public int n()
  {
    return this.D.O();
  }

  public void Q(int paramInt)
  {
    this.D.A(paramInt);
  }

  public void A(V paramV)
  {
    this.D.A(paramV);
  }

  public double K(int paramInt)
  {
    return this.D.E(paramInt);
  }

  public double O(int paramInt)
  {
    return this.D.M(paramInt);
  }

  public double P()
  {
    return this.D.M().A();
  }

  public double M()
  {
    return this.D.M().C();
  }

  public boolean Z()
  {
    return this.D.A();
  }

  public void B(String paramString)
  {
    this.D.B(paramString);
  }

  public void L(int paramInt)
  {
    com.biotools.poker.E.H("Setting starting level to " + paramInt);
    this.D.I(paramInt);
  }

  public int I()
  {
    return this.D.P();
  }

  public a J(int paramInt)
  {
    return this.E.A(paramInt);
  }

  public double C(int paramInt1, int paramInt2)
  {
    return this.E.A(paramInt1, paramInt2);
  }

  public int R(int paramInt)
  {
    return this.E.C(paramInt);
  }

  public void C(int paramInt)
  {
    this.E.D(paramInt);
  }

  public void D()
  {
    this.E.E();
  }

  public void E(int paramInt)
  {
    this.E.B(paramInt);
  }

  public int O()
  {
    return this.D.T();
  }

  public boolean k()
  {
    return this.B;
  }

  public boolean E()
  {
    return !k();
  }

  public boolean f()
  {
    return (!k()) && (Á() > ¢());
  }

  public boolean d()
  {
    return (!k()) && (!f());
  }

  public int º()
  {
    if (k())
      return Y() ? 23 : 22;
    return Y() ? 21 : 20;
  }

  public void B(int paramInt)
  {
    this.D.O(paramInt);
  }

  public void V(int paramInt)
  {
    this.D.C(paramInt);
  }

  public void W(int paramInt)
  {
    this.D.L(paramInt);
  }

  public String toString()
  {
    return ª();
  }

  public Vector _()
  {
    Vector localVector = new Vector();
    for (int i = 0; i < n(); i++)
      localVector.add(Action.formatCash(K(i)) + " + " + Action.formatCash(O(i)));
    return localVector;
  }

  public String i()
  {
    return this.D.B();
  }

  public String C()
  {
    return this.D.U();
  }

  public File G()
  {
    return this.A;
  }

  public void B(File paramFile)
  {
    this.A = paramFile;
  }

  public int w()
  {
    return this.I.B.size();
  }

  public int l()
  {
    return this.I.K();
  }

  public int V()
  {
    return this.D.Q();
  }

  public void D(int paramInt)
  {
    this.D.F(paramInt);
  }

  public int K()
  {
    return G(0).F();
  }

  public String z()
  {
    return e.I(L());
  }

  public String M(int paramInt)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    String str1 = "#aaaacc";
    String str2 = "#ddddff";
    String str3 = "white";
    localStringBuffer.append("<center><table border=\"0\" width='100%'><tr bgcolor=" + str1 + "><td align=center>" + "<font face=Arial size=3>" + com.biotools.poker.E.D("TournamentStructure.Level") + "</font></td>" + "<td align=center>" + "<font face=Arial size=3>" + com.biotools.poker.E.D("TournamentStructure.Blinds") + "</font></td>" + "<td align=center>" + "<font face=Arial size=3>" + com.biotools.poker.E.D("TournamentStructure.Ante") + "</font></td></tr>");
    localStringBuffer.append("<ol>");
    for (int i = 0; i < this.I.B.size(); i++)
    {
      e locale = G(i);
      double d1 = locale.R();
      double d2 = locale.M();
      double d3 = locale.J();
      String str4 = new String("");
      String str5 = new String("");
      if (paramInt == i)
      {
        str4 = "<b>";
        str5 = "</b>";
      }
      if (locale.F() != -1)
      {
        localStringBuffer.append("<tr bgcolor=" + (i % 2 == 0 ? str3 : str2) + "><td align=center>" + "<font face=Arial size=3>" + str4 + (i + 1) + "</td><td align=center>" + "<font face=Arial size=3>" + str4 + Math.round(d1) + " / " + Math.round(d2) + str5 + "</td><td align=center>" + "<font face=Arial size=3>" + str4 + Math.round(d3) + str5 + "</td></tr>");
      }
      else if (locale.F() == -1)
      {
        localStringBuffer.append("<tr bgcolor=" + (i % 2 == 0 ? str3 : str2) + "><td align=center>" + "<font face=Arial size=3>" + str4 + (i + 1) + "</td><td align=center>" + "<font face=Arial size=3>" + str4 + Math.round(d1) + " / " + Math.round(d2) + str5 + "</td><td align=center>" + "<font face=Arial size=3>" + str4 + Math.round(d3) + str5 + "</td></tr>");
        localStringBuffer.append("</table></center>");
        return localStringBuffer.toString();
      }
    }
    localStringBuffer.append("</table></center>");
    return localStringBuffer.toString();
  }

  public String A(int paramInt, double paramDouble)
  {
    return this.E.A(paramInt, paramDouble);
  }

  public String c()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<html>");
    localStringBuffer.append("<head>");
    localStringBuffer.append("<style type=\"text/css\">");
    localStringBuffer.append("  body {font-family: Lucidia; font-size: 10px;}");
    localStringBuffer.append("</style>");
    localStringBuffer.append("</head><body>");
    localStringBuffer.append(i());
    localStringBuffer.append("</body></html>");
    return localStringBuffer.toString();
  }

  public String m()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<html>");
    localStringBuffer.append("<head>");
    localStringBuffer.append("<style type=\"text/css\">");
    localStringBuffer.append("  body {font-family: Lucidia; font-size: 10px;}");
    localStringBuffer.append("</style>");
    localStringBuffer.append("</head><body>");
    localStringBuffer.append("<p>");
    localStringBuffer.append(i());
    localStringBuffer.append("<p>");
    Object[] arrayOfObject1 = { q() };
    localStringBuffer.append(com.biotools.poker.E.A("TournamentStructure.BuyInPattern", arrayOfObject1));
    Object[] arrayOfObject2 = { new Integer(o()) };
    localStringBuffer.append(o() != 1 ? com.biotools.poker.E.A("TournamentStructure.EveryoneStartsPluralPattern", arrayOfObject2) : com.biotools.poker.E.A("TournamentStructure.EveryoneStartsSingularPattern", arrayOfObject2));
    if (x())
    {
      Object[] arrayOfObject3 = { new Integer(H()), e.I(L()) };
      localStringBuffer.append("  " + (H() > 1 ? com.biotools.poker.E.A("TournamentStructure.LevelIncreasePluralPattern", arrayOfObject3) : com.biotools.poker.E.A("TournamentStructure.LevelIncreaseSingularPattern", arrayOfObject3)));
    }
    localStringBuffer.append("<p>");
    localStringBuffer.append("</body></html>");
    return localStringBuffer.toString();
  }

  public void B(int paramInt1, int paramInt2)
  {
    this.I.B(paramInt1, paramInt2);
  }

  public void A(int paramInt1, int paramInt2)
  {
    this.I.C(paramInt1, paramInt2);
  }

  public String q()
  {
    if ((e() == 0.0D) && (X() > 0.0D))
      return "Freeroll";
    if (M() == 0.0D)
      return Action.formatCash(P());
    return Action.formatCash(P()) + "+" + Action.formatCash(M());
  }

  public Z s()
  {
    return this.D.D();
  }

  public boolean x()
  {
    return this.I.M();
  }

  public int H()
  {
    return this.I.J();
  }

  public int L()
  {
    return this.I.E();
  }

  public int a()
  {
    if (L() == 1)
      return (I() - 1) * H();
    return 0;
  }

  public int g()
  {
    if (L() == 0)
      return (I() - 1) * H() * 60000;
    return 0;
  }

  public int U()
  {
    if (L() == 2)
      return (I() - 1) * H();
    return 0;
  }

  public void E(Attributes paramAttributes)
  {
    this.D = M.A(paramAttributes);
  }

  public void A(Attributes paramAttributes)
  {
    this.I = new d();
  }

  public void H(Attributes paramAttributes)
  {
    this.I.A(e.C(paramAttributes));
  }

  public void G(Attributes paramAttributes)
  {
  }

  public void C(Attributes paramAttributes)
  {
    this.E = new A();
    this.E.A(this.D.X());
  }

  public void F(Attributes paramAttributes)
  {
    a locala = a.A(paramAttributes);
    if (locala != null)
      this.E.A(locala);
  }

  public void B(Attributes paramAttributes)
  {
    a locala = (a)this.E.A.get(this.E.A.size() - 1);
    int i = locala.F();
    List localList = locala.E;
    int j = 1;
    if (localList.size() > 0)
      j = ((N)localList.get(localList.size() - 1)).C() + 1;
    if (j > i)
    {
      com.biotools.poker.E.H("MaxEntrants should not be less than the previous paying spot");
      i = j;
    }
    N localN = N.A(paramAttributes, j, i);
    if (localN != null)
      locala.A(localN);
  }

  public void D(Attributes paramAttributes)
  {
    String str = paramAttributes.getValue("val");
    if (str != null)
      this.B = str.equals("t");
    else
      System.err.println("ERR: Cannot find ring game attribute");
  }

  public void T(int paramInt)
  {
    this.I.A(paramInt);
  }

  public String S()
  {
    return this.D.X();
  }

  public d B()
  {
    return this.I;
  }

  public void A(d paramd)
  {
    this.I = paramd;
  }

  public void C(String paramString)
  {
    this.D.C(paramString);
  }

  public void I(int paramInt)
  {
    this.D.N(paramInt);
  }

  public void P(int paramInt)
  {
    this.D.K(paramInt);
  }

  public int Q()
  {
    return this.D.C();
  }

  public void U(int paramInt)
  {
    this.D.A(paramInt);
  }

  public void h()
  {
    com.biotools.poker.E.H("Writing Structure to Disk: " + S());
    if (G() != null)
      try
      {
        B.A(F().getBytes(), G());
      }
      catch (IOException localIOException)
      {
        com.biotools.A.d.A(localIOException);
      }
  }

  public void £()
  {
    com.biotools.poker.E.H("Deleting Structure to Disk: " + S());
    if (G() != null)
      G().delete();
  }

  public void A(String paramString1, String paramString2)
  {
    this.D.A(paramString1, paramString2);
  }

  public void A(A paramA)
  {
    this.E = paramA;
  }

  public A N()
  {
    return this.E;
  }

  public void A(Z paramZ)
  {
    this.D.A(paramZ);
  }

  public void C(boolean paramBoolean)
  {
    this.D.A(paramBoolean);
  }

  public void A(File paramFile)
  {
    File localFile = G();
    String str = localFile.getName();
    B(new File(paramFile, str));
    h();
  }

  public void H(int paramInt)
  {
    this.D.D(paramInt);
  }

  public int ¤()
  {
    return this.D.f();
  }

  public void b()
  {
    try
    {
      B(File.createTempFile("cts", ".xml", com.biotools.poker.E.T()));
    }
    catch (Exception localException)
    {
      com.biotools.A.d.A(localException);
    }
  }

  public void A()
  {
    if (this.D.N())
      B(¢());
  }

  public M p()
  {
    return this.D;
  }

  public void D(boolean paramBoolean)
  {
    this.D.E(paramBoolean);
  }

  public double e()
  {
    return P() + M();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.T
 * JD-Core Version:    0.6.2
 */