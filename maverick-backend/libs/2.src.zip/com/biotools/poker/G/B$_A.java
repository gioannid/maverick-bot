package com.biotools.poker.G;

import java.util.List;
import javax.swing.table.AbstractTableModel;

class B$_A extends AbstractTableModel
{
  private String[] A = { com.biotools.poker.E.D("BuyInListEditor.MoneyToPrize"), com.biotools.poker.E.D("BuyInListEditor.MoneyToHouse") };
  final B this$0;

  public B$_A(B paramB, List paramList)
  {
  }

  public String[] A()
  {
    return this.A;
  }

  public String getColumnName(int paramInt)
  {
    return A()[paramInt].toString();
  }

  public Object getValueAt(int paramInt1, int paramInt2)
  {
    int i = paramInt1;
    switch (paramInt2)
    {
    case 0:
      return new Double(B.access$0(this.this$0).E(paramInt1));
    case 1:
      return new Double(B.access$0(this.this$0).A(paramInt1));
    }
    return "";
  }

  public void setValueAt(Object paramObject, int paramInt1, int paramInt2)
  {
    Double localDouble = null;
    localDouble = (Double)paramObject;
    if (localDouble != null)
    {
      if (localDouble.doubleValue() < 0.0D)
        localDouble = new Double(-localDouble.doubleValue());
      if (paramInt2 == 0)
        B.access$0(this.this$0).A(paramInt1, localDouble.doubleValue());
      else if (paramInt2 == 1)
        B.access$0(this.this$0).B(paramInt1, localDouble.doubleValue());
      fireTableCellUpdated(paramInt1, paramInt2);
      this.this$0.H();
    }
  }

  public Class getColumnClass(int paramInt)
  {
    Object localObject = getValueAt(0, paramInt);
    if (localObject == null)
      return Object.class;
    return localObject.getClass();
  }

  public boolean isCellEditable(int paramInt1, int paramInt2)
  {
    return true;
  }

  public int getRowCount()
  {
    return B.access$0(this.this$0).C();
  }

  public int getColumnCount()
  {
    return this.A.length;
  }

  public String toString()
  {
    return "BuyInListEditor";
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.B._A
 * JD-Core Version:    0.6.2
 */