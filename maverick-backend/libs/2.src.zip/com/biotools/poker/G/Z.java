package com.biotools.poker.G;

import com.biotools.A.N;
import com.biotools.poker.E;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;

public class Z
{
  public static final String F = "category";
  public static final String B = E.D("Category.NoLimit");
  public static final String A = E.D("Category.Limit");
  public static final String D = E.D("Category.MultiTable");
  public static final String E = E.D("Category.SingleTable");
  String C = null;
  Z G = null;

  public Z(String paramString)
  {
    this.C = paramString;
  }

  public Z(Element paramElement)
  {
    this.C = paramElement.getAttribute("name");
    NodeList localNodeList = paramElement.getElementsByTagName("category");
    if (localNodeList.getLength() > 0)
      this.G = new Z((Element)localNodeList.item(0));
  }

  public Z(Attributes paramAttributes)
  {
    this.C = paramAttributes.getValue("name");
  }

  public void A(Z paramZ)
  {
    if (this.G == null)
      this.G = paramZ;
    else
      this.G.A(paramZ);
  }

  public Z A()
  {
    return this.G;
  }

  public String D()
  {
    return this.C;
  }

  public String toString()
  {
    return this.C;
  }

  public String C()
  {
    return B().toString();
  }

  public N B()
  {
    N localN = new N("category");
    localN.A("name", D());
    if (A() != null)
      localN.A(A().B());
    return localN;
  }

  public boolean A(String paramString)
  {
    if (this.C.equals(paramString))
      return true;
    if (this.G != null)
      return this.G.A(paramString);
    return false;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.Z
 * JD-Core Version:    0.6.2
 */