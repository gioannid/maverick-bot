package com.biotools.poker.G;

import com.biotools.A.N;
import java.util.List;
import java.util.StringTokenizer;
import org.xml.sax.Attributes;

public class M
{
  public static final String[] Q = { "Texas Holdem" };
  public static final String[] L = { "No Limit", "Limit" };
  private static final int W = 50;
  public static final int H = 6600;
  public static final int J = 10;
  public static final int c = 2;
  public static final int j = 500000;
  public static final int Y = 100;
  private static final String P = ";;;";
  private String O;
  private String F;
  private String N = com.biotools.poker.E.D("TournamentDetails.UnknownTournament");
  private String g = Q[0];
  private String E = L[0];
  private int k = 0;
  private double B = 0.0D;
  private E D = null;
  private V f = null;
  private int _ = 1000;
  private int U = 10;
  private int G = 100;
  private int M = 500000;
  private int e = 0;
  private int A = 10;
  private int d = 3;
  private int R = 6600;
  private int K = 10;
  private int C = 1;
  private int Z = 0;
  private boolean T = false;
  private boolean V = false;
  private boolean a = false;
  private Z I = null;
  private boolean X = true;
  private boolean S = false;
  public static final String i = "details";
  public static final String h = "buy_ins";
  public static final String b = "buy_in";

  public M()
  {
  }

  public M(M paramM)
  {
    this.O = paramM.B();
    this.F = paramM.U();
    this.N = paramM.X();
    this.g = paramM.V();
    this.E = paramM.c();
    this.k = paramM.C();
    this.B = paramM.b();
    this.D = paramM.K();
    this.f = paramM.M();
    this._ = paramM.g();
    this.U = paramM.f();
    this.e = paramM.T();
    this.A = paramM.Q();
    this.d = paramM.Z();
    this.R = paramM.d();
    this.K = paramM.e();
    this.C = paramM.P();
    this.Z = paramM.G();
    this.T = paramM.a();
    this.a = paramM.F();
    this.V = paramM.A();
    this.I = paramM.D();
    this.X = paramM.X;
    this.S = paramM.E();
  }

  public boolean L()
  {
    return this.X;
  }

  public void B(boolean paramBoolean)
  {
    this.X = paramBoolean;
  }

  public boolean F()
  {
    return this.a;
  }

  public void C(boolean paramBoolean)
  {
    this.a = paramBoolean;
  }

  public boolean W()
  {
    return this.E.equals(L[0]);
  }

  public String c()
  {
    return this.E;
  }

  public Z D()
  {
    return this.I;
  }

  public boolean a()
  {
    return this.T;
  }

  public void E(boolean paramBoolean)
  {
    this.T = paramBoolean;
  }

  public void D(String paramString)
  {
    int m = -1;
    for (int n = 0; n < L.length; n++)
      if (paramString.equals(L[n]))
      {
        m = n;
        break;
      }
    if (m != -1)
    {
      this.E = paramString;
      this.k = m;
    }
    else
    {
      com.biotools.poker.E.H("DO NOT UNDERSTAND THAT BETTING TYPE (" + paramString + ")!");
    }
  }

  public void K(int paramInt)
  {
    this.E = L[paramInt];
    this.k = paramInt;
  }

  public int C()
  {
    return this.k;
  }

  public void A(double paramDouble1, double paramDouble2)
  {
    int m = K().C();
    K().A(paramDouble1, paramDouble2);
    H(m);
  }

  public List I()
  {
    return K().B();
  }

  public void A(List paramList)
  {
    K().A(paramList);
    H(0);
  }

  public void A(E paramE)
  {
    this.D = new E(paramE);
  }

  public int O()
  {
    return K().C();
  }

  public void H(int paramInt)
  {
    this.Z = paramInt;
    if (K().B().size() > paramInt)
      this.f = K().B(paramInt);
  }

  public int G()
  {
    return this.Z;
  }

  public void A(int paramInt)
  {
    this.f = K().F(paramInt);
    this.Z = 0;
  }

  public void A(V paramV)
  {
    this.f = paramV;
  }

  public V M()
  {
    if (this.f == null)
      if (K().B().size() == 0)
        this.f = new V(0.0D, 0.0D);
      else
        this.f = K().B(0);
    return this.f;
  }

  public double E(int paramInt)
  {
    return K().E(paramInt);
  }

  public double M(int paramInt)
  {
    return K().A(paramInt);
  }

  public String V()
  {
    return this.g;
  }

  public String B()
  {
    if (this.O == null)
      return null;
    return this.O.trim();
  }

  public String R()
  {
    StringTokenizer localStringTokenizer = new StringTokenizer(this.O, ";;;");
    return localStringTokenizer.nextToken();
  }

  public void B(String paramString)
  {
    this.O = paramString;
  }

  public String U()
  {
    return this.F;
  }

  public void E(String paramString)
  {
    this.F = paramString;
  }

  public void A(String paramString)
  {
    int m = -1;
    for (int n = 0; n < Q.length; n++)
      if (paramString.equals(Q[n]))
      {
        m = n;
        break;
      }
    if (m != -1)
      this.g = paramString;
    else
      com.biotools.poker.E.H("DO NOT UNDERSTAND THAT GAME TYPE (" + paramString + ")!");
  }

  public double b()
  {
    return this.B;
  }

  public void A(double paramDouble)
  {
    this.B = paramDouble;
  }

  public int d()
  {
    return this.R;
  }

  public void O(int paramInt)
  {
    if (paramInt > 6600)
      paramInt = 6600;
    if (paramInt < 2)
      paramInt = 2;
    this.R = paramInt;
  }

  public int e()
  {
    return this.K;
  }

  public void N(int paramInt)
  {
    if (paramInt > 10)
      paramInt = 10;
    if (paramInt < 2)
      paramInt = 2;
    this.K = paramInt;
  }

  public int T()
  {
    return this.e;
  }

  public void G(int paramInt)
  {
    if (paramInt < 0)
      paramInt = 50;
    this.e = paramInt;
  }

  public int Z()
  {
    return this.d;
  }

  public void C(int paramInt)
  {
    if (paramInt < 2)
      paramInt = 2;
    this.d = paramInt;
    if (Q() < paramInt)
      F(paramInt);
    if (f() < paramInt)
      D(paramInt);
  }

  public int Q()
  {
    return this.A;
  }

  public void F(int paramInt)
  {
    if (paramInt < Z())
      paramInt = Z();
    this.A = paramInt;
  }

  public String X()
  {
    return this.N;
  }

  public void C(String paramString)
  {
    this.N = paramString;
  }

  public int g()
  {
    return this._;
  }

  public void L(int paramInt)
  {
    this._ = paramInt;
  }

  public int f()
  {
    return this.U;
  }

  public void D(int paramInt)
  {
    if (paramInt < Z())
      paramInt = Z();
    this.U = paramInt;
  }

  public int H()
  {
    return this.G;
  }

  public void B(int paramInt)
  {
    this.G = paramInt;
  }

  public int S()
  {
    return this.M;
  }

  public void J(int paramInt)
  {
    this.M = paramInt;
  }

  public int P()
  {
    return this.C;
  }

  public void I(int paramInt)
  {
    this.C = paramInt;
  }

  public boolean A()
  {
    return this.V;
  }

  public void A(boolean paramBoolean)
  {
    this.V = paramBoolean;
  }

  public String toString()
  {
    return X();
  }

  public N Y()
  {
    N localN = new N("details");
    localN.A("name", X());
    localN.A("game_type", V());
    localN.A("custom", A());
    localN.A("betting", c());
    localN.A("initial_prize_pool", b());
    localN.A("mult_prize_pool", E() ? "t" : "f");
    localN.A("start_chips", g());
    localN.A("start_players", Q());
    localN.A("min_start_chips", H());
    localN.A("max_start_chips", S());
    localN.A("max_rebuys_per_player", T());
    localN.A("min_players", Z());
    localN.A("max_players", d());
    localN.A("max_players_per_table", e());
    localN.A("online", a() ? "t" : "f");
    localN.A("raked", F() ? "t" : "f");
    localN.A("start_level", P());
    localN.A("buy_in_default", G());
    localN.A("play_money", L());
    if (D() != null)
      localN.A(D().B());
    localN.A(K().A());
    if (B() != null)
      localN.B(B());
    return localN;
  }

  public String _()
  {
    return Y().toString();
  }

  public static M A(Attributes paramAttributes)
  {
    M localM = new M();
    String str = paramAttributes.getValue("name");
    if (str != null)
      localM.C(str);
    str = paramAttributes.getValue("game_type");
    if (str != null)
      localM.A(str);
    str = paramAttributes.getValue("custom");
    if (str != null)
      localM.A(str.startsWith("t"));
    else
      localM.A(false);
    str = paramAttributes.getValue("betting");
    if (str != null)
      localM.D(str);
    str = paramAttributes.getValue("initial_prize_pool");
    if (str != null)
      localM.A(Double.parseDouble(str));
    str = paramAttributes.getValue("mult_prize_pool");
    if (str != null)
      localM.D(str.startsWith("t"));
    str = paramAttributes.getValue("start_chips");
    if (str != null)
      localM.L(Integer.parseInt(str));
    str = paramAttributes.getValue("min_start_chips");
    if (str != null)
      localM.B(Integer.parseInt(str));
    str = paramAttributes.getValue("max_start_chips");
    if (str != null)
      localM.J(Integer.parseInt(str));
    str = paramAttributes.getValue("max_rebuys_per_player");
    if (str != null)
      localM.G(Integer.parseInt(str));
    str = paramAttributes.getValue("min_players");
    if (str != null)
      localM.C(Integer.parseInt(str));
    str = paramAttributes.getValue("max_players");
    if (str != null)
      localM.O(Integer.parseInt(str));
    str = paramAttributes.getValue("max_players_per_table");
    if (str != null)
      localM.N(Integer.parseInt(str));
    str = paramAttributes.getValue("online");
    if (str != null)
      localM.E(str.startsWith("t"));
    str = paramAttributes.getValue("raked");
    if (str != null)
      localM.C(str.startsWith("t"));
    str = paramAttributes.getValue("play_money");
    if (str != null)
      localM.B(str.startsWith("t"));
    str = paramAttributes.getValue("start_level");
    if (str != null)
      localM.I(Integer.parseInt(str));
    else
      localM.I(1);
    str = paramAttributes.getValue("start_players");
    if (str != null)
      localM.F(Integer.parseInt(str));
    else
      localM.F(9);
    str = paramAttributes.getValue("buy_in_default");
    if (str != null)
      localM.H(Integer.parseInt(str));
    else
      localM.H(0);
    return localM;
  }

  public void B(Attributes paramAttributes)
  {
    K().A(paramAttributes);
  }

  public void C(Attributes paramAttributes)
  {
    if (this.I == null)
      this.I = new Z(paramAttributes);
    else
      this.I.A(new Z(paramAttributes));
  }

  public static Object[] J()
  {
    return L;
  }

  public void A(String paramString1, String paramString2)
  {
    this.I = new Z(paramString1);
    this.I.A(new Z(paramString2));
  }

  public E K()
  {
    if (this.D == null)
      this.D = new E();
    return this.D;
  }

  public void A(Z paramZ)
  {
    this.I = paramZ;
  }

  public boolean N()
  {
    return this.I.A(com.biotools.poker.E.D("TournamentDetails.SingleTable"));
  }

  public boolean E()
  {
    return this.S;
  }

  public void D(boolean paramBoolean)
  {
    this.S = paramBoolean;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.M
 * JD-Core Version:    0.6.2
 */