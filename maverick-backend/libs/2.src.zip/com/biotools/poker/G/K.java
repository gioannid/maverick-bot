package com.biotools.poker.G;

import com.biotools.meerkat.Action;
import com.biotools.poker.E;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.List;
import javax.swing.JComponent;

public class K extends JComponent
  implements MouseListener, MouseMotionListener
{
  private static final Color B = new Color(90, 200, 90);
  private static final Color N = new Color(90, 120, 90);
  private static final Color F = B.brighter();
  private static final Color O = N.brighter();
  private static final int K = 6;
  private double[] E;
  private double P;
  private double J;
  private double M = 0.0D;
  private int L = 0;
  private int A = 0;
  private double I = 0.0D;
  private List D;
  private int C = -1;
  private int H;
  private int G;

  public K()
  {
    addMouseMotionListener(this);
    addMouseListener(this);
  }

  public void A(R paramR)
  {
    this.D = paramR.R();
    this.E = new double[this.D.size()];
    this.P = 0.0D;
    this.A = 0;
    this.J = 0.0D;
    this.L = 0;
    this.M = 0.0D;
    for (int i = 0; i < this.D.size(); i++)
    {
      G localG = (G)this.D.get(i);
      if ((paramR.£() != null) && (localG.I().equals(paramR.£())))
      {
        this.J = localG.F();
        this.L = (localG.L() - 1);
      }
      this.E[i] = localG.F();
      if (this.E[i] > 0.0D)
      {
        this.M += this.E[i];
        this.A += 1;
      }
      this.P = Math.max(this.P, this.E[i]);
    }
    if (this.P > 0.0D)
    {
      this.J /= this.P;
      for (i = 0; i < this.E.length; i++)
        this.E[i] /= this.P;
    }
    this.I = (paramR.g() / this.P);
    this.M /= this.A * this.P;
    repaint();
  }

  public void mouseDragged(MouseEvent paramMouseEvent)
  {
  }

  public void mouseMoved(MouseEvent paramMouseEvent)
  {
    this.H = paramMouseEvent.getX();
    this.G = paramMouseEvent.getY();
    repaint();
  }

  public void mouseClicked(MouseEvent paramMouseEvent)
  {
  }

  public void mousePressed(MouseEvent paramMouseEvent)
  {
  }

  public void mouseReleased(MouseEvent paramMouseEvent)
  {
  }

  public void mouseEntered(MouseEvent paramMouseEvent)
  {
  }

  public void mouseExited(MouseEvent paramMouseEvent)
  {
    this.H = -1;
    this.G = -1;
    repaint();
  }

  public void paint(Graphics paramGraphics)
  {
    if (!isVisible())
      return;
    int i = getWidth() - 12;
    int j = getHeight() - 24;
    if (this.E == null)
      return;
    Graphics2D localGraphics2D = (Graphics2D)paramGraphics;
    localGraphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    double d = i / this.A;
    paramGraphics.setColor(getBackground());
    paramGraphics.fillRect(0, 0, getWidth(), getHeight());
    paramGraphics.setColor(getForeground());
    paramGraphics.setFont(new Font("Sans Serif", 0, 10));
    FontMetrics localFontMetrics = paramGraphics.getFontMetrics();
    paramGraphics.drawString(E.D("StackDistributionGraph.PlayerStacks"), getWidth() / 2 - localFontMetrics.stringWidth(E.D("StackDistributionGraph.PlayerStacks")) / 2, 4 + j + localFontMetrics.getHeight());
    if (this.I * j >= 10.0D)
    {
      paramGraphics.setColor(getBackground().brighter());
      k = 1;
      m = (int)(j - k * this.I * j + 6.0D);
      while (m > 6)
      {
        m = (int)(j - k * this.I * j + 6.0D);
        paramGraphics.drawLine(6, m, (int)(6.0D + d * this.A) - 2, m);
        k++;
      }
    }
    paramGraphics.setColor(getForeground());
    paramGraphics.drawLine(6, j + 6 - 1, (int)(6.0D + d * this.A) - 2, j + 6 - 1);
    if (d > 2.0D)
      for (k = 0; k < this.A; k++)
      {
        paramGraphics.setColor(getForeground());
        paramGraphics.drawLine((int)(d / 2.0D + 6.0D + d * k), j + 6 + 1, (int)(d / 2.0D + 6.0D + d * k), j + 6 - 5);
      }
    this.C = -1;
    int k = 0;
    int m = 0;
    int n = this.A / i;
    if (n < 2)
      n = 1;
    int i1 = -1;
    int i2 = 0;
    label453: 
    while (m == 0)
    {
      if (i2 >= this.A)
      {
        m = 1;
        if (n <= 1)
          break;
        i2 = this.A - 1;
        break label453;
        break;
      }
      k++;
      i1 = A(paramGraphics, i2, d, j, i1);
      i2 += n;
    }
    if ((this.J > 0.0D) && (d < 2.0D))
      i1 = A(paramGraphics, this.A - 1 - this.L, d, j, i1);
    int i3 = j - (int)(this.M * j) + 6;
    if (i3 > 12)
    {
      paramGraphics.setColor(getForeground());
      Object[] arrayOfObject = { Action.formatCash(this.M * this.P) };
      paramGraphics.drawString(E.A("StackDistributionGraph.AverageTitlePattern", arrayOfObject), 6, i3 - 2);
      paramGraphics.drawLine(6, i3, (int)(6.0D + d * this.A) - 2, i3);
    }
    int i4 = j - (int)(this.I * j) + 6;
    Object localObject;
    if ((i4 < j) && (i4 > i3 + localFontMetrics.getDescent()))
    {
      paramGraphics.setColor(getForeground());
      localObject = new Object[] { Action.formatCash(this.I * this.P) };
      paramGraphics.drawString(E.A("StackDistributionGraph.BigBlindTitle", (Object[])localObject), 6, i4 - 2);
      paramGraphics.drawLine(6, i4, (int)(6.0D + d * this.A) - 2, i4);
    }
    if (i1 >= 0)
    {
      localObject = (G)this.D.get(i1);
      String str = Action.formatCash(((G)localObject).F());
      int i5 = localFontMetrics.stringWidth(((G)localObject).I());
      int i6 = localFontMetrics.stringWidth(str);
      i5 = Math.max(i5, i6);
      Composite localComposite = localGraphics2D.getComposite();
      localGraphics2D.setComposite(AlphaComposite.getInstance(3, 0.75F));
      int i7 = 6;
      int i8 = 0;
      if (this.H + i5 > i + 6)
        i8 = i5;
      int i9 = this.H - i8;
      int i10 = this.G - localFontMetrics.getHeight() * 2;
      if (i10 < localFontMetrics.getHeight() * 2)
        i10 = this.G + 3 * localFontMetrics.getHeight();
      localGraphics2D.setColor(Color.DARK_GRAY);
      localGraphics2D.fillRoundRect(i9 - i7, i10 - localFontMetrics.getAscent(), i5 + i7 + i7, 2 * localFontMetrics.getHeight() + i7, i7 * 2, i7 * 2);
      localGraphics2D.setColor(Color.GREEN);
      localGraphics2D.drawRoundRect(i9 - i7, i10 - localFontMetrics.getAscent(), i5 + i7 + i7, 2 * localFontMetrics.getHeight() + i7, i7 * 2, i7 * 2);
      localGraphics2D.setColor(Color.BLACK);
      localGraphics2D.drawString(((G)localObject).I(), i9 + 1, i10 + i7 / 2 + 1);
      localGraphics2D.drawString(str, i9 + 1, localFontMetrics.getHeight() + i10 + i7 / 2 + 1);
      localGraphics2D.setColor(Color.YELLOW);
      localGraphics2D.drawString(((G)localObject).I(), i9, i10 + i7 / 2);
      localGraphics2D.drawString(str, i9, localFontMetrics.getHeight() + i10 + i7 / 2);
      localGraphics2D.setComposite(localComposite);
    }
  }

  private int A(Graphics paramGraphics, int paramInt1, double paramDouble, int paramInt2, int paramInt3)
  {
    int i = this.A - 1 - paramInt1;
    double d1 = this.E[i];
    double d2 = 6.0D + paramDouble * paramInt1;
    double d3 = 6.0D + paramDouble * (paramInt1 + 1);
    if (paramDouble < 1.0D)
      d3 = d2 + 1.0D;
    if ((this.H >= d2) && (this.H < d3))
      paramInt3 = i;
    if (d1 > 0.0D)
    {
      Color localColor = N;
      if (((d1 >= this.J) && (d1 <= this.J)) || (i == this.L))
      {
        localColor = B;
        if (paramInt3 == i)
          localColor = F;
      }
      else if (paramInt3 == i)
      {
        localColor = O;
      }
      paramGraphics.setColor(localColor);
      int j = (int)paramDouble;
      int k = (int)(6.0D + paramDouble * paramInt1);
      if (k > this.C)
      {
        k--;
        j++;
      }
      if (j > 1)
        paramGraphics.fill3DRect(k, paramInt2 - (int)(d1 * paramInt2) + 6, j, (int)(d1 * paramInt2), true);
      else
        paramGraphics.drawLine(k, paramInt2 - (int)(d1 * paramInt2) + 6, k, paramInt2 + 6 + 1);
      this.C = (k + j);
    }
    return paramInt3;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.K
 * JD-Core Version:    0.6.2
 */