package com.biotools.poker.G;

import com.biotools.meerkat.Action;
import com.biotools.poker.A;
import com.biotools.poker.E;
import com.biotools.poker.PokerApp;
import com.biotools.poker.Q.K;

public class X
  implements b
{
  boolean ʃ = false;
  boolean ʊ = false;
  boolean ʈ = false;
  boolean ʁ = false;
  String ʉ = null;
  boolean ʄ = false;
  boolean ʂ = false;
  PokerApp ʇ = null;
  public static final int ʀ = 3000;
  int[] ʆ = { 1000, 900, 800, 700, 600, 500, 400, 300, 200, 100, 50, 25, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };
  int ʅ = 0;

  public X(PokerApp paramPokerApp)
  {
    this.ʇ = paramPokerApp;
  }

  public void ƞ()
  {
    this.ʅ = 0;
    if (this.ʇ.Ȕ() != null)
    {
      int i = this.ʇ.Ȕ().v();
      for (int j = this.ʅ; j < this.ʆ.length; j++)
        if (i <= this.ʆ[j])
          this.ʅ += 1;
    }
    Ɲ();
  }

  public void Ɲ()
  {
    this.ʃ = false;
    this.ʊ = false;
    this.ʈ = false;
    this.ʁ = false;
    this.ʉ = null;
    this.ʄ = false;
    this.ʂ = false;
  }

  private String Ɵ()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    int i;
    if (this.ʄ)
    {
      localStringBuffer.append(E.D("TournamentAnnouncements.TournamentStarted"));
      if (this.ʇ.Ȕ() != null)
      {
        i = this.ʇ.Ȕ().v();
        Object[] arrayOfObject1 = { new Integer(i) };
        A(localStringBuffer, i > 1 ? E.A("TournamentAnnouncements.NumberOfTablesPattern", arrayOfObject1) : E.A("TournamentAnnouncements.NumberOfTablePattern", arrayOfObject1));
      }
      if (this.ʉ != null)
        A(localStringBuffer, this.ʉ);
      return localStringBuffer.toString();
    }
    if ((this.ʃ) && (this.ʇ.Ȕ() != null))
    {
      i = this.ʇ.Ȕ().v();
      int j = 0;
      for (int k = this.ʅ; k < this.ʆ.length; k++)
        if (i <= this.ʆ[k])
        {
          j = 1;
          this.ʅ += 1;
        }
      if (j != 0)
      {
        Object[] arrayOfObject2 = { new Integer(i) };
        A(localStringBuffer, i > 1 ? E.A("TournamentAnnouncements.DownToTablesPattern", arrayOfObject2) : E.A("TournamentAnnouncements.DownToTablePattern", arrayOfObject2));
      }
    }
    if (this.ʉ != null)
      A(localStringBuffer, this.ʉ);
    if (this.ʊ)
      A(localStringBuffer, E.D("TournamentAnnouncements.YouWereMoved"));
    return localStringBuffer.toString();
  }

  private void A(StringBuffer paramStringBuffer, String paramString)
  {
    if (paramStringBuffer.length() != 0)
      paramStringBuffer.append("|");
    paramStringBuffer.append(paramString);
  }

  public int ƚ()
  {
    int i = 0;
    String str = Ɵ();
    if (str.length() != 0)
    {
      E.H("Setting tournament announcement...");
      this.ʇ.ʋ().w(str);
      E.H("announces: " + str);
      E.H("table announce string: " + this.ʇ.ʋ().Ή);
      i = 3000;
    }
    else
    {
      this.ʇ.ʋ().w(null);
    }
    Ɲ();
    return i;
  }

  public boolean Ɯ()
  {
    return (this.ʈ) || (this.ʁ);
  }

  public boolean ƛ()
  {
    return this.ʈ;
  }

  public void A(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3)
  {
    Object[] arrayOfObject1 = { new Integer(paramInt) };
    Object[] arrayOfObject2 = { Action.formatCash(paramDouble1) };
    Object[] arrayOfObject3 = { Action.formatCash(paramDouble2), Action.formatCash(paramDouble3) };
    this.ʉ = (E.A("TournamentAnnouncements.AdvancingLevelPattern", arrayOfObject1) + " " + (paramDouble1 > 0.0D ? E.A("TournamentAnnouncements.AntePattern", arrayOfObject2) + " " : "") + E.A("TournamentAnnouncements.BlindsPattern", arrayOfObject3));
  }

  public void W(int paramInt)
  {
  }

  public void s(String paramString)
  {
  }

  public void A(String paramString, double paramDouble1, double paramDouble2)
  {
  }

  public void B(String paramString, double paramDouble1, double paramDouble2)
  {
  }

  public void r(String paramString)
  {
    if (paramString.equals(this.ʇ.ɬ()))
      this.ʈ = true;
    else
      this.ʁ = true;
  }

  public void A(String paramString, double paramDouble)
  {
  }

  public void A(String paramString, K paramK1, K paramK2, int paramInt1, int paramInt2)
  {
    if (paramString.equals(this.ʇ.ɬ()))
      this.ʊ = true;
  }

  public void V(int paramInt)
  {
    this.ʃ = true;
  }

  public void Ɨ()
  {
    ƞ();
    this.ʄ = true;
  }

  public void Ɩ()
  {
    this.ʂ = true;
  }

  public void Ƙ()
  {
  }

  public void ƙ()
  {
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.X
 * JD-Core Version:    0.6.2
 */