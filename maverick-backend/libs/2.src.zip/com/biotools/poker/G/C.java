package com.biotools.poker.G;

import com.A.B.A;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class C extends JFrame
  implements ItemListener
{
  private R H = null;
  private String D = null;
  private JLabel C = null;
  private JCheckBox L = null;
  private JCheckBox G = null;
  private K J;
  private J A = null;
  private _ I = null;
  private A K = null;
  private A B = null;
  private A F = null;
  private Dimension E = new Dimension(320, 360);

  public C(Frame paramFrame)
  {
    E();
    setDefaultCloseOperation(2);
  }

  public void A(R paramR, String paramString)
  {
    this.H = paramR;
    this.D = paramString;
    this.J.A(this.H);
    F().A(this.H.Q().M(this.H.A()));
    D().A(this.H.Q().A(this.H.V(), this.H.i()));
    C().A(H());
  }

  public void A(R paramR)
  {
    F().A(this.H.Q().M(this.H.A()));
    C().A(H());
  }

  private void E()
  {
    setTitle(getTitle());
    this.I = new _(this.H);
    this.A = new J(this.I, this.D);
    this.A.setOpaque(false);
    this.A.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
    this.A.setPreferredSize(this.E);
    this.L = new JCheckBox(E.D("StandingsDialog.ShowAtStart"), A());
    this.L.addItemListener(this);
    this.G = new JCheckBox(E.D("StandingsDialog.ShowAfterBust"), G());
    this.G.addItemListener(this);
    JPanel localJPanel1 = new JPanel();
    localJPanel1.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
    localJPanel1.setLayout(new BoxLayout(localJPanel1, 1));
    localJPanel1.add(Box.createVerticalStrut(5));
    localJPanel1.add(this.L);
    localJPanel1.add(Box.createVerticalStrut(5));
    localJPanel1.add(this.G);
    localJPanel1.add(Box.createVerticalGlue());
    localJPanel1.setPreferredSize(this.E);
    this.J = new K();
    this.J.setPreferredSize(this.E);
    this.K = F();
    this.B = D();
    this.F = C();
    JTabbedPane localJTabbedPane = new JTabbedPane();
    localJTabbedPane.add(E.D("StandingsDialog.Summary"), this.F);
    localJTabbedPane.add(E.D("StandingsDialog.Standings"), this.A);
    localJTabbedPane.add(E.D("StandingsDialog.Stacks"), this.J);
    localJTabbedPane.add(E.D("StandingsDialog.Levels"), this.K);
    localJTabbedPane.add(E.D("StandingsDialog.Payouts"), this.B);
    localJTabbedPane.add(E.D("StandingsDialog.Options"), localJPanel1);
    JPanel localJPanel2 = new JPanel(new BorderLayout(4, 4));
    localJPanel2.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
    localJPanel2.add(localJTabbedPane, "Center");
    Container localContainer = getContentPane();
    localContainer.add(localJPanel2);
    E.A("TSI_WINDOW", this);
    setIconImage(E.¢);
  }

  public void B()
  {
    setTitle(getTitle());
    this.A.A(this.D);
    this.I.A(this.H);
  }

  public String getTitle()
  {
    if ((this.H != null) && (this.D != null) && (this.H.K(this.D)))
      return E.D("StandingsDialog.YouWonHeading");
    return E.D("StandingsDialog.TournamentStandingsHeading");
  }

  private String H()
  {
    if (this.H == null)
      return null;
    return this.H.M(this.D);
  }

  public static final boolean G()
  {
    return E.£().getBoolean("SHOW_TOURNEY_STANDINGS_ON_BUST", false);
  }

  public static final boolean A()
  {
    return E.£().getBoolean("SHOW_TOURNEY_STANDINGS_AT_START", true);
  }

  public void itemStateChanged(ItemEvent paramItemEvent)
  {
    E.H("Checkbox changed!!!!");
    if (paramItemEvent.getSource() == this.G)
    {
      E.H("ShowOnBust Checkbox changed!");
      E.£().putBoolean("SHOW_TOURNEY_STANDINGS_ON_BUST", paramItemEvent.getStateChange() == 1);
    }
    else if (paramItemEvent.getSource() == this.L)
    {
      E.H("ShowAtStart Checkbox changed!");
      E.£().putBoolean("SHOW_TOURNEY_STANDINGS_AT_START", paramItemEvent.getStateChange() == 1);
    }
    else
    {
      E.H("No idea what was the source of this event!");
    }
  }

  private A F()
  {
    if (this.K == null)
    {
      this.K = new A();
      this.K.B().setFocusable(false);
      this.K.setPreferredSize(this.E);
    }
    return this.K;
  }

  private A D()
  {
    if (this.B == null)
    {
      this.B = new A();
      this.B.B().setFocusable(false);
      this.B.setPreferredSize(this.E);
    }
    return this.B;
  }

  private A C()
  {
    if (this.F == null)
    {
      this.F = new A();
      this.F.B().setFocusable(false);
      this.F.setPreferredSize(this.E);
    }
    return this.F;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.C
 * JD-Core Version:    0.6.2
 */