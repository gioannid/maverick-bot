package com.biotools.poker.G;

import com.biotools.poker.Q.K;

public abstract interface b
{
  public abstract void A(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);

  public abstract void W(int paramInt);

  public abstract void s(String paramString);

  public abstract void A(String paramString, double paramDouble1, double paramDouble2);

  public abstract void B(String paramString, double paramDouble1, double paramDouble2);

  public abstract void r(String paramString);

  public abstract void A(String paramString, double paramDouble);

  public abstract void A(String paramString, K paramK1, K paramK2, int paramInt1, int paramInt2);

  public abstract void V(int paramInt);

  public abstract void Ɨ();

  public abstract void Ɩ();

  public abstract void Ƙ();

  public abstract void ƙ();
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.G.b
 * JD-Core Version:    0.6.2
 */