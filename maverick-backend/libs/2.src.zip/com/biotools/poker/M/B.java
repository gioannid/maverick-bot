package com.biotools.poker.M;

import com.biotools.meerkat.Player;
import com.biotools.poker.D.C;

public abstract interface B extends Player
{
  public abstract double l();

  public abstract C h();

  public abstract double g();
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.M.B
 * JD-Core Version:    0.6.2
 */