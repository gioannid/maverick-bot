package com.biotools.poker.M;

import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class D extends JPanel
{
  private JComboBox E;
  private JComboBox B;
  private JButton D;
  private JButton A;
  private C C;

  public D(C paramC)
  {
    this.C = paramC;
    this.D = new JButton(E.D("AdvisorBotOptions.EditButton"));
    this.D.setFocusable(false);
    A(this.D);
    this.D.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        com.biotools.poker.E.B localB = new com.biotools.poker.E.B(D.C());
        com.biotools.poker.E.C.G(localB);
        D.this.C.Ă();
      }
    });
    this.A = new JButton(E.D("AdvisorBotOptions.EditButton"));
    A(this.A);
    this.A.setFocusable(false);
    this.A.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        com.biotools.poker.E.B localB = new com.biotools.poker.E.B(D.A());
        com.biotools.poker.E.C.G(localB);
        D.this.C.Ă();
      }
    });
    this.E = new JComboBox(A(false));
    this.B = new JComboBox(A(true));
    this.E.setFocusable(false);
    this.B.setFocusable(false);
    B();
    this.E.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        D.this.B((com.biotools.poker.E.B)D.this.E.getSelectedItem());
      }
    });
    this.B.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        D.this.A((com.biotools.poker.E.B)D.this.B.getSelectedItem());
      }
    });
    JPanel localJPanel = new JPanel(new B.A.A.B(3, 3));
    localJPanel.add("br", new JLabel(E.D("AdvisorBotOptions.FL")));
    localJPanel.add("tab hfill", this.E);
    localJPanel.add("", this.D);
    localJPanel.add("br", new JLabel(E.D("AdvisorBotOptions.NL")));
    localJPanel.add("tab hfill", this.B);
    localJPanel.add("", this.A);
    setLayout(new BorderLayout(4, 4));
    setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
    add(localJPanel, "Center");
  }

  private Vector A(boolean paramBoolean)
  {
    Vector localVector = new Vector();
    Iterator localIterator = com.biotools.poker.E.B.N().iterator();
    while (localIterator.hasNext())
    {
      com.biotools.poker.E.B localB = (com.biotools.poker.E.B)localIterator.next();
      if ((paramBoolean == localB.B()) && (localB.D()))
        localVector.add(localB);
    }
    return localVector;
  }

  public static String C()
  {
    String str = E.£().get("LIMIT_ADVISOR", E());
    File localFile = new File(str);
    if (!localFile.exists())
      str = E();
    return str;
  }

  private static String E()
  {
    File localFile = new File(E.O(), "Karma.pd");
    if (localFile.exists())
      return localFile.toString();
    return "logs/advisor.pd";
  }

  public static String A()
  {
    String str = E.£().get("NO_LIMIT_ADVISOR", D());
    File localFile = new File(str);
    if (!localFile.exists())
      str = D();
    return str;
  }

  private static String D()
  {
    File localFile = new File(E.O(), "Guru.pd");
    if (localFile.exists())
      return localFile.toString();
    return "logs/advisorNL.pd";
  }

  public void B()
  {
    File localFile1 = new File(C());
    Object localObject = (com.biotools.poker.E.B)this.E.getItemAt(0);
    this.E.setModel(new DefaultComboBoxModel(A(false)));
    com.biotools.poker.E.B localB;
    File localFile2;
    for (int i = 0; i < this.E.getItemCount(); i++)
    {
      localB = (com.biotools.poker.E.B)this.E.getItemAt(i);
      localFile2 = new File(localB.M());
      if (localFile2.equals(localFile1))
      {
        this.E.setSelectedIndex(i);
        localObject = localB;
      }
    }
    B((com.biotools.poker.E.B)localObject);
    this.B.setModel(new DefaultComboBoxModel(A(true)));
    localFile1 = new File(A());
    localObject = (com.biotools.poker.E.B)this.B.getItemAt(0);
    for (i = 0; i < this.B.getItemCount(); i++)
    {
      localB = (com.biotools.poker.E.B)this.B.getItemAt(i);
      localFile2 = new File(localB.M());
      if (localFile2.equals(localFile1))
      {
        this.B.setSelectedIndex(i);
        localObject = localB;
      }
    }
    A((com.biotools.poker.E.B)localObject);
  }

  public void B(com.biotools.poker.E.B paramB)
  {
    if (paramB != null)
      E.£().put("LIMIT_ADVISOR", paramB.M());
  }

  public void A(com.biotools.poker.E.B paramB)
  {
    if (paramB != null)
      E.£().put("NO_LIMIT_ADVISOR", paramB.M());
  }

  private void A(JButton paramJButton)
  {
    paramJButton.setFont(paramJButton.getFont().deriveFont(10.0F));
    paramJButton.setFocusable(false);
    paramJButton.setBorder(BorderFactory.createEmptyBorder());
    paramJButton.setBorderPainted(false);
    paramJButton.setMargin(new Insets(0, 0, 0, 0));
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.M.D
 * JD-Core Version:    0.6.2
 */