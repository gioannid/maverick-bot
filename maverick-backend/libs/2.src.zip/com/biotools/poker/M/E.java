package com.biotools.poker.M;

import com.biotools.meerkat.util.Preferences;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

public class E extends JPanel
{
  private JButton A = new JButton(com.biotools.poker.E.D("PopUpAdviceOptions.EnableAll"));
  private JButton B = new JButton(com.biotools.poker.E.D("PopUpAdviceOptions.DisableAll"));

  public E()
  {
    this.A.setFocusable(false);
    this.B.setFocusable(false);
    this.A.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        E.this.A(true);
        E.this.A.setEnabled(false);
        E.this.B.setEnabled(true);
      }
    });
    this.B.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        E.this.A(false);
        E.this.B.setEnabled(false);
        E.this.A.setEnabled(true);
      }
    });
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(this.A);
    localJPanel.add(Box.createHorizontalStrut(5));
    localJPanel.add(this.B);
    localJPanel.add(Box.createHorizontalGlue());
    setLayout(new BorderLayout(4, 4));
    setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
    add(localJPanel, "Center");
    A();
  }

  public void A(boolean paramBoolean)
  {
    com.biotools.poker.E.£().putBoolean("advice/foldFlushDraw.html", paramBoolean);
    com.biotools.poker.E.£().putBoolean("advice/foldForZero.html", paramBoolean);
    com.biotools.poker.E.£().putBoolean("advice/foldStraightDraw.html", paramBoolean);
    com.biotools.poker.E.£().putBoolean("advice/foldStrongHand.html", paramBoolean);
    com.biotools.poker.E.£().putBoolean("advice/foldWithShowOdds.html", paramBoolean);
    com.biotools.poker.E.£().putBoolean("advice/callCommits.html", paramBoolean);
    com.biotools.poker.E.£().putBoolean("advice/callWithoutShowOdds.html", paramBoolean);
    com.biotools.poker.E.£().putBoolean("advice/callWithNuts.html", paramBoolean);
    com.biotools.poker.E.£().putBoolean("advice/callWithStrongHand.html", paramBoolean);
    com.biotools.poker.E.£().putBoolean("advice/minBetting.html", paramBoolean);
    com.biotools.poker.E.£().putBoolean("advice/betCommits.html", paramBoolean);
  }

  public void A()
  {
    boolean bool = true;
    bool = (bool) && (com.biotools.poker.E.£().getBoolean("advice/foldFlushDraw.html", true));
    bool = (bool) && (com.biotools.poker.E.£().getBoolean("advice/foldForZero.html", true));
    bool = (bool) && (com.biotools.poker.E.£().getBoolean("advice/foldStraightDraw.html", true));
    bool = (bool) && (com.biotools.poker.E.£().getBoolean("advice/foldStrongHand.html", true));
    bool = (bool) && (com.biotools.poker.E.£().getBoolean("advice/foldWithShowOdds.html", true));
    bool = (bool) && (com.biotools.poker.E.£().getBoolean("advice/callCommits.html", true));
    bool = (bool) && (com.biotools.poker.E.£().getBoolean("advice/callWithoutShowOdds.html", true));
    bool = (bool) && (com.biotools.poker.E.£().getBoolean("advice/callWithNuts.html", true));
    bool = (bool) && (com.biotools.poker.E.£().getBoolean("advice/callWithStrongHand.html", true));
    bool = (bool) && (com.biotools.poker.E.£().getBoolean("advice/betCommits.html", true));
    bool = (bool) && (com.biotools.poker.E.£().getBoolean("advice/minBetting.html", true));
    this.A.setEnabled(!bool);
    this.B.setEnabled(bool);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.M.E
 * JD-Core Version:    0.6.2
 */