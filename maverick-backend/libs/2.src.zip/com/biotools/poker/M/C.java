package com.biotools.poker.M;

import com.biotools.A.b;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.Player;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URI;
import javax.swing.JComponent;

public class C extends JComponent
  implements MouseListener, Player
{
  public static final Color ŏ = new Color(230, 60, 60);
  public static final Color ŕ = new Color(60, 60, 230);
  public static final Color Ŕ = new Color(60, 200, 60);
  private com.biotools.poker.D.C ŉ;
  private double œ;
  private double Ŋ;
  private Image ő = A(E.K("pix/advisor4.png"));
  private Image Ő = this.ő;
  private Image ň = A(E.K("pix/newLogo100x60.png"));
  private boolean Ō = false;
  private B ŋ;
  private String Ŏ;
  private GameInfo ō;
  private int Œ;

  public C()
  {
    addMouseListener(this);
  }

  public Image A(File paramFile)
  {
    try
    {
      Image localImage = Toolkit.getDefaultToolkit().getImage(paramFile.toURI().toURL());
      MediaTracker localMediaTracker = new MediaTracker(this);
      localMediaTracker.addImage(localImage, 0);
      try
      {
        localMediaTracker.waitForAll();
      }
      catch (InterruptedException localInterruptedException)
      {
      }
      return localImage;
    }
    catch (MalformedURLException localMalformedURLException)
    {
      localMalformedURLException.printStackTrace();
    }
    return null;
  }

  public Dimension getMinimumSize()
  {
    return new Dimension(this.ő.getWidth(null), this.ő.getHeight(null));
  }

  public Dimension getMaximumSize()
  {
    return super.getMaximumSize();
  }

  public Dimension getPreferredSize()
  {
    return new Dimension(this.ő.getWidth(null), this.ő.getHeight(null));
  }

  public synchronized void paint(Graphics paramGraphics)
  {
    Graphics2D localGraphics2D = (Graphics2D)paramGraphics;
    localGraphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    if ((this.ŋ != null) && ((E.Ø()) || (this.Ō)))
    {
      int i = (getWidth() - this.ő.getWidth(null)) / 2;
      int j = (getHeight() - this.ő.getHeight(null)) / 2;
      if (this.ŉ == null)
      {
        paramGraphics.drawImage(this.ő, getWidth() - this.ő.getWidth(null), 0, null);
      }
      else
      {
        paramGraphics.drawImage(this.ő, getWidth() - this.ő.getWidth(null), 0, null);
        paramGraphics.setFont(new Font("Courier", 1, 14));
        FontMetrics localFontMetrics = paramGraphics.getFontMetrics();
        com.biotools.poker.D.C localC = this.ŉ;
        double d = localC.H();
        int k = 52;
        int m = 5;
        int n = 5;
        paramGraphics.setColor(ŏ);
        paramGraphics.fillArc(m, n, k, k, 0, (int)(360.0D * localC.J()));
        paramGraphics.setColor(ŕ);
        paramGraphics.fillArc(m, n, k, k, (int)(360.0D * localC.J()), (int)(360.0D * localC.C()));
        paramGraphics.setColor(Ŕ);
        paramGraphics.fillArc(m, n, k, k, (int)(360.0D * localC.J()) + (int)(360.0D * localC.C()), (int)(360.0D * localC.D()));
        int i1 = 1;
        int i2 = localFontMetrics.getAscent() + localFontMetrics.getDescent() / 2;
        String str = E.D("Advisor.FoldTitle");
        if (localC.I())
        {
          paramGraphics.setColor(Color.BLACK);
          paramGraphics.drawString(str, m + 1 + (k - localFontMetrics.stringWidth(str)) / 2, 1 + n + localFontMetrics.getDescent() + k / 2);
          paramGraphics.setColor(ŏ.brighter().brighter());
          paramGraphics.drawString(str, m + (k - localFontMetrics.stringWidth(str)) / 2, n + localFontMetrics.getDescent() + k / 2);
        }
        Object[] arrayOfObject1 = { new Integer((int)Math.round(localC.J() * 100.0D)) };
        str = E.A("Advisor.FoldPattern", arrayOfObject1);
        paramGraphics.setColor(Color.BLACK);
        paramGraphics.drawString(str, m + k + 3, n + 1 + i1 * i2);
        paramGraphics.setColor(ŏ.brighter().brighter());
        paramGraphics.drawString(str, m + k + 3, n + i1 * i2);
        i1++;
        str = this.Ŋ > 0.0D ? E.D("Advisor.CallTitle") : E.D("Advisor.CheckTitle");
        if (localC.B())
        {
          paramGraphics.setColor(Color.BLACK);
          paramGraphics.drawString(str, m + 1 + (k - localFontMetrics.stringWidth(str)) / 2, 1 + n + localFontMetrics.getDescent() + k / 2);
          paramGraphics.setColor(ŕ.brighter().brighter());
          paramGraphics.drawString(str, m + (k - localFontMetrics.stringWidth(str)) / 2, n + localFontMetrics.getDescent() + k / 2);
        }
        Object[] arrayOfObject2 = { new Integer((int)Math.round(localC.C() * 100.0D)) };
        str = this.Ŋ > 0.0D ? E.A("Advisor.CallPattern", arrayOfObject2) : E.A("Advisor.CheckPattern", arrayOfObject2);
        paramGraphics.setColor(Color.BLACK);
        paramGraphics.drawString(str, m + k + 3, n + 1 + i1 * i2);
        paramGraphics.setColor(ŕ.brighter().brighter());
        paramGraphics.drawString(str, m + k + 3, n + i1 * i2);
        i1++;
        str = this.Ŋ > 0.0D ? E.D("Advisor.RaiseTitle") : E.D("Advisor.BetTitle");
        if (localC.G())
        {
          paramGraphics.setColor(Color.BLACK);
          paramGraphics.drawString(str, m + 1 + (k - localFontMetrics.stringWidth(str)) / 2, 1 + n + localFontMetrics.getDescent() + k / 2);
          paramGraphics.setColor(Ŕ.brighter().brighter());
          paramGraphics.drawString(str, m + (k - localFontMetrics.stringWidth(str)) / 2, n + localFontMetrics.getDescent() + k / 2);
        }
        Object[] arrayOfObject3 = { new Integer((int)Math.round(localC.D() * 100.0D)) };
        str = this.Ŋ > 0.0D ? E.A("Advisor.RaisePattern", arrayOfObject3) : E.A("Advisor.BetPattern", arrayOfObject3);
        paramGraphics.setColor(Color.BLACK);
        paramGraphics.drawString(str, m + k + 3, n + 1 + i1 * i2);
        paramGraphics.setColor(Ŕ);
        paramGraphics.drawString(str, m + k + 3, n + i1 * i2);
        i1++;
      }
    }
    else
    {
      paramGraphics.drawImage(this.ň, (getWidth() - this.ň.getWidth(null)) / 2, (getHeight() - this.ň.getHeight(null)) / 2, null);
    }
  }

  private String A(String paramString, int paramInt)
  {
    return b.C(paramString, paramInt);
  }

  public void ă()
  {
    this.ŉ = null;
    repaint();
  }

  public void mouseClicked(MouseEvent paramMouseEvent)
  {
    E.Ù();
    repaint();
  }

  public void mouseEntered(MouseEvent paramMouseEvent)
  {
    if (this.ŋ == null)
      return;
    this.Ō = true;
    repaint();
    setCursor(new Cursor(12));
  }

  public void mouseExited(MouseEvent paramMouseEvent)
  {
    setCursor(Cursor.getDefaultCursor());
    this.Ō = false;
    repaint();
  }

  public void mousePressed(MouseEvent paramMouseEvent)
  {
    this.Ō = true;
    repaint();
  }

  public void mouseReleased(MouseEvent paramMouseEvent)
  {
    this.Ō = false;
    repaint();
  }

  public void init(Preferences paramPreferences)
  {
    if (this.ŋ == null)
      return;
    this.ŋ.init(paramPreferences);
  }

  public void dealHoleCardsEvent()
  {
    if (this.ŋ == null)
      return;
    this.ŋ.dealHoleCardsEvent();
  }

  public void holeCards(Card paramCard1, Card paramCard2, int paramInt)
  {
    this.Œ = paramInt;
    if (this.ŋ == null)
      return;
    this.ŋ.holeCards(paramCard1, paramCard2, paramInt);
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
    if (this.ŋ == null)
      return;
    this.ŋ.actionEvent(paramInt, paramAction);
  }

  public void stageEvent(int paramInt)
  {
    if (this.ŋ == null)
      return;
    this.ŋ.stageEvent(paramInt);
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
    if (this.ŋ == null)
      return;
    this.ŋ.showdownEvent(paramInt, paramCard1, paramCard2);
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    this.ō = paramGameInfo;
    String str = null;
    if (paramGameInfo.isNoLimit())
      str = D.A();
    else
      str = D.C();
    if (!str.equals(this.Ŏ))
    {
      E.H("Loading Advisor: " + str);
      File localFile = new File(str);
      if (localFile.exists())
      {
        this.ŋ = ((B)com.biotools.poker.E.B.F(str));
        this.Ŏ = str;
      }
      else
      {
        this.ŋ = null;
      }
    }
    if (this.ŋ == null)
      return;
    this.ŋ.gameStartEvent(paramGameInfo);
  }

  public void gameOverEvent()
  {
    if (this.ŋ == null)
      return;
    this.ŋ.gameOverEvent();
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
    if (this.ŋ == null)
      return;
    this.ŋ.winEvent(paramInt, paramDouble, paramString);
  }

  public void gameStateChanged()
  {
    if (this.ō.getCurrentPlayerSeat() != this.Œ)
      ă();
    if (this.ŋ == null)
      return;
    this.ŋ.gameStateChanged();
  }

  public Action getAction()
  {
    this.Ŋ = this.ō.getAmountToCall(this.Œ);
    Action localAction = this.ŋ.getAction();
    this.ŉ = this.ŋ.h();
    if (this.ō.isNoLimit())
      this.œ = this.ŋ.g();
    else
      this.œ = -1.0D;
    if (!this.ō.canRaise(this.Œ))
    {
      this.ŉ.D(this.ŉ.C() + this.ŉ.D());
      this.ŉ.F(0.0D);
    }
    repaint();
    return localAction;
  }

  public void Ă()
  {
    this.Ŏ = null;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.M.C
 * JD-Core Version:    0.6.2
 */