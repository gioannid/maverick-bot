package com.biotools.poker.M;

import com.biotools.A.I;
import com.biotools.A.b;
import com.biotools.B.L;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.D.G;
import com.biotools.poker.E;
import com.biotools.poker.P.V;
import com.biotools.poker.P.Z;
import com.biotools.poker.PokerApp;
import com.biotools.poker.Q.D;
import java.awt.Dimension;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class F extends V
{
  public static final String O = "advice/foldForZero.html";
  public static final String L = "advice/foldFlushDraw.html";
  public static final String G = "advice/foldStraightDraw.html";
  public static final String E = "advice/foldStrongHand.html";
  public static final String F = "advice/foldWithShowOdds.html";
  public static final String H = "advice/callWithoutShowOdds.html";
  public static final String N = "advice/minBetting.html";
  public static final String D = "advice/callCommits.html";
  public static final String C = "advice/betCommits.html";
  public static final String K = "advice/callWithNuts.html";
  public static final String M = "advice/callWithStrongHand.html";
  private boolean J = false;
  private String P;
  private Action I;

  public F(Action paramAction, String paramString)
  {
    this.I = paramAction;
    this.P = paramString;
  }

  public JLabel F()
  {
    return new JLabel(E.D("AdviceWindow.AdviceHeading"), 0);
  }

  public JPanel A()
  {
    String str = com.biotools.A.B.A(E.K(this.P));
    str = str.replaceFirst("%FGCOL%", L.A(com.biotools.B.A.D));
    com.A.B.A localA = new com.A.B.A();
    localA.A(str);
    localA.setPreferredSize(new Dimension(350, 100));
    JCheckBox localJCheckBox = new JCheckBox(E.D("AdviceWindow.ShowAdviceInFuture"), true);
    JButton localJButton1 = new JButton(E.D("AdviceWindow.ProceedButton"));
    localJButton1.addActionListener(new F.1(this, localJCheckBox));
    JButton localJButton2 = new JButton(E.D("AdviceWindow.UndoButton"));
    localJButton2.addActionListener(new F.2(this, localJCheckBox));
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(localJCheckBox);
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(localJButton1);
    localJPanel.add(Box.createHorizontalStrut(10));
    localJPanel.add(localJButton2);
    Z localZ = new Z();
    localZ.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    localZ.setLayout(new BoxLayout(localZ, 1));
    localZ.add(localA);
    localZ.add(Box.createVerticalStrut(10));
    localZ.add(localJPanel);
    return localZ;
  }

  private static URL A(String paramString)
  {
    try
    {
      File localFile = new File(paramString);
      return localFile.toURI().toURL();
    }
    catch (MalformedURLException localMalformedURLException)
    {
      I.A("", localMalformedURLException);
    }
    return null;
  }

  public static boolean A(PokerApp paramPokerApp, Action paramAction, int paramInt, Card paramCard1, Card paramCard2, D paramD)
  {
    String str = null;
    if ((paramCard1 == null) || (paramCard2 == null) || (!paramCard1.valid()) || (!paramCard2.valid()))
    {
      if (!$assertionsDisabled)
        throw new AssertionError();
      return true;
    }
    double d1 = paramD.getAmountToCall(paramInt);
    double d2 = paramD.G(paramInt).getBankRollAtRisk();
    double d3 = paramD.G(paramInt).getBankRoll();
    double d4 = paramD.getEligiblePot(paramInt);
    double d5 = -1.0D;
    if (paramD.getStage() > 0)
    {
      if (paramD.getBoard().size() < 3)
      {
        if (!$assertionsDisabled)
          throw new AssertionError();
        return true;
      }
      d5 = G.A(paramD).Q(paramInt).A(paramCard1, paramCard2);
      Deck localDeck = new Deck();
      localDeck.extractCard(paramCard1);
      localDeck.extractCard(paramCard2);
      localDeck.extractHand(paramD.getBoard());
      double d7 = HandEvaluator.handRank(paramCard1, paramCard2, G.A(paramD).ŷ(), localDeck);
      d5 = 0.85D * d5 + 0.15D * d7;
    }
    if ((paramAction.isFold()) && (d1 == 0.0D))
      str = "advice/foldForZero.html";
    double d6;
    if ((str == null) && (paramD.getStage() > 0) && (paramAction.isFold()))
    {
      double d8;
      if (paramD.getStage() < 3)
      {
        d6 = d1 / (d4 + d1);
        d8 = paramD.isFlop() ? 0.1914893617021277D : 0.1956521739130435D;
        double d9 = paramD.isFlop() ? 0.170212765957447D : 0.1739130434782609D;
        paramD.isNoLimit();
        E.H(" | current odds: = " + b.A(d6, 3) + " , flush odds: = " + b.A(d8, 3) + " , straight odds: = " + b.A(d9, 3));
        if ((B(paramCard1, paramCard2, paramD.getBoard())) && (d8 >= d6))
          str = "advice/foldFlushDraw.html";
        else if ((A(paramCard1, paramCard2, paramD.getBoard())) && (d9 >= d6))
          str = "advice/foldStraightDraw.html";
      }
      if (d5 > 0.85D)
        str = "advice/foldStrongHand.html";
      if ((str == null) && (paramD.isRiver()))
      {
        d6 = d1 / (d4 + d1);
        d8 = 0.75D;
        if (d1 / d3 > 0.25D)
        {
          d8 = 0.5D;
          if (d1 / d3 > 0.5D)
            d8 = 0.4D;
        }
        if (d5 * d8 >= d6)
        {
          E.H(" WARN - SHOWDOWN ODDS to call: HS = " + b.A(d5, 3) + ", currOdds = " + b.A(d6, 3));
          str = "advice/foldWithShowOdds.html";
        }
        else
        {
          E.H(" GOOD FOLD - NO SHOWDOWN ODDS to call: HS = " + b.A(d5, 3) + ", currOdds = " + b.A(d6, 3));
        }
      }
    }
    if ((str == null) && (paramAction.isCheckOrCall()) && (paramD.isRiver()) && (paramD.a()) && (d2 > d1) && (paramD.getNumToAct() == 1))
      if (HandEvaluator.isTheNuts(paramCard1, paramCard2, paramD.getBoard(), G.A(paramD).ŷ()))
      {
        if (HandEvaluator.rankHand(paramCard1, paramCard2, paramD.getBoard()) > HandEvaluator.rankHand(paramD.getBoard()))
        {
          E.H(" WARN - CALLING WITH THE NUTS INSTEAD OF RAISING");
          str = "advice/callWithNuts.html";
        }
      }
      else if ((d5 > 0.9D) && (paramD.getNumRaises() == 0))
      {
        E.H(" WARN - CHECKING WITH STRONG HAND INSTEAD OF BETTING");
        str = "advice/callWithStrongHand.html";
      }
    if ((str == null) && (d1 > 0.0D) && (paramD.isRiver()) && (paramAction.isCall()))
    {
      d6 = d1 / (d4 + d1);
      if (d5 < d6)
      {
        E.H(" WARN - DOUBTFUL SHOWDOWN ODDS to call: HS = " + b.A(d5, 3) + ", currOdds = " + b.A(d6, 3));
        str = "advice/callWithoutShowOdds.html";
      }
      else
      {
        E.H(" WARN - OK SHOWDOWN ODDS to call: HS = " + b.A(d5, 3) + ", currOdds = " + b.A(d6, 3));
      }
    }
    if ((str == null) && (paramD.isNoLimit()) && (paramPokerApp.Ǳ()) && (d1 > 0.0D) && (paramAction.isCall()) && (paramD.a()) && (!paramD.isRiver()) && (d2 > d1) && (A(d1, d3)))
    {
      E.H("Warn about call committing stack...");
      str = "advice/callCommits.html";
    }
    if ((str == null) && (paramD.isNoLimit()) && (paramD.getNumRaises() == 0) && (paramD.getStage() > 0) && (paramAction.getAmount() == paramD.getMinRaise()) && (paramD.getMinRaise() < 0.2D * (paramD.getTotalPotSize() + d1)) && (d2 > d1 + paramD.getMinRaise()))
    {
      E.H("Warn about min betting...");
      str = "advice/minBetting.html";
    }
    if ((str == null) && (paramD.isNoLimit()) && (paramPokerApp.Ǳ()) && (paramAction.isRaise()) && (d2 > d1 + paramAction.getAmount()) && (!paramD.isRiver()) && (A(paramAction.getAmount(), d1, d3)))
    {
      E.H("Warn about bet committing...");
      str = "advice/betCommits.html";
    }
    if (str != null)
    {
      if (E.£().getBoolean(str, true))
      {
        F localF = new F(paramAction, str);
        paramPokerApp.A(localF);
        return false;
      }
      E.H("Ignoring: " + str);
    }
    return true;
  }

  private static boolean B(Card paramCard1, Card paramCard2, Hand paramHand)
  {
    if (paramHand.size() >= 5)
      return false;
    int[] arrayOfInt = new int[4];
    for (int i = 1; i <= paramHand.size(); i++)
      arrayOfInt[paramHand.getCard(i).getSuit()] += 1;
    for (i = 0; i < 4; i++)
    {
      if ((arrayOfInt[i] == 3) && ((paramCard1.getSuit() == i) || (paramCard2.getSuit() == i)) && (paramCard1.getSuit() != paramCard2.getSuit()))
        return true;
      if ((arrayOfInt[i] == 2) && (paramCard1.getSuit() == i) && (paramCard2.getSuit() == i))
        return true;
    }
    return false;
  }

  private static boolean A(Card paramCard1, Card paramCard2, Hand paramHand)
  {
    if (B(paramHand))
      return false;
    Hand localHand = new Hand(paramHand);
    localHand.addCard(paramCard1);
    localHand.addCard(paramCard2);
    return B(localHand);
  }

  private static boolean B(Hand paramHand)
  {
    if (A(paramHand))
      return false;
    Deck localDeck = new Deck();
    localDeck.extractHand(paramHand);
    int i = 0;
    for (int j = localDeck.getTopCardIndex(); j < 52; j++)
    {
      paramHand.addCard(localDeck.getCard(j));
      if (A(paramHand))
        i++;
      paramHand.removeCard();
    }
    return i >= 8;
  }

  private static boolean A(Hand paramHand)
  {
    int i = 0;
    if (A(paramHand, 12))
      i++;
    for (int j = 0; j <= 12; j++)
    {
      if (A(paramHand, j))
        i++;
      else
        i = 0;
      if (i == 5)
        return true;
    }
    return false;
  }

  private static boolean A(Hand paramHand, int paramInt)
  {
    for (int i = 1; i <= paramHand.size(); i++)
      if (paramHand.getCard(i).getRank() == paramInt)
        return true;
    return false;
  }

  private static boolean A(double paramDouble1, double paramDouble2)
  {
    boolean bool = false;
    if (paramDouble1 > paramDouble2 / 3.0D)
      bool = true;
    return bool;
  }

  private static boolean A(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    boolean bool = false;
    if (paramDouble1 + paramDouble2 > paramDouble3 / 2.0D)
      bool = true;
    return bool;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.M.F
 * JD-Core Version:    0.6.2
 */