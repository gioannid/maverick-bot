package com.biotools.poker.F;

import com.biotools.poker.O.J;
import com.biotools.poker.O.M;
import com.biotools.poker.O.P;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

public abstract class E
  implements P
{
  protected static final Color ô = new Color(93, 27, 27);
  public static Font ð = new Font("Trebuchet MS", 1, 16);
  public static Font ñ = new Font("Trebuchet MS", 1, 14);
  protected String õ;
  protected int í;
  protected int ê;
  protected boolean ö = false;
  protected boolean î = false;
  protected boolean ë = true;
  protected boolean ï = true;
  private Vector ò = new Vector();
  boolean ó = false;
  boolean ì = false;
  Rectangle é = null;

  public abstract int É();

  public abstract int Ê();

  public abstract void I(Graphics2D paramGraphics2D);

  public static void A(String paramString, int paramInt1, int paramInt2)
  {
    ð = new Font(paramString, paramInt1, paramInt2);
    ñ = new Font(paramString, paramInt1, paramInt2 - 2);
  }

  public void H(int paramInt1, int paramInt2)
  {
    this.í = paramInt1;
    this.ê = paramInt2;
    this.é = null;
  }

  public void A(Point paramPoint)
  {
    this.í = paramPoint.x;
    this.ê = paramPoint.y;
    this.é = null;
  }

  public Rectangle Á()
  {
    return new Rectangle(this.í, this.ê, É(), Ê());
  }

  public void A(String paramString)
  {
    this.õ = paramString;
    this.ì = true;
  }

  protected void A(Graphics2D paramGraphics2D, float paramFloat)
  {
    paramGraphics2D.setComposite(AlphaComposite.getInstance(3, paramFloat));
  }

  public void B(ActionListener paramActionListener)
  {
    this.ò.add(paramActionListener);
  }

  public void A(ActionListener paramActionListener)
  {
    this.ò.remove(paramActionListener);
  }

  public void Æ()
  {
    ActionEvent localActionEvent = new ActionEvent(this, 0, this.õ);
    for (int i = 0; i < this.ò.size(); i++)
    {
      ActionListener localActionListener = (ActionListener)this.ò.get(i);
      localActionListener.actionPerformed(localActionEvent);
    }
  }

  public void F(boolean paramBoolean)
  {
    this.ö = paramBoolean;
  }

  public void G(boolean paramBoolean)
  {
    if (this.ë != paramBoolean)
      this.ì = true;
    this.ë = paramBoolean;
  }

  public boolean Ä()
  {
    return this.ë;
  }

  public void H(boolean paramBoolean)
  {
    if (this.ï != paramBoolean)
      this.ì = true;
    this.ï = paramBoolean;
  }

  public boolean Ç()
  {
    return this.ï;
  }

  public boolean F(int paramInt1, int paramInt2)
  {
    return (this.ï) && (this.ë) && (paramInt1 > this.í) && (paramInt1 < this.í + É()) && (paramInt2 > this.ê) && (paramInt2 < this.ê + Ê());
  }

  public boolean I(int paramInt1, int paramInt2)
  {
    this.ì = true;
    if (F(paramInt1, paramInt2))
    {
      F(true);
      this.î = true;
      return true;
    }
    return false;
  }

  public boolean E(int paramInt1, int paramInt2)
  {
    this.ì = true;
    F(false);
    if ((F(paramInt1, paramInt2)) && (this.î))
    {
      this.î = false;
      Æ();
      return true;
    }
    this.î = false;
    return false;
  }

  public boolean G(int paramInt1, int paramInt2)
  {
    if (!this.ë)
      return false;
    boolean bool1 = this.ö;
    boolean bool2 = F(paramInt1, paramInt2);
    F(bool2);
    this.ì = (bool2 ^ bool1);
    return this.ì;
  }

  public int Å()
  {
    return this.í;
  }

  public int Ã()
  {
    return this.ê;
  }

  public Rectangle È()
  {
    if (this.é == null)
    {
      Rectangle localRectangle = Á();
      int i = À();
      int j = Â();
      this.é = new Rectangle(localRectangle.x, localRectangle.y, i, j);
    }
    return this.é;
  }

  protected int À()
  {
    return É();
  }

  protected int Â()
  {
    return Ê();
  }

  public void B(M paramM)
  {
  }

  public void A(M paramM)
  {
    if (this.ì)
    {
      paramM.A(new J(È(), false));
      this.ì = false;
    }
  }

  public void A()
  {
    this.ó = false;
  }

  public boolean A(Rectangle paramRectangle)
  {
    if (!Ä())
      return false;
    Rectangle localRectangle = È();
    if (localRectangle != null)
      return localRectangle.intersects(paramRectangle);
    return false;
  }

  public void A(Graphics2D paramGraphics2D)
  {
    if (!this.ó)
      I(paramGraphics2D);
    this.ó = true;
  }

  public J B(Rectangle paramRectangle)
  {
    if (!Ä())
      return null;
    return new J(È(), false);
  }

  public void B()
  {
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.E
 * JD-Core Version:    0.6.2
 */