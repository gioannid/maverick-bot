package com.biotools.poker.F;

import com.biotools.B.G;
import com.biotools.poker.E;
import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.io.File;
import javax.swing.JComponent;
import javax.swing.JFrame;

public class N
{
  private static final double[] B = { 5000000.0D, 1000000.0D, 500000.0D, 100000.0D, 25000.0D, 5000.0D, 1000.0D, 100.0D, 25.0D, 5.0D, 1.0D, 0.25D, 0.1D, 0.05D, 0.01D };
  private static Image[] C = new Image[B.length];
  private static int D;
  private static int A;

  public static void A(G paramG)
  {
    C[0] = paramG.B(E.K("pix/chips-5M.png"));
    C[1] = paramG.B(E.K("pix/chips-1M.png"));
    C[2] = paramG.B(E.K("pix/chips-500000.png"));
    C[3] = paramG.B(E.K("pix/chips-100000.png"));
    C[4] = paramG.B(E.K("pix/chips-25000.png"));
    C[5] = paramG.B(E.K("pix/chips-5000.png"));
    C[6] = paramG.B(E.K("pix/chips-1000.png"));
    C[7] = paramG.B(E.K("pix/chips-100.png"));
    C[8] = paramG.B(E.K("pix/chips-25.png"));
    C[9] = paramG.B(E.K("pix/chips-5.png"));
    C[10] = paramG.B(E.K("pix/chips-1.png"));
    C[11] = paramG.B(E.K("pix/chips-25c.png"));
    C[12] = paramG.B(E.K("pix/chips-10c.png"));
    C[13] = paramG.B(E.K("pix/chips-5c.png"));
    C[14] = paramG.B(E.K("pix/chips-1c.png"));
    A = C[0].getHeight(null);
    D = C[0].getWidth(null);
  }

  public static double A(double paramDouble1, double paramDouble2)
  {
    double d1 = (int)(paramDouble1 / paramDouble2) * paramDouble2;
    if (d1 == paramDouble1)
      return d1;
    if (paramDouble1 == (int)paramDouble1)
      return paramDouble1;
    double d2 = d1;
    for (int i = 0; i < B.length; i++)
      if ((B[i] <= paramDouble2) && ((B[i] > 1.0D) || (paramDouble2 <= 2.0D)))
      {
        d1 = (int)(paramDouble1 / B[i]) * B[i];
        double d3 = Math.abs(paramDouble1 - d1);
        if (d3 == 0.0D)
          return d1;
        if (d3 < Math.abs(paramDouble1 - d2))
          d2 = d1;
      }
    return d2;
  }

  public static Rectangle A(double paramDouble, int paramInt1, int paramInt2, Graphics paramGraphics)
  {
    if (paramDouble <= 0.0D)
      return null;
    int i = -1;
    int j = 0;
    double d = -1.0D;
    int k = 10000;
    int m = 0;
    int n = 10000;
    int i1 = 0;
    int i2 = 0;
    while (paramDouble > 0.0D)
    {
      Image localImage = null;
      for (int i3 = 0; i3 < B.length; i3++)
        if ((i3 != 1) && (paramDouble >= B[i3]))
        {
          paramDouble -= B[i3];
          paramDouble = Math.round(paramDouble * 100.0D) / 100.0D;
          localImage = C[i3];
          if (d == B[i3])
            break;
          d = B[i3];
          i++;
          j = 0;
          break;
        }
      if ((localImage == null) || (i >= 5))
        break;
      i3 = paramInt1 + i * (2 + D);
      int i4 = paramInt2 - j * 3;
      if (paramGraphics != null)
        paramGraphics.drawImage(localImage, i3, i4, null);
      if (i3 < k)
        k = i3;
      if (i3 > m)
        m = i3;
      if (i4 < n)
        n = i4;
      if (i4 > i1)
        i1 = i4;
      i2 = 1;
      j++;
    }
    if (i2 == 0)
      return new Rectangle(paramInt1, paramInt2, 10, 10);
    return new Rectangle(k, n, m + D - k, i1 + A - n);
  }

  public static Rectangle A(double paramDouble, int paramInt1, int paramInt2, int paramInt3, Graphics paramGraphics)
  {
    if (paramInt1 < 0)
      return null;
    int i = 10000;
    int j = 0;
    int k = 10000;
    int m = 0;
    int n = 0;
    for (int i1 = 0; i1 < paramInt1; i1++)
    {
      double d = paramDouble;
      for (int i2 = 0; d > 0.0D; i2++)
      {
        Image localImage = null;
        if (d == 40.0D)
        {
          localImage = C[8];
          d -= B[8];
        }
        else if (d == 6.0D)
        {
          localImage = C[9];
          d -= B[9];
        }
        else
        {
          for (i3 = 0; i3 < B.length; i3++)
            if ((i3 != 1) && (d >= B[i3]))
            {
              localImage = C[i3];
              d -= B[i3];
              break;
            }
        }
        if ((localImage == null) || (i1 >= 5))
          break;
        int i3 = paramInt2 + i1 * (2 + D);
        int i4 = paramInt3 - i2 * 3;
        if (paramGraphics != null)
          paramGraphics.drawImage(localImage, i3, i4, null);
        if (i3 < i)
          i = i3;
        if (i3 > j)
          j = i3;
        if (i4 < k)
          k = i4;
        if (i4 > m)
          m = i4;
        n = 1;
      }
    }
    if (n == 0)
      return new Rectangle(paramInt2, paramInt3, 10, 10);
    return new Rectangle(i, k, j + D - i, m + A - k);
  }

  public static void A()
  {
    JFrame localJFrame = new JFrame();
    localJFrame.setDefaultCloseOperation(3);
    localJFrame.setSize(200, 200);
    localJFrame.getContentPane().add(new _A(null));
    localJFrame.setVisible(true);
  }

  private static class _A extends JComponent
    implements G
  {
    private _A()
    {
    }

    public void paint(Graphics paramGraphics)
    {
      paramGraphics.setColor(new Color(50, 150, 50));
      paramGraphics.fillRect(0, 0, getWidth(), getHeight());
      paramGraphics.setColor(Color.black);
      N.A(this);
      N.A(3.75D, 1, 50, 100, paramGraphics);
    }

    public Image B(File paramFile)
    {
      Image localImage = Toolkit.getDefaultToolkit().getImage(paramFile.getPath());
      MediaTracker localMediaTracker = new MediaTracker(this);
      localMediaTracker.addImage(localImage, 0);
      try
      {
        localMediaTracker.waitForAll();
      }
      catch (InterruptedException localInterruptedException)
      {
      }
      return localImage;
    }

    _A(_A param_A)
    {
      this();
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.N
 * JD-Core Version:    0.6.2
 */