package com.biotools.poker.F;

import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class A extends E
{
  private int Č = 37;
  private int ċ = 17;

  public void J(int paramInt)
  {
    this.Č = paramInt;
  }

  public void I(int paramInt)
  {
    this.ċ = paramInt;
  }

  public int É()
  {
    return this.Č;
  }

  public int Ê()
  {
    return this.ċ;
  }

  public Rectangle È()
  {
    return new Rectangle(this.í - 1, this.ê - 1, É() + 3, Ê() + 3);
  }

  public void I(Graphics2D paramGraphics2D)
  {
    if (!this.ë)
      return;
    int i = (this.î) && (this.ö) ? 1 : 0;
    Composite localComposite = paramGraphics2D.getComposite();
    A(paramGraphics2D, this.ö ? 0.95F : 0.7F);
    paramGraphics2D.setColor(com.biotools.B.A.M);
    paramGraphics2D.fill3DRect(this.í + i, this.ê + i, É(), Ê(), true);
    paramGraphics2D.setComposite(localComposite);
    paramGraphics2D.setFont(new Font("Application", 0, 10));
    FontMetrics localFontMetrics = paramGraphics2D.getFontMetrics();
    int j = localFontMetrics.stringWidth(this.õ);
    int k = localFontMetrics.getAscent() + localFontMetrics.getDescent();
    paramGraphics2D.setColor(com.biotools.B.A.D);
    paramGraphics2D.drawString(this.õ, this.í + i + (É() - j) / 2, this.ê + i + (Ê() - k) / 2 + (k - localFontMetrics.getDescent()));
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.A
 * JD-Core Version:    0.6.2
 */