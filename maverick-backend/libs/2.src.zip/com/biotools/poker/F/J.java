package com.biotools.poker.F;

import com.biotools.B.G;
import com.biotools.poker.A;
import java.awt.Color;
import java.awt.Composite;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Image;

public class J extends E
{
  protected Image ā;
  protected Image ÿ;
  protected Image þ;
  protected int Ā = 1;

  public J(G paramG)
  {
    this.ā = paramG.B(com.biotools.poker.E.K("pix/00-01.png"));
    this.ÿ = paramG.B(com.biotools.poker.E.K("pix/00-02.png"));
    this.þ = paramG.B(com.biotools.poker.E.K("pix/00-03.png"));
  }

  public int É()
  {
    return 159;
  }

  public int Ê()
  {
    return 39;
  }

  protected int À()
  {
    return 163;
  }

  protected int Â()
  {
    return 49;
  }

  public void A(String paramString)
  {
    this.Ā = 0;
    super.A(paramString);
  }

  public void I(Graphics2D paramGraphics2D)
  {
    if (!this.ë)
      return;
    if (!this.ï)
    {
      Composite localComposite = paramGraphics2D.getComposite();
      A(paramGraphics2D, 0.6F);
      paramGraphics2D.drawImage(this.ā, this.í, this.ê, null);
      J(paramGraphics2D);
      paramGraphics2D.setComposite(localComposite);
    }
    else
    {
      if (this.ö)
      {
        if (this.î)
          paramGraphics2D.drawImage(this.þ, this.í, this.ê, null);
        else
          paramGraphics2D.drawImage(this.ÿ, this.í, this.ê, null);
      }
      else
        paramGraphics2D.drawImage(this.ā, this.í, this.ê, null);
      J(paramGraphics2D);
    }
  }

  public Color Î()
  {
    return ô;
  }

  public void J(Graphics2D paramGraphics2D)
  {
    A.A(paramGraphics2D);
    paramGraphics2D.setColor(Î());
    paramGraphics2D.setFont(ð);
    FontMetrics localFontMetrics = paramGraphics2D.getFontMetrics();
    if (this.Ā == 0)
    {
      i = localFontMetrics.stringWidth(this.õ);
      if (É() - i < 30)
        this.Ā = 2;
      else
        this.Ā = 1;
    }
    if (this.Ā == 2)
    {
      paramGraphics2D.setFont(ñ);
      localFontMetrics = paramGraphics2D.getFontMetrics();
    }
    int i = this.í + É() / 2 - localFontMetrics.stringWidth(this.õ) / 2;
    int j = this.ê + Ê() / 2 + (localFontMetrics.getAscent() + localFontMetrics.getDescent() / 2) / 2 - 2;
    if ((this.î) && (this.ö))
    {
      i += 3;
      j += 3;
    }
    paramGraphics2D.drawString(this.õ, i, j);
    A.B(paramGraphics2D);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.J
 * JD-Core Version:    0.6.2
 */