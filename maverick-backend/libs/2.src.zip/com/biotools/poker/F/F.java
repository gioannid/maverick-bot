package com.biotools.poker.F;

import com.biotools.B.G;
import com.biotools.poker.E;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JComponent;
import javax.swing.Timer;

public class F extends JComponent
  implements ActionListener
{
  private static final String A = "pix/lobby/spinner/";
  Image F;
  Image[] D = new Image[8];
  int E = 0;
  Timer B;
  double C = 0.0D;

  public F(G paramG)
  {
    this.F = paramG.B(E.K("pix/lobby/spinner/chip_animation-shadow.png"));
    for (int i = 0; i < this.D.length; i++)
      this.D[i] = paramG.B(E.K("pix/lobby/spinner/chip_animation-frame0" + (i + 1) + ".png"));
    this.B = new Timer(50, this);
    this.B.setCoalesce(true);
    this.B.setInitialDelay(0);
    this.B.setRepeats(true);
  }

  public Dimension getPreferredSize()
  {
    return new Dimension(this.F.getWidth(null), this.F.getHeight(null));
  }

  public Dimension getMinimumSize()
  {
    return new Dimension(this.F.getWidth(null), this.F.getHeight(null));
  }

  public Dimension getMaximumSize()
  {
    return new Dimension(this.F.getWidth(null), this.F.getHeight(null));
  }

  public void paint(Graphics paramGraphics)
  {
    paramGraphics.drawImage(this.F, 0, 0, null);
    paramGraphics.drawImage(this.D[this.E], 2, 2, null);
  }

  public void A(int paramInt)
  {
    this.B.setDelay(paramInt);
    B();
  }

  public void B()
  {
    this.C = 0.0D;
    this.B.start();
  }

  public void A()
  {
    this.B.stop();
  }

  public void actionPerformed(ActionEvent paramActionEvent)
  {
    repaint();
    this.C += 0.1570796326794897D;
    this.E = ((this.E + 1) % this.D.length);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.F
 * JD-Core Version:    0.6.2
 */