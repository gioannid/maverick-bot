package com.biotools.poker.F;

import com.biotools.B.L;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.poker.A;
import com.biotools.poker.E;
import com.biotools.poker.Q.D;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;

public class M extends J
{
  private A Ą;
  private boolean ą = false;
  private double ă = 0.0D;
  private String Ă = null;

  public M(A paramA)
  {
    super(paramA);
    this.Ą = paramA;
  }

  public boolean Ü()
  {
    return this.ą;
  }

  public void I(boolean paramBoolean)
  {
    this.ą = paramBoolean;
    if (paramBoolean)
      B("");
    else
      D(this.Ą.ǫ());
  }

  public void Ó()
  {
    this.ą = false;
    this.Ă = null;
  }

  public double Ï()
  {
    return this.ă;
  }

  public void G(boolean paramBoolean)
  {
    super.G(paramBoolean);
    Ó();
  }

  public void I(Graphics2D paramGraphics2D)
  {
    if (!this.ë)
      return;
    if (Ü())
    {
      Composite localComposite = paramGraphics2D.getComposite();
      A(paramGraphics2D, 0.85F);
      paramGraphics2D.drawImage(this.ā, this.í, this.ê, null);
      paramGraphics2D.setComposite(localComposite);
      J(paramGraphics2D);
    }
    else
    {
      super.I(paramGraphics2D);
    }
  }

  public Color Î()
  {
    if (Ü())
      return L.A(ô.brighter(), Color.RED, 0.5D);
    return super.Î();
  }

  private D Ô()
  {
    return this.Ą.ǆ();
  }

  private void Ø()
  {
    B(Ù());
    I(false);
    double d1 = Ï();
    double d2 = (0.0D / 0.0D);
    try
    {
      d2 = Double.parseDouble(Ù());
    }
    catch (NumberFormatException localNumberFormatException)
    {
    }
    if (d2 != d1)
    {
      Toolkit.getDefaultToolkit().beep();
      F(0.0D);
      this.Ą.Ǥ().Í();
    }
    else if (d1 >= Ô().getMinRaise())
    {
      Ò();
    }
    D(null);
  }

  private void Ö()
  {
    String str = Ù();
    if (str.length() > 0)
    {
      str = str.substring(0, str.length() - 1);
      B(str);
      this.Ą.ǋ();
    }
    B(str);
    this.Ą.ǋ();
  }

  private void Õ()
  {
    String str = Ù();
    int i = C(str);
    if (i < 0)
      B(str + ".");
  }

  private void A(char paramChar)
  {
    String str = Ù();
    if ((str.length() == 0) && (paramChar == '0'))
      return;
    int i = C(str);
    int j = A(str, i);
    if (j < 2)
    {
      B(str + paramChar);
      this.Ą.ǋ();
    }
  }

  public void A(KeyEvent paramKeyEvent)
  {
    if (!Ô().a())
      return;
    if (!Ü())
      return;
    if (paramKeyEvent.getKeyCode() == E.P())
    {
      I(false);
      return;
    }
    if (paramKeyEvent.getKeyCode() == 10)
      Ø();
    else if (paramKeyEvent.getKeyCode() == 8)
      Ö();
    if ((paramKeyEvent.getKeyChar() >= '0') && (paramKeyEvent.getKeyChar() <= '9'))
      A(paramKeyEvent.getKeyChar());
    if (paramKeyEvent.getKeyChar() == '.')
      Õ();
  }

  public void Ò()
  {
    if (Ü())
    {
      Ø();
      return;
    }
    double d1 = Ï();
    double d2 = Ô().getAmountToCall(Ú());
    if (d1 > 0.0D)
      this.Ą.C(Action.raiseAction(d2, d1));
    else
      this.Ą.C(Action.callAction(d2));
  }

  private int Ú()
  {
    return this.Ą.ǯ();
  }

  private PlayerInfo H(int paramInt)
  {
    return this.Ą.Z(paramInt);
  }

  public void D(double paramDouble)
  {
    paramDouble = E(paramDouble);
    PlayerInfo localPlayerInfo = H(Ú());
    if (localPlayerInfo != null)
    {
      double d1 = localPlayerInfo.getAmountToCall();
      double d2 = Ô().isNoLimit() ? E(localPlayerInfo.getBankRoll() - d1) : Ô().getCurrentBetSize();
      d2 = E(d2);
      if (d2 < 0.0D)
        d2 = 0.0D;
      double d3 = Ô().getMinRaise();
      if (d3 > d2)
        d3 = d2;
      if (paramDouble > d2)
        paramDouble = d2;
      if (paramDouble < d3)
        paramDouble = d3;
      Object[] arrayOfObject;
      if (d1 == 0.0D)
      {
        arrayOfObject = new Object[] { Action.formatCash(paramDouble) };
        A(E.A("RaiseButton.BetPattern", arrayOfObject));
      }
      else
      {
        arrayOfObject = new Object[] { Action.formatCash(paramDouble) };
        A(E.A("RaiseButton.RaisePattern", arrayOfObject));
      }
      this.ă = paramDouble;
      if (d2 != d3)
        this.Ą.Ǥ().A(paramDouble, d3, d2);
    }
  }

  public String Ù()
  {
    if (this.Ă == null)
      this.Ă = "";
    return this.Ă;
  }

  public void D(String paramString)
  {
    this.Ă = paramString;
  }

  public void B(String paramString)
  {
    double d1 = (0.0D / 0.0D);
    try
    {
      d1 = Double.parseDouble(paramString);
    }
    catch (NumberFormatException localNumberFormatException)
    {
    }
    if (Double.isNaN(d1))
      d1 = 0.0D;
    PlayerInfo localPlayerInfo = H(Ú());
    if (localPlayerInfo != null)
    {
      double d2 = localPlayerInfo.getAmountToCall();
      double d3 = localPlayerInfo.getBankRoll() - d2;
      d3 = E(d3);
      if (d3 < 0.0D)
        d3 = 0.0D;
      double d4 = Ô().getMinRaise();
      if (d4 > d3)
        d4 = d3;
      if (d1 > d3)
      {
        Toolkit.getDefaultToolkit().beep();
        d1 = d3;
        paramString = Integer.toString((int)d3);
      }
      Object[] arrayOfObject;
      if (d2 == 0.0D)
      {
        arrayOfObject = new Object[] { paramString };
        A(E.A("RaiseButton.BetAmountPattern", arrayOfObject));
      }
      else
      {
        arrayOfObject = new Object[] { paramString };
        A(E.A("RaiseButton.RaiseAmountPattern", arrayOfObject));
      }
      this.Ă = paramString;
      if (d1 < d4)
        return;
      this.ă = d1;
      if (d3 != d4)
        this.Ą.Ǥ().A(d1, d4, d3);
    }
  }

  public void F(double paramDouble)
  {
    Ó();
    PlayerInfo localPlayerInfo = H(Ú());
    if (localPlayerInfo != null)
    {
      if (paramDouble < 100.0D)
        paramDouble = 100.0D * (1.0D - Math.log(100.0D - paramDouble) / Math.log(100.0D));
      double d1 = localPlayerInfo.getAmountToCall();
      double d2 = localPlayerInfo.getBankRoll() - d1;
      if (d2 < 0.0D)
        d2 = 0.0D;
      double d3 = Ô().getMinRaise();
      if (d3 > d2)
        d3 = d2;
      double d4 = d3 + (d2 - d3) * (paramDouble / 100.0D);
      d4 = E(d4);
      if (paramDouble < 100.0D)
      {
        double d5 = Ô().getSmallBlindSize();
        double d6 = Ô().getSmallBlindSize();
        double d7 = (int)(d4 / d5) * d5;
        double d8 = (int)(d4 / d6) * d6;
        d4 = Math.min(d7, d8);
        if (d4 < d3)
          d4 = d3;
      }
      if (this.Ă == null)
      {
        Object[] arrayOfObject;
        if (d1 == 0.0D)
        {
          arrayOfObject = new Object[] { Action.formatCash(d4) };
          A(E.A("RaiseButton.BetPattern", arrayOfObject));
        }
        else
        {
          arrayOfObject = new Object[] { Action.formatCash(d4) };
          A(E.A("RaiseButton.RaisePattern", arrayOfObject));
        }
      }
      d4 = E(d4);
      this.ă = d4;
    }
  }

  public void Ñ()
  {
    PlayerInfo localPlayerInfo = H(Ú());
    if (localPlayerInfo != null)
    {
      double d1 = localPlayerInfo.getAmountToCall();
      double d2 = Ô().getTotalPotSize() + d1;
      D(d2);
    }
  }

  public void Ð()
  {
    PlayerInfo localPlayerInfo = H(Ú());
    if (localPlayerInfo != null)
    {
      double d = localPlayerInfo.getAmountToCall();
      long l1 = Math.round(100.0D * E((Ô().getTotalPotSize() + d) / 2.0D));
      long l2 = l1;
      long l3 = Math.round(100.0D * Ô().getSmallBlindSize());
      long l4 = Math.round(100.0D * Ô().getBigBlindSize());
      long l5 = l1 % l3;
      long l6 = l1 % l4;
      if ((l5 != 0L) && (l6 != 0L))
        if (l3 <= 10L)
        {
          l3 = 1L;
          l4 = 5L;
        }
        else if (l3 <= 50L)
        {
          l3 = 5L;
          l4 = 10L;
        }
        else if (l3 <= 100L)
        {
          l3 = 25L;
          l4 = 50L;
        }
        else if (l3 <= 500L)
        {
          l3 = 100L;
        }
        else if (l3 <= 5000L)
        {
          l3 = 500L;
        }
        else if (l3 <= 50000L)
        {
          l3 = 2500L;
        }
      l5 = l1 % l3;
      l6 = l1 % l4;
      if ((l5 != 0L) && (l6 != 0L))
      {
        long l7 = l3 * ((l1 + l3) / l3);
        long l8 = l4 * ((l1 + l4) / l4);
        l1 = Math.min(l7, l8);
      }
      if (E(l1) != E(l2))
        E.H("changed! ");
      D(E(l1 / 100.0D));
    }
  }

  public void Û()
  {
    PlayerInfo localPlayerInfo = H(Ú());
    if (localPlayerInfo != null)
    {
      double d1 = localPlayerInfo.getAmountToCall();
      double d2 = Ô().getTotalPotSize() + d1;
      D(d2 * 2.0D);
    }
  }

  private static int C(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    for (int i = 0; i < arrayOfChar.length; i++)
      if (arrayOfChar[i] == '.')
        return i;
    return -1;
  }

  private static int A(String paramString, int paramInt)
  {
    if (paramInt < 0)
      return 0;
    int i = 0;
    char[] arrayOfChar = paramString.toCharArray();
    for (int j = paramInt + 1; j < arrayOfChar.length; j++)
      i++;
    return i;
  }

  private double E(double paramDouble)
  {
    return Math.round(paramDouble * 100.0D) / 100.0D;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.M
 * JD-Core Version:    0.6.2
 */