package com.biotools.poker.F;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Q extends E
  implements ActionListener
{
  protected boolean Ċ = false;
  private boolean Ĉ = false;
  Color ĉ = null;

  public Q(String paramString)
  {
    this();
    this.õ = paramString;
  }

  public Q()
  {
    B(this);
  }

  public boolean Ý()
  {
    return this.Ċ;
  }

  public void J(boolean paramBoolean)
  {
    this.Ċ = paramBoolean;
  }

  public int É()
  {
    if (this.Ĉ)
      return 111;
    return 101;
  }

  public int Ê()
  {
    return 19;
  }

  public void K(boolean paramBoolean)
  {
    this.Ĉ = paramBoolean;
  }

  public void I(Graphics2D paramGraphics2D)
  {
    if (!Ä())
      return;
    if (this.ĉ == null)
      this.ĉ = com.biotools.B.A.D;
    if (this.Ĉ)
    {
      Composite localComposite = paramGraphics2D.getComposite();
      paramGraphics2D.setColor(Color.BLACK);
      paramGraphics2D.setColor(com.biotools.B.A.M);
      paramGraphics2D.setComposite(AlphaComposite.getInstance(3, 0.6F));
      paramGraphics2D.fillRoundRect(Å(), Ã(), É() - 1, Ê(), 5, 5);
      paramGraphics2D.setComposite(localComposite);
    }
    paramGraphics2D.setColor(this.ĉ);
    if (this.Ċ)
      paramGraphics2D.setColor(this.ĉ.brighter());
    paramGraphics2D.drawRect(Å() + 4, Ã() + 4, 10, 10);
    if (((this.Ċ) && (!this.î)) || ((!this.Ċ) && (this.î)))
    {
      int i = Å() + 6;
      int j = Ã() + 9;
      int k = i + 2;
      int m = j + 2;
      int n = k + 5;
      int i1 = m - 5;
      paramGraphics2D.drawLine(i, j, k, m);
      paramGraphics2D.drawLine(k, m, n, i1);
      j++;
      m++;
      i1++;
      paramGraphics2D.drawLine(i, j, k, m);
      paramGraphics2D.drawLine(k, m, n, i1);
      j++;
      m++;
      i1++;
      paramGraphics2D.drawLine(i, j, k, m);
      paramGraphics2D.drawLine(k, m, n, i1);
    }
    K(paramGraphics2D);
  }

  public void K(Graphics2D paramGraphics2D)
  {
    if (com.biotools.poker.E.¤())
      com.biotools.poker.A.A(paramGraphics2D);
    paramGraphics2D.setFont(J.ñ);
    paramGraphics2D.setFont(new Font("Arial", 0, 11));
    FontMetrics localFontMetrics = paramGraphics2D.getFontMetrics();
    int i = this.í + 18;
    int j = Ã() + Ê() / 2 + (localFontMetrics.getAscent() + localFontMetrics.getDescent() / 2) / 2 - 1;
    paramGraphics2D.drawString(this.õ, i, j);
    if (com.biotools.poker.E.¤())
      com.biotools.poker.A.B(paramGraphics2D);
  }

  public void actionPerformed(ActionEvent paramActionEvent)
  {
    this.Ċ = (!this.Ċ);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.Q
 * JD-Core Version:    0.6.2
 */