package com.biotools.poker.F;

import com.biotools.meerkat.Action;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.poker.A;
import com.biotools.poker.E;
import com.biotools.poker.N.W;
import com.biotools.poker.O._;
import com.biotools.poker.PokerApp;
import com.biotools.poker.Q.D;
import com.biotools.poker.Q.F;
import com.biotools.poker.Q.J;
import com.biotools.poker.Q.K;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class H
  implements ActionListener
{
  private ArrayList N;
  private Q M = new Q(E.D("AdvanceActionControls.Fold"));
  private Q F = new Q(E.D("AdvanceActionControls.FoldAny"));
  private Q J = new Q(E.D("AdvanceActionControls.Check"));
  private Q I = new Q(E.D("AdvanceActionControls.CallAny"));
  private Q G = new Q(E.D("AdvanceActionControls.Raise"));
  private Q O = new Q(E.D("AdvanceActionControls.RaiseAny"));
  private Q Q = new Q(E.D("AdvanceActionControls.SitOutNextHand"));
  private Q B = new Q(E.D("AdvanceActionControls.WaitForBlinds"));
  private double D = 0.0D;
  private double C = 0.0D;
  private int H = -1;
  private boolean P = false;
  private D L;
  private W K;
  private _ A = new _();
  boolean E = false;

  public H(A paramA, int paramInt1, int paramInt2)
  {
    A(paramA, paramInt1, paramInt2, this.M.É(), this.M.Ê());
  }

  public H(A paramA, int paramInt1, int paramInt2, int paramInt3)
  {
    A(paramA, paramInt1, paramInt2, paramInt3, this.M.Ê());
  }

  private void A(A paramA, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = 3;
    int j = paramInt2 - paramInt4 - i - 6;
    int k = paramInt1 / 2;
    int m = this.M.É();
    int n = (paramInt3 - m) / 2;
    int i1 = k - paramInt3 / 2;
    this.Q.H(6, j - (paramInt4 + 3) * 0);
    this.B.H(6, j - (paramInt4 + 3) * 1);
    this.M.H(i1 + (paramInt3 + paramInt3 / 3) * -1 + n + n, j - (paramInt4 + i) * 1);
    this.J.H(i1 + (paramInt3 + paramInt3 / 3) * 0 + n, this.M.ê);
    this.G.H(i1 + (paramInt3 + paramInt3 / 3) * 1, this.M.ê);
    this.F.H(this.M.í, j - (paramInt4 + i) * 0);
    this.I.H(this.J.í, this.F.ê);
    this.O.H(this.G.í, this.F.ê);
    this.B.H(true);
    this.B.K(true);
    this.B.G(false);
    this.Q.H(true);
    this.Q.K(true);
    G();
    if (E.Ð())
      this.A.D(new Rectangle(130, 470, 505, 43));
    else
      this.A.D(new Rectangle(150, 613, 505, 53));
    this.A.E(false);
    Iterator localIterator = H().iterator();
    while (localIterator.hasNext())
    {
      Q localQ = (Q)localIterator.next();
      if ((localQ != this.Q) && (localQ != this.B))
        localQ.B(this);
    }
    D(false);
  }

  public void actionPerformed(ActionEvent paramActionEvent)
  {
    if (this.P)
      return;
    this.P = true;
    Q localQ = (Q)paramActionEvent.getSource();
    boolean bool = localQ.Ý();
    B();
    localQ.J(bool);
    this.D = this.C;
    if ((this.K != null) && (this.L.getCurrentPlayerSeat() == this.K.Ď()))
    {
      Action localAction = A(this.K, this.L);
      if (localAction != null)
        this.K.A(localAction);
    }
    this.P = false;
  }

  public void D(boolean paramBoolean)
  {
    if ((!E.l()) && (paramBoolean))
      return;
    Iterator localIterator = H().iterator();
    while (localIterator.hasNext())
    {
      Q localQ = (Q)localIterator.next();
      if ((localQ != this.Q) && (localQ != this.B))
        localQ.G(paramBoolean);
    }
    this.A.E(paramBoolean);
  }

  public void B()
  {
    Iterator localIterator = H().iterator();
    while (localIterator.hasNext())
    {
      Q localQ = (Q)localIterator.next();
      if ((localQ != this.Q) && (localQ != this.B))
        localQ.J(false);
    }
    this.D = -1.0D;
  }

  public Collection H()
  {
    if (this.N == null)
    {
      this.N = new ArrayList();
      this.N.add(this.Q);
      this.N.add(this.B);
      this.N.add(this.M);
      this.N.add(this.J);
      this.N.add(this.G);
      this.N.add(this.F);
      this.N.add(this.I);
      this.N.add(this.O);
    }
    return this.N;
  }

  private void G()
  {
    this.Q.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        K localK = PokerApp.Ȅ().ʐ();
        if ((localK instanceof J))
          ((J)localK).F(H.this.Q.Ý());
      }
    });
  }

  public _ E()
  {
    return this.A;
  }

  public Action A(W paramW, D paramD)
  {
    this.K = paramW;
    this.L = paramD;
    int i = paramW.Ď();
    F localF = paramD.G(i);
    double d = paramD.getAmountToCall(i);
    if (this.F.Ý())
    {
      B();
      D(false);
      return Action.foldAction(d);
    }
    if (this.M.Ý())
    {
      B();
      D(false);
      return Action.checkOrFoldAction(d);
    }
    if (this.I.Ý())
    {
      B();
      return Action.callAction(d);
    }
    if ((this.J.Ý()) && (this.D == d))
    {
      B();
      return Action.callAction(d);
    }
    if (this.O.Ý())
    {
      B();
      if (paramD.isNoLimit())
        return Action.raiseAction(d, localF.getBankRoll() - d);
      return Action.raiseAction(d, paramD.getMinRaise());
    }
    if ((this.G.Ý()) && (this.D == d))
    {
      B();
      return Action.raiseAction(d, paramD.getMinRaise());
    }
    return null;
  }

  public void A(GameInfo paramGameInfo, int paramInt)
  {
    if (!E.l())
      return;
    if (paramInt == -1)
      return;
    if (C())
      return;
    double d = paramGameInfo.getMinRaise();
    PlayerInfo localPlayerInfo = paramGameInfo.getPlayer(paramInt);
    if (this.H != paramGameInfo.getStage())
      B();
    this.H = paramGameInfo.getStage();
    if ((paramGameInfo.isGameOver()) || (!paramGameInfo.isActive(paramInt)) || (paramGameInfo.getNumActivePlayersNotAllIn() <= 1) || (paramGameInfo.getStage() > 3) || (localPlayerInfo.isAllIn()) || (paramGameInfo.getNumToAct() <= 0))
    {
      B();
      D(false);
      return;
    }
    D(true);
    this.C = paramGameInfo.getAmountToCall(paramInt);
    if ((this.C == 0.0D) && (localPlayerInfo.hasActedThisRound()) && (localPlayerInfo.getAmountInPot() == paramGameInfo.getStakes()))
      this.C = paramGameInfo.getCurrentBetSize();
    if (this.D != this.C)
    {
      this.J.J(false);
      this.G.J(false);
    }
    Object[] arrayOfObject1;
    if (this.C == 0.0D)
    {
      this.M.A(E.D("AdvanceActionControls.CheckFold"));
      this.J.A(E.D("AdvanceActionControls.Check"));
      arrayOfObject1 = new Object[] { Action.formatCash(localPlayerInfo.getRaiseAmount(d)) };
      this.G.A(E.A("AdvanceActionControls.BetPattern", arrayOfObject1));
    }
    else
    {
      this.M.A(E.D("AdvanceActionControls.Fold"));
      arrayOfObject1 = new Object[] { Action.formatCash(this.C) };
      this.J.A(E.A("AdvanceActionControls.CallPattern", arrayOfObject1));
      if (paramGameInfo.isNoLimit())
        this.O.A(E.D("AdvanceActionControls.Jam"));
      else
        this.O.A(E.D("AdvanceActionControls.RaiseAny"));
      Object[] arrayOfObject2 = { Action.formatCash(localPlayerInfo.getRaiseAmount(d)) };
      this.G.A(E.A("AdvanceActionControls.RaisePattern", arrayOfObject2));
    }
    boolean bool = paramGameInfo.canRaise(localPlayerInfo.getSeat());
    this.G.G(bool);
    this.O.G(bool);
  }

  public void B(boolean paramBoolean)
  {
    this.Q.G(paramBoolean);
  }

  public void C(boolean paramBoolean)
  {
    this.B.G(paramBoolean);
  }

  public void A(Action paramAction)
  {
    B();
    if (paramAction.isFold())
      this.M.J(true);
    else if (paramAction.isCheckOrCall())
      this.J.J(true);
    else if (paramAction.isBetOrRaise())
      this.G.J(true);
  }

  public void I()
  {
    if (!this.M.Ä())
      return;
    this.P = true;
    boolean bool = this.M.Ý();
    B();
    this.M.J(!bool);
    this.D = this.C;
    this.P = false;
  }

  public void J()
  {
    if (!this.J.Ä())
      return;
    this.P = true;
    boolean bool = this.J.Ý();
    B();
    this.J.J(!bool);
    this.D = this.C;
    this.P = false;
  }

  public void A()
  {
    if (!this.G.Ä())
      return;
    this.P = true;
    boolean bool = this.G.Ý();
    B();
    this.G.J(!bool);
    this.D = this.C;
    this.P = false;
  }

  public void F()
  {
    if (!this.O.Ä())
      return;
    this.P = true;
    boolean bool = this.O.Ý();
    B();
    this.O.J(!bool);
    this.D = this.C;
    this.P = false;
  }

  public void E(boolean paramBoolean)
  {
    this.Q.J(paramBoolean);
    this.E = paramBoolean;
    if (paramBoolean)
    {
      this.B.G(false);
      this.B.J(false);
    }
  }

  public boolean C()
  {
    return this.E;
  }

  public boolean D()
  {
    return this.B.Ý();
  }

  public void A(boolean paramBoolean)
  {
    this.B.J(paramBoolean);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.H
 * JD-Core Version:    0.6.2
 */