package com.biotools.poker.F;

import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.GameObserver;
import com.biotools.poker.A;
import com.biotools.poker.E;
import com.biotools.poker.PokerApp;
import com.biotools.poker.Q.B;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collection;

public class I
  implements GameObserver
{
  private B Ȕ;
  private O Ȗ;
  private O ȗ;
  private O ȕ;
  private O ȓ;
  private O Ȓ;

  public I(A paramA, int paramInt1, int paramInt2)
  {
    this.Ȗ = new O(E.K("pix/playback-next-off.png"), E.K("pix/playback-next-on.png"), paramA);
    this.ȗ = new O(E.K("pix/playback-prev-off.png"), E.K("pix/playback-prev-on.png"), paramA);
    this.ȕ = new O(E.K("pix/playback-play-off.png"), E.K("pix/playback-play-on.png"), paramA);
    this.Ȓ = new O(E.K("pix/playback-pause-off.png"), E.K("pix/playback-pause-on.png"), paramA);
    this.ȓ = new O(E.K("pix/playback-step-off.png"), E.K("pix/playback-step-on.png"), paramA);
    E(false);
    int i = 10;
    int j = this.Ȗ.É();
    int k = this.Ȗ.Ê();
    int m = paramInt2 - k - i;
    int n = 5;
    int i1 = paramInt1 / 2 - n - j - n - n - j;
    this.ȗ.H(i1, m);
    i1 += j + n;
    i1 += n;
    this.ȓ.H(i1, m);
    i1 += j + n;
    this.ȕ.H(i1, m);
    this.Ȓ.H(i1, m);
    i1 += j + n;
    i1 += n;
    this.Ȗ.H(i1, m);
    this.Ȗ.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        I.this.ź();
      }
    });
    this.ȗ.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        I.this.ż();
      }
    });
    this.ȕ.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        I.this.ſ();
      }
    });
    this.Ȓ.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        I.this.Ž();
      }
    });
    this.ȓ.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        I.this.ž();
      }
    });
  }

  public void A(B paramB)
  {
    if (this.Ȕ != null)
      this.Ȕ.C(this);
    this.Ȕ = paramB;
    this.Ȕ.B(this);
  }

  public void E(boolean paramBoolean)
  {
    this.Ȗ.G(paramBoolean);
    this.ȗ.G(paramBoolean);
    this.ȕ.G((paramBoolean) && (this.Ȕ.¥()));
    this.Ȓ.G((paramBoolean) && (!this.Ȕ.¥()));
    this.ȓ.G(paramBoolean);
  }

  protected void ž()
  {
    if (this.Ȕ.R())
      this.Ȕ.º();
    else if (this.Ȕ.v())
      PokerApp.Ȅ().ǰ();
  }

  protected void ſ()
  {
    this.Ȕ.x();
    this.Ȓ.G(true);
    this.ȕ.G(false);
  }

  protected void Ž()
  {
    this.Ȕ.¤();
    this.Ȓ.G(false);
    this.ȕ.G(true);
  }

  protected void ź()
  {
    if (this.Ȕ.v())
    {
      this.Ȗ.H(true);
      PokerApp.Ȅ().ɓ();
      PokerApp.Ȅ().ǰ();
    }
    else
    {
      this.Ȗ.H(false);
    }
  }

  protected void ż()
  {
    PokerApp.Ȅ().ɓ();
    this.Ȕ.Ä();
    if (this.Ȕ.u() == 0)
      this.ȗ.H(false);
    PokerApp.Ȅ().ǰ();
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
    this.ȗ.H(true);
  }

  public void stageEvent(int paramInt)
  {
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    this.Ȗ.H(this.Ȕ.v());
    this.Ȓ.H(true);
    this.ȕ.H(true);
    this.ȓ.H(true);
  }

  public void gameOverEvent()
  {
    if (!this.Ȕ.¥())
      if (this.Ȕ.v())
      {
        PokerApp.Ȅ().ǰ();
      }
      else
      {
        this.ȕ.H(false);
        this.Ȓ.H(false);
        this.ȓ.H(false);
      }
  }

  public void dealHoleCardsEvent()
  {
  }

  public void gameStateChanged()
  {
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
  }

  public Collection Ż()
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(this.Ȗ);
    localArrayList.add(this.Ȓ);
    localArrayList.add(this.ȕ);
    localArrayList.add(this.ȗ);
    localArrayList.add(this.ȓ);
    return localArrayList;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.I
 * JD-Core Version:    0.6.2
 */