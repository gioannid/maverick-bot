package com.biotools.poker.F;

import com.biotools.A.I;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import javax.imageio.ImageIO;
import javax.swing.JComponent;

public class U extends JComponent
{
  private static volatile Hashtable I = new Hashtable();
  private static final String C = "data/cards/";
  private static final String E = "data/cards-med/";
  private Card H = null;
  private Image D;
  private Image G;
  private boolean A = false;
  private boolean B = false;
  private boolean F = false;

  public static void A(String[] paramArrayOfString)
  {
    K();
  }

  private static void K()
  {
    String str = "data/help/tutorial/standalone/pix/deck.png";
    BufferedImage localBufferedImage = new BufferedImage(340, 266, 2);
    Graphics2D localGraphics2D = localBufferedImage.createGraphics();
    String[] arrayOfString1 = "2 3 4 5 6 7 8 9 T J Q K A".split(" ");
    String[] arrayOfString2 = "h s d c".split(" ");
    for (int i = 0; i < arrayOfString2.length; i++)
      for (int j = 0; j < arrayOfString1.length; j++)
      {
        T localT = new T(new Card(arrayOfString1[j].charAt(0), arrayOfString2[i].charAt(0)));
        localT.A(j * 25, i * 70, localGraphics2D, -1.0F, 0, true);
      }
    try
    {
      ImageIO.write(localBufferedImage, "png", new File(str));
    }
    catch (IOException localIOException)
    {
      I.A("", localIOException);
    }
  }

  public static boolean E()
  {
    return E.£().getBoolean("FOUR_COLOR", false);
  }

  public U(Card paramCard)
  {
    A(paramCard);
  }

  public U()
  {
    setSize(getPreferredSize());
  }

  public void J()
  {
    this.A = true;
    G();
    setSize(getPreferredSize());
  }

  public String I()
  {
    return O() ? "data/cards-med/" : "data/cards/";
  }

  public void F()
  {
    A(this.H);
  }

  public int A()
  {
    return O() ? 43 : 55;
  }

  public void A(Card paramCard)
  {
    if ((paramCard == null) || (!paramCard.valid()))
    {
      G();
    }
    else
    {
      this.H = new Card(paramCard.getIndex());
      String str = "";
      if (E())
        if (paramCard.getSuit() == 3)
          str = "g";
        else if (paramCard.getSuit() == 2)
          str = "b";
      this.D = B(I() + paramCard.toEnglishString() + str + ".png");
    }
    repaint();
  }

  public void G()
  {
    this.D = P();
    this.H = null;
  }

  private Image P()
  {
    if (this.G == null)
      this.G = B(I() + "back4.png");
    return this.G;
  }

  public boolean C()
  {
    return this.D == P();
  }

  public boolean H()
  {
    return (C()) || (N() == null) || (!N().valid());
  }

  public void Q()
  {
    this.D = B(I() + "folded.gif");
    this.H = null;
  }

  public void L()
  {
    this.D = B(I() + "greencard.png");
    this.H = null;
  }

  public Dimension getPreferredSize()
  {
    return new Dimension(getWidth(), getHeight());
  }

  public Dimension getMaximumSize()
  {
    return new Dimension(getWidth(), getHeight());
  }

  public Dimension getMinimumSize()
  {
    return new Dimension(getWidth(), getHeight());
  }

  public void A(boolean paramBoolean)
  {
    this.B = paramBoolean;
  }

  public boolean B()
  {
    return this.B;
  }

  public int getWidth()
  {
    return O() ? 40 : 50;
  }

  public int getHeight()
  {
    return O() ? 56 : 70;
  }

  public Card N()
  {
    return this.H;
  }

  protected Image B(String paramString)
  {
    Image localImage = null;
    if (I.contains(paramString))
      localImage = (Image)I.get(paramString);
    if (localImage == null)
    {
      localImage = A(paramString);
      I.put(paramString, localImage);
    }
    return localImage;
  }

  public void paint(Graphics paramGraphics)
  {
    A(0, 0, paramGraphics, -1.0F);
  }

  public void A(int paramInt1, int paramInt2, Graphics paramGraphics, float paramFloat)
  {
    A(paramInt1, paramInt2, paramGraphics, paramFloat, 0, false);
  }

  public void A(int paramInt1, int paramInt2, Graphics paramGraphics, float paramFloat, int paramInt3, boolean paramBoolean)
  {
    if ((isVisible()) || (paramBoolean))
      if (this.B)
      {
        int i = getWidth();
        int j = getHeight();
        Graphics2D localGraphics2D2 = (Graphics2D)paramGraphics;
        Composite localComposite = localGraphics2D2.getComposite();
        Color localColor = Color.getHSBColor(0.0F, 0.0F, 0.2F);
        localGraphics2D2.setColor(localColor);
        localGraphics2D2.fillRect(paramInt1 + 1, paramInt2 + 1, i - 2, j - 2);
        localGraphics2D2.setComposite(AlphaComposite.getInstance(3, 0.5F));
        localGraphics2D2.drawImage(M(), paramInt1, paramInt2, null);
        localGraphics2D2.setComposite(localComposite);
      }
      else
      {
        Graphics2D localGraphics2D1 = (Graphics2D)paramGraphics;
        if (paramFloat < 0.0F)
        {
          paramGraphics.drawImage(M(), paramInt1, paramInt2, null);
        }
        else
        {
          AffineTransform localAffineTransform = localGraphics2D1.getTransform();
          int k = getWidth();
          int m = getHeight();
          int n = (int)(k * paramFloat) / 2;
          if (paramInt3 == 0)
          {
            int i1 = k / 2;
            paramGraphics.drawImage(M(), paramInt1 + i1 - n, paramInt2, paramInt1 + i1 + n, paramInt2 + m, 0, 0, k, m, null);
          }
          double d;
          if (paramInt3 == 1)
          {
            localGraphics2D1.translate(paramInt1, paramInt2);
            if (paramFloat == 0.0F)
              paramFloat = 1.0E-005F;
            d = (1.0D - paramFloat) * (20.0D / k) / paramFloat;
            localGraphics2D1.shear(0.0D, -d);
            paramGraphics.drawImage(M(), 0, 0, n + n, m, 0, 0, k, m, null);
          }
          if (paramInt3 == 2)
          {
            localGraphics2D1.translate(paramInt1 + k, paramInt2);
            if (paramFloat == 0.0F)
              paramFloat = 1.0E-005F;
            d = (1.0D - paramFloat) * (20.0D / k) / paramFloat;
            localGraphics2D1.shear(0.0D, d);
            paramGraphics.drawImage(M(), 0 - n - n, 0, 0, m, 0, 0, k, m, null);
          }
          localGraphics2D1.setTransform(localAffineTransform);
        }
      }
  }

  public Image M()
  {
    if (this.D == null)
      G();
    return this.D;
  }

  public Image A(String paramString)
  {
    Image localImage = Toolkit.getDefaultToolkit().getImage(paramString);
    MediaTracker localMediaTracker = new MediaTracker(this);
    localMediaTracker.addImage(localImage, 0);
    try
    {
      localMediaTracker.waitForAll();
    }
    catch (InterruptedException localInterruptedException)
    {
    }
    return localImage;
  }

  protected boolean O()
  {
    return this.A;
  }

  public boolean D()
  {
    return this.F;
  }

  public void B(boolean paramBoolean)
  {
    this.F = paramBoolean;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.U
 * JD-Core Version:    0.6.2
 */