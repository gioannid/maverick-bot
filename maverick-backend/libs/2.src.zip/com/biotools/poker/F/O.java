package com.biotools.poker.F;

import com.biotools.B.G;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.io.File;

public class O extends J
{
  int ć;
  int Ć;

  public O(File paramFile1, File paramFile2, G paramG)
  {
    super(paramG);
    if (paramFile1 != null)
      this.ā = paramG.B(paramFile1);
    else
      this.ā = null;
    if (paramFile2 != null)
      this.ÿ = paramG.B(paramFile2);
    else
      this.ā = null;
    if (this.ā != null)
    {
      this.ć = this.ā.getWidth(null);
      this.Ć = this.ā.getHeight(null);
    }
    else if (this.ÿ != null)
    {
      this.ć = this.ÿ.getWidth(null);
      this.Ć = this.ÿ.getHeight(null);
    }
  }

  public void I(Graphics2D paramGraphics2D)
  {
    if (!this.ë)
      return;
    int i = 0;
    if (!this.ï)
    {
      Composite localComposite = paramGraphics2D.getComposite();
      A(paramGraphics2D, 0.5F);
      if (this.ā != null)
        paramGraphics2D.drawImage(this.ā, this.í, this.ê, null);
      J(paramGraphics2D);
      paramGraphics2D.setComposite(localComposite);
    }
    else
    {
      if ((this.î) && (this.ö))
        if ((this.ā == null) && (this.ÿ != null))
          paramGraphics2D.drawImage(this.ÿ, this.í + i, this.ê + i, null);
        else
          i++;
      if (this.ö)
      {
        if (this.ÿ != null)
          paramGraphics2D.drawImage(this.ÿ, this.í + i, this.ê + i, null);
      }
      else if (this.ā != null)
        paramGraphics2D.drawImage(this.ā, this.í + i, this.ê + i, null);
      J(paramGraphics2D);
    }
  }

  public void J(Graphics2D paramGraphics2D)
  {
  }

  public int É()
  {
    return this.ć;
  }

  public int Ê()
  {
    return this.Ć;
  }

  protected int À()
  {
    return this.ć;
  }

  protected int Â()
  {
    return this.Ć;
  }

  public Rectangle È()
  {
    if (this.é == null)
    {
      Rectangle localRectangle = Á();
      int i = É() + 1;
      int j = Ê() + 1;
      this.é = new Rectangle(localRectangle.x, localRectangle.y, i, j);
    }
    return this.é;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.O
 * JD-Core Version:    0.6.2
 */