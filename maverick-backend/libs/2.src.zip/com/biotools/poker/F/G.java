package com.biotools.poker.F;

import com.biotools.meerkat.PlayerInfo;
import com.biotools.poker.Q.D;
import com.biotools.poker.Q.F;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Rectangle;

public class G extends E
{
  protected double ü = 0.0D;
  protected int ø = 0;
  protected int ù = 0;
  protected int û = 2;
  protected int ý = 114;
  private com.biotools.poker.A ú;

  public G(com.biotools.poker.A paramA)
  {
    this.õ = "NLSlider";
    this.ú = paramA;
  }

  public int É()
  {
    return 127;
  }

  public int Ê()
  {
    return 33;
  }

  public double B(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    double d1 = 100.0D * (paramDouble1 - paramDouble2) / (paramDouble3 - paramDouble2);
    double d2 = 100.0D - Math.exp(Math.log(100.0D) * (1.0D - d1 / 100.0D));
    return d2;
  }

  public void A(int paramInt1, int paramInt2, int paramInt3)
  {
    this.ù = paramInt1;
    this.ø = paramInt2;
    this.ü = paramInt3;
  }

  public void Í()
  {
    this.ü = this.ù;
    G(this.í + this.û);
  }

  public void I(Graphics2D paramGraphics2D)
  {
    if (!this.ë)
      return;
    if (this.ù >= this.ø)
      return;
    int i = (É() - this.ý) / 2;
    this.û = i;
    int j = Ê();
    int k = É() - i * 2;
    Composite localComposite = paramGraphics2D.getComposite();
    A(paramGraphics2D, this.ö ? 0.95F : 0.7F);
    paramGraphics2D.setColor(com.biotools.B.A.M);
    paramGraphics2D.fill3DRect(this.í, this.ê, k + i * 2, j, true);
    paramGraphics2D.setComposite(localComposite);
    int m = this.ê + j / 2;
    paramGraphics2D.setColor(com.biotools.B.A.D);
    paramGraphics2D.drawLine(this.í + i, m, this.í + i + k, m);
    int n = this.ù;
    paramGraphics2D.drawLine(this.í + i, m - 3, this.í + i, m + 4);
    paramGraphics2D.drawLine(this.í + i + k, m - 3, this.í + i + k, m + 4);
    int i1 = 1;
    for (double d1 = B(i1); (d1 != -1.0D) && (d1 < this.ø) && (i1 < this.ý); d1 = B(i1))
    {
      i2 = (int)(d1 / this.ø * this.ý);
      paramGraphics2D.drawLine(this.í + i + i2, m, this.í + i + i2, m + 3);
      i1++;
    }
    paramGraphics2D.setColor(this.î ? com.biotools.B.A.D.brighter() : com.biotools.B.A.D);
    int i2 = this.í + i + (int)(this.ü / this.ø * this.ý);
    Polygon localPolygon = new Polygon();
    localPolygon.addPoint(i2, m + 2);
    localPolygon.addPoint(i2 + 5, m + 2 + 10);
    localPolygon.addPoint(i2 - 5, m + 2 + 10);
    paramGraphics2D.fillPolygon(localPolygon);
    paramGraphics2D.setColor(paramGraphics2D.getColor().darker());
    paramGraphics2D.drawPolygon(localPolygon);
    paramGraphics2D.setFont(new Font("Application", 0, 9));
    FontMetrics localFontMetrics = paramGraphics2D.getFontMetrics();
    double d2 = Ì();
    double d3 = Ë();
    Object[] arrayOfObject = { new Long(Math.round(d2)), new Double(d3 > 10.0D ? Math.round(d3) : d3) };
    String str = d2 < 1.0D ? com.biotools.poker.E.A("SliderWidget.StackPotIndicatorSmallPattern", arrayOfObject) : com.biotools.poker.E.A("SliderWidget.StackPotIndictorPattern", arrayOfObject);
    paramGraphics2D.setColor(com.biotools.B.A.D);
    if ((d2 > 66.0D) || (d3 > 2.5D))
      paramGraphics2D.setColor(com.biotools.B.A.D.brighter());
    int i3 = localFontMetrics.stringWidth(str);
    paramGraphics2D.drawString(str, this.í + i + (k - i3) / 2, this.ê + j / 2 - 2);
  }

  public double Ì()
  {
    D localD = this.ú.ǆ();
    assert (localD != null);
    if (localD == null)
      return -1.0D;
    F localF = localD.G(this.ú.ǯ());
    assert (localF != null);
    if (localF == null)
      return -1.0D;
    double d = this.ú.ǫ();
    return 100.0D * d / (localF.getBankRoll() - localF.getAmountToCall());
  }

  public double Ë()
  {
    D localD = this.ú.ǆ();
    assert (localD != null);
    if (localD == null)
      return -1.0D;
    F localF = localD.G(this.ú.ǯ());
    assert (localF != null);
    if (localF == null)
      return -1.0D;
    double d1 = this.ú.ǫ();
    double d2 = d1 / (localD.getTotalPotSize() + localF.getAmountToCall());
    return Math.round(10.0D * d2) / 10.0D;
  }

  private double B(double paramDouble)
  {
    D localD = this.ú.ǆ();
    assert (localD != null);
    if (localD == null)
      return -1.0D;
    F localF = localD.G(this.ú.ǯ());
    assert (localF != null);
    if (localF == null)
      return -1.0D;
    double d1 = localF.getAmountToCall();
    double d2 = paramDouble * (localD.getTotalPotSize() + d1);
    double d3 = localF.getBankRoll() - d1;
    double d4 = localD.getMinRaise();
    return B(d2, d4, d3);
  }

  public Rectangle Á()
  {
    return new Rectangle(this.í, this.ê, É() + 1, Ê() + 1);
  }

  public boolean F(int paramInt1, int paramInt2)
  {
    return (this.ë) && (paramInt1 > this.í) && (paramInt1 < this.í + É()) && (paramInt2 > this.ê) && (paramInt2 < this.ê + Ê());
  }

  public boolean I(int paramInt1, int paramInt2)
  {
    this.ì = true;
    if (F(paramInt1, paramInt2))
    {
      F(true);
      this.î = true;
      G(paramInt1);
      return true;
    }
    return false;
  }

  public boolean E(int paramInt1, int paramInt2)
  {
    this.ì = true;
    F(false);
    if ((F(paramInt1, paramInt2)) && (this.î))
    {
      this.î = false;
      return true;
    }
    this.î = false;
    return false;
  }

  public boolean G(int paramInt1, int paramInt2)
  {
    if (!this.ë)
      return false;
    boolean bool1 = this.ö;
    boolean bool2 = F(paramInt1, paramInt2);
    this.ì = (bool2 ^ bool1);
    if (this.î)
    {
      G(paramInt1);
      this.ì = true;
    }
    F(bool2);
    return bool2 ^ bool1;
  }

  public void G(int paramInt)
  {
    int i = this.í + this.û;
    if (paramInt > i + this.ý)
      paramInt = i + this.ý;
    if (paramInt < i)
      paramInt = i;
    this.ü = (this.ù + (int)((paramInt - i) / this.ý * (this.ø - this.ù)));
    this.ú.ǌ().F(this.ü);
  }

  public void A(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    if (paramDouble1 >= paramDouble3)
    {
      C(this.ø);
      return;
    }
    if (paramDouble1 <= paramDouble2)
    {
      C(this.ù);
      return;
    }
    C(B(paramDouble1, paramDouble2, paramDouble3));
  }

  public void C(double paramDouble)
  {
    this.ü = paramDouble;
  }

  public Rectangle È()
  {
    if (this.é == null)
      this.é = Á();
    return this.é;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.G
 * JD-Core Version:    0.6.2
 */