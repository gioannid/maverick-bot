package com.biotools.poker.F;

import com.biotools.A.A;
import com.biotools.A.G;
import com.biotools.A.I;
import com.biotools.A.M;
import com.biotools.A.S;
import com.biotools.A.V;
import com.biotools.A.Y;
import com.biotools.A.Z;
import com.biotools.A._;
import com.biotools.A.d;
import com.biotools.A.f;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import java.applet.AudioClip;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JApplet;
import javax.swing.JOptionPane;

public class D
{
  private boolean D = true;
  private boolean B = true;
  private boolean S = true;
  public static final int W = -1;
  public static final int M = 0;
  public static final int P = 1;
  public static final int Z = 2;
  private Y[] F = A(4);
  private Y[] R = A(4);
  private Y[] L = A(3);
  private Y[] I = A(4);
  private Y[] K = A(5);
  private Y[] b = A(3);
  private Y[] E = A(4);
  private Y[] a = A(5);
  private Y[] N = A(1);
  private Y[] O = A(3);
  private Y[] X = A(1);
  private Y J;
  private Y d;
  private Y T;
  private Y C;
  public static final int G = 1;
  public static final int c = 2;
  public static final int A = 3;
  public static final int H = 4;
  public static final int Y = 5;
  public static final int V = 6;
  public static final int Q = 7;
  private static final int _ = Q();
  private boolean U = false;

  public static int Q()
  {
    return E.£().getInt("SOUND_ENGINE", 7);
  }

  public static void A()
  {
    if (_ == 1)
      S.B();
  }

  public Y[] A(int paramInt)
  {
    if (_ == 7)
      return new _[paramInt];
    if (_ == 3)
      return new G[paramInt];
    if (_ == 1)
      return new Z[paramInt];
    if (_ == 4)
      return new M[paramInt];
    if (_ == 5)
      return new V[paramInt];
    if (_ == 6)
      return new A[paramInt];
    return new f[paramInt];
  }

  public Y B(String paramString)
  {
    if (_ == 7)
      return new _(paramString);
    if (_ == 3)
      return new G(paramString);
    if (_ == 1)
      return new Z(paramString);
    if (_ == 4)
      return new M(paramString);
    if (_ == 5)
      return new V(paramString);
    if (_ == 6)
      return new A(paramString);
    return new f(paramString);
  }

  public void C()
  {
    for (int i = 0; i < this.F.length; i++)
      this.F[i] = B("data/sounds/deal" + (i + 1) + ".wav");
    for (i = 0; i < this.R.length; i++)
      this.R[i] = B("data/sounds/chips-call" + (i + 1) + ".wav");
    for (i = 0; i < this.L.length; i++)
      this.L[i] = B("data/sounds/chips-bet" + (i + 1) + ".wav");
    for (i = 0; i < this.I.length; i++)
      this.I[i] = B("data/sounds/chips-raise" + (i + 1) + ".wav");
    for (i = 0; i < this.b.length; i++)
      this.b[i] = B("data/sounds/fold" + (i + 1) + ".wav");
    for (i = 0; i < this.K.length; i++)
      this.K[i] = B("data/sounds/check" + (i + 1) + ".wav");
    for (i = 0; i < this.E.length; i++)
      this.E[i] = B("data/sounds/shuffle" + (i + 1) + ".wav");
    for (i = 0; i < this.a.length; i++)
      this.a[i] = B("data/sounds/rakePot" + (i + 1) + ".wav");
    for (i = 0; i < this.N.length; i++)
      this.N[i] = B("data/sounds/bigHand" + (i + 1) + ".wav");
    for (i = 0; i < this.O.length; i++)
      this.O[i] = B("data/sounds/aggression" + (i + 1) + ".wav");
    for (i = 0; i < this.X.length; i++)
      this.X[i] = B("data/sounds/rollout" + (i + 1) + ".wav");
    this.J = B("data/sounds/beep1.wav");
    this.d = B("data/sounds/ourTurnNet1.wav");
    this.C = B("data/sounds/sunshine.wav");
    this.T = B("data/sounds/bingbong.wav");
  }

  public void E()
  {
    this.D = E.£().getBoolean("USE_SOUND_TABLE", true);
    this.B = E.£().getBoolean("USE_SOUND_BEEP", true);
    this.S = E.£().getBoolean("USE_SOUND_OTHER", true);
  }

  private void J()
  {
    E.£().putBoolean("USE_SOUND_TABLE", false);
    E.£().putBoolean("USE_SOUND_BEEP", false);
    E.£().putBoolean("USE_SOUND_OTHER", false);
    E();
    this.U = true;
  }

  public void A(Y paramY, int paramInt)
  {
    switch (paramInt)
    {
    case 0:
      if (!this.B)
        return;
      break;
    case 1:
      if (!this.D)
        return;
      break;
    case 2:
      if (!this.S)
        return;
      break;
    }
    try
    {
      paramY.A();
      if (!this.U)
        this.U = true;
    }
    catch (Error localError)
    {
      if (localError.getMessage().equals("AudioError"))
        try
        {
          throw localError.getCause();
        }
        catch (UnsupportedAudioFileException localUnsupportedAudioFileException)
        {
          I.A(E.D("SoundEffects.ErrorUnsupportedFile"), localUnsupportedAudioFileException);
        }
        catch (IOException localIOException)
        {
          I.A(E.D("SoundEffects.ErrorUnableReadSoundFile"), localIOException);
        }
        catch (LineUnavailableException localLineUnavailableException)
        {
          d.A(E.D("SoundEffects.ErrorUnableGetLineToPlaySound"), localLineUnavailableException);
        }
        catch (IllegalArgumentException localIllegalArgumentException)
        {
          if (!this.U)
          {
            JOptionPane.showMessageDialog(E.É(), E.D("SoundEffects.SoundDeviceNotFound"), E.D("SoundEffects.SoundError"), 0);
            J();
          }
          d.A("ERROR: IllegalArgumentException", localIllegalArgumentException);
        }
        catch (Throwable localThrowable)
        {
          localThrowable.printStackTrace();
        }
      else
        throw localError;
    }
  }

  public AudioClip C(String paramString)
  {
    try
    {
      File localFile = new File(paramString);
      AudioClip localAudioClip = JApplet.newAudioClip(localFile.toURI().toURL());
      return localAudioClip;
    }
    catch (MalformedURLException localMalformedURLException)
    {
      localMalformedURLException.printStackTrace();
    }
    return null;
  }

  public void M()
  {
    if (this.J != null)
      A(this.J, 0);
  }

  public void T()
  {
    int i = (int)(Math.random() * this.F.length);
    A(this.F[i], 1);
  }

  public void G()
  {
    int i = (int)(Math.random() * this.R.length);
    A(this.R[i], 1);
  }

  public void H()
  {
    int i = (int)(Math.random() * this.L.length);
    A(this.L[i], 1);
  }

  public void R()
  {
    int i = (int)(Math.random() * this.I.length);
    A(this.I[i], 1);
  }

  public void U()
  {
    int i = (int)(Math.random() * this.K.length);
    A(this.K[i], 1);
  }

  public void F()
  {
    int i = (int)(Math.random() * this.N.length);
    A(this.N[i], 2);
  }

  public void S()
  {
    int i = (int)(Math.random() * this.O.length);
    A(this.O[i], 2);
  }

  public void B()
  {
    int i = (int)(Math.random() * this.b.length);
    A(this.b[i], 1);
  }

  public void P()
  {
    int i = (int)(Math.random() * this.E.length);
    A(this.E[i], 1);
  }

  public void K()
  {
    int i = (int)(Math.random() * this.a.length);
    A(this.a[i], 1);
  }

  public void L()
  {
    int i = (int)(Math.random() * this.X.length);
    A(this.X[i], 2);
  }

  public void O()
  {
    if (this.d != null)
      A(this.d, 0);
  }

  public void N()
  {
    if (this.C != null)
      A(this.C, 0);
  }

  public void D()
  {
    if (this.T != null)
      A(this.T, 0);
  }

  public void A(String paramString)
  {
    A(B(paramString), -1);
  }

  protected static void I()
  {
    D localD = new D();
    localD.C();
    while (true)
      try
      {
        int i = 5;
        localD.P();
        Thread.currentThread();
        Thread.sleep(i);
        int j = 0;
        continue;
        localD.T();
        Thread.currentThread();
        Thread.sleep(i);
        j++;
        if (j >= 20)
        {
          localD.H();
          Thread.currentThread();
          Thread.sleep(i);
          localD.U();
          Thread.currentThread();
          Thread.sleep(i);
          localD.U();
          Thread.currentThread();
          Thread.sleep(i);
          localD.U();
          Thread.currentThread();
          Thread.sleep(i);
          localD.B();
          Thread.currentThread();
          Thread.sleep(i);
          localD.B();
          Thread.currentThread();
          Thread.sleep(i);
          localD.B();
          Thread.currentThread();
          Thread.sleep(i);
          localD.B();
          Thread.currentThread();
          Thread.sleep(i);
          localD.M();
          Thread.currentThread();
          Thread.sleep(i);
          localD.G();
          Thread.currentThread();
          Thread.sleep(i);
          localD.R();
          Thread.currentThread();
          Thread.sleep(i);
          localD.U();
          Thread.currentThread();
          Thread.sleep(i);
          localD.K();
          Thread.currentThread();
          Thread.sleep(i);
          if (Math.random() < 0.2D)
            localD.F();
          localD.S();
          Thread.currentThread();
          Thread.sleep(1000L);
        }
      }
      catch (InterruptedException localInterruptedException)
      {
        localInterruptedException.printStackTrace();
      }
  }

  public static void A(String[] paramArrayOfString)
  {
    I();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.D
 * JD-Core Version:    0.6.2
 */