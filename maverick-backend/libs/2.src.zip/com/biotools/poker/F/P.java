package com.biotools.poker.F;

import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;

public class P extends JPanel
{
  double C = 0.45D;
  double F = 0.35D;
  double B = 0.75D;
  double A = 0.2D;
  double E = 0.25D;
  int G = 1;
  int D = 1;

  public P(Preferences paramPreferences, int paramInt)
  {
    A(paramPreferences, paramInt);
    JSlider localJSlider1 = new JSlider(0, 100, (int)(100.0D * this.C));
    localJSlider1.setPaintTicks(true);
    localJSlider1.setMajorTickSpacing(10);
    localJSlider1.setMinorTickSpacing(5);
    localJSlider1.setBorder(BorderFactory.createTitledBorder(E.D("PreFlopStratGraph.Tightness")));
    localJSlider1.addChangeListener(new P.1(this, localJSlider1, paramPreferences, paramInt));
    JSlider localJSlider2 = new JSlider(0, 100, (int)(100.0D * this.F));
    localJSlider2.setPaintTicks(true);
    localJSlider2.setMajorTickSpacing(10);
    localJSlider2.setMinorTickSpacing(5);
    localJSlider2.setBorder(BorderFactory.createTitledBorder(E.D("PreFlopStratGraph.Aggression")));
    localJSlider2.addChangeListener(new P.2(this, localJSlider2, paramPreferences, paramInt));
    JSlider localJSlider3 = new JSlider(0, 100, (int)(100.0D * this.B));
    localJSlider3.setPaintTicks(true);
    localJSlider3.setMajorTickSpacing(10);
    localJSlider3.setMinorTickSpacing(5);
    localJSlider3.setBorder(BorderFactory.createTitledBorder(E.D("PreFlopStratGraph.Deception")));
    localJSlider3.addChangeListener(new P.3(this, localJSlider3, paramPreferences, paramInt));
    JSlider localJSlider4 = new JSlider(0, 100, (int)(100.0D * this.A));
    localJSlider4.setPaintTicks(true);
    localJSlider4.setMajorTickSpacing(10);
    localJSlider4.setMinorTickSpacing(5);
    localJSlider4.setBorder(BorderFactory.createTitledBorder(E.D("PreFlopStratGraph.SensitivityPosition")));
    localJSlider4.addChangeListener(new P.4(this, localJSlider4, paramPreferences, paramInt));
    JSlider localJSlider5 = new JSlider(0, 100, (int)(100.0D * this.E));
    localJSlider5.setPaintTicks(true);
    localJSlider5.setMajorTickSpacing(10);
    localJSlider5.setMinorTickSpacing(5);
    localJSlider5.setBorder(BorderFactory.createTitledBorder(E.D("PreFlopStratGraph.SensitivityBetting")));
    localJSlider5.addChangeListener(new P.5(this, localJSlider5, paramPreferences, paramInt));
    P._A local_A = new P._A(this);
    local_A.setPreferredSize(new Dimension(300, 100));
    JPanel localJPanel = new JPanel(new GridLayout(3, 2));
    localJPanel.add(localJSlider1);
    localJPanel.add(localJSlider2);
    localJPanel.add(localJSlider3);
    localJPanel.add(localJSlider4);
    localJPanel.add(localJSlider5);
    localJPanel.add(Box.createRigidArea(new Dimension(4, 4)));
    setLayout(new BoxLayout(this, 1));
    add(local_A);
    add(localJPanel);
  }

  public void D()
  {
    JFrame localJFrame = new JFrame(E.D("PreFlopStratGraph.PF"));
    localJFrame.setDefaultCloseOperation(3);
    localJFrame.getContentPane().add(this);
    localJFrame.pack();
    localJFrame.setVisible(true);
  }

  private void A(Preferences paramPreferences, int paramInt)
  {
    this.C = paramPreferences.getDoublePreference("TIGHTNESS" + paramInt, this.C);
    this.F = paramPreferences.getDoublePreference("AGGRESSION" + paramInt, this.F);
    this.B = paramPreferences.getDoublePreference("DECEPTION" + paramInt, this.B);
    this.A = paramPreferences.getDoublePreference("POSITION" + paramInt, this.A);
    this.E = paramPreferences.getDoublePreference("COSTSENS" + paramInt, this.E);
  }

  public void B(double paramDouble)
  {
    this.B = paramDouble;
    repaint();
  }

  public double A(double paramDouble1, double paramDouble2)
  {
    try
    {
      return 1.0D / (1.0D + Math.exp(-paramDouble2 * paramDouble1));
    }
    catch (ArithmeticException localArithmeticException)
    {
    }
    return 1.0D;
  }

  public double C()
  {
    double d = Math.pow(this.C, 1.0D + this.A * this.G + this.E * (this.D - 1));
    return d;
  }

  public double E()
  {
    return this.F;
  }

  public double A()
  {
    double d = 1.0D - C();
    return d;
  }

  public double F()
  {
    double d = 1.0D - C() * E();
    if (this.D == 0)
      d = (A() + d) * 0.5D;
    return d;
  }

  public double B()
  {
    return Math.pow(this.B, 1.0D + 2.0D * this.A * this.G + this.E * this.D);
  }

  public double C(double paramDouble)
  {
    double d1 = F();
    double d2 = A();
    double d3 = B();
    double d4 = 1.0D - A(d1 - paramDouble, 10.0D + (1.0D - d3) * 200.0D);
    d4 += 0.5D * d3 * d3 * A(this.C / (4.0D / this.F) - paramDouble, 20.0D);
    return d4;
  }

  public double A(double paramDouble)
  {
    double d1 = F();
    double d2 = A();
    double d3 = B();
    if (paramDouble > d1)
      return 1.0D;
    double d4 = 1.0D - A(d2 - paramDouble, 5.0D + (1.0D - d3) * 100.0D);
    d4 += 0.5D * d3 * d3 * A(this.C / 4.0D - paramDouble, 20.0D);
    return d4;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.P
 * JD-Core Version:    0.6.2
 */