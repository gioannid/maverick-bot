package com.biotools.poker.F;

import com.biotools.meerkat.Card;

public class T extends U
{
  private static final String J = "data/cards-med/";

  public String I()
  {
    return "data/cards-med/";
  }

  public T(Card paramCard)
  {
    super(paramCard);
  }

  public T()
  {
  }

  public int getWidth()
  {
    return 40;
  }

  public int getHeight()
  {
    return 56;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.T
 * JD-Core Version:    0.6.2
 */