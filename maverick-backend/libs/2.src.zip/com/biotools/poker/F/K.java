package com.biotools.poker.F;

import com.biotools.meerkat.Card;

public class K extends U
{
  private static final String K = "data/cards-small/";

  public String I()
  {
    return "data/cards-small/";
  }

  public K(Card paramCard)
  {
    super(paramCard);
  }

  public K()
  {
  }

  public int getWidth()
  {
    return 30;
  }

  public int getHeight()
  {
    return 42;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.K
 * JD-Core Version:    0.6.2
 */