package com.biotools.poker.F;

import com.biotools.meerkat.Card;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JComponent;

public class R extends JComponent
{
  private static final Color B = new Color(50, 150, 50);
  private Card A;
  private static final char[] C = { '♠', '♥', '♦', '♣' };

  public R()
  {
  }

  public R(Card paramCard)
  {
    this();
    A(paramCard);
  }

  public void paint(Graphics paramGraphics)
  {
    Graphics2D localGraphics2D = (Graphics2D)paramGraphics;
    localGraphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    paramGraphics.setFont(new Font("Times", 0, 15));
    FontMetrics localFontMetrics = paramGraphics.getFontMetrics();
    paramGraphics.setColor(Color.BLACK);
    String str = Card.getRankChar(this.A.getRank());
    if (!this.A.valid())
      str = "?";
    int i = localFontMetrics.stringWidth(str);
    int j = localFontMetrics.stringWidth("Q");
    int k = getHeight() - 2;
    paramGraphics.drawString(str, (j - i) / 2, k);
    paramGraphics.setColor(A());
    paramGraphics.setFont(new Font("Sans", 0, 13));
    if (!this.A.valid())
      paramGraphics.drawString("?", j, k);
    else
      paramGraphics.drawString(C[this.A.getSuit()], j - 1, k);
    super.paint(paramGraphics);
  }

  public void A(Card paramCard)
  {
    this.A = paramCard;
    repaint();
  }

  private Color A()
  {
    boolean bool = U.E();
    if (this.A.getSuit() == 1)
      return Color.RED;
    if (this.A.getSuit() == 2)
      return bool ? Color.BLUE : Color.RED;
    if (this.A.getSuit() == 3)
      return bool ? B : Color.BLACK;
    return Color.BLACK;
  }

  public Card B()
  {
    return this.A;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.R
 * JD-Core Version:    0.6.2
 */