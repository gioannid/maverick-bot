package com.biotools.poker.F;

import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.poker.A;
import com.biotools.poker.E;
import com.biotools.poker.O.G;
import com.biotools.poker.O.Z;
import com.biotools.poker.PokerApp;
import com.biotools.poker.Q.D;
import com.biotools.poker.Q.F;
import com.biotools.poker.Q.K;
import java.awt.Point;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class S
{
  public static final int F = 100;
  public static final int U = 50;
  private volatile boolean V;
  private U E;
  private U R;
  private String I = "";
  private volatile double K = 0.0D;
  private String S;
  private volatile String L = null;
  private volatile String N = null;
  private boolean Z = false;
  private int A;
  private int a;
  private int _;
  private int P;
  private int O;
  private int C;
  private int B;
  private int J;
  private int H;
  private double[] G = new double[5];
  private A D;
  private U[] Y = new U[2];
  private long Q = System.currentTimeMillis();
  public com.biotools.poker.O.U W;
  public G T;
  public Z X;
  int M = -1;

  public void A(Element paramElement)
  {
    int i = 0;
    int j = 0;
    Element localElement1 = (Element)paramElement.getElementsByTagName("offset").item(0);
    i = Integer.parseInt(localElement1.getAttribute("x"));
    j = Integer.parseInt(localElement1.getAttribute("y"));
    Element localElement2 = (Element)paramElement.getElementsByTagName("box").item(0);
    this.a = Integer.parseInt(localElement2.getAttribute("x"));
    this._ = Integer.parseInt(localElement2.getAttribute("y"));
    Element localElement3 = (Element)paramElement.getElementsByTagName("cards").item(0);
    this.P = Integer.parseInt(localElement3.getAttribute("x"));
    this.O = Integer.parseInt(localElement3.getAttribute("y"));
    Element localElement4 = (Element)paramElement.getElementsByTagName("chips").item(0);
    this.C = Integer.parseInt(localElement4.getAttribute("x"));
    this.B = Integer.parseInt(localElement4.getAttribute("y"));
    Element localElement5 = (Element)paramElement.getElementsByTagName("button").item(0);
    this.J = Integer.parseInt(localElement5.getAttribute("x"));
    this.H = Integer.parseInt(localElement5.getAttribute("y"));
    NodeList localNodeList = paramElement.getElementsByTagName("forceCompact");
    if (localNodeList.getLength() > 0)
    {
      this.E.J();
      this.R.J();
    }
    if (!E.Ð())
    {
      i -= 10;
      this.a -= 10;
    }
    this.P += i;
    this.O += j;
    this.C += i;
    this.B += j;
    this.J += i;
    this.H += j;
    d();
  }

  public S(A paramA, int paramInt)
  {
    this.D = paramA;
    this.A = paramInt;
    this.E = new U();
    this.R = new U();
  }

  public void Q()
  {
    if (W() != null)
    {
      A(null, null);
      B(false);
      this.L = null;
    }
    Z();
  }

  public boolean a()
  {
    return this.K > 0.0D;
  }

  public double c()
  {
    return this.K;
  }

  public void B()
  {
    this.K = 0.0D;
  }

  public void A(Card paramCard1, Card paramCard2)
  {
    if (paramCard1 == null)
      this.E.G();
    else
      this.E.A(paramCard1);
    if (paramCard2 == null)
      this.R.G();
    else
      this.R.A(paramCard2);
  }

  public void B(boolean paramBoolean)
  {
    this.E.setVisible(paramBoolean);
    this.R.setVisible(paramBoolean);
  }

  public void A(boolean paramBoolean1, boolean paramBoolean2)
  {
    if (paramBoolean2)
      this.E.setVisible(paramBoolean1);
    else
      this.R.setVisible(paramBoolean1);
  }

  public boolean b()
  {
    return (this.E.N() != null) && (this.R.N() != null);
  }

  public boolean U()
  {
    return (this.E.C()) && (this.R.C()) && (this.E.isVisible()) && (this.R.isVisible());
  }

  public void Z()
  {
    this.K = 0.0D;
    this.S = null;
    this.Z = true;
    this.N = null;
    this.I = "";
    PlayerInfo localPlayerInfo = I();
    if ((localPlayerInfo != null) && (!localPlayerInfo.inGame()) && (!localPlayerInfo.isAllIn()) && (!localPlayerInfo.isSittingOut()) && (PokerApp.Ȅ().Ǽ()))
      this.I = E.D("Seat.Waiting");
    A(false);
    this.T.B(false);
    if (G.r)
      this.T.a();
    C();
    if (this.E != null)
      this.E.A(false);
    if (this.R != null)
      this.R.A(false);
  }

  public void B(String paramString)
  {
    this.S = paramString;
  }

  public void d()
  {
    this.G[0] = -1.0D;
  }

  public double[] V()
  {
    if (this.K <= 0.0D)
      return null;
    if (this.G[0] >= 0.0D)
      return this.G;
    this.G[0] = this.K;
    this.G[3] = this.C;
    this.G[4] = this.B;
    D localD = this.D.ǆ();
    if (localD.Z() == null)
    {
      double d1 = localD.c();
      double d2 = this.K;
      for (int i = 0; (d2 > 0.0D) && (i < 4); i++)
        d2 -= d1;
      if ((d2 == 0.0D) && (i > 0) && (i <= 4))
      {
        this.G[0] = d2;
        this.G[1] = d1;
        this.G[2] = i;
      }
    }
    return this.G;
  }

  public synchronized void A(double paramDouble)
  {
    this.K = paramDouble;
    d();
  }

  public U[] J()
  {
    U localU1 = this.E;
    U localU2 = this.R;
    localU1.A(false);
    localU2.A(false);
    if (this.D.ǀ() != null)
    {
      if ((this.E.N() != null) && (this.R.N() != null))
      {
        if ((this.D.A(this.E.N())) && (!this.D.A(this.R.N())))
        {
          localU1 = this.R;
          localU2 = this.E;
        }
        if (!this.D.A(localU1.N()))
          localU1.A(true);
        if (!this.D.A(localU2.N()))
          localU2.A(true);
      }
    }
    else if ((!localU1.H()) && (localU2.H()))
    {
      localU1 = this.R;
      localU2 = this.E;
    }
    this.Y[0] = localU1;
    this.Y[1] = localU2;
    return this.Y;
  }

  public String[] G()
  {
    String[] arrayOfString = { "??", "??" };
    Hand localHand = this.D.Ǡ().N(this.A);
    if (localHand != null)
    {
      Card localCard = localHand.getCard(1);
      if (localCard.valid())
        arrayOfString[0] = localCard.toTranslatedString();
      localCard = localHand.getCard(2);
      if (localCard.valid())
        arrayOfString[1] = localCard.toTranslatedString();
    }
    return arrayOfString;
  }

  public String T()
  {
    PlayerInfo localPlayerInfo = I();
    if (localPlayerInfo != null)
    {
      double d = localPlayerInfo.getBankRoll();
      if (d == 0.0D)
        return "";
      return Action.formatCash(d);
    }
    return null;
  }

  public void A(boolean paramBoolean)
  {
    this.V = paramBoolean;
    if (paramBoolean)
    {
      this.I = "";
      this.T.B(true);
    }
  }

  public void A(Action paramAction)
  {
    PlayerInfo localPlayerInfo = I();
    if (localPlayerInfo != null)
      if (paramAction != null)
      {
        if (!paramAction.isFoldOrMuck())
        {
          if (!paramAction.isPostDeadBlind())
          {
            double d = paramAction.getToCall() + paramAction.getAmount();
            A(localPlayerInfo.getAmountInPotThisRound() + d);
            if (paramAction.isAnte())
              paramAction = paramAction;
          }
        }
        else
        {
          this.Z = false;
          this.W.w();
        }
        this.I = paramAction.toString();
      }
      else
      {
        if ((!localPlayerInfo.isSittingOut()) && (localPlayerInfo.inGame()))
          this.I = "";
        A(0.0D);
      }
  }

  public boolean B(int paramInt1, int paramInt2)
  {
    if (G.r)
      return this.T.A(paramInt1, paramInt2);
    return (paramInt1 > this.a) && (paramInt2 > this._) && (paramInt1 < this.a + 100) && (paramInt2 < this._ + 50);
  }

  public boolean A(int paramInt1, int paramInt2)
  {
    PlayerInfo localPlayerInfo = I();
    if ((localPlayerInfo == null) || (!this.E.isVisible()))
      return false;
    if (localPlayerInfo.isActive())
    {
      if ((paramInt1 > this.P) && (paramInt2 > this.O) && (paramInt1 < this.P + this.E.getWidth()) && (paramInt2 < this.O + this.E.getHeight()))
        return true;
      int i = this.E.getWidth() / 3;
      int j = this.E.getHeight() / 6;
      if ((paramInt1 > this.P + i) && (paramInt2 > this.O + j) && (paramInt1 < this.P + i + this.E.getWidth()) && (paramInt2 < this.O + j + this.E.getHeight()))
        return true;
    }
    return false;
  }

  public void L()
  {
    if (this.E != null)
      this.E.F();
    if (this.R != null)
      this.R.F();
  }

  public boolean N()
  {
    return I() != null;
  }

  public boolean F()
  {
    return this.V;
  }

  public String S()
  {
    return this.D.Ǡ().I(this.A);
  }

  private PlayerInfo I()
  {
    return this.D.Z(this.A);
  }

  public String W()
  {
    PlayerInfo localPlayerInfo = I();
    if (localPlayerInfo != null)
      return localPlayerInfo.getName();
    return null;
  }

  public int X()
  {
    return this.M;
  }

  public String A()
  {
    if (this.M < 0)
      return "";
    switch (this.M)
    {
    case 1:
      return E.D("Seat.1st");
    case 2:
      return E.D("Seat.2nd");
    case 3:
      return E.D("Seat.3rd");
    case 4:
      return E.D("Seat.4th");
    case 5:
      return E.D("Seat.5th");
    case 6:
      return E.D("Seat.6th");
    case 7:
      return E.D("Seat.7th");
    case 8:
      return E.D("Seat.8th");
    case 9:
      return E.D("Seat.9th");
    case 10:
      return E.D("Seat.10th");
    }
    return "";
  }

  public void C()
  {
    this.M = -1;
    PlayerInfo localPlayerInfo = I();
    if (localPlayerInfo != null)
    {
      double d = localPlayerInfo.getBankRoll();
      int i = 1;
      for (int j = 0; j < 10; j++)
      {
        F localF = this.D.Z(j);
        if ((localF != null) && (localF.getBankRoll() > d))
          i++;
      }
      this.M = i;
    }
  }

  public Point E()
  {
    return new Point(this.P, this.O);
  }

  public Point _()
  {
    return new Point(this.C, this.B);
  }

  public Point K()
  {
    return new Point(this.a, this._);
  }

  public Point Y()
  {
    return new Point(this.J, this.H);
  }

  public String P()
  {
    PlayerInfo localPlayerInfo = I();
    if ((localPlayerInfo != null) && (localPlayerInfo.isSittingOut()))
      return E.D("Seat.SittingOut");
    if ((this.I != null) && (this.I.length() < 2) && (!M()))
    {
      int i = O();
      if (i > 0)
      {
        Object[] arrayOfObject = { Integer.toString(i) };
        return E.A("Seat.TimeLeftSecondsPattern", arrayOfObject);
      }
    }
    return this.I;
  }

  private int O()
  {
    long l = this.Q - System.currentTimeMillis();
    if (l > 0L)
      return (int)Math.round(l / 1000.0D);
    return 0;
  }

  public boolean R()
  {
    return I().getBankRoll() > 0.0D;
  }

  public boolean M()
  {
    return !this.Z;
  }

  public void A(String paramString)
  {
    this.L = paramString;
  }

  public String H()
  {
    return this.L;
  }

  public void C(String paramString)
  {
    this.N = paramString;
  }

  public String D()
  {
    return this.N;
  }

  public void A(long paramLong)
  {
    this.Q = paramLong;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.F.S
 * JD-Core Version:    0.6.2
 */