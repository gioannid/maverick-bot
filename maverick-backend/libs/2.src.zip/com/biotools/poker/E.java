package com.biotools.poker;

import C.A.X;
import com.biotools.A.I;
import com.biotools.A.d;
import com.biotools.B.L;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.Messages;
import com.biotools.poker.P.N;
import com.biotools.poker.Q.A;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Vector;
import java.util.prefs.BackingStoreException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public final class E
{
  private static boolean Á;
  private static boolean l;
  public static final int ¤ = 197;
  public static final String Ò;
  public static final String è = "2";
  public static final String Ü = "PAPro2";
  public static final String Ë = "Poker Academy Pro 2";
  public static final String å = "Poker Academy 2";
  public static final String Q = "Poker Academy 2";
  public static final int N = 0;
  public static final int B = 1;
  public static final int Y = 2;
  public static final int d = 3;
  public static final int ā = 4;
  public static final int ü = 5;
  public static final String £ = "ubdekp";
  private static boolean ò;
  public static int Ï;
  public static int P;
  public static int f;
  public static int r;
  public static final String G = "DEMO_KEY";
  public static String ø;
  private static final String ä = "meerkat";
  private static final String Ì = "com.biotools.poker.ApplicationResources";
  private static final String ý = "meerkat_global";
  private static int Ô;
  public static final Image ¢;
  private static JFrame n;
  private static com.biotools.meerkat.util.Preferences Ç;
  private static com.biotools.meerkat.util.Preferences Ö;
  public static final String g = "IDENTITY2";
  public static final String à = "XIDENTITY2";
  public static final String ó = "DEFAULT_TABLE";
  public static final String ª = "ALL_FACE_UP";
  public static final String é = "FACE_DOWN";
  public static final String L = "PEEKING";
  public static final String y = "PROFILE";
  public static final String i = "SOUND_EFFECTS";
  public static final String Z = "AUTO_DEAL";
  public static final String W = "ADVICE_ON";
  public static final String O = "ADVICE";
  public static final String C = "LIMIT_ADVISOR";
  public static final String v = "NO_LIMIT_ADVISOR";
  public static final String þ = "ALL_IN_RULES";
  public static final String q = "FREEZE_BUTTON";
  public static final String Þ = "INSTANT_FOLDS";
  public static final String Î = "AUTO_MUCK";
  public static final String Ñ = "USE_DEAL_ANIMATION";
  public static final String ú = "USE_FOLD_ANIMATION";
  public static final String Â = "USE_CHIP_ANIMATION";
  public static final String T = "USE_BOARD_SWIRL_ANIMATION";
  public static final String ¥ = "USE_BOARD_FLIP_ANIMATION";
  public static final String w = "USE_BOARD_FADE_ANIMATION";
  public static final String º = "USE_PLAYER_CHAT_ANIMATION";
  public static final String Ê = "USE_TO_ACT_ANIMATION";
  public static final String Í = "USE_SOUND_TABLE";
  public static final String Ð = "USE_SOUND_BEEP";
  public static final String ù = "USE_SOUND_OTHER";
  public static final String V = "BANKROLL_INIT";
  public static final String ß = "LIMIT_LEVEL";
  public static final String Õ = "LIMIT_INC";
  public static final String ë = "TOURNEY_MODE";
  public static final String j = "BIG_BET_SIZE";
  public static final String E = "SMALL_BET_SIZE";
  public static final String s = "SMALL_BLIND_SIZE";
  public static final String Ú = "FOUR_COLOR";
  public static final String D = "SHOW_PROFILE_AT_STARTUP";
  public static final String K = "SHOW_TOURNEY_STANDINGS_ON_BUST";
  public static final String Ã = "SHOW_TOURNEY_STANDINGS_AT_START";
  public static final String t = "SHOW_CHIP_TEXT";
  public static final String ï = "AUTO_UPDATE";
  public static final String ÿ = "LAST_UPDATE_CHECK";
  public static final String À = "HAND_HISTORY_SIZE";
  public static final String ô = "LOG_HANDS";
  public static final String Û = "NO_CAP_HU";
  public static final String Æ = "HIDE_NAMES";
  public static final String Ý = "DTL_ID197";
  public static final String ã = "WINDOW_SIZE";
  public static final String A = "PLAYER_STATS_UNITS";
  public static final String ê = "TOURNEY_ID";
  public static final String b = "SERVER_GAME_ID";
  public static final String É = "RAKE";
  public static final String X = "AUTO_REBUY";
  public static final String Ù = "MIN_HANDS_FILTER";
  public static final String Ä = "LAST_ONLINE_PROFILE";
  public static final String U = "TRANSCRIPT_DISPLAY_GAME_EVENTS";
  public static final String k = "TRANSCRIPT_DISPLAY_GAME_ACTIONS";
  public static final String H = "TRANSCRIPT_DISPLAY_GAME_SUMMARY";
  public static final String Ā = "TRANSCRIPT_DISPLAY_CHAT";
  public static final String ç = "HIST_SHOW_HANDS";
  public static final String ð = "SHOW_ADVANCE_ACTIONS";
  public static final String Å = "AFFILITATE";
  public static final String _ = "EMAIL";
  public static final String o = "BMODE";
  public static final String µ = "BORIGIN";
  public static final String î = "SIDEBAR_SESSION_STATE";
  public static final String z = "SIDEBAR_ACTIONS_STATE";
  public static final String Ó = "SIDEBAR_TOURNEY_STATE";
  public static final String æ = "SIDEBAR_HANDEVAL_STATE";
  public static final String F = "SIDEBAR_ADVISOR_STATE";
  public static final String h = "SIDEBAR_TRANSCRIPT_STATE";
  public static final String Ă = "SOUND_ENGINE";
  public static final String û = "COLOR_SCHEME";
  public static final int õ = 0;
  public static final int e = 1;
  public static final int M = 2;
  public static final int J = 3;
  public static final int c = 1000;
  public static final String u = "<font face=Arial size=3>";
  public static final String I = "<font face=Arial size=4>";
  public static final String S = "USE_SUIT_SYMBOLS";
  private static final int ñ = -1;
  private static final int ö = 0;
  private static final int â = 1;
  public static boolean m = false;
  private static int x = -1;
  public static A í;
  private static ResourceBundle È;
  private static ResourceBundle R;
  private static ResourceBundle Ø;
  private static ResourceBundle á;
  private static Locale a;
  private static Locale ì;
  private static ClassLoader p = new com.biotools.A.H(new File("data"));

  static
  {
    Á = false;
    l = false;
    Ò = "2.5.7" + (l ? "b" : "");
    ò = false;
    Ï = 0;
    P = 0;
    f = 0;
    r = 1;
    ø = £().get("DEMO_KEY", "");
    Ô = 0;
    ¢ = Toolkit.getDefaultToolkit().getImage("data/pix/shield-32x32.png");
    HandEvaluator.setHandEval(new X());
  }

  public static final void Ï()
  {
    ò = true;
    £().put("DEMO_KEY", ø);
    N();
  }

  public static final void Æ()
  {
    Á = true;
  }

  public static boolean Ð()
  {
    return A(null);
  }

  public static boolean A(JFrame paramJFrame)
  {
    if (Ô == 0)
      Ô = B(paramJFrame) ? 1 : 2;
    return Ô == 1;
  }

  public static final boolean a()
  {
    if (x != -1)
      return x == 0;
    return false;
  }

  public static final void S()
  {
    x = 0;
  }

  public static final boolean J()
  {
    return l;
  }

  public static void C(JFrame paramJFrame)
  {
    n = paramJFrame;
  }

  public static JFrame É()
  {
    return n;
  }

  public static boolean y()
  {
    return System.getProperty("debug.mode") != null;
  }

  public static final String Ò()
  {
    String str = D("Meerkat.ProductNamePro");
    if (Ú())
      str = D("Meerkat.ProductNameLight");
    return str;
  }

  public static final String Õ()
  {
    String str = D("Meerkat.ProductNameProAbrv");
    if (Ú())
      str = D("Meerkat.ProductNameLightAbrv");
    return str;
  }

  public static final boolean p()
  {
    return ò;
  }

  public static final boolean Â()
  {
    return (ò) && (Ï == 3);
  }

  public static final boolean D()
  {
    return (ò) && (Ï == 2);
  }

  public static final boolean Ú()
  {
    return Á;
  }

  public static com.biotools.meerkat.util.Preferences £()
  {
    if (Ç == null)
    {
      Ç = new com.biotools.meerkat.util.Preferences(¢());
      if (!¢().exists())
        B(Ç);
      com.biotools.poker.Q.D.E = Ç;
    }
    return Ç;
  }

  public static void A(com.biotools.meerkat.util.Preferences paramPreferences)
  {
    B(paramPreferences);
    paramPreferences.saveSortedPreferences();
  }

  private static void B(com.biotools.meerkat.util.Preferences paramPreferences)
  {
    try
    {
      java.util.prefs.Preferences localPreferences = null;
      localPreferences = java.util.prefs.Preferences.userNodeForPackage(E.class);
      String[] arrayOfString = localPreferences.keys();
      for (int i1 = 0; i1 < arrayOfString.length; i1++)
        paramPreferences.put(arrayOfString[i1], localPreferences.get(arrayOfString[i1], null));
      paramPreferences.savePreferences();
    }
    catch (BackingStoreException localBackingStoreException)
    {
      localBackingStoreException.printStackTrace();
    }
  }

  private static void b()
  {
    try
    {
      java.util.prefs.Preferences localPreferences = java.util.prefs.Preferences.systemNodeForPackage(E.class);
      String[] arrayOfString = localPreferences.keys();
      for (int i1 = 0; i1 < arrayOfString.length; i1++)
        µ().put(arrayOfString[i1], localPreferences.get(arrayOfString[i1], null));
      µ().savePreferences();
    }
    catch (BackingStoreException localBackingStoreException)
    {
      localBackingStoreException.printStackTrace();
    }
  }

  public static File ¢()
  {
    return new File(Y(), "user.prefs");
  }

  public static File U()
  {
    return new File(R(), "meerkat.prefs");
  }

  public static com.biotools.meerkat.util.Preferences µ()
  {
    if (Ö == null)
    {
      Ö = new com.biotools.meerkat.util.Preferences(U());
      if (!U().exists())
        b();
    }
    return Ö;
  }

  public static boolean Ø()
  {
    return £().getBoolean("ADVICE", true);
  }

  public static void Ù()
  {
    £().putBoolean("ADVICE", !Ø());
  }

  public static boolean _()
  {
    return £().getBoolean("AUTO_MUCK", true);
  }

  public static String Y()
  {
    String str1 = "pokilogs/";
    String str2 = "PokerAcademyPro2";
    if (Ú())
      str2 = "PokerAcademy2";
    if (J())
      str2 = str2 + "Beta";
    if (¤())
    {
      localObject = System.getProperty("user.home");
      str1 = localObject + "/Library/Preferences/" + str2 + "/";
    }
    else if (Å())
    {
      localObject = I();
      str1 = localObject + "/" + str2 + "/";
    }
    Object localObject = new File(str1);
    if (!((File)localObject).exists())
      ((File)localObject).mkdir();
    return str1;
  }

  public static File R()
  {
    File localFile = null;
    if (¤())
      localFile = new File("/Library/Preferences/");
    else if (Å())
    {
      if (o())
        localFile = new File(new File("/"), "WINDOWS/Application Data/");
      else
        localFile = new File(new File("/"), "Documents and Settings/All Users/Application Data/");
    }
    else
      localFile = new File("/");
    if (!localFile.exists())
    {
      localFile = null;
    }
    else
    {
      String str = "PokerAcademyPro2";
      if (Ú())
        str = "PokerAcademy2";
      localFile = new File(localFile, str);
      if (!localFile.exists())
        localFile.mkdir();
    }
    return localFile;
  }

  public static String n()
  {
    String str = Y() + "logs/";
    File localFile = new File(str);
    if (!localFile.exists())
      localFile.mkdir();
    return str;
  }

  public static String I()
  {
    String str1 = System.getProperty("user.home");
    String str2 = System.getProperty("os.name").toLowerCase();
    if (!str2.startsWith("windows"))
      return null;
    String str3 = str1 + "/Application Data";
    return str3;
  }

  public static String K()
  {
    return "data/";
  }

  public static File K(String paramString)
  {
    return A(paramString, false);
  }

  public static File A(String paramString, boolean paramBoolean)
  {
    Object localObject = new File("data");
    if (!paramBoolean)
    {
      localFile = new File("data_" + F().getLanguage());
      if (localFile.exists())
        localObject = localFile;
    }
    File localFile = new File((File)localObject, paramString);
    if (localFile.exists())
      return localFile;
    if (!paramBoolean)
      return A(paramString, true);
    return localFile.exists() ? localFile : null;
  }

  public static String C(String paramString)
    throws FileNotFoundException
  {
    return B(paramString, false);
  }

  public static String B(String paramString, boolean paramBoolean)
    throws FileNotFoundException
  {
    File localFile = A(paramString, paramBoolean);
    if (localFile == null)
      throw new FileNotFoundException(paramString);
    return localFile.getPath();
  }

  public static final boolean ¤()
  {
    return System.getProperty("os.name").equals("Mac OS X");
  }

  public static File Q()
  {
    return new File(n(), "tables");
  }

  public static File O()
  {
    return new File(n(), "players");
  }

  public static File Ì()
  {
    return K("bots");
  }

  public static String u()
  {
    return n() + "models/";
  }

  public static File V()
  {
    return A(new File(n(), "imports"));
  }

  public static File Û()
  {
    return A(new File(n(), "tourneys"));
  }

  public static File Z()
  {
    return A(new File(K(), "ringstructs"));
  }

  public static File x()
  {
    return A(new File(Û(), "unfinished"));
  }

  public static File d()
  {
    return A(new File(Û(), "tourneys"));
  }

  public static File T()
  {
    return A(new File(Û(), "tourneys"));
  }

  public static File Á()
  {
    if (m)
      return new File("tourneys");
    return A(new File(Û(), "finished"));
  }

  private static File A(File paramFile)
  {
    if (!paramFile.exists())
      paramFile.mkdirs();
    return paramFile;
  }

  public static String c()
  {
    return n() + "GAMES_V3.LOG";
  }

  public static final boolean Ô()
  {
    if (Â())
    {
      JOptionPane.showMessageDialog(null, D("Meerkat.DemoWarningFeatureUnavailable"));
      return true;
    }
    return false;
  }

  public static void q()
  {
    if (p())
      com.biotools.poker.B.H.D();
  }

  private static boolean o()
  {
    String str = System.getProperty("os.name");
    if (str.equalsIgnoreCase("Windows 95"))
      return true;
    if (str.equalsIgnoreCase("Windows 98"))
      return true;
    return str.equalsIgnoreCase("Windows Me");
  }

  public static final boolean Å()
  {
    String str = System.getProperty("os.name").toLowerCase();
    return str.startsWith("windows");
  }

  public static synchronized int L()
  {
    int i1 = £().getInt("TOURNEY_ID", 0) + 1;
    £().putInt("TOURNEY_ID", i1);
    return i1;
  }

  public static boolean h()
  {
    return £().getBoolean("HIDE_NAMES", false);
  }

  protected static void A(boolean paramBoolean)
  {
    £().putBoolean("HIDE_NAMES", paramBoolean);
  }

  public static void C(boolean paramBoolean)
  {
    £().putBoolean("ADVICE_ON", paramBoolean);
  }

  public static boolean Î()
  {
    return £().getBoolean("ADVICE_ON", true);
  }

  public static void B(boolean paramBoolean)
  {
    £().putBoolean("SHOW_ADVANCE_ACTIONS", paramBoolean);
  }

  public static boolean l()
  {
    return £().getBoolean("SHOW_ADVANCE_ACTIONS", true);
  }

  public static boolean B()
  {
    boolean bool = z();
    return £().getBoolean("USE_SUIT_SYMBOLS", !bool);
  }

  public static void D(boolean paramBoolean)
  {
    £().putBoolean("USE_SUIT_SYMBOLS", paramBoolean);
    Card.setUseSuitSymbols(paramBoolean);
  }

  public static void L(int paramInt)
  {
    £().putInt("FOLD_KEY", paramInt);
  }

  public static void B(int paramInt)
  {
    £().putInt("CALL_KEY", paramInt);
  }

  public static void F(int paramInt)
  {
    £().putInt("RAISE_KEY", paramInt);
  }

  public static void E(int paramInt)
  {
    £().putInt("DEAL_KEY", paramInt);
  }

  public static void K(int paramInt)
  {
    £().putInt("ZIP_KEY", paramInt);
  }

  public static void J(int paramInt)
  {
    £().putInt("BET_HALF_POT_KEY", paramInt);
  }

  public static void I(int paramInt)
  {
    £().putInt("BET_POT_KEY", paramInt);
  }

  public static void H(int paramInt)
  {
    £().putInt("BET_2POT_KEY", paramInt);
  }

  public static void A(int paramInt)
  {
    £().putInt("FLASH_KEY", paramInt);
  }

  public static void C(int paramInt)
  {
    £().putInt("JAM_KEY", paramInt);
  }

  public static void G(int paramInt)
  {
    £().putInt("SET_RAISE_KEY", paramInt);
  }

  public static void D(int paramInt)
  {
    £().putInt("CHAT_KEY", paramInt);
  }

  public static int À()
  {
    return £().getInt("FOLD_KEY", 70);
  }

  public static int G()
  {
    return £().getInt("CALL_KEY", 67);
  }

  public static int g()
  {
    return £().getInt("RAISE_KEY", 82);
  }

  public static int k()
  {
    return £().getInt("DEAL_KEY", 68);
  }

  public static int ª()
  {
    return £().getInt("ZIP_KEY", 90);
  }

  public static int E()
  {
    return £().getInt("FLASH_KEY", 47);
  }

  public static int Ñ()
  {
    return £().getInt("CHAT_KEY", 10);
  }

  public static int r()
  {
    return £().getInt("BET_HALF_POT_KEY", 72);
  }

  public static int È()
  {
    return £().getInt("BET_POT_KEY", 80);
  }

  public static int Ö()
  {
    return £().getInt("BET_2POT_KEY", 76);
  }

  public static int Ó()
  {
    return £().getInt("JAM_KEY", 74);
  }

  public static int P()
  {
    return £().getInt("SET_RAISE_KEY", 192);
  }

  public static String j()
  {
    return £().get("AFFILITATE", "");
  }

  public static void I(String paramString)
  {
    £().put("AFFILITATE", paramString);
  }

  public static boolean Ë()
  {
    return System.getProperty("affiliate.mode") != null;
  }

  public static int H()
  {
    return £().getInt("PLAYER_STATS_UNITS", 0);
  }

  public static File s()
  {
    return K("logs");
  }

  public static void A()
    throws IOException, FileNotFoundException
  {
    Ú();
    File localFile = new File(n());
    com.biotools.A.B.A(A("logs", true), localFile);
    com.biotools.A.B.A(A("logs", false), localFile);
  }

  public static boolean E(String paramString)
  {
    Enumeration localEnumeration = N.Ñ().elements();
    while (localEnumeration.hasMoreElements())
      if (paramString.equalsIgnoreCase((String)localEnumeration.nextElement()))
        return false;
    Iterator localIterator = com.biotools.poker.E.B.N().iterator();
    while (localIterator.hasNext())
    {
      com.biotools.poker.E.B localB = (com.biotools.poker.E.B)localIterator.next();
      if (paramString.equalsIgnoreCase(localB.J()))
        return false;
    }
    return true;
  }

  private static boolean B(JFrame paramJFrame)
  {
    Dimension localDimension = Toolkit.getDefaultToolkit().getScreenSize();
    int i1 = (localDimension.getWidth() >= 1024.0D) && (localDimension.getHeight() >= 768.0D) ? 0 : 1;
    String str = £().get("WINDOW_SIZE", "ASK_IF_SMALL");
    if (((i1 != 0) && (str.equals("ASK_IF_SMALL"))) || (str.equals("ASK_ALWAYS")))
    {
      Object[] arrayOfObject = { Ò() };
      int i2 = JOptionPane.showConfirmDialog(paramJFrame, A("Meerkat.ScreenResolutionDialogPattern", arrayOfObject), "Compact Mode Option", 0);
      return i2 == 0;
    }
    if (str.equals("ALWAYS_SMALL"))
      return true;
    return !str.equals("ALWAYS_BIG");
  }

  public static void H(String paramString)
  {
    d.C(paramString);
  }

  public static void J(String paramString)
  {
    d.F(paramString);
  }

  public static void A(A paramA)
  {
    í = paramA;
  }

  public static void A(String paramString, int paramInt)
  {
    d.B(paramString);
    if ((paramInt != 0) && (í != null))
      í.B(paramString, paramInt);
  }

  public static void A(String paramString1, int paramInt1, String paramString2, int paramInt2)
  {
    d.B(paramString1 + paramString2);
    if ((paramInt1 != 0) && (í != null))
      í.A(paramString1, paramInt1, paramString2, paramInt2);
  }

  public static String º()
  {
    if (Å())
    {
      if (o())
        return "command.com /e:4096 /c java\\bin\\java";
      return "java\\bin\\java";
    }
    return "java";
  }

  public static void A(Component paramComponent, String paramString)
  {
    try
    {
      com.biotools.B.E.A(paramString);
      return;
    }
    catch (IOException localIOException1)
    {
      d.A(localIOException1);
      try
      {
        if (o())
          Runtime.getRuntime().exec("command.com /e:4096 /c start \"" + paramString + "\"");
        else
          Runtime.getRuntime().exec("start \"" + paramString + "\"");
        return;
      }
      catch (IOException localIOException2)
      {
        d.A(localIOException2);
        Object[] arrayOfObject = { paramString };
        JOptionPane.showMessageDialog(paramComponent, A("Meerkat.LaunchURLErrorDialogPattern", arrayOfObject));
      }
    }
  }

  public static void Ã()
  {
    if (y())
    {
      H("DEBUG MODE");
      return;
    }
    try
    {
      System.setOut(new PrintStream(new BufferedOutputStream(new FileOutputStream(n() + "output.log"))));
      System.setErr(new PrintStream(new BufferedOutputStream(new FileOutputStream(n() + "error.log"))));
    }
    catch (Exception localException)
    {
      I.A("", localException);
    }
  }

  public static final boolean W()
  {
    return false;
  }

  public static final boolean X()
  {
    return false;
  }

  public static String w()
  {
    if (Ú())
      return "Satan!Klaws";
    return "Veruca Salt";
  }

  public static final String C()
  {
    if (Ú())
      return p() ? "PA2D" : "PA2";
    return p() ? "PR2D" : "PAP2";
  }

  public static final String f()
  {
    if (Ú())
      return "PA2";
    return "PAP2";
  }

  public static void G(String paramString)
  {
    p = new com.biotools.A.H(new File(paramString));
  }

  private static final ResourceBundle M()
  {
    if (È == null)
      try
      {
        È = ResourceBundle.getBundle("meerkat", F(), p);
      }
      catch (MissingResourceException localMissingResourceException)
      {
        d.A("Cannot find bundle: meerkat", localMissingResourceException);
        È = Ê();
      }
    return È;
  }

  private static final ResourceBundle Ê()
  {
    if (R == null)
      try
      {
        R = ResourceBundle.getBundle("meerkat", Í(), p);
      }
      catch (MissingResourceException localMissingResourceException)
      {
        d.A("Cannot find bundle: meerkat", localMissingResourceException);
      }
    return R;
  }

  public static final ResourceBundle i()
  {
    if (Ø == null)
      try
      {
        Ø = ResourceBundle.getBundle("com.biotools.poker.ApplicationResources", F(), E.class.getClassLoader());
      }
      catch (MissingResourceException localMissingResourceException)
      {
        d.A("Cannot find bundle: meerkat", localMissingResourceException);
        if (!F().getLanguage().equalsIgnoreCase("en"))
        {
          A(new Locale("en"));
          Ø = i();
        }
      }
    return Ø;
  }

  private static final ResourceBundle e()
  {
    if (á == null)
      try
      {
        á = ResourceBundle.getBundle("meerkat_global", F(), p);
      }
      catch (MissingResourceException localMissingResourceException)
      {
        d.A("Cannot find bundle: meerkat_global", localMissingResourceException);
        if (!F().getLanguage().equalsIgnoreCase("en"))
        {
          A(new Locale("en"));
          á = e();
        }
      }
    return á;
  }

  public static Locale F()
  {
    if (a == null)
      t();
    return a;
  }

  public static Locale Í()
  {
    if (ì == null)
      ì = new Locale("en");
    return ì;
  }

  public static void t()
  {
    com.biotools.meerkat.util.Preferences localPreferences = new com.biotools.meerkat.util.Preferences("data/default.prefs");
    A(new Locale(localPreferences.getPreference("LOCALE", "en")));
  }

  public static void A(Locale paramLocale)
  {
    a = paramLocale;
    È = null;
    á = null;
    Ø = null;
    Messages.setLoader(p);
    Messages.setLocale(paramLocale);
    £().setPreference("LOCALE", paramLocale.getLanguage());
    Locale.setDefault(paramLocale);
  }

  public static boolean v()
  {
    return F().getLanguage().equals("en");
  }

  public static boolean z()
  {
    return D("_Commands.Meerkat.EnglishSuitNames").equalsIgnoreCase("true");
  }

  public static String A(String paramString, Object[] paramArrayOfObject)
  {
    return A(false, paramString, paramArrayOfObject);
  }

  public static String A(boolean paramBoolean, String paramString, Object[] paramArrayOfObject)
  {
    MessageFormat localMessageFormat = new MessageFormat(A(paramBoolean, paramString), paramBoolean ? Í() : F());
    return localMessageFormat.format(paramArrayOfObject);
  }

  public static String D(String paramString)
  {
    return A(false, paramString);
  }

  public static String A(boolean paramBoolean, String paramString)
  {
    String str;
    try
    {
      if (paramBoolean)
        str = Ê().getString(paramString.trim());
      else
        str = M().getString(paramString.trim());
    }
    catch (Exception localException1)
    {
      if (paramBoolean)
        try
        {
          str = e().getString(paramString.trim());
        }
        catch (Exception localException2)
        {
          if (!$assertionsDisabled)
            throw new AssertionError("Resource Bundle not found for " + paramString);
          str = "*" + paramString + "*";
        }
      else
        str = A(true, paramString);
    }
    return str;
  }

  public static void N()
  {
    try
    {
      £().savePreferences();
      µ().savePreferences();
    }
    catch (Exception localException)
    {
    }
  }

  public static String m()
  {
    String str1 = "PokerAcademyDemo";
    if (Ë())
      str1 = "PokerAcademyDemoCD";
    String str2 = "http://www.poker-academy.com/refer.php?referID=" + str1 + "&redirURL=order.php";
    return str2;
  }

  public static void A(String paramString, final JFrame paramJFrame)
  {
    paramJFrame.pack();
    int i1 = £().getInt(paramString + "_X", -1);
    int i2 = £().getInt(paramString + "_Y", -1);
    if ((i1 < 0) || (i2 < 0))
      L.B(paramJFrame);
    else
      paramJFrame.setLocation(i1, i2);
    paramJFrame.addComponentListener(new ComponentAdapter()
    {
      private final JFrame val$frame;

      public void componentMoved(ComponentEvent paramAnonymousComponentEvent)
      {
        E.£().setPreference(E.this + "_X", paramJFrame.getLocation().x);
        E.£().setPreference(E.this + "_Y", paramJFrame.getLocation().y);
      }
    });
  }

  public static String Ç()
  {
    String str = µ().get("BMODE", "--");
    if (!str.equals("--"))
      return str;
    com.biotools.meerkat.util.Preferences localPreferences = new com.biotools.meerkat.util.Preferences("data/default.prefs");
    str = localPreferences.getPreference("BMODE", "DEMO");
    B(str);
    return str;
  }

  public static void B(String paramString)
  {
    µ().put("BMODE", paramString);
  }

  public static String ¥()
  {
    String str = µ().get("BORIGIN", "--");
    if (!str.equals("--"))
      return str;
    com.biotools.meerkat.util.Preferences localPreferences = new com.biotools.meerkat.util.Preferences("data/default.prefs");
    str = localPreferences.getPreference("BORIGIN", "PA");
    A(str);
    return str;
  }

  public static void A(String paramString)
  {
    µ().put("BORIGIN", paramString);
  }

  public static String Ä()
  {
    return µ().get("EMAIL", "");
  }

  public static void F(String paramString)
  {
    µ().put("EMAIL", paramString);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.E
 * JD-Core Version:    0.6.2
 */