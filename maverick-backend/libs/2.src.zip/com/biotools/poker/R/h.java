package com.biotools.poker.R;

import com.biotools.B.J;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class h extends JPanel
  implements N
{
  private R ť;
  private JPanel ũ;
  private JLabel Ŧ = new JLabel("<html>&nbsp;</html>");
  private I Ť;
  private T Ũ;
  private HashSet ŧ = new HashSet();

  public h(R paramR)
  {
    this.ť = paramR;
    this.ť.Ġ().B(this);
    this.Ť = new I(paramR);
    this.Ť.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("DataSummary.Sites")), BorderFactory.createEmptyBorder(8, 8, 8, 8)));
    JPanel localJPanel1 = new JPanel(new BorderLayout(2, 2));
    localJPanel1.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("DataSummary.Totals")), BorderFactory.createEmptyBorder(4, 4, 4, 4)));
    localJPanel1.add(this.Ŧ, "North");
    localJPanel1.add(ō(), "South");
    JPanel localJPanel2 = new JPanel(new BorderLayout(2, 6));
    localJPanel2.add(localJPanel1, "West");
    localJPanel2.add(this.Ť, "Center");
    this.Ũ = new T(paramR);
    setLayout(new BorderLayout(8, 8));
    setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    add(localJPanel2, "North");
    add(this.Ũ, "Center");
    ŋ();
  }

  private JPanel ō()
  {
    if (this.ũ == null)
    {
      this.ũ = new JPanel();
      this.ũ.setLayout(new BoxLayout(this.ũ, 0));
      J localJ1 = new J("export.png", com.biotools.poker.E.D("DataSummary.ExportDescription"));
      localJ1.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          h.this.ť.Ĩ();
        }
      });
      J localJ2 = new J("import.png", com.biotools.poker.E.D("DataSummary.ImportDescription"));
      localJ2.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          h.this.ť.Ħ();
        }
      });
      this.ũ.add(localJ2);
      this.ũ.add(localJ1);
    }
    return this.ũ;
  }

  public void E(com.biotools.poker.G.R paramR)
  {
    this.Ť.B(paramR);
    ŋ();
  }

  public void Ō()
  {
    this.ŧ.clear();
    Ŋ();
    V localV = this.ť.Ġ();
    for (int i = 0; i < localV.size(); i++)
      L(localV.D(i));
  }

  public void L(E paramE)
  {
    for (int i = 0; i < 10; i++)
      if (paramE.G(i))
        this.ŧ.add(paramE.J(i));
  }

  private void ŋ()
  {
    final StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<html>");
    localStringBuffer.append("<table>");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><b>" + com.biotools.poker.E.D("DataSummary.HandsTitle") + "</b></td>");
    localStringBuffer.append("<td align=\"right\">" + this.ť.Ġ().size() + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><b>" + com.biotools.poker.E.D("DataSummary.SessionsTitle") + "</b></td>");
    localStringBuffer.append("<td align=\"right\">" + U.K().size() + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("<tr>");
    localStringBuffer.append("<td align=\"right\"><b>" + com.biotools.poker.E.D("DataSummary.PlayersTitle") + "</b></td>");
    localStringBuffer.append("<td align=\"right\">" + this.ŧ.size() + "</td>");
    localStringBuffer.append("</tr>");
    localStringBuffer.append("</table>");
    localStringBuffer.append("</html>");
    SwingUtilities.invokeLater(new Runnable()
    {
      private final StringBuffer val$sb;

      public void run()
      {
        h.this.Ŧ.setText(localStringBuffer.toString());
      }
    });
  }

  public void B()
  {
    com.biotools.poker.E.H("DataSummary.gameRecordListChanged()");
    Ō();
    ŋ();
    this.Ũ.ć();
  }

  public void A(E paramE)
  {
    L(paramE);
    ŋ();
    this.Ũ.ć();
  }

  public void A()
  {
    com.biotools.poker.E.H("DataSummary.gameFiltersChanged()");
    Ō();
    ŋ();
    this.Ũ.ć();
  }

  public void Ŋ()
  {
    if (this.Ũ != null)
      this.Ũ.D(U.K());
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.h
 * JD-Core Version:    0.6.2
 */