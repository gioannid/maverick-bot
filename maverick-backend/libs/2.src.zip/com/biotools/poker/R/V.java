package com.biotools.poker.R;

import com.biotools.A.d;
import com.biotools.B.P;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.Q.D;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Vector;

public class V extends ArrayList
{
  protected Vector Ê;
  protected boolean É = true;
  static int Ì = 0;
  int Ë = Ì++;

  public V()
  {
  }

  public V(V paramV)
  {
    A(paramV);
  }

  public void A(V paramV)
  {
    for (int i = 0; i < paramV.size(); i++)
      add(paramV.D(i));
    É();
  }

  public void D(E paramE)
  {
    add(paramE);
    B(paramE);
  }

  private Vector Å()
  {
    if (this.Ê == null)
      this.Ê = new Vector();
    return this.Ê;
  }

  protected void B(E paramE)
  {
    if (this.É)
      for (int i = 0; i < Å().size(); i++)
        ((N)Å().get(i)).A(paramE);
  }

  protected void É()
  {
    if (this.É)
      for (int i = 0; i < Å().size(); i++)
        ((N)Å().get(i)).B();
  }

  protected void Æ()
  {
    if (this.É)
      for (int i = 0; i < Å().size(); i++)
      {
        N localN = (N)Å().get(i);
        localN.A();
      }
  }

  public synchronized void B(N paramN)
  {
    Å().add(paramN);
  }

  public synchronized void C(N paramN)
  {
    Å().remove(paramN);
  }

  public boolean equals(Object paramObject)
  {
    return this == paramObject;
  }

  public Object remove(int paramInt)
  {
    Object localObject = super.remove(paramInt);
    É();
    return localObject;
  }

  public boolean remove(Object paramObject)
  {
    boolean bool = super.remove(paramObject);
    É();
    return bool;
  }

  public boolean removeAll(Collection paramCollection)
  {
    this.É = false;
    boolean bool = super.removeAll(paramCollection);
    this.É = true;
    É();
    return bool;
  }

  public Object A(int paramInt, boolean paramBoolean)
  {
    Object localObject = super.remove(paramInt);
    if (paramBoolean)
      É();
    return localObject;
  }

  public int A(File paramFile)
    throws IOException
  {
    int i = 0;
    int j = com.biotools.poker.E.£().getInt("TOURNEY_ID", 0);
    long l = D.R();
    if (paramFile.exists())
    {
      BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(paramFile), Charset.forName("ISO-8859-1")));
      for (String str = localBufferedReader.readLine(); str != null; str = localBufferedReader.readLine())
        try
        {
          E localE = new E(str);
          if (localE != null)
          {
            add(localE);
            if ((localE._() != null) && (localE._().J() != null))
            {
              if ((localE._().J().equals(U.Q)) && (localE.h() > l))
                l = localE.h();
              if (((localE._().J().equals(U.Q)) || (localE._().J().equals(U.K))) && (localE.X() > j))
                j = localE.X();
            }
          }
        }
        catch (Exception localException)
        {
          d.A(localException);
          i++;
        }
      localBufferedReader.close();
    }
    if (i > 0)
      com.biotools.poker.E.H("Could not read " + i + " game records.");
    if (j != com.biotools.poker.E.£().getInt("TOURNEY_ID", 0))
    {
      d.E("tourney id was increased from " + com.biotools.poker.E.£().getInt("TOURNEY_ID", 0) + " to " + j);
      com.biotools.poker.E.£().putInt("TOURNEY_ID", j);
    }
    if (l != D.R())
    {
      d.E("game id was increased from " + D.R() + " to " + l);
      D.B(l);
    }
    É();
    return i;
  }

  public void B(File paramFile)
  {
    V.1 local1 = new V.1(this, paramFile);
    P.A(null, com.biotools.poker.E.D("Stats.GameRecordList.LoadingGameRecords"), local1);
  }

  public E D(int paramInt)
  {
    return (E)get(paramInt);
  }

  public void Ä()
  {
    Ã();
    for (int i = 1; i < size(); i++)
    {
      E localE1 = D(i);
      E localE2 = D(i - 1);
      if (localE2.A(localE1))
      {
        remove(i);
        com.biotools.poker.E.H("REMOVING DUPLICATE:" + localE2);
      }
    }
    É();
  }

  public E C(E paramE)
  {
    for (int i = 0; i < size(); i++)
    {
      E localE = D(i);
      if (paramE.A(localE))
        return D(i);
    }
    return null;
  }

  public void Ã()
  {
    Collections.sort(this);
    É();
  }

  public void A(boolean paramBoolean)
  {
    Collections.sort(this);
    if (paramBoolean)
      É();
  }

  public E È()
  {
    if (size() == 0)
      return null;
    return D(size() - 1);
  }

  public void Ç()
  {
  }

  public void A(N paramN)
  {
    C(paramN);
    if (Å().size() == 0)
      Ç();
  }

  public void finalize()
  {
    Ì -= 1;
    com.biotools.poker.E.H(getClass().getName() + ".finalize() " + Ì);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.V
 * JD-Core Version:    0.6.2
 */