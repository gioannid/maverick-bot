package com.biotools.poker.R;

import java.text.DecimalFormat;
import java.util.List;

public class T$_A extends j
{
  private String[] L = T.access$0();
  private String[] K = T.access$1();
  final T this$0;

  public T$_A(T paramT, List paramList)
  {
    super(paramList);
  }

  public String[] A()
  {
    return this.L;
  }

  public String B(int paramInt)
  {
    return this.K[paramInt];
  }

  public Object getValueAt(int paramInt1, int paramInt2)
  {
    Z localZ = (Z)A(paramInt1);
    if (localZ == null)
      return null;
    switch (T.access$2(this.this$0, paramInt2))
    {
    case 0:
      return localZ.T();
    case 11:
      return localZ.Y();
    case 1:
      return A.format(localZ.a());
    case 2:
      return Integer.toString(localZ.g());
    case 8:
      return localZ.F();
    case 9:
      return localZ.M();
    case 10:
      return localZ.H();
    case 12:
      return A.format(localZ.U());
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    }
    return "";
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.T._A
 * JD-Core Version:    0.6.2
 */