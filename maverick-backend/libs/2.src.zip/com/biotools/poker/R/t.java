package com.biotools.poker.R;

import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.Q.B;
import com.biotools.poker.Q.D;
import java.io.File;
import java.io.IOException;

public class t
{
  V A = new V();

  public static void A(String[] paramArrayOfString)
  {
    t localt = new t();
    V localV = new V();
    try
    {
      localV.A(new File("server/games.log"));
      localt.A(localV);
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }

  public boolean A(V paramV)
  {
    int i = com.biotools.poker.E.£().getInt("STATS_VERIFY", 0);
    if (i >= 197)
      return false;
    com.biotools.poker.E.£().putInt("STATS_VERIFY", 197);
    int j = 0;
    for (int k = 0; k < paramV.size(); k++)
    {
      E localE = paramV.D(k);
      if (A(localE))
        j++;
    }
    com.biotools.poker.E.H("Changed: " + j + " / " + paramV.size());
    return j > 0;
  }

  public boolean A(E paramE)
  {
    if (!paramE.S())
      return false;
    if (!paramE._().J().equals(com.biotools.poker.E.D("Stats.SessionInfo.PokerAcademyOnline")))
      return false;
    boolean bool = false;
    this.A.clear();
    this.A.D(paramE);
    B localB = new B(this.A, null);
    localB.l();
    localB.C(false);
    localB.C().A(true);
    localB.t();
    try
    {
      localB.V();
      D localD = localB.C();
      if (!localD.isGameOver())
        com.biotools.poker.E.H("bad game!");
      else
        for (int i = 0; i < localD.getNumSeats(); i++)
          if (localD.inGame(i))
          {
            double d1 = localD.getPlayer(i).getNetGain() / localD.getBigBlindSize();
            double d2 = paramE.C(i);
            d1 = Math.round(100000.0D * d1) / 100000.0D;
            d2 = Math.round(100000.0D * d2) / 100000.0D;
            double d3 = Math.abs(d1 - d2);
            d3 = Math.round(100000.0D * d3) / 100000.0D;
            if (d3 > 0.0D)
            {
              bool = true;
              paramE.A(i, d1);
            }
          }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return bool;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.t
 * JD-Core Version:    0.6.2
 */