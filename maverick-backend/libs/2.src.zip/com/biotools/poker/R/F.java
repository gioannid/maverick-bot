package com.biotools.poker.R;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Collections;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public abstract class F extends JPanel
{
  protected JTable ø;
  protected AbstractTableModel õ;
  protected int ô = 2;
  protected boolean ö = false;

  public F()
  {
    setLayout(new BorderLayout(4, 4));
    this.ø = new JTable()
    {
      public Component prepareRenderer(TableCellRenderer paramAnonymousTableCellRenderer, int paramAnonymousInt1, int paramAnonymousInt2)
      {
        Component localComponent = super.prepareRenderer(paramAnonymousTableCellRenderer, paramAnonymousInt1, paramAnonymousInt2);
        return F.this.A(localComponent, paramAnonymousInt1, paramAnonymousInt2);
      }

      protected JTableHeader createDefaultTableHeader()
      {
        return new F.2(this, this.columnModel);
      }
    };
    this.õ = å();
    this.ø.setShowVerticalLines(false);
    this.ø.setModel(this.õ);
    this.ø.setSelectionMode(0);
    this.ø.getTableHeader().setReorderingAllowed(false);
    this.ø.getTableHeader().addMouseListener(new MouseAdapter()
    {
      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        JTableHeader localJTableHeader = (JTableHeader)paramAnonymousMouseEvent.getSource();
        TableColumnModel localTableColumnModel = localJTableHeader.getColumnModel();
        int i = localTableColumnModel.getColumnIndexAtX(paramAnonymousMouseEvent.getX());
        int j = localTableColumnModel.getColumn(i).getModelIndex();
        if (j != -1)
          F.this.K(j);
      }
    });
    é();
    JScrollPane localJScrollPane = new JScrollPane(this.ø);
    localJScrollPane.setVerticalScrollBarPolicy(22);
    localJScrollPane.setPreferredSize(ã());
    add(localJScrollPane, "Center");
    setBorder(BorderFactory.createEmptyBorder(7, 7, 7, 7));
  }

  public void A(ListSelectionListener paramListSelectionListener)
  {
    ç().getSelectionModel().addListSelectionListener(paramListSelectionListener);
  }

  public void B(ListSelectionListener paramListSelectionListener)
  {
    ç().getSelectionModel().removeListSelectionListener(paramListSelectionListener);
  }

  public void é()
  {
    TableColumnModel localTableColumnModel = this.ø.getColumnModel();
    DefaultTableCellRenderer localDefaultTableCellRenderer = new DefaultTableCellRenderer();
    localDefaultTableCellRenderer.setHorizontalAlignment(4);
    for (int i = 1; i < localTableColumnModel.getColumnCount(); i++)
    {
      TableColumn localTableColumn = localTableColumnModel.getColumn(i);
      localTableColumn.setCellRenderer(localDefaultTableCellRenderer);
    }
  }

  public void æ()
  {
    this.õ.fireTableStructureChanged();
    é();
    this.ø.repaint();
    repaint();
  }

  public Dimension ã()
  {
    return new Dimension(480, 200);
  }

  public int â()
  {
    return this.ô;
  }

  public AbstractTableModel è()
  {
    return this.õ;
  }

  protected void A(Component paramComponent, int paramInt, double paramDouble)
  {
    if (this.ø.getSelectionModel().isSelectedIndex(paramInt))
      paramComponent.setBackground(paramDouble == 0.0D ? d.F : paramDouble > 0.0D ? d.A : d.E);
    else
      paramComponent.setBackground(paramDouble == 0.0D ? d.B : paramDouble > 0.0D ? d.G : d.M);
  }

  public abstract List á();

  public abstract Component A(Component paramComponent, int paramInt1, int paramInt2);

  public abstract AbstractTableModel å();

  public void K(int paramInt)
  {
    if (paramInt == this.ô)
      this.ö = (!this.ö);
    else
      this.ö = false;
    this.ô = paramInt;
    Collections.sort(á());
    this.õ.fireTableDataChanged();
  }

  public void ê()
  {
    this.ö = true;
  }

  public void ä()
  {
    this.ö = false;
  }

  public void à()
  {
    Collections.sort(á());
    this.õ.fireTableDataChanged();
  }

  public JTable ç()
  {
    return this.ø;
  }

  public void B(int paramInt1, int paramInt2)
  {
    if (!(this.ø.getParent() instanceof JViewport))
      return;
    JViewport localJViewport = (JViewport)this.ø.getParent();
    Rectangle localRectangle = this.ø.getCellRect(paramInt1, paramInt2, true);
    Point localPoint = localJViewport.getViewPosition();
    localRectangle.setLocation(localRectangle.x - localPoint.x, localRectangle.y - localPoint.y);
    localJViewport.scrollRectToVisible(localRectangle);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.F
 * JD-Core Version:    0.6.2
 */