package com.biotools.poker.R;

import java.text.DecimalFormat;

public class a
  implements Comparable
{
  protected static final int D = 0;
  protected static final int J = 1;
  protected static final int W = 2;
  protected static final int M = 3;
  protected static final int N = 4;
  protected static final int K = 5;
  protected static final int U = 6;
  protected static final int E = 7;
  protected static int T = 2;
  protected static boolean F = false;
  private static final int L = 2;
  protected String Z;
  private String R;
  protected U C;
  private boolean V = false;
  private boolean Q = false;
  private boolean X = false;
  private double B = 0.0D;
  private double Y = 0.0D;
  protected double P = 0.0D;
  private int A = 0;
  private int G = 0;
  private int I = 0;
  private int H = 0;
  private double O = 0.0D;
  private Z S;

  public static a A(U paramU, String paramString)
  {
    if ((paramU instanceof A))
      return new o(paramU, paramString);
    return new a(paramU, paramString);
  }

  a(U paramU, String paramString)
  {
    this.Z = paramString;
    this.R = paramU.J();
    this.C = paramU;
  }

  public void A(E paramE, int paramInt)
  {
    if (paramE.J(paramInt) != this.Z)
    {
      com.biotools.poker.E.H("PlayerSessionStats error: trying to add return to wrong player");
      return;
    }
    this.A += 1;
    this.B += paramE.C(paramInt);
    this.Y += paramE.Q(paramInt);
    if (!paramE.O())
      this.P += paramE.C(paramInt) * this.C.T();
    int i = paramE.B(paramInt, false);
    int j = paramE.A(paramInt, 'c', -1);
    int k = paramE.A(paramInt, 'b', -1);
    int m = paramE.A(paramInt, 'r', -1);
    if (j + k + m > 0)
      this.G += 1;
    if ((paramE.C(paramInt) > 0.0D) && (paramE.e()))
    {
      this.H += 1;
    }
    else if (i == 4)
    {
      this.I += 1;
      if (paramE.C(paramInt) > 0.0D)
        this.O += 1.0D / paramE.A();
    }
    if (paramE.a() == paramInt)
    {
      this.V = true;
      this.Q = false;
    }
    else if ((paramE._() != null) && (paramE._().J() != null) && (paramE._().J().startsWith("Poker Academy")) && (!paramE._().J().endsWith("Online")))
    {
      this.Q = true;
    }
  }

  public static void A(int paramInt, boolean paramBoolean)
  {
    T = paramInt;
    F = paramBoolean;
  }

  public Z B()
  {
    return Z.A(Z.A(this.R, this.Z));
  }

  public boolean I()
  {
    return this.V;
  }

  public boolean S()
  {
    return this.Q;
  }

  public String Q()
  {
    return this.Z;
  }

  public String H()
  {
    return this.R;
  }

  public int Z()
  {
    return this.A;
  }

  public U J()
  {
    return this.C;
  }

  public double M()
  {
    return this.P;
  }

  public double R()
  {
    return this.Y;
  }

  public double _()
  {
    return this.B;
  }

  public double V()
  {
    return this.B * 2.0D;
  }

  public double W()
  {
    return M();
  }

  public int N()
  {
    return this.G;
  }

  public double A()
  {
    return this.H + this.O;
  }

  public int E()
  {
    return this.I;
  }

  public double F()
  {
    return this.O;
  }

  public int C()
  {
    return this.H;
  }

  public double a()
  {
    return this.A > 0 ? this.B / this.A : 0.0D;
  }

  public double D()
  {
    return this.A > 0 ? V() / this.A : 0.0D;
  }

  public double G()
  {
    return this.A > 0 ? M() / this.A : 0.0D;
  }

  public double Y()
  {
    return a();
  }

  public String L()
  {
    return (Y() > 0.0D ? "+" : "") + j.B.format(Y());
  }

  public double X()
  {
    return N() / Z();
  }

  public double U()
  {
    return this.A > 0 ? (this.H + this.O) / this.A : 0.0D;
  }

  public double T()
  {
    return this.A > 0 ? this.O / this.A : 0.0D;
  }

  public double P()
  {
    return this.A > 0 ? this.H / this.A : 0.0D;
  }

  public String K()
  {
    if (I())
      return "<html><b>" + this.Z + "</b></html>";
    return this.Z;
  }

  public String toString()
  {
    return "[" + this.R + "][" + this.C.D() + "][" + this.Z + "]";
  }

  public int compareTo(Object paramObject)
  {
    a locala = (a)paramObject;
    int i = F ? -1 : 1;
    switch (T)
    {
    case 1:
      if (W() < locala.W())
        return 1 * i;
      if (W() > locala.W())
        return -1 * i;
    case 2:
      if (Z() < locala.Z())
        return 1 * i;
      if (Z() > locala.Z())
        return -1 * i;
    case 3:
      if (Y() < locala.Y())
        return 1 * i;
      if (Y() > locala.Y())
        return -1 * i;
    case 4:
      if (X() < locala.X())
        return 1 * i;
      if (X() > locala.X())
        return -1 * i;
    case 5:
      if (U() < locala.U())
        return 1 * i;
      if (U() > locala.U())
        return -1 * i;
    case 6:
      if (T() < locala.T())
        return 1 * i;
      if (T() > locala.T())
        return -1 * i;
    case 7:
      if (P() < locala.P())
        return 1 * i;
      if (P() > locala.P())
        return -1 * i;
    case 0:
      return ((char)(I() ? 25 : 30) + this.Z).compareToIgnoreCase((char)(locala.I() ? 25 : 30) + locala.Z) * i;
    }
    return 0;
  }

  public void A(boolean paramBoolean)
  {
    this.X = paramBoolean;
  }

  public boolean O()
  {
    return this.X;
  }

  public void A(Z paramZ)
  {
    this.S = paramZ;
  }

  public boolean b()
  {
    return false;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.a
 * JD-Core Version:    0.6.2
 */