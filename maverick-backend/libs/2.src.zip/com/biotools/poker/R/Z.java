package com.biotools.poker.R;

import com.biotools.poker.E;
import com.biotools.poker.E.B;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class Z
  implements Comparable
{
  private static HashMap P = new HashMap();
  private static ArrayList T = new ArrayList();
  public static final int A = 0;
  public static final int G = 1;
  public static final int V = 2;
  public static final int J = 3;
  public static final int M = 4;
  public static final int H = 5;
  public static final int S = 6;
  public static final int B = 7;
  public static final int F = 8;
  public static final int I = 9;
  public static final int L = 10;
  public static final int Y = 11;
  public static final int K = 12;
  public static final int U = 13;
  public static final int E = 14;
  public static final int D = 15;
  protected static int R = 13;
  protected static boolean C = false;
  private String X;
  private String Q;
  private boolean W = false;
  private HashSet N = new HashSet();
  private ArrayList O = new ArrayList();

  public Z(String paramString1, String paramString2)
  {
    this.X = paramString2;
    this.Q = paramString1;
  }

  public static ArrayList e()
  {
    return T;
  }

  public static String A(String paramString1, String paramString2)
  {
    return "[" + paramString1 + "]" + "[" + paramString2 + "]";
  }

  public static Z B(int paramInt)
  {
    return (Z)e().get(paramInt);
  }

  public static Z A(String paramString)
  {
    return (Z)P.get(paramString);
  }

  public static void A(int paramInt, boolean paramBoolean)
  {
    R = paramInt;
    C = paramBoolean;
  }

  public static int O()
  {
    return T.size();
  }

  public static Z C(a parama)
  {
    Z localZ = (Z)P.get(A(parama.H(), parama.Q()));
    if (localZ == null)
    {
      localZ = new Z(parama.H(), parama.Q());
      P.put(A(parama.H(), parama.Q()), localZ);
      T.add(localZ);
    }
    localZ.A(parama);
    return localZ;
  }

  public void A(a parama)
  {
    if (this.N.add(parama))
      this.O.add(parama);
  }

  public a A(int paramInt)
  {
    return (a)this.O.get(paramInt);
  }

  private boolean B(a parama)
  {
    return parama.J().Q();
  }

  public int f()
  {
    return this.O.size();
  }

  public int P()
  {
    int i = 0;
    for (int j = 0; j < this.O.size(); j++)
      if (!B(A(j)))
        i++;
    return i;
  }

  public void A()
  {
    for (int i = 0; i < this.O.size(); i++)
      E.H(A(i).toString());
  }

  public boolean K()
  {
    for (int i = 0; i < this.O.size(); i++)
      if ((!B(A(i))) && (A(i).I()))
        return true;
    return false;
  }

  public boolean b()
  {
    for (int i = 0; i < this.O.size(); i++)
      if ((!B(A(i))) && (A(i).S()))
        return true;
    return false;
  }

  public String H()
  {
    if (K())
      return E.D("Stats.PlayerStatsInfo.HeroLowercase");
    if (b())
    {
      B localB = B.D(this.X);
      if (localB != null)
      {
        Object[] arrayOfObject = { localB.C() };
        return E.A("Stats.PlayerStatsInfo.BotLowercasePattern", arrayOfObject);
      }
      return E.D("Stats.PlayerStatsInfo.BotLowercase");
    }
    return E.D("Stats.PlayerStatsInfo.HumanLowercase");
  }

  public String Z()
  {
    if (K())
      return E.D("Stats.PlayerStatsInfo.Hero");
    if (b())
    {
      B localB = B.D(this.X);
      if (localB != null)
      {
        Object[] arrayOfObject = { localB.C(), localB.F() };
        return E.A("Stats.PlayerStatsInfo.BotPattern", arrayOfObject);
      }
      return E.D("Stats.PlayerStatsInfo.Bot");
    }
    return E.D("Stats.PlayerStatsInfo.Human");
  }

  public String T()
  {
    return this.X;
  }

  public String J()
  {
    return this.Q;
  }

  public String Y()
  {
    return U.E(J());
  }

  public String L()
  {
    if (K())
      return "<html><b>" + this.X + "</b></html>";
    return this.X;
  }

  public String G()
  {
    return A(this.Q, this.X);
  }

  public boolean B(Z paramZ)
  {
    return G().compareTo(paramZ.G()) == 0;
  }

  public double h()
  {
    double d = 0.0D;
    for (int i = 0; i < this.O.size(); i++)
      if (!B(A(i)))
        d += A(i)._();
    return d;
  }

  public double U()
  {
    double d = 0.0D;
    for (int i = 0; i < this.O.size(); i++)
      if (!B(A(i)))
        d += A(i).R();
    return d;
  }

  public double _()
  {
    double d = 0.0D;
    for (int i = 0; i < this.O.size(); i++)
      if (!B(A(i)))
        d += A(i).V();
    return d;
  }

  public double Q()
  {
    double d = 0.0D;
    for (int i = 0; i < this.O.size(); i++)
      if (!B(A(i)))
        d += A(i).M();
    return d;
  }

  public int g()
  {
    int i = 0;
    for (int j = 0; j < this.O.size(); j++)
      if (!B(A(j)))
        i += A(j).Z();
    return i;
  }

  public int R()
  {
    int i = 0;
    for (int j = 0; j < this.O.size(); j++)
      if (!B(A(j)))
        i += A(j).N();
    return i;
  }

  public double c()
  {
    return R() / g();
  }

  public double i()
  {
    return h() / g();
  }

  public double E()
  {
    return _() / g();
  }

  private double d()
  {
    double d = 0.0D;
    for (int i = 0; i < this.O.size(); i++)
      if (!B(A(i)))
        d += A(i).Y();
    return d / this.O.size();
  }

  private double j()
  {
    if ((this.O.size() == 1) && (A(0).b()))
      return -((o)A(0)).d();
    return i();
  }

  public double a()
  {
    double d = 0.0D;
    for (int i = 0; i < this.O.size(); i++)
      if (!B(A(i)))
        d += A(i).W();
    return d;
  }

  public int F()
  {
    int i = 0;
    for (int j = 0; j < this.O.size(); j++)
      if (!B(A(j)))
        i += (A(j).b() ? 0 : 1);
    return i;
  }

  public int M()
  {
    int i = 0;
    for (int j = 0; j < this.O.size(); j++)
      if (!B(A(j)))
        i += (A(j).b() ? 1 : 0);
    return i;
  }

  public double B()
  {
    double d = 0.0D;
    for (int i = 0; i < this.O.size(); i++)
      if (!B(A(i)))
        d += A(i).A();
    return d;
  }

  public double I()
  {
    double d = 0.0D;
    for (int i = 0; i < this.O.size(); i++)
      if (!B(A(i)))
        d += A(i).E();
    return d;
  }

  public double C()
  {
    double d = 0.0D;
    for (int i = 0; i < this.O.size(); i++)
      if (!B(A(i)))
        d += A(i).C();
    return d;
  }

  public double X()
  {
    return B() / g();
  }

  public double V()
  {
    return I() / g();
  }

  public double S()
  {
    return C() / g();
  }

  public boolean A(Z paramZ)
  {
    String str1 = G();
    String str2 = paramZ.G();
    return str1.equals(str2);
  }

  public void A(boolean paramBoolean)
  {
    this.W = paramBoolean;
  }

  public boolean W()
  {
    return this.W;
  }

  public void D()
  {
    e().remove(this);
  }

  public String toString()
  {
    return L();
  }

  public String N()
  {
    String str1 = E.D("Stats.PlayerStatsInfo.NA");
    String str2 = str1;
    int i = 0;
    int j = 0;
    for (int k = 0; k < this.O.size(); k++)
      if (!B(A(k)))
        if (A(k).b())
        {
          i = 1;
          str2 = A(k).L();
        }
        else
        {
          j = 1;
        }
    if ((i != 0) && (j != 0))
    {
      E.H("BBB: Error tournament and ring game in same PlayerInfo.getEVCol()");
      return str1;
    }
    if (i != 0)
    {
      if (this.O.size() == 1)
        return str2;
      return str1;
    }
    double d = i();
    return (d > 0.0D ? "+" : "") + j.B.format(d);
  }

  public int compareTo(Object paramObject)
  {
    Z localZ = (Z)paramObject;
    int i = C ? -1 : 1;
    switch (R)
    {
    case 0:
      return this.X.compareToIgnoreCase(localZ.X) * i;
    case 11:
      return Y().compareToIgnoreCase(localZ.Y()) * i;
    case 1:
      if (a() < localZ.a())
        return 1 * i;
      if (a() > localZ.a())
        return -1 * i;
      break;
    case 2:
      if (g() < localZ.g())
        return 1 * i;
      if (g() > localZ.g())
        return -1 * i;
      break;
    case 3:
      if (j() < localZ.j())
        return 1 * i;
      if (j() > localZ.j())
        return -1 * i;
      break;
    case 4:
      if (c() < localZ.c())
        return 1 * i;
      if (c() > localZ.c())
        return -1 * i;
      break;
    case 5:
      if (X() < localZ.X())
        return 1 * i;
      if (X() > localZ.X())
        return -1 * i;
      break;
    case 6:
      if (V() < localZ.V())
        return 1 * i;
      if (V() > localZ.V())
        return -1 * i;
      break;
    case 7:
      if (S() < localZ.S())
        return 1 * i;
      if (S() > localZ.S())
        return -1 * i;
      break;
    case 8:
      if (F() < localZ.F())
        return i;
      if (F() > localZ.F())
        return -i;
      break;
    case 9:
      if (M() < localZ.M())
        return i;
      if (M() < localZ.M())
        return -i;
      break;
    case 10:
      return H().compareToIgnoreCase(localZ.H()) * i;
    case 12:
      if (U() < localZ.U())
        return i;
      if (U() > localZ.U())
        return -i;
    case 13:
      return ((char)((K() ? 25 : 30) + (b() ? 30 : 25)) + this.X).compareToIgnoreCase((char)((localZ.K() ? 25 : 30) + (localZ.b() ? 30 : 25)) + localZ.X) * i;
    case 14:
      if (c() < localZ.c())
        return i;
      if (c() > localZ.c())
        return -i;
      break;
    case 15:
      return ((char)(K() ? 25 : 30) + this.X).compareToIgnoreCase((char)(localZ.K() ? 25 : 30) + localZ.X) * i;
    }
    return 0;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.Z
 * JD-Core Version:    0.6.2
 */