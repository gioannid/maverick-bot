package com.biotools.poker.R;

import com.biotools.B.J;
import com.biotools.B.L;
import com.biotools.meerkat.util.PreferenceChangeEvent;
import com.biotools.meerkat.util.PreferenceChangeListener;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;

public class c extends F
  implements PreferenceChangeListener
{
  private static final int[] Ė = { 0, 1, 2, 3, 14, 5, 6, 7 };
  private static final String[] Ě = { E.D("Stats.SessionPlayerSummary.Player"), E.D("Stats.SessionPlayerSummary.DollarsWon"), E.D("Stats.SessionPlayerSummary.Hands"), E.D("Stats.SessionPlayerSummary.SBPerHand"), E.D("Stats.SessionPlayerSummary.PlayedPercent"), E.D("Stats.SessionPlayerSummary.WinPercent"), E.D("Stats.SessionPlayerSummary.ShowdownPercent"), E.D("Stats.SessionPlayerSummary.Uncontested") };
  private static final String[] ě = { E.D("Stats.SessionPlayerSummary.PlayerDescription"), E.D("Stats.SessionPlayerSummary.DollarsWonDescription"), E.D("Stats.SessionPlayerSummary.HandsDescription"), E.D("Stats.SessionPlayerSummary.SBPerHandDescription"), "<html>" + E.D("Stats.SessionPlayerSummary.PlayedPercentDescription") + "</html>", "<html>" + E.D("Stats.SessionPlayerSummary.WinPercentDescription") + "</html>", "<html>" + E.D("Stats.SessionPlayerSummary.ShowdownPercentDescription") + "</html>", "<html>" + E.D("Stats.SessionPlayerSummary.UncontestedDescription") + "</html>" };
  private V Ĝ;
  private List Ĕ = null;
  private List ē;
  private HashMap Ğ = new HashMap();
  private JButton đ = new J("graph.png", E.D("Stats.SessionPlayerSummary.25"));
  private JButton Ę = new J("hand.png", E.D("Stats.SessionPlayerSummary.ViewHandHistory"));
  private int ę = E.£().getInt("MIN_HANDS_FILTER", 0);
  private JCheckBox ĕ;
  private JCheckBox Ē;
  private JSpinner ė;
  private boolean ĝ;
  private boolean Đ;
  private boolean ğ;

  public c(V paramV)
  {
    this.Ĝ = paramV;
    this.ĝ = true;
    Ă();
  }

  public c(V paramV, boolean paramBoolean1, boolean paramBoolean2)
  {
    this.Ĝ = paramV;
    this.ğ = paramBoolean1;
    this.Đ = paramBoolean2;
    this.ĝ = false;
    if (paramBoolean2)
      æ();
    Ă();
  }

  private boolean ā()
  {
    return this.Ĝ != null;
  }

  protected void Ă()
  {
    E.£().addPreferenceChangeListener(this);
    if (!ā())
    {
      ç().setFocusable(false);
      ç().setEnabled(false);
    }
    if (ā())
    {
      add(Ĉ(), "East");
      add(Ć(), "South");
      this.ø.addMouseListener(new MouseAdapter()
      {
        int A = -1;

        public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
        {
          if (paramAnonymousMouseEvent.getClickCount() == 2)
          {
            c.this.Ą();
            return;
          }
          if (c.this.ø.getSelectedRowCount() == 1)
            if (c.this.ø.getSelectedRow() == this.A)
            {
              c.this.ø.getSelectionModel().clearSelection();
              this.A = -1;
            }
            else
            {
              this.A = c.this.ø.getSelectedRow();
            }
        }
      });
      this.ø.addKeyListener(new KeyAdapter()
      {
        public void keyPressed(KeyEvent paramAnonymousKeyEvent)
        {
          if (paramAnonymousKeyEvent.getKeyCode() == 10)
          {
            c.this.Ą();
            return;
          }
        }
      });
    }
    this.ø.getSelectionModel().addListSelectionListener(new ListSelectionListener()
    {
      public void valueChanged(ListSelectionEvent paramAnonymousListSelectionEvent)
      {
        c.this.ü();
      }
    });
    ü();
    ć();
  }

  public JSpinner ă()
  {
    if (this.ė == null)
    {
      Integer localInteger1 = new Integer(this.ę);
      Integer localInteger2 = new Integer(0);
      Integer localInteger3 = new Integer(99999);
      Integer localInteger4 = new Integer(10);
      final SpinnerNumberModel localSpinnerNumberModel = new SpinnerNumberModel(localInteger1, localInteger2, localInteger3, localInteger4);
      this.ė = new JSpinner(localSpinnerNumberModel);
      this.ė.setEnabled(false);
      this.ė.addChangeListener(new ChangeListener()
      {
        private final SpinnerNumberModel val$sModel;

        public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
        {
          c.this.ę = localSpinnerNumberModel.getNumber().intValue();
          E.£().putInt("MIN_HANDS_FILTER", c.this.ę);
          c.this.ą();
        }
      });
    }
    return this.ė;
  }

  protected JPanel Ć()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(Box.createHorizontalStrut(10));
    localJPanel.add(ý());
    localJPanel.add(Box.createHorizontalStrut(10));
    localJPanel.add(Box.createHorizontalGlue());
    if (!E.Ú())
    {
      localJPanel.add(Box.createHorizontalStrut(10));
      localJPanel.add(Ā());
      localJPanel.add(Box.createHorizontalStrut(10));
      localJPanel.add(ă());
      localJPanel.add(Box.createHorizontalStrut(10));
      localJPanel.add(new JLabel(E.D("Stats.SessionPlayerSummary.HandsLowercase")));
      localJPanel.add(Box.createHorizontalGlue());
      localJPanel.add(Box.createVerticalStrut(5));
    }
    localJPanel.setBorder(BorderFactory.createEmptyBorder(4, 4, 1, 1));
    return localJPanel;
  }

  private JCheckBox Ā()
  {
    if (this.ĕ == null)
    {
      this.ĕ = new JCheckBox(E.D("Stats.SessionPlayerSummary.ShowPlayersWithMoreThan"), false);
      this.ĕ.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          c.this.ă().setEnabled(c.this.ĕ.isSelected());
          c.this.ą();
        }
      });
    }
    return this.ĕ;
  }

  private JCheckBox ý()
  {
    if (this.Ē == null)
    {
      this.Ē = new JCheckBox(E.D("Stats.SessionPlayerSummary.ShowHeroesOnly"), false);
      this.Ē.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          c.this.ą();
        }
      });
    }
    return this.Ē;
  }

  protected void ü()
  {
    if (this.ø.getSelectedRowCount() != 0)
    {
      this.đ.setEnabled(true);
      this.Ę.setEnabled(true);
    }
    else
    {
      this.đ.setEnabled(false);
      this.Ę.setEnabled(false);
    }
  }

  protected Z Q(int paramInt)
  {
    if (paramInt >= á().size())
    {
      if (á().size() > 0)
        return (Z)á().get(á().size() - 1);
      return null;
    }
    return (Z)á().get(paramInt);
  }

  protected Z þ()
  {
    if (this.ø.getSelectedRowCount() > 0)
      return Q(this.ø.getSelectedRow());
    return null;
  }

  private void û()
  {
    Z localZ = þ();
    if (localZ != null)
    {
      D localD = new D(this.Ĝ);
      localD.C(this.Ĕ);
      localD.B(localZ);
      X localX = new X(localD, localZ);
      localX.ł();
      localX.ľ();
    }
  }

  public void D(List paramList)
  {
    if (paramList.size() == 0)
      this.Ĕ = paramList;
    else
      this.Ĕ = paramList;
    ć();
  }

  private void ą()
  {
    Object localObject = þ();
    this.Ğ.clear();
    this.ē.clear();
    if (this.Ĕ == null)
      return;
    for (int i = 0; i < this.Ĕ.size(); i++)
    {
      U localU = (U)this.Ĕ.get(i);
      for (int k = 0; k < localU.M(); k++)
      {
        a locala = localU.B(k);
        String str = Z.A(locala.H(), locala.Q());
        Z localZ2 = (Z)this.Ğ.get(str);
        if (localZ2 == null)
        {
          localZ2 = new Z(locala.H(), locala.Q());
          this.Ğ.put(str, localZ2);
        }
        localZ2.A(locala);
      }
    }
    ArrayList localArrayList = new ArrayList(this.Ğ.values());
    for (int j = 0; j < localArrayList.size(); j++)
    {
      Z localZ1 = (Z)localArrayList.get(j);
      int m = 1;
      if ((Ā().isSelected()) && (localZ1.g() < this.ę))
        m = 0;
      if ((ý().isSelected()) && (!localZ1.K()))
        m = 0;
      if (localZ1.P() == 0)
        m = 0;
      if (m != 0)
      {
        this.ē.add(localZ1);
        if ((localObject != null) && (localZ1.A((Z)localObject)))
          localObject = localZ1;
      }
    }
    à();
    j = á().indexOf(localObject);
    if (j != -1)
      this.ø.getSelectionModel().addSelectionInterval(j, j);
    else if (this.ø.getRowCount() > 0)
      this.ø.getSelectionModel().addSelectionInterval(0, 0);
  }

  public void K(int paramInt)
  {
    int i = paramInt;
    if (!(this instanceof T))
      i = P(paramInt);
    Z localZ = þ();
    Z.A(i, (i == this.ô) && (!this.ö));
    super.K(i);
    int j = á().indexOf(localZ);
    if (j != -1)
      this.ø.getSelectionModel().addSelectionInterval(j, j);
  }

  public void ć()
  {
    ą();
    à();
  }

  public List á()
  {
    if (this.ē == null)
      this.ē = new ArrayList();
    return this.ē;
  }

  private int P(int paramInt)
  {
    return Ė[paramInt];
  }

  public AbstractTableModel å()
  {
    return new _A(á());
  }

  public void preferenceChange(PreferenceChangeEvent paramPreferenceChangeEvent)
  {
    if ((paramPreferenceChangeEvent.getKey() == "POSITIVE_COLOR") || (paramPreferenceChangeEvent.getKey() == "NEUTRAL_COLOR") || (paramPreferenceChangeEvent.getKey() == "NEGATIVE_COLOR"))
      repaint();
  }

  public Component A(Component paramComponent, int paramInt1, int paramInt2)
  {
    if (paramInt1 >= á().size())
      return paramComponent;
    Z localZ = (Z)á().get(paramInt1);
    paramComponent.setForeground(Color.black);
    A(paramComponent, paramInt1, localZ.Q());
    if (localZ.W())
    {
      paramComponent.setForeground(Color.gray);
      paramComponent.setBackground(L.A(paramComponent.getBackground(), Color.LIGHT_GRAY, 0.5D));
    }
    else if (this.ø.getSelectionModel().isSelectedIndex(paramInt1))
    {
      paramComponent.setForeground(Color.white);
    }
    else
    {
      paramComponent.setForeground(Color.black);
    }
    if (localZ.K())
      paramComponent.setFont(paramComponent.getFont().deriveFont(1));
    return paramComponent;
  }

  private void Ą()
  {
    Z localZ = þ();
    if (localZ != null)
    {
      Cursor localCursor = getCursor();
      setCursor(Cursor.getPredefinedCursor(3));
      D localD = new D(this.Ĝ);
      localD.C(this.Ĕ);
      localD.B(localZ);
      if (!this.ĝ)
        localD.A(this.ğ, this.Đ);
      s locals = new s(localZ, localD);
      locals.u();
      setCursor(localCursor);
    }
  }

  private JPanel Ĉ()
  {
    this.đ.setToolTipText(E.D("Stats.SessionPlayerSummary.DisplaySelectedSessions"));
    this.đ.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        c.this.Ą();
      }
    });
    this.Ę.setToolTipText(E.D("Stats.SessionPlayerSummary.ViewSelectedHands"));
    this.Ę.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        c.this.û();
      }
    });
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 1));
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.add(this.đ);
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.add(this.Ę);
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(1, 4, 1, 1));
    return localJPanel;
  }

  public void ÿ()
  {
    E.£().removePreferenceChangeListener(this);
  }

  public class _A extends j
  {
    private String[] P = c.Ě;
    private String[] O = c.ě;

    public _A(List arg2)
    {
      super();
    }

    public String[] A()
    {
      return this.P;
    }

    public String getColumnName(int paramInt)
    {
      if ((c.this.P(paramInt) == 3) && (c.this.Đ))
        return E.D("Stats.SessionPlayerSummary.PlaceStack");
      return super.getColumnName(paramInt);
    }

    public String B(int paramInt)
    {
      if ((c.this.P(paramInt) == 3) && (c.this.Đ))
        return E.D("Stats.SessionPlayerSummary.PlayersFinishPlaceStackSize");
      return this.O[paramInt];
    }

    public String A(Z paramZ)
    {
      if ((c.this.Đ) && (c.this.Ĕ != null) && (c.this.Ĕ.size() > 1))
        return E.D("Stats.SessionPlayerSummary.NA");
      return paramZ.N();
    }

    public Object getValueAt(int paramInt1, int paramInt2)
    {
      Z localZ = (Z)A(paramInt1);
      if (localZ == null)
        return null;
      switch (c.this.P(paramInt2))
      {
      case 0:
        return localZ.T();
      case 1:
        return A.format(localZ.a());
      case 2:
        return Integer.toString(localZ.g());
      case 3:
        return A(localZ);
      case 14:
        return H.format(localZ.c());
      case 5:
        return H.format(localZ.X());
      case 6:
        return H.format(localZ.V());
      case 7:
        return H.format(localZ.S());
      case 4:
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      }
      return "";
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.c
 * JD-Core Version:    0.6.2
 */