package com.biotools.poker.R;

import java.util.List;

public abstract interface Q
{
  public abstract void A(List paramList);
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.Q
 * JD-Core Version:    0.6.2
 */