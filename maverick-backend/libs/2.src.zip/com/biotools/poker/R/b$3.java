package com.biotools.poker.R;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

final class b$3 extends MouseAdapter
{
  final b this$0;

  b$3(b paramb)
  {
  }

  public void mouseClicked(MouseEvent paramMouseEvent)
  {
    JTableHeader localJTableHeader = (JTableHeader)paramMouseEvent.getSource();
    TableColumnModel localTableColumnModel = localJTableHeader.getColumnModel();
    int i = localTableColumnModel.getColumnIndexAtX(paramMouseEvent.getX());
    int j = localTableColumnModel.getColumn(i).getModelIndex();
    if (j != -1)
      this.this$0.O(j);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.b.3
 * JD-Core Version:    0.6.2
 */