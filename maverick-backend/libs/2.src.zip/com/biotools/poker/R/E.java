package com.biotools.poker.R;

import com.biotools.A.O;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.G.R;
import com.biotools.poker.G.T;
import com.biotools.poker.G.a;
import com.biotools.poker.Q.D;
import com.biotools.poker.Q.F;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class E
  implements Comparable
{
  public static final String H = "PB";
  public static final String p = "PV";
  public static final String G = "PC";
  public static final String C = "PN";
  public static final String g = "BETS";
  public static final String k = "RAKE";
  public static final String o = "HERO";
  public static final String A = "SEQ";
  public static final String N = "BOARD";
  public static final String f = "BB";
  public static final String I = "SB";
  public static final String D = "BTN";
  public static final String m = "SBS";
  public static final String d = "NP";
  public static final String E = "TIME";
  public static final String O = "ID";
  public static final String U = "TABLE";
  public static final String e = "GAME";
  public static final String Q = "SITE";
  public static final String S = "ANTE";
  public static final String M = "TOURNAMENT_ID";
  public static final int L = 0;
  public static final int b = 1;
  protected static int T = 0;
  protected static boolean R = false;
  private static final int B = 500;
  protected static O a = new O();
  protected U X;
  protected long n;
  protected long _;
  protected byte Y;
  protected byte F;
  protected byte J;
  protected byte[] K;
  protected byte[] i;
  protected byte[] c = new byte[10];
  protected short[] j;
  protected byte[] Z;
  protected float[] l;
  protected float[] W;
  protected P h;
  private float[] P;
  private float V;

  public E(D paramD, String paramString1, String paramString2, String paramString3, R paramR, long paramLong)
  {
    A(paramD, paramString1, paramString2, paramString3, paramR, paramLong);
  }

  public E(D paramD, String paramString1, String paramString2, String paramString3, R paramR)
  {
    A(paramD, paramString1, paramString2, paramString3, paramR, 0L);
  }

  private void A(D paramD, String paramString1, String paramString2, String paramString3, R paramR, long paramLong)
  {
    H(paramD.d());
    A(paramD.getBoard());
    this._ = paramD.b();
    F(paramD.getNumPlayers());
    A(paramD.getSmallBlindSeat());
    this.V = ((float)paramD.getRake());
    A((float)paramD.getAnte(), (float)paramD.getSmallBlindSize(), (float)paramD.getBigBlindSize());
    int i1 = 0;
    for (int i2 = 0; i2 < paramD.getNumSeats(); i2++)
    {
      this.c[i2] = -1;
      if (!paramD.E(i2))
        this.c[i2] = ((byte)i1++);
    }
    this.j = new short[i1];
    this.Z = new byte[i1 * 2];
    this.l = new float[i1];
    this.W = new float[i1];
    for (i2 = 0; i2 < paramD.getNumSeats(); i2++)
      if (!paramD.E(i2))
      {
        this.j[this.c[i2]] = ((short)a.C(paramD.getPlayerName(i2)));
        if (paramD.inGame(i2))
        {
          this.l[this.c[i2]] = ((float)(paramD.G(i2).getNetGain() / W()));
          A(this.c[i2], paramD.G(i2).getRevealedHand());
          this.W[this.c[i2]] = ((float)(paramD.G(i2).getBankRoll() - paramD.G(i2).getNetGain()));
        }
        else
        {
          this.l[this.c[i2]] = 0.0F;
          A(this.c[i2], null);
          this.W[this.c[i2]] = 0.0F;
        }
      }
    if (paramLong == 0L)
      A(System.currentTimeMillis());
    else
      A(paramLong);
    M(paramD.M());
    S(B(paramString1));
    if (paramD.isNoLimit())
    {
      this.P = new float[paramD.H().size()];
      for (i2 = 0; i2 < paramD.H().size(); i2++)
        this.P[i2] = ((Double)paramD.H().get(i2)).floatValue();
    }
    if (paramR != null)
      A.A(this, paramR, paramString2, paramString3);
    else
      U localU = U.B(this, paramString2, paramString3);
  }

  public String k()
  {
    return new String(this.i);
  }

  private String[] C(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    int i1 = 1;
    for (int i2 = 0; i2 < paramString.length(); i2++)
      if (paramString.charAt(i2) == '/')
        i1++;
    String[] arrayOfString = new String[i1];
    int i3 = -1;
    for (int i4 = 0; i4 < paramString.length(); i4++)
    {
      char c1 = paramString.charAt(i4);
      if (c1 == '/')
      {
        i3++;
        arrayOfString[i3] = localStringBuffer.toString();
        localStringBuffer.setLength(0);
      }
      else
      {
        localStringBuffer.append(c1);
      }
    }
    i3++;
    arrayOfString[i3] = localStringBuffer.toString();
    localStringBuffer.setLength(0);
    while (i3 < i1 - 1)
      arrayOfString[(++i3)] = "";
    return arrayOfString;
  }

  public void H(String paramString)
  {
    this.i = paramString.getBytes();
  }

  public void A(Hand paramHand)
  {
    if (paramHand == null)
      return;
    if (paramHand.size() == 0)
      return;
    paramHand.clearBadCards();
    this.K = new byte[paramHand.size()];
    for (int i1 = 0; i1 < paramHand.size(); i1++)
    {
      Card localCard = paramHand.getCard(i1 + 1);
      if (localCard.valid())
        this.K[i1] = ((byte)localCard.getIndex());
    }
  }

  public int V()
  {
    if (this.K == null)
      return 0;
    return this.K.length;
  }

  public Card H(int paramInt)
  {
    return new Card(this.K[(paramInt - 1)]);
  }

  private void A(int paramInt, Hand paramHand)
  {
    if (paramHand == null)
    {
      this.Z[B(paramInt, 0)] = -1;
      this.Z[B(paramInt, 1)] = -1;
    }
    else
    {
      this.Z[B(paramInt, 0)] = ((byte)paramHand.getCard(1).getIndex());
      this.Z[B(paramInt, 1)] = ((byte)paramHand.getCard(2).getIndex());
    }
  }

  private final int B(int paramInt1, int paramInt2)
  {
    return paramInt1 * 2 + paramInt2;
  }

  private String D(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i1 = 0; i1 < paramString.length(); i1++)
      if (paramString.charAt(i1) != ' ')
        localStringBuffer.append(paramString.charAt(i1));
    return localStringBuffer.toString();
  }

  private String E()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i1 = 1; i1 <= 5; i1++)
      if (i1 > V())
        localStringBuffer.append("??");
      else
        localStringBuffer.append(H(i1).toString());
    return localStringBuffer.toString();
  }

  public long h()
  {
    return this._;
  }

  public int b()
  {
    return this.F;
  }

  public int a()
  {
    return this.Y;
  }

  public void S(int paramInt)
  {
    this.Y = ((byte)paramInt);
  }

  public void F(int paramInt)
  {
    this.F = ((byte)paramInt);
  }

  public void F(String paramString)
  {
    S(B(paramString));
  }

  public int c()
  {
    return this.c.length;
  }

  public int C()
  {
    return this.J % 10;
  }

  public int F()
  {
    return this.J / 10;
  }

  public void M(int paramInt)
  {
    this.J = ((byte)(paramInt + 10 * F()));
  }

  public void A(int paramInt)
  {
    this.J = ((byte)(C() + 10 * paramInt));
  }

  private int L()
  {
    if ((k().startsWith("s")) || (k().startsWith("S")))
    {
      if (b() == 2)
        return C();
      return D(C());
    }
    int i1 = L(C());
    int i2 = D(C());
    if (i1 == i2)
    {
      i1 = (C() + 1) % 10;
      if (i1 == i2)
      {
        com.biotools.poker.E.H("Setting dead small blind seat to the button seat since there are no alternatives!");
        i1 = C();
      }
    }
    return i1;
  }

  public int i()
  {
    return D(F());
  }

  public boolean R()
  {
    return (b() == 2) && (C() == F());
  }

  public int N()
  {
    if (R())
      return C();
    return D(C());
  }

  public int D(int paramInt)
  {
    assert ((paramInt >= 0) && (paramInt < 10));
    if ((paramInt < 0) || (paramInt >= 10))
      throw new ArrayIndexOutOfBoundsException(paramInt);
    for (int i1 = (paramInt + 1) % 10; i1 != paramInt; i1 = (i1 + 1) % 10)
      if (G(i1))
        return i1;
    return paramInt;
  }

  public int L(int paramInt)
  {
    assert ((paramInt >= 0) && (paramInt < 10));
    if ((paramInt < 0) || (paramInt >= 10))
      throw new ArrayIndexOutOfBoundsException(paramInt);
    for (int i1 = (paramInt + 1) % 10; i1 != paramInt; i1 = (i1 + 1) % 10)
      if (!N(i1))
        return i1;
    return paramInt;
  }

  public int g()
  {
    int i1 = 0;
    for (int i2 = 0; i2 < 10; i2++)
      if (!N(i2))
        i1++;
    return i1;
  }

  public boolean E(String paramString)
  {
    return G(B(paramString));
  }

  public boolean G(int paramInt)
  {
    if (paramInt < 0)
      return false;
    if (this.c[paramInt] < 0)
      return false;
    return this.W[this.c[paramInt]] > 0.0F;
  }

  public boolean N(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= 10))
      return true;
    return this.c[paramInt] < 0;
  }

  public Hand H()
  {
    Hand localHand = new Hand();
    for (int i1 = 1; i1 <= V(); i1++)
      localHand.addCard(H(i1));
    return localHand;
  }

  public int B(String paramString)
  {
    for (int i1 = 0; i1 < 10; i1++)
      if ((this.c[i1] >= 0) && (J(i1).equals(paramString)))
        return i1;
    return -1;
  }

  public Hand O(int paramInt)
  {
    Hand localHand = new Hand();
    int i1 = this.c[paramInt];
    localHand.addCard(this.Z[B(i1, 0)]);
    localHand.addCard(this.Z[B(i1, 1)]);
    return localHand;
  }

  public double j()
  {
    double d1 = 0.0D;
    for (int i1 = 0; i1 < this.l.length; i1++)
      if (this.l[i1] > 0.0F)
        d1 += this.l[i1];
    return A(d1);
  }

  public double C(int paramInt)
  {
    return B(this.l[this.c[paramInt]]);
  }

  public void A(int paramInt, double paramDouble)
  {
    this.l[this.c[paramInt]] = ((float)B(paramDouble));
  }

  public double B()
  {
    float f1 = 0.0F;
    for (int i1 = 0; i1 < 10; i1++)
      if (!N(i1))
        f1 = (float)(f1 + P(i1));
    return f1;
  }

  public double d()
  {
    if ((_() != null) && (_().X()))
    {
      R localR = D().b();
      double d1 = localR.i();
      return W() / B() * d1;
    }
    return W();
  }

  public double T(int paramInt)
  {
    if ((_() != null) && (_().X()))
      return this.l[this.c[paramInt]] * W();
    return 0.0D;
  }

  public double I(int paramInt)
  {
    if ((_() != null) && (_().X()))
      return A(paramInt, true) - A(paramInt, false);
    return A(this.l[this.c[paramInt]] * W());
  }

  public double A(int paramInt1, int paramInt2)
  {
    switch (paramInt2)
    {
    case 2:
      return I(paramInt1);
    case 0:
      return C(paramInt1);
    case 3:
      return T(paramInt1);
    case 1:
    }
    return 0.0D;
  }

  public int A()
  {
    int i1 = 0;
    for (int i2 = 0; i2 < this.l.length; i2++)
      if (this.l[i2] > 0.0F)
        i1++;
    return i1;
  }

  public double Q(int paramInt)
  {
    if (this.l[this.c[paramInt]] > 0.0F)
      return A(this.V / A());
    return 0.0D;
  }

  protected Hand A(String paramString)
  {
    int i1 = 0;
    Hand localHand = new Hand();
    while (i1 + 1 < paramString.length())
      if (paramString.charAt(i1) == ' ')
      {
        i1++;
      }
      else
      {
        Card localCard = new Card(paramString.charAt(i1), paramString.charAt(i1 + 1));
        if (localCard.getIndex() != -1)
          localHand.addCard(localCard);
        else
          localHand.addCard(new Card(-1));
        i1 += 2;
      }
    return localHand;
  }

  protected int G(String paramString)
  {
    return Integer.parseInt(paramString.substring(1).trim());
  }

  public int B(int paramInt, boolean paramBoolean)
  {
    boolean[] arrayOfBoolean = new boolean[c()];
    for (int i1 = 0; i1 < c(); i1++)
      arrayOfBoolean[i1] = (G(i1) ? 0 : true);
    i1 = N();
    assert (i1 != -1);
    int i2 = b();
    int i3 = 0;
    String str = k();
    for (int i4 = 0; i4 < str.length(); i4++)
    {
      int i5 = str.charAt(i4);
      if (i5 == 47)
      {
        i3++;
        i1 = D(C());
        if ((!$assertionsDisabled) && (i1 == -1))
          throw new AssertionError();
      }
      else if (i5 == 102)
      {
        if (i1 == paramInt)
          return i3;
        arrayOfBoolean[i1] = true;
        i2--;
        i1++;
      }
      else
      {
        if ((i5 == 80) || (i5 == 68))
        {
          i4++;
          continue;
        }
        i1++;
      }
      if (i1 >= c())
        i1 = 0;
      while ((arrayOfBoolean[i1] != 0) && (i2 > 1))
      {
        i1++;
        if (i1 >= c())
          i1 = 0;
      }
    }
    if ((i2 > 1) || (paramBoolean))
      return 4;
    return i3;
  }

  public boolean e()
  {
    if (this.K == null)
      return true;
    if (this.K.length < 5)
      return true;
    String str = k();
    if (str.charAt(str.length() - 1) == 'f')
    {
      boolean[] arrayOfBoolean = new boolean[c()];
      for (int i1 = 0; i1 < c(); i1++)
        arrayOfBoolean[i1] = (G(i1) ? 0 : true);
      i1 = N();
      assert (i1 != -1);
      int i2 = b();
      int i3 = 0;
      for (int i4 = 0; i4 < str.length(); i4++)
      {
        int i5 = str.charAt(i4);
        if (i5 == 47)
        {
          i3++;
          i1 = D(C());
        }
        else if (i5 == 102)
        {
          arrayOfBoolean[i1] = true;
          i2--;
          i1++;
        }
        else
        {
          if ((i5 == 80) || (i5 == 68))
          {
            i4++;
            continue;
          }
          i1++;
        }
        if (i1 >= c())
          i1 = 0;
        while ((arrayOfBoolean[i1] != 0) && (i2 > 1))
        {
          i1++;
          if (i1 >= c())
            i1 = 0;
        }
      }
      return i2 == 1;
    }
    return false;
  }

  public int A(int paramInt1, char paramChar, int paramInt2)
  {
    boolean[] arrayOfBoolean = new boolean[c()];
    for (int i1 = 0; i1 < c(); i1++)
      arrayOfBoolean[i1] = (G(i1) ? 0 : true);
    i1 = N();
    assert (i1 != -1);
    int i2 = 0;
    int i3 = b();
    int i4 = 0;
    String str = k();
    for (int i5 = 0; i5 < str.length(); i5++)
    {
      char c1 = str.charAt(i5);
      if ((c1 == paramChar) && (i1 == paramInt1) && ((paramInt2 == -1) || (paramInt2 == i4)))
        i2++;
      if (c1 == '/')
      {
        i4++;
        i1 = D(C());
      }
      else if (c1 == 'f')
      {
        arrayOfBoolean[i1] = true;
        i3--;
        i1++;
      }
      else
      {
        if ((c1 == 'P') || (c1 == 'D'))
        {
          i5++;
          continue;
        }
        i1++;
      }
      if (i1 >= c())
        i1 = 0;
      while ((arrayOfBoolean[i1] != 0) && (i3 > 1))
      {
        i1++;
        if (i1 >= c())
          i1 = 0;
      }
    }
    return i2;
  }

  public int C(int paramInt1, int paramInt2)
  {
    boolean[] arrayOfBoolean = new boolean[c()];
    for (int i1 = 0; i1 < c(); i1++)
      arrayOfBoolean[i1] = (G(i1) ? 0 : true);
    i1 = N();
    assert (i1 != -1);
    int i2 = b();
    int i3 = 0;
    int i4 = 0;
    int i5 = 0;
    int i6 = 0;
    int i7 = 0;
    String str = k();
    for (int i8 = 0; i8 < str.length(); i8++)
    {
      int i9 = str.charAt(i8);
      if (i1 == paramInt1)
      {
        if ((i7 == 0) && (i4 >= 2) && ((paramInt2 == -1) || (paramInt2 == i3)))
        {
          i6++;
          if (i9 == 99)
            i5++;
        }
        if ((i9 != 107) && (i9 != 102))
          i7 = 1;
      }
      if ((i9 == 66) || (i9 == 98) || (i9 == 114))
        i4++;
      if (i9 == 47)
      {
        i3++;
        i4 = 0;
        i7 = 0;
        i1 = D(C());
      }
      else if (i9 == 102)
      {
        arrayOfBoolean[i1] = true;
        i2--;
        i1++;
      }
      else
      {
        if ((i9 == 80) || (i9 == 68))
        {
          i8++;
          continue;
        }
        i1++;
      }
      if (i1 >= c())
        i1 = 0;
      while ((arrayOfBoolean[i1] != 0) && (i2 > 1))
      {
        i1++;
        if (i1 >= c())
          i1 = 0;
      }
    }
    return i5 * 10 + i6;
  }

  public int K(int paramInt)
  {
    boolean[] arrayOfBoolean = new boolean[c()];
    for (int i1 = 0; i1 < c(); i1++)
      arrayOfBoolean[i1] = (G(i1) ? 0 : true);
    i1 = N();
    assert (i1 != -1);
    int i2 = b();
    if (i2 < 6)
      return 0;
    int i3 = 0;
    int i4 = C();
    int i5 = i4 - 1;
    if (i5 == -1)
      i5 = c() - 1;
    for (int i6 = 0; i6 < c(); i6++)
    {
      if (arrayOfBoolean[i5] == 0)
        break;
      i5--;
      if (i5 == -1)
        i5 = c() - 1;
    }
    i6 = F();
    int i7 = i();
    String str = k();
    if ((paramInt != i5) && (paramInt != i4) && (paramInt != i6) && (paramInt != i7))
      return 0;
    for (int i8 = 0; i8 < str.length(); i8++)
    {
      int i9 = str.charAt(i8);
      if ((i3 != 0) && ((i9 == 99) || (i9 == 114)) && (paramInt != i1))
        return 0;
      if ((i1 == i6) && (paramInt == i6) && (i3 != 0))
        return i9 == 102 ? 2 : 1;
      if ((i1 == i7) && (paramInt == i7) && (i3 != 0))
        return i9 == 102 ? 4 : 3;
      if ((i1 != i4) && (i1 != i5))
      {
        if ((i9 == 99) || (i9 == 114))
          return 0;
      }
      else
      {
        if (paramInt == i1)
        {
          if (i3 == 0)
            return i9 == 114 ? 5 : 6;
          return 0;
        }
        if (i9 == 114)
          i3 = 1;
        else if (i9 == 99)
          return 0;
      }
      if (i9 == 47)
        return 0;
      if ((i9 == 80) || (i9 == 68))
      {
        i8++;
      }
      else
      {
        i1++;
        if (i1 >= c())
          i1 = 0;
        while ((arrayOfBoolean[i1] != 0) && (i2 > 1))
        {
          i1++;
          if (i1 >= c())
            i1 = 0;
        }
      }
    }
    return 0;
  }

  public String J(int paramInt)
  {
    if (N(paramInt))
      return null;
    return a.D(this.j[this.c[paramInt]]);
  }

  public boolean I()
  {
    for (int i1 = 0; i1 < 10; i1++)
      if (!E(i1))
        return false;
    return true;
  }

  public boolean E(int paramInt)
  {
    if (G(paramInt))
    {
      int i1 = this.c[paramInt];
      if ((this.Z[B(i1, 0)] == -1) || (this.Z[B(i1, 1)] == -1))
        return false;
    }
    return true;
  }

  public static void B(int paramInt)
  {
    T = paramInt;
  }

  public int compareTo(Object paramObject)
  {
    int i1 = R ? -1 : 1;
    if (paramObject == null)
      return 0;
    E localE = (E)paramObject;
    switch (T)
    {
    case 0:
      if (this.n < localE.n)
        return -i1;
      if (this.n > localE.n)
        return i1;
    case 1:
      if (_().I() < localE._().I())
        return -i1;
      if (_().I() > localE._().I())
        return i1;
      if (this.n < localE.n)
        return -i1;
      if (this.n > localE.n)
        return i1;
      break;
    }
    return 0;
  }

  public boolean Y()
  {
    return this.X.Q();
  }

  public boolean J()
  {
    return this.P != null;
  }

  public long P()
  {
    return this.n;
  }

  public void A(long paramLong)
  {
    this.n = paramLong;
  }

  public String U()
  {
    if (a() >= 0)
      return J(a());
    return "?";
  }

  public E(String paramString)
  {
    Preferences localPreferences = new Preferences(paramString, ";");
    A(localPreferences);
    if ((com.biotools.poker.E.y()) && (A(true, false) < 0))
    {
      com.biotools.poker.E.H(this);
      if (A(true, false) == -1)
        System.out.println(f.B(this, true));
    }
  }

  public E(Preferences paramPreferences)
  {
    A(paramPreferences);
  }

  public boolean A(E paramE)
  {
    if (this == paramE)
      return false;
    return (paramE._().J().equalsIgnoreCase(_().J())) && (paramE.h() == h()) && (paramE.P() == P());
  }

  public U _()
  {
    return this.X;
  }

  public void A(U paramU)
  {
    this.X = paramU;
  }

  public String T()
  {
    if (J())
      return "$" + U.j.format(this.h.A()) + "/$" + U.j.format(this.h.B()) + " NL";
    return "$" + U.j.format(this.h.B()) + "/$" + U.j.format(this.h.B() * 2.0D);
  }

  public String toString()
  {
    Preferences localPreferences = K();
    return localPreferences.toString(';') + '\n';
  }

  public double Z()
  {
    return A(this.V);
  }

  public double f()
  {
    return A(this.h.A());
  }

  public double M()
  {
    return A(this.h.B());
  }

  public double W()
  {
    return A(this.h.B());
  }

  public double R(int paramInt)
  {
    if (this.P == null)
      return 0.0D;
    if (paramInt >= this.P.length)
      return 0.0D;
    return A(this.P[paramInt]);
  }

  public double l()
  {
    return A(this.h.C());
  }

  public double P(int paramInt)
  {
    return A(this.W[this.c[paramInt]]);
  }

  private String m()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i1 = 0; i1 < this.P.length; i1++)
    {
      if (i1 != 0)
        localStringBuffer.append(',');
      localStringBuffer.append(A(this.P[i1]));
    }
    return localStringBuffer.toString();
  }

  public float[] G()
  {
    return this.P;
  }

  public Preferences K()
  {
    Preferences localPreferences = new Preferences();
    localPreferences.setPreference("SITE", _().J());
    localPreferences.setPreference("GAME", _().P());
    localPreferences.setPreference("TABLE", _().D());
    localPreferences.setPreference("ID", h());
    localPreferences.setPreference("TIME", P());
    localPreferences.setPreference("NP", b());
    localPreferences.setPreference("BTN", C());
    localPreferences.setPreference("SBS", F());
    localPreferences.setPreference("SB", f());
    localPreferences.setPreference("BB", W());
    localPreferences.setPreference("BOARD", E());
    localPreferences.setPreference("SEQ", k());
    localPreferences.setPreference("ANTE", l());
    if (O())
      localPreferences.setPreference("TOURNAMENT_ID", X());
    if (a() >= 0)
      localPreferences.setPreference("HERO", U());
    if (Z() > 0.0D)
      localPreferences.setPreference("RAKE", Z());
    if (this.P != null)
      localPreferences.setPreference("BETS", m());
    for (int i1 = 0; i1 < 10; i1++)
      if (this.c[i1] >= 0)
      {
        localPreferences.setPreference("PN" + i1, J(i1));
        if (G(i1))
        {
          localPreferences.setPreference("PC" + i1, D(O(i1).toString().trim()));
          localPreferences.setPreference("PV" + i1, C(i1));
          localPreferences.setPreference("PB" + i1, P(i1));
        }
      }
    return localPreferences;
  }

  public void A(Preferences paramPreferences)
  {
    this.n = paramPreferences.getLongPreference("TIME", System.currentTimeMillis());
    this._ = paramPreferences.getLongPreference("ID", -1L);
    F(paramPreferences.getIntPreference("NP", 2));
    this.V = ((float)paramPreferences.getDoublePreference("RAKE", 0.0D));
    M(paramPreferences.getIntPreference("BTN", -1));
    float f1 = (float)paramPreferences.getDoublePreference("ANTE", 0.0D);
    float f2 = (float)paramPreferences.getDoublePreference("SB", 1.0D);
    float f3 = (float)paramPreferences.getDoublePreference("BB", 2.0D);
    A(f1, f2, f3);
    H(paramPreferences.getPreference("SEQ", ""));
    A(A(paramPreferences.getPreference("BOARD", "")));
    int i1 = 0;
    Object localObject;
    for (int i2 = 0; i2 < 10; i2++)
    {
      this.c[i2] = -1;
      localObject = paramPreferences.getPreference("PN" + i2, null);
      if (localObject != null)
        this.c[i2] = ((byte)i1++);
    }
    this.j = new short[i1];
    this.l = new float[i1];
    this.W = new float[i1];
    this.Z = new byte[i1 * 2];
    for (i2 = 0; i2 < 10; i2++)
    {
      localObject = paramPreferences.getPreference("PN" + i2, null);
      if (localObject != null)
      {
        this.j[this.c[i2]] = ((short)a.C((String)localObject));
        String str2 = paramPreferences.getPreference("PC" + i2);
        if (str2 != null)
        {
          this.l[this.c[i2]] = ((float)paramPreferences.getDoublePreference("PV" + i2, 0.0D));
          this.W[this.c[i2]] = ((float)paramPreferences.getDoublePreference("PB" + i2, 0.0D));
          A(this.c[i2], A(str2));
        }
        else
        {
          this.l[this.c[i2]] = 0.0F;
          this.W[this.c[i2]] = 0.0F;
          A(this.c[i2], null);
        }
      }
    }
    if (C() == -1)
      for (i2 = 0; i2 < 10; i2++)
        if ((this.c[i2] != -1) && (C() < i2))
          M(i2);
    if (paramPreferences.hasPreference("SBS"))
      A(paramPreferences.getIntPreference("SBS", -1));
    else
      A(L());
    S(B(paramPreferences.getPreference("HERO")));
    String str1 = paramPreferences.getPreference("BETS", null);
    if (str1 != null)
      if (str1.trim().length() == 0)
      {
        this.P = new float[0];
      }
      else
      {
        localObject = str1.split(",");
        this.P = new float[localObject.length];
        for (i4 = 0; i4 < localObject.length; i4++)
          this.P[i4] = (Math.round(Float.parseFloat(localObject[i4]) * 100.0F) / 100.0F);
      }
    int i3 = 0;
    int i4 = paramPreferences.getIntPreference("TOURNAMENT_ID", -1);
    if (i4 != -1)
      A.A(this, i4, paramPreferences.getPreference("SITE", com.biotools.poker.E.Ò()), paramPreferences.getPreference("TABLE", com.biotools.poker.E.D("Stats.GameRecord.UnknownTable")));
    if (_() == null)
      U.B(this, paramPreferences.getPreference("SITE", com.biotools.poker.E.Ò()), paramPreferences.getPreference("TABLE", com.biotools.poker.E.D("Stats.GameRecord.UnknownTable")));
  }

  private void A(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    this.h = P.A(new P(paramFloat1, paramFloat2, paramFloat3));
  }

  public static void Q()
  {
    com.biotools.poker.E.H("String Dict: " + a.size());
  }

  public boolean S()
  {
    return !O();
  }

  public boolean O()
  {
    return this.X instanceof A;
  }

  public int X()
  {
    if ((this.X instanceof A))
      return ((A)this.X).c();
    return -1;
  }

  public A D()
  {
    if ((this.X instanceof A))
      return (A)this.X;
    return null;
  }

  public final double A(int paramInt, boolean paramBoolean)
  {
    R localR = D().b();
    if (paramInt == -1)
      return 0.0D;
    float f1 = 0.0F;
    double[] arrayOfDouble1 = new double[10];
    for (int i1 = 0; i1 < 10; i1++)
      if (!N(i1))
      {
        arrayOfDouble1[i1] = P(i1);
        if (paramBoolean)
          arrayOfDouble1[i1] += C(i1) * W();
        f1 = (float)(f1 + arrayOfDouble1[i1]);
      }
    double d1 = -localR.I(J(paramInt));
    a locala = localR.Q().J(localR.V());
    if (locala == null)
      return 0.0D;
    double[] arrayOfDouble2 = locala.A(localR.i());
    if (Math.abs(f1 - localR.d()) < 0.1D * W())
    {
      for (int i2 = 0; i2 < arrayOfDouble2.length; i2++)
        d1 += B(arrayOfDouble1, paramInt, i2 + 1) * arrayOfDouble2[i2];
    }
    else
    {
      double d2 = arrayOfDouble1[paramInt] / localR.d();
      for (int i3 = 0; i3 < arrayOfDouble2.length; i3++)
        d1 += d2 * Math.pow(1.0D - d2, i3) * arrayOfDouble2[i3];
    }
    return d1;
  }

  private final double B(double[] paramArrayOfDouble, int paramInt1, int paramInt2)
  {
    if (paramArrayOfDouble[paramInt1] < 0.01D)
    {
      int i1 = 0;
      for (int i2 = 0; i2 < paramArrayOfDouble.length; i2++)
        if (paramArrayOfDouble[i2] > 0.01D)
          i1++;
      return i1 + 1 == paramInt2 ? 1 : 0;
    }
    if (Math.pow(paramArrayOfDouble.length, paramInt2 - 1) < 500.0D)
      return C(paramArrayOfDouble, paramInt1, paramInt2);
    return A(paramArrayOfDouble, paramInt1, paramInt2);
  }

  private final double A(double[] paramArrayOfDouble, int paramInt1, int paramInt2)
  {
    double d1 = 0.0D;
    for (int i1 = 0; i1 < paramArrayOfDouble.length; i1++)
      d1 += paramArrayOfDouble[i1];
    double d2 = paramArrayOfDouble[paramInt1] / d1;
    return d2 * Math.pow(1.0D - d2, paramInt2 - 1);
  }

  private final double C(double[] paramArrayOfDouble, int paramInt1, int paramInt2)
  {
    if (paramInt2 <= 1)
    {
      d1 = 0.0D;
      for (i1 = 0; i1 < paramArrayOfDouble.length; i1++)
        d1 += paramArrayOfDouble[i1];
      return paramArrayOfDouble[paramInt1] / d1;
    }
    double d1 = 0.0D;
    for (int i1 = 0; i1 < paramArrayOfDouble.length; i1++)
      if (i1 != paramInt1)
      {
        double d2 = B(paramArrayOfDouble, i1, 1);
        double d3 = paramArrayOfDouble[i1];
        paramArrayOfDouble[i1] = 0.0D;
        double d4 = B(paramArrayOfDouble, paramInt1, paramInt2 - 1);
        paramArrayOfDouble[i1] = d3;
        double d5 = d2 * d4;
        d1 += d5;
      }
    return d1;
  }

  private double A(double paramDouble)
  {
    return Math.round(paramDouble * 100.0D) / 100.0D;
  }

  private double B(double paramDouble)
  {
    return Math.round(paramDouble * 10000.0D) / 10000.0D;
  }

  public int A(boolean paramBoolean1, boolean paramBoolean2)
  {
    if (paramBoolean1)
    {
      double d1 = 0.0D;
      for (int i1 = 0; i1 < this.l.length; i1++)
        d1 += this.l[i1];
      d1 += Z() / W();
      if (Math.abs(d1) > 0.05D)
      {
        com.biotools.poker.E.H("Non-zero sum game record: " + h());
        com.biotools.poker.E.H(d1 + " r:" + Z() + " v:" + this.l.toString() + " " + new SimpleDateFormat("MMMM dd, yyyy - HH:mm:ss (zzz)").format(new Date(P())));
        return -1;
      }
    }
    if (paramBoolean2)
      try
      {
        f localf = new f(this, true, false);
      }
      catch (Exception localException)
      {
        com.biotools.poker.E.H("Generate transcript exception: " + h());
        localException.printStackTrace();
        return -2;
      }
      catch (AssertionError localAssertionError)
      {
        com.biotools.poker.E.H("Generate transcript assertion: " + h());
        localAssertionError.printStackTrace();
        return -3;
      }
    return 1;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.E
 * JD-Core Version:    0.6.2
 */