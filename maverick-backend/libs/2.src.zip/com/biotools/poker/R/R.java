package com.biotools.poker.R;

import com.biotools.A.I;
import com.biotools.A.b;
import com.biotools.B.P;
import com.biotools.poker.PokerApp;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

public class R extends JFrame
  implements N
{
  private static final String ň = com.biotools.poker.E.D("Stats.StatsDatabase.PlayerStatisticsDatabase");
  private h ŏ;
  private B œ;
  private B ŉ;
  private B Ŋ;
  private B Œ;
  private X Ō;
  private V ő = new V();
  private U ņ = null;
  private JTabbedPane Ŏ = new JTabbedPane();
  private Timer Ő;
  private Timer ŋ;
  private volatile double Ņ = 0.0D;
  private boolean Ň = false;
  private g ō;

  public R(boolean paramBoolean)
  {
    G(ģ());
    t localt = new t();
    if (localt.A(this.ő))
      this.Ň = true;
    if (com.biotools.poker.E.Ú())
      ī();
    else
      Ĳ();
    setTitle(ň);
    setIconImage(com.biotools.poker.E.¢);
    setJMenuBar(new K(this));
    com.biotools.poker.E.A("HHDB_WINDOW", this);
    if (paramBoolean)
      setDefaultCloseOperation(3);
    else
      setDefaultCloseOperation(1);
    Ģ();
    ĭ();
    this.ő.B(this);
    this.ő.Æ();
  }

  private void ī()
  {
    String str = Z.A(U.Q, PokerApp.Ȅ().ɬ());
    Z localZ = Z.A(str);
    if (localZ == null)
    {
      str = Z.A(U.K, PokerApp.Ȅ().ɬ());
      localZ = Z.A(str);
    }
    this.ō = new g(this, localZ);
    this.Ō = new X(this.ő, null);
    this.Ŏ.add(this.ō, com.biotools.poker.E.D("Stats.StatsDatabase.Players"));
    this.Ŏ.add(this.Ō, com.biotools.poker.E.D("Stats.StatsDatabase.HandHistories"));
    JPanel localJPanel = new JPanel(new BorderLayout(2, 2));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
    localJPanel.add(this.Ŏ, "Center");
    getContentPane().add(localJPanel);
  }

  private void Ĳ()
  {
    this.œ = new B(this, false, false);
    this.ŉ = new B(this, true, false);
    this.Ŋ = new B(this, false, true);
    this.Œ = new B(this, true, true);
    this.ŏ = new h(this);
    this.Ō = new X(this.ő, null);
    this.Ŏ.add(this.ŏ, com.biotools.poker.E.D("Stats.StatsDatabase.Summary"));
    this.Ŏ.add(this.Ō, com.biotools.poker.E.D("Stats.StatsDatabase.Histories"));
    this.Ŏ.add(this.œ, com.biotools.poker.E.D("Stats.StatsDatabase.LimitRing"));
    this.Ŏ.add(this.ŉ, com.biotools.poker.E.D("Stats.StatsDatabase.NoLimitRing"));
    this.Ŏ.add(this.Ŋ, com.biotools.poker.E.D("Stats.StatsDatabase.LimitTournament"));
    this.Ŏ.add(this.Œ, com.biotools.poker.E.D("Stats.StatsDatabase.NoLimitTournament"));
    JPanel localJPanel = new JPanel(new BorderLayout(2, 2));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
    localJPanel.add(this.Ŏ, "Center");
    getContentPane().add(localJPanel);
  }

  private String ģ()
  {
    return com.biotools.poker.E.c();
  }

  protected void Ĭ()
  {
    d locald = new d(this);
  }

  private void ĩ()
  {
    synchronized (this.ő)
    {
      int i = JOptionPane.showConfirmDialog(this, com.biotools.poker.E.D("Stats.StatsDatabase.DeleteDatabaseDescription"), com.biotools.poker.E.D("Stats.StatsDatabase.DeleteDatabase"), 0);
      if (i == 0)
      {
        this.ő.clear();
        U.K().clear();
        this.Ň = true;
      }
    }
  }

  public void ğ()
  {
    com.biotools.B.R localR = com.biotools.B.R.B(com.biotools.poker.E.D("Stats.StatsDatabase.Help"));
    localR.A("statsdb.html");
  }

  public void ı()
  {
    setVisible(false);
  }

  public void Ĩ()
  {
    synchronized (this.ő)
    {
      D(this.ő);
    }
  }

  public void Ħ()
  {
    if (!com.biotools.poker.E.Ú())
      new C(this);
  }

  private void G(String paramString)
  {
    synchronized (this.ő)
    {
      try
      {
        File localFile = new File(paramString);
        int i = this.ő.A(localFile);
        if (i > 0)
          this.Ň = true;
      }
      catch (Exception localException)
      {
        I.A("Error loading hand histories", localException);
      }
    }
    this.ő.Ã();
    İ();
  }

  public void K(E paramE)
  {
    synchronized (this.ő)
    {
      this.ő.D(paramE);
    }
  }

  private void Ĥ()
  {
    Thread localThread = new Thread(į(), "Save HDB");
    localThread.setPriority(1);
    localThread.start();
  }

  private void Ģ()
  {
    this.Ő = new Timer(150, new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        Object[] arrayOfObject = { new Integer((int)(100.0D * R.this.Ņ)) };
        R.this.setTitle(R.ň + com.biotools.poker.E.A("Stats.StatsDatabase.SavingPattern", arrayOfObject));
      }
    });
    this.Ő.setRepeats(true);
  }

  private void ĭ()
  {
    this.ŋ = new Timer(60000, new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        R.this.ħ();
      }
    });
    this.ŋ.setRepeats(true);
    this.ŋ.start();
  }

  private void Į()
  {
    SwingUtilities.invokeLater(new R.3(this));
  }

  private void ĥ()
  {
    SwingUtilities.invokeLater(new R.4(this));
  }

  private Runnable į()
  {
    R.5 local5 = new R.5(this);
    return local5;
  }

  public void C(int paramInt1, int paramInt2)
  {
    if (this.ő.size() > paramInt1)
    {
      this.ő.É = false;
      while (this.ő.size() > paramInt2)
        this.ő.remove(0);
      this.ő.É = true;
      this.ő.É();
      this.Ň = true;
    }
  }

  public void İ()
  {
    U.A(this.ő);
  }

  public V Ġ()
  {
    return this.ő;
  }

  public U ġ()
  {
    return this.ņ;
  }

  public void F(U paramU)
  {
    this.ņ = paramU;
  }

  private void Ğ()
  {
    if (this.ő.È() != null)
      this.ņ = this.ő.È()._();
    else
      this.ņ = null;
  }

  protected void D(V paramV)
  {
    JFileChooser localJFileChooser = new JFileChooser();
    localJFileChooser.setSelectedFile(new File("histories.txt"));
    if (localJFileChooser.showSaveDialog(null) == 0)
    {
      File localFile = localJFileChooser.getSelectedFile();
      if (localFile != null)
      {
        Object[] arrayOfObject = { new Integer(paramV.size()) };
        P.A(this, com.biotools.poker.E.A("Stats.StatsDatabase.ExportingHandHistoriesPattern", arrayOfObject), new R.6(this, localFile, paramV));
      }
    }
  }

  public void ĳ()
  {
    this.Ŏ.setSelectedComponent(this.Ō);
  }

  public void B()
  {
    com.biotools.poker.E.H("StatsDatabase.gameRecordListChanged()");
    İ();
    this.Ň = true;
  }

  public void A()
  {
    İ();
  }

  public void A(E paramE)
  {
    synchronized (this.ő)
    {
      b.A(paramE.toString(), com.biotools.poker.E.c());
      Ğ();
    }
  }

  public void D(com.biotools.poker.G.R paramR)
  {
    if (!com.biotools.poker.E.Ú())
      this.ŏ.E(paramR);
  }

  private void ħ()
  {
    if (this.Ň)
      Ĥ();
  }

  public void Ĵ()
  {
    this.ŋ.stop();
    synchronized (this.ő)
    {
      if (this.Ň)
      {
        Runnable localRunnable = į();
        localRunnable.run();
      }
    }
  }

  public void C(V paramV)
  {
    synchronized (this.ő)
    {
      HashSet localHashSet = new HashSet();
      for (int i = 0; i < paramV.size(); i++)
        localHashSet.add(paramV.D(i)._());
      Iterator localIterator = localHashSet.iterator();
      while (localIterator.hasNext())
        D((U)localIterator.next());
      this.ő.É();
    }
  }

  private void D(U paramU)
  {
    V localV = new V();
    for (int i = 0; i < this.ő.size(); i++)
    {
      localObject = this.ő.D(i);
      if (paramU.equals(((E)localObject)._()))
        localV.add(localObject);
    }
    String str = paramU.J();
    Object localObject = paramU.D();
    if (localV.size() > 0)
    {
      paramU.A(localV.D(0), str, (String)localObject);
      int j;
      if (paramU.X())
      {
        j = ((A)paramU).c();
        for (int k = 1; k < localV.size(); k++)
          A.A(localV.D(k), j, str, (String)localObject);
      }
      else
      {
        for (j = 1; j < localV.size(); j++)
          paramU = U.B(localV.D(j), str, (String)localObject);
      }
    }
    else
    {
      paramU.C();
    }
  }

  public void B(V paramV)
  {
    synchronized (this.ő)
    {
      HashSet localHashSet = new HashSet();
      for (int i = 0; i < paramV.size(); i++)
      {
        E localE = paramV.D(i);
        localHashSet.add(localE._());
        this.ő.remove(localE);
      }
      Iterator localIterator = localHashSet.iterator();
      while (localIterator.hasNext())
        D((U)localIterator.next());
      this.ő.É();
    }
  }

  public void E(U paramU)
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramU);
    G(localArrayList);
  }

  public void G(List paramList)
  {
    if (paramList == null)
      return;
    if (paramList.size() == 0)
      return;
    Object localObject1;
    for (int i = 0; i < paramList.size(); i++)
    {
      localObject1 = (U)paramList.get(i);
      ((U)localObject1).C();
    }
    synchronized (this.ő)
    {
      localObject1 = new D(this.ő);
      ((D)localObject1).Ô();
      ((D)localObject1).C(paramList);
      ((D)localObject1).Ø();
      this.ő.removeAll((Collection)localObject1);
    }
  }

  private D Ī()
  {
    D localD = new D(PokerApp.Ȅ().ʣ());
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(ġ());
    localD.C(localArrayList);
    return localD;
  }

  public void B(Z paramZ, boolean paramBoolean)
  {
    this.ō.A(paramZ);
    if (paramBoolean)
      ġ();
    this.Ŏ.setSelectedComponent(this.ō);
    this.ō.setVisible(true);
  }

  public void A(Z paramZ, boolean paramBoolean)
  {
    if (paramZ == null)
      return;
    Object localObject;
    if ((paramBoolean) && (ġ() != null))
    {
      localObject = new s(paramZ, Ī());
      ((s)localObject).g();
      if (ġ().X())
        ((s)localObject).C(2);
      else
        ((s)localObject).C(0);
      ((s)localObject).u();
    }
    else
    {
      localObject = new D(this.ő);
      ((D)localObject).C(U.K());
      ((D)localObject).B(paramZ);
      s locals = new s(paramZ, (D)localObject);
      locals.u();
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.R
 * JD-Core Version:    0.6.2
 */