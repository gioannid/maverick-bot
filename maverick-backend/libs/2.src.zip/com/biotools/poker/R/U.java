package com.biotools.poker.R;

import com.biotools.poker.PokerApp;
import com.biotools.poker.R.C.F;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class U
  implements Comparable
{
  private static List M = new ArrayList();
  public static final DecimalFormat R = new DecimalFormat(com.biotools.poker.E.D("Stats.SessionInfo.DecimalFormatHour"));
  public static final DecimalFormat i = new DecimalFormat(com.biotools.poker.E.D("Stats.SessionInfo.DecimalFormatMinutes"));
  public static final DecimalFormat j = new DecimalFormat(com.biotools.poker.E.D("Stats.SessionInfo.DecimalFormatLimit"));
  private static final int f = 3600000;
  private static final int D = 60000;
  public static final int Z = 0;
  public static final int e = 1;
  public static final int B = 2;
  public static final int g = 3;
  public static final int k = 4;
  public static final int I = 5;
  public static final int X = 6;
  public static final int c = 7;
  public static final int _ = 8;
  public static final int L = 9;
  public static final int J = 10;
  public static final String Q = com.biotools.poker.E.Ò();
  public static final String C = com.biotools.poker.E.Õ();
  public static final String K = com.biotools.poker.E.D("Stats.SessionInfo.PokerAcademyOnline");
  public static final String H = com.biotools.poker.E.D("Stats.SessionInfo.PAOnline");
  private static HashMap O;
  protected static int U = 0;
  protected static boolean T = false;
  private static String W;
  private String G;
  private String V;
  protected boolean b = false;
  private double E = 0.25D;
  private double N = 0.5D;
  private long S = -1L;
  private long P = -1L;
  private boolean A = false;
  private int a;
  private String d = com.biotools.poker.E.D("Stats.SessionInfo.TexasHoldem");
  private ArrayList Y = new ArrayList();
  private HashMap h = new HashMap();
  private a F;

  public static List K()
  {
    return M;
  }

  public static U A(int paramInt)
  {
    return (U)K().get(paramInt);
  }

  public static U B(E paramE, String paramString1, String paramString2)
  {
    for (int m = 0; m < M.size(); m++)
    {
      U localU2 = A(m);
      if (localU2.A(paramString1, paramString2, paramE.U(), paramE.P(), paramE.J(), paramE.W()))
      {
        paramE.A(localU2);
        localU2.B(paramE);
        return localU2;
      }
    }
    U localU1 = new U();
    localU1.A(paramE, paramString1, paramString2);
    M.add(localU1);
    return localU1;
  }

  public void G()
  {
    this.S = -1L;
    this.P = -1L;
    this.a = 0;
    this.d = com.biotools.poker.E.D("Stats.SessionInfo.TexasHoldem");
    if (this.Y != null)
    {
      for (int m = 0; m < this.Y.size(); m++);
      this.Y.clear();
      this.h.clear();
    }
    this.F = null;
  }

  public void A(E paramE, String paramString1, String paramString2)
  {
    G();
    D(paramString1);
    B(paramString2);
    A(paramE.W());
    B(paramE.f());
    A(paramE.J());
    paramE.A(this);
    B(paramE);
  }

  public static void A(int paramInt, boolean paramBoolean)
  {
    U = paramInt;
    T = paramBoolean;
  }

  public static void C(String paramString)
  {
    W = paramString;
  }

  public int compareTo(Object paramObject)
  {
    int m = T ? -1 : 1;
    if (paramObject == null)
      return 0;
    U localU = (U)paramObject;
    switch (U)
    {
    case 0:
      if (this.S < localU.S)
        return 1 * m;
      if (this.S > localU.S)
        return -1 * m;
    case 1:
      return this.G.compareToIgnoreCase(localU.G) * m;
    case 2:
      return this.V.compareToIgnoreCase(localU.V) * m;
    case 5:
      String str1 = F() == null ? "~ " : F();
      String str2 = localU.F() == null ? "~" : localU.F();
      return str1.compareToIgnoreCase(str2) * m;
    case 4:
      if (this.a < localU.a)
        return 1 * m;
      if (this.a > localU.a)
        return -1 * m;
    case 7:
      if (this.P - this.S < localU.P - localU.S)
        return 1 * m;
      if (this.P - this.S > localU.P - localU.S)
        return -1 * m;
    case 6:
      if (H() < localU.H())
        return 1 * m;
      if (H() > localU.H())
        return -1 * m;
    case 3:
      if (this.N < localU.N)
        return 1 * m;
      if (this.N > localU.N)
        return -1 * m;
    case 9:
      if ((A(W) != null) && (localU.A(W) != null))
      {
        if (A(W).M() < localU.A(W).M())
          return m;
        if (A(W).M() > localU.A(W).M())
          return -m;
      }
    case 10:
      if ((A(W) != null) && (localU.A(W) != null))
      {
        if (A(W).Z() < localU.A(W).Z())
          return m;
        if (A(W).Z() > localU.A(W).Z())
          return -m;
      }
      break;
    case 8:
    }
    return 0;
  }

  public a B(int paramInt)
  {
    return (a)this.Y.get(paramInt);
  }

  public a A(String paramString)
  {
    return (a)this.h.get(paramString);
  }

  public int M()
  {
    return this.Y.size();
  }

  public double H()
  {
    if (this.F != null)
      return this.F.M();
    return 0.0D;
  }

  public String E()
  {
    if (this.b)
    {
      arrayOfObject = new Object[] { j.format(this.E), j.format(this.N) };
      return com.biotools.poker.E.A("Stats.SessionInfo.StakesNLPattern", arrayOfObject);
    }
    Object[] arrayOfObject = { j.format(this.N), j.format(this.N * 2.0D) };
    return com.biotools.poker.E.A("Stats.SessionInfo.StakesPattern", arrayOfObject);
  }

  public boolean Q()
  {
    return this.A;
  }

  public int V()
  {
    return this.a;
  }

  public String U()
  {
    long l = this.P - this.S;
    int m = (int)(l / 3600000L);
    l -= 3600000 * m;
    int n = (int)(l / 60000L);
    if (m == 0)
    {
      arrayOfObject = new Object[] { i.format(n) };
      return com.biotools.poker.E.A("Stats.SessionInfo.MinutesPattern", arrayOfObject);
    }
    Object[] arrayOfObject = { R.format(m), i.format(n) };
    return com.biotools.poker.E.A("Stats.SessionInfo.HoursMinutesPattern", arrayOfObject);
  }

  public long I()
  {
    return this.S;
  }

  public long L()
  {
    return this.P;
  }

  public String J()
  {
    return this.G;
  }

  public String O()
  {
    return E(J());
  }

  private static HashMap B()
  {
    if (O == null)
    {
      O = new HashMap();
      O.put(K, H);
      O.put(com.biotools.poker.E.D("Meerkat.ProductNamePro"), com.biotools.poker.E.D("Meerkat.ProductNameProAbrv"));
      O.put(com.biotools.poker.E.D("Meerkat.ProductNameLight"), com.biotools.poker.E.D("Meerkat.ProductNameLightAbrv"));
      Object[] arrayOfObject1 = { com.biotools.poker.E.D("Meerkat.ProductNamePro") };
      Object[] arrayOfObject2 = { com.biotools.poker.E.D("Meerkat.ProductNameProAbrv") };
      Object[] arrayOfObject3 = { com.biotools.poker.E.D("Meerkat.ProductNameLight") };
      Object[] arrayOfObject4 = { com.biotools.poker.E.D("Meerkat.ProductNameLightAbrv") };
      O.put(com.biotools.poker.E.A("Meerkat.ProductNameDemoSuffixPattern", arrayOfObject1), com.biotools.poker.E.A("Meerkat.ProductNameDemoSuffixPattern", arrayOfObject2));
      O.put(com.biotools.poker.E.A("Meerkat.ProductNameDemoSuffixPattern", arrayOfObject3), com.biotools.poker.E.A("Meerkat.ProductNameDemoSuffixPattern", arrayOfObject4));
      F[] arrayOfF = F.W();
      for (int m = 0; m < arrayOfF.length; m++)
        if ((arrayOfF[m].R() != null) && (arrayOfF[m].R() != ""))
          O.put(arrayOfF[m].G(), arrayOfF[m].R());
    }
    return O;
  }

  public static String E(String paramString)
  {
    if (paramString != null)
    {
      if (B().containsKey(paramString))
        return (String)B().get(paramString);
      return paramString;
    }
    return "";
  }

  public String P()
  {
    return this.d;
  }

  public void D(String paramString)
  {
    this.G = paramString;
  }

  public void A(double paramDouble)
  {
    this.N = paramDouble;
  }

  public double T()
  {
    return this.N;
  }

  public void B(double paramDouble)
  {
    this.E = paramDouble;
  }

  public String D()
  {
    return this.V;
  }

  public void B(String paramString)
  {
    this.V = paramString;
  }

  public boolean A(String paramString1, String paramString2, String paramString3, long paramLong, boolean paramBoolean, double paramDouble)
  {
    if (!paramString1.equals(this.G))
      return false;
    if (!paramString2.equals(this.V))
      return false;
    if (X())
      return false;
    if ((paramString3 != null) && (W() != null) && (!W().Q().equals(paramString3)))
      return false;
    if (paramLong < this.S - 3600000L)
      return false;
    if (paramLong > this.P + 3600000L)
      return false;
    if (paramDouble != this.N)
      return false;
    return paramBoolean == this.b;
  }

  public void B(E paramE)
  {
    if ((paramE.P() < this.S) || (this.S <= 0L))
      this.S = paramE.P();
    if ((paramE.P() > this.P) || (this.P < 0L))
      this.P = paramE.P();
    this.a += 1;
    A(paramE);
  }

  private void A(E paramE)
  {
    for (int m = 0; m < 10; m++)
      if (paramE.G(m))
      {
        a locala = (a)this.h.get(paramE.J(m));
        if (locala == null)
        {
          locala = a.A(this, paramE.J(m));
          this.h.put(paramE.J(m), locala);
          this.Y.add(locala);
          Z localZ = Z.C(locala);
          locala.A(localZ);
          locala.A(paramE, m);
          if (locala.I())
            A(locala);
        }
        else
        {
          locala.A(paramE, m);
        }
      }
  }

  private void A(a parama)
  {
    if (this.F != null)
      com.biotools.poker.E.H("ERROR: two hero's within the same session!");
    this.F = parama;
  }

  public a W()
  {
    return this.F;
  }

  public String F()
  {
    if (this.F == null)
      return null;
    return this.F.Q();
  }

  public static boolean A(V paramV)
  {
    for (int m = 0; m < M.size(); m++)
    {
      U localU1 = A(m);
      if (!(localU1 instanceof A))
        for (int n = m + 1; n < M.size(); n++)
        {
          U localU2 = A(n);
          if ((!(localU2 instanceof A)) && ((localU1.A(localU2.J(), localU2.D(), localU2.F(), localU2.I(), localU2.R(), localU2.T())) || (localU1.A(localU2.J(), localU2.D(), localU2.F(), localU2.L(), localU2.R(), localU2.T()))))
          {
            A(localU1, localU2, paramV);
            A(paramV);
            return true;
          }
        }
    }
    return false;
  }

  public static void A(U paramU1, U paramU2, V paramV)
  {
    System.out.println("MERGING: " + paramU1 + " and " + paramU2);
    for (int m = 0; m < paramV.size(); m++)
    {
      E localE = paramV.D(m);
      if (localE._() == paramU2)
      {
        localE.A(paramU1);
        paramU1.B(localE);
      }
    }
    M.remove(paramU2);
  }

  public String toString()
  {
    Object[] arrayOfObject = { new Date(this.S), new Date(this.P), this.G, this.V };
    return com.biotools.poker.E.A("Stats.SessionInfo.DateStringPattern", arrayOfObject);
  }

  public String N()
  {
    Object[] arrayOfObject = { E(this.G), this.V, new Date(this.S) };
    return com.biotools.poker.E.A("Stats.SessionInfo.TitleStringPattern", arrayOfObject);
  }

  public void B(boolean paramBoolean)
  {
    this.A = paramBoolean;
  }

  public void S()
  {
    this.S = System.currentTimeMillis();
    this.P = System.currentTimeMillis();
  }

  public void A(boolean paramBoolean)
  {
    this.b = paramBoolean;
  }

  public boolean R()
  {
    return this.b;
  }

  public void C()
  {
    if (equals(PokerApp.Ȅ().ǳ()))
    {
      G();
      S();
    }
    else
    {
      K().remove(this);
    }
  }

  public boolean X()
  {
    return false;
  }

  public boolean A()
  {
    return !X();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.U
 * JD-Core Version:    0.6.2
 */