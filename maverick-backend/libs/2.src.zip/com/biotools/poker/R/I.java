package com.biotools.poker.R;

import com.biotools.B.J;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.util.PreferenceChangeEvent;
import com.biotools.meerkat.util.PreferenceChangeListener;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.G.T;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class I extends F
  implements N, PreferenceChangeListener
{
  private JButton ÿ = new J("del.png", com.biotools.poker.E.D("Stats.SiteSummary.DeleteDescription"));
  private JButton ü = new J("hand.png", com.biotools.poker.E.D("Stats.SiteSummary.HandDescription"));
  private List þ;
  private int û = -1;
  private R ù;
  private HashMap ý = new HashMap();
  private JPanel ú;
  private boolean Ā = false;

  public I(R paramR)
  {
    this.ù = paramR;
    this.ù.Ġ().B(this);
    com.biotools.poker.E.£().addPreferenceChangeListener(this);
    this.ø.addMouseListener(new MouseAdapter()
    {
      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        if (paramAnonymousMouseEvent.getClickCount() == 2)
        {
          I.this.ë();
          return;
        }
      }
    });
    this.ø.getSelectionModel().addListSelectionListener(new ListSelectionListener()
    {
      public void valueChanged(ListSelectionEvent paramAnonymousListSelectionEvent)
      {
        I.this.ð();
      }
    });
    TableColumn localTableColumn = this.ø.getColumnModel().getColumn(0);
    if (localTableColumn != null)
    {
      localTableColumn.setMinWidth(60);
      localTableColumn.setMaxWidth(60);
    }
    localTableColumn = this.ø.getColumnModel().getColumn(1);
    if (localTableColumn != null)
      localTableColumn.setMinWidth(110);
    add(ó(), "East");
    this.ÿ.setEnabled(false);
    this.ü.setEnabled(false);
    ð();
  }

  public Dimension ã()
  {
    return new Dimension(480, 100);
  }

  private void ð()
  {
    if (this.ø.getSelectedRow() == -1)
    {
      this.û = -1;
      this.ø.getSelectionModel().clearSelection();
      this.ÿ.setEnabled(false);
      this.ü.setEnabled(false);
    }
    else
    {
      this.û = this.ø.getSelectedRow();
      _B local_B = L(this.û);
      this.ÿ.setEnabled(true);
      this.ü.setEnabled(true);
    }
  }

  private void ë()
  {
    if (this.ø.getSelectedRow() >= 0)
    {
      _B local_B = L(this.ø.getSelectedRow());
      D localD = new D(í());
      localD.A(local_B.A);
      X localX = new X(localD, null);
      localX.ł();
      localX.H(local_B.A);
    }
  }

  private _B L(int paramInt)
  {
    return (_B)á().get(paramInt);
  }

  public List á()
  {
    if (this.þ == null)
      this.þ = new ArrayList();
    return this.þ;
  }

  public void preferenceChange(PreferenceChangeEvent paramPreferenceChangeEvent)
  {
    if ((paramPreferenceChangeEvent.getKey() == "POSITIVE_COLOR") || (paramPreferenceChangeEvent.getKey() == "NEUTRAL_COLOR") || (paramPreferenceChangeEvent.getKey() == "NEGATIVE_COLOR"))
      repaint();
  }

  public Component A(Component paramComponent, int paramInt1, int paramInt2)
  {
    if (paramInt2 > 0)
    {
      _B local_B = L(paramInt1);
      A(paramComponent, paramInt1, local_B.F + local_B.C);
    }
    else
    {
      paramComponent.setBackground(getBackground());
    }
    return paramComponent;
  }

  public AbstractTableModel å()
  {
    return new _A(á());
  }

  public void ñ()
  {
    this.ý.clear();
    V localV = this.ù.Ġ();
    for (int i = 0; i < localV.size(); i++)
    {
      E localE = localV.D(i);
      G(localE);
    }
    ò();
    î();
  }

  public void ò()
  {
    com.biotools.poker.E.H("SiteSummary.updateTournaments()");
    Object localObject;
    for (int i = 0; i < á().size(); i++)
    {
      localObject = L(i);
      ((_B)localObject).C = 0.0D;
      ((_B)localObject).I = 0;
      ((_B)localObject).E = 0.0D;
    }
    for (i = 0; i < U.K().size(); i++)
    {
      localObject = U.A(i);
      if ((localObject instanceof A))
      {
        A localA = (A)localObject;
        localA.Z();
        _B local_B = (_B)this.ý.get(localA.J());
        if ((local_B != null) && (localA._() != -1))
        {
          local_B.C += localA.a();
          local_B.I += 1;
          local_B.E += localA.b().Q().M();
        }
        else if (local_B == null)
        {
          local_B = null;
        }
      }
    }
  }

  public void B(com.biotools.poker.G.R paramR)
  {
    ò();
    î();
  }

  private void G(E paramE)
  {
    _B local_B = (_B)this.ý.get(paramE._().J());
    if (local_B == null)
    {
      local_B = new _B();
      local_B.A = paramE._().J();
      this.ý.put(paramE._().J(), local_B);
    }
    local_B.J.add(paramE._());
    local_B.H += 1;
    if ((paramE.a() >= 0) && (!paramE.O()))
    {
      local_B.F += paramE.W() * paramE.C(paramE.a());
      if (paramE.a() != -1)
        local_B.G += paramE.Q(paramE.a());
    }
    for (int i = 0; i < paramE.c(); i++)
      if (paramE.G(i))
        local_B.B.add(paramE.J(i));
  }

  private void ï()
  {
    if (this.ø.getSelectedRow() >= 0)
    {
      _B local_B = L(this.ø.getSelectedRow());
      Object[] arrayOfObject = { local_B.A };
      int i = JOptionPane.showConfirmDialog(this, com.biotools.poker.E.A("Stats.SiteSummary.DeleteSiteStatsDescriptionPattern", arrayOfObject), com.biotools.poker.E.D("Stats.SiteSummary.DeleteSiteStats"), 0);
      if (i == 0)
      {
        ArrayList localArrayList = new ArrayList();
        Iterator localIterator = U.K().iterator();
        while (localIterator.hasNext())
        {
          U localU = (U)localIterator.next();
          if (localU.J().equals(local_B.A))
            localArrayList.add(localU);
        }
        this.ù.G(localArrayList);
        this.û = -1;
      }
    }
  }

  private V í()
  {
    return this.ù.Ġ();
  }

  private void A(_B param_B, boolean paramBoolean)
  {
    if (this.Ā)
      return;
    this.Ā = true;
    param_B.D = (!paramBoolean);
    for (int i = 0; i < U.K().size(); i++)
      if (U.A(i).J().equals(param_B.A))
        U.A(i).B(paramBoolean);
    this.ù.Ġ().Æ();
    this.Ā = false;
  }

  private JPanel ó()
  {
    this.ÿ.setToolTipText(com.biotools.poker.E.D("Stats.SiteSummary.DeleteAllHands"));
    this.ÿ.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        I.this.ï();
      }
    });
    this.ü.setToolTipText(com.biotools.poker.E.D("Stats.SiteSummary.ViewAllHands"));
    this.ü.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        I.this.ë();
      }
    });
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 1));
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.add(this.ü);
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.add(this.ÿ);
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(1, 4, 1, 1));
    this.ú = localJPanel;
    return localJPanel;
  }

  public void B()
  {
    if (this.Ā)
      return;
    com.biotools.poker.E.H("SiteSummary.gameRecordListChanged()");
    ñ();
  }

  public void A()
  {
    if (this.Ā)
      return;
    com.biotools.poker.E.H("SiteSummary.gameFiltersChanged()");
    ñ();
  }

  public void A(E paramE)
  {
    if (this.Ā)
      return;
    G(paramE);
    î();
  }

  private void î()
  {
    á().clear();
    Iterator localIterator = this.ý.keySet().iterator();
    while (localIterator.hasNext())
      á().add(this.ý.get(localIterator.next()));
    è().fireTableDataChanged();
  }

  protected void ì()
  {
    com.biotools.poker.E.H("DISPOSE SESSION SITE SUMMARY");
    com.biotools.poker.E.£().removePreferenceChangeListener(this);
  }

  public class _A extends j
  {
    private String[] c = { com.biotools.poker.E.D("Stats.SiteSummary.Enable"), com.biotools.poker.E.D("Stats.SiteSummary.Site"), com.biotools.poker.E.D("Stats.SiteSummary.Abbreviation"), com.biotools.poker.E.D("Stats.SiteSummary.Hands"), com.biotools.poker.E.D("Stats.SiteSummary.Sessions"), com.biotools.poker.E.D("Stats.SiteSummary.Players"), com.biotools.poker.E.D("Stats.SiteSummary.NetWon"), com.biotools.poker.E.D("Stats.SiteSummary.MoneyRaked") };
    private String[] b = { 0, 0, 0, 0, 0, 0, com.biotools.poker.E.D("Stats.SiteSummary.NetWonByHeros"), com.biotools.poker.E.D("Stats.SiteSummary.NetPaidByHeros") };

    public _A(List arg2)
    {
      super();
    }

    public String[] A()
    {
      return this.c;
    }

    public String B(int paramInt)
    {
      return this.b[paramInt];
    }

    public boolean isCellEditable(int paramInt1, int paramInt2)
    {
      return paramInt2 == 0;
    }

    public void setValueAt(Object paramObject, int paramInt1, int paramInt2)
    {
      if (paramInt2 == 0)
      {
        boolean bool = ((Boolean)paramObject).booleanValue();
        I._B local_B = I.this.L(paramInt1);
        I.this.A(local_B, !bool);
        fireTableCellUpdated(paramInt1, paramInt2);
      }
    }

    public Object getValueAt(int paramInt1, int paramInt2)
    {
      I._B local_B = (I._B)A(paramInt1);
      switch (paramInt2)
      {
      case 0:
        return new Boolean(local_B.D);
      case 1:
        return local_B.A;
      case 2:
        return U.E(local_B.A);
      case 3:
        return new Integer(local_B.H);
      case 4:
        return new Integer(local_B.J.size());
      case 5:
        return new Integer(local_B.B.size());
      case 6:
        return Action.formatCash(local_B.C + local_B.F);
      case 7:
        return Action.formatCash(local_B.G + local_B.E);
      }
      return "";
    }
  }

  public class _B
    implements Comparable
  {
    String A;
    HashSet B = new HashSet();
    HashSet J = new HashSet();
    int I;
    int H;
    double G;
    double E;
    double F;
    double C;
    boolean D = true;

    public _B()
    {
    }

    public int compareTo(Object paramObject)
    {
      return 0;
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.I
 * JD-Core Version:    0.6.2
 */