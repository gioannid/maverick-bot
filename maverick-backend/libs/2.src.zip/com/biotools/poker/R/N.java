package com.biotools.poker.R;

public abstract interface N
{
  public abstract void B();

  public abstract void A();

  public abstract void A(E paramE);
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.N
 * JD-Core Version:    0.6.2
 */