package com.biotools.poker.R;

import java.text.DecimalFormat;
import javax.swing.table.AbstractTableModel;

public class b$_C extends AbstractTableModel
{
  private String[] A = { com.biotools.poker.E.D("Stats.HistoryTable.Game"), com.biotools.poker.E.D("Stats.HistoryTable.Players"), com.biotools.poker.E.D("Stats.HistoryTable.NetSB"), com.biotools.poker.E.D("Stats.HistoryTable.Hand"), com.biotools.poker.E.D("Stats.HistoryTable.Board") };
  final b this$0;

  public b$_C(b paramb)
  {
  }

  public String getColumnName(int paramInt)
  {
    return this.A[paramInt].toString();
  }

  public int getRowCount()
  {
    return this.this$0.ö().size();
  }

  public int getColumnCount()
  {
    return this.A.length;
  }

  public Object getValueAt(int paramInt1, int paramInt2)
  {
    E localE = this.this$0.N(paramInt1);
    switch (paramInt2)
    {
    case 0:
      return " #" + localE.h();
    case 1:
      return " " + localE.b();
    case 2:
      return b.ď.format(b.access$0(this.this$0, localE)) + " ";
    case 3:
      return b.access$1(this.this$0, localE);
    case 4:
      return localE.H();
    }
    return "";
  }

  public Class getColumnClass(int paramInt)
  {
    return getValueAt(0, paramInt).getClass();
  }

  public boolean isCellEditable(int paramInt1, int paramInt2)
  {
    return false;
  }

  public void setValueAt(Object paramObject, int paramInt1, int paramInt2)
  {
    fireTableCellUpdated(paramInt1, paramInt2);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.b._C
 * JD-Core Version:    0.6.2
 */