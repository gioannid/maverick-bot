package com.biotools.poker.R;

import java.awt.BorderLayout;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JSplitPane;

public class B extends JPanel
  implements N, Q
{
  private R Å;
  private M È;
  private c Æ;
  private D Ç;

  public B(R paramR, boolean paramBoolean1, boolean paramBoolean2)
  {
    this.Å = paramR;
    this.Ç = new D(paramR.Ġ());
    this.Ç.A(paramBoolean1, paramBoolean2);
    Â();
  }

  public boolean Á()
  {
    return (this.Ç.ß() == 4) || (this.Ç.ß() == 3);
  }

  public boolean º()
  {
    return (this.Ç.ß() == 4) || (this.Ç.ß() == 2);
  }

  public B(R paramR)
  {
    this.Å = paramR;
    Â();
  }

  private void Â()
  {
    this.Å.Ġ().B(this);
    this.È = new M(this.Å, this.Ç);
    this.È.A(this);
    this.Æ = new c(this.Å.Ġ(), º(), Á());
    String str = D.ñ[this.Ç.ß()];
    Object[] arrayOfObject = { str };
    this.È.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5), com.biotools.poker.E.A("Stats.SessionSummary.SessionsPattern", arrayOfObject) + " "));
    this.Æ.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5), com.biotools.poker.E.D("Stats.SessionSummary.Players") + " "));
    JSplitPane localJSplitPane = new JSplitPane(0, this.È, this.Æ);
    setLayout(new BorderLayout());
    add(localJSplitPane, "Center");
  }

  public R À()
  {
    return this.Å;
  }

  public void A(E paramE)
  {
    this.Æ.ć();
  }

  public void B()
  {
    this.Æ.ć();
  }

  public void A()
  {
    B();
  }

  public void A(List paramList)
  {
    if ((this.Æ != null) && (paramList != null))
      this.Æ.D(paramList);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.B
 * JD-Core Version:    0.6.2
 */