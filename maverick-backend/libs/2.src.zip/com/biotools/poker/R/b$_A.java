package com.biotools.poker.R;

import com.biotools.meerkat.Hand;
import com.biotools.poker.F.R;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

public class b$_A
  implements TableCellRenderer
{
  int A;
  final b this$0;

  public b$_A(b paramb, int paramInt)
  {
    this.A = paramInt;
  }

  public Component getTableCellRendererComponent(JTable paramJTable, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2)
  {
    JPanel localJPanel = new JPanel(new GridLayout(1, this.A, 2, 2));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(2, 4, 2, 4));
    Hand localHand = (Hand)paramObject;
    if (localHand == null)
      localHand = new Hand();
    for (int i = 0; i < this.A; i++)
      if (i < localHand.size())
        localJPanel.add(new R(localHand.getCard(i + 1)));
      else
        localJPanel.add(Box.createRigidArea(new Dimension(5, 5)));
    if (paramBoolean1)
    {
      localJPanel.setForeground(paramJTable.getSelectionForeground());
      localJPanel.setBackground(paramJTable.getSelectionBackground());
    }
    else
    {
      localJPanel.setForeground(paramJTable.getForeground());
      localJPanel.setBackground(paramJTable.getBackground());
    }
    return localJPanel;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.b._A
 * JD-Core Version:    0.6.2
 */