package com.biotools.poker.R;

import com.biotools.A.F;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

public class D extends V
  implements N
{
  private boolean Ü = true;
  private V ë;
  private H â;
  private boolean Ò = false;
  private List Õ = null;
  private int Ô = -1;
  private int Ó = -1;
  private int ê = -1;
  private int î = 0;
  private String Ø = null;
  private String Ð = null;
  private String Ý = null;
  private String ð = null;
  private int Ñ = 0;
  private boolean æ = true;
  private boolean Û = true;
  private boolean ß = true;
  private boolean è = true;
  private long ç = -1L;
  private long Ù = -1L;
  public static final int í = 0;
  public static final int Ï = 1;
  public static final int å = 2;
  public static final int ó = 3;
  public static final int é = 4;
  public static final int Ú = 5;
  public static final int ä = 6;
  public static final int Í = 7;
  public static final int á = 8;
  public static final int Ö = 9;
  protected static final String[] ñ = { com.biotools.poker.E.D("FilteredGameList.AllGames"), com.biotools.poker.E.D("FilteredGameList.LimitRing"), com.biotools.poker.E.D("FilteredGameList.NoLimitRing"), com.biotools.poker.E.D("FilteredGameList.LimitTournament"), com.biotools.poker.E.D("FilteredGameList.NoLimitTournament") };
  public static final int ã = -1;
  public static final int ì = 0;
  public static final int Þ = 1;
  public static final int ï = 2;
  public static final int ò = 3;
  static int Î = 0;
  int à = this.Ë++;

  public D(V paramV)
  {
    this.ë = paramV;
    this.ë.B(this);
    this.Ü = true;
  }

  private boolean F(E paramE)
  {
    for (int i = 0; i < size(); i++)
    {
      E localE = D(i);
      if (paramE == localE)
        return true;
    }
    return false;
  }

  public void D(E paramE)
  {
    if ((E(paramE)) && (!F(paramE)))
      super.D(paramE);
  }

  public int size()
  {
    if (this.Ü)
      Ê();
    if ((this.Ô != -1) && (this.Ô < super.size()))
      return this.Ô;
    return super.size();
  }

  public int Ù()
  {
    if (this.Ü)
      Ê();
    return super.size();
  }

  public int Ñ()
  {
    return this.ë.size();
  }

  public E D(int paramInt)
  {
    if (this.Ü)
      Ê();
    if ((this.Ô != -1) && (this.Ô < super.size()))
      paramInt += super.size() - this.Ô;
    return (E)super.get(paramInt);
  }

  public void F(int paramInt)
  {
    if (paramInt != this.Ô)
    {
      this.Ô = paramInt;
      this.Ü = true;
    }
  }

  public void B(Z paramZ)
  {
    if (paramZ == null)
      return;
    if ((paramZ != null) && (this.Ø != null) && (paramZ.T().equals(this.Ø)) && (paramZ.J().equals(this.Ð)))
      return;
    this.Ø = paramZ.T();
    this.Ð = paramZ.J();
    this.Ü = true;
  }

  public void C(List paramList)
  {
    this.Õ = paramList;
    this.Ü = true;
  }

  public void H(int paramInt)
  {
    if (this.Ñ != paramInt)
    {
      this.Ñ = paramInt;
      this.Ü = true;
    }
  }

  public void A(boolean paramBoolean1, boolean paramBoolean2)
  {
    if (paramBoolean2)
    {
      if (paramBoolean1)
      {
        H(4);
        C(false);
        D(true);
        F(false);
        B(true);
      }
      else
      {
        H(3);
        C(false);
        D(true);
        F(true);
        B(false);
      }
    }
    else if (paramBoolean1)
    {
      H(2);
      C(true);
      D(false);
      F(false);
      B(true);
    }
    else
    {
      H(1);
      C(true);
      D(false);
      F(true);
      B(false);
    }
  }

  public void C(boolean paramBoolean)
  {
    if (this.æ != paramBoolean)
      this.Ü = true;
    this.æ = paramBoolean;
  }

  public void D(boolean paramBoolean)
  {
    if (this.Û != paramBoolean)
      this.Ü = true;
    this.Û = paramBoolean;
  }

  public void F(boolean paramBoolean)
  {
    if (this.ß != paramBoolean)
      this.Ü = true;
    this.ß = paramBoolean;
  }

  public void B(boolean paramBoolean)
  {
    if (this.è != paramBoolean)
      this.Ü = true;
    this.è = paramBoolean;
  }

  public synchronized void Ø()
  {
    if (this.Ü)
      Ê();
  }

  private synchronized void Ê()
  {
    long l = F.A();
    clear();
    for (int i = 0; i < this.ë.size(); i++)
      if (E(this.ë.D(i)))
        add(this.ë.D(i));
    this.Ü = false;
    com.biotools.poker.E.H("Filtered " + this.ë.size() + " => " + size() + ", " + F.A(l) / 1000.0D + "s");
    É();
  }

  public synchronized boolean C(U paramU)
  {
    if ((this.Õ != null) && (this.Õ.size() != 0))
    {
      int i = 0;
      Iterator localIterator = this.Õ.iterator();
      while ((localIterator.hasNext()) && (i == 0))
        if (paramU == localIterator.next())
          i = 1;
      if (i == 0)
        return false;
    }
    if ((this.Ý != null) && (!this.Ý.equals(paramU.D())))
      return false;
    if ((this.ð != null) && (!this.ð.equals(paramU.E())))
      return false;
    if ((this.Ð != null) && (!paramU.J().equals(this.Ð)))
      return false;
    return B(paramU);
  }

  public synchronized boolean E(E paramE)
  {
    if (paramE.Y())
      return false;
    if (this.Ó != -1)
    {
      if (paramE.b() < this.Ó)
        return false;
      if (paramE.b() > this.ê)
        return false;
    }
    if ((this.â != null) && (!this.â.A(this.Ø, paramE)))
      return false;
    if (this.Ø != null)
    {
      int i = paramE.B(this.Ø);
      if (!paramE.G(i))
        return false;
      int j;
      int k;
      if (this.Ò)
      {
        j = paramE.A(i, 'c', -1);
        k = paramE.A(i, 'b', -1);
        int m = paramE.A(i, 'r', -1);
        if (j + k + m == 0)
          return false;
      }
      if (this.î != 0)
        if (this.î == 1)
        {
          if (i != paramE.C())
            return false;
        }
        else if (this.î == 2)
        {
          if (i != paramE.F())
            return false;
        }
        else if (this.î == 3)
        {
          if (i != paramE.i())
            return false;
        }
        else
        {
          if (this.î > paramE.b())
            return false;
          j = 1;
          k = paramE.C();
          while (k != i)
          {
            k = paramE.D(k);
            j++;
          }
          if (j != this.î)
            return false;
        }
    }
    if ((this.ç != -1L) && (paramE.P() < this.ç))
      return false;
    if ((this.Ù != -1L) && (paramE.P() > this.Ù))
      return false;
    return C(paramE._());
  }

  public void B(String paramString)
  {
    if (A(paramString, this.Ý))
    {
      this.Ý = paramString;
      this.Ü = true;
    }
  }

  public void J(int paramInt)
  {
    if (this.î != paramInt)
    {
      this.î = paramInt;
      this.Ü = true;
    }
  }

  public void G(int paramInt)
  {
    A(paramInt, paramInt);
  }

  public void A(int paramInt1, int paramInt2)
  {
    if ((paramInt1 != this.Ó) || (paramInt2 != this.ê))
    {
      this.Ó = paramInt1;
      this.ê = paramInt2;
      this.Ü = true;
    }
  }

  public void I(int paramInt)
  {
    if (this.ê != paramInt)
    {
      this.Ó = Math.min(this.Ó, paramInt);
      this.ê = paramInt;
      this.Ü = true;
    }
  }

  public void E(int paramInt)
  {
    if (paramInt != this.Ó)
    {
      this.Ó = paramInt;
      this.ê = Math.max(this.ê, paramInt);
      this.Ü = true;
    }
  }

  public void A(long paramLong)
  {
    if (this.ç != paramLong)
    {
      this.ç = paramLong;
      this.Ü = true;
    }
  }

  public void B(long paramLong)
  {
    if (paramLong != this.Ù)
    {
      this.Ù = paramLong;
      this.Ü = true;
    }
  }

  public H Î()
  {
    return this.â;
  }

  public void A(H paramH)
  {
    this.â = paramH;
    this.Ü = true;
  }

  public boolean Ì()
  {
    return this.Ò;
  }

  public void E(boolean paramBoolean)
  {
    if (paramBoolean != this.Ò)
    {
      this.Ò = paramBoolean;
      this.Ü = true;
    }
  }

  private boolean B(U paramU)
  {
    if (this.Ñ == 0)
    {
      if ((!this.æ) && (paramU.A()))
        return false;
      if ((!this.Û) && (paramU.X()))
        return false;
      if ((!this.ß) && (!paramU.R()))
        return false;
      return (this.è) || (!paramU.R());
    }
    if (this.Ñ == 1)
    {
      if ((paramU.R()) || (paramU.X()))
        return false;
    }
    else if (this.Ñ == 3)
    {
      if ((paramU.R()) || (paramU.A()))
        return false;
    }
    else if (this.Ñ == 2)
    {
      if ((!paramU.R()) || (paramU.X()))
        return false;
    }
    else if ((this.Ñ == 4) && ((!paramU.R()) || (paramU.A())))
      return false;
    return true;
  }

  public void B()
  {
    this.Ü = true;
    boolean bool = this.É;
    this.É = false;
    Ø();
    this.É = bool;
    Æ();
  }

  public void A(E paramE)
  {
    D(paramE);
  }

  public void A()
  {
    this.Ü = true;
    boolean bool = this.É;
    this.É = false;
    Ø();
    this.É = bool;
    Æ();
  }

  public void Ç()
  {
    com.biotools.poker.E.H("FilteredGameList.dispose(" + this.à + ")");
    this.ë.C(this);
    this.Ê.clear();
    clear();
  }

  public void Ô()
  {
    this.ë.C(this);
  }

  public V Í()
  {
    return this.ë;
  }

  public V Ö()
  {
    if ((this.ë instanceof D))
      return ((D)this.ë).Ö();
    return this.ë;
  }

  public String Ð()
  {
    return this.Ø;
  }

  public String Ë()
  {
    return this.Ý;
  }

  public List Ü()
  {
    return this.Õ;
  }

  private boolean A(String paramString1, String paramString2)
  {
    if ((paramString1 == null) || (paramString2 == null))
      return paramString1 != paramString2;
    return !paramString1.equals(paramString2);
  }

  public void C(String paramString)
  {
    if (A(paramString, this.ð))
    {
      this.ð = paramString;
      this.Ü = true;
    }
  }

  public int ß()
  {
    return this.Ñ;
  }

  public void A(String paramString)
  {
    if (A(paramString, this.Ð))
    {
      this.Ð = paramString;
      this.Ü = true;
    }
  }

  public void Ú()
  {
    List localList = Ó();
    Iterator localIterator = localList.iterator();
    V localV = new V();
    while (localIterator.hasNext())
    {
      U localU = (U)localIterator.next();
      for (int i = 0; i < this.ë.size(); i++)
      {
        E localE = this.ë.D(i);
        if (localU.equals(localE._()))
          localV.add(localE);
      }
    }
    this.ë = localV;
  }

  public int Ý()
  {
    if (size() == 0)
      return 0;
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < size(); i++)
    {
      int j = 0;
      for (int k = 0; k < localArrayList.size(); k++)
        if (localArrayList.get(k).equals(D(i)._()))
          j = 1;
      if (j == 0)
        localArrayList.add(D(i)._());
    }
    return localArrayList.size();
  }

  public int Þ()
  {
    if (size() == 0)
      return 0;
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < size(); i++)
      if (!D(i)._().X())
      {
        int j = 0;
        for (int k = 0; k < localArrayList.size(); k++)
          if (localArrayList.get(k).equals(D(i)._()))
            j = 1;
        if (j == 0)
          localArrayList.add(D(i)._());
      }
    return localArrayList.size();
  }

  public List Ó()
  {
    if (size() == 0)
      return null;
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < size(); i++)
    {
      int j = 0;
      for (int k = 0; k < localArrayList.size(); k++)
        if (localArrayList.get(k).equals(D(i)._()))
          j = 1;
      if (j == 0)
        localArrayList.add(D(i)._());
    }
    return localArrayList;
  }

  public int Ò()
  {
    if (size() == 0)
      return 0;
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < size(); i++)
      if (D(i)._().X())
      {
        int j = 0;
        for (int k = 0; k < localArrayList.size(); k++)
          if (localArrayList.get(k).equals(D(i)._()))
            j = 1;
        if (j == 0)
          localArrayList.add(D(i)._());
      }
    return localArrayList.size();
  }

  public boolean Û()
  {
    if (size() == 0)
      return false;
    U localU = D(0)._();
    if (!localU.equals(È()._()))
      return false;
    for (int i = 1; i < size(); i++)
      if (!localU.equals(D(i)._()))
        return false;
    return true;
  }

  public boolean Õ()
  {
    if (size() != 0)
      return (D(0)._().X()) && (È()._().X()) && (Û());
    return false;
  }

  public boolean Ï()
  {
    if (size() != 0)
      return (!D(0)._().X()) && (!È()._().X()) && (Û());
    return false;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.D
 * JD-Core Version:    0.6.2
 */