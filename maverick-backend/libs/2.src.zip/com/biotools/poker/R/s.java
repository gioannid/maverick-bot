package com.biotools.poker.R;

import com.biotools.A.b;
import com.biotools.B.L;
import com.biotools.meerkat.Action;
import com.biotools.poker.G.G;
import com.biotools.poker.G.T;
import com.biotools.poker.PokerApp;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.SwingUtilities;

public class s extends JPanel
  implements ItemListener, N, Q
{
  private static int k = 0;
  private static final String ¥ = com.biotools.poker.E.D("Stats.PlayerStatsWindow.Graph");
  private static final String Á = com.biotools.poker.E.D("Stats.PlayerStatsWindow.RingGame");
  private static final String z = com.biotools.poker.E.D("Stats.PlayerStatsWindow.Tournament");
  private static final String h = "SESSIONS";
  private static final String ¤ = "HANDS";
  private Z Ã;
  private List w;
  private D f;
  private com.A.C.A g;
  private com.A.C.B d = new com.A.C.B(com.biotools.poker.E.D("Stats.PlayerStatsWindow.Bankroll"), Color.RED);
  private com.A.B.A ª;
  private Y v;
  private l À;
  private J t;
  private r e;
  private CardLayout j;
  private CardLayout l;
  private JPanel Ä;
  private JPanel º;
  private JComboBox o = new JComboBox(D.ñ);
  private JComboBox r = new JComboBox();
  private JComboBox u = new JComboBox();
  private JLabel q;
  private JToggleButton s;
  private JToggleButton p;
  private JPanel µ;
  ImageIcon n = new ImageIcon(com.biotools.poker.E.K("pix/playerstat-session-on.png").getPath());
  ImageIcon c = new ImageIcon(com.biotools.poker.E.K("pix/playerstat-session-off.png").getPath());
  ImageIcon Â = new ImageIcon(com.biotools.poker.E.K("pix/playerstat-hand-on.png").getPath());
  ImageIcon i = new ImageIcon(com.biotools.poker.E.K("pix/playerstat-hand-off.png").getPath());
  private boolean ¢ = false;
  private JFrame £;
  private JMenuBar m;

  public s(Z paramZ, D paramD)
  {
    k += 1;
    this.f = paramD;
    this.Ã = paramZ;
    paramD.B(paramZ);
    List localList = paramD.Ü();
    this.w = localList;
    paramD.C(null);
    r().F(localList);
    r().ê();
    r().K(0);
    setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
    setLayout(new BorderLayout(2, 2));
    add(q(), "North");
    add(i(), "Center");
    this.o.setSelectedIndex(paramD.ß());
    p();
    l();
    this.o.addItemListener(this);
    this.r.addItemListener(this);
    this.u.addItemListener(this);
    paramD.B(this);
    paramD.Ø();
  }

  private Y r()
  {
    if (this.v == null)
    {
      this.v = new Y(PokerApp.Ȅ().Ȇ(), this.f, this.Ã);
      this.v.A(this);
      this.v.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("Stats.PlayerStatsWindow.Sessions")), BorderFactory.createEmptyBorder(3, 6, 3, 6)));
    }
    return this.v;
  }

  private void A(com.biotools.poker.G.R paramR)
  {
    if (paramR != null)
      ¢().C(paramR, this.Ã.T());
  }

  private void A(U paramU)
  {
    y().A(paramU);
  }

  private CardLayout o()
  {
    if (this.j == null)
      this.j = new CardLayout();
    return this.j;
  }

  public JPanel h()
  {
    if (this.Ä == null)
    {
      this.Ä = new JPanel(o());
      this.Ä.add(¤(), ¥);
      this.Ä.add(¢(), z);
      this.Ä.add(y(), Á);
    }
    return this.Ä;
  }

  private r y()
  {
    if (this.e == null)
      this.e = new r();
    return this.e;
  }

  private com.A.C.A ¤()
  {
    if (this.g == null)
    {
      this.g = new com.A.C.A();
      this.g.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
      this.g.A(true);
      this.g.B(com.biotools.poker.E.D("Stats.PlayerStatsWindow.MoneyWon"));
      Object[] arrayOfObject = { this.Ã.T() };
      this.g.C(com.biotools.poker.E.A("Stats.PlayerStatsWindow.PlayersBankrollPattern", arrayOfObject));
      this.g.D(com.biotools.poker.E.D("Stats.PlayerStatsWindow.SessionsPlayed"));
      this.g.setPreferredSize(new Dimension(350, 280));
      this.d.A(0.0D, 0.0D);
      this.g.A(this.d);
      this.g.setBorder(BorderFactory.createEtchedBorder());
    }
    return this.g;
  }

  private J ¢()
  {
    if (this.t == null)
      this.t = new J();
    return this.t;
  }

  private JPanel q()
  {
    JPanel localJPanel = new JPanel(new BorderLayout(4, 4));
    localJPanel.add(f(), "West");
    localJPanel.add(r(), "Center");
    return localJPanel;
  }

  private JPanel f()
  {
    JPanel localJPanel1 = new JPanel(new BorderLayout());
    localJPanel1.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2), BorderFactory.createRaisedBevelBorder()));
    localJPanel1.add(n(), "Center");
    JPanel localJPanel2 = new JPanel(new BorderLayout(2, 2));
    localJPanel2.add(localJPanel1, "North");
    localJPanel2.add(µ(), "Center");
    localJPanel2.add(x(), "South");
    return localJPanel2;
  }

  public void s()
  {
    this.s.setSelected(true);
    w().show(i(), "SESSIONS");
  }

  public void g()
  {
    this.p.setSelected(true);
    w().show(i(), "HANDS");
  }

  public void C(int paramInt)
  {
    z().Y(paramInt);
  }

  private void ¥()
  {
    this.s.setIcon(this.s.isSelected() ? this.n : this.c);
    this.s.setRolloverIcon(this.s.isSelected() ? this.n : this.c);
    this.s.setPressedIcon(!this.s.isSelected() ? this.n : this.c);
    this.p.setIcon(this.p.isSelected() ? this.Â : this.i);
    this.p.setRolloverIcon(this.p.isSelected() ? this.Â : this.i);
    this.p.setPressedIcon(!this.p.isSelected() ? this.Â : this.i);
  }

  private JPanel x()
  {
    this.s = new JToggleButton(com.biotools.poker.E.D("Stats.PlayerStatsWindow.SessionStats"), true);
    this.s.addActionListener(new s.5(this));
    this.p = new JToggleButton(com.biotools.poker.E.D("Stats.PlayerStatsWindow.HandStats"), false);
    this.p.addActionListener(new s.6(this));
    ButtonGroup localButtonGroup = new ButtonGroup();
    localButtonGroup.add(this.s);
    localButtonGroup.add(this.p);
    JPanel localJPanel = new JPanel(new GridLayout(1, 2, 6, 6));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    localJPanel.add(this.s);
    localJPanel.add(this.p);
    return localJPanel;
  }

  private CardLayout w()
  {
    if (this.l == null)
      this.l = new CardLayout();
    return this.l;
  }

  public JPanel i()
  {
    if (this.º == null)
    {
      this.º = new JPanel(w());
      this.º.add(k(), "SESSIONS");
      this.º.add(z(), "HANDS");
    }
    return this.º;
  }

  private JLabel n()
  {
    if (this.q == null)
    {
      this.q = new JLabel(this.Ã.T(), 0);
      this.q.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
      this.q.setFont(this.q.getFont().deriveFont(1, 16.0F));
    }
    return this.q;
  }

  private JPanel k()
  {
    JPanel localJPanel = new JPanel(new BorderLayout(8, 8));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
    localJPanel.add(£(), "West");
    localJPanel.add(h(), "Center");
    return localJPanel;
  }

  private l z()
  {
    if (this.À == null)
    {
      this.À = new l(this.f, this.Ã, this.£);
      this.À.H(this.w);
    }
    return this.À;
  }

  private com.A.B.A £()
  {
    if (this.ª == null)
    {
      this.ª = new com.A.B.A();
      this.ª.setPreferredSize(new Dimension(230, 160));
    }
    return this.ª;
  }

  private JPanel µ()
  {
    JPanel localJPanel = new JPanel(new B.A.A.B(2, 2));
    localJPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("Stats.PlayerStatsWindow.Filters")), BorderFactory.createEmptyBorder(1, 3, 3, 3)));
    localJPanel.add("", new JLabel(com.biotools.poker.E.D("Stats.PlayerStatsWindow.TypeTitle"), 4));
    localJPanel.add("tab hfill", this.o);
    localJPanel.add("br", new JLabel(com.biotools.poker.E.D("Stats.PlayerStatsWindow.StakesTitle"), 4));
    localJPanel.add("tab hfill", this.r);
    localJPanel.add("br", new JLabel(com.biotools.poker.E.D("Stats.PlayerStatsWindow.NameTitle"), 4));
    localJPanel.add("tab hfill", this.u);
    localJPanel.setPreferredSize(new Dimension(200, localJPanel.getPreferredSize().height));
    return localJPanel;
  }

  public void itemStateChanged(ItemEvent paramItemEvent)
  {
    if (this.¢)
      return;
    if (paramItemEvent.getStateChange() == 2)
      return;
    this.¢ = true;
    this.f.H(this.o.getSelectedIndex());
    if (paramItemEvent.getSource() == this.o)
      p();
    String str1 = null;
    if ((this.r.isEnabled()) && (this.r.getSelectedIndex() > 0))
      str1 = (String)this.r.getSelectedItem();
    this.f.C(str1);
    String str2 = null;
    if ((this.u.isEnabled()) && (this.u.getSelectedIndex() > 0))
      str2 = (String)this.u.getSelectedItem();
    this.f.B(str2);
    this.f.Ø();
    if (paramItemEvent.getSource() == this.o)
      l();
    this.v.ė();
    this.¢ = false;
  }

  private void p()
  {
    if (this.o.getSelectedIndex() == 0)
    {
      this.r.setEnabled(false);
      this.u.setEnabled(false);
    }
    else
    {
      this.r.setEnabled(true);
      this.u.setEnabled(true);
    }
  }

  private void l()
  {
    HashSet localHashSet1 = new HashSet();
    HashSet localHashSet2 = new HashSet();
    ArrayList localArrayList = (ArrayList)this.v.á();
    for (int i1 = 0; i1 < localArrayList.size(); i1++)
    {
      localObject = (U)localArrayList.get(i1);
      localHashSet1.add(((U)localObject).E());
      localHashSet2.add(((U)localObject).D());
    }
    Vector localVector = new Vector();
    localVector.addAll(localHashSet1);
    Collections.sort(localVector);
    localVector.insertElementAt("All", 0);
    Object localObject = new Vector();
    ((Vector)localObject).addAll(localHashSet2);
    Collections.sort((List)localObject);
    ((Vector)localObject).insertElementAt("All", 0);
    this.r.setModel(new DefaultComboBoxModel(localVector));
    this.u.setModel(new DefaultComboBoxModel((Vector)localObject));
  }

  public void v()
  {
    com.biotools.poker.E.H("PlayerStatsWindow.updateStats()");
    if (this.w == null)
      return;
    int i1 = 0;
    int i2 = 0;
    int i3 = 0;
    int i4 = 0;
    int i5 = 0;
    int i6 = 0;
    int i7 = 0;
    double d1 = 0.0D;
    double d2 = 0.0D;
    double d3 = 0.0D;
    double d4 = 0.0D;
    double d5 = 0.0D;
    double d6 = 0.0D;
    double d7 = 0.0D;
    double d8 = 0.0D;
    double d9 = 1.0E-007D;
    for (int i8 = 0; i8 < this.w.size(); i8++)
    {
      U localU = (U)this.w.get(i8);
      Object localObject1;
      if (localU.X())
      {
        localObject1 = (A)localU;
        com.biotools.poker.G.R localR = ((A)localObject1).b();
        if ((localR != null) && ((localR.I()) || (localR.D(this.Ã.T()))))
        {
          localObject2 = localR.T(this.Ã.T());
          if (localObject2 != null)
          {
            i2++;
            i3++;
            d5 += localR.Q().M();
            double d12 = localR.I(this.Ã.T());
            double d13 = localR.Q(this.Ã.T());
            if (d13 > 0.0D)
              i4++;
            if (((G)localObject2).L() == 1)
              i5++;
            d2 += d12;
            d3 += d13;
            d7 += d13 - d12;
            i7 += localR.E();
            double d14 = localR.V() / 2.0D;
            d14 += 0.5D;
            if (((G)localObject2).L() > d14)
              d1 += (((G)localObject2).L() - 1.0D) / localR.V() + d9;
            else if (((G)localObject2).L() < d14)
              d1 += ((G)localObject2).L() / localR.V() - d9;
            else
              d1 += 0.5D;
          }
        }
      }
      else
      {
        i1++;
        i3++;
        localObject1 = localU.A(this.Ã.T());
        if (localObject1 != null)
        {
          d4 += ((a)localObject1).R();
          d6 += ((a)localObject1).M();
          d8 += ((a)localObject1)._();
          i6 += ((a)localObject1).Z();
        }
      }
    }
    if (i3 > 0)
      d1 /= i2;
    double d10 = 0.0D;
    double d11 = 0.0D;
    if (i3 > 0)
    {
      d10 = i4 / i2;
      d11 = i5 / i2;
    }
    Object localObject2 = new StringBuffer();
    ((StringBuffer)localObject2).append("<html>");
    ((StringBuffer)localObject2).append("<table border=0 width=\"100%\" cellpadding=\"2\">");
    if ((i1 > 0) && (i2 > 0))
    {
      ((StringBuffer)localObject2).append("<tr bgcolor=\"#ddddff\">");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=4><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.TotalSessionsTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=4>" + i3 + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
      ((StringBuffer)localObject2).append("<tr>");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.HandsPlayedTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=3>" + (i7 + i6) + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
      ((StringBuffer)localObject2).append("<tr>");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.RakedTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=3>" + Action.formatCash(d4 + d5) + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
      ((StringBuffer)localObject2).append("<tr>");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.NetWonTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=3>" + Action.formatCash(d6 + d7) + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
    }
    if (i1 > 0)
    {
      ((StringBuffer)localObject2).append("<tr bgcolor=\"#ddddff\">");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=4><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.RingGamesTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=4>" + i1 + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
      ((StringBuffer)localObject2).append("<tr>");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.HandsPlayedTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=3>" + i6 + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
      ((StringBuffer)localObject2).append("<tr>");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.MoneyPerHandTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=3>" + Action.formatCash(d6 / i6) + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
      ((StringBuffer)localObject2).append("<tr>");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.SmallBetsPerHourTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=3>" + j.B.format(d8 / i6) + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
      ((StringBuffer)localObject2).append("<tr>");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.RakedTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=3>" + Action.formatCash(d4) + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
      ((StringBuffer)localObject2).append("<tr>");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.NetWonTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=3>" + Action.formatCash(d6) + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
    }
    if (i2 > 0)
    {
      ((StringBuffer)localObject2).append("<tr bgcolor=\"#ddddff\">");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=4><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.TournamentsTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=4>" + i2 + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
      ((StringBuffer)localObject2).append("<tr>");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.HandsPlayedTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=3>" + i7 + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
      ((StringBuffer)localObject2).append("<tr>");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.FinishesTitle") + "</b></td>");
      if (d1 < 0.5D)
        ((StringBuffer)localObject2).append("<td><font face=Arial size=3>Top " + b.A(100.0D * d1, 1) + "%" + "</td>");
      else
        ((StringBuffer)localObject2).append("<td><font face=Arial size=3>Bottom " + b.A(100.0D * (1.0D - d1), 1) + "%" + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
      ((StringBuffer)localObject2).append("<tr>");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.WonTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=3>" + b.A(100.0D * d11, 1) + "%" + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
      ((StringBuffer)localObject2).append("<tr>");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.MoniedTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=3>" + b.A(100.0D * d10, 1) + "%" + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
      ((StringBuffer)localObject2).append("<tr>");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.SpentTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=3>" + Action.formatCash(d2) + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
      ((StringBuffer)localObject2).append("<tr>");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.EarnedTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=3><font face=Arial size=3>" + Action.formatCash(d3) + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
      ((StringBuffer)localObject2).append("<tr>");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.ROITitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=3>" + ((int)b.A(100.0D * d3 / d2, 0) - 100) + "%" + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
      ((StringBuffer)localObject2).append("<tr>");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.RakedTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=3>" + Action.formatCash(d5) + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
      ((StringBuffer)localObject2).append("<tr>");
      ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.NetWonTitle") + "</b></td>");
      ((StringBuffer)localObject2).append("<td><font face=Arial size=3>" + Action.formatCash(d7) + "</td>");
      ((StringBuffer)localObject2).append("</tr>");
    }
    if ((i1 == 0) && (i2 == 0))
      if (this.f.size() == 0)
      {
        ((StringBuffer)localObject2).append("<tr bgcolor=\"#ddddff\">");
        ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=4><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.EmptySessionData") + "</b></td>");
        ((StringBuffer)localObject2).append("<td><font face=Arial size=4> </td>");
        ((StringBuffer)localObject2).append("</tr>");
        ((StringBuffer)localObject2).append("<tr>");
        ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.NoSummaryDataAvailable") + "</td>");
        ((StringBuffer)localObject2).append("</tr>");
      }
      else
      {
        ((StringBuffer)localObject2).append("<tr bgcolor=\"#ddddff\">");
        ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=4><b>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.UnfinishedTournament") + "</b></td>");
        ((StringBuffer)localObject2).append("<td><font face=Arial size=4> </td>");
        ((StringBuffer)localObject2).append("</tr>");
        ((StringBuffer)localObject2).append("<tr>");
        ((StringBuffer)localObject2).append("<td align=\"right\"><font face=Arial size=3>" + com.biotools.poker.E.D("Stats.PlayerStatsWindow.NoSummaryDataAvailable") + "</td>");
        ((StringBuffer)localObject2).append("</tr>");
      }
    ((StringBuffer)localObject2).append("</table>");
    ((StringBuffer)localObject2).append("</html>");
    SwingUtilities.invokeLater(new s.7(this, (StringBuffer)localObject2));
    m();
  }

  private void m()
  {
    int i1 = 0;
    double d1 = 0.0D;
    this.d.B();
    this.d.A(i1++, 0.0D);
    ArrayList localArrayList = new ArrayList();
    localArrayList.addAll(this.w);
    Collections.sort(localArrayList, new s.8(this));
    for (int i2 = 0; i2 < localArrayList.size(); i2++)
    {
      U localU = (U)localArrayList.get(i2);
      a locala = localU.A(this.Ã.T());
      if (locala != null)
      {
        d1 += locala.M();
        this.d.A(i1++, d1);
      }
    }
    ¤().B();
  }

  public void B()
  {
    com.biotools.poker.E.H("PlayerStatsWindow.gameRecordListChanged()");
    v();
  }

  public void A()
  {
    B();
  }

  public void A(E paramE)
  {
    if (paramE.O())
      v();
  }

  public void j()
  {
    com.biotools.B.R localR = com.biotools.B.R.B("Help");
    localR.A("statistics.html");
  }

  public void A(List paramList)
  {
    this.w = paramList;
    if (this.À != null)
    {
      z().ś().C(paramList);
      z().ś().Ø();
    }
    if ((paramList != null) && (paramList.size() > 0))
    {
      if (paramList.size() == 1)
      {
        U localU = (U)paramList.get(0);
        if (localU.X())
        {
          A localA = (A)paramList.get(0);
          A(localA.b());
          o().show(h(), z);
        }
        else
        {
          A(localU);
          o().show(h(), Á);
        }
      }
      else
      {
        o().show(h(), ¥);
      }
    }
    else
    {
      A(null);
      A(null);
    }
    v();
  }

  public void u()
  {
    if (this.£ == null)
    {
      Object[] arrayOfObject = { this.Ã.T(), this.Ã.Y(), this.Ã.Z() };
      this.£ = new JFrame(com.biotools.poker.E.A("Stats.StatsDatabaseMenu.PlayerStatisticsPattern", arrayOfObject));
      this.£.setIconImage(com.biotools.poker.E.¢);
      this.£.getContentPane().add(this);
      this.m = new s._A(this);
      this.£.setJMenuBar(this.m);
      L.A(this.£);
      this.£.setDefaultCloseOperation(2);
      this.£.addWindowListener(new s.9(this));
    }
    this.£.setVisible(true);
  }

  public void ª()
  {
    if (this.£ != null)
    {
      this.m = null;
      this.£.setJMenuBar(null);
      this.£.setVisible(false);
      this.£.dispose();
    }
  }

  private void t()
  {
    com.biotools.poker.E.H("DISPOSE PLAYER STATS WINDOW");
    r().ď();
    r().B(this);
    this.e.A();
    this.f.A(this);
    this.f.Ç();
    z().Ř();
    this.À = null;
    this.v = null;
    this.ª.removeAll();
    ¢().removeAll();
    i().removeAll();
    removeAll();
    if (this.£ != null)
    {
      if (this.£.isDisplayable())
      {
        this.£.setJMenuBar(null);
        this.£.getContentPane().removeAll();
        this.£.dispose();
      }
      this.£ = null;
    }
    if (com.biotools.poker.E.y())
      com.biotools.poker.E.H(L.B());
  }

  public void finalize()
  {
    com.biotools.poker.E.H("PlayerStatsWindow.finalize(" + --k + ")");
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.s
 * JD-Core Version:    0.6.2
 */