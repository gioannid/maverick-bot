package com.biotools.poker.R;

import com.biotools.B.L;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;

public class g extends JPanel
  implements ItemListener, N, Q
{
  public static final int Z = 0;
  public static final int R = 1;
  R L;
  private Z U;
  private ArrayList O = new ArrayList();
  private D _;
  private D T;
  private JComboBox I = new JComboBox(D.ñ);
  private JComboBox J = new JComboBox();
  private JComboBox K = new JComboBox();
  private JLabel P;
  private Y S;
  private n Q;
  private _ H;
  private JRadioButton X;
  private JRadioButton b;
  private JRadioButton a;
  private JRadioButton E;
  private JRadioButton V;
  private JCheckBox D;
  private JCheckBox G;
  private JCheckBox N;
  private JCheckBox Y;
  private q F;
  private int W = d.N();
  private int M = 0;

  public g(R paramR, Z paramZ)
  {
    this.L = paramR;
    this.U = paramZ;
    this.T = new D(paramR.Ġ());
    this._ = new D(paramR.Ġ());
    setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
    setLayout(new BorderLayout(2, 2));
    add(V(), "Center");
    add(S(), "West");
    A(paramZ);
    this.I.setSelectedIndex(this._.ß());
    _();
    Y();
    this.I.addItemListener(this);
    this.J.addItemListener(this);
    this.K.addItemListener(this);
    this._.B(this);
    Q().F(this.O);
    Q().ê();
    Q().K(0);
  }

  public void A(Z paramZ)
  {
    this.U = paramZ;
    R().C(paramZ);
    this.O.clear();
    Q().D(paramZ);
    X().F(paramZ);
    U().E(paramZ);
    this.T.B(paramZ);
    this.T.Ø();
    this._.B(this.U);
    this._.Ø();
  }

  private Component V()
  {
    JPanel localJPanel = new JPanel(new BorderLayout(4, 4));
    localJPanel.add(O(), "Center");
    localJPanel.add(Q(), "North");
    return localJPanel;
  }

  private JPanel S()
  {
    JPanel localJPanel = new JPanel(new BorderLayout(4, 4));
    localJPanel.add(a(), "South");
    localJPanel.add(R(), "Center");
    return localJPanel;
  }

  private JPanel a()
  {
    JPanel localJPanel1 = new JPanel(new GridLayout(2, 1, 2, 2));
    localJPanel1.setBorder(L.A(BorderFactory.createTitledBorder(com.biotools.poker.E.D("Stats.LiteStatsPanel.GraphOptions")), 5));
    localJPanel1.add(c());
    localJPanel1.add(Z());
    JPanel localJPanel2 = new JPanel(new GridLayout(3, 1, 3, 3));
    localJPanel2.add(localJPanel1);
    localJPanel2.add(d());
    localJPanel2.add(W());
    return localJPanel2;
  }

  private JPanel W()
  {
    this.P = new JLabel(com.biotools.poker.E.D("Stats.LiteStatsPanel.SelectPlayer"));
    JPanel localJPanel = new JPanel(new BorderLayout(0, 0));
    localJPanel.setBorder(L.A(BorderFactory.createTitledBorder(com.biotools.poker.E.D("Stats.LiteStatsPanel.Totals")), 5));
    localJPanel.add(this.P, "North");
    return localJPanel;
  }

  private JPanel d()
  {
    this.D = new JCheckBox(com.biotools.poker.E.D("Stats.LiteStatsPanel.NoLimit"));
    this.D.setSelected(true);
    this.D.addItemListener(new g.1(this));
    this.G = new JCheckBox(com.biotools.poker.E.D("Stats.LiteStatsPanel.Limit"));
    this.G.setSelected(true);
    this.G.addItemListener(new g.2(this));
    this.N = new JCheckBox(com.biotools.poker.E.D("Stats.LiteStatsPanel.Ring"));
    this.N.setSelected(true);
    this.N.addItemListener(new g.3(this));
    this.Y = new JCheckBox(com.biotools.poker.E.D("Stats.LiteStatsPanel.Tourney"));
    this.Y.setSelected(true);
    this.Y.addItemListener(new g.4(this));
    JPanel localJPanel = new JPanel(new GridLayout(2, 2, 4, 4));
    localJPanel.setBorder(L.A(BorderFactory.createTitledBorder(com.biotools.poker.E.D("Stats.LiteStatsPanel.FilterGames")), 5));
    localJPanel.add(this.N);
    localJPanel.add(this.G);
    localJPanel.add(this.Y);
    localJPanel.add(this.D);
    return localJPanel;
  }

  private Y Q()
  {
    if (this.S == null)
    {
      this.S = new Y(this.L, this.T, this.U);
      this.S.A(this);
      this.S.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("Stats.LiteStatsPanel.Sessions")), BorderFactory.createEmptyBorder(3, 6, 3, 6)));
    }
    return this.S;
  }

  private void _()
  {
    if (this.I.getSelectedIndex() == 0)
    {
      this.J.setEnabled(false);
      this.K.setEnabled(false);
    }
    else
    {
      this.J.setEnabled(true);
      this.K.setEnabled(true);
    }
  }

  private void Y()
  {
    HashSet localHashSet1 = new HashSet();
    HashSet localHashSet2 = new HashSet();
    ArrayList localArrayList = (ArrayList)this.S.á();
    for (int i = 0; i < localArrayList.size(); i++)
    {
      U localU = (U)localArrayList.get(i);
      localHashSet1.add(localU.E());
      localHashSet2.add(localU.D());
    }
  }

  private JPanel c()
  {
    this.a = new JRadioButton(d.E(2));
    this.a.addActionListener(new g.5(this));
    this.X = new JRadioButton(d.E(0));
    this.X.addActionListener(new g.6(this));
    this.b = new JRadioButton(d.E(3));
    this.b.addActionListener(new g.7(this));
    ButtonGroup localButtonGroup = new ButtonGroup();
    localButtonGroup.add(this.a);
    localButtonGroup.add(this.X);
    localButtonGroup.add(this.b);
    e();
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(new JLabel(com.biotools.poker.E.D("Stats.LiteStatsPanel.UnitsTitle")));
    localJPanel.add(Box.createHorizontalStrut(8));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(this.a);
    localJPanel.add(Box.createHorizontalStrut(6));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(this.X);
    localJPanel.add(Box.createHorizontalStrut(6));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(this.b);
    localJPanel.add(Box.createHorizontalGlue());
    return localJPanel;
  }

  public void B(int paramInt)
  {
    if (this.W != paramInt)
    {
      this.W = paramInt;
      e();
      T();
      X()._(paramInt);
      U().Z(paramInt);
    }
  }

  public void e()
  {
    switch (this.W)
    {
    case 0:
      this.X.setSelected(true);
      break;
    case 3:
      this.b.setSelected(true);
      break;
    case 2:
      this.a.setSelected(true);
    case 1:
    }
  }

  public void P()
  {
    int i = 0;
    int j = 0;
    for (int k = 0; k < this.O.size(); k++)
      if (((U)this.O.get(k)).A())
        i = 1;
      else
        j = 1;
    if (i != 0)
    {
      this.b.setEnabled(false);
      if (this.W == 3)
        B(2);
    }
    else if (j != 0)
    {
      this.b.setEnabled(true);
    }
  }

  private JPanel Z()
  {
    this.E = new JRadioButton(com.biotools.poker.E.D("Stats.LiteStatsPanel.Hands"));
    this.E.addActionListener(new g.8(this));
    this.V = new JRadioButton(com.biotools.poker.E.D("Stats.LiteStatsPanel.Sessions"));
    this.V.addActionListener(new g.9(this));
    ButtonGroup localButtonGroup = new ButtonGroup();
    localButtonGroup.add(this.E);
    localButtonGroup.add(this.V);
    b();
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(new JLabel(com.biotools.poker.E.D("Stats.LiteStatsPanel.TypeTitle")));
    localJPanel.add(Box.createHorizontalStrut(8));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(this.E);
    localJPanel.add(Box.createHorizontalStrut(6));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(this.V);
    localJPanel.add(Box.createHorizontalStrut(6));
    localJPanel.add(Box.createHorizontalGlue());
    return localJPanel;
  }

  public void A(int paramInt)
  {
    if (this.M != paramInt)
    {
      this.M = paramInt;
      b();
      X().a(paramInt);
    }
  }

  public void b()
  {
    switch (this.M)
    {
    case 0:
      this.E.setSelected(true);
      break;
    case 1:
      this.V.setSelected(true);
    }
  }

  private n R()
  {
    if (this.Q == null)
    {
      this.Q = new n(this.L, this);
      this.Q.D(U.K());
    }
    return this.Q;
  }

  private JTabbedPane O()
  {
    JTabbedPane localJTabbedPane = new JTabbedPane();
    localJTabbedPane.add(X(), com.biotools.poker.E.D("Stats.LiteStatsPanel.BankrollGraph"));
    localJTabbedPane.add(U(), com.biotools.poker.E.D("Stats.LiteStatsPanel.Actions"));
    return localJTabbedPane;
  }

  private _ X()
  {
    if (this.H == null)
      this.H = new _(this._, this.U);
    return this.H;
  }

  private q U()
  {
    if (this.F == null)
      this.F = new q(this._, this.U);
    return this.F;
  }

  public void T()
  {
    double d1 = 0.0D;
    double d2 = 0.0D;
    double d3 = 0.0D;
    double d4 = 0.0D;
    int i = 0;
    HashSet localHashSet = new HashSet();
    if (this.U == null)
    {
      this.P.setText(com.biotools.poker.E.D("Stats.LiteStatsPanel.SelectPlayer"));
      return;
    }
    for (int j = 0; j < this._.size(); j++)
    {
      E localE = this._.D(j);
      int k = localE.B(this.U.T());
      if (localE.G(k))
      {
        double d7 = localE.C(k);
        i++;
        if (localE._().X())
        {
          if (!localHashSet.contains(localE._()))
          {
            localHashSet.add(localE._());
            if ((((A)localE._()).F(this.U.T()) != -1) && (this.W == 2))
              d4 += ((A)localE._()).G(this.U.T());
          }
          if (this.W == 0)
            d3 += d7;
          else if (this.W == 3)
            d4 += d7 * localE.W();
        }
        else
        {
          d3 += d7;
          d4 += d7 * localE.W();
        }
      }
    }
    if (i == 0)
    {
      this.P.setVisible(false);
      return;
    }
    this.P.setVisible(true);
    double d5 = 0.0D;
    double d6 = 0.0D;
    switch (this.W)
    {
    case 0:
      d5 = d3;
      break;
    case 2:
    case 3:
      d5 = d4;
    case 1:
    }
    double d8 = d5 / i;
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<html><table width=\"150\" cellspacing=1 cellpadding=2 border=0>");
    localStringBuffer.append("<tr><td align=\"right\"><b>" + com.biotools.poker.E.D("Stats.LiteStatsPanel.HandsTitle") + "</b></td>");
    localStringBuffer.append("<td align=\"right\">" + i + "</td></tr>");
    Object[] arrayOfObject = { d.C(this.W) };
    localStringBuffer.append("<tr><td align=\"right\"><b>" + com.biotools.poker.E.A("Stats.LiteStatsPanel.UnitsStringTitlePattern", arrayOfObject) + "</b></td>");
    localStringBuffer.append("<td align=\"right\">" + j.B.format(d5) + "</td></tr>");
    localStringBuffer.append("</table></html>");
    String str = localStringBuffer.toString();
    SwingUtilities.invokeLater(new g.10(this, str));
  }

  public void B(List paramList)
  {
    this.O.clear();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
      this.O.add((U)localIterator.next());
    Q().F(paramList);
  }

  public void itemStateChanged(ItemEvent paramItemEvent)
  {
  }

  public void A(List paramList)
  {
    this.O.clear();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
      this.O.add((U)localIterator.next());
    this._.C(this.O);
    this._.Ø();
    P();
  }

  public void A(E paramE)
  {
    this.Q.ć();
    T();
  }

  public void B()
  {
    this.Q.ć();
    T();
  }

  public void A()
  {
    B();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.g
 * JD-Core Version:    0.6.2
 */