package com.biotools.poker.R;

import com.biotools.A.I;
import com.biotools.B.D;
import com.biotools.B.J;
import com.biotools.B.L;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.L.G;
import com.biotools.poker.PokerApp;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;

public class X extends JPanel
  implements N
{
  private D ś;
  private b Š;
  private JLabel Ŕ;
  private JLabel Ŝ;
  private V Ś;
  private JButton ř;
  private JButton Ţ;
  private JButton ŕ;
  private JButton ţ;
  private Z š;
  private E Ř = null;
  private U ş;
  private int ŗ;
  private volatile boolean Ş = false;
  private JFrame Ŗ;
  private JMenuBar ŝ;

  public X(V paramV, Z paramZ)
  {
    A(paramV, paramZ);
  }

  private void A(V paramV, Z paramZ)
  {
    this.š = paramZ;
    this.Ś = paramV;
    this.Ś.B(this);
    JPanel localJPanel = new JPanel(new BorderLayout(4, 4));
    localJPanel.add(ņ(), "Center");
    localJPanel.add(Ĺ(), "East");
    setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));
    setLayout(new BorderLayout(5, 5));
    add(ļ(), "North");
    add(localJPanel, "Center");
    W(-1);
  }

  private JPanel ņ()
  {
    JScrollPane localJScrollPane = new JScrollPane(Ŀ());
    localJScrollPane.setMinimumSize(new Dimension(450, 300));
    JPanel localJPanel = new JPanel(new BorderLayout(4, 4));
    localJPanel.add(localJScrollPane, "Center");
    return localJPanel;
  }

  private JPanel ŉ()
  {
    JPanel localJPanel = new JPanel(new BorderLayout(4, 4));
    localJPanel.setBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("Stats.HistoryPanel.FiltersTitle")));
    return localJPanel;
  }

  public V Ň()
  {
    return this.Ś;
  }

  private JPanel Ĺ()
  {
    this.ř = new J("play.png", com.biotools.poker.E.D("Stats.HistoryPanel.PlayToolTip"));
    this.ř.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        X.this.ń();
      }
    });
    this.Ţ = new J("calc.png", com.biotools.poker.E.D("Stats.HistoryPanel.CalcToolTip"));
    this.Ţ.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        X.this.Ķ();
      }
    });
    this.ŕ = new J("export.png", com.biotools.poker.E.D("Stats.HistoryPanel.ExportToolTip"));
    this.ŕ.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        X.this.Ľ();
      }
    });
    this.ţ = new J("del.png", com.biotools.poker.E.D("Stats.HistoryPanel.DeleteToolTip"));
    this.ţ.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        X.this.Ļ();
      }
    });
    this.Ŝ = new JLabel("");
    this.Ŝ.setFont(this.Ŝ.getFont().deriveFont(1));
    JPanel localJPanel1 = new JPanel();
    localJPanel1.setLayout(new BoxLayout(localJPanel1, 0));
    localJPanel1.add(Box.createHorizontalStrut(4));
    localJPanel1.add(this.Ŝ);
    localJPanel1.add(Box.createHorizontalGlue());
    if (!com.biotools.poker.E.Ú())
    {
      localJPanel1.add(this.ř);
      localJPanel1.add(Box.createHorizontalStrut(5));
    }
    localJPanel1.add(this.Ţ);
    localJPanel1.add(Box.createHorizontalStrut(5));
    localJPanel1.add(this.ŕ);
    localJPanel1.add(Box.createHorizontalStrut(5));
    localJPanel1.add(this.ţ);
    localJPanel1.add(Box.createHorizontalStrut(5));
    localJPanel1.add(ĵ());
    localJPanel1.add(Box.createHorizontalStrut(5));
    this.ś = new D(new Dimension(285, 250));
    this.ś.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
    JPanel localJPanel2 = new JPanel(new BorderLayout());
    localJPanel2.setBorder(BorderFactory.createBevelBorder(0));
    localJPanel2.add(this.ś, "Center");
    localJPanel2.add(localJPanel1, "South");
    return localJPanel2;
  }

  private JComponent ļ()
  {
    Object[] arrayOfObject = { new Integer(this.Ś.size()) };
    this.Ŕ = new JLabel(com.biotools.poker.E.A("Stats.HistoryPanel.ShowingHandHistoriesPattern", arrayOfObject));
    this.Ŕ.setFont(new Font("Application", 1, 14));
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(this.Ŕ);
    localJPanel.add(Box.createHorizontalGlue());
    return localJPanel;
  }

  private JButton ĵ()
  {
    JButton localJButton = PokerApp.ɩ();
    localJButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        X.this.ĸ();
      }
    });
    return localJButton;
  }

  public b Ŀ()
  {
    if (this.Š == null)
      this.Š = new b(this);
    return this.Š;
  }

  public void Ń()
  {
    if (this.Ŕ != null)
    {
      Object[] arrayOfObject = { new Integer(this.Ś.size()) };
      this.Ŕ.setText(com.biotools.poker.E.A("Stats.HistoryPanel.ShowingHandHistoriesPattern", arrayOfObject));
    }
    Ŀ().ø();
  }

  public void A()
  {
    Ń();
  }

  public void B()
  {
    com.biotools.poker.E.H("HistoryPanel.gameRecordListChanged()");
    Ń();
  }

  public void A(E paramE)
  {
    int i = Ŀ().getSelectedRow();
    Ń();
    W(i + 1);
  }

  public D ĺ()
  {
    return this.ś;
  }

  protected void W(final int paramInt)
  {
    SwingUtilities.invokeLater(new Runnable()
    {
      private final int val$i;

      public void run()
      {
        if (X.this.Ş)
          return;
        X.this.Ş = true;
        X.this.Ř = null;
        if ((paramInt >= 0) && (paramInt < X.this.Ś.size()))
        {
          X.this.Ř = X.this.Ś.D(X.this.Ś.size() - 1 - paramInt);
          X.this.Ŀ().getSelectionModel().setSelectionInterval(paramInt, paramInt);
        }
        if (X.this.Ř == null)
        {
          X.this.ś.B();
          X.this.Ŝ.setText("");
          X.this.Ŀ().getSelectionModel().clearSelection();
        }
        else
        {
          Object[] arrayOfObject = { new Long(X.this.Ř.h()) };
          X.this.Ŝ.setText(com.biotools.poker.E.A("Stats.HistoryPanel.HandNumberPattern", arrayOfObject));
          X.this.ś.C(f.B(X.this.Ř, X.this.ķ()));
        }
        X.this.ś.E();
        X.this.ŕ.setEnabled(X.this.Ř != null);
        X.this.ř.setEnabled(X.this.Ř != null);
        X.this.ţ.setEnabled(X.this.Ř != null);
        X.this.Ţ.setEnabled(X.this.Ř != null);
        X.this.Ş = false;
      }
    });
  }

  public void G(boolean paramBoolean)
  {
    com.biotools.poker.E.£().putBoolean("HIST_SHOW_HANDS", paramBoolean);
    W(Ŀ().getSelectedRow());
  }

  public void ń()
  {
    E localE = Ŀ().ù();
    if ((localE != null) && (PokerApp.Ȅ() != null))
    {
      PokerApp.Ȅ().D(localE);
      PokerApp.Ȅ().setVisible(true);
    }
  }

  public void Ķ()
  {
    E localE = Ŀ().ù();
    if ((localE != null) && (PokerApp.Ȅ() != null))
    {
      PokerApp.Ȅ().ȇ().A(localE);
      PokerApp.Ȅ().ɥ();
    }
  }

  protected boolean ķ()
  {
    return com.biotools.poker.E.£().getBoolean("HIST_SHOW_HANDS", true);
  }

  public String Ł()
  {
    if (this.š != null)
      return this.š.T();
    return null;
  }

  public void ĸ()
  {
    com.biotools.B.R localR = com.biotools.B.R.B(com.biotools.poker.E.D("Stats.HistoryPanel.Help"));
    localR.A("history.html");
  }

  public void G(U paramU)
  {
    this.ş = paramU;
    ľ();
  }

  public void V(int paramInt)
  {
    this.ŗ = paramInt;
    ľ();
  }

  public void H(String paramString)
  {
    if (this.Ŗ != null)
      this.Ŗ.setTitle(com.biotools.poker.E.D("Stats.HistoryPanel.HandHistoryTitle") + paramString);
  }

  public void ľ()
  {
    String str = "";
    if (this.š != null)
      str = str + Ł();
    else if ((this.ş != null) && (this.ş.F() != null))
      str = str + this.ş.F();
    if (this.ş != null)
    {
      str = str + ", " + this.ş.N();
    }
    else if (this.ŗ > 1)
    {
      Object[] arrayOfObject = { new Integer(this.ŗ) };
      str = str + ", " + com.biotools.poker.E.A("Stats.HistoryPanel.SessionsPattern", arrayOfObject);
    }
    H(str);
  }

  private void Ľ()
  {
    E localE = Ŀ().ù();
    if (localE != null)
    {
      JFileChooser localJFileChooser = new JFileChooser();
      localJFileChooser.setSelectedFile(new File(localE.h() + ".txt"));
      if (localJFileChooser.showSaveDialog(null) == 0)
      {
        File localFile = localJFileChooser.getSelectedFile();
        if (localFile != null)
        {
          String str = f.A(localE, ķ(), true);
          try
          {
            BufferedWriter localBufferedWriter = new BufferedWriter(new FileWriter(localFile));
            localBufferedWriter.write(str);
            localBufferedWriter.close();
          }
          catch (IOException localIOException)
          {
            I.A(com.biotools.poker.E.D("Stats.HistoryPanel.ErrorExportingFile"), localIOException);
          }
        }
      }
    }
  }

  private void Ļ()
  {
    if (this.Ř != null)
    {
      int i = JOptionPane.showConfirmDialog(this.Ŗ, com.biotools.poker.E.D("Stats.HistoryPanel.DeleteDescription"), com.biotools.poker.E.D("Stats.HistoryPanel.Delete"), 0, 2);
      if (i == 0)
      {
        V localV = new V();
        localV.add(this.Ř);
        PokerApp.Ȅ().Ȇ().B(localV);
        Ŀ().ø();
      }
    }
  }

  private void ŀ()
  {
    Ŀ().ú();
    this.Ś.A(this);
  }

  public void ł()
  {
    if (this.Ŗ == null)
    {
      this.Ŗ = new JFrame(com.biotools.poker.E.D("Stats.HistoryPanel.HandHistoryHeading"));
      this.Ŗ.setResizable(false);
      this.Ŗ.setIconImage(com.biotools.poker.E.¢);
      this.Ŗ.getContentPane().add(this);
      this.ŝ = new p(this);
      this.Ŗ.setJMenuBar(this.ŝ);
      L.A(this.Ŗ);
      this.Ŗ.setSize(770, 580);
      L.B(this.Ŗ);
      this.Ŗ.setDefaultCloseOperation(2);
      this.Ŗ.addWindowListener(new X.7(this));
    }
    this.Ŗ.setVisible(true);
  }

  public void ň()
  {
    if (this.Ŗ != null)
    {
      this.Ŗ.setVisible(false);
      ŀ();
    }
  }

  public E Ņ()
  {
    return this.Ř;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.X
 * JD-Core Version:    0.6.2
 */