package com.biotools.poker.R;

import java.util.HashMap;

public class P
{
  protected static HashMap A = new HashMap();
  private float B;
  private float C;
  private float D;

  public P(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    this.B = paramFloat1;
    this.D = paramFloat2;
    this.C = paramFloat3;
  }

  public String toString()
  {
    return this.B + " " + this.C + " " + this.D;
  }

  public double C()
  {
    return this.B;
  }

  public void A(float paramFloat)
  {
    this.B = paramFloat;
  }

  public double B()
  {
    return this.C;
  }

  public void B(float paramFloat)
  {
    this.C = paramFloat;
  }

  public double A()
  {
    return this.D;
  }

  public void C(float paramFloat)
  {
    this.D = paramFloat;
  }

  public static P A(P paramP)
  {
    P localP = (P)A.get(paramP.toString());
    if (localP == null)
    {
      A.put(paramP.toString(), paramP);
      return paramP;
    }
    return localP;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.P
 * JD-Core Version:    0.6.2
 */