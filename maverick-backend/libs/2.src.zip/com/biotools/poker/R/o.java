package com.biotools.poker.R;

import com.biotools.poker.E;
import com.biotools.poker.G.G;
import com.biotools.poker.G.R;
import com.biotools.poker.G.T;
import java.text.DecimalFormat;

public class o extends a
{
  o(U paramU, String paramString)
  {
    super(paramU, paramString);
  }

  public A c()
  {
    return (A)this.C;
  }

  public double M()
  {
    return c().G(this.Z);
  }

  public String e()
  {
    int i = c().F(this.Z);
    if (i == -1)
    {
      R localR = c().b();
      if (localR != null)
      {
        localObject = localR.T(this.Z);
        if (localObject != null)
          return j.E.format(((G)localObject).F());
      }
    }
    int j = c().Y();
    Object localObject = { new Integer(i), new Integer(j) };
    return E.A("PlayerSessionTournyStats.PlaceOfPattern", (Object[])localObject);
  }

  public String L()
  {
    return e();
  }

  public int d()
  {
    G localG = c().b().T(this.Z);
    if (localG != null)
      return localG.L();
    return -1;
  }

  public boolean b()
  {
    return true;
  }

  public double R()
  {
    if (c().F(this.Z) != -1)
      return c().b().Q().M();
    return 0.0D;
  }

  public int compareTo(Object paramObject)
  {
    o localo = (o)paramObject;
    int i = F ? -1 : 1;
    switch (T)
    {
    case 3:
      if (d() < localo.d())
        return 1 * i;
      if (d() > localo.d())
        return -1 * i;
      break;
    }
    return super.compareTo(paramObject);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.o
 * JD-Core Version:    0.6.2
 */