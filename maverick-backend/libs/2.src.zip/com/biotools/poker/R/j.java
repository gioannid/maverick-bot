package com.biotools.poker.R;

import com.biotools.poker.E;
import java.text.DecimalFormat;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public abstract class j extends AbstractTableModel
{
  public static final DecimalFormat B = new DecimalFormat(E.D("StatsTableModel.DecimalFormatNF2"));
  public static final DecimalFormat C = new DecimalFormat(E.D("StatsTableModel.DecimalFormatNF1"));
  public static final DecimalFormat D = new DecimalFormat(E.D("StatsTableModel.DecimalFormatNF0"));
  public static final DecimalFormat H = new DecimalFormat(E.D("StatsTableModel.NFP"));
  public static final DecimalFormat F = new DecimalFormat(E.D("StatsTableModel.NFP0"));
  public static final DecimalFormat A = new DecimalFormat(E.D("StatsTableModel.NFD"));
  public static final DecimalFormat E = new DecimalFormat(E.D("StatsTableModel.NFT"));
  protected List G;

  public j(List paramList)
  {
    this.G = paramList;
  }

  public abstract String[] A();

  public String getColumnName(int paramInt)
  {
    return A()[paramInt].toString();
  }

  protected String B(int paramInt)
  {
    return null;
  }

  public int getRowCount()
  {
    return this.G.size();
  }

  public Object A(int paramInt)
  {
    if (paramInt >= this.G.size())
      return null;
    return this.G.get(paramInt);
  }

  public int getColumnCount()
  {
    return A().length;
  }

  public abstract Object getValueAt(int paramInt1, int paramInt2);

  public Class getColumnClass(int paramInt)
  {
    Object localObject = getValueAt(0, paramInt);
    if (localObject == null)
      return Object.class;
    return localObject.getClass();
  }

  public boolean isCellEditable(int paramInt1, int paramInt2)
  {
    return false;
  }

  public void setValueAt(Object paramObject, int paramInt1, int paramInt2)
  {
    fireTableCellUpdated(paramInt1, paramInt2);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.j
 * JD-Core Version:    0.6.2
 */