package com.biotools.poker.R;

import com.biotools.B.J;
import com.biotools.B.L;
import com.biotools.meerkat.util.PreferenceChangeEvent;
import com.biotools.meerkat.util.PreferenceChangeListener;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.PokerApp;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class M extends F
  implements N, PreferenceChangeListener
{
  protected static final int Ľ = 0;
  protected static final int ĳ = 1;
  protected static final int Ļ = 2;
  protected static final int Ĳ = 3;
  protected static final int ĵ = 4;
  protected static final int ľ = 5;
  protected static final int Ķ = 6;
  private Vector ĸ = new Vector();
  protected List Ĵ;
  private JButton Ŀ = new J("del.png", com.biotools.poker.E.D("Stats.SessionStatsSummary.DeleteToolTip"));
  private JButton ķ = new J("hand.png", com.biotools.poker.E.D("Stats.SessionStatsSummary.HandToolTip"));
  private JButton ı = new J("play.png", com.biotools.poker.E.D("Stats.SessionStatsSummary.PlayToolTip"));
  private JButton İ = new J("export.png", com.biotools.poker.E.D("Stats.SessionStatsSummary.ExportToolTip"));
  private R ļ;
  private D ĺ;
  private boolean Ĺ;

  public M(R paramR, D paramD)
  {
    this.ĺ = paramD;
    this.ļ = paramR;
    add(Đ(), "East");
    this.ø.addMouseListener(new MouseAdapter()
    {
      int A = -1;

      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        if (paramAnonymousMouseEvent.getClickCount() == 2)
        {
          M.this.Č();
          return;
        }
        if (M.this.ø.getSelectedRowCount() == 1)
        {
          if (M.this.ø.getSelectedRow() == this.A)
          {
            M.this.ė();
            this.A = -1;
          }
          else
          {
            this.A = M.this.ø.getSelectedRow();
          }
        }
        else
          this.A = -1;
      }
    });
    this.ø.addKeyListener(new KeyAdapter()
    {
      public void keyPressed(KeyEvent paramAnonymousKeyEvent)
      {
        if (paramAnonymousKeyEvent.getKeyCode() == 10)
        {
          M.this.Č();
          return;
        }
      }
    });
    this.ø.setSelectionMode(2);
    this.ø.getSelectionModel().addListSelectionListener(new ListSelectionListener()
    {
      public void valueChanged(ListSelectionEvent paramAnonymousListSelectionEvent)
      {
        M.this.ċ();
      }
    });
    setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
    Ę();
    é();
    paramD.B(this);
    com.biotools.poker.E.£().addPreferenceChangeListener(this);
  }

  public void ė()
  {
    this.ø.getSelectionModel().clearSelection();
  }

  public void é()
  {
    super.é();
    TableColumn localTableColumn = null;
    localTableColumn = this.ø.getTableHeader().getColumnModel().getColumn(2);
    localTableColumn.setMinWidth(130);
  }

  public Dimension ã()
  {
    return new Dimension(480, 80);
  }

  protected Z Ď()
  {
    return null;
  }

  protected void ċ()
  {
    this.Ŀ.setEnabled(this.ø.getSelectedRowCount() != 0);
    this.ķ.setEnabled(true);
    this.ı.setEnabled(true);
    E(ē());
  }

  private synchronized List ē()
  {
    ArrayList localArrayList = new ArrayList();
    if (this.ø.getSelectedRowCount() == 0)
    {
      localArrayList.addAll(á());
    }
    else
    {
      int[] arrayOfInt = this.ø.getSelectedRows();
      for (int i = 0; i < arrayOfInt.length; i++)
        localArrayList.add((U)á().get(arrayOfInt[i]));
    }
    return localArrayList;
  }

  private void Č()
  {
    V localV = đ();
    List localList = ē();
    if (localV.size() > 0)
    {
      X localX = new X(localV, Ď());
      localX.ł();
      if (localList.size() == 1)
      {
        U localU = (U)localList.get(0);
        localX.G(localU);
      }
      else
      {
        localX.V(localList.size());
      }
    }
  }

  private V đ()
  {
    D localD = new D(Ē());
    localD.C(ē());
    return localD;
  }

  private void č()
  {
    V localV = đ();
    if (localV.size() > 0)
      PokerApp.Ȅ().A(localV);
  }

  private void ĕ()
  {
    if (this.ø.getSelectedRowCount() > 0)
    {
      int i = 0;
      int j = 1;
      if (i != 0)
        j = JOptionPane.showConfirmDialog(this, com.biotools.poker.E.D("Stats.SessionStatsSummary.DeleteSessionsCurrentDescription") + "Are you sure you want to permanently delete the selected session(s)?", com.biotools.poker.E.D("Stats.SessionStatsSummary.DeleteSessions"), 0);
      else
        j = JOptionPane.showConfirmDialog(this, com.biotools.poker.E.D("Stats.SessionStatsSummary.DeleteDessionsDescription"), com.biotools.poker.E.D("Stats.SessionStatsSummary.DeleteSessions"), 0);
      if (j == 0)
      {
        if (i != 0)
        {
          PokerApp.Ȅ().ʒ();
          PokerApp.Ȅ().ʝ();
        }
        this.ļ.G(ē());
        this.ø.getSelectionModel().clearSelection();
      }
    }
  }

  private V Ē()
  {
    return this.ļ.Ġ();
  }

  private JPanel Đ()
  {
    this.Ŀ.setToolTipText(com.biotools.poker.E.D("Stats.SessionStatsSummary.DeleteSelectedSessions"));
    this.Ŀ.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        M.this.ĕ();
      }
    });
    this.ķ.setToolTipText(com.biotools.poker.E.D("Stats.SessionStatsSummary.ViewSelectedSessions"));
    this.ķ.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        M.this.Č();
      }
    });
    this.ı.setToolTipText(com.biotools.poker.E.D("Stats.SessionStatsSummary.ReplaySelectedSessions"));
    this.ı.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        M.this.č();
      }
    });
    this.İ.setToolTipText(com.biotools.poker.E.D("Stats.SessionStatsSummary.ExportSelectedSessions"));
    this.İ.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        M.this.ļ.D(M.this.đ());
      }
    });
    JLabel localJLabel1 = new JLabel(com.biotools.poker.E.D("Stats.SessionStatsSummary.StartedTitle"), 4);
    localJLabel1.setFont(new Font("Application", 1, 12));
    JLabel localJLabel2 = new JLabel(com.biotools.poker.E.D("Stats.SessionStatsSummary.EndedTitle"), 4);
    localJLabel2.setFont(new Font("Application", 1, 12));
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 1));
    localJPanel.add(this.ķ);
    localJPanel.add(Box.createVerticalStrut(1));
    if (!com.biotools.poker.E.Ú())
    {
      localJPanel.add(this.ı);
      localJPanel.add(Box.createVerticalStrut(1));
    }
    localJPanel.add(this.İ);
    localJPanel.add(Box.createVerticalStrut(1));
    localJPanel.add(this.Ŀ);
    this.Ŀ.setEnabled(false);
    localJPanel.setBorder(BorderFactory.createEmptyBorder(1, 4, 1, 1));
    return localJPanel;
  }

  public void K(int paramInt)
  {
    List localList = null;
    if (this.ø.getSelectedRowCount() > 0)
      localList = ē();
    U.A(paramInt, (paramInt == this.ô) && (!this.ö));
    super.K(paramInt);
    F(localList);
    E(ē());
  }

  protected void F(List paramList)
  {
    if (paramList != null)
    {
      if (paramList.size() == á().size())
        return;
      boolean bool = this.Ĺ;
      this.Ĺ = true;
      com.biotools.poker.E.H("restoreSelections()");
      int i = 2147483647;
      this.ø.getSelectionModel().clearSelection();
      for (int j = 0; j < paramList.size(); j++)
      {
        U localU = (U)paramList.get(j);
        int k = á().indexOf(localU);
        if (k >= 0)
        {
          this.ø.getSelectionModel().addSelectionInterval(k, k);
          i = Math.min(i, k);
        }
      }
      if (i != 2147483647)
        B(i, 0);
      this.Ĺ = bool;
      E(paramList);
    }
  }

  public void B()
  {
    ę();
  }

  public void A()
  {
    B();
  }

  public void A(E paramE)
  {
    ę();
  }

  protected void Ė()
  {
    HashSet localHashSet = new HashSet();
    for (int i = 0; i < this.ĺ.size(); i++)
    {
      E localE = this.ĺ.D(i);
      U localU = localE._();
      if (!localU.Q())
        localHashSet.add(localU);
    }
    this.Ĵ.clear();
    this.Ĵ.addAll(localHashSet);
  }

  public List á()
  {
    if (this.Ĵ == null)
      this.Ĵ = new ArrayList();
    return this.Ĵ;
  }

  public void preferenceChange(PreferenceChangeEvent paramPreferenceChangeEvent)
  {
    if ((paramPreferenceChangeEvent.getKey() == "POSITIVE_COLOR") || (paramPreferenceChangeEvent.getKey() == "NEUTRAL_COLOR") || (paramPreferenceChangeEvent.getKey() == "NEGATIVE_COLOR"))
      repaint();
  }

  public Component A(Component paramComponent, int paramInt1, int paramInt2)
  {
    U localU = (U)á().get(paramInt1);
    A(paramComponent, paramInt1, localU.H());
    if (localU.Q())
    {
      paramComponent.setForeground(Color.LIGHT_GRAY);
      paramComponent.setBackground(L.A(paramComponent.getBackground(), Color.LIGHT_GRAY, 0.5D));
    }
    else if (this.ø.getSelectionModel().isSelectedIndex(paramInt1))
    {
      paramComponent.setForeground(Color.white);
    }
    else
    {
      paramComponent.setForeground(Color.black);
    }
    return paramComponent;
  }

  private void Ę()
  {
    List localList = null;
    if (this.ø.getSelectedRowCount() > 0)
      localList = ē();
    Ė();
    à();
    this.õ.fireTableDataChanged();
    F(localList);
  }

  public void ę()
  {
    boolean bool = this.Ĺ;
    this.Ĺ = true;
    Ę();
    this.Ĺ = bool;
    Ĕ();
  }

  public void Ĕ()
  {
    if (ē().size() == 0)
      E(this.Ĵ);
    else
      E(ē());
  }

  private void E(List paramList)
  {
    if (!this.Ĺ)
      for (int i = 0; i < this.ĸ.size(); i++)
      {
        Q localQ = (Q)this.ĸ.get(i);
        localQ.A(paramList);
      }
  }

  public void A(Q paramQ)
  {
    this.ĸ.add(paramQ);
  }

  public void B(Q paramQ)
  {
    this.ĸ.remove(paramQ);
  }

  public AbstractTableModel å()
  {
    return new _A(á());
  }

  protected void ď()
  {
    com.biotools.poker.E.H("DISPOSE SESSION STATS SUMMARY");
    com.biotools.poker.E.£().removePreferenceChangeListener(this);
    this.ĺ.A(this);
    this.ĸ.clear();
  }

  public class _A extends j
  {
    private String[] J = { com.biotools.poker.E.D("Stats.SessionStatsSummary.Date"), com.biotools.poker.E.D("Stats.SessionStatsSummary.Site"), com.biotools.poker.E.D("Stats.SessionStatsSummary.Table"), com.biotools.poker.E.D("Stats.SessionStatsSummary.Stakes"), com.biotools.poker.E.D("Stats.SessionStatsSummary.Hands"), com.biotools.poker.E.D("Stats.SessionStatsSummary.Hero"), com.biotools.poker.E.D("Stats.SessionStatsSummary.MoneyWon") };
    private String[] I = { com.biotools.poker.E.D("Stats.SessionStatsSummary.DateDescription"), com.biotools.poker.E.D("Stats.SessionStatsSummary.SiteDescription"), com.biotools.poker.E.D("Stats.SessionStatsSummary.TableDescription"), com.biotools.poker.E.D("Stats.SessionStatsSummary.StakesDescription"), com.biotools.poker.E.D("Stats.SessionStatsSummary.HandsDescription"), com.biotools.poker.E.D("Stats.SessionStatsSummary.HeroDescription"), com.biotools.poker.E.D("Stats.SessionStatsSummary.MoneyWonDescription") };

    public _A(List arg2)
    {
      super();
    }

    public String[] A()
    {
      return this.J;
    }

    public String B(int paramInt)
    {
      return this.I[paramInt];
    }

    public Object getValueAt(int paramInt1, int paramInt2)
    {
      U localU = (U)M.this.Ĵ.get(paramInt1);
      double d = 0.0D;
      switch (paramInt2)
      {
      case 0:
        return new Date(localU.I());
      case 1:
        return localU.O();
      case 2:
        return localU.D();
      case 5:
        return localU.W() == null ? com.biotools.poker.E.D("Stats.SessionStatsSummary.NA") : localU.W().Q();
      case 4:
        return new Integer(localU.V());
      case 3:
        return localU.E();
      case 6:
        return A.format(localU.H());
      }
      return "";
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.M
 * JD-Core Version:    0.6.2
 */