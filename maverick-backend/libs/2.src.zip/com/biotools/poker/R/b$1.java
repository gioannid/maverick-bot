package com.biotools.poker.R;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ListSelectionModel;

final class b$1 extends MouseAdapter
{
  int A = -1;
  final b this$0;

  b$1(b paramb)
  {
  }

  public void mouseClicked(MouseEvent paramMouseEvent)
  {
    int i = this.this$0.getSelectedRow();
    if (i == -1)
    {
      this.this$0.getSelectionModel().clearSelection();
      this.A = -1;
    }
    else
    {
      this.A = i;
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.b.1
 * JD-Core Version:    0.6.2
 */