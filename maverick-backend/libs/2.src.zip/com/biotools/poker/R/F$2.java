package com.biotools.poker.R;

import java.awt.Point;
import java.awt.event.MouseEvent;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

final class F$2 extends JTableHeader
{
  final F.1 this$1;

  F$2(F.1 param1, TableColumnModel paramTableColumnModel)
  {
    super(paramTableColumnModel);
  }

  public String getToolTipText(MouseEvent paramMouseEvent)
  {
    Object localObject = null;
    Point localPoint = paramMouseEvent.getPoint();
    int i = this.columnModel.getColumnIndexAtX(localPoint.x);
    int j = this.columnModel.getColumn(i).getModelIndex();
    return ((j)F.1.access$0(this.this$1).õ).B(j);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.F.2
 * JD-Core Version:    0.6.2
 */