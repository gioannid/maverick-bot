package com.biotools.poker.R;

import com.biotools.poker.E;
import com.biotools.poker.PokerApp;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

public class K extends JMenuBar
{
  private R C;
  JMenu B = new JMenu(E.D("Stats.StatsDatabaseMenu.File"));
  JMenu A = new JMenu(E.D("Stats.StatsDatabaseMenu.Help"));

  public K(R paramR)
  {
    this.C = paramR;
    add(E());
    add(B());
  }

  protected JMenu E()
  {
    this.B.add(F());
    if (!E.Ú())
      this.B.add(C());
    this.B.add(H());
    this.B.addSeparator();
    this.B.add(D());
    this.B.add(G());
    return this.B;
  }

  protected JMenu B()
  {
    this.A.add(A());
    return this.A;
  }

  protected KeyStroke A(int paramInt)
  {
    return KeyStroke.getKeyStroke(paramInt, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask());
  }

  protected JMenuItem D()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("Stats.StatsDatabaseMenu.Close"), 67);
    localJMenuItem.setAccelerator(A(87));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        K.this.C.ı();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem G()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("Stats.StatsDatabaseMenu.QuitProgram"), 81);
    localJMenuItem.setAccelerator(A(81));
    localJMenuItem.setToolTipText(E.D("Stats.StatsDatabaseMenu.QuitProgramDescription"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        PokerApp.Ȅ().ʠ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem A()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("Stats.StatsDatabaseMenu.Help"), 72);
    localJMenuItem.setAccelerator(A(47));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        K.this.C.ğ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem H()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("Stats.StatsDatabaseMenu.Export"), 69);
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        K.this.C.Ĩ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem C()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("Stats.StatsDatabaseMenu.Import"), 73);
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        K.this.C.Ħ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem F()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("Stats.StatsDatabaseMenu.ColorPreferences"), 79);
    localJMenuItem.setAccelerator(A(79));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        K.this.C.Ĭ();
      }
    });
    return localJMenuItem;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.K
 * JD-Core Version:    0.6.2
 */