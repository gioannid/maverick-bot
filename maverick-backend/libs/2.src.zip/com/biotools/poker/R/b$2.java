package com.biotools.poker.R;

import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

final class b$2
  implements ListSelectionListener
{
  final b this$0;

  b$2(b paramb)
  {
  }

  public void valueChanged(ListSelectionEvent paramListSelectionEvent)
  {
    if (paramListSelectionEvent.getValueIsAdjusting())
      return;
    ListSelectionModel localListSelectionModel = (ListSelectionModel)paramListSelectionEvent.getSource();
    if (!localListSelectionModel.isSelectionEmpty())
    {
      int i = localListSelectionModel.getMinSelectionIndex();
      b.access$2(this.this$0).W(i);
    }
    else
    {
      b.access$2(this.this$0).W(-1);
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.R.b.2
 * JD-Core Version:    0.6.2
 */