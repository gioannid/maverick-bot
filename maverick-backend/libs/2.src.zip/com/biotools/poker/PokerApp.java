package com.biotools.poker;

import com.apple.mrj.MRJAboutHandler;
import com.apple.mrj.MRJQuitHandler;
import com.biotools.A.d;
import com.biotools.keycode.MachineIdentifier;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.GameObserver;
import com.biotools.meerkat.Player;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.F.S;
import com.biotools.poker.G.Q;
import com.biotools.poker.G.T;
import com.biotools.poker.G.X;
import com.biotools.poker.N.W;
import com.biotools.poker.P.Y;
import com.biotools.poker.P._;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JRootPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

public class PokerApp extends JFrame
  implements GameObserver, com.biotools.poker.G.b, com.biotools.poker.Q.A, com.biotools.B.G, MRJQuitHandler, MRJAboutHandler
{
  protected JFrame έ = null;
  protected JProgressBar ν = new JProgressBar(0, 100);
  private com.biotools.poker.Q.K Ϊ;
  private com.biotools.poker.Q.K ύ;
  private com.biotools.poker.Q.K τ;
  private com.biotools.poker.Q.B δ;
  private com.biotools.poker.K.F ς;
  protected com.biotools.poker.J.B Χ;
  private com.biotools.poker.C.D ί;
  protected com.biotools.poker.R.R Υ;
  private com.biotools.poker.L.G ε;
  private A κ;
  private W η;
  private Card ρ;
  private Card π;
  private com.biotools.poker.F.D λ;
  private com.biotools.poker.I.A υ;
  protected B menuBar;
  protected String Ϋ = E.D("PokerApp.ProfileHuman");
  protected String ξ = E.D("PokerApp.TableNameUntitled");
  private volatile boolean ϊ = false;
  private volatile boolean ή = false;
  private boolean θ = false;
  private long γ;
  public static int χ = 0;
  private int σ = 0;
  private CardLayout ό = new CardLayout();
  private volatile com.biotools.poker.G.U ζ = null;
  private com.biotools.poker.G.C φ = null;
  private X μ = new X(this);
  private JPanel ΰ;
  protected JPanel Ψ;
  private com.biotools.poker.P.U ώ;
  private com.biotools.poker.C.R ι;
  private com.biotools.poker.C.A Ω;
  private com.biotools.poker.C.U ϑ;
  private boolean ϔ = true;
  private static Image β = null;
  private static PokerApp ά = null;
  private String ϐ = E.Â() ? "online-lobby" : "frontpage";
  volatile Thread α = null;
  com.biotools.A.L Φ = new com.biotools.A.L();
  private boolean ω = false;
  protected _B[] ϋ = { new _B(0.05D, 0.1D, 0.2D), new _B(0.25D, 0.5D, 1.0D), new _B(0.5D, 1.0D, 2.0D), new _B(1.0D, 2.0D, 4.0D), new _B(1.0D, 3.0D, 6.0D), new _B(2.0D, 4.0D, 8.0D), new _B(2.0D, 5.0D, 10.0D), new _B(5.0D, 10.0D, 20.0D), new _B(10.0D, 15.0D, 30.0D), new _B(10.0D, 20.0D, 40.0D), new _B(15.0D, 25.0D, 50.0D), new _B(15.0D, 30.0D, 60.0D), new _B(20.0D, 40.0D, 80.0D), new _B(25.0D, 50.0D, 100.0D), new _B(50.0D, 100.0D, 200.0D), new _B(100.0D, 200.0D, 400.0D), new _B(200.0D, 400.0D, 800.0D), new _B(250.0D, 500.0D, 1000.0D), new _B(500.0D, 1000.0D, 2000.0D) };
  private Object ϒ = new Object();
  private static final long ο = 86400000L;
  private static final long ϓ = 1209600000L;
  private static final long ψ = 2592000000L;

  public PokerApp()
  {
    ɶ();
  }

  protected void ɶ()
  {
    try
    {
      com.biotools.poker.B.F.A();
      System.setProperty("java.awt.Window.locationByPlatform", "true");
      d.A(E.y() ? 3 : 0);
      d.D(E.n() + "comm/");
      E.Ã();
      ά = this;
      E.C(this);
      E.A(this);
      ɰ();
      com.biotools.poker.N.C.A();
      _.H();
      this.λ = new com.biotools.poker.F.D();
      ɖ();
      setTitle(ʚ());
      setSize(700, 600);
      ʢ();
      this.λ.E();
      getContentPane().add(this.Ψ);
      setResizable(false);
      setIconImage(E.¢);
      setDefaultCloseOperation(0);
      addWindowListener(new WindowAdapter()
      {
        public void windowClosing(WindowEvent paramAnonymousWindowEvent)
        {
          PokerApp.this.ʂ();
        }

        public void windowIconified(WindowEvent paramAnonymousWindowEvent)
        {
          com.biotools.poker.O.M.A(false);
          com.biotools.poker.O.M.B(true);
          PokerApp.this.ʋ().Ǩ().A();
        }

        public void windowDeiconified(WindowEvent paramAnonymousWindowEvent)
        {
          com.biotools.poker.O.M.A(true);
          com.biotools.poker.O.M.B(false);
          PokerApp.this.ʋ().ǋ();
        }
      });
      ɘ();
      Q(false);
      this.κ.Ǭ().G(false);
      com.biotools.poker.O.A.Q();
      E.A("MAINWINDOW", this);
      ʀ();
      ɫ();
      setVisible(true);
      E.H("Window Size: " + getSize());
      E.H("Window Size: " + getContentPane().getSize());
      Ȉ();
      ɳ();
      ʝ();
      this.Χ.C(Ǽ());
    }
    catch (Exception localException)
    {
      com.biotools.A.I.A("Fatal Error on startup", localException);
      setVisible(false);
    }
  }

  private final void ǵ()
  {
    if ((com.biotools.poker.B.A.C()) && (ɸ()))
    {
      E.S();
      return;
    }
    Object localObject = new com.biotools.poker.B.A();
    if ((((com.biotools.poker.B.A)localObject).A()) && (!E.y()))
      return;
    localObject = new com.biotools.poker.B.G(this.έ);
    if (!((com.biotools.poker.B.G)localObject).J())
      System.exit(0);
    E.N();
  }

  public boolean ɸ()
  {
    return (MachineIdentifier.isCDMounted("Poker Academy Pro 2")) || (MachineIdentifier.isCDMounted("PAPro2"));
  }

  private void Ȉ()
  {
    String str = "FIRST_TIME197" + E.Ò + (E.p() ? "DEMO" : "");
    boolean bool = E.£().getBoolean(str, true);
    if ((bool) || (E.p()))
    {
      com.biotools.poker.P.K.A(this, com.biotools.poker.P.N.Ñ().size() == 0);
      E.£().putBoolean(str, false);
      if ((E.Â()) && (!bool))
        ʞ();
    }
    else
    {
      ʞ();
    }
  }

  public void ɧ()
  {
    com.biotools.poker.P.K.A(this, false);
  }

  private void ɢ()
  {
    PokerApp.2 local2 = new PokerApp.2(this);
    com.biotools.B.P.A(this, E.D("PokerApp.LoadingCardsAndSounds"), local2);
  }

  private void ɖ()
  {
    this.ν.setStringPainted(true);
    this.ν.setValue(0);
    this.ν.setString(E.D("PokerApp.Loading"));
    boolean bool = E.A(this.έ);
    com.biotools.poker.C.G.A(bool);
    ɝ();
    com.biotools.poker.I.B.A();
    ɼ();
    this.η = new W(this);
    this.κ = new A(this, bool);
    ǵ();
    this.ν.setValue(5);
    this.ν.setString(E.D("PokerApp.LoadingCards"));
    com.biotools.poker.F.U localU = new com.biotools.poker.F.U();
    com.biotools.poker.F.K localK = new com.biotools.poker.F.K();
    for (int i = 0; i < 52; i++)
    {
      localU.A(new Card(i));
      localK.A(new Card(i));
      this.ν.setValue(5 + (int)(10.0D * (i / 52.0D)));
    }
    this.ν.setValue(15);
    this.ν.setString(E.D("PokerApp.LoadingSounds"));
    this.λ.C();
    this.ν.setValue(25);
    this.ν.setString(E.D("PokerApp.LoadingChips"));
    com.biotools.poker.F.N.A(this);
    this.ν.setValue(30);
    this.ν.setString(E.D("PokerApp.LoadingTables"));
    this.κ.Ǩ().A(this.έ);
    this.ν.setValue(40);
    this.ν.setString(E.D("PokerApp.LoadingHandHistories"));
    this.Ϋ = E.£().get("PROFILE", this.Ϋ);
    this.Υ = new com.biotools.poker.R.R(false);
    this.ν.setString(E.D("PokerApp.LoadingLobby"));
    this.ν.setValue(75);
    com.biotools.poker.R.E.Q();
    this.ν.setString(E.D("PokerApp.LoadingInitializingWindow"));
    this.ν.setValue(80);
    com.biotools.B.A.A(E.£().get("COLOR_SCHEME", "Dark Grey"));
    com.biotools.poker.P.E.j();
    ǲ();
    this.ν.setValue(85);
    S(bool);
    this.ν.setValue(100);
  }

  public Image B(File paramFile)
  {
    return com.biotools.B.L.A(paramFile, this.έ == null ? this : this.έ);
  }

  public void ȅ()
  {
    com.biotools.poker.G.R localR = Ȕ();
    if (localR != null)
      A(localR, true);
  }

  private void A(com.biotools.poker.G.R paramR, boolean paramBoolean)
  {
    if (paramR == null)
      return;
    if (paramR.Q().k())
      return;
    if (this.φ == null)
    {
      E.H("Creating standings dialog!");
      this.φ = new com.biotools.poker.G.C(this);
    }
    if ((paramBoolean) || ((this.φ.isVisible()) && (this.φ.isShowing())))
    {
      E.H("Updating standings dialog!");
      this.φ.A(paramR, ɬ());
      this.φ.B();
      if (paramBoolean)
      {
        this.φ.setVisible(true);
        this.φ.setExtendedState(0);
        this.φ.toFront();
      }
      else
      {
        this.φ.repaint();
      }
    }
    this.Χ.A(paramR);
  }

  private void B(com.biotools.poker.G.R paramR)
  {
    if (paramR == null)
      return;
    if (paramR.Q().k())
      return;
    com.biotools.poker.G.R localR = paramR;
    PokerApp localPokerApp = this;
    SwingUtilities.invokeLater(new PokerApp.3(this, localR));
  }

  private void C(com.biotools.poker.G.R paramR)
  {
    if (paramR == null)
      return;
    com.biotools.poker.G.R localR = paramR;
    String str = ɬ();
    SwingUtilities.invokeLater(new PokerApp.4(this, localR, str));
  }

  public void ɵ()
  {
    com.biotools.poker.P.b localb = new com.biotools.poker.P.b();
    localb.setOpaque(false);
    A(localb, null);
  }

  public void ʆ()
  {
    Ȍ().A(null, true);
  }

  public void A(JPanel paramJPanel)
  {
    A(paramJPanel, null);
  }

  public void A(JPanel paramJPanel, Image paramImage)
  {
    com.biotools.poker.O.M.B(true);
    this.ώ.B = paramImage;
    this.ή = true;
    this.ώ.A(null, (com.biotools.poker.P.V)paramJPanel);
    CardLayout localCardLayout = (CardLayout)this.ΰ.getLayout();
    localCardLayout.show(this.ΰ, "overlay");
    this.menuBar.B(false);
    ((com.biotools.poker.P.V)paramJPanel).K();
    repaint();
  }

  public void ɪ()
  {
    if (this.ϔ)
    {
      ʝ();
      return;
    }
    this.ή = false;
    com.biotools.poker.O.M.B(false);
    CardLayout localCardLayout = (CardLayout)this.ΰ.getLayout();
    localCardLayout.show(this.ΰ, "main");
    this.menuBar.B(true);
    requestFocus();
  }

  public void P(boolean paramBoolean)
  {
    this.ϔ = paramBoolean;
  }

  public void ʝ()
  {
    this.ϐ = "frontpage";
    if (E.Â())
      this.ϐ = "online-lobby";
    ʃ();
  }

  public void ȍ()
  {
    if (E.Ô())
      return;
    this.ϐ = "ring-lobby";
    ʃ();
  }

  public void ʇ()
  {
    if (E.Ô())
      return;
    this.ϐ = "tournament-lobby";
    ʃ();
  }

  public void ʟ()
  {
    ɔ().Ġ();
    this.ϐ = "online-lobby";
    ʃ();
  }

  public void ʃ()
  {
    if (ɔ().ę())
    {
      if (ɔ().ĝ().I(true))
        return;
      int i = JOptionPane.showConfirmDialog(this, E.D("PokerApp.LeaveRoomText"), E.D("PokerApp.LeaveRoomHeading"), 0);
      if (i == 0)
      {
        X(false);
        if (this.ϐ.equals("online-lobby"))
          ʟ();
      }
      else
      {
        return;
      }
    }
    if ((this.ϐ.equals("online-lobby")) && (ɔ().Ĥ()))
      ɔ().setVisible(true);
    this.ή = true;
    this.ό.show(this.Ψ, this.ϐ);
    this.menuBar.B(false);
  }

  public void A(com.biotools.poker.E.E paramE, _B param_B, int paramInt)
  {
    ɓ();
    ʒ();
    com.biotools.poker.O.C.J.I();
    if (this.Ϊ != this.ύ)
    {
      if (this.Ϊ != null)
        this.Ϊ.g();
      this.Ϊ = this.ύ;
    }
    Q(false);
    A(paramE);
    if (paramInt != -1)
    {
      this.σ = paramInt;
      n(paramInt);
    }
    this.Ϊ.A(com.biotools.poker.C.R.V());
    A(param_B, false);
    ɣ();
    this.Χ.C();
    ʈ();
    this.Χ.E(false);
  }

  protected void ʢ()
  {
    this.menuBar = new B(this);
    setJMenuBar(this.menuBar);
  }

  protected JPanel Y(boolean paramBoolean)
  {
    JPanel localJPanel = new JPanel(new BorderLayout(0, 0));
    localJPanel.add(ʉ(), "Center");
    if (paramBoolean)
      ɽ();
    else
      localJPanel.add(this.Χ, "East");
    return localJPanel;
  }

  protected JComponent S(boolean paramBoolean)
  {
    this.ί = new com.biotools.poker.C.D();
    this.Ψ = new JPanel();
    this.Ψ.setLayout(this.ό);
    this.Ψ.add(new com.biotools.poker.C.P(this), "frontpage");
    this.Ψ.add(Y(paramBoolean), "main");
    this.ι = new com.biotools.poker.C.R();
    this.Ψ.add(this.ι, "ring-lobby");
    this.Ψ.add(this.ί, "tournament-lobby");
    this.Ψ.add(ȃ(), "online-lobby");
    if (E.Â())
      this.ό.show(this.Ψ, "online-lobby");
    return this.Ψ;
  }

  public com.biotools.poker.C.U ȃ()
  {
    if (this.ϑ == null)
      this.ϑ = new com.biotools.poker.C.U(ɔ());
    return this.ϑ;
  }

  private void ǲ()
  {
    this.ε = new com.biotools.poker.L.G(this);
    this.ς = new com.biotools.poker.K.F();
    this.Χ = new com.biotools.poker.J.B(this);
  }

  public void ɽ()
  {
    if (E.Ð())
      this.Χ.B();
  }

  public void B(String paramString, int paramInt)
  {
    if (paramInt != 0)
    {
      com.biotools.poker.J.E localE = this.Χ.G();
      synchronized (localE)
      {
        this.Χ.G().A(paramString, paramInt);
      }
    }
  }

  public void A(String paramString1, int paramInt1, String paramString2, int paramInt2)
  {
    if (paramInt1 != 0)
    {
      com.biotools.poker.J.E localE = this.Χ.G();
      synchronized (localE)
      {
        this.Χ.G().A(paramString1, paramInt1);
        this.Χ.G().A(paramString2, paramInt2);
      }
    }
  }

  public com.biotools.poker.R.R Ȇ()
  {
    return this.Υ;
  }

  public com.biotools.poker.R.V ʣ()
  {
    return this.Υ.Ġ();
  }

  public com.biotools.poker.R.U ǳ()
  {
    return this.Υ.ġ();
  }

  public void A(com.biotools.poker.R.U paramU)
  {
    this.Υ.F(paramU);
  }

  public void ɛ()
  {
    if (E.Ú())
      return;
    if (!ɞ().isGameOver())
      this.ς.A(ɞ(), this.ρ, this.π);
    this.ς._();
  }

  public void ȕ()
  {
    this.Υ.setVisible(true);
  }

  public void ɹ()
  {
    this.Υ.setVisible(true);
  }

  public void ȋ()
  {
    this.Υ.setVisible(true);
    this.Υ.ĳ();
  }

  public void ɥ()
  {
    this.ε.L();
  }

  public com.biotools.poker.L.G ȇ()
  {
    return this.ε;
  }

  protected JPanel ʉ()
  {
    this.ΰ = new JPanel(new CardLayout());
    this.ώ = new com.biotools.poker.P.U(this);
    this.ΰ.add(this.ώ, "overlay");
    this.ΰ.add(this.κ, "main");
    return this.ΰ;
  }

  public void A(Card paramCard1, Card paramCard2, int paramInt)
  {
    this.ρ = paramCard1;
    this.π = paramCard2;
    χ = paramInt;
    if (!ʁ())
    {
      this.κ.B(χ, paramCard1, paramCard2);
      if (ɞ().isActive(paramInt))
      {
        Object[] arrayOfObject = { paramCard1.toTranslatedString(), paramCard2.toTranslatedString() };
        E.A(E.A("PokerApp.HoleCardsTranscriptPattern", arrayOfObject) + "\n", 2);
      }
    }
    if (this.ς.isShowing())
      this.ς.A(ɞ(), paramCard1, paramCard2);
  }

  private void ɑ()
  {
    if (this.ζ == null)
      return;
    if (this.ζ.I())
      return;
    if (!this.ζ.g())
      return;
    this.ϊ = false;
    Q(true);
    if (this.Ϊ != null)
    {
      assert (this.Ϊ != this.ύ) : "Dealing tournament hand: coming from ring dealer!";
      assert (this.Ϊ != this.δ) : "Dealing tournament hand: coming from replay dealer!";
      assert (!(this.Ϊ instanceof com.biotools.poker.Q.B)) : "Dealing tournament hand: coming from instanceof replay dealer!";
    }
    this.Χ.E(true);
    int i = 1;
    if (this.ζ != null)
    {
      this.ζ.T();
      i = this.ζ.H() == 0 ? 1 : 0;
      if ((this.ζ != null) && (i != 0))
        R(true);
    }
    else
    {
      return;
    }
    if ((this.ζ != null) && (i != 0))
    {
      ʘ();
      this.ζ.A(this.Ϊ, this, this.Ϋ, this.η);
      this.κ.A(this.Ϊ);
    }
    if (this.ζ != null)
    {
      this.ζ.F(this.Ϊ);
      i = this.ζ.H() == 5 ? 1 : 0;
      if ((this.ζ != null) && (i != 0))
        R(true);
    }
    else
    {
      return;
    }
    if (this.ζ != null)
    {
      this.ζ._();
      E.q();
      if (this.ζ != null)
      {
        i = this.ζ.H() == 6 ? 1 : 0;
        if ((this.ζ != null) && (i != 0))
          R(true);
      }
      else
      {
        return;
      }
    }
    else
    {
      return;
    }
    if ((this.ζ != null) && (i != 0))
    {
      assert (this.ζ.H() == 6) : ("tournMan.getState() = " + this.ζ.Z());
      W((this.ζ != null) && (!this.ζ.I()));
    }
  }

  private void ʘ()
  {
    com.biotools.poker.Q.K localK = this.ζ.A(this.Ϋ);
    if (localK == null)
      if ((this.Ϊ != null) && (this.ζ.D(this.Ϊ)))
        localK = this.Ϊ;
      else
        localK = this.ζ.A();
    if (this.Ϊ != localK)
      this.Ϊ = localK;
  }

  private void ʌ()
  {
    if (this.α == null)
    {
      this.α = new Thread(new Runnable()
      {
        public void run()
        {
          while (PokerApp.this.α != null)
            try
            {
              Thread localThread = Thread.currentThread();
              if (!localThread.isAlive())
                E.H("Somehow the thread is not alive");
              Runnable localRunnable = (Runnable)PokerApp.this.Φ.C();
              localRunnable.run();
            }
            catch (InterruptedException localInterruptedException)
            {
            }
        }
      }
      , "doDealHandThread");
      this.α.start();
    }
  }

  public void ǰ()
  {
    ʌ();
    synchronized (this.Φ)
    {
      if (this.Φ.B() > 0)
        return;
      this.Φ.A(new Runnable()
      {
        public void run()
        {
          PokerApp.this.ʊ();
        }
      });
    }
  }

  public void ɺ()
  {
    ʌ();
    synchronized (this.Φ)
    {
      if (this.Φ.B() > 0)
        return;
      this.Φ.A(new PokerApp.7(this));
    }
  }

  public void ʊ()
  {
    if ((this.ή) || (ʐ().R()))
      return;
    Ȃ();
    if ((Ǳ()) && (!ʔ()))
    {
      ɑ();
    }
    else
    {
      if ((Ǳ()) && (ʔ()))
        E.H("Instant replaying in the middle of a tournament!");
      else if (Ȑ())
        ʐ().A(false);
      Q(true);
      this.ϊ = false;
      ɞ().D(com.biotools.poker.Q.E.B());
      com.biotools.poker.O.C.J.A(ɞ().isNoLimit());
      ʐ().V();
    }
  }

  public boolean ɮ()
  {
    if (ʐ().R())
    {
      boolean bool = this.ή;
      this.ή = true;
      int i = JOptionPane.showConfirmDialog(this, E.D("PokerApp.AbortHandText"), E.D("PokerApp.AbortHandHeading"), 0);
      this.ή = bool;
      if (i == 0)
      {
        ɓ();
        return true;
      }
      return false;
    }
    return true;
  }

  public void ɓ()
  {
    synchronized (this.Φ)
    {
      com.biotools.poker.O.M.A(false);
      com.biotools.poker.O.M.B(true);
      E.H("Trying to abort hand");
      if (ʐ().R())
      {
        this.ϊ = true;
        ɾ();
        boolean bool = this.ή;
        this.η.A(Action.foldAction(0.0D));
        ʋ().Ǩ().A();
        this.ή = true;
        ʙ();
        this.κ.Ǟ();
        Q(false);
        this.ή = bool;
        this.κ.ǋ();
      }
      else
      {
        E.H("Trying to abort hand outside of gameInProgress");
        if ((Ǳ()) && (!ʔ()))
        {
          ɦ();
          ʋ().Ǩ().A();
          ʛ();
          E.H("Leaving abort hand outside of gameInProgress");
        }
      }
      this.Φ.A();
      com.biotools.poker.O.M.A(true);
      com.biotools.poker.O.M.B(false);
    }
  }

  private void ɾ()
  {
    ɦ();
    this.Ϊ.E();
  }

  private void ʙ()
  {
    ʛ();
    ʐ().Q();
  }

  protected void D(Action paramAction)
  {
    A(paramAction, false);
  }

  protected void A(Action paramAction, boolean paramBoolean)
  {
    if (this.η.ċ())
    {
      int i = 1;
      try
      {
        i = (!paramBoolean) && (!com.biotools.poker.M.F.A(this, paramAction, χ, this.ρ, this.π, ɞ())) ? 0 : 1;
      }
      catch (Exception localException)
      {
        com.biotools.A.I.A("Error encountered when evaluating action", localException);
      }
      if (i != 0)
        E(paramAction);
      else
        O(false);
    }
  }

  public void E(Action paramAction)
  {
    if (this.η.ċ())
    {
      this.η.A(paramAction);
      ǿ();
      if ((paramAction.isFold()) && (!Ǽ()))
        if (Ǻ())
          ȑ();
        else if (this.Ϊ.C().getNumActivePlayers() > 2)
          this.κ.Ǣ().G(true);
    }
  }

  public A ʋ()
  {
    return this.κ;
  }

  public com.biotools.poker.Q.K ʐ()
  {
    return this.Ϊ;
  }

  public com.biotools.poker.M.C ʑ()
  {
    return this.Χ.A();
  }

  public com.biotools.poker.J.B ɿ()
  {
    return this.Χ;
  }

  public void o(int paramInt)
  {
    this.κ.X(paramInt);
  }

  public void O(boolean paramBoolean)
  {
    double d = ɞ().getAmountToCall(χ);
    if (ɞ().getNumToAct() > 0)
    {
      com.biotools.poker.O.M.B(false);
      ɞ().C(false);
      this.κ.B(d, χ);
      if ((!this.ω) && (paramBoolean))
      {
        this.λ.M();
        if ((ɒ()) && (!this.Χ.G().A()) && (getExtendedState() == 1))
        {
          setExtendedState(0);
          toFront();
        }
      }
      this.κ.ǋ();
      this.Χ.A(this.ρ, this.π);
    }
    this.ω = true;
  }

  public void ǿ()
  {
    this.ω = false;
    this.κ.ǜ();
  }

  private void F(Action paramAction)
  {
    switch (paramAction.getType())
    {
    case 5:
    case 6:
      break;
    case 0:
    case 9:
      this.λ.B();
      break;
    case 1:
      this.λ.U();
      break;
    case 2:
      this.λ.G();
      break;
    case 3:
    case 7:
    case 12:
      this.λ.H();
      break;
    case 4:
      this.λ.R();
      break;
    case 8:
    case 10:
    case 11:
    }
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
    if (!this.Ϊ.R())
      return;
    if (paramAction.isVoluntary())
      i(paramInt);
    F(paramAction);
    ǿ();
    this.κ.B(paramInt, paramAction);
    if ((this.Ϊ.R()) && (ɞ().getNumToAct() >= 1))
      o(this.Ϊ.e());
  }

  public void dealHoleCardsEvent()
  {
    this.κ.ǒ();
  }

  public void gameStateChanged()
  {
    this.κ.ǅ();
    this.Χ.A(this.ρ, this.π);
  }

  private boolean ɠ()
  {
    if (ɞ().isZipMode())
      return true;
    return ((com.biotools.poker.P.E.i()) || (Ǻ())) && (!this.Ϊ.C().isActive(χ));
  }

  private void i(int paramInt)
  {
    if (Ǽ())
      return;
    if (ʓ())
    {
      ə();
    }
    else if (paramInt == χ)
    {
      A(100L);
    }
    else
    {
      A(10L);
      if (ɠ())
        return;
      ə();
    }
    this.γ = System.currentTimeMillis();
  }

  private void ə()
  {
    long l = com.biotools.poker.P.E.m() - (System.currentTimeMillis() - this.γ);
    if (l > com.biotools.poker.P.E.m())
      l = com.biotools.poker.P.E.m();
    if (l > 0L)
      A(l);
  }

  protected void A(long paramLong)
  {
    try
    {
      Thread.sleep(paramLong);
    }
    catch (InterruptedException localInterruptedException)
    {
    }
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
    this.κ.A(paramInt, paramDouble, paramString);
    ʅ();
  }

  private void ʅ()
  {
    if (this.ϊ)
      return;
    if (Ǽ())
      return;
    A(400L);
    if (ɠ())
      return;
    if (ɞ().getNumActivePlayers() > 1)
      A(com.biotools.poker.P.E.k());
  }

  public com.biotools.poker.F.D ȏ()
  {
    return this.λ;
  }

  public void gameOverEvent()
  {
    if ((Ǳ()) && (!ʔ()))
      return;
    this.κ.ǂ();
    Q(false);
    if (ɞ().getNumPlayers() < 2)
    {
      if ((!Ǳ()) && (!ʔ()) && (!Ǽ()))
        this.κ.w(E.D("PokerApp.NotEnoughPlayers"));
      E.q();
      return;
    }
    ɱ();
    if (ɞ().b() % 10L == 0L)
    {
      System.runFinalization();
      System.gc();
      System.err.println("MEM: " + com.biotools.B.L.B());
    }
    if ((!ʓ()) && (!Ǽ()))
      U(true);
    E.q();
    if (this.Ϊ == this.ύ)
      Ǿ();
    if ((ɞ().inGame(χ)) && (!this.Χ.G().A()) && (isActive()))
      requestFocus();
  }

  public void Ǵ()
  {
    this.κ.ǂ();
    if (ɞ().getNumPlayers() < 2)
    {
      if (Ǽ())
        E.q();
      return;
    }
    ɱ();
    if (ɞ().b() % 10L == 0L)
    {
      System.runFinalization();
      System.gc();
      System.err.println("MEM: " + com.biotools.B.L.B());
    }
    if (!Ǽ())
      U(true);
    if (Ǽ())
      E.q();
  }

  private void U(boolean paramBoolean)
  {
    final boolean bool = paramBoolean;
    SwingUtilities.invokeLater(new Runnable()
    {
      private final boolean val$visibleVal;

      public void run()
      {
        PokerApp.this.menuBar.A(bool);
      }
    });
  }

  private void W(boolean paramBoolean)
  {
    Q(false);
    if ((ɞ().inGame(χ)) && (!this.Χ.G().A()) && (isActive()))
      requestFocus();
    if ((paramBoolean) && (ʗ()))
      ɺ();
  }

  public void Ȃ()
  {
    if (this.Ϊ == this.δ)
      if (this.δ.v())
      {
        this.δ.t();
        this.κ.K(this.δ.£());
        com.biotools.poker.R.E localE = this.δ.À();
        if (localE.a() >= 0)
          y(localE.U());
      }
      else if (!this.δ.£())
      {
        χ = 0;
        this.δ.g();
        this.δ = null;
        this.Ϊ = this.τ;
        this.κ.A(this.τ);
        E.H("Restoring dealer: " + this.Ϊ.getClass());
      }
      else
      {
        this.δ.Ä();
        Ȃ();
      }
  }

  private void ɼ()
  {
    if (this.ύ == null)
    {
      this.ύ = new com.biotools.poker.Q.K();
      this.ύ.B(this);
    }
    this.ύ.A(com.biotools.poker.C.R.V());
    this.Ϊ = this.ύ;
  }

  public boolean Ǳ()
  {
    return Ȕ() != null;
  }

  public String ɴ()
  {
    return Ǽ() ? com.biotools.poker.R.U.K : com.biotools.poker.R.U.Q;
  }

  private void ɱ()
  {
    try
    {
      if ((ɞ().d() != null) && (this.Ϊ.T()))
      {
        com.biotools.poker.G.R localR = Ȕ();
        String str = ɴ();
        com.biotools.poker.R.E localE = new com.biotools.poker.R.E(ɞ(), this.Ϋ, str, this.ξ, localR);
        if (localE != null)
          this.Υ.K(localE);
        if (localR == null)
          ɞ().O();
      }
    }
    catch (Exception localException)
    {
      com.biotools.A.I.A("logGame() failed", localException);
    }
  }

  public com.biotools.poker.G.R Ȕ()
  {
    if (this.ζ != null)
      return this.ζ.X();
    if (Ǽ())
      return ((com.biotools.poker.Q.J)this.Ϊ).ö();
    return null;
  }

  private void Q(boolean paramBoolean)
  {
    this.κ.Ǭ().A(E.D("PokerApp.DealButton"));
    this.κ.Ǭ().G((!paramBoolean) && (!Ǽ()) && (!ʓ()));
    this.κ.K(ʓ());
    this.κ.Ǣ().G(false);
    if ((paramBoolean) && (this.Ϊ.R()) && (!this.ϊ) && (!Ǽ()))
    {
      com.biotools.poker.O.M.B(false);
      com.biotools.poker.D.G.A(ɞ()).D(true);
    }
    if (!paramBoolean)
      ʋ().Ǆ().D(false);
    ǿ();
    this.κ.M(this.κ.ǉ());
    this.κ.ǋ();
  }

  private void Ǿ()
  {
    if ((ʗ()) && (ɞ().G() > 1))
    {
      Timer localTimer = new Timer(com.biotools.poker.P.E.h(), new AbstractAction()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          if ((!PokerApp.this.ϊ) && (!PokerApp.this.ή) && (!PokerApp.this.Ǽ()))
          {
            E.H(" *** AUTO-DEAL *** ");
            PokerApp.this.ǰ();
          }
        }
      });
      localTimer.setRepeats(false);
      localTimer.start();
    }
  }

  protected boolean ʗ()
  {
    return E.£().getBoolean("AUTO_DEAL", false);
  }

  protected boolean ɗ()
  {
    return E.£().getBoolean("AUTO_UPDATE", true);
  }

  protected boolean Ȓ()
  {
    return true;
  }

  public boolean Ǻ()
  {
    return E.£().getBoolean("INSTANT_FOLDS", false);
  }

  public boolean Ȑ()
  {
    if (this.Ϊ != this.ύ)
      return false;
    return E.£().getBoolean("FREEZE_BUTTON", false);
  }

  protected boolean ɻ()
  {
    return E.£().getBoolean("SOUND_EFFECTS", true);
  }

  protected boolean ɡ()
  {
    return E.£().getBoolean("PEEKING", true);
  }

  protected boolean ʁ()
  {
    return E.£().getBoolean("FACE_DOWN", false);
  }

  public void ʖ()
  {
    if (!ʁ())
      this.κ.B(χ, this.ρ, this.π);
    else if (!Ȁ())
      this.κ.B(χ, null, null);
  }

  public boolean Ȁ()
  {
    if (E.Ú())
      return false;
    if (ʓ())
      return true;
    return E.£().getBoolean("ALL_FACE_UP", false);
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
    this.κ.C(paramInt, paramCard1, paramCard2);
    if (ɞ().getStage() >= 3)
      ʅ();
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    Q(true);
    com.biotools.poker.O.C.J.A(paramGameInfo.isNoLimit());
    this.ρ = (this.π = null);
    this.λ.P();
    this.κ.B(this.Ϊ);
    ɣ();
  }

  private void ɣ()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    Object localObject;
    if (ʔ())
    {
      localObject = ((com.biotools.poker.Q.B)this.Ϊ).À();
      Object[] arrayOfObject;
      if (((com.biotools.poker.R.E)localObject).O())
      {
        if (ɞ().isNoLimit())
          localStringBuffer.append(E.D("PokerApp.NLTournamentGameTitle"));
        else
          localStringBuffer.append(E.D("PokerApp.LimitTournamentGameTitle"));
        if (ɞ().getAnte() > 0.0D)
        {
          arrayOfObject = new Object[] { Action.formatCash(ɞ().getAnte()) };
          localStringBuffer.append(" " + E.A("PokerApp.AntePattern", arrayOfObject) + ", ");
        }
        arrayOfObject = new Object[] { Action.formatCash(ɞ().getSmallBlindSize()), Action.formatCash(ɞ().getBigBlindSize()) };
        localStringBuffer.append(" " + E.A("PokerApp.BlindsPattern", arrayOfObject));
      }
      else if (ɞ().isNoLimit())
      {
        arrayOfObject = new Object[] { Action.formatCash(ɞ().getSmallBlindSize()), Action.formatCash(ɞ().getBigBlindSize()) };
        localStringBuffer.append(E.A("PokerApp.NLRingGamePattern", arrayOfObject));
      }
      else
      {
        arrayOfObject = new Object[] { Action.formatCash(ɞ().K()), Action.formatCash(ɞ().N()) };
        localStringBuffer.append(E.A("PokerApp.LimitRingGamePattern", arrayOfObject));
      }
      localStringBuffer.append(" - ");
      if (this.δ.£())
      {
        arrayOfObject = new Object[] { new Integer(this.δ.u()), new Integer(this.δ.Â()) };
        localStringBuffer.append(E.A("PokerApp.PlayingBackHandNumberPattern", arrayOfObject));
      }
      else
      {
        localStringBuffer.append(E.D("PokerApp.RedealingLastHand"));
      }
    }
    else if (Ǳ())
    {
      localStringBuffer.append(Ȕ().o());
    }
    else if (ɞ().isNoLimit())
    {
      localObject = new Object[] { Action.formatCash(ɞ().getSmallBlindSize()), Action.formatCash(ɞ().getBigBlindSize()) };
      localStringBuffer.append(E.A("PokerApp.NLRingGamePattern", (Object[])localObject));
    }
    else
    {
      localObject = new Object[] { Action.formatCash(ɞ().K()), Action.formatCash(ɞ().N()) };
      localStringBuffer.append(E.A("PokerApp.LimitRingGamePattern", (Object[])localObject));
    }
    this.κ.v(localStringBuffer.toString());
  }

  public String ɬ()
  {
    return this.Ϋ;
  }

  public void stageEvent(int paramInt)
  {
    if ((this.Ϊ.o()) && (!Ǽ()))
      ʅ();
    int i = -1;
    switch (paramInt)
    {
    case 0:
      if ((!ʁ()) && (this.ρ != null) && (this.π != null))
        this.κ.B(χ, this.ρ, this.π);
      i = -1;
      break;
    case 1:
      i = 0;
      break;
    case 2:
      i = 3;
      break;
    case 3:
      i = 4;
    }
    this.κ._(paramInt);
    int j = ɞ().nextActivePlayer(ɞ().M());
    this.Χ.A(this.ρ, this.π);
    this.λ.T();
    this.κ.A(ɞ().getBoard(), i);
    if (this.κ.c(paramInt))
      this.κ.ǋ();
    o(j);
    if ((this.ς.isShowing()) && (this.ρ != null) && (this.π != null))
      this.ς.A(ɞ(), this.ρ, this.π);
  }

  public com.biotools.poker.Q.D ɞ()
  {
    return this.Ϊ.C();
  }

  public void ʠ()
  {
    ʂ();
  }

  public void ʂ()
  {
    if ((ɔ().ę()) && (!E.D()) && (!ɔ().Ĭ()))
      return;
    try
    {
      ɓ();
      ɔ().Ĵ();
      com.biotools.poker.D.G.A(ɞ()).Ź();
      ʒ();
      E.N();
      this.Υ.Ĵ();
      dispose();
      ʐ().j();
      System.out.flush();
      System.err.flush();
    }
    catch (Exception localException1)
    {
      d.A(localException1);
    }
    try
    {
      if (E.p())
        com.biotools.poker.B.D.J();
    }
    catch (Exception localException2)
    {
      d.A(localException2);
    }
    System.exit(0);
  }

  public void y(String paramString)
  {
    if (!paramString.equals(this.Ϋ))
    {
      ɓ();
      ʒ();
    }
    else
    {
      return;
    }
    this.Ϋ = paramString;
    this.Ϊ.A(0, this.Ϋ, this.η);
    this.κ.A(this.Ϊ);
    E.£().put("PROFILE", this.Ϋ);
    this.menuBar.n();
  }

  public void ɨ()
  {
    E.H("Opponenet Editor " + com.biotools.A.F.B());
    if (((!Ǽ()) && (ɮ())) || (Ǽ()))
    {
      boolean bool = com.biotools.poker.E.C.J();
      if (bool)
      {
        E.H("Reloading Players...");
        ɟ();
      }
    }
  }

  public void ɟ()
  {
    E.H("Reloading Players...");
    for (int i = 0; i < 10; i++)
      if ((i != χ) && (this.Ϊ.H(i)))
      {
        com.biotools.poker.E.B localB = com.biotools.poker.E.B.D(this.Ϊ.F(i));
        if (localB != null)
        {
          localB.O();
        }
        else
        {
          Ȅ().k(i);
          Ȅ().ʋ().ǋ();
        }
      }
  }

  public void A(int paramInt, boolean paramBoolean)
  {
    if (!ɮ())
    {
      this.menuBar.B(-1);
      return;
    }
    ɞ().L(paramInt);
    this.Ϊ.A(paramInt, paramBoolean);
    this.κ.f(paramInt);
    this.menuBar.B(paramInt);
    this.κ.ǋ();
  }

  public void B(com.biotools.poker.E.B paramB, int paramInt)
  {
    Player localPlayer = B(paramB);
    if ((localPlayer != null) && (!this.Ϊ.R()))
    {
      this.Ϊ.A(paramInt, paramB.J(), localPlayer);
      this.menuBar.n();
    }
  }

  private Player B(com.biotools.poker.E.B paramB)
  {
    return com.biotools.poker.E.B.F(paramB.M());
  }

  public void C(com.biotools.poker.E.B paramB, int paramInt)
  {
    String str = null;
    if (ɮ())
    {
      if (paramB != null)
        str = paramB.M();
      B(paramB, paramInt);
    }
  }

  public void A(com.biotools.poker.E.B paramB)
  {
    if (paramB == null)
      return;
    if (paramB.J() == null)
      return;
    for (int i = 0; i < 10; i++)
      if ((this.Ϊ.H(i)) && (this.Ϊ.F(i).equals(paramB.J())))
        this.Ϊ.R(i);
  }

  public void k(int paramInt)
  {
    if (ɮ())
    {
      this.Ϊ.R(paramInt);
      this.menuBar.n();
    }
  }

  public void ɷ()
  {
    E.q();
    String str = JOptionPane.showInputDialog(this, E.D("PokerApp.SaveTableText"), E.D("PokerApp.SaveTableHeading"), 3);
    if (str != null)
    {
      str = str.trim();
      if (com.biotools.poker.C.R.A(str, 1, 30))
      {
        com.biotools.poker.E.E localE = new com.biotools.poker.E.E();
        localE.C(ɞ().isNoLimit());
        localE.A(true);
        localE.M();
        localE.D(str);
        for (int i = 1; i < 10; i++)
          if (this.Ϊ.H(i))
          {
            localE.B();
            localE.B(i, this.Ϊ.F(i));
          }
          else
          {
            localE.B();
          }
        localE.T();
        this.ι.Z().A(localE);
      }
      else
      {
        JOptionPane.showMessageDialog(this, E.D("PokerApp.SaveTableErrorText"), E.D("PokerApp.SaveTableErrorHeading"), 0);
      }
    }
  }

  private void A(com.biotools.poker.E.E paramE)
  {
    if (!ɮ())
      return;
    this.ξ = paramE.J();
    ʋ().Ǩ().A();
    this.κ.Ǭ().G(false);
    com.biotools.poker.O.C.J.A(paramE.O());
    ɞ().B(paramE.O());
    this.Ϊ.j();
    this.Ϊ.A(0, this.Ϋ, this.η);
    for (int i = 1; i < paramE.R(); i++)
      if (!paramE.D(i))
        B(paramE.F(i), i);
    this.κ.A(this.Ϊ);
    this.menuBar.n();
    A(0, true);
    Q(false);
    ʋ().Ǟ();
    ʋ().Ǩ().A();
    ʋ().ǋ();
  }

  public void D(com.biotools.poker.R.E paramE)
  {
    com.biotools.poker.R.V localV = new com.biotools.poker.R.V();
    localV.D(paramE);
    A(localV);
  }

  public void A(com.biotools.poker.R.V paramV)
  {
    if ((Ǽ()) || (!ɮ()))
      return;
    ʒ();
    try
    {
      E.q();
      if (this.δ != null)
        this.δ.g();
      this.δ = new com.biotools.poker.Q.B(paramV, this.η);
      this.δ.B(true);
      this.κ.ǧ().A(this.δ);
      if (!(this.Ϊ instanceof com.biotools.poker.Q.B))
        this.τ = this.Ϊ;
      this.Ϊ = this.δ;
      this.Ϊ.B(this);
      this.κ.A(this.Ϊ);
      this.Χ.C();
      ʈ();
      this.Χ.E(false);
      ǰ();
    }
    catch (Exception localException)
    {
      d.A(localException);
      JOptionPane.showMessageDialog(this, E.D("PokerApp.UnableToSetupHand"));
    }
  }

  public boolean ɜ()
  {
    return (ǳ() != null) && (ʣ().È() != null) && (ʣ().È()._() == ǳ());
  }

  public void Ȏ()
  {
    if (ɜ())
      C(ʣ().È());
  }

  public void C(com.biotools.poker.R.E paramE)
  {
    if ((paramE == null) || (Ǽ()) || (!ɮ()))
      return;
    try
    {
      if (this.δ != null)
        this.δ.g();
      this.δ = new com.biotools.poker.Q.C(paramE, this.Ϊ, this.η);
      if (!(this.Ϊ instanceof com.biotools.poker.Q.B))
        this.τ = this.Ϊ;
      this.Ϊ = this.δ;
      this.Ϊ.B(this);
      this.κ.A(this.Ϊ);
      ʈ();
      this.Χ.E(false);
      ǰ();
    }
    catch (Exception localException)
    {
      d.A(localException);
      JOptionPane.showMessageDialog(this, E.D("PokerApp.UnableToSetupHand"));
    }
  }

  public void p(int paramInt)
  {
    if (Ǽ())
      return;
    if ((ɞ().inGame(paramInt)) && (!ɮ()))
      return;
    if ((this.Ϊ != null) && (this.Ϊ.E(paramInt) != null))
      A(new Y(paramInt, ɞ().N(), this.Ϊ.E(paramInt).getBankRoll()));
  }

  public void m(int paramInt)
  {
    if (!Ǽ())
      return;
    com.biotools.poker.Q.J localJ = (com.biotools.poker.Q.J)this.Ϊ;
    localJ.Y(paramInt);
  }

  public void l(int paramInt)
  {
    if (Ǽ())
    {
      com.biotools.poker.Q.J localJ = (com.biotools.poker.Q.J)this.Ϊ;
      if (localJ.õ())
        localJ.û();
      else
        localJ.G(localJ.è());
    }
    else
    {
      p(χ);
    }
  }

  public void C(int paramInt, double paramDouble)
  {
    if (paramDouble > 0.0D)
    {
      com.biotools.poker.Q.J localJ = (com.biotools.poker.Q.J)this.Ϊ;
      localJ.G(paramDouble);
    }
  }

  public void A(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    if (!Ǽ())
      return;
    Y localY = new Y();
    localY.F(paramDouble2);
    localY.K();
    A(localY);
  }

  public void N(double paramDouble)
  {
    if (!Ǽ())
      return;
    E.H("Requesting " + paramDouble + " chips");
    com.biotools.poker.Q.J localJ = (com.biotools.poker.Q.J)this.Ϊ;
    localJ.G(paramDouble);
  }

  public void ȉ()
  {
    if ((!ɮ()) || (Ǽ()))
      return;
    A(new com.biotools.poker.P.G(ɞ().N(), ȁ()));
  }

  public void ʡ()
  {
    this.κ.ǋ();
  }

  public void n(int paramInt)
  {
    for (int i = 0; i < 10; i++)
      if (this.Ϊ.H(i))
        this.Ϊ.E(i).E(paramInt);
    this.κ.A(this.Ϊ);
    this.κ.ǋ();
  }

  public static JButton ɩ()
  {
    return new com.biotools.B.J("help.png", E.D("PokerApp.ShowHelpButtonToolTip"));
  }

  public static void z(String paramString)
  {
    com.biotools.B.R localR = com.biotools.B.R.B("Help");
    localR.A(paramString);
  }

  public void Ȗ()
  {
    com.biotools.B.R.B("Help");
  }

  public void ɘ()
  {
    if (!ȓ())
      return;
    double d1 = E.£().getDouble("SMALL_BLIND_SIZE", 5.0D);
    double d2 = E.£().getDouble("SMALL_BET_SIZE", 10.0D);
    double d3 = E.£().getDouble("BIG_BET_SIZE", 20.0D);
    for (int i = 0; i < this.ϋ.length; i++)
      if ((this.ϋ[i].C == d2) && (this.ϋ[i].B == d3))
        A(this.ϋ[i], false);
  }

  public _B[] ɭ()
  {
    return this.ϋ;
  }

  public void A(_B param_B, boolean paramBoolean)
  {
    if ((ɮ()) && ((paramBoolean) || (ȓ())))
    {
      ɞ().A(param_B.D, param_B.C, param_B.B);
      E.£().putDouble("SMALL_BLIND_SIZE", param_B.D);
      E.£().putDouble("SMALL_BET_SIZE", param_B.C);
      E.£().putDouble("BIG_BET_SIZE", param_B.B);
      return;
    }
  }

  public void ȑ()
  {
    com.biotools.poker.O.M.B(true);
    ɞ().C(true);
    if ((!ɞ().E(χ)) && (ɞ().getPlayer(χ).isFolded()))
      com.biotools.poker.D.G.A(ɞ()).D(false);
    this.κ.Ǣ().G(false);
  }

  public void ɰ()
  {
    this.έ = new JFrame(E.Ò());
    this.έ.setIconImage(E.¢);
    this.έ.setUndecorated(true);
    this.έ.getRootPane().setWindowDecorationStyle(0);
    File localFile = E.K("pix/poki-splash.png");
    if (E.Ú())
      localFile = E.K("pix/poki-splash-lite.png");
    JLabel localJLabel = new JLabel(new ImageIcon(localFile.getPath()));
    localJLabel.setMinimumSize(localJLabel.getPreferredSize());
    this.ν.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
    this.ν.setStringPainted(true);
    this.έ.getContentPane().add(localJLabel, "Center");
    this.έ.getContentPane().add(this.ν, "South");
    com.biotools.B.L.A(this.έ);
    this.έ.setVisible(true);
    this.έ.toFront();
  }

  public void ɫ()
  {
    if (this.έ != null)
    {
      this.έ.setVisible(false);
      this.έ.dispose();
      this.έ = null;
      this.ν = null;
    }
  }

  private void ɳ()
  {
    if (E.¤())
      try
      {
        Class localClass1 = Class.forName("com.apple.mrj.MRJApplicationUtils");
        Class localClass2 = Class.forName("com.apple.mrj.MRJQuitHandler");
        Class[] arrayOfClass1 = { localClass2 };
        Method localMethod1 = localClass1.getDeclaredMethod("registerQuitHandler", arrayOfClass1);
        if (localMethod1 != null)
        {
          localObject = new Object[] { this };
          localMethod1.invoke(localClass1, (Object[])localObject);
        }
        Object localObject = Class.forName("com.apple.mrj.MRJAboutHandler");
        Class[] arrayOfClass2 = { localObject };
        Method localMethod2 = localClass1.getDeclaredMethod("registerAboutHandler", arrayOfClass2);
        if (localMethod2 != null)
        {
          Object[] arrayOfObject = { this };
          localMethod2.invoke(localClass1, arrayOfObject);
        }
      }
      catch (Exception localException)
      {
        com.biotools.A.I.A("", localException);
      }
  }

  private void ʀ()
  {
    this.κ.addMouseWheelListener(new MouseWheelListener()
    {
      public void mouseWheelMoved(MouseWheelEvent paramAnonymousMouseWheelEvent)
      {
        if ((PokerApp.this.ɞ().isNoLimit()) && (PokerApp.this.η.ċ()))
        {
          int i = -1 * paramAnonymousMouseWheelEvent.getWheelRotation() * paramAnonymousMouseWheelEvent.getScrollAmount();
          double d = PokerApp.this.κ.ǫ();
          PokerApp.this.κ.ǌ().D(d + i * PokerApp.this.ɞ().getSmallBlindSize());
          PokerApp.this.κ.ǌ().I(false);
          PokerApp.this.κ.ǋ();
        }
      }
    });
    addKeyListener(new KeyAdapter()
    {
      public void keyPressed(KeyEvent paramAnonymousKeyEvent)
      {
        if (paramAnonymousKeyEvent.getModifiers() == 0)
        {
          if ((PokerApp.this.ɞ().isNoLimit()) && (PokerApp.this.η.ċ()))
          {
            if (PokerApp.this.κ.ǌ().Ü())
            {
              PokerApp.this.κ.ǌ().A(paramAnonymousKeyEvent);
              PokerApp.this.ʋ().ǋ();
              return;
            }
            if (paramAnonymousKeyEvent.getKeyCode() == E.P())
              PokerApp.this.κ.ǌ().I(PokerApp.this.ɞ().a());
            else if (paramAnonymousKeyEvent.getKeyCode() == E.È())
              PokerApp.this.ʋ().ǖ();
            else if (paramAnonymousKeyEvent.getKeyCode() == E.r())
              PokerApp.this.ʋ().ǝ();
            else if (paramAnonymousKeyEvent.getKeyCode() == E.Ö())
              PokerApp.this.ʋ().ǘ();
          }
          if (paramAnonymousKeyEvent.getKeyCode() == E.À())
          {
            if (PokerApp.this.η.ċ())
            {
              PokerApp.this.D(Action.foldAction(PokerApp.this.ɞ().getAmountToCall(PokerApp.χ)));
            }
            else
            {
              PokerApp.this.ʋ().Ǆ().I();
              PokerApp.this.ʋ().ǋ();
            }
          }
          else if (paramAnonymousKeyEvent.getKeyCode() == E.G())
          {
            if (PokerApp.this.η.ċ())
            {
              PokerApp.this.D(Action.callAction(PokerApp.this.ɞ().getAmountToCall(PokerApp.χ)));
            }
            else
            {
              PokerApp.this.ʋ().Ǆ().J();
              PokerApp.this.ʋ().ǋ();
            }
          }
          else if (paramAnonymousKeyEvent.getKeyCode() == E.g())
          {
            if (PokerApp.this.η.ċ())
            {
              PokerApp.this.κ.ǌ().Ò();
            }
            else
            {
              PokerApp.this.ʋ().Ǆ().A();
              PokerApp.this.ʋ().ǋ();
            }
          }
          else if (paramAnonymousKeyEvent.getKeyCode() == E.Ó())
          {
            if (PokerApp.this.ɞ().isNoLimit())
              if (PokerApp.this.η.ċ())
              {
                PokerApp.this.ʋ().Ǘ();
              }
              else
              {
                PokerApp.this.ʋ().Ǆ().F();
                PokerApp.this.ʋ().ǋ();
              }
          }
          else if (paramAnonymousKeyEvent.getKeyCode() == E.k())
          {
            if ((PokerApp.this.κ.Ǭ().Ä()) && (!PokerApp.this.Ǽ()))
              PokerApp.this.ǰ();
          }
          else if (paramAnonymousKeyEvent.getKeyCode() == E.ª())
            PokerApp.this.ȑ();
          else if (paramAnonymousKeyEvent.getKeyCode() == E.Ñ())
            PokerApp.this.Χ.G().C();
          else if (paramAnonymousKeyEvent.getKeyCode() == E.E())
            PokerApp.this.κ.ǚ();
        }
        PokerApp.this.ʋ().ǋ();
      }
    });
  }

  public void handleQuit()
  {
    ʂ();
  }

  private void ɝ()
  {
    File localFile1 = E.O();
    File localFile2 = E.Q();
    if ((!localFile1.exists()) || (!localFile2.exists()))
      try
      {
        E.A();
      }
      catch (FileNotFoundException localFileNotFoundException)
      {
        com.biotools.A.I.A("", localFileNotFoundException);
      }
      catch (IOException localIOException)
      {
        com.biotools.A.I.A("", localIOException);
      }
  }

  public void A(T paramT, com.biotools.poker.E.E paramE)
  {
    E.H("Trying to start tourney...");
    ɓ();
    ʒ();
    com.biotools.poker.O.C.J.I();
    paramT = new T(paramT);
    paramT.Q(paramT.y());
    this.μ.ƞ();
    this.ζ = new com.biotools.poker.G.U(paramT, this.Ϋ, false);
    this.ζ.B(this);
    this.ζ.A(new Q(this));
    assert ((paramE.R() >= paramT.µ()) && (paramE.R() <= paramT.Á()));
    this.ζ.A(this.Ϋ, this.η);
    for (int i = 1; i < paramE.R(); i++)
      this.ζ.A(paramE.F(i).J(), null);
    this.ζ.m();
    com.biotools.poker.Q.K localK = this.ζ.A(this.Ϋ);
    if (localK == null)
      localK = this.ζ.A();
    if (localK == null)
    {
      E.H("Can't get a dealer for the tournament!");
      if (!$assertionsDisabled)
        throw new AssertionError();
      return;
    }
    this.Ϊ = localK;
    this.ζ.B(this.Ϊ, this, this.Ϋ, this.η);
    this.Χ.C();
    Q(false);
    this.κ.Ǟ();
    R(true);
    this.κ.A(this.Ϊ);
    ɣ();
    this.κ.ǋ();
    this.ξ = this.ζ.X().Q().ª();
    ʈ();
  }

  public void ʎ()
  {
    P(false);
    ɪ();
    this.ό.show(this.Ψ, "main");
    if (Ǽ())
    {
      com.biotools.poker.Q.J localJ = (com.biotools.poker.Q.J)this.Ϊ;
      if ((localJ.ñ()) && (!localJ.Ă()))
        ʋ().Ǟ();
    }
    requestFocus();
  }

  public void ʈ()
  {
    Cursor localCursor = getCursor();
    setCursor(Cursor.getPredefinedCursor(3));
    V(true);
    this.Χ.A(Ǽ());
    ʎ();
    setCursor(localCursor);
  }

  public void ǻ()
  {
    if (!SwingUtilities.isEventDispatchThread())
      SwingUtilities.invokeLater(new PokerApp.12(this));
    else
      ʈ();
  }

  public void A(com.biotools.poker.G.R paramR)
  {
    ɓ();
    ʒ();
    this.μ.ƞ();
    this.ζ = new com.biotools.poker.G.U(paramR);
    this.ζ.B(this);
    this.ζ.A(new Q(this));
    if ((this.ζ.X().£() != null) && (!this.ζ.X().£().equals(this.Ϋ)))
    {
      E.H("Warning: saved tournament profile doesn't match current profile");
      this.Ϋ = this.ζ.X().£();
      E.£().put("PROFILE", this.Ϋ);
    }
    com.biotools.poker.Q.K localK = this.ζ.A(this.Ϋ);
    if (localK == null)
    {
      E.H("Can't get a dealer for the loaded tournament!");
      if (!$assertionsDisabled)
        throw new AssertionError();
      return;
    }
    this.Ϊ = localK;
    this.ζ.B(this.Ϊ, this, this.Ϋ, this.η);
    ʈ();
    Q(false);
    this.κ.Ǟ();
    this.κ.A(this.Ϊ);
    ɣ();
    this.κ.ǋ();
    this.ξ = this.ζ.X().Q().ª();
    T(true);
  }

  public boolean ȓ()
  {
    if (Ǳ())
    {
      boolean bool = this.ή;
      this.ή = true;
      int i = JOptionPane.showConfirmDialog(this, E.D("PokerApp.AbortTournamentText"), E.D("PokerApp.AbortTournamentHeading"), 0);
      this.ή = bool;
      if (i == 0)
      {
        ʒ();
        return true;
      }
      return false;
    }
    return true;
  }

  private void ɦ()
  {
    if ((Ǳ()) && (this.ζ != null))
      this.ζ.o();
  }

  private void ʛ()
  {
    if ((Ǳ()) && (this.ζ != null))
      this.ζ.k();
  }

  public void ʒ()
  {
    if (Ǳ())
    {
      E.H("Aborting tournament");
      ɓ();
      com.biotools.poker.G.R localR = Ȕ();
      if ((localR != null) && (localR.D(this.Ϋ)))
        localR.I();
      ʍ();
      this.κ.v(null);
      V(false);
      E.H("Done aborting tournament");
    }
  }

  public void ʍ()
  {
    E.H("Cleaning up tournament...");
    com.biotools.poker.G.R localR = Ȕ();
    if (this.ζ != null)
    {
      this.ζ.f();
      this.ζ = null;
    }
    ɤ();
    if (this.μ != null)
      this.μ.Ɲ();
    E.H("Done cleaning up tournament...");
    V(false);
  }

  private void ɤ()
  {
    SwingUtilities.invokeLater(new PokerApp.13(this));
  }

  public com.biotools.poker.I.A Ȋ()
  {
    if (this.υ == null)
      this.υ = new com.biotools.poker.I.A();
    return this.υ;
  }

  public void ʞ()
  {
    if (E.£().getBoolean("AUTO_UPDATE", true))
      Ȋ().ƴ();
  }

  public void ɚ()
  {
    com.biotools.B.H.A("Tutorial");
  }

  public void ɲ()
  {
    int i = Thread.activeCount();
    Thread[] arrayOfThread = new Thread[i];
    Thread.enumerate(arrayOfThread);
    for (int j = 0; j < i; j++)
      System.out.println(arrayOfThread[j].toString());
  }

  public void A(com.biotools.poker.Q.J paramJ, String paramString, com.biotools.poker.S.E.K paramK)
  {
    ɓ();
    ʒ();
    y(paramString);
    this.Ϊ = paramJ;
    this.Ϊ.B(this);
    this.ξ = paramK.a();
    ɞ().B(paramK._());
    com.biotools.poker.O.C.J.A(paramK._());
    com.biotools.poker.O.C.J.A(paramK);
    com.biotools.poker.O.M.B(false);
    this.Χ.C();
    if (paramK.O())
    {
      Object[] arrayOfObject = { this.ξ };
      ʋ().w(E.A("PokerApp.ConnectTablePattern", arrayOfObject));
    }
    ʋ().Ǟ();
    ʋ().Ǩ().E();
  }

  public void ʕ()
  {
    com.biotools.poker.Q.J localJ = (com.biotools.poker.Q.J)this.Ϊ;
    ʈ();
    Q(true);
    ʋ().Ǟ();
    ʋ().Ǆ().E(false);
    ʋ().Ǆ().C(false);
    ʋ().Ǆ().A(false);
    this.Χ.A(true);
    this.Χ.E(false);
    ʋ().A(this.Ϊ);
    this.menuBar.E(true);
    this.κ.v(null);
    toFront();
  }

  public boolean X(boolean paramBoolean)
  {
    synchronized (this.ϒ)
    {
      if (ɔ().ę())
      {
        if (paramBoolean)
        {
          Object[] arrayOfObject = { ȗ() };
          int i = JOptionPane.showConfirmDialog(this, E.A("PokerApp.DisconnectTableTextPattern", arrayOfObject), E.D("PokerApp.DisconnectTableHeading"), 0);
          if (i != 0)
            return false;
        }
        ɔ().ĭ();
        E.H("PokerApp.disconnectFromRoom()");
        ɤ();
        ɼ();
        this.Χ.A(false);
        V(false);
        ʋ().w(E.D("PokerApp.Disconnected"));
      }
    }
    return true;
  }

  public com.biotools.poker.P.U Ȍ()
  {
    return this.ώ;
  }

  public com.biotools.poker.C.A ɔ()
  {
    if (this.Ω == null)
      this.Ω = new com.biotools.poker.C.A();
    return this.Ω;
  }

  public void A(String paramString1, String paramString2, boolean paramBoolean)
  {
    if (paramBoolean)
      return;
    S[] arrayOfS = ʋ().ʴ;
    for (int i = 0; i < arrayOfS.length; i++)
      if ((arrayOfS[i].N()) && (arrayOfS[i].W().equals(paramString1)))
      {
        arrayOfS[i].A(paramString2);
        return;
      }
  }

  public boolean Ǽ()
  {
    return this.Ϊ instanceof com.biotools.poker.Q.J;
  }

  public boolean ɒ()
  {
    if (!(this.Ϊ instanceof com.biotools.poker.Q.J))
      return false;
    return ((com.biotools.poker.Q.J)this.Ϊ).ú();
  }

  public boolean ʔ()
  {
    return this.Ϊ instanceof com.biotools.poker.Q.B;
  }

  public boolean ʓ()
  {
    if ((this.Ϊ instanceof com.biotools.poker.Q.B))
      return ((com.biotools.poker.Q.B)this.Ϊ).£();
    return false;
  }

  private void ʄ()
  {
    if (E.p())
    {
      long l1 = System.currentTimeMillis();
      long l2 = E.£().getLong("DTL_ID197", 0L);
      if (l2 == 0L)
      {
        E.£().putLong("DTL_ID197", l1);
      }
      else if (l1 - l2 > 2592000000L)
      {
        JOptionPane.showMessageDialog(this.έ, E.D("PokerApp.TrialPeriodExpiredText"), E.D("PokerApp.TrialPeriodExpiredHeading"), 1);
        E.A(this, E.m());
        System.exit(1);
      }
    }
  }

  public double h(int paramInt)
  {
    if (ɞ().isActive(paramInt))
    {
      com.biotools.poker.D.B localB = com.biotools.poker.D.G.A(ɞ()).Q(paramInt);
      if (localB != null)
        return localB.Ū();
    }
    return -1.0D;
  }

  public void A(com.biotools.poker.Q.A.A paramA)
  {
    if ((!Ǳ()) && (!Ǽ()))
      this.Ϊ.A(paramA);
  }

  public boolean ɕ()
  {
    return this.θ;
  }

  public void V(boolean paramBoolean)
  {
    this.θ = paramBoolean;
  }

  public void A(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3)
  {
    this.μ.A(paramInt, paramDouble1, paramDouble2, paramDouble3);
    com.biotools.poker.G.R localR = Ȕ();
    if (localR != null)
      B(localR);
  }

  public void W(int paramInt)
  {
    this.μ.W(paramInt);
  }

  public void s(String paramString)
  {
    this.μ.s(paramString);
  }

  public void A(String paramString, double paramDouble1, double paramDouble2)
  {
    this.μ.A(paramString, paramDouble1, paramDouble2);
  }

  public void B(String paramString, double paramDouble1, double paramDouble2)
  {
    this.μ.B(paramString, paramDouble1, paramDouble2);
  }

  public void r(String paramString)
  {
    if ((Ȕ() != null) && (!Ȕ().I()) && (paramString.equals(this.Ϋ)))
      C(Ȕ());
    this.μ.r(paramString);
  }

  public void A(String paramString, double paramDouble)
  {
    this.μ.A(paramString, paramDouble);
  }

  public void A(String paramString, com.biotools.poker.Q.K paramK1, com.biotools.poker.Q.K paramK2, int paramInt1, int paramInt2)
  {
    this.μ.A(paramString, paramK1, paramK2, paramInt1, paramInt2);
  }

  public void V(int paramInt)
  {
    this.μ.V(paramInt);
  }

  public void Ɨ()
  {
    this.μ.Ɨ();
    com.biotools.poker.G.R localR = Ȕ();
    if (localR != null)
      T(true);
    if (Ǽ())
      R(true);
  }

  public void Ɩ()
  {
    this.μ.Ɩ();
    this.Υ.D(Ȕ());
    this.κ.v("Tournament Finished");
    C(Ȕ());
    ʍ();
  }

  public void Ƙ()
  {
    this.μ.Ƙ();
    com.biotools.poker.G.R localR = Ȕ();
    if (localR == null)
      return;
    Ǵ();
    localR.K();
    this.Υ.D(localR);
    if (localR.U() != -1)
      T(false);
    R(!Ǽ());
  }

  public void ƙ()
  {
    com.biotools.poker.G.R localR = Ȕ();
    if (localR == null)
      return;
    if (localR.U() != -1)
      T(false);
  }

  private void T(boolean paramBoolean)
  {
    com.biotools.poker.G.R localR1 = Ȕ();
    if (localR1 == null)
      return;
    if (localR1.Q().k())
      return;
    com.biotools.poker.G.R localR2 = localR1;
    boolean bool = paramBoolean;
    SwingUtilities.invokeLater(new PokerApp.14(this, localR2, bool));
  }

  public void ɯ()
  {
    com.biotools.poker.B.I localI = new com.biotools.poker.B.I();
    String str = localI.A(com.biotools.poker.B.A.B());
    E.A(this, "http://www.poker-academy.com/register2.php?code=" + str);
  }

  public void R(boolean paramBoolean)
  {
    com.biotools.poker.G.R localR = Ȕ();
    if (localR == null)
      return;
    if (!localR.I())
    {
      long l = this.μ.ƚ();
      if (paramBoolean)
        com.biotools.B.L.C(l);
    }
    else
    {
      this.μ.Ɲ();
    }
  }

  public void ʜ()
  {
    String str = getTitle();
    int i = str.indexOf('|');
    if (i < 0)
      return;
    str = str.substring(0, i - 1);
    setTitle(str);
  }

  public int ȁ()
  {
    return this.σ;
  }

  public void j(int paramInt)
  {
    if ((ɞ().inGame(paramInt)) && (!ɮ()))
      return;
    ʐ().E(paramInt).E(ȁ());
    ʋ().ǋ();
    ʋ().M(ʋ().ǉ());
  }

  public W ǽ()
  {
    return this.η;
  }

  public String ȗ()
  {
    return this.ξ;
  }

  public static final PokerApp Ȅ()
  {
    return ά;
  }

  public Component ʏ()
  {
    return this.έ;
  }

  public void handleAbout()
  {
    ɧ();
  }

  public static void main(String[] paramArrayOfString)
  {
    PokerAppLauncher.setLookAndFeel();
    Object localObject;
    if (E.W())
      localObject = new D();
    else
      localObject = new PokerApp();
  }

  private String ʚ()
  {
    String str = E.Ò();
    if (E.D())
    {
      int i = E.P / 60;
      if (i <= 0)
        i = 1;
      str = str + " (" + i + " min" + (i == 1 ? "" : "s") + " left in demo)";
    }
    return str;
  }

  public void ɐ()
  {
    String str1 = ʚ();
    String str2 = getTitle();
    int i = str2.indexOf('|');
    if (i > 0)
      str1 = str1 + str2.substring(i - 1);
    setTitle(str1);
  }

  public class _B
  {
    public double D;
    public double C;
    public double B;
    private boolean A = false;

    public _B(double arg2, double arg4, double arg6)
    {
      this.D = ???;
      Object localObject1;
      this.C = localObject1;
      Object localObject2;
      this.B = localObject2;
    }

    public void A(boolean paramBoolean)
    {
      this.A = paramBoolean;
    }

    public String toString()
    {
      if (this.A)
        return Action.formatCash(this.D) + "/" + Action.formatCash(this.C);
      return Action.formatCash(this.C) + "/" + Action.formatCash(this.B);
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.PokerApp
 * JD-Core Version:    0.6.2
 */