/*    */ package com.biotools.poker;
/*    */ 
/*    */ import com.vastmind.loader.Launcher;
/*    */ import java.io.File;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ public final class PokerAppLauncher
/*    */ {
/*    */   public static Launcher launcher;
/*    */   public static String munge;
/*    */ 
/*    */   public PokerAppLauncher(String className)
/*    */   {
/* 24 */     loadLocal(className);
/*    */   }
/*    */ 
/*    */   private void loadLocal(String className) {
/*    */     try {
/* 29 */       File f = new File("data/meerkat.xzf");
/*    */ 
/* 31 */       launcher = new Launcher(f);
/* 32 */       byte[] x = new byte[8];
/* 33 */       x[1] = 48; x[3] = 57;
/* 34 */       x[6] = 121; x[4] = 46;
/* 35 */       x[2] = 57; x[0] = 103;
/* 36 */       x[7] = 49; x[5] = 82;
/* 37 */       if (munge != null) {
/* 38 */         for (int i = 0; i < x.length; i++)
/*    */         {
/*    */           int tmp83_81 = i;
/*    */           byte[] tmp83_80 = x; tmp83_80[tmp83_81] = ((byte)(tmp83_80[tmp83_81] + (byte)munge.charAt(i)));
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 44 */       launcher.setKeyStr(new String(x));
/*    */ 
/* 46 */       launcher.launchProgram(className);
/*    */     }
/*    */     catch (Exception e) {
/* 49 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   private static URL makeURL(String str) {
/*    */     try {
/* 55 */       return new URL(str); } catch (MalformedURLException localMalformedURLException) {
/*    */     }
/* 57 */     return null;
/*    */   }
/*    */ 
/*    */   public static ImageIcon loadImageIcon(String name)
/*    */   {
/* 67 */     if (launcher == null)
/* 68 */       return null;
/* 69 */     return launcher.loadImageIcon(name);
/*    */   }
/*    */ 
/*    */   public static boolean isMacOSX()
/*    */   {
/* 74 */     String osname = System.getProperty("os.name");
/* 75 */     return osname.equals("Mac OS X");
/*    */   }
/*    */ 
/*    */   public static void setLookAndFeel() {
/*    */     try {
/* 80 */       if (isMacOSX())
/* 81 */         UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/*    */       else
/* 83 */         UIManager.setLookAndFeel("com.jgoodies.looks.plastic.PlasticXPLookAndFeel");
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 87 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) {
/* 92 */     setLookAndFeel();
/* 93 */     PokerAppLauncher app = new PokerAppLauncher(args[0]);
/*    */   }
/*    */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.PokerAppLauncher
 * JD-Core Version:    0.6.2
 */