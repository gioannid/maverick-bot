package com.biotools.poker;

import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.poker.F.S;
import com.biotools.poker.F.U;
import com.biotools.poker.H.N;
import com.biotools.poker.N.W;
import com.biotools.poker.O.R;
import com.biotools.poker.O.X;
import com.biotools.poker.O.Z;
import com.biotools.poker.Q.F;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComponent;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.Timer;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class A extends JComponent
  implements MouseListener, MouseMotionListener, com.biotools.B.G
{
  private static final boolean Η = E.¤();
  public int Σ = 10;
  public ArrayList Ύ = new ArrayList();
  private com.biotools.poker.F.M Θ;
  private com.biotools.poker.F.J Ά;
  private com.biotools.poker.F.J ː;
  private com.biotools.poker.F.J ˣ;
  private com.biotools.poker.F.J Ο;
  private com.biotools.poker.F.J Τ;
  private com.biotools.poker.F.J Π;
  private com.biotools.poker.F.J Ν;
  private com.biotools.poker.F.J ΐ;
  private com.biotools.poker.F.J Λ;
  private com.biotools.poker.F.J Ε;
  private com.biotools.poker.F.J ʶ;
  private com.biotools.poker.F.J Γ;
  private com.biotools.poker.F.O Ό;
  private com.biotools.poker.F.A ͺ;
  private com.biotools.poker.F.A ˑ;
  private com.biotools.poker.F.A ʿ;
  private com.biotools.poker.F.A Β;
  private com.biotools.poker.F.I Έ;
  private com.biotools.poker.F.H ˁ;
  private com.biotools.poker.F.G ʸ;
  private Cursor ˠ = new Cursor(12);
  private Cursor ʽ = new Cursor(0);
  public S[] ʴ = new S[this.Σ];
  public U[] Ώ = new U[5];
  public double ʲ = 0.0D;
  public String ʼ = null;
  public String Ι = null;
  public volatile String Ή = null;
  public Hand ʾ = null;
  boolean ˡ = false;
  protected PokerApp ʵ;
  public com.biotools.poker.O.M ʷ;
  public boolean ʳ = false;
  private boolean ˤ = false;
  private int Ί = -1;
  private int ˢ = -1;
  protected int Ρ = -1;
  private boolean Μ = false;
  private long ʻ;
  private Timer Ξ;
  Point Ζ = null;
  private static String Δ = null;
  private int ˀ = 0;
  private int Κ = -1;
  public Vector Α;

  public A(PokerApp paramPokerApp, boolean paramBoolean)
  {
    this.ʵ = paramPokerApp;
    this.ʳ = paramBoolean;
    addMouseListener(this);
    addMouseMotionListener(this);
    if (Η)
      this.ʷ = new R(this);
    else
      this.ʷ = new com.biotools.poker.O.M(this);
    int i = this.ʷ.I();
    int j = this.ʷ.H();
    int k = j;
    this.ˡ = paramPokerApp.ɞ().isNoLimit();
    A(k, i);
    setPreferredSize(new Dimension(j, i));
    setMaximumSize(new Dimension(j, i));
    setDoubleBuffered(false);
    setOpaque(true);
    u(this.ʳ ? "data/layoutSmall.xml" : "data/layoutBig.xml");
    for (int m = 0; m < 5; m++)
    {
      this.Ώ[m] = new U();
      this.Ώ[m].setVisible(false);
      if (paramBoolean)
        this.Ώ[m].J();
    }
    this.ʷ.F();
    ǥ();
    System.err.println("HandEval = " + HandEvaluator.getHandEval().getClass());
  }

  public com.biotools.poker.Q.K Ǡ()
  {
    return this.ʵ.ʐ();
  }

  private synchronized void ǥ()
  {
    if (this.Ξ == null)
    {
      this.Ξ = new Timer(50, new AbstractAction()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          A.this.Ǜ();
        }
      });
      this.Ξ.setCoalesce(true);
      this.Ξ.start();
    }
  }

  private void Ǜ()
  {
    try
    {
      com.biotools.poker.F.D.A();
      if (E.¤())
      {
        Graphics localGraphics = getGraphics();
        if (localGraphics != null)
        {
          this.ʷ.A(localGraphics);
          localGraphics.dispose();
        }
      }
      else
      {
        repaint(5L);
      }
    }
    catch (Exception localException)
    {
      com.biotools.A.I.A("Severe Animation Error", localException);
      this.Ξ.stop();
      this.Ξ = null;
    }
    catch (Error localError)
    {
      localError.printStackTrace();
      JOptionPane.showMessageDialog(this.ʵ, "Severe Animation Error");
      this.Ξ.stop();
      this.Ξ = null;
    }
  }

  public void A(com.biotools.poker.Q.K paramK)
  {
    for (int i = 0; i < this.Σ; i++)
      if (paramK.H(i))
      {
        F localF = Z(i);
        if (localF != null)
          this.ʴ[i].Q();
        else
          this.ʴ[i].B();
      }
      else
      {
        this.ʴ[i].B();
      }
    this.ʼ = null;
    com.biotools.poker.O.C.J.A(paramK.C().isNoLimit());
    A(new Hand(), -1);
    this.ˁ.B((!this.ˁ.C()) && (this.ʵ.ɒ()));
    N(this.ˁ.C());
    ǋ();
  }

  public void ǒ()
  {
    this.ʷ.F.F(this.Σ);
    ǎ();
  }

  public void ǎ()
  {
    if (this.ʵ.Ȁ())
      for (int i = 0; i < this.Σ; i++)
        if ((Ǡ().H(i)) && (Ǡ().N(i) != null))
          this.ʴ[i].A(Ǡ().N(i).getCard(1), Ǡ().N(i).getCard(2));
    ǋ();
  }

  public void L(boolean paramBoolean)
  {
    for (int i = paramBoolean ? 1 : 0; i < this.Σ; i++)
      if ((Ǡ().H(i)) && (Ǡ().N(i) != null))
      {
        F localF = Z(i);
        if (localF.getRevealedHand() == null)
          this.ʴ[i].A(null, null);
      }
    ǋ();
  }

  public void Ǧ()
  {
    for (int i = 0; i < this.Σ; i++)
      if ((Ǡ().H(i)) && (Ǡ().N(i) != null))
        this.ʴ[i].L();
    for (i = 0; i < this.Ώ.length; i++)
      if (this.Ώ[i] != null)
        this.Ώ[i].F();
  }

  public void f(int paramInt)
  {
    this.Ρ = paramInt;
    this.ʷ.C.D(paramInt);
  }

  public void B(com.biotools.poker.Q.K paramK)
  {
    int i = paramK.H();
    I(true);
    A(paramK);
    this.Κ = -1;
    this.ʵ.menuBar.B(i);
    this.ʷ.C.E(i);
  }

  protected boolean ǉ()
  {
    if (this.ʵ.ʔ())
      return false;
    if (this.ʵ.Ǳ())
      return false;
    if (this.Ά.Ä())
      return false;
    F localF = Ǡ().E(PokerApp.χ);
    return (localF != null) && (localF.getBankRoll() == 0.0D) && (localF.getName().equals(this.ʵ.ɬ())) && ((ǆ().isGameOver()) || (!ǆ().inGame(PokerApp.χ)));
  }

  public void Ǫ()
  {
    int i = 0;
    int j = -1;
    for (int k = 0; k < this.Σ; k++)
      if (this.ʴ[k].a())
      {
        i = 1;
        j = k;
      }
    if (i == 0)
      return;
    for (k = 0; k < this.Σ; k++)
      if (this.ʴ[k].a())
        this.ʴ[k].X.D(k == j);
    this.ʲ = ǆ().getTotalPotSize();
  }

  public void A(double paramDouble, S paramS)
  {
    this.ʲ -= paramDouble;
    paramS.X.A(paramDouble);
  }

  public void Ǟ()
  {
    I(false);
  }

  public void I(boolean paramBoolean)
  {
    for (int i = 0; i < this.Σ; i++)
    {
      this.ʴ[i].B(false);
      this.ʴ[i].Z();
      this.ʴ[i].T.C(false);
    }
    if (!paramBoolean)
      this.Ι = null;
    this.ʼ = null;
    this.ʲ = 0.0D;
    this.ʷ.E.g();
    A(new Hand(), -1);
    w(null);
    H(false);
  }

  public void ǂ()
  {
    this.ʷ.E.i();
    ǜ();
    this.ˤ = false;
    this.Ρ = Ǡ().H();
    H(false);
    this.ˁ.D(false);
    M(ǉ());
  }

  public void B(int paramInt, Card paramCard1, Card paramCard2)
  {
    if (paramInt < 0)
      return;
    this.ʴ[paramInt].A(paramCard1, paramCard2);
    ǋ();
  }

  public void A(Hand paramHand, int paramInt)
  {
    this.ʾ = null;
    for (int i = 0; i < 5; i++)
      if (i < paramHand.size())
      {
        this.Ώ[i].A(paramHand.getCard(i + 1));
        this.Ώ[i].setVisible(i < paramInt);
        this.Ώ[i].B(i >= paramInt);
      }
      else
      {
        this.Ώ[i].setVisible(false);
        this.Ώ[i].B(false);
      }
    if (paramInt != -1)
      this.ʷ.A.R();
  }

  public void ǋ()
  {
    this.ʷ.E();
    repaint();
  }

  public void update(Graphics paramGraphics)
  {
  }

  public void paint(Graphics paramGraphics)
  {
    try
    {
      this.ʷ.A((Graphics2D)paramGraphics);
    }
    catch (Exception localException)
    {
      com.biotools.A.I.A("Severe Animation Error", localException);
    }
    catch (Error localError)
    {
      localError.printStackTrace();
      JOptionPane.showMessageDialog(this.ʵ, "Severe Animation Error");
    }
  }

  private boolean Ǚ()
  {
    return true;
  }

  public static void A(Graphics2D paramGraphics2D)
  {
    paramGraphics2D.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
  }

  public static void B(Graphics2D paramGraphics2D)
  {
    paramGraphics2D.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
  }

  public com.biotools.poker.O.M Ǩ()
  {
    return this.ʷ;
  }

  protected com.biotools.poker.F.J Ǒ()
  {
    return this.Τ;
  }

  protected com.biotools.poker.F.J Ǐ()
  {
    return this.ː;
  }

  protected com.biotools.poker.F.J Ǔ()
  {
    return this.ˣ;
  }

  public com.biotools.poker.F.M ǌ()
  {
    return this.Θ;
  }

  protected com.biotools.poker.F.J Ǭ()
  {
    return this.Ά;
  }

  public com.biotools.poker.F.J Ǣ()
  {
    return this.Ό;
  }

  public com.biotools.poker.F.G Ǥ()
  {
    return this.ʸ;
  }

  public com.biotools.poker.Q.D ǆ()
  {
    return Ǡ().C();
  }

  protected void B(double paramDouble, int paramInt)
  {
    this.ˁ.D(false);
    Ǭ().G(false);
    F localF = ǆ().G(paramInt);
    Object[] arrayOfObject;
    if (paramDouble == 0.0D)
    {
      Ǔ().A(E.D("PokerTable.CheckButton"));
    }
    else
    {
      arrayOfObject = new Object[] { Action.formatCash(localF.getAmountCallable()) };
      Ǔ().A(E.A("PokerTable.CallButtonPattern", arrayOfObject));
    }
    if (ǆ().getNumRaises() == 0)
    {
      arrayOfObject = new Object[] { Action.formatCash(localF.getAmountRaiseable()) };
      ǌ().A(E.A("PokerTable.BetButtonPattern", arrayOfObject));
    }
    else
    {
      arrayOfObject = new Object[] { Action.formatCash(localF.getAmountRaiseable()) };
      ǌ().A(E.A("PokerTable.RaiseButtonPattern", arrayOfObject));
    }
    if (ǔ())
      ǌ().F(0.0D);
    else
      ǌ().D(ǆ().c());
    boolean bool1 = ǆ().getNumToAct() > 0;
    Ǐ().G(bool1);
    if (this.Ζ == null)
      this.Ζ = new Point(Ǐ().Å(), Ǐ().Ã());
    Ǐ().H(this.Ζ.x, this.Ζ.y);
    int i = (ǆ().getNumActivePlayers() != 2) && (ǆ().getNumActivePlayersNotAllIn() != 1) ? 0 : 1;
    i = (i != 0) && (this.ʵ.ɒ()) ? 1 : 0;
    if ((i != 0) && (bool1))
    {
      com.biotools.poker.F.J localJ = Ǐ();
      localJ.H(localJ.Å(), localJ.Ã() + 9);
      Ǒ().G(true);
      this.ʻ = Ǡ().C().b();
    }
    Ǔ().G(bool1);
    boolean bool2 = ǆ().a();
    ǌ().G((bool1) && (bool2));
    if (ǔ())
    {
      E.H("toCall: " + paramDouble);
      this.ʸ.G((bool1) && (bool2));
      this.ʿ.G((bool1) && (bool2));
      this.ˑ.G((bool1) && (bool2));
      this.ͺ.G((bool1) && (bool2));
      this.Β.G((bool1) && (bool2));
    }
    ǋ();
  }

  private void A(int paramInt1, int paramInt2)
  {
    this.Ά = new com.biotools.poker.F.J(this);
    this.Ά.A(E.D("PokerTable.DealHandButton"));
    int i = E.Ð() ? 11 : 25;
    int j = 10;
    int k = this.Ά.É();
    int m = this.Ά.Ê();
    int n = paramInt1 / 2 - k / 2;
    int i1 = n - k - i;
    int i2 = i1 - k - i;
    int i3 = n + k + i;
    int i4 = paramInt2 - (m + j);
    this.Ε = new com.biotools.poker.F.J(this);
    this.Ε.A(E.D("PokerTable.ImBackButton"));
    this.ː = new com.biotools.poker.F.J(this);
    this.ː.A(E.D("PokerTable.FoldButton"));
    this.Τ = new com.biotools.poker.F.J(this);
    this.Τ.A(E.D("PokerTable.FoldAndShowButton"));
    this.ˣ = new com.biotools.poker.F.J(this);
    this.ˣ.A(E.D("PokerTable.CallButton"));
    this.Θ = new com.biotools.poker.F.M(this);
    this.Θ.A(E.D("PokerTable.RaiseButton"));
    this.Π = new com.biotools.poker.F.J(this);
    this.Π.A(E.D("PokerTable.RevealBothButton"));
    this.Ν = new com.biotools.poker.F.J(this);
    this.Ν.A(E.D("PokerTable.RevealLeftButton"));
    this.ΐ = new com.biotools.poker.F.J(this);
    this.ΐ.A(E.D("PokerTable.RevealRightButton"));
    this.Λ = new com.biotools.poker.F.J(this);
    this.Λ.A(E.D("PokerTable.AddChipsButton"));
    this.ʶ = new com.biotools.poker.F.J(this);
    this.ʶ.A(E.D("PokerTable.PostBlindButton"));
    this.ʶ.G(false);
    this.Γ = new com.biotools.poker.F.J(this);
    this.Γ.A(E.D("PokerTable.WaitForBlindButton"));
    this.Γ.G(false);
    this.Ά.H(n, i4);
    this.ˣ.H(n, i4);
    this.Ε.H(n, i4);
    this.ː.H(i1, i4);
    this.Τ.H(i1, i4 - m + 10);
    this.Θ.H(i3, i4);
    this.Π.H(n, i4);
    this.Ν.H(i1, i4);
    this.ΐ.H(i3, i4);
    this.Λ.H(n, i4);
    this.ʶ.H(n - (k + i) / 2, i4);
    this.Γ.H(n + (k + i) / 2, i4);
    this.ʸ = new com.biotools.poker.F.G(this);
    this.ʸ.A(0, 100, 0);
    this.ʸ.G(true);
    this.ʸ.H(paramInt1 / 2 + (k / 2 + i) + k + 8, paramInt2 - (m + j) + 5);
    this.ʿ = new com.biotools.poker.F.A();
    this.ʿ.A(E.D("PokerTable.AllInButton"));
    this.ʿ.G(false);
    int i5 = this.ʸ.Å() + this.ʸ.É() - this.ʿ.É();
    int i6 = this.ʸ.Ã() - this.ʿ.Ê() - 3;
    this.ʿ.H(i5, i6);
    this.ˑ = new com.biotools.poker.F.A();
    this.ˑ.A(E.D("PokerTable.PotButton"));
    this.ˑ.G(false);
    i5 -= this.ˑ.É();
    i5--;
    this.ˑ.H(i5, i6);
    this.ͺ = new com.biotools.poker.F.A();
    this.ͺ.A(E.D("PokerTable.HalfPotButton"));
    this.ͺ.G(false);
    i5 -= this.ͺ.É();
    i5--;
    this.ͺ.H(i5, i6);
    this.Β = new com.biotools.poker.F.A();
    this.Β.J(13);
    this.Β.A(E.D("PokerTable.SetRaiseButton"));
    this.Β.G(false);
    i5 -= this.Β.É();
    i5--;
    this.Β.H(i5, i6);
    H(false);
    M(false);
    this.Ό = new com.biotools.poker.F.O(E.K("pix/zip-1.png"), E.K("pix/zip-2.png"), this);
    this.Ό.G(false);
    k = this.Ό.É();
    m = this.Ό.Ê();
    this.Ό.H(paramInt1 / 2 - k / 2, paramInt2 - (m + j));
    this.Έ = new com.biotools.poker.F.I(this, paramInt1, paramInt2);
    this.Ύ.addAll(this.Έ.Ż());
    this.ˁ = new com.biotools.poker.F.H(this, paramInt1, paramInt2, this.Ά.É());
    this.Ε.G(false);
    this.Ύ.addAll(this.ˁ.H());
    this.Ύ.add(this.Ά);
    this.Ύ.add(this.Τ);
    this.Ύ.add(this.ː);
    this.Ύ.add(this.Λ);
    this.Ύ.add(this.ˣ);
    this.Ύ.add(this.Θ);
    this.Ύ.add(this.Ό);
    this.Ύ.add(this.Π);
    this.Ύ.add(this.Ν);
    this.Ύ.add(this.ΐ);
    this.Ύ.add(this.Ε);
    this.Ύ.add(this.ʶ);
    this.Ύ.add(this.Γ);
    this.Ύ.add(this.ʸ);
    this.Ύ.add(this.ʿ);
    this.Ύ.add(this.ˑ);
    this.Ύ.add(this.ͺ);
    this.Ύ.add(this.Β);
    Ǎ();
  }

  protected com.biotools.poker.F.I ǧ()
  {
    return this.Έ;
  }

  public int ǯ()
  {
    return PokerApp.χ;
  }

  private void ǩ()
  {
    if (ǌ().Ü())
      ǌ().I(false);
    else
      ǌ().I(ǆ().a());
    ǋ();
  }

  public void X(int paramInt)
  {
    for (int i = 0; i < this.Σ; i++)
      this.ʴ[i].A(i == paramInt);
    ǋ();
  }

  public void A(int paramInt, double paramDouble, String paramString)
  {
    com.biotools.poker.K.D localD = new com.biotools.poker.K.D();
    Object localObject1;
    if (paramString != null)
    {
      localObject1 = Z(paramInt);
      Hand localHand1 = ((PlayerInfo)localObject1).getRevealedHand();
      if (localHand1 != null)
      {
        localObject2 = new Hand(ǆ().getBoard());
        int i = localD.rankHand((Hand)localObject2);
        ((Hand)localObject2).addHand(localHand1);
        int j = localD.rankHand((Hand)localObject2);
        if (j == i)
        {
          this.ʾ = new Hand(ǆ().getBoard());
          Δ = paramString;
        }
        else
        {
          ((Hand)localObject2).addHand(localHand1);
          if (this.ʾ == null)
          {
            this.ʾ = com.biotools.poker.K.D.E((Hand)localObject2);
            Δ = paramString;
          }
          else
          {
            Hand localHand2 = com.biotools.poker.K.D.E((Hand)localObject2);
            if (com.biotools.poker.K.D.B(localHand2).equals(Δ))
            {
              if (localHand2.contains(localHand1.getCard(1)))
                this.ʾ.addCard(localHand1.getCard(1));
              if (localHand2.contains(localHand1.getCard(2)))
                this.ʾ.addCard(localHand1.getCard(2));
            }
            else
            {
              this.ʾ = localHand2;
              Δ = paramString;
            }
          }
        }
      }
      this.ʵ.ȏ().K();
      Object localObject2 = { this.ʴ[paramInt].S(), Action.formatCash(paramDouble), paramString };
      this.ʼ = E.A("PokerTable.WinStringPattern", (Object[])localObject2);
      if ((ǆ().getNumWinners() == 1) && (paramInt == ǯ()) && ((paramString.matches(".*[Ff]ull [hH]ouse.*")) || (paramString.matches(".*[Ff]our of a [Kk]ind.*")) || (paramString.matches(".*[sS]traight [fF]lush.*")) || (paramString.matches(".*[rR]oyal [Ff]lush.*"))))
        this.ʵ.ȏ().F();
      ǋ();
      A(paramDouble, this.ʴ[paramInt]);
    }
    else
    {
      this.ʴ[paramInt].A(Z(paramInt).getAmountInPotThisRound());
      Ǫ();
      if ((ǆ().getNumWinners() == 1) && (paramInt == ǯ()))
      {
        this.ˀ += 1;
        H(this.ʵ.ɒ());
      }
      else
      {
        this.ˀ = 0;
      }
      if (this.ˀ == 3)
      {
        this.ʵ.ȏ().S();
        this.ˀ = 0;
      }
      else
      {
        this.ʵ.ȏ().K();
      }
      ǁ();
      localObject1 = new Object[] { this.ʴ[paramInt].S(), Action.formatCash(paramDouble) };
      this.ʼ = E.A("PokerTable.WinUncontestedStringPattern", (Object[])localObject1);
      A(paramDouble, this.ʴ[paramInt]);
      this.ˤ = true;
    }
    Ǖ();
    this.ʴ[paramInt].T.C(true);
    ǋ();
  }

  private void Ǖ()
  {
    for (int i = 0; i < this.Σ; i++)
      this.ʴ[i].T.B(false);
  }

  public void C(int paramInt, Card paramCard1, Card paramCard2)
  {
    if (!ǆ().isActive(paramInt))
      return;
    if (!this.ˤ)
    {
      for (int i = 0; i < this.Σ; i++)
        if ((b(i)) && (ǆ().inGame(i)))
        {
          double d = Z(i).getAmountInPotThisRound();
          if (this.ʴ[i].c() > d)
            this.ʴ[i].A(d);
        }
      Ǫ();
    }
    ǁ();
    X(paramInt);
    B(paramInt, paramCard1, paramCard2);
    ǜ();
    if (this.Ί == paramInt)
      this.Ί = -1;
    if (ǆ().getStage() == 3)
    {
      Hand localHand = new Hand(ǆ().getBoard());
      localHand.addCard(paramCard1);
      localHand.addCard(paramCard2);
      Object[] arrayOfObject = { this.ʴ[paramInt].S(), com.biotools.poker.K.D.B(localHand) };
      this.ʼ = E.A("PokerTable.ShowStringPattern", arrayOfObject);
      this.ʴ[paramInt].B(com.biotools.poker.K.D.B(localHand));
    }
    else
    {
      if (!this.ˤ)
      {
        this.ʵ.ȏ().L();
        c(ǆ().getStage());
        ǋ();
      }
      if ((this.ˤ) && (c(ǆ().getStage())))
        ǋ();
    }
    ǋ();
    this.ˤ = true;
  }

  protected boolean c(int paramInt)
  {
    Hand[] arrayOfHand = new Hand[Ǡ().C().getNumActivePlayers()];
    int i = 0;
    Object localObject2;
    for (int j = 0; j < this.Σ; j++)
    {
      localObject2 = Z(j);
      if ((localObject2 != null) && (((PlayerInfo)localObject2).isActive()))
      {
        arrayOfHand[i] = ((PlayerInfo)localObject2).getRevealedHand();
        if (arrayOfHand[i] == null)
          return false;
        i++;
      }
    }
    Object localObject1;
    if (paramInt == 0)
    {
      localObject2 = new com.biotools.poker.L.B(ǆ().getBoard(), arrayOfHand);
      ((com.biotools.poker.L.B)localObject2).G(50000);
      localObject1 = localObject2;
    }
    else
    {
      localObject2 = new com.biotools.poker.L.E(ǆ().getBoard(), arrayOfHand);
      localObject1 = localObject2;
    }
    localObject1.run();
    long l1 = localObject1.I();
    i = 0;
    for (int k = 0; k < this.Σ; k++)
    {
      F localF = Z(k);
      if ((localF != null) && (localF.isActive()))
      {
        double d = localObject1.C(i);
        d *= 100.0D;
        long l2 = Math.round(Math.floor(d));
        long l3 = Math.round((d - l2) * 10.0D);
        Object[] arrayOfObject = { new Long(l2), new Long(l3) };
        String str = E.A("PokerTable.WinPercentStringPattern", arrayOfObject);
        if (d == 100.0D)
          str = E.D("PokerTable.WinnerString");
        if (d == 0.0D)
          str = E.D("PokerTable.LoserString");
        this.ʴ[k].C(str);
        i++;
      }
    }
    return true;
  }

  public void E(String[] paramArrayOfString)
  {
    for (int i = 0; i < this.Σ; i++)
      this.ʴ[i].C(paramArrayOfString[i]);
    ǋ();
  }

  public void _(int paramInt)
  {
    if (paramInt == this.Κ)
      return;
    this.Κ = paramInt;
    if (paramInt > 0)
      Ǫ();
    Ǯ();
    w(null);
  }

  public Image B(File paramFile)
  {
    Image localImage = Toolkit.getDefaultToolkit().getImage(paramFile.getPath());
    MediaTracker localMediaTracker = new MediaTracker(this);
    localMediaTracker.addImage(localImage, 0);
    try
    {
      localMediaTracker.waitForAll();
    }
    catch (InterruptedException localInterruptedException)
    {
    }
    return localImage;
  }

  public synchronized void ǁ()
  {
    for (int i = 0; i < this.Σ; i++)
      this.ʴ[i].A(0.0D);
  }

  public boolean b(int paramInt)
  {
    return this.ʴ[paramInt].N();
  }

  private JPopupMenu e(int paramInt)
  {
    JPopupMenu localJPopupMenu1 = new JPopupMenu();
    JPopupMenu localJPopupMenu2 = new JPopupMenu();
    Object localObject = null;
    int i = (paramInt != 0) && (!this.ʴ[paramInt].N()) ? 1 : 0;
    if ((i != 0) && (!this.ʵ.Ǽ()))
    {
      localJPopupMenu2 = d(paramInt);
      com.biotools.B.A.A(localJPopupMenu2);
      return localJPopupMenu2;
    }
    if (!this.ʵ.Ǽ())
    {
      if ((this.ʴ[paramInt].N()) && (!this.ʵ.Ǳ()))
      {
        if (!this.ʴ[paramInt].R())
          localJPopupMenu1.add(new com.biotools.poker.H.L(paramInt));
        localJPopupMenu1.add(new com.biotools.poker.H.K(paramInt));
        localJPopupMenu1.add(new com.biotools.poker.H.I(paramInt));
      }
      if (paramInt != 0)
      {
        if (this.ʴ[paramInt].N())
        {
          localJPopupMenu1.add(new com.biotools.poker.H.G(paramInt));
          if (!this.ʵ.Ǳ())
          {
            localJPopupMenu1.addSeparator();
            localJPopupMenu1.add(new com.biotools.poker.H.C(paramInt));
          }
        }
        if (!this.ʵ.Ǳ())
          localJPopupMenu1.add(g(paramInt));
      }
      if (!this.ʵ.Ǳ())
        localJPopupMenu1.addSeparator();
    }
    if (this.ʴ[paramInt].N())
    {
      if (this.ʵ.Ǽ())
      {
        JMenuItem localJMenuItem = new JMenuItem(this.ʴ[paramInt].S());
        localJMenuItem.setEnabled(false);
        localJPopupMenu1.add(localJMenuItem);
        localJPopupMenu1.addSeparator();
        if (paramInt == ǯ())
        {
          if (!this.ʵ.ɞ().isActive(paramInt))
            localJPopupMenu1.add(new com.biotools.poker.H.M(paramInt));
        }
        else if (!this.ʴ[paramInt].W().equals(this.ʵ.ɬ()))
        {
          N localN = new N(paramInt);
          JCheckBoxMenuItem localJCheckBoxMenuItem = new JCheckBoxMenuItem(localN);
          localJCheckBoxMenuItem.setSelected(localN.B());
          localJPopupMenu1.add(localJCheckBoxMenuItem);
        }
      }
      localJPopupMenu1.add(new com.biotools.poker.H.J(paramInt));
      if (E.y())
      {
        localJPopupMenu1.addSeparator();
        localJPopupMenu1.add(new com.biotools.poker.H.B(paramInt));
      }
    }
    com.biotools.B.A.A(localJPopupMenu1);
    return localJPopupMenu1;
  }

  private JMenu g(int paramInt)
  {
    JMenu localJMenu = new JMenu(E.D("PokerTable.ChangeOpponentButton"));
    for (int i = 0; i < Ǉ().size(); i++)
    {
      String str = (String)Ǉ().get(i);
      if (str != null)
        localJMenu.add(C(str, paramInt));
    }
    return localJMenu;
  }

  private JPopupMenu d(int paramInt)
  {
    JPopupMenu localJPopupMenu = new JPopupMenu();
    localJPopupMenu.add(E.D("PokerTable.SelectOpponentButton"));
    localJPopupMenu.addSeparator();
    for (int i = 0; i < Ǉ().size(); i++)
    {
      String str = (String)Ǉ().get(i);
      if (str != null)
        localJPopupMenu.add(C(str, paramInt));
    }
    return localJPopupMenu;
  }

  public JMenuItem C(String paramString, int paramInt)
  {
    int i = 20;
    JMenu localJMenu = new JMenu(paramString);
    Vector localVector = x(paramString);
    if (localVector.size() > 0)
    {
      int j;
      if (localVector.size() > i)
      {
        j = 0;
        while (j < localVector.size())
        {
          localJMenu.add(A(localVector, j, i, paramString, paramInt));
          j += i;
        }
      }
      else
      {
        for (j = 0; j < localVector.size(); j++)
          localJMenu.add(new com.biotools.poker.H.A(paramInt, (com.biotools.poker.E.B)localVector.get(j)));
      }
    }
    return localJMenu;
  }

  public JMenuItem A(List paramList, int paramInt1, int paramInt2, String paramString, int paramInt3)
  {
    StringBuffer localStringBuffer1 = new StringBuffer();
    int i = paramInt1 + paramInt2 - 1;
    if (i >= paramList.size())
      i = paramList.size() - 1;
    StringBuffer localStringBuffer2 = new StringBuffer(paramList.get(paramInt1).toString());
    StringBuffer localStringBuffer3 = new StringBuffer(paramList.get(i).toString());
    localStringBuffer1.append(localStringBuffer2.substring(0, 1).toUpperCase() + " - " + localStringBuffer3.substring(0, 1).toUpperCase());
    JMenu localJMenu = new JMenu(localStringBuffer1.toString());
    for (int j = paramInt1; j <= i; j++)
      localJMenu.add(new com.biotools.poker.H.A(paramInt3, (com.biotools.poker.E.B)paramList.get(j)));
    return localJMenu;
  }

  private Vector Ǉ()
  {
    if (this.ˡ != ǔ())
    {
      this.Α = null;
      this.ˡ = ǔ();
    }
    if (this.Α == null)
    {
      ArrayList localArrayList = com.biotools.poker.E.B.B(E.Ì());
      Vector localVector = new Vector();
      for (int i = 0; i < localArrayList.size(); i++)
      {
        com.biotools.poker.E.B localB = (com.biotools.poker.E.B)localArrayList.get(i);
        if (localB.B() == ǔ())
          localVector.add(localB.C());
      }
      this.Α = localVector;
    }
    return this.Α;
  }

  private Vector x(String paramString)
  {
    Vector localVector = new Vector();
    if ((paramString != null) && (!paramString.equals("RANDOM")))
      for (int i = 0; i < com.biotools.poker.E.B.N().size(); i++)
      {
        com.biotools.poker.E.B localB = (com.biotools.poker.E.B)com.biotools.poker.E.B.N().get(i);
        if ((localB.C() != null) && (localB.C().equals(paramString)))
          localVector.add(localB);
      }
    return localVector;
  }

  public void mousePressed(MouseEvent paramMouseEvent)
  {
    this.ʵ.requestFocus();
    Object localObject;
    for (int i = 0; i < this.Ύ.size(); i++)
    {
      localObject = (com.biotools.poker.F.E)this.Ύ.get(i);
      ((com.biotools.poker.F.E)localObject).I(paramMouseEvent.getX(), paramMouseEvent.getY());
      ǭ();
    }
    this.ʷ.L.C(paramMouseEvent.getX(), paramMouseEvent.getY());
    for (i = 0; i < this.Σ; i++)
    {
      if (this.ʴ[i].B(paramMouseEvent.getX(), paramMouseEvent.getY()))
      {
        if (!this.ʵ.ʓ())
        {
          localObject = e(i);
          if (((JPopupMenu)localObject).getComponents().length > 0)
            ((JPopupMenu)localObject).show(this, paramMouseEvent.getX(), paramMouseEvent.getY());
        }
        if (this.ʵ.Ǽ())
        {
          localObject = (com.biotools.poker.Q.J)this.ʵ.ʐ();
          if ((((com.biotools.poker.Q.J)localObject).æ()) && (!((com.biotools.poker.Q.J)localObject).H(i)))
            this.ʵ.m(i);
        }
      }
      if ((!this.ʵ.Ȁ()) && ((this.ʵ.ɡ()) || (i == 0)) && (Ǡ().H(i)) && (this.ʴ[i].A(paramMouseEvent.getX(), paramMouseEvent.getY())) && (this.ʴ[i].U()))
      {
        this.Ί = i;
        localObject = Ǡ().N(i);
        if (localObject != null)
        {
          this.ʴ[this.Ί].A(((Hand)localObject).getCard(1), ((Hand)localObject).getCard(2));
          ǋ();
        }
      }
    }
  }

  private void ǭ()
  {
    this.Μ = true;
    repaint(5L);
  }

  public boolean ǔ()
  {
    return ǆ().isNoLimit();
  }

  public double ǫ()
  {
    return ǌ().Ï();
  }

  private void ǟ()
  {
    double d = ǆ().getAmountToCall(ǯ());
    if (ǫ() > 0.0D)
      this.ʵ.D(Action.raiseAction(d, ǫ()));
    else
      this.ʵ.D(Action.callAction(d));
    ǭ();
  }

  protected void Ǘ()
  {
    if (ǔ())
    {
      ǌ().F(100.0D);
      this.ʸ.C(100.0D);
      ǟ();
    }
  }

  protected void ǖ()
  {
    if (ǔ())
    {
      ǌ().Ñ();
      ǟ();
    }
  }

  protected void ǝ()
  {
    if (ǔ())
    {
      ǌ().Ð();
      ǟ();
    }
  }

  protected void ǘ()
  {
    if (ǔ())
    {
      ǌ().Û();
      ǟ();
    }
  }

  private void ǣ()
  {
    G(false);
  }

  private void G(boolean paramBoolean)
  {
    this.ʵ.A(Action.foldAction(ǆ().getAmountToCall(ǯ())), paramBoolean);
  }

  private void ǐ()
  {
    this.ʵ.ǿ();
    Y(0);
    com.biotools.B.L.C(1000L);
    G(true);
  }

  private void ǈ()
  {
    this.ʵ.D(Action.callAction(ǆ().getAmountToCall(ǯ())));
  }

  private void Ǎ()
  {
    this.Ε.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        com.biotools.poker.Q.K localK = PokerApp.Ȅ().ʐ();
        if ((localK instanceof com.biotools.poker.Q.J))
          ((com.biotools.poker.Q.J)localK).F(false);
        A.this.Ε.G(false);
      }
    });
    this.ː.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        A.this.ǣ();
      }
    });
    this.Τ.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        A.this.ǐ();
      }
    });
    this.ˣ.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        A.this.ǈ();
      }
    });
    this.Θ.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        A.this.ǌ().Ò();
      }
    });
    this.ʿ.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        A.this.Ǘ();
      }
    });
    this.ˑ.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        A.this.ǖ();
      }
    });
    this.ͺ.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        A.this.ǝ();
      }
    });
    this.Ό.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        A.this.ʵ.ȑ();
      }
    });
    this.Ά.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        A.this.ʵ.ǰ();
      }
    });
    this.Β.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        A.this.ǩ();
      }
    });
    this.Π.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        A.this.ǚ();
      }
    });
    this.Ν.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        A.this.Y(1);
      }
    });
    this.ΐ.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        A.this.Y(2);
      }
    });
    this.Λ.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        A.this.M(false);
        A.this.ʵ.l(A.this.ǯ());
      }
    });
    this.ʶ.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        A.this.Ǌ();
      }
    });
    this.Γ.B(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        A.this.ǃ();
      }
    });
  }

  public void mouseReleased(MouseEvent paramMouseEvent)
  {
    for (int i = 0; i < this.Ύ.size(); i++)
    {
      com.biotools.poker.F.E localE = (com.biotools.poker.F.E)this.Ύ.get(i);
      localE.E(paramMouseEvent.getX(), paramMouseEvent.getY());
      ǭ();
    }
    this.ʷ.L.B(paramMouseEvent.getX(), paramMouseEvent.getY());
    if (this.Ί >= 0)
    {
      this.ʴ[this.Ί].A(null, null);
      ǋ();
      this.Ί = -1;
    }
  }

  public void mouseMoved(MouseEvent paramMouseEvent)
  {
    int i = paramMouseEvent.getX();
    int j = paramMouseEvent.getY();
    for (int k = 0; k < this.Ύ.size(); k++)
    {
      com.biotools.poker.F.E localE = (com.biotools.poker.F.E)this.Ύ.get(k);
      if (localE.G(i, j))
        ǭ();
    }
    this.ˢ = -1;
    for (k = 0; k < this.Σ; k++)
      if (this.ʴ[k].N())
      {
        if (this.ʴ[k].B(i, j))
        {
          setCursor(this.ˠ);
          return;
        }
        if (((this.ʵ.ɡ()) || (k == 0)) && (this.ʴ[k].A(i, j)))
        {
          setCursor(this.ˠ);
          return;
        }
      }
      else if (this.ʴ[k].B(i, j))
      {
        setCursor(this.ˠ);
        this.ˢ = k;
        ǋ();
        return;
      }
    setCursor(this.ʽ);
  }

  public void mouseEntered(MouseEvent paramMouseEvent)
  {
  }

  public void mouseExited(MouseEvent paramMouseEvent)
  {
  }

  public void mouseClicked(MouseEvent paramMouseEvent)
  {
  }

  public void mouseDragged(MouseEvent paramMouseEvent)
  {
    for (int i = 0; i < this.Ύ.size(); i++)
    {
      com.biotools.poker.F.E localE = (com.biotools.poker.F.E)this.Ύ.get(i);
      localE.G(paramMouseEvent.getX(), paramMouseEvent.getY());
      this.Μ = true;
      repaint(5L);
    }
  }

  public void ǜ()
  {
    this.ː.G(false);
    this.Τ.G(false);
    this.ˣ.G(false);
    this.Θ.G(false);
    this.ʸ.G(false);
    this.ʿ.G(false);
    this.ˑ.G(false);
    this.ͺ.G(false);
    this.Β.G(false);
    this.ʸ.Í();
    ǋ();
  }

  public void ǚ()
  {
    if (this.Π.Ä())
      Y(0);
    else if (this.Τ.Ä())
      ǐ();
  }

  private void Y(int paramInt)
  {
    H(false);
    if (this.ʵ.Ǽ())
      ((com.biotools.poker.Q.J)Ǡ()).A(paramInt, this.ʻ);
  }

  private void H(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      String[] arrayOfString = this.ʴ[ǯ()].G();
      Object[] arrayOfObject1 = { arrayOfString[0] };
      this.Ν.A(E.A("PokerTable.RevealCardPattern", arrayOfObject1));
      Object[] arrayOfObject2 = { arrayOfString[1] };
      this.ΐ.A(E.A("PokerTable.RevealCardPattern", arrayOfObject2));
      this.ʻ = Ǡ().C().b();
    }
    this.Π.G(paramBoolean);
    this.Ν.G(paramBoolean);
    this.ΐ.G(paramBoolean);
  }

  public F Z(int paramInt)
  {
    return Ǡ().E(paramInt);
  }

  public void B(int paramInt, Action paramAction)
  {
    this.ʴ[paramInt].A(paramAction);
    if (paramAction.isPostDeadBlind())
    {
      F localF = Z(paramInt);
      if ((localF != null) && (localF.inGame()) && (paramAction.getAmount() > 0.0D))
        this.ʲ += paramAction.getAmount();
    }
    ǋ();
  }

  public void Ǯ()
  {
    for (int i = 0; i < this.Σ; i++)
      this.ʴ[i].A(null);
  }

  private void u(String paramString)
  {
    try
    {
      DocumentBuilderFactory localDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
      localDocumentBuilderFactory.setNamespaceAware(true);
      DocumentBuilder localDocumentBuilder = localDocumentBuilderFactory.newDocumentBuilder();
      File localFile = new File(paramString);
      Document localDocument = localDocumentBuilder.parse(localFile);
      Element localElement1 = localDocument.getDocumentElement();
      NodeList localNodeList = localElement1.getElementsByTagName("playerpanel");
      for (int i = 0; i < localNodeList.getLength(); i++)
      {
        Element localElement2 = (Element)localNodeList.item(i);
        int j = Integer.parseInt(localElement2.getAttribute("id"));
        this.ʴ[j] = new S(this, j);
        this.ʴ[j].A(localElement2);
      }
    }
    catch (Exception localException)
    {
      com.biotools.A.I.A("", localException);
    }
  }

  public Hand ǀ()
  {
    return this.ʾ;
  }

  public boolean A(Card paramCard)
  {
    if (this.ʾ != null)
      for (int i = 1; i <= this.ʾ.size(); i++)
        if (this.ʾ.getCard(i).equals(paramCard))
          return true;
    return false;
  }

  public void v(String paramString)
  {
    this.Ι = paramString;
    ǋ();
  }

  public void w(String paramString)
  {
    if (this.Ή == paramString)
      return;
    if ((this.Ή != null) && (paramString != null) && (this.Ή.equals(paramString)))
      return;
    this.Ή = paramString;
    ǋ();
  }

  private boolean ǡ()
  {
    if ((Ǡ() instanceof com.biotools.poker.Q.B))
    {
      com.biotools.poker.Q.B localB = (com.biotools.poker.Q.B)Ǡ();
      return localB.£();
    }
    return false;
  }

  protected void K(boolean paramBoolean)
  {
    this.Έ.E(paramBoolean);
  }

  public void M(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      if (this.ʵ.Ǳ())
        return;
      this.Ε.G(false);
    }
    this.Λ.G(paramBoolean);
  }

  public void ǅ()
  {
    M(ǉ());
    w(null);
    if (this.Ξ == null)
      ǥ();
    ǋ();
  }

  public com.biotools.poker.F.H Ǆ()
  {
    return this.ˁ;
  }

  public S a(int paramInt)
  {
    return this.ʴ[paramInt];
  }

  public void N(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      paramBoolean = (paramBoolean) && (this.ʵ.ɒ());
      paramBoolean = (paramBoolean) && (!this.Λ.Ä());
      paramBoolean = (paramBoolean) && (ǆ().getPlayer(this.ʵ.ɬ()) != null);
    }
    if (paramBoolean)
      Ǆ().D(false);
    if ((paramBoolean) && (ǉ()))
      this.Λ.G(paramBoolean);
    else
      this.Ε.G(paramBoolean);
  }

  public void C(Action paramAction)
  {
    this.ʵ.D(paramAction);
  }

  public void J(boolean paramBoolean)
  {
    this.ʶ.G(paramBoolean);
    this.Γ.G(paramBoolean);
    if (paramBoolean)
    {
      this.ʵ.ȏ().M();
      this.ˁ.D(false);
    }
  }

  protected void Ǌ()
  {
    J(false);
    Ǆ().A(false);
    Ǆ().C(false);
    this.ʵ.ǽ().A(Action.postBlindAction(ǆ().getBigBlindSize()));
  }

  protected void ǃ()
  {
    J(false);
    Ǆ().A(true);
    Ǆ().C(true);
    this.ʵ.ǽ().A(Action.sitout());
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.A
 * JD-Core Version:    0.6.2
 */