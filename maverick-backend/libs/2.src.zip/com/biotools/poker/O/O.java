package com.biotools.poker.O;

import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.A;
import com.biotools.poker.E;
import com.biotools.poker.F.S;
import com.biotools.poker.PokerApp;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;

public class O extends I
{
  private static Image É;
  int Ê;
  int Ë;
  long Î;
  float Í;
  V Ì;

  public static void E(M paramM)
  {
    É = paramM.B(E.K("pix/button.png"));
  }

  public void B(M paramM)
  {
    super.B(paramM);
    this.Ê = -1;
    this.X = false;
  }

  public void D(int paramInt)
  {
    this.Ë = paramInt;
    this.Ê = paramInt;
  }

  public void E(int paramInt)
  {
    if ((this.Ê < 0) || (!r()))
    {
      this.Ê = paramInt;
      this.W = t();
      return;
    }
    this.Ë = paramInt;
    this.Î = System.currentTimeMillis();
    this.W = t();
    this.Ì = null;
    this.X = true;
    if (r())
      N();
  }

  protected void B(Graphics2D paramGraphics2D)
  {
    Point localPoint = s();
    if (localPoint == null)
      return;
    paramGraphics2D.drawImage(É, localPoint.x, localPoint.y, null);
    if (PokerApp.Ȅ().Ȑ())
      paramGraphics2D.drawImage(U.Ó, localPoint.x + 10, localPoint.y + 10, null);
  }

  Point s()
  {
    if (!this.X)
    {
      if ((this.Ê < 0) || (this.Ê >= this.U.ʴ.length))
        return null;
      return this.U.ʴ[this.Ê].Y();
    }
    if (this.Ì == null)
    {
      if ((this.Ê < 0) || (this.Ê >= this.U.ʴ.length))
        return null;
      if ((this.Ë < 0) || (this.Ë >= this.U.ʴ.length))
        return null;
      Point localPoint1 = this.U.ʴ[this.Ê].Y();
      Point localPoint2 = this.U.ʴ[this.Ë].Y();
      Point localPoint3 = this.U.ʴ[this.Ë].Y();
      Point[] arrayOfPoint = { localPoint1, localPoint2, localPoint3 };
      this.Ì = V.A(arrayOfPoint);
    }
    return this.Ì.A(this.Í);
  }

  public void A(M paramM)
  {
    if (!this.X)
      return;
    long l = System.currentTimeMillis() - this.Î;
    this.Í = ((float)l / 300.0F);
    if (this.Í > 1.0F)
    {
      this.X = false;
      this.Ê = this.Ë;
      this.Ë = -1;
      O();
      return;
    }
    Rectangle localRectangle = t();
    paramM.A(this);
    if (localRectangle != null)
      paramM.A(new J(localRectangle, false));
    this.W = localRectangle;
  }

  private Rectangle t()
  {
    Point localPoint = s();
    if (localPoint == null)
      return null;
    return new Rectangle(localPoint.x, localPoint.y, É.getWidth(null), É.getHeight(null));
  }

  private boolean r()
  {
    return (E.£().getBoolean("USE_DEAL_ANIMATION", true)) && (!M.R);
  }

  public J B(Rectangle paramRectangle)
  {
    return new J(this.W, false);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.O
 * JD-Core Version:    0.6.2
 */