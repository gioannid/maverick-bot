package com.biotools.poker.O;

import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.A;
import com.biotools.poker.E;
import com.biotools.poker.F.N;
import com.biotools.poker.F.S;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;

public class Z extends I
{
  private static final int Þ = 370;
  private static final int Ý = 267;
  private static final int Û = 390;
  private static final int Ù = 365;
  private static final int ß = 500;
  private int Ø;
  private float Ú;
  private long Ü;
  private boolean Ö;
  private double[] à;

  public Z(int paramInt)
  {
    this.Ø = paramInt;
  }

  public void B(M paramM)
  {
    super.B(paramM);
    Point localPoint = this.U.ʴ[this.Ø]._();
    this.W = new Rectangle(localPoint.x, localPoint.y, 100, 50);
    this.Ú = 0.0F;
    this.U.ʴ[this.Ø].X = this;
    this.à = null;
  }

  private Point A(double[] paramArrayOfDouble)
  {
    int i = (int)paramArrayOfDouble[3];
    int j = (int)paramArrayOfDouble[4];
    if ((this.X) && (this.Ú != 0.0F))
    {
      int k = this.U.ʳ ? 370 : 390;
      int m = this.U.ʳ ? 267 : 365;
      i += (int)((k - i) * this.Ú);
      j += (int)((m - j) * this.Ú);
    }
    return new Point(i, j);
  }

  private double[] z()
  {
    if (this.X)
      return this.à;
    return this.U.ʴ[this.Ø].V();
  }

  protected void B(Graphics2D paramGraphics2D)
  {
    double[] arrayOfDouble = z();
    if (arrayOfDouble == null)
      return;
    Point localPoint = A(arrayOfDouble);
    Rectangle localRectangle;
    if (arrayOfDouble[0] != 0.0D)
    {
      localRectangle = N.A(arrayOfDouble[0], localPoint.x, localPoint.y, paramGraphics2D);
      if (localRectangle != null)
      {
        localRectangle.grow(2, 2);
        this.W = localRectangle;
      }
    }
    else
    {
      localRectangle = N.A(arrayOfDouble[1], (int)arrayOfDouble[2], localPoint.x, localPoint.y, paramGraphics2D);
      if (localRectangle != null)
      {
        localRectangle.grow(2, 2);
        this.W = localRectangle;
      }
    }
  }

  private void ¢()
  {
    B(null);
  }

  public void A(M paramM)
  {
    if (!this.X)
      return;
    long l = System.currentTimeMillis() - this.Ü;
    if (l > 500L)
    {
      this.Ú = (this.Ö ? 0.0F : 1.0F);
      O();
    }
    else
    {
      this.Ú = ((float)l / 500.0F);
      if (this.Ö)
        this.Ú = (1.0F - this.Ú);
    }
    this.Ú = V.B(this.Ú);
    paramM.A(this);
    ¢();
    paramM.A(this);
  }

  public void D(boolean paramBoolean)
  {
    this.Ö = false;
    this.Ú = 0.0F;
    this.à = ((double[])z().clone());
    this.U.ʴ[this.Ø].A(0.0D);
    if (y())
    {
      this.Ü = System.currentTimeMillis();
      this.X = true;
      if (paramBoolean)
        N();
    }
    else
    {
      this.U.Ǩ().A(this);
    }
  }

  public void A(double paramDouble)
  {
    this.Ö = true;
    this.Ú = 1.0F;
    this.U.ʴ[this.Ø].A(paramDouble);
    double[] arrayOfDouble = z();
    if (arrayOfDouble != null)
    {
      this.à = ((double[])arrayOfDouble.clone());
      if (y())
      {
        this.Ü = System.currentTimeMillis();
        this.X = true;
        N();
      }
      else
      {
        this.U.Ǩ().A(this);
      }
    }
    else
    {
      this.U.Ǩ().A(this);
    }
  }

  private boolean y()
  {
    return (E.£().getBoolean("USE_CHIP_ANIMATION", true)) && (!M.R);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.Z
 * JD-Core Version:    0.6.2
 */