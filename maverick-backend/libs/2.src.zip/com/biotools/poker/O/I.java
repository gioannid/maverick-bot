package com.biotools.poker.O;

import com.biotools.poker.A;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public abstract class I
  implements P
{
  Rectangle W;
  boolean V = false;
  boolean X = false;
  A U;

  public void A()
  {
    this.V = false;
  }

  public boolean A(Rectangle paramRectangle)
  {
    if (this.W == null)
      return false;
    return paramRectangle.intersects(this.W);
  }

  public boolean A(int paramInt1, int paramInt2)
  {
    if (this.W == null)
      return false;
    return this.W.contains(paramInt1, paramInt2);
  }

  public void A(Graphics2D paramGraphics2D)
  {
    if (this.V)
      return;
    this.V = true;
    B(paramGraphics2D);
  }

  public void C(Rectangle paramRectangle)
  {
    this.W = paramRectangle;
  }

  public void B(M paramM)
  {
    this.U = paramM.C();
  }

  protected abstract void B(Graphics2D paramGraphics2D);

  public J B(Rectangle paramRectangle)
  {
    return null;
  }

  public synchronized void O()
  {
    this.X = false;
    notifyAll();
  }

  public synchronized void N()
  {
    while (this.X)
      try
      {
        wait();
      }
      catch (InterruptedException localInterruptedException)
      {
      }
  }

  public void B()
  {
    O();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.I
 * JD-Core Version:    0.6.2
 */