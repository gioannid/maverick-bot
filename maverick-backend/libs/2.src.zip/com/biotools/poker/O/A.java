package com.biotools.poker.O;

import com.biotools.meerkat.Hand;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.PokerApp;
import java.awt.AlphaComposite;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;

public class A extends I
{
  private static final int f = 500;
  public static final int a = 0;
  public static final int _ = 1;
  public static final int g = 2;
  public static final int h = 3;
  private static int[] i = { 1, 2, 3 };
  public static int d = 5;
  public static int Y = 10;
  private volatile long b;
  private int Z = 1;
  private volatile float e;
  com.biotools.poker.F.U c = new com.biotools.poker.F.U();

  public static void Q()
  {
    boolean bool1 = com.biotools.poker.E.£().getBoolean("USE_BOARD_FLIP_ANIMATION", true);
    boolean bool2 = com.biotools.poker.E.£().getBoolean("USE_BOARD_SWIRL_ANIMATION", true);
    boolean bool3 = com.biotools.poker.E.£().getBoolean("USE_BOARD_FADE_ANIMATION", true);
    int j = 0;
    if (bool1)
      j++;
    if (bool2)
      j++;
    if (bool3)
      j++;
    if (j == 0)
    {
      i = new int[1];
      i[0] = 0;
      return;
    }
    i = new int[j];
    int k = 0;
    if (bool1)
    {
      i[k] = 1;
      k++;
    }
    if (bool2)
    {
      i[k] = 3;
      k++;
    }
    if (bool3)
    {
      i[k] = 2;
      k++;
    }
  }

  public void B(M paramM)
  {
    super.B(paramM);
    int j = this.U.ʳ ? 245 : 280;
    int k = this.U.ʳ ? 185 : 275;
    if (this.U.ʳ)
      this.c.J();
    int m = this.c.A();
    int n = this.c.getWidth() + m * 4;
    int i1 = this.c.getHeight() + Y;
    this.W = new Rectangle(j, k, n, i1);
  }

  protected void B(Graphics2D paramGraphics2D)
  {
    Composite localComposite = paramGraphics2D.getComposite();
    com.biotools.poker.F.U[] arrayOfU = this.U.Ώ;
    int m = arrayOfU[0].A();
    float f1 = this.e;
    if (f1 < 0.0F)
      f1 = 0.0F;
    if (f1 > 1.0F)
      f1 = 1.0F;
    int j = this.W.x;
    int k = this.W.y;
    for (int i1 = 0; i1 < arrayOfU.length; i1++)
    {
      int n = 0;
      paramGraphics2D.setComposite(localComposite);
      if ((this.U.ʾ != null) && (arrayOfU[i1].N() != null) && (!this.U.ʾ.contains(arrayOfU[i1].N())))
      {
        AlphaComposite localAlphaComposite1 = AlphaComposite.getInstance(3, 0.5F);
        paramGraphics2D.setComposite(localAlphaComposite1);
        n = Y;
      }
      int i2 = j + m * i1;
      int i3 = k + n;
      int i4 = this.c.getWidth();
      int i5 = this.c.getHeight();
      if (arrayOfU[i1].isVisible())
      {
        arrayOfU[i1].A(i2, i3, paramGraphics2D, -1.0F);
        if ((com.biotools.poker.Q.E.B(i1) != null) && (!PokerApp.Ȅ().ʔ()) && (!PokerApp.Ȅ().Ǽ()))
          paramGraphics2D.drawImage(U.Ó, i2 + i4 - 15, i3 + 2, null);
      }
      else if ((arrayOfU[i1].D()) && (this.X))
      {
        if ((this.Z == 3) || (this.Z == 2))
        {
          int i6 = (int)(i4 * f1);
          int i7 = (int)(i5 * f1);
          Image localImage = arrayOfU[i1].M();
          AlphaComposite localAlphaComposite2 = AlphaComposite.getInstance(3, f1);
          AffineTransform localAffineTransform = paramGraphics2D.getTransform();
          if (this.Z == 2)
          {
            paramGraphics2D.setComposite(localAlphaComposite2);
            paramGraphics2D.drawImage(localImage, i2, i3, i4, i5, null);
          }
          else
          {
            int i8 = i2 + i4 / 2;
            int i9 = i3 + i5 / 2;
            i2 = i8 - i6 / 2;
            i3 = i9 - i7 / 2;
            paramGraphics2D.translate(i8, i9);
            paramGraphics2D.rotate(-6.283185307179586D * f1);
            paramGraphics2D.translate(-(i6 / 2), -(i7 / 2));
            paramGraphics2D.drawImage(localImage, 0, 0, i6, i7, 0, 0, i4, i5, null);
            paramGraphics2D.setTransform(localAffineTransform);
          }
        }
        else if (this.Z == 1)
        {
          i5 += 20;
          float f2;
          if (f1 < 0.5F)
          {
            f2 = 1.0F - f1 * 2.0F;
            this.c.A(j + m * i1 + i4, k + n, paramGraphics2D, f2, 1, true);
          }
          else
          {
            f2 = 1.0F - (1.0F - f1) * 2.0F;
            arrayOfU[i1].A(j + m * i1, k + n, paramGraphics2D, f2, 2, true);
          }
        }
      }
    }
    paramGraphics2D.setComposite(localComposite);
  }

  public void R()
  {
    this.b = System.currentTimeMillis();
    this.e = 0.0F;
    if (this.U.Ώ[0].D())
      T();
    if ((this.Z != 0) && (!M.R))
    {
      this.X = true;
      N();
    }
    else
    {
      P();
    }
  }

  private void T()
  {
    int j = (int)(Math.random() * i.length);
    this.Z = i[j];
  }

  public void A(M paramM)
  {
    if (!this.X)
      return;
    long l = System.currentTimeMillis() - this.b;
    if ((l > 500L) || (l < 0L))
    {
      P();
      this.e = 1.0F;
      O();
      C(paramM);
      return;
    }
    this.e = ((float)l / 500.0F);
    if (this.Z == 3)
      this.e = V.B(this.e);
    if ((this.Z == 1) || (this.Z == 2))
      this.e = V.A(this.e);
    C(paramM);
  }

  private void C(M paramM)
  {
    paramM.A(new J(new Rectangle(this.W.x - 20, this.W.y - 20, this.W.width + 90, this.W.height + 40), false));
  }

  private void P()
  {
    com.biotools.poker.F.U[] arrayOfU = this.U.Ώ;
    for (int j = 0; j < arrayOfU.length; j++)
      if ((arrayOfU[j].isVisible()) || (arrayOfU[j].D()))
      {
        arrayOfU[j].setVisible(true);
        arrayOfU[j].B(false);
      }
  }

  public J B(Rectangle paramRectangle)
  {
    if (!S())
      return null;
    return new J(this.W, false);
  }

  private boolean S()
  {
    return this.U.Ώ[0].isVisible();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.A
 * JD-Core Version:    0.6.2
 */