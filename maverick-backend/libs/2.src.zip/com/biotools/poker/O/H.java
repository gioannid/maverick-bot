package com.biotools.poker.O;

import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.A;
import com.biotools.poker.E;
import com.biotools.poker.F.N;
import java.awt.AlphaComposite;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;

public class H extends I
{
  private static final int Â = 1000;
  private double Á = 0.0D;
  private volatile long Ä;
  private float Ã;

  public void B(M paramM)
  {
    super.B(paramM);
    Point localPoint = h();
    this.W = new Rectangle(localPoint.x, localPoint.y, 10, 10);
  }

  private Point h()
  {
    int i = this.U.Ǩ().H();
    int j = (i - 60) / 2;
    int k = this.U.ʳ ? 267 : 365;
    return new Point(j, k);
  }

  protected void B(Graphics2D paramGraphics2D)
  {
    Point localPoint = h();
    if ((this.U.ʲ > 0.0D) && (this.Ã < 1.0F))
    {
      if (this.Ã != 0.0F)
      {
        float f = 1.0F - this.Ã;
        f = f > 1.0F ? 1.0F : f < 0.0F ? 0.0F : f;
        Composite localComposite = paramGraphics2D.getComposite();
        paramGraphics2D.setComposite(AlphaComposite.getInstance(3, f));
        this.W = N.A(this.U.ʲ, localPoint.x, localPoint.y, paramGraphics2D);
        paramGraphics2D.setComposite(localComposite);
      }
      else
      {
        this.W = N.A(this.U.ʲ, localPoint.x, localPoint.y, paramGraphics2D);
      }
      this.Á = this.U.ʲ;
    }
  }

  public void A(M paramM)
  {
    if (!this.X)
    {
      if (this.Á != this.U.ʲ)
        paramM.A(this);
      return;
    }
    paramM.A(this);
    long l = System.currentTimeMillis() - this.Ä;
    if (l > 1000L)
    {
      this.Ã = 1.0F;
      this.X = false;
      O();
      return;
    }
    this.Ã = ((float)l / 1000.0F);
  }

  public void i()
  {
    this.Ä = System.currentTimeMillis();
    this.Ã = 0.0F;
    if ((j()) && (this.U.ʲ > 0.0D))
    {
      this.X = true;
      N();
    }
  }

  public void g()
  {
    this.Ã = 0.0F;
  }

  private boolean j()
  {
    return (E.£().getBoolean("USE_CHIP_ANIMATION", true)) && (!M.R);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.H
 * JD-Core Version:    0.6.2
 */