package com.biotools.poker.O;

import com.biotools.poker.PokerApp;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;

public class E extends N
{
  boolean Ç = false;
  boolean È = true;
  boolean Æ = false;

  public void q()
  {
    this.È = (!this.È);
    this.Æ = true;
  }

  protected boolean m()
  {
    return true;
  }

  protected void H(Graphics2D paramGraphics2D)
  {
    paramGraphics2D.setFont(new Font("Arial", 0, 11));
  }

  protected String n()
  {
    return this.U.Ι;
  }

  protected Point C(int paramInt)
  {
    int i = 16;
    int j = PokerApp.Ȅ().ʋ().getWidth() - paramInt - 10;
    return new Point(j, i);
  }

  protected void A(Graphics2D paramGraphics2D, Rectangle paramRectangle, int paramInt)
  {
    paramGraphics2D.setColor(com.biotools.B.A.M);
    paramGraphics2D.fillRoundRect(paramRectangle.x - 10, paramRectangle.y - 2, paramInt + 30, paramRectangle.height + 4, 5, 5);
  }

  protected boolean l()
  {
    return com.biotools.poker.E.¤();
  }

  protected void B(Graphics2D paramGraphics2D)
  {
    if (this.È)
    {
      super.B(paramGraphics2D);
      return;
    }
    H(paramGraphics2D);
    FontMetrics localFontMetrics = paramGraphics2D.getFontMetrics();
    Point localPoint = A(0, localFontMetrics);
    this.W = new Rectangle(localPoint.x, localPoint.y - localFontMetrics.getAscent() - 1, 1, localFontMetrics.getHeight() + 1);
    A(paramGraphics2D, this.W, 0);
  }

  public void A(M paramM)
  {
    super.A(paramM);
    if (this.Æ)
    {
      this.Æ = false;
      this.W = p();
      paramM.A(this);
    }
  }

  public Rectangle p()
  {
    return new Rectangle(this.W.x - 10, this.W.y - 3, this.W.width + 30, this.W.height + 6);
  }

  public void C(int paramInt1, int paramInt2)
  {
    this.Ç = p().contains(paramInt1, paramInt2);
  }

  public void B(int paramInt1, int paramInt2)
  {
    if (!this.Ç)
      return;
    this.Ç = false;
    if (p().contains(paramInt1, paramInt2))
      q();
  }

  protected Color o()
  {
    return com.biotools.B.A.D;
  }

  protected boolean k()
  {
    return false;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.E
 * JD-Core Version:    0.6.2
 */