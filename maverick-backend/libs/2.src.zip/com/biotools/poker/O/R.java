package com.biotools.poker.O;

import com.biotools.poker.A;
import com.biotools.poker.PokerApp;
import java.awt.Component;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.VolatileImage;
import java.io.PrintStream;

public class R extends M
{
  public R(A paramA)
  {
    super(paramA);
  }

  public synchronized void A(Graphics2D paramGraphics2D, boolean paramBoolean)
  {
    int i = 0;
    Rectangle localRectangle = null;
    VolatileImage localVolatileImage = (VolatileImage)this.I;
    boolean bool1 = false;
    do
    {
      GraphicsConfiguration localGraphicsConfiguration = J();
      int j = localVolatileImage.validate(localGraphicsConfiguration);
      if (j == 2)
      {
        this.I = B(this.J, this.H);
        localVolatileImage = (VolatileImage)this.I;
        System.err.println("volatile image buffer created");
      }
      boolean bool2 = D();
      if ((bool2) || (i != 0) || (!paramBoolean))
      {
        i = 1;
        if (localRectangle == null)
          localRectangle = this.Q;
        if (!paramBoolean)
        {
          paramGraphics2D.drawImage(localVolatileImage, 0, 0, null);
        }
        else if (localRectangle != null)
        {
          if (localRectangle.y + localRectangle.height > this.H)
            localRectangle.height = (this.H - localRectangle.y);
          if (localRectangle.x + localRectangle.width > this.J)
            localRectangle.width = (this.J - localRectangle.x);
          paramGraphics2D.drawImage(localVolatileImage, localRectangle.x, localRectangle.y, localRectangle.x + localRectangle.width, localRectangle.y + localRectangle.height, localRectangle.x, localRectangle.y, localRectangle.x + localRectangle.width, localRectangle.y + localRectangle.height, null);
        }
        else
        {
          System.err.println("painting with no damage");
        }
      }
      bool1 = localVolatileImage.contentsLost();
      if (bool1)
        System.err.println("volatile image contents lost");
    }
    while ((i != 0) && (bool1));
  }

  private GraphicsConfiguration J()
  {
    return PokerApp.Ȅ().getGraphicsConfiguration();
  }

  public void A(Component paramComponent)
  {
    super.A(paramComponent);
  }

  public Image B(int paramInt1, int paramInt2)
  {
    GraphicsConfiguration localGraphicsConfiguration = J();
    return localGraphicsConfiguration.createCompatibleVolatileImage(paramInt1, paramInt2);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.R
 * JD-Core Version:    0.6.2
 */