package com.biotools.poker.O;

import java.awt.Graphics2D;
import java.awt.Rectangle;

public abstract interface P
{
  public abstract void B(M paramM);

  public abstract void A(M paramM);

  public abstract void A();

  public abstract boolean A(Rectangle paramRectangle);

  public abstract void A(Graphics2D paramGraphics2D);

  public abstract J B(Rectangle paramRectangle);

  public abstract void B();
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.P
 * JD-Core Version:    0.6.2
 */