package com.biotools.poker.O;

import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.A;
import com.biotools.poker.E;
import com.biotools.poker.F.S;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;

public class B extends I
{
  private static final int l = 25;
  private static final int k = 6000;
  private int n;
  private long m;
  private String j = null;

  public B(int paramInt)
  {
    this.n = paramInt;
  }

  private boolean V()
  {
    return E.£().getBoolean("USE_PLAYER_CHAT_ANIMATION", true);
  }

  public void B(M paramM)
  {
    super.B(paramM);
    Point localPoint = U();
    this.W = new Rectangle(localPoint.x, localPoint.y, 10, 10);
  }

  private Point U()
  {
    S localS = this.U.ʴ[this.n];
    Point localPoint = localS.E();
    int i = localPoint.x - 12;
    int i1 = localPoint.y + 20;
    return new Point(i, i1);
  }

  private String X()
  {
    S localS = this.U.ʴ[this.n];
    return localS.H();
  }

  protected void B(Graphics2D paramGraphics2D)
  {
    if (!this.X)
      return;
    Point localPoint = U();
    String str = X();
    if (str == null)
      return;
    int i = localPoint.x;
    int i1 = localPoint.y;
    paramGraphics2D.setFont(new Font("Arial", 1, 10));
    FontMetrics localFontMetrics = paramGraphics2D.getFontMetrics();
    ArrayList localArrayList = new ArrayList();
    int i2 = A(str, localArrayList, localFontMetrics);
    paramGraphics2D.setComposite(AlphaComposite.getInstance(3, 0.6F));
    paramGraphics2D.setColor(Color.black);
    int i3 = localFontMetrics.getHeight() * localArrayList.size();
    this.W = new Rectangle(i, i1, i2 + 8, i3 + 8);
    paramGraphics2D.fillRoundRect(this.W.x, this.W.y, this.W.width - 2, this.W.height - 2, 6, 6);
    paramGraphics2D.setComposite(AlphaComposite.getInstance(3, 1.0F));
    paramGraphics2D.setColor(Color.white);
    for (int i4 = 0; i4 < localArrayList.size(); i4++)
    {
      str = (String)localArrayList.get(i4);
      paramGraphics2D.drawString(str, i + 3, i1 + localFontMetrics.getHeight() * (i4 + 1));
    }
  }

  public void A(M paramM)
  {
    if (!V())
      return;
    String str = X();
    if ((str == null) || (str.length() == 0))
    {
      str = null;
      if (this.X)
        O();
      return;
    }
    if (!str.equals(this.j))
    {
      this.m = System.currentTimeMillis();
      this.X = true;
      Point localPoint = U();
      int i = localPoint.x;
      int i1 = localPoint.y;
      FontMetrics localFontMetrics = this.U.getFontMetrics(new Font("Arial", 1, 10));
      ArrayList localArrayList = new ArrayList();
      int i2 = A(str, localArrayList, localFontMetrics) + 8;
      int i3 = localFontMetrics.getHeight() * localArrayList.size() + 8;
      if (this.W != null)
      {
        i2 = Math.max(i2, this.W.width);
        i3 = Math.max(i2, this.W.height);
      }
      this.W = new Rectangle(i, i1, i2 + 8, i3 + 8);
      paramM.A(this);
      this.j = str;
      return;
    }
    if (!this.X)
      return;
    if (System.currentTimeMillis() - this.m > 6000L)
    {
      paramM.A(this);
      O();
    }
  }

  private int A(String paramString, List paramList, FontMetrics paramFontMetrics)
  {
    String str1 = paramString;
    int i = 60;
    if (str1.length() > i)
    {
      str1 = str1.substring(0, i);
      str1 = str1 + "...";
    }
    int i1 = -1;
    while (str1.length() > 25)
    {
      i2 = 0;
      int i3 = -1;
      while ((i2 <= 25) && (i2 != -1))
      {
        i3 = i2;
        i2 = str1.indexOf(' ', i3 + 1);
      }
      if (i3 <= 0)
        i3 = 25;
      String str2 = str1.substring(0, i3);
      paramList.add(str2);
      int i4 = paramFontMetrics.stringWidth(str2);
      i1 = i1 < i4 ? i4 : i1;
      str1 = str1.substring(i3 + 1);
    }
    paramList.add(str1);
    int i2 = paramFontMetrics.stringWidth(str1);
    i1 = i1 < i2 ? i2 : i1;
    return i1;
  }

  public J B(Rectangle paramRectangle)
  {
    if (!W())
      return null;
    return new J(this.W, false);
  }

  private boolean W()
  {
    return (this.X) && (X() != null);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.B
 * JD-Core Version:    0.6.2
 */