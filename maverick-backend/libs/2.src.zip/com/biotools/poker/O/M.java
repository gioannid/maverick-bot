package com.biotools.poker.O;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import javax.imageio.ImageIO;

public class M
{
  public static volatile boolean R = false;
  public static final boolean B = false;
  public static volatile boolean P = true;
  private static final int K = 200;
  protected com.biotools.poker.A D;
  protected Image I;
  public C M;
  protected List O;
  protected List G;
  protected Component N;
  protected Rectangle Q;
  int H;
  int J;
  public O C;
  public A A;
  public H E;
  public X F;
  public E L;

  public M(com.biotools.poker.A paramA)
  {
    this.D = paramA;
    this.J = (paramA.ʳ ? 770 : 806);
    this.H = (paramA.ʳ ? 520 : 670);
    this.M = new C();
    if (paramA.ʳ)
      C.G = "pix/smalltables/";
    this.O = new LinkedList();
    this.G = new ArrayList();
    this.N = paramA;
    this.I = null;
  }

  public synchronized void A(Graphics paramGraphics)
  {
    if ((paramGraphics != null) && (this.D.isShowing()))
      A((Graphics2D)paramGraphics, true);
  }

  public synchronized void A(Graphics2D paramGraphics2D)
  {
    A(paramGraphics2D, false);
  }

  public void A(Graphics2D paramGraphics2D, boolean paramBoolean)
  {
    D();
    paramGraphics2D.drawImage(this.I, 0, 0, null);
  }

  public boolean D()
  {
    Graphics2D localGraphics2D = (Graphics2D)this.I.getGraphics();
    com.biotools.poker.A.B(localGraphics2D);
    for (int i = 0; i < this.G.size(); i++)
    {
      P localP = (P)this.G.get(i);
      localP.A(this);
    }
    if (this.O.size() != 0)
    {
      if (this.O.size() >= 200)
      {
        this.O.clear();
        E();
      }
      G();
      B(localGraphics2D);
      C(localGraphics2D);
      this.O.clear();
      localGraphics2D.dispose();
      return true;
    }
    localGraphics2D.dispose();
    return false;
  }

  protected void B(Graphics2D paramGraphics2D)
  {
    Iterator localIterator = this.O.iterator();
    while (localIterator.hasNext())
    {
      J localJ = (J)localIterator.next();
      if (!localJ.C)
      {
        Rectangle localRectangle = localJ.A;
        if (localRectangle.y + localRectangle.height > this.H)
          localRectangle.height = (this.H - localRectangle.y);
        if (localRectangle.x + localRectangle.width > this.J)
          localRectangle.width = (this.J - localRectangle.x);
        paramGraphics2D.drawImage(this.M.B, localRectangle.x, localRectangle.y, localRectangle.x + localRectangle.width, localRectangle.y + localRectangle.height, localRectangle.x, localRectangle.y, localRectangle.x + localRectangle.width, localRectangle.y + localRectangle.height, null);
      }
    }
  }

  protected void C(Graphics2D paramGraphics2D)
  {
    Object localObject;
    for (int i = 0; i < this.G.size(); i++)
    {
      localObject = (P)this.G.get(i);
      ((P)localObject).A();
    }
    for (i = 0; i < this.G.size(); i++)
    {
      localObject = this.O.iterator();
      while (((Iterator)localObject).hasNext())
      {
        J localJ = (J)((Iterator)localObject).next();
        P localP = (P)this.G.get(i);
        if (((!com.biotools.poker.E.X()) || (!(localP instanceof com.biotools.poker.F.J))) && (localP.A(localJ.A)))
          localP.A(paramGraphics2D);
      }
    }
  }

  public BufferedImage A(File paramFile)
  {
    BufferedImage localBufferedImage = null;
    try
    {
      localBufferedImage = ImageIO.read(paramFile);
    }
    catch (Exception localException)
    {
      com.biotools.A.I.A("Could not read image file", localException);
    }
    return localBufferedImage;
  }

  public Image B(File paramFile)
  {
    Object localObject = A(paramFile);
    localObject = this.N.createImage(((Image)localObject).getSource());
    return localObject;
  }

  public Image A(int paramInt1, int paramInt2)
  {
    Image localImage = this.N.createImage(paramInt1, paramInt2);
    return localImage;
  }

  public Image B(int paramInt1, int paramInt2)
  {
    return A(paramInt1, paramInt2);
  }

  public void A(Component paramComponent)
  {
    this.N = paramComponent;
    this.I = B(this.J, this.H);
    A(J.A(this));
    G.D(this);
    U.F(this);
    O.E(this);
    for (int i = 0; i < this.G.size(); i++)
    {
      P localP = (P)this.G.get(i);
      localP.B(this);
    }
    Graphics2D localGraphics2D = (Graphics2D)this.I.getGraphics();
    localGraphics2D.drawImage(this.M.B, 0, 0, null);
    localGraphics2D.dispose();
    this.N = this.D;
  }

  public synchronized void A(J paramJ)
  {
    assert (paramJ.A != null) : "bad rectangle for damage";
    if (paramJ.A == null)
      return;
    if (this.O.size() < 200)
      this.O.add(paramJ);
  }

  public void A(I paramI)
  {
    Rectangle localRectangle = paramI.W;
    A(new J(localRectangle, false));
  }

  public int I()
  {
    return this.H;
  }

  public int H()
  {
    return this.J;
  }

  public com.biotools.poker.A C()
  {
    return this.D;
  }

  public void A()
  {
    for (int i = 0; i < this.G.size(); i++)
    {
      P localP = (P)this.G.get(i);
      localP.B();
    }
  }

  public synchronized void E()
  {
    A(J.A(this));
  }

  public Image B()
  {
    return this.I;
  }

  public void F()
  {
    this.G.add(this.M);
    this.C = new O();
    this.G.add(this.C);
    this.G.add(D.M);
    for (int i = 0; i < 10; i++)
    {
      this.G.add(new U(i));
      this.G.add(new G(i));
    }
    this.G.add(this.D.Ǆ().E());
    ArrayList localArrayList = this.D.Ύ;
    for (int j = 0; j < localArrayList.size(); j++)
      this.G.add(localArrayList.get(j));
    this.A = new A();
    this.E = new H();
    this.F = new X();
    this.G.add(this.A);
    this.G.add(this.E);
    this.G.add(this.F);
    for (j = 0; j < 10; j++)
      this.G.add(new Z(j));
    this.G.add(new F());
    this.G.add(new L());
    this.G.add(new W());
    this.L = new E();
    this.G.add(this.L);
    this.G.add(new S());
    for (j = 0; j < 10; j++)
      this.G.add(new B(j));
  }

  protected void G()
  {
    LinkedList localLinkedList = new LinkedList(this.O);
    Object localObject3;
    while (localLinkedList.size() > 0)
    {
      localObject1 = (J)localLinkedList.get(0);
      localLinkedList.remove(0);
      localObject2 = ((J)localObject1).A;
      for (int i = 0; i < this.G.size(); i++)
      {
        localObject3 = (P)this.G.get(i);
        if (((P)localObject3).A((Rectangle)localObject2))
        {
          J localJ2 = ((P)localObject3).B((Rectangle)localObject2);
          assert ((localJ2 == null) || (localJ2.A != null)) : "bad collatoral damage rectangle";
          if ((localJ2 != null) && (localJ2.A != null) && (!((Rectangle)localObject2).contains(localJ2.A)) && (!A(this.O, localJ2)))
          {
            localLinkedList.add(localJ2);
            this.O.add(localJ2);
          }
        }
      }
    }
    Collections.sort(this.O, new Comparator()
    {
      public int compare(Object paramAnonymousObject1, Object paramAnonymousObject2)
      {
        Rectangle localRectangle1 = ((J)paramAnonymousObject1).A;
        Rectangle localRectangle2 = ((J)paramAnonymousObject2).A;
        return localRectangle2.width * localRectangle2.height - localRectangle1.width * localRectangle1.height;
      }
    });
    Object localObject1 = this.O.listIterator();
    Object localObject2 = null;
    this.Q = null;
    while (((ListIterator)localObject1).hasNext())
    {
      J localJ1 = (J)((ListIterator)localObject1).next();
      localObject3 = localJ1.A;
      if (this.Q == null)
        this.Q = ((Rectangle)localObject3);
      else
        this.Q = this.Q.union((Rectangle)localObject3);
      if (localObject2 == null)
        localObject2 = localObject3;
      else if ((((Rectangle)localObject2).equals(localObject3)) || (((Rectangle)localObject2).contains((Rectangle)localObject3)))
        ((ListIterator)localObject1).remove();
    }
  }

  private boolean A(List paramList, J paramJ)
  {
    for (int i = 0; i < paramList.size(); i++)
    {
      J localJ = (J)paramList.get(i);
      if (localJ.A.equals(paramJ.A))
        return true;
    }
    return false;
  }

  public static void B(boolean paramBoolean)
  {
    if ((!paramBoolean) && (!P))
    {
      com.biotools.poker.E.H("Not allowed to turn animations here!");
      return;
    }
    R = paramBoolean;
  }

  public static void A(boolean paramBoolean)
  {
    P = paramBoolean;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.M
 * JD-Core Version:    0.6.2
 */