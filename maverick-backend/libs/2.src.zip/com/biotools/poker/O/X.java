package com.biotools.poker.O;

import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.A;
import com.biotools.poker.E;
import com.biotools.poker.F.S;
import com.biotools.poker.PokerApp;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class X
  implements P
{
  A æ;
  boolean å;
  int è;
  int ç;

  public void B(M paramM)
  {
    this.æ = paramM.C();
  }

  public void A(M paramM)
  {
    if (!this.å)
      return;
    int j = 0;
    int k = 1;
    while (this.è < this.ç * 2)
    {
      k = this.è >= this.ç ? 1 : 0;
      int i = this.æ.ǆ()._();
      j = (i + this.è) % this.ç;
      this.è += 1;
      if (this.æ.ǆ().inGame(j))
      {
        S localS = this.æ.ʴ[j];
        localS.A(true, k == 0);
        paramM.A(localS.W);
        PokerApp.Ȅ().ȏ().T();
        return;
      }
    }
    if (this.è >= this.ç * 2)
    {
      µ();
      return;
    }
  }

  public void A()
  {
  }

  public boolean A(Rectangle paramRectangle)
  {
    return false;
  }

  public void A(Graphics2D paramGraphics2D)
  {
  }

  public J B(Rectangle paramRectangle)
  {
    return null;
  }

  public synchronized void F(int paramInt)
  {
    this.è = 0;
    this.ç = paramInt;
    if (ª())
    {
      this.å = true;
      while (this.å)
        try
        {
          wait();
        }
        catch (InterruptedException localInterruptedException)
        {
        }
      return;
    }
    º();
  }

  private void º()
  {
    for (int i = 0; i < this.æ.Σ; i++)
      if (this.æ.ǆ().inGame(i))
      {
        this.æ.ʴ[i].A(true, true);
        this.æ.ʴ[i].A(true, false);
      }
  }

  private synchronized void µ()
  {
    this.å = false;
    notifyAll();
  }

  private boolean ª()
  {
    return (E.£().getBoolean("USE_DEAL_ANIMATION", true)) && (!M.R);
  }

  public void B()
  {
    º();
    µ();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.X
 * JD-Core Version:    0.6.2
 */