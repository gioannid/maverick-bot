package com.biotools.poker.O;

import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.F.S;
import com.biotools.poker.PokerApp;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;

public class U extends I
{
  private static final int Ò = 400;
  static Image Ó;
  int Õ;
  float Ñ;
  long Ô;

  public static void F(M paramM)
  {
    Ó = paramM.B(com.biotools.poker.E.K("pix/lock.png"));
  }

  public U(int paramInt)
  {
    this.Õ = paramInt;
    this.X = false;
    this.Ñ = 1.0F;
  }

  public void B(M paramM)
  {
    super.B(paramM);
    S localS = this.U.ʴ[this.Õ];
    localS.W = this;
    Point localPoint = localS.E();
    com.biotools.poker.F.U localU = localS.J()[0];
    int i = localU.getWidth();
    int j = localU.getHeight();
    i += i / 3;
    j += 30;
    this.W = new Rectangle(localPoint.x, localPoint.y, i, j);
  }

  protected void B(Graphics2D paramGraphics2D)
  {
    S localS = this.U.ʴ[this.Õ];
    com.biotools.poker.F.U[] arrayOfU = localS.J();
    Point localPoint = localS.E();
    Composite localComposite = paramGraphics2D.getComposite();
    if ((localS.M()) && (!this.X))
      return;
    if ((this.Ñ != 1.0F) && (this.X))
      paramGraphics2D.setComposite(AlphaComposite.getInstance(3, this.Ñ));
    AlphaComposite localAlphaComposite = AlphaComposite.getInstance(3, 0.5F);
    int i = arrayOfU[0].getWidth();
    int j = arrayOfU[0].getHeight();
    arrayOfU[0].A(localPoint.x, localPoint.y, paramGraphics2D, -1.0F);
    if ((arrayOfU[0].isVisible()) && (com.biotools.poker.Q.E.A(this.Õ, 0)) && (!PokerApp.Ȅ().ʔ()) && (!PokerApp.Ȅ().Ǽ()))
    {
      if (arrayOfU[0].B())
        paramGraphics2D.setComposite(localAlphaComposite);
      paramGraphics2D.drawImage(Ó, localPoint.x + i - 15, localPoint.y + 2, null);
      if (arrayOfU[0].B())
        paramGraphics2D.setComposite(localComposite);
    }
    int k = localPoint.x + arrayOfU[1].getWidth() / 3;
    int m = localPoint.y + arrayOfU[1].getHeight() / 6;
    arrayOfU[1].A(k, m, paramGraphics2D, -1.0F);
    if ((arrayOfU[1].isVisible()) && (com.biotools.poker.Q.E.A(this.Õ, 1)) && (!PokerApp.Ȅ().ʔ()) && (!PokerApp.Ȅ().Ǽ()))
    {
      if (arrayOfU[1].B())
        paramGraphics2D.setComposite(localAlphaComposite);
      paramGraphics2D.drawImage(Ó, k + i - 15, m + 2, null);
      if (arrayOfU[1].B())
        paramGraphics2D.setComposite(localComposite);
    }
    String str = localS.D();
    if ((str != null) && (!str.equals(com.biotools.poker.E.D("PokerTable.LoserString"))))
    {
      paramGraphics2D.setFont(new Font("Georgia", 0, 12));
      FontMetrics localFontMetrics = paramGraphics2D.getFontMetrics();
      int n = localFontMetrics.stringWidth(str);
      int i1 = k + arrayOfU[1].getWidth() - localPoint.x;
      k = localPoint.x + i1 / 2 - n / 2;
      m = localPoint.y + 50;
      int i2 = 5;
      paramGraphics2D.setColor(Color.YELLOW);
      paramGraphics2D.fillRoundRect(k - i2, m - i2, n + i2 + i2, localFontMetrics.getHeight() + i2 + i2, i2 * 2, i2 * 2);
      paramGraphics2D.setColor(Color.ORANGE);
      paramGraphics2D.drawRoundRect(k - i2, m - i2, n + i2 + i2 - 1, localFontMetrics.getHeight() + i2 + i2 - 1, i2 * 2, i2 * 2);
      paramGraphics2D.setColor(Color.BLACK);
      paramGraphics2D.drawString(str, k, m + localFontMetrics.getAscent());
    }
    paramGraphics2D.setComposite(localComposite);
  }

  public void w()
  {
    if (!x())
      return;
    S localS = this.U.ʴ[this.Õ];
    this.Ô = System.currentTimeMillis();
    this.Ñ = 1.0F;
    this.X = true;
    N();
  }

  public void A(M paramM)
  {
    if (!this.X)
      return;
    paramM.A(this);
    long l = System.currentTimeMillis() - this.Ô;
    if (l > 400L)
    {
      this.Ñ = 0.0F;
      this.X = false;
      O();
      return;
    }
    this.Ñ = (1.0F - (float)l / 400.0F);
    if (this.Ñ > 1.0F)
      this.Ñ = 1.0F;
    if (this.Ñ < 0.0F)
      this.Ñ = 0.0F;
  }

  private boolean x()
  {
    return (com.biotools.poker.E.£().getBoolean("USE_FOLD_ANIMATION", true)) && (!M.R);
  }

  public J B(Rectangle paramRectangle)
  {
    if (!v())
      return null;
    return new J(this.W, false);
  }

  private boolean v()
  {
    S localS = this.U.ʴ[this.Õ];
    return (!localS.M()) || (this.X);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.U
 * JD-Core Version:    0.6.2
 */