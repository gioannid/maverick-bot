package com.biotools.poker.O;

import com.biotools.meerkat.Action;
import com.biotools.meerkat.GameInfo;
import com.biotools.poker.A;
import com.biotools.poker.E;
import com.biotools.poker.Q.D;
import com.biotools.poker.Q.K;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Point;

public class F extends N
{
  protected void H(Graphics2D paramGraphics2D)
  {
    paramGraphics2D.setFont(new Font("Arial", 1, 12));
  }

  protected String n()
  {
    if (this.U.Ǡ() == null)
      return "";
    if (!this.U.Ǡ().R())
      return null;
    D localD = this.U.ǆ();
    if (localD == null)
      return "";
    int i = localD.getNumSidePots();
    double d = localD.getRake();
    if (i == 0)
    {
      localObject = new Object[] { Action.formatCash(localD.getMainPotSize() - d) };
      return E.A("PotText.PotPattern", (Object[])localObject);
    }
    d = 0.0D;
    Object localObject = new StringBuffer();
    for (int j = i - 1; j >= 0; j--)
    {
      Object[] arrayOfObject2 = { Action.formatCash(localD.getSidePotSize(j)) };
      ((StringBuffer)localObject).append(E.A("PotText.MultiplePotsPatternCombiner", arrayOfObject2));
    }
    Object[] arrayOfObject1 = { ((StringBuffer)localObject).toString(), Action.formatCash(localD.getMainPotSize() - d) };
    return E.A("PotText.MultiplePotsPatternOverall", arrayOfObject1);
  }

  protected Point C(int paramInt)
  {
    int i = this.U.ʳ ? 232 : 310;
    int j = this.U.ʳ ? 103 : 83;
    return new Point(j, i);
  }

  protected Point A(int paramInt, FontMetrics paramFontMetrics)
  {
    Point localPoint = C(paramInt);
    int i = paramFontMetrics.stringWidth(E.D("PotText.RakeTitle")) - paramFontMetrics.stringWidth(E.D("PotText.PotTitle"));
    localPoint.x += i;
    return localPoint;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.F
 * JD-Core Version:    0.6.2
 */