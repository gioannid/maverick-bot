package com.biotools.poker.O;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class S extends I
{
  public void B(M paramM)
  {
    super.B(paramM);
    D(10, 10);
  }

  private void D(int paramInt1, int paramInt2)
  {
    int i = (this.U.Ǩ().H() - paramInt1) / 2;
    int j = 16 + (this.U.Ǩ().I() - 40 - paramInt2) / 2;
    this.W = new Rectangle(i, j, paramInt1, paramInt2);
  }

  protected void B(Graphics2D paramGraphics2D)
  {
    String str = this.U.Ή;
    if (str == null)
      return;
    paramGraphics2D.setFont(new Font("Arial", 1, 12));
    FontMetrics localFontMetrics = paramGraphics2D.getFontMetrics();
    String[] arrayOfString = str.split("\\|");
    int i = 0;
    for (int j = 0; j < arrayOfString.length; j++)
    {
      k = localFontMetrics.stringWidth(arrayOfString[j]);
      if (k > i)
        i = k;
    }
    j = 16;
    int k = i + j + j;
    int m = j + j + localFontMetrics.getHeight() * arrayOfString.length;
    D(k + 6, m + 6);
    int n = this.W.x + 3;
    int i1 = this.W.y + 3;
    int i2 = n;
    paramGraphics2D.setComposite(AlphaComposite.getInstance(3, 0.75F));
    paramGraphics2D.setColor(Color.BLACK);
    paramGraphics2D.fillRoundRect(this.W.x, this.W.y, this.W.width, this.W.height, 5, 5);
    paramGraphics2D.setColor(com.biotools.B.A.M);
    paramGraphics2D.fillRoundRect(n, i1, k, m, 5, 5);
    paramGraphics2D.setColor(com.biotools.B.A.D);
    paramGraphics2D.setComposite(AlphaComposite.getInstance(3, 1.0F));
    i1 += j + localFontMetrics.getAscent();
    for (int i3 = 0; i3 < arrayOfString.length; i3++)
      paramGraphics2D.drawString(arrayOfString[i3], n + (k - localFontMetrics.stringWidth(arrayOfString[i3])) / 2, i1 + localFontMetrics.getHeight() * i3);
  }

  public void A(M paramM)
  {
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.S
 * JD-Core Version:    0.6.2
 */