package com.biotools.poker.O;

import java.awt.Point;

class K extends V
{
  Point J;
  Point I;

  K(Point paramPoint1, Point paramPoint2)
  {
    this.J = paramPoint1;
    this.I = paramPoint2;
  }

  Point A(double paramDouble)
  {
    double d1 = 1.0D - paramDouble;
    double d2 = paramDouble;
    double d3 = this.J.x * d1 + this.I.x * d2;
    double d4 = this.J.y * d1 + this.I.y * d2;
    return new Point((int)d3, (int)d4);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.K
 * JD-Core Version:    0.6.2
 */