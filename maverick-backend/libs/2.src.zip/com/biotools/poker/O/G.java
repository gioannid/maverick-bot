package com.biotools.poker.O;

import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import com.biotools.poker.F.S;
import com.biotools.poker.PokerApp;
import com.biotools.poker.Q.K;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.File;
import java.io.PrintStream;

public class G extends I
{
  private static final Color o = new Color(220, 170, 120);
  public static volatile boolean r = false;
  private static Image µ;
  private static Image u;
  private static Image v;
  private static Image[] s;
  private static int z = -1;
  private static int q = -1;
  private static final float p = 0.7F;
  private int w;
  private float ¥;
  private long £;
  private boolean À;
  private boolean x = false;
  private Rectangle º = null;
  private V y = null;
  Image ª = null;
  Image t = null;
  String ¢ = null;
  private String ¤ = "";

  public static void D(M paramM)
  {
    µ = paramM.B(E.K("pix/meerkat-player-bg.png"));
    u = paramM.B(E.K("pix/meerkat-player-bg-5.png"));
    v = paramM.B(E.K("pix/meerkat-player-bg-6.png"));
  }

  public G(int paramInt)
  {
    this.w = paramInt;
    this.¥ = 0.0F;
    this.X = false;
    this.À = false;
    this.ª = null;
  }

  public void A(Image paramImage)
  {
    this.t = paramImage;
  }

  public void B(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      if (_())
      {
        this.£ = System.currentTimeMillis();
        this.X = true;
      }
      else
      {
        this.X = false;
      }
      this.À = true;
      for (int i = 0; i < 10; i++)
        if (i != this.w)
          this.U.ʴ[i].T.B(false);
    }
    else
    {
      this.¥ = 0.0F;
      this.À = false;
      this.X = false;
      this.U.Ǩ().A(this);
    }
  }

  public void C(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      if (_())
      {
        this.£ = System.currentTimeMillis();
        this.X = true;
      }
      else
      {
        this.X = false;
      }
      this.x = true;
    }
    else
    {
      this.¥ = 0.0F;
      this.x = false;
      this.X = false;
      this.U.Ǩ().A(this);
    }
  }

  protected void B(Graphics2D paramGraphics2D)
  {
    if (Z())
      return;
    if (Y())
    {
      if (d())
        G(paramGraphics2D);
      else
        C(paramGraphics2D);
      return;
    }
    E(paramGraphics2D);
  }

  private boolean Y()
  {
    return !this.U.Ǡ().H(this.w);
  }

  private boolean d()
  {
    if (PokerApp.Ȅ().Ǽ())
    {
      com.biotools.poker.Q.J localJ = (com.biotools.poker.Q.J)this.U.Ǡ();
      return localJ.æ();
    }
    return false;
  }

  private boolean Z()
  {
    return (((this.U.Ǡ() instanceof com.biotools.poker.Q.J)) && (!d()) && (Y())) || ((r) && (Y()));
  }

  private Rectangle c()
  {
    if (!this.x)
    {
      Rectangle localRectangle1 = this.W;
      if (r)
        localRectangle1 = new Rectangle(localRectangle1.x, localRectangle1.y, localRectangle1.width, localRectangle1.height + 8);
      return localRectangle1;
    }
    if (z < 100)
    {
      z = PokerApp.Ȅ().ʋ().getWidth();
      q = PokerApp.Ȅ().ʋ().getHeight();
    }
    int i = 20;
    Rectangle localRectangle2 = new Rectangle(this.W.x - i, this.W.y - i, this.W.width + i + i, this.W.height + i + i);
    if (localRectangle2.x + localRectangle2.width >= z)
      localRectangle2.width = (z - localRectangle2.x);
    if (localRectangle2.y + localRectangle2.height >= q)
      localRectangle2.height = (q - localRectangle2.y);
    if (localRectangle2.x < 0)
      localRectangle2.x = 0;
    if (localRectangle2.y < 0)
      localRectangle2.y = 0;
    return localRectangle2;
  }

  public void B(M paramM)
  {
    super.B(paramM);
    Point localPoint = this.U.ʴ[this.w].K();
    this.W = new Rectangle(localPoint.x, localPoint.y, 100, 50);
    this.U.ʴ[this.w].T = this;
  }

  public void A(M paramM)
  {
    if (!this.X)
    {
      if (D.M.K())
      {
        System.out.println("whoops!!");
        f1 = D.M.O;
        f2 = D.M.R;
        int i = D.M.Q;
        paramM.A(new J(A(f1, i), false));
        this.º = A(f2, i);
        paramM.A(new J(this.º, false));
      }
      else
      {
        this.º = null;
        this.y = null;
        if (!this.¤.equals(this.U.ʴ[this.w].P()))
          paramM.A(this);
      }
      return;
    }
    this.º = null;
    this.y = null;
    float f1 = 2000.0F;
    float f2 = (float)(System.currentTimeMillis() - this.£) % f1 / f1;
    f2 = (float)(f2 - 0.5D);
    f2 = f2 < 0.0F ? -f2 : f2;
    f2 = (float)(f2 + 0.2D);
    this.¥ = f2;
    paramM.A(new J(c(), false));
  }

  public J B(Rectangle paramRectangle)
  {
    return new J(this.W, false);
  }

  private Rectangle A(float paramFloat, int paramInt)
  {
    boolean bool = D.M.P;
    if (this.y == null)
    {
      int i = paramInt > 5 ? 10 - paramInt : paramInt;
      if (bool)
        i = 1;
      Point[] arrayOfPoint = new Point[i + 1];
      if (bool)
      {
        arrayOfPoint[0] = this.U.ʴ[this.w].K();
        arrayOfPoint[1] = this.U.ʴ[((this.w + paramInt) % 10)].K();
      }
      else
      {
        int j;
        int k;
        Point localPoint2;
        if (paramInt <= 5)
        {
          System.out.println("total is " + paramInt);
          for (j = 0; j <= i; j++)
          {
            k = (this.w + j) % 10;
            localPoint2 = this.U.ʴ[k].K();
            arrayOfPoint[j] = localPoint2;
          }
        }
        else
        {
          System.out.println("total2 is " + paramInt);
          for (j = 0; j <= i; j++)
          {
            k = (this.w - j) % 10;
            if (k < 0)
              k += 10;
            localPoint2 = this.U.ʴ[k].K();
            arrayOfPoint[j] = localPoint2;
          }
        }
      }
      this.y = V.A(arrayOfPoint);
      if (this.y == null)
      {
        E.H("err: path with cp of size: " + arrayOfPoint.length);
        arrayOfPoint = new Point[2];
        arrayOfPoint[0] = this.U.ʴ[this.w].K();
        arrayOfPoint[1] = this.U.ʴ[((this.w + paramInt) % 10)].K();
        this.y = V.A(arrayOfPoint);
      }
    }
    if ((bool) && (paramFloat > 0.5D))
      paramFloat = 1.0F - paramFloat;
    Point localPoint1 = this.y.A(paramFloat);
    return new Rectangle(localPoint1.x, localPoint1.y, 100, 50);
  }

  private void C(Graphics2D paramGraphics2D)
  {
    Rectangle localRectangle = b();
    Composite localComposite = paramGraphics2D.getComposite();
    paramGraphics2D.setComposite(AlphaComposite.getInstance(3, 0.3F));
    paramGraphics2D.drawImage(µ, localRectangle.x, localRectangle.y, null);
    paramGraphics2D.setComposite(localComposite);
  }

  private void G(Graphics2D paramGraphics2D)
  {
    Rectangle localRectangle = b();
    Composite localComposite = paramGraphics2D.getComposite();
    paramGraphics2D.setComposite(AlphaComposite.getInstance(3, 0.6F));
    paramGraphics2D.drawImage(µ, localRectangle.x, localRectangle.y, null);
    paramGraphics2D.setComposite(localComposite);
    int i = localRectangle.x;
    int j = localRectangle.y;
    com.biotools.poker.A.A(paramGraphics2D);
    paramGraphics2D.setFont(new Font("Arial", 1, 13));
    FontMetrics localFontMetrics = paramGraphics2D.getFontMetrics();
    paramGraphics2D.setColor(o);
    String str = "Select";
    j += 21;
    paramGraphics2D.drawString(str, i + 50 - localFontMetrics.stringWidth(str) / 2, j);
    str = "Seat";
    paramGraphics2D.drawString(str, i + 50 - localFontMetrics.stringWidth(str) / 2, j + localFontMetrics.getHeight());
    com.biotools.poker.A.B(paramGraphics2D);
  }

  private void E(Graphics2D paramGraphics2D)
  {
    if (r)
      F(paramGraphics2D);
    else
      D(paramGraphics2D);
  }

  Rectangle f()
  {
    int i = b().x;
    int j = b().y;
    switch (this.w)
    {
    case 0:
      i -= 10;
      j -= 15;
      break;
    case 1:
      i -= 10;
      j -= 20;
      break;
    case 2:
      i -= 5;
      j -= 20;
      break;
    case 3:
      i -= 7;
      j -= 24;
      break;
    case 4:
      i -= 10;
      j -= 30;
      break;
    case 5:
      i -= 10;
      j -= 30;
      break;
    case 6:
      i -= 18;
      j -= 30;
      break;
    case 7:
      i -= 20;
      j -= 28;
      break;
    case 8:
      i -= 20;
      j -= 20;
      break;
    case 9:
      i -= 15;
      j -= 15;
    }
    return new Rectangle(i, j, 130, 80);
  }

  public void a()
  {
    String str = "pix/avatars/" + e() + ".png";
    if ((this.¢ != null) && (this.¢.equals(str)))
      return;
    this.¢ = str;
    int i = this.ª == null ? 1 : 0;
    File localFile = new File(str);
    if (localFile.exists())
    {
      this.ª = PokerApp.Ȅ().ʋ().Ǩ().B(localFile);
    }
    else
    {
      if (s == null)
      {
        s = new Image[10];
        for (j = 0; j < s.length; j++)
          s[j] = PokerApp.Ȅ().ʋ().Ǩ().B(E.K("pix/avatars/default.png"));
      }
      int j = this.w % s.length;
      this.ª = s[j];
    }
    if (i != 0)
      this.W = f();
  }

  private void F(Graphics2D paramGraphics2D)
  {
    if (this.ª == null)
      a();
    Rectangle localRectangle = b();
    S localS = this.U.ʴ[this.w];
    boolean bool = this.À;
    int i = (this.w >= 3) && (this.w <= 7) ? 0 : 1;
    int j = localRectangle.x;
    int k = localRectangle.y;
    int m = 80;
    int n = 60;
    int i1 = 130;
    int i2 = (i1 - m) / 2;
    int i3 = 25;
    int i4 = 25;
    int i5 = i != 0 ? k - i3 + 1 : k + n + 1;
    int i6 = i != 0 ? k + n + i3 + 1 : k - i4 + 1;
    int i7 = i != 0 ? i5 - i3 + 3 : i5 + i3 + 1;
    if (i != 0)
    {
      k += i3;
      i5 += i3;
      i7 += i3;
    }
    String str1 = localS.T();
    String str2 = localS.A();
    if (str2.length() > 0)
      str1 = str1 + " (" + str2 + ")";
    Object localObject = e();
    if (localObject == null)
      return;
    String str3 = localS.P();
    this.¤ = str3;
    int i8 = 0;
    if ((str3.length() > 2) && (!str3.equals(E.D("Action.Fold"))))
    {
      i8 = 1;
      localObject = str3;
    }
    paramGraphics2D.setFont(com.biotools.poker.F.J.ð);
    FontMetrics localFontMetrics = paramGraphics2D.getFontMetrics();
    Composite localComposite = paramGraphics2D.getComposite();
    paramGraphics2D.setColor(com.biotools.B.A.M);
    if (i8 != 0)
      paramGraphics2D.setColor(Color.YELLOW);
    int i9 = 7;
    paramGraphics2D.fillRoundRect(j + i9 - 5, i5 + 1, i1 - i9 - i9 + 10, i3, 5, 5);
    paramGraphics2D.setComposite(AlphaComposite.getInstance(3, 0.6F));
    paramGraphics2D.setColor(Color.BLACK);
    paramGraphics2D.setComposite(localComposite);
    float f = this.¥;
    if ((bool) && (f == 0.0F))
      f = 0.7F;
    if ((f == 0.0F) || (this.x))
      paramGraphics2D.setComposite(AlphaComposite.getInstance(3, 0.75F));
    if (f > 0.0F)
    {
      if (f > 1.0F)
      {
        System.err.println("trying to display an alpha of " + f);
        f = 1.0F;
      }
      paramGraphics2D.setComposite(AlphaComposite.getInstance(3, f));
      if (this.x)
      {
        paramGraphics2D.setColor(Color.GREEN);
        paramGraphics2D.fillRoundRect(j, k + 2, i1, n, 10, 10);
      }
      else
      {
        paramGraphics2D.setColor(Color.YELLOW);
        paramGraphics2D.fillRoundRect(j, k + 2, i1, n, 10, 10);
      }
    }
    paramGraphics2D.setComposite(localComposite);
    paramGraphics2D.drawImage(this.ª, j + i2, k + 2, null);
    com.biotools.poker.A.A(paramGraphics2D);
    paramGraphics2D.setFont(com.biotools.poker.F.J.ð);
    localFontMetrics = paramGraphics2D.getFontMetrics();
    paramGraphics2D.setColor(com.biotools.B.A.D);
    if (i8 != 0)
      paramGraphics2D.setColor(Color.BLACK);
    paramGraphics2D.drawString((String)localObject, j + i1 / 2 - localFontMetrics.stringWidth((String)localObject) / 2, i5 + 18);
    com.biotools.poker.A.B(paramGraphics2D);
    paramGraphics2D.setComposite(localComposite);
  }

  private void D(Graphics2D paramGraphics2D)
  {
    Rectangle localRectangle = b();
    S localS = this.U.ʴ[this.w];
    boolean bool = this.À;
    int i = localRectangle.x;
    int j = localRectangle.y;
    float f = this.¥;
    if ((bool) && (f == 0.0F))
      f = 0.7F;
    Composite localComposite = paramGraphics2D.getComposite();
    if ((f == 0.0F) || (this.x))
      paramGraphics2D.setComposite(AlphaComposite.getInstance(3, 0.75F));
    paramGraphics2D.drawImage(µ, i, j, null);
    if (f > 0.0F)
    {
      if (f > 1.0F)
      {
        System.err.println("trying to display an alpha of " + f);
        f = 1.0F;
      }
      paramGraphics2D.setComposite(AlphaComposite.getInstance(3, f));
      if (this.x)
        paramGraphics2D.drawImage(v, i - 20, j - 20, null);
      else
        paramGraphics2D.drawImage(u, i, j, null);
    }
    paramGraphics2D.setComposite(localComposite);
    if (this.t != null)
      paramGraphics2D.drawImage(this.t, i + 80, j + 30, null);
    if (localS != null)
    {
      String str1 = e();
      if (str1 == null)
        return;
      com.biotools.poker.A.A(paramGraphics2D);
      paramGraphics2D.setFont(new Font("Arial", 1, str1.length() < 12 ? 14 : 12));
      FontMetrics localFontMetrics = paramGraphics2D.getFontMetrics();
      paramGraphics2D.setColor(Color.white);
      paramGraphics2D.drawString(str1, i + 50 - localFontMetrics.stringWidth(str1) / 2, j + 15);
      com.biotools.poker.A.B(paramGraphics2D);
      String str2 = localS.P();
      this.¤ = str2;
      if (str2.length() > 2)
      {
        paramGraphics2D.setFont(new Font("Georgia", 0, 12));
        localFontMetrics = paramGraphics2D.getFontMetrics();
        paramGraphics2D.setColor(Color.yellow);
        paramGraphics2D.drawString(str2, i + 50 - localFontMetrics.stringWidth(str2) / 2, j + 43);
      }
      String str3 = localS.T();
      if (str3 != null)
      {
        paramGraphics2D.setFont(new Font("Georgia", 0, 12));
        localFontMetrics = paramGraphics2D.getFontMetrics();
        paramGraphics2D.setColor(Color.green);
        int k = i + 50 - localFontMetrics.stringWidth(str3) / 2;
        paramGraphics2D.drawString(str3, k, j + 29);
      }
    }
  }

  private boolean _()
  {
    return (E.£().getBoolean("USE_TO_ACT_ANIMATION", true)) && (!M.R);
  }

  private Rectangle b()
  {
    if (this.º != null)
      return this.º;
    return this.W;
  }

  public boolean A(Rectangle paramRectangle)
  {
    if (this.W == null)
      return false;
    if (this.º != null)
      return this.º.intersects(paramRectangle);
    boolean bool = paramRectangle.intersects(this.W);
    return bool;
  }

  private String e()
  {
    if (this.U.ʴ[this.w] != null)
    {
      String str = this.U.ʴ[this.w].S();
      if (D.M.T == null)
        return str;
      if (D.M.R <= 0.5F)
        return str;
      return D.M.T[this.w];
    }
    return "";
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.G
 * JD-Core Version:    0.6.2
 */