package com.biotools.poker.O;

import com.biotools.poker.A;
import com.biotools.poker.Q.D;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;

public abstract class N extends I
{
  private String Å = null;

  protected abstract void H(Graphics2D paramGraphics2D);

  protected abstract String n();

  protected abstract Point C(int paramInt);

  public void B(M paramM)
  {
    super.B(paramM);
    Point localPoint = C(0);
    this.W = new Rectangle(localPoint.x, localPoint.y, 10, 10);
  }

  public void A(M paramM)
  {
    String str = n();
    if ((str == null) && (this.Å == null))
      return;
    if (str == null)
    {
      this.Å = null;
      paramM.A(this);
      return;
    }
    if (str.equals(this.Å))
      return;
    paramM.A(this);
  }

  protected boolean m()
  {
    return false;
  }

  protected void B(Graphics2D paramGraphics2D)
  {
    String str = n();
    if (str == null)
      return;
    if ((this.U.ǆ().getTotalPotSize() <= 0.0D) && (!m()))
      return;
    if (l())
      A.A(paramGraphics2D);
    H(paramGraphics2D);
    FontMetrics localFontMetrics = paramGraphics2D.getFontMetrics();
    int i = localFontMetrics.stringWidth(str);
    Point localPoint = A(i, localFontMetrics);
    this.W = new Rectangle(localPoint.x, localPoint.y - localFontMetrics.getAscent() - 1, i + 1, localFontMetrics.getHeight() + 1);
    A(paramGraphics2D, this.W, i);
    if (k())
    {
      paramGraphics2D.setColor(Color.black);
      paramGraphics2D.drawString(str, localPoint.x, localPoint.y);
    }
    paramGraphics2D.setColor(o());
    paramGraphics2D.drawString(str, localPoint.x + 1, localPoint.y - 1);
    this.Å = str;
    if (l())
      A.B(paramGraphics2D);
  }

  protected void A(Graphics2D paramGraphics2D, Rectangle paramRectangle, int paramInt)
  {
  }

  protected Point A(int paramInt, FontMetrics paramFontMetrics)
  {
    return C(paramInt);
  }

  protected boolean l()
  {
    return false;
  }

  protected Color o()
  {
    return Color.YELLOW;
  }

  protected boolean k()
  {
    return true;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.N
 * JD-Core Version:    0.6.2
 */