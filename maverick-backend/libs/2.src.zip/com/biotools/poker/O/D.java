package com.biotools.poker.O;

import com.biotools.poker.A;
import com.biotools.poker.E;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.io.PrintStream;

public class D
  implements P
{
  public static D M = new D();
  public float R;
  public float O;
  public boolean P;
  public String[] T;
  A N;
  int Q;
  long L;
  boolean S;

  public void B(M paramM)
  {
    this.N = paramM.C();
    this.S = false;
  }

  public boolean K()
  {
    return this.S;
  }

  public void D(String[] paramArrayOfString)
  {
    this.T = paramArrayOfString;
    this.N.w(E.D("RotationAnimator.ShufflingSeats"));
    this.P = true;
    B(5);
    this.N.w(null);
    this.N.ǋ();
  }

  public void A(int paramInt)
  {
    this.T = null;
    this.P = false;
    this.N.w(E.D("RotationAnimator.RotatingTable"));
    B(paramInt);
  }

  public void M()
  {
    this.T = null;
  }

  private void B(int paramInt)
  {
    System.out.println(">>>>>>>>>> asked to rotate: " + paramInt);
    this.Q = paramInt;
    this.L = System.currentTimeMillis();
    this.S = true;
    this.R = 0.0F;
    this.O = 0.0F;
    J();
  }

  public void A(M paramM)
  {
    if (!K())
      return;
    long l = System.currentTimeMillis() - this.L;
    this.O = this.R;
    this.R = ((float)l / (500 * this.Q));
    if (this.R > 1.0F)
    {
      L();
      return;
    }
  }

  public void A()
  {
  }

  public boolean A(Rectangle paramRectangle)
  {
    return false;
  }

  public void A(Graphics2D paramGraphics2D)
  {
  }

  public J B(Rectangle paramRectangle)
  {
    return null;
  }

  public synchronized void L()
  {
    this.S = false;
    notifyAll();
  }

  public synchronized void J()
  {
    while (this.S)
      try
      {
        wait();
      }
      catch (InterruptedException localInterruptedException)
      {
      }
  }

  public void B()
  {
    L();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.D
 * JD-Core Version:    0.6.2
 */