package com.biotools.poker.O;

import com.biotools.poker.A;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Point;

public class W extends N
{
  protected void H(Graphics2D paramGraphics2D)
  {
    paramGraphics2D.setFont(new Font("Arial", 1, 20));
  }

  protected Point C(int paramInt)
  {
    int i = this.U.Ǩ().H();
    int j = this.U.ʳ ? 180 : 270;
    int k = (i - paramInt) / 2;
    return new Point(k, j);
  }

  protected String n()
  {
    return this.U.ʼ;
  }

  protected boolean l()
  {
    return true;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.W
 * JD-Core Version:    0.6.2
 */