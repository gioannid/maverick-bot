package com.biotools.poker.O;

import java.awt.Point;

class Y extends V
{
  Point H;
  Point G;
  Point F;
  Point E;

  Y(Point paramPoint1, Point paramPoint2, Point paramPoint3, Point paramPoint4)
  {
    this.H = paramPoint1;
    this.G = paramPoint2;
    this.F = paramPoint3;
    this.E = paramPoint4;
  }

  Point A(double paramDouble)
  {
    double d1 = 1.0D - paramDouble;
    double d2 = d1 * d1 * d1;
    double d3 = 3.0D * paramDouble * d1 * d1;
    double d4 = 3.0D * paramDouble * paramDouble * d1;
    double d5 = paramDouble * paramDouble * paramDouble;
    double d6 = this.H.x * d2 + this.G.x * d3 + this.F.x * d4 + this.E.x * d5;
    double d7 = this.H.y * d2 + this.G.y * d3 + this.F.y * d4 + this.E.y * d5;
    return new Point((int)d6, (int)d7);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.Y
 * JD-Core Version:    0.6.2
 */