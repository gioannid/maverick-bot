package com.biotools.poker.O;

import com.biotools.poker.A;
import com.biotools.poker.PokerApp;
import java.awt.Rectangle;

public class J
{
  Rectangle A;
  boolean C;
  private static int B = -1;
  private static int D = -1;

  public static J A(M paramM)
  {
    Rectangle localRectangle = new Rectangle(0, 0, paramM.J, paramM.H);
    return new J(localRectangle, false);
  }

  public J(Rectangle paramRectangle, boolean paramBoolean)
  {
    this.A = paramRectangle;
    this.C = paramBoolean;
  }

  private void A(Rectangle paramRectangle)
  {
    if (B <= 100)
    {
      B = PokerApp.Ȅ().ʋ().getWidth();
      D = PokerApp.Ȅ().ʋ().getHeight();
    }
    if (B <= 100)
      return;
    if ((paramRectangle.x < 0) || (paramRectangle.y < 0) || (paramRectangle.x + paramRectangle.width > B) || (paramRectangle.y + paramRectangle.height > D))
      throw new Error("insane damage");
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.J
 * JD-Core Version:    0.6.2
 */