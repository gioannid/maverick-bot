package com.biotools.poker.O;

import com.biotools.B.A;
import java.awt.AlphaComposite;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class _ extends I
{
  private boolean â = false;
  private boolean á = false;
  private Rectangle ä = null;
  private float ã = 0.8F;

  protected void B(Graphics2D paramGraphics2D)
  {
    if (!this.á)
      return;
    Composite localComposite = paramGraphics2D.getComposite();
    paramGraphics2D.setColor(A.M);
    paramGraphics2D.setComposite(AlphaComposite.getInstance(3, 0.6F));
    paramGraphics2D.fillRoundRect(this.ä.x + 1, this.ä.y + 1, this.ä.width - 2, this.ä.height - 2, 10, 10);
    paramGraphics2D.setComposite(localComposite);
  }

  public void A(M paramM)
  {
    if (this.â)
    {
      this.â = false;
      paramM.A(this);
    }
  }

  public J B(Rectangle paramRectangle)
  {
    if (this.á)
      return new J(this.W, false);
    return null;
  }

  public boolean ¤()
  {
    return this.á;
  }

  public void E(boolean paramBoolean)
  {
    this.â = (this.á ^ paramBoolean);
    this.á = paramBoolean;
  }

  public Rectangle £()
  {
    return this.ä;
  }

  public void D(Rectangle paramRectangle)
  {
    this.ä = paramRectangle;
    C(paramRectangle);
  }

  public float ¥()
  {
    return this.ã;
  }

  public void A(float paramFloat)
  {
    this.ã = paramFloat;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O._
 * JD-Core Version:    0.6.2
 */