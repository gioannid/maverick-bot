package com.biotools.poker.O;

import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import com.biotools.poker.S.E.K;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;

public class C
  implements P
{
  public static C J;
  public static String G = "pix/bigtables/";
  Image B;
  boolean A = false;
  private String[] C = { "Wood", "Wood" };
  private String[] F = { "Green", "Red" };
  private String[] I = { "Red", "Red" };
  private String[] H = { "felt-", "feltNL-" };
  private int D = 0;
  private M E;
  private Image K;

  public void B(M paramM)
  {
    this.B = paramM.A(paramM.J, paramM.H);
    this.E = paramM;
    this.K = null;
    D();
    G();
    J = this;
  }

  public void I()
  {
    if (this.K == null)
      return;
    this.K = null;
    F();
  }

  public void A(K paramK)
  {
    String str = E.Ð() ? paramK.i() : paramK.Y();
    if (str == null)
    {
      if (this.K == null)
        return;
      this.K = null;
      F();
      return;
    }
    new C.1(this, str).run();
  }

  private void G()
  {
    String[] arrayOfString = { "carpet-" + this.C[this.D] + ".png", "table-" + this.I[this.D] + ".png", this.H[this.D] + this.F[this.D] + ".png" };
    Graphics localGraphics = this.B.getGraphics();
    for (int k = 0; k < arrayOfString.length; k++)
    {
      File localFile = E.K(G + arrayOfString[k]);
      int i = 0;
      int j = 0;
      BufferedImage localBufferedImage = this.E.A(localFile);
      localGraphics.drawImage(localBufferedImage, i, j, null);
    }
    if (this.K != null)
      localGraphics.drawImage(this.K, 0, 0, null);
    localGraphics.dispose();
  }

  private BufferedImage C()
  {
    return null;
  }

  public void A(M paramM)
  {
    if (!this.A)
      return;
    G();
    paramM.A(J.A(paramM));
    this.A = false;
  }

  public void A()
  {
  }

  public boolean A(Rectangle paramRectangle)
  {
    return false;
  }

  public void A(Graphics2D paramGraphics2D)
  {
  }

  public String E()
  {
    return this.F[this.D] + this.C[this.D] + this.I[this.D];
  }

  public void H()
  {
    String str = this.F[0] + "-" + this.F[1] + "-" + this.I[0] + "-" + this.I[1] + "-" + this.C[0] + "-" + this.C[1] + "-" + this.D;
    E.£().put("TABLE_IMAGE_OPTIONS", str);
  }

  public void D()
  {
    String str = E.£().get("TABLE_IMAGE_OPTIONS", "Green-Red-Red-Red-Wood-Wood-0");
    String[] arrayOfString = str.split("-");
    this.F[0] = arrayOfString[0];
    this.F[1] = arrayOfString[1];
    this.I[0] = arrayOfString[2];
    this.I[1] = arrayOfString[3];
    this.C[0] = arrayOfString[4];
    this.C[1] = arrayOfString[5];
    this.D = Integer.parseInt(arrayOfString[6]);
  }

  public void A(boolean paramBoolean)
  {
    int i = this.D;
    this.D = (paramBoolean ? 1 : 0);
    if (i != this.D)
    {
      F();
      H();
    }
  }

  public void C(String[] paramArrayOfString)
  {
    this.C = paramArrayOfString;
  }

  public void B(String[] paramArrayOfString)
  {
    this.F = paramArrayOfString;
  }

  public void A(String[] paramArrayOfString)
  {
    this.I = paramArrayOfString;
  }

  public void F()
  {
    this.A = true;
  }

  public boolean A(String paramString1, int paramInt, String paramString2)
  {
    String[] arrayOfString = (String[])null;
    if (paramString1.equals("carpet"))
      arrayOfString = this.C;
    if (paramString1.equals("felt"))
      arrayOfString = this.F;
    if (paramString1.equals("table"))
      arrayOfString = this.I;
    return arrayOfString[paramInt].equals(paramString2);
  }

  public J B(Rectangle paramRectangle)
  {
    return null;
  }

  public void B()
  {
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.C
 * JD-Core Version:    0.6.2
 */