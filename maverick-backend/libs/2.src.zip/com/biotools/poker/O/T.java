package com.biotools.poker.O;

import java.awt.Point;

class T extends V
{
  Point D;
  Point C;
  Point B;

  T(Point paramPoint1, Point paramPoint2, Point paramPoint3)
  {
    this.D = paramPoint1;
    this.C = paramPoint2;
    this.B = paramPoint3;
  }

  Point A(double paramDouble)
  {
    double d1 = 1.0D - paramDouble;
    double d2 = d1 * d1;
    double d3 = 2.0D * paramDouble * d1;
    double d4 = paramDouble * paramDouble;
    double d5 = this.D.x * d2 + this.C.x * d3 + this.B.x * d4;
    double d6 = this.D.y * d2 + this.C.y * d3 + this.B.y * d4;
    return new Point((int)d5, (int)d6);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.T
 * JD-Core Version:    0.6.2
 */