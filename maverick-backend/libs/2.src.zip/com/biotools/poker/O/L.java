package com.biotools.poker.O;

import com.biotools.meerkat.Action;
import com.biotools.poker.A;
import com.biotools.poker.E;
import com.biotools.poker.Q.D;
import com.biotools.poker.Q.K;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Point;

public class L extends N
{
  protected void H(Graphics2D paramGraphics2D)
  {
    paramGraphics2D.setFont(new Font("Arial", 1, 12));
  }

  protected Point C(int paramInt)
  {
    int i = this.U.ʳ ? 232 : 310;
    int j = this.U.ʳ ? 103 : 83;
    i += 14;
    return new Point(j, i);
  }

  protected String n()
  {
    if (!this.U.Ǡ().R())
      return null;
    double d = this.U.ǆ().getRake();
    if (d == 0.0D)
      return null;
    Object[] arrayOfObject = { Action.formatCash(d) };
    String str = E.A("PotText.RakePattern", arrayOfObject);
    return str;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.L
 * JD-Core Version:    0.6.2
 */