package com.biotools.poker.O;

import java.awt.Point;

public abstract class V
{
  private static V A = A(arrayOfPoint);

  static
  {
    Point[] arrayOfPoint = { new Point(0, 0), new Point(0, 10000), new Point(0, 10000), new Point(0, 10000) };
  }

  public static float B(float paramFloat)
  {
    return A.A(paramFloat).y / 10000.0F;
  }

  public static float A(float paramFloat)
  {
    return 1.0F - B(1.0F - paramFloat);
  }

  public static V A(Point[] paramArrayOfPoint)
  {
    if (paramArrayOfPoint.length == 2)
      return new K(paramArrayOfPoint[0], paramArrayOfPoint[1]);
    if (paramArrayOfPoint.length == 3)
      return new T(paramArrayOfPoint[0], paramArrayOfPoint[1], paramArrayOfPoint[2]);
    if (paramArrayOfPoint.length == 4)
      return new Y(paramArrayOfPoint[0], paramArrayOfPoint[1], paramArrayOfPoint[2], paramArrayOfPoint[3]);
    if (paramArrayOfPoint.length == 5)
      return new T(paramArrayOfPoint[0], paramArrayOfPoint[2], paramArrayOfPoint[4]);
    if (paramArrayOfPoint.length == 6)
      return new Y(paramArrayOfPoint[0], paramArrayOfPoint[2], paramArrayOfPoint[3], paramArrayOfPoint[5]);
    return null;
  }

  abstract Point A(double paramDouble);
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.O.V
 * JD-Core Version:    0.6.2
 */