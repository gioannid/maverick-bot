package com.biotools.poker.L;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.poker.E;

public class B extends C
{
  private int M;

  public B(Hand paramHand, Hand[] paramArrayOfHand)
  {
    A(paramHand, paramArrayOfHand);
  }

  public void D()
  {
    this.G = false;
    this.E = this.M;
    boolean[][] arrayOfBoolean = new boolean[this.L][2];
    for (int i = 0; i < this.K.length; i++)
    {
      arrayOfBoolean[i][0] = (this.K[i].getCard(1).valid() ? 0 : 1);
      arrayOfBoolean[i][1] = (this.K[i].getCard(2).valid() ? 0 : 1);
    }
    i = 0;
    for (int j = 0; j < this.K.length; j++)
    {
      if (arrayOfBoolean[j][0] != 0)
        i++;
      if (arrayOfBoolean[j][1] != 0)
        i++;
    }
    j = 5 - this.J.size();
    int k = 0;
    Deck localDeck1 = new Deck();
    Deck localDeck2 = new Deck();
    localDeck1.extractHand(this.J);
    for (int m = 0; m < this.K.length; m++)
      localDeck1.extractHand(this.K[m]);
    this.B = null;
    m = 0;
    boolean bool;
    while ((k++ < this.M) && (!bool))
    {
      if (k % 10000 == 0)
        bool = G();
      localDeck2.copy(localDeck1);
      for (int n = 0; n < j; n++)
        this.J.addCard(localDeck2.dealCard());
      if (i > 0)
        for (n = 0; n < this.K.length; n++)
        {
          if (arrayOfBoolean[n][0] != 0)
            this.K[n].setCard(1, localDeck2.dealCard());
          if (arrayOfBoolean[n][1] != 0)
            this.K[n].setCard(2, localDeck2.dealCard());
        }
      H();
      for (n = 0; n < j; n++)
        this.J.removeCard();
    }
    this.B = null;
    this.G = true;
  }

  public String E()
  {
    return E.D("ShowdownCalculatorPanel.Trials");
  }

  protected final int A(Hand paramHand)
  {
    return HandEvaluator.rankHand(paramHand.getCard(1), paramHand.getCard(2), this.J);
  }

  public void G(int paramInt)
  {
    this.M = paramInt;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.L.B
 * JD-Core Version:    0.6.2
 */