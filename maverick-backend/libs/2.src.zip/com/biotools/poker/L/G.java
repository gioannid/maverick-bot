package com.biotools.poker.L;

import com.biotools.B.L;
import com.biotools.B.R;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.Hand;
import com.biotools.poker.PokerApp;
import com.biotools.poker.Q.D;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;

public class G extends JPanel
  implements I
{
  private static final Integer[] B = { new Integer(2), new Integer(3), new Integer(4), new Integer(5), new Integer(6), new Integer(7), new Integer(8), new Integer(9), new Integer(10) };
  private static final String[] G = { com.biotools.poker.E.D("ShowdownCalculatorPanel.Percentages"), com.biotools.poker.E.D("ShowdownCalculatorPanel.Totals") };
  private static final String[] D = { "100000", "500000", "1000000", "5000000" };
  private JButton A = new JButton(com.biotools.poker.E.D("ShowdownCalculatorPanel.EnumerateButton"));
  private JButton H = new JButton(com.biotools.poker.E.D("ShowdownCalculatorPanel.SimulateButton"));
  private JButton N = new JButton(new ImageIcon(com.biotools.poker.E.K("pix/Stop24.gif").getPath()));
  private JProgressBar O = new JProgressBar();
  private JComboBox K = new JComboBox(B);
  private JComboBox I = new JComboBox(G);
  private JComboBox R = new JComboBox(D);
  private volatile boolean Q = false;
  private volatile C E;
  private K[] J = new K[5];
  private J[] C = new J[10];
  private Deck P = new Deck();
  private PokerApp L;
  private JFrame M;
  private JMenuBar F;

  public G(PokerApp paramPokerApp)
  {
    this.L = paramPokerApp;
    JPanel localJPanel1 = new JPanel(new B.A.A.B());
    localJPanel1.setBorder(BorderFactory.createEmptyBorder(5, 4, 4, 4));
    localJPanel1.add("tab", new JLabel(com.biotools.poker.E.D("ShowdownCalculatorPanel.NumberOfHandsTitle")));
    localJPanel1.add("tab", this.K);
    localJPanel1.add("hfill", Box.createHorizontalGlue());
    localJPanel1.add("right", A());
    JPanel localJPanel2 = new JPanel(new BorderLayout());
    localJPanel2.add(localJPanel1, "North");
    localJPanel2.add(G(), "South");
    JPanel localJPanel3 = new JPanel(new BorderLayout(10, 10));
    localJPanel3.add(Q(), "West");
    localJPanel3.add(localJPanel2, "Center");
    JPanel localJPanel4 = new JPanel(new BorderLayout(5, 5));
    localJPanel4.add(localJPanel3, "North");
    localJPanel4.add(P(), "Center");
    setLayout(new BorderLayout(4, 4));
    setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    add(localJPanel4, "Center");
    add(M(), "South");
  }

  private JPanel M()
  {
    this.O.setStringPainted(true);
    this.O.setMaximum(2147483647);
    this.N.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        if (G.this.E != null)
          G.this.E.F();
      }
    });
    this.N.setMargin(new Insets(0, 0, 0, 0));
    this.N.setEnabled(false);
    this.N.setBorder(BorderFactory.createEmptyBorder());
    this.N.setBorderPainted(false);
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(this.O);
    localJPanel.add(Box.createHorizontalStrut(6));
    localJPanel.add(this.N);
    return localJPanel;
  }

  private JPanel W()
  {
    this.R.setSelectedIndex(1);
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(this.A);
    localJPanel.add(Box.createHorizontalStrut(8));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(new JLabel(" " + com.biotools.poker.E.D("ShowdownCalculatorPanel.Or") + " "));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(Box.createHorizontalStrut(8));
    localJPanel.add(this.H);
    localJPanel.add(Box.createHorizontalStrut(6));
    localJPanel.add(this.R);
    localJPanel.add(new JLabel(com.biotools.poker.E.D("ShowdownCalculatorPanel.Trials")));
    return localJPanel;
  }

  private JPanel Q()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("ShowdownCalculatorPanel.BoardTitle")), BorderFactory.createEmptyBorder(4, 4, 4, 4)));
    for (int i = 0; i < 5; i++)
    {
      this.J[i] = new K(this.P, E());
      this.J[i].A(this);
      localJPanel.add(this.J[i]);
      localJPanel.add(Box.createHorizontalStrut(2));
    }
    localJPanel.add(Box.createHorizontalGlue());
    return localJPanel;
  }

  private JPanel P()
  {
    JPanel localJPanel = new JPanel(new GridLayout(2, 5, 8, 6));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(4, 2, 2, 2));
    for (int i = 0; i < 10; i++)
    {
      this.C[i] = new J(this.P, E());
      this.C[i].A(this);
      localJPanel.add(this.C[i]);
      this.C[i].B(i < 2);
      this.C[i].C();
    }
    return localJPanel;
  }

  private JButton A()
  {
    JButton localJButton = PokerApp.ɩ();
    localJButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        G.this.C();
      }
    });
    return localJButton;
  }

  public JPanel G()
  {
    this.A.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        G.this.T();
      }
    });
    this.A.setToolTipText(com.biotools.poker.E.D("ShowdownCalculatorPanel.ComputExact"));
    this.H.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        G.this.S();
      }
    });
    this.H.setToolTipText(com.biotools.poker.E.D("ShowdownCalculatorPanel.MonteCarlo"));
    this.K.addItemListener(new ItemListener()
    {
      public void itemStateChanged(ItemEvent paramAnonymousItemEvent)
      {
        G.this.X();
      }
    });
    this.I.addItemListener(new ItemListener()
    {
      public void itemStateChanged(ItemEvent paramAnonymousItemEvent)
      {
        G.this.F();
      }
    });
    JPanel localJPanel = new JPanel(new BorderLayout(5, 5));
    localJPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(), BorderFactory.createEmptyBorder(14, 14, 14, 14)));
    localJPanel.add(W(), "Center");
    return localJPanel;
  }

  private void X()
  {
    int i = ((Integer)this.K.getSelectedItem()).intValue();
    for (int j = 0; j < 10; j++)
    {
      this.C[j].B(j < i);
      this.C[j].C();
    }
  }

  public void A(int paramInt)
  {
    this.K.setSelectedItem(new Integer(paramInt));
  }

  private void F()
  {
    int i = this.I.getSelectedIndex();
    for (int j = 0; j < 10; j++)
      this.C[j].A(i == 0);
  }

  private Hand I()
  {
    Hand localHand = new Hand();
    for (int i = 0; i < 5; i++)
      if (this.J[i].E() != null)
        localHand.addCard(this.J[i].E());
    return localHand;
  }

  private Hand A(K paramK1, K paramK2)
  {
    Hand localHand = new Hand();
    Card localCard1 = paramK1.E();
    Card localCard2 = paramK2.E();
    if (localCard1 == null)
      localCard1 = new Card();
    if (localCard2 == null)
      localCard2 = new Card();
    localHand.addCard(localCard1);
    localHand.addCard(localCard2);
    return localHand;
  }

  private Hand[] V()
  {
    int i = 0;
    for (int j = 0; j < 10; j++)
      if (this.C[j].B())
        i++;
    Hand[] arrayOfHand = new Hand[i];
    int k = 0;
    for (int m = 0; m < 10; m++)
      if (this.C[m].B())
        arrayOfHand[(k++)] = A(this.C[m].A(), this.C[m].D());
    return arrayOfHand;
  }

  private synchronized void R()
  {
    this.A.setEnabled(false);
    this.H.setEnabled(false);
    this.N.setEnabled(true);
    for (int i = 0; i < 10; i++)
      this.C[i].C(false);
    for (i = 0; i < 5; i++)
      this.J[i].A(false);
    this.K.setEnabled(false);
    this.F.setEnabled(false);
  }

  private void B()
  {
    while (this.Q)
      L.C(5L);
    this.A.setEnabled(true);
    this.H.setEnabled(true);
    this.N.setEnabled(false);
    this.K.setEnabled(true);
    this.O.setValue(0);
    for (int i = 0; i < 10; i++)
      this.C[i].C(true);
    for (i = 0; i < 5; i++)
      this.J[i].A(true);
    this.E = null;
    this.F.setEnabled(true);
  }

  private void T()
  {
    com.biotools.poker.E.q();
    this.E = new E(I(), V());
    O();
  }

  private void S()
  {
    com.biotools.poker.E.q();
    int i = Integer.parseInt((String)this.R.getSelectedItem());
    B localB = new B(I(), V());
    localB.G(i);
    this.E = localB;
    O();
  }

  private void O()
  {
    Thread localThread = new Thread(new G.7(this), "Showdown Calculator");
    localThread.start();
  }

  private void D()
  {
    if (this.E == null)
      return;
    this.Q = true;
    G.8 local8 = new G.8(this);
    SwingUtilities.invokeLater(local8);
  }

  private void U()
  {
    if (this.E != null)
    {
      this.O.setStringPainted(true);
      String str;
      if (this.E.I() < 0L)
      {
        str = com.biotools.poker.E.D("ShowdownCalculatorPanel.TooManyCombinations");
        this.O.setString(str);
        this.O.setValue(0);
      }
      else
      {
        str = this.E.A() + " / " + this.E.I() + " " + this.E.E();
        this.O.setString(str);
        this.O.setValue(this.E.C());
      }
      int i = 0;
      for (int j = 0; j < 10; j++)
        if (this.C[j].B())
        {
          this.C[j].A(this.E.B(i), this.E.E(i), this.E.D(i));
          i++;
        }
    }
    this.Q = false;
  }

  public void C()
  {
    R localR = R.B(com.biotools.poker.E.D("ShowdownCalculatorPanel.Help"));
    localR.A("calculator.html");
  }

  public void A(K paramK)
  {
    for (int i = 0; i < 10; i++)
      this.C[i].C();
  }

  public void A(Hand paramHand)
  {
    for (int i = 0; i < 5; i++)
      if (i < paramHand.size())
        this.J[i].A(paramHand.getCard(i + 1));
      else
        this.J[i].A(null);
  }

  public void A(int paramInt, Hand paramHand)
  {
    if ((paramHand != null) && (paramHand.getCard(1).valid()) && (paramHand.getCard(2).valid()))
    {
      this.C[paramInt].A().A(paramHand.getCard(1));
      this.C[paramInt].D().A(paramHand.getCard(2));
      return;
    }
    this.C[paramInt].A().A(null);
    this.C[paramInt].D().A(null);
  }

  public void N()
  {
    for (int i = 0; i < 5; i++)
      this.J[i].A(null);
    for (i = 0; i < 10; i++)
    {
      this.C[i].A().A(null);
      this.C[i].D().A(null);
    }
  }

  public void H()
  {
    D localD = this.L.ɞ();
    N();
    A(localD.getNumActivePlayers());
    A(localD.getBoard());
    int i = 0;
    Hand localHand = this.L.ʐ().N(PokerApp.χ);
    A(i++, localHand);
  }

  public void J()
  {
    D localD = this.L.ɞ();
    N();
    A(localD.getNumActivePlayers());
    A(localD.getBoard());
    int i = 0;
    for (int j = 0; j < localD.getNumSeats(); j++)
      if ((localD.isActive(j)) || (j == PokerApp.χ))
      {
        Hand localHand = this.L.ʐ().N(j);
        A(i++, localHand);
      }
  }

  public void A(com.biotools.poker.R.E paramE)
  {
    N();
    A(paramE.b());
    A(paramE.H());
    int i = 0;
    for (int j = 0; j < paramE.c(); j++)
      if (paramE.G(j))
        A(i++, paramE.O(j));
  }

  private JFrame E()
  {
    if (this.M == null)
      K();
    return this.M;
  }

  private void K()
  {
    this.M = new JFrame(com.biotools.poker.E.D("ShowdownCalculatorPanel.ShowdownCalculator"));
    this.M.setResizable(false);
    this.M.setIconImage(com.biotools.poker.E.¢);
    this.M.getContentPane().add(this);
    this.F = new H(this);
    this.M.setJMenuBar(this.F);
    com.biotools.poker.E.A("SDC_WINDOW", this.M);
    this.M.setSize(700, 525);
    this.M.setDefaultCloseOperation(1);
  }

  public void L()
  {
    E().setVisible(true);
  }

  public void Y()
  {
    if (this.M != null)
      this.M.setVisible(false);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.L.G
 * JD-Core Version:    0.6.2
 */