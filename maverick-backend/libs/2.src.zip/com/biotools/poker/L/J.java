package com.biotools.poker.L;

import com.biotools.A.b;
import com.biotools.meerkat.Deck;
import com.biotools.poker.E;
import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class J extends JPanel
{
  private K H;
  private K G;
  private JLabel F = new JLabel("", 0);
  private boolean I = true;
  private boolean A = true;
  private boolean B;
  private long E;
  private long D;
  private long C;

  public J(Deck paramDeck, JFrame paramJFrame)
  {
    this.H = new K(paramDeck, paramJFrame);
    this.G = new K(paramDeck, paramJFrame);
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(this.H);
    localJPanel.add(Box.createHorizontalStrut(2));
    localJPanel.add(this.G);
    localJPanel.add(Box.createHorizontalGlue());
    setLayout(new BorderLayout(2, 2));
    add(localJPanel, "North");
    add(this.F, "Center");
    setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(), BorderFactory.createEmptyBorder(4, 4, 4, 4)));
    this.F.setEnabled(true);
    this.F.addMouseListener(new MouseAdapter()
    {
      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        J.this.A(!J.this.I);
      }
    });
  }

  public void A(I paramI)
  {
    this.H.A(paramI);
    this.G.A(paramI);
  }

  public void B(boolean paramBoolean)
  {
    this.B = paramBoolean;
    this.F.setVisible(this.B);
    this.H.setEnabled(this.B);
    this.G.setEnabled(this.B);
    if (!this.B)
    {
      this.H.B();
      this.G.B();
    }
    E();
  }

  public boolean B()
  {
    return this.B;
  }

  public K A()
  {
    return this.H;
  }

  public K D()
  {
    return this.G;
  }

  public void C()
  {
    A(0L, 0L, 0L);
  }

  public void A(long paramLong1, long paramLong2, long paramLong3)
  {
    this.E = paramLong1;
    this.D = paramLong2;
    this.C = paramLong3;
    E();
  }

  private void E()
  {
    double d1 = this.E + this.D + this.C;
    this.F.setVisible(d1 > 0.0D);
    if (d1 == 0.0D)
      return;
    double d2 = b.A(100.0D * this.E / d1, 1);
    double d3 = b.A(100.0D * this.D / d1, 1);
    double d4 = b.A(100.0D * this.C / d1, 1);
    if (this.I)
      this.F.setText("<html><table border=\"0\" ><tr> <td align=\"right\"><b>" + E.D("HandPanel.WonTitle") + "</b></td>" + " <td align=\"right\">" + d2 + "%</td></tr>" + "<tr> <td align=\"right\"><b>" + E.D("HandPanel.TiedTitle") + "</b></td>" + " <td align=\"right\">" + d3 + "%</td></tr>" + "<tr> <td align=\"right\"><b>" + E.D("HandPanel.LostTitle") + "</b></td>" + " <td align=\"right\">" + d4 + "%</td></tr>" + "</table></html>");
    else
      this.F.setText("<html><table border=\"0\" ><tr> <td align=\"right\"><b>" + E.D("HandPanel.WonTitle") + "</b></td>" + " <td align=\"right\">" + this.E + "</td></tr>" + "<tr> <td align=\"right\"><b>" + E.D("HandPanel.TiedTitle") + "</b></td>" + " <td align=\"right\">" + this.D + "</td></tr>" + "<tr> <td align=\"right\"><b>" + E.D("HandPanel.LostTitle") + "</b></td>" + " <td align=\"right\">" + this.C + "</td></tr>" + "</table></html>");
  }

  public void C(boolean paramBoolean)
  {
    this.A = paramBoolean;
    this.H.A(paramBoolean);
    this.G.A(paramBoolean);
  }

  public void A(boolean paramBoolean)
  {
    this.I = paramBoolean;
    E();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.L.J
 * JD-Core Version:    0.6.2
 */