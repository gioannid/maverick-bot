package com.biotools.poker.L;

import com.biotools.poker.E;
import com.biotools.poker.PokerApp;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

public class H extends JMenuBar
{
  private G D;
  JMenu C = new JMenu(E.D("ShowdownCalculatorMenu.File"));
  JMenu A = new JMenu(E.D("ShowdownCalculatorMenu.Options"));
  JMenu B = new JMenu(E.D("ShowdownCalculatorMenu.Help"));

  public H(G paramG)
  {
    this.D = paramG;
    add(F());
    add(C());
    add(D());
  }

  public void setEnabled(boolean paramBoolean)
  {
    this.C.setEnabled(paramBoolean);
    this.A.setEnabled(paramBoolean);
  }

  protected JMenu F()
  {
    this.C.add(E());
    this.C.add(G());
    return this.C;
  }

  protected JMenu C()
  {
    this.A.add(A());
    this.A.add(H());
    return this.A;
  }

  protected JMenu D()
  {
    this.B.add(B());
    return this.B;
  }

  protected KeyStroke A(int paramInt)
  {
    return KeyStroke.getKeyStroke(paramInt, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask());
  }

  protected JMenuItem E()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("ShowdownCalculatorMenu.Close"), 67);
    localJMenuItem.setAccelerator(A(87));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        H.this.D.Y();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem G()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("ShowdownCalculatorMenu.QuitProgram"), 81);
    localJMenuItem.setAccelerator(A(81));
    localJMenuItem.setToolTipText(E.D("ShowdownCalculatorMenu.QuitProgramDescription"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        PokerApp.Ȅ().ʠ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem B()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("ShowdownCalculatorMenu.Help"), 72);
    localJMenuItem.setAccelerator(A(47));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        H.this.D.C();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem A()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("ShowdownCalculatorMenu.LoadCurrentHand"), 76);
    localJMenuItem.setAccelerator(A(76));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        H.this.D.H();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem H()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("ShowdownCalculatorMenu.LoadCurrentHandAndOpponentHands"), 79);
    localJMenuItem.setAccelerator(A(79));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        H.this.D.J();
      }
    });
    return localJMenuItem;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.L.H
 * JD-Core Version:    0.6.2
 */