package com.biotools.poker.L;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import java.io.PrintStream;
import javax.swing.JOptionPane;

public class E extends C
{
  public E(Hand paramHand, Hand[] paramArrayOfHand)
  {
    A(paramHand, paramArrayOfHand);
  }

  public synchronized boolean G()
  {
    return this.G;
  }

  public synchronized void F()
  {
    this.G = true;
  }

  public synchronized long B(int paramInt)
  {
    return this.I[paramInt];
  }

  public synchronized long E(int paramInt)
  {
    return this.H[paramInt];
  }

  public synchronized long D(int paramInt)
  {
    return this.F[paramInt];
  }

  public void D()
  {
    System.err.println("HandEval = " + HandEvaluator.getHandEval().getClass());
    Deck localDeck = new Deck();
    localDeck.extractHand(this.J);
    this.B = null;
    int i = 0;
    for (int j = 0; j < this.K.length; j++)
    {
      localDeck.extractHand(this.K[j]);
      if (!this.K[j].getCard(1).valid())
        i++;
      if (!this.K[j].getCard(2).valid())
        i++;
    }
    j = 5 - this.J.size();
    A(j + " board cards to enumerate");
    A(i + " hole cards to enumerate");
    this.E = 1L;
    if (j > 0)
    {
      this.E = A(localDeck.cardsLeft(), j);
      A(this.E + " board combinations");
    }
    if ((i > 0) && (this.E > 0L))
    {
      int k = 0;
      for (int m = 0; m < this.K.length; m++)
      {
        int n = 0;
        if (!this.K[m].getCard(1).valid())
          n++;
        if (!this.K[m].getCard(2).valid())
          n++;
        if (n == 1)
        {
          this.E *= (localDeck.cardsLeft() - j - k);
          if (this.E < 0L)
            break;
        }
        else if (n == 2)
        {
          this.E *= A(localDeck.cardsLeft() - j - k, 2);
          if (this.E < 0L)
            break;
        }
        k += n;
      }
      A(this.E + " total combinations");
    }
    if (this.E < 0L)
    {
      JOptionPane.showMessageDialog(null, com.biotools.poker.E.D("ShowdownCalculatorPanel.TooManyCombinationsUseSimulator"));
      return;
    }
    A(localDeck, this.J, localDeck.getTopCardIndex(), i);
    A("finished " + this.A + " combinations");
    this.B = null;
  }

  private void A(String paramString)
  {
  }

  private void A(Deck paramDeck, Hand paramHand, int paramInt1, int paramInt2)
  {
    if (paramHand.size() == 5)
    {
      if (paramInt2 > 0)
        this.B = HandEvaluator.getRanks(paramHand);
      F(paramInt2);
    }
    else
    {
      for (int i = paramInt1; (i < 52) && (!G()); i++)
      {
        paramHand.addCard(paramDeck.getCard(i));
        A(paramDeck, paramHand, i + 1, paramInt2);
        paramHand.removeCard();
      }
    }
  }

  private void F(int paramInt)
  {
    if (paramInt > 0)
    {
      if (G())
        return;
      Deck localDeck = new Deck();
      localDeck.extractHand(this.J);
      for (int i = 0; i < this.K.length; i++)
        localDeck.extractHand(this.K[i]);
      for (i = 0; i < this.K.length; i++)
      {
        int j = this.K[i].getCardIndex(1);
        int k = this.K[i].getCardIndex(2);
        int m;
        if ((j < 0) && (k < 0))
        {
          for (m = localDeck.getTopCardIndex(); m < 52; m++)
          {
            this.K[i].setCard(1, localDeck.getCard(m));
            for (int n = m + 1; n < 52; n++)
            {
              this.K[i].setCard(2, localDeck.getCard(n));
              F(paramInt - 2);
            }
          }
          this.K[i].setCard(1, j);
          this.K[i].setCard(2, k);
          return;
        }
        if (j < 0)
        {
          for (m = localDeck.getTopCardIndex(); m < 52; m++)
          {
            this.K[i].setCard(1, localDeck.getCard(m));
            F(paramInt - 1);
          }
          this.K[i].setCard(1, j);
          return;
        }
        if (k < 0)
        {
          for (m = localDeck.getTopCardIndex(); m < 52; m++)
          {
            this.K[i].setCard(2, localDeck.getCard(m));
            F(paramInt - 1);
          }
          this.K[i].setCard(2, k);
          return;
        }
      }
    }
    else
    {
      H();
    }
  }

  public String E()
  {
    return com.biotools.poker.E.D("ShowdownCalculatorPanel.Combinations");
  }

  public static long B(Hand paramHand, Hand[] paramArrayOfHand)
  {
    Deck localDeck = new Deck();
    localDeck.extractHand(paramHand);
    int i = 0;
    for (int j = 0; j < paramArrayOfHand.length; j++)
    {
      localDeck.extractHand(paramArrayOfHand[j]);
      if (!paramArrayOfHand[j].getCard(1).valid())
        i++;
      if (!paramArrayOfHand[j].getCard(2).valid())
        i++;
    }
    j = 5 - paramHand.size();
    long l = 1L;
    if (j > 0)
    {
      l = A(localDeck.cardsLeft(), j);
      if (l < 0L)
        return -1L;
    }
    if (i > 0)
    {
      int k = 0;
      for (int m = 0; m < paramArrayOfHand.length; m++)
      {
        int n = 0;
        if (!paramArrayOfHand[m].getCard(1).valid())
          n++;
        if (!paramArrayOfHand[m].getCard(2).valid())
          n++;
        if (n == 1)
        {
          l *= (localDeck.cardsLeft() - j - k);
          if (l < 0L)
            return -1L;
        }
        else if (n == 2)
        {
          l *= A(localDeck.cardsLeft() - j - k, 2);
          if (l < 0L)
            return -1L;
        }
        k += n;
      }
    }
    return l;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.L.E
 * JD-Core Version:    0.6.2
 */