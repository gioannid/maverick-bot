package com.biotools.poker.L;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.util.NChoose2IntTable;
import com.biotools.poker.E;
import java.io.PrintStream;

public abstract class C
  implements Runnable
{
  protected NChoose2IntTable B;
  protected int[] D;
  protected long[] I;
  protected long[] H;
  protected long[] F;
  protected long E;
  protected long A;
  protected volatile boolean G = true;
  protected int L;
  protected Hand J;
  protected Hand[] K;
  protected double[] C;

  public void run()
  {
    this.G = false;
    long l1 = System.currentTimeMillis();
    D();
    long l2 = System.currentTimeMillis();
    double d = l2 - l1;
    int i = (int)(I() / d);
    E.H("Speed: " + i + " eval/msec, " + d + " msec.");
    this.G = true;
  }

  public abstract void D();

  public synchronized boolean G()
  {
    return this.G;
  }

  public synchronized void F()
  {
    this.G = true;
  }

  public synchronized int C()
  {
    return (int)(2147483647.0D * (this.A / this.E));
  }

  public synchronized long A()
  {
    return this.A;
  }

  public synchronized long I()
  {
    return this.E;
  }

  public synchronized long B(int paramInt)
  {
    return this.I[paramInt];
  }

  public synchronized long E(int paramInt)
  {
    return this.H[paramInt];
  }

  public synchronized long D(int paramInt)
  {
    return this.F[paramInt];
  }

  public synchronized double A(int paramInt)
  {
    return this.C[paramInt];
  }

  public synchronized double C(int paramInt)
  {
    return (B(paramInt) + A(paramInt)) / I();
  }

  protected static final int A(int paramInt1, int paramInt2)
  {
    if (paramInt2 == 1)
      return paramInt1;
    return (paramInt1 - (paramInt2 - 1)) * A(paramInt1, paramInt2 - 1) / paramInt2;
  }

  protected int A(Hand paramHand)
  {
    if (this.B != null)
      return this.B.get(paramHand.getFirstCard().getIndex(), paramHand.getSecondCard().getIndex());
    this.J.addCard(paramHand.getFirstCard());
    this.J.addCard(paramHand.getSecondCard());
    int i = HandEvaluator.rankHand7(this.J);
    this.J.removeCard();
    this.J.removeCard();
    return i;
  }

  protected void A(Hand paramHand, Hand[] paramArrayOfHand)
  {
    this.J = new Hand(paramHand);
    this.K = new Hand[paramArrayOfHand.length];
    for (int i = 0; i < paramArrayOfHand.length; i++)
      this.K[i] = new Hand(paramArrayOfHand[i]);
    this.L = this.K.length;
    this.I = new long[this.L];
    this.H = new long[this.L];
    this.F = new long[this.L];
    this.D = new int[this.L];
    this.C = new double[this.L];
  }

  protected final void H()
  {
    int i = 0;
    int j = 0;
    int m;
    for (int k = 0; k < this.L; k++)
    {
      m = this.D[k] = A(this.K[k]);
      if (m > i)
      {
        i = m;
        j = 0;
      }
      else if (m == i)
      {
        j++;
      }
    }
    for (k = 0; k < this.L; k++)
    {
      m = this.D[k];
      if (m < i)
        this.F[k] += 1L;
      else if (m == i)
        if (j == 0)
        {
          this.I[k] += 1L;
        }
        else
        {
          this.C[k] += 1.0D / (j + 1);
          this.H[k] += 1L;
        }
    }
    this.A += 1L;
  }

  protected void B()
  {
    for (int i = 0; i < this.L; i++)
    {
      System.out.println(" " + this.K[i]);
      System.out.println("   WON: " + this.I[i]);
      System.out.println("  TIED: " + this.H[i]);
      System.out.println("  LOST: " + this.F[i]);
      System.out.println("----------------");
      System.out.println(" TOTAL: " + (this.I[i] + this.H[i] + this.F[i]));
    }
  }

  public abstract String E();
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.L.C
 * JD-Core Version:    0.6.2
 */