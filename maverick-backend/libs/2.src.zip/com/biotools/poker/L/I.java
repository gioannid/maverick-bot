package com.biotools.poker.L;

public abstract interface I
{
  public abstract void A(K paramK);
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.L.I
 * JD-Core Version:    0.6.2
 */