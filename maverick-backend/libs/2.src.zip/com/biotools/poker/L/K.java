package com.biotools.poker.L;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.poker.F.T;
import com.biotools.poker.F.U;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;

public class K extends JButton
  implements ActionListener
{
  private I D;
  private U C = new U();
  private Deck B;
  private boolean A = true;
  private Object E = null;

  public K(Deck paramDeck, JFrame paramJFrame)
  {
    this.E = paramJFrame;
    A(paramDeck);
  }

  public K(Deck paramDeck, JDialog paramJDialog)
  {
    this.E = paramJDialog;
    A(paramDeck);
  }

  public void D()
  {
    this.C = new com.biotools.poker.F.K();
    setIcon(new ImageIcon(this.C.M()));
  }

  public void C()
  {
    this.C = new T();
    setIcon(new ImageIcon(this.C.M()));
  }

  public void A()
  {
    this.C = new U();
    setIcon(new ImageIcon(this.C.M()));
  }

  private void A(Deck paramDeck)
  {
    this.B = paramDeck;
    setIcon(new ImageIcon(this.C.M()));
    setMargin(new Insets(2, 2, 2, 2));
    setBorderPainted(false);
    setBorder(BorderFactory.createEmptyBorder());
    addActionListener(this);
  }

  public void actionPerformed(ActionEvent paramActionEvent)
  {
    if (!this.A)
      return;
    Card localCard1 = this.C.N();
    B();
    if (((paramActionEvent.getModifiers() & 0x2) == 2) && (localCard1 != null))
    {
      if (this.D != null)
        this.D.A(this);
      return;
    }
    Card localCard2 = A.A(this.B, this.E);
    if (localCard2 != null)
    {
      this.C.A(localCard2);
      this.B.extractCard(localCard2);
      setIcon(new ImageIcon(this.C.M()));
      if ((!localCard2.equals(localCard1)) && (this.D != null))
        this.D.A(this);
    }
    else if ((localCard1 != null) && (this.D != null))
    {
      this.D.A(this);
    }
  }

  public Card E()
  {
    return this.C.N();
  }

  public void B()
  {
    Card localCard = this.C.N();
    if (localCard != null)
      this.B.replaceCard(localCard);
    this.C.G();
    setIcon(new ImageIcon(this.C.M()));
  }

  public void A(boolean paramBoolean)
  {
    this.A = paramBoolean;
  }

  public void A(I paramI)
  {
    this.D = paramI;
  }

  public void A(Card paramCard)
  {
    Card localCard = E();
    B();
    if (paramCard != null)
    {
      this.C.A(paramCard);
      this.B.extractCard(paramCard);
      setIcon(new ImageIcon(this.C.M()));
    }
    if ((this.D != null) && ((localCard != null) || (paramCard != null)))
      this.D.A(this);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.L.K
 * JD-Core Version:    0.6.2
 */