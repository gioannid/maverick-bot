package com.biotools.poker.K;

import com.biotools.B.R;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.poker.PokerApp;
import com.biotools.poker.Q.J;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.util.Hashtable;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class F extends JPanel
  implements com.biotools.poker.L.I
{
  private static final String W = com.biotools.poker.E.D("HandInfo.OpponentPreflopTightness");
  private HandEvaluator X = new HandEvaluator();
  private com.biotools.poker.D.E S = new com.biotools.poker.D.E();
  private I k;
  private Deck m = new Deck();
  private Deck h = new Deck();
  private JLabel U = new JLabel("<html></html>", 0);
  private JLabel g = new JLabel("<html><i> " + com.biotools.poker.E.D("HandInfo.PleaseEnterCards") + " </i></html>", 0);
  private JLabel T = new JLabel("<html></html>", 0);
  private JLabel c = new JLabel("<html></html>", 0);
  private com.biotools.poker.L.K b;
  private com.biotools.poker.L.K a;
  private com.biotools.poker.L.K[] Y = new com.biotools.poker.L.K[5];
  private K l = new K();
  private E f = new E();
  private JSlider Z = r();
  private A i = new A();
  private H j = new H();
  private static transient double[] e = { 0.0548D, 0.0668D, 0.0808D, 0.0968D, 0.1151D, 0.1357D, 0.1587D, 0.1841D, 0.2119D, 0.242D, 0.2743D, 0.3085D, 0.3446D, 0.3821D, 0.4207D, 0.4602D, 0.5D, 0.5398D, 0.5793D, 0.6179D, 0.6554D, 0.6915D, 0.7257D, 0.758D, 0.7881D, 0.8159D, 0.8413000000000001D, 0.8849D, 0.9032D, 0.9192D, 0.9332D, 0.9452D };
  private JFrame d = null;
  private boolean _ = true;
  private JMenuBar V;

  public F()
  {
    com.A.B.A localA = new com.A.B.A();
    localA.A(com.biotools.poker.E.K("help/evaluator.html"));
    localA.setPreferredSize(new Dimension(300, 300));
    JTabbedPane localJTabbedPane = new JTabbedPane();
    localJTabbedPane.add(com.biotools.poker.E.D("HandInfo.Strength"), o());
    localJTabbedPane.add(com.biotools.poker.E.D("HandInfo.Draws"), c());
    localJTabbedPane.add(com.biotools.poker.E.D("HandInfo.Hands"), j());
    localJTabbedPane.add(com.biotools.poker.E.D("HandInfo.Bias"), Z());
    localJTabbedPane.add(com.biotools.poker.E.D("HandInfo.Help"), localA);
    setLayout(new BorderLayout(5, 5));
    setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    add(l(), "North");
    add(localJTabbedPane, "Center");
    add(this.Z, "South");
    s();
  }

  private JPanel o()
  {
    JPanel localJPanel = new JPanel(new BorderLayout(5, 5));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
    localJPanel.add(h(), "North");
    localJPanel.add(this.j, "Center");
    localJPanel.add(this.U, "South");
    this.U.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
    return localJPanel;
  }

  private JPanel c()
  {
    JPanel localJPanel = new JPanel(new BorderLayout(5, 5));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
    localJPanel.add(this.l, "Center");
    localJPanel.add(this.c, "South");
    localJPanel.add(q(), "North");
    this.c.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
    return localJPanel;
  }

  private JPanel j()
  {
    JPanel localJPanel = new JPanel(new BorderLayout(5, 5));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
    localJPanel.add(i(), "North");
    localJPanel.add(this.f, "Center");
    localJPanel.add(this.T, "South");
    this.T.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
    return localJPanel;
  }

  public void A(com.biotools.poker.L.K paramK)
  {
    Card localCard1 = this.b.E();
    Card localCard2 = this.a.E();
    Hand localHand = u();
    for (int n = 0; n < 5; n++)
    {
      if (n < 3)
        this.Y[n].setEnabled((localCard1 != null) && (localCard2 != null));
      else if (n == 3)
        this.Y[n].setEnabled((localCard1 != null) && (localCard2 != null) && (localHand.size() >= 3));
      else if (n == 4)
        this.Y[n].setEnabled((localCard1 != null) && (localCard2 != null) && (localHand.size() >= 4));
      if (!this.Y[n].isEnabled())
        this.Y[n].A(null);
    }
    f();
  }

  private JPanel l()
  {
    this.b = new com.biotools.poker.L.K(this.m, a());
    this.a = new com.biotools.poker.L.K(this.m, a());
    this.b.A(this);
    this.a.A(this);
    JPanel localJPanel1 = new JPanel();
    localJPanel1.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    localJPanel1.setLayout(new BoxLayout(localJPanel1, 0));
    localJPanel1.add(Box.createHorizontalStrut(6));
    localJPanel1.add(Box.createHorizontalGlue());
    localJPanel1.add(this.b);
    localJPanel1.add(Box.createHorizontalStrut(6));
    localJPanel1.add(this.a);
    localJPanel1.add(Box.createHorizontalStrut(28));
    for (int n = 0; n < 5; n++)
    {
      localJPanel1.add(Box.createHorizontalStrut(6));
      this.Y[n] = new com.biotools.poker.L.K(this.m, a());
      this.Y[n].A(this);
      localJPanel1.add(this.Y[n]);
      this.Y[n].setEnabled(false);
    }
    localJPanel1.add(Box.createHorizontalGlue());
    localJPanel1.add(Box.createHorizontalStrut(6));
    JPanel localJPanel2 = new JPanel(new BorderLayout(6, 6));
    localJPanel2.add(localJPanel1, "Center");
    localJPanel2.add(this.g, "South");
    return localJPanel2;
  }

  public void t()
  {
    this.b.A(null);
    this.a.A(null);
    for (int n = 0; n < 5; n++)
      this.Y[n].A(null);
  }

  public void A(com.biotools.poker.Q.D paramD, Card paramCard1, Card paramCard2)
  {
    if (PokerApp.Ȅ().ɒ())
    {
      J localJ = (J)PokerApp.Ȅ().ʐ();
      if (!localJ.ê().I())
        return;
    }
    t();
    this.b.A(paramCard1);
    this.a.A(paramCard2);
    for (int n = 0; n < 5; n++)
    {
      if (n < paramD.getBoard().size())
        this.Y[n].A(paramD.C(n));
      else
        this.Y[n].A(null);
      this.Y[n].repaint();
    }
    f();
  }

  private JPanel Z()
  {
    this.k = new I(this.S, 14);
    JPanel localJPanel1 = new JPanel();
    localJPanel1.setBorder(BorderFactory.createEtchedBorder());
    localJPanel1.add(this.k);
    this.i.A(this.S);
    JPanel localJPanel2 = new JPanel(new BorderLayout());
    localJPanel2.setBorder(BorderFactory.createEtchedBorder());
    localJPanel2.add(this.i, "Center");
    JPanel localJPanel3 = new JPanel(new BorderLayout(6, 6));
    localJPanel3.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    localJPanel3.add(localJPanel1, "West");
    localJPanel3.add(localJPanel2, "Center");
    localJPanel3.add(d(), "North");
    return localJPanel3;
  }

  private JSlider r()
  {
    JSlider localJSlider = new JSlider(0, 100, 25);
    localJSlider.setInverted(true);
    localJSlider.setMajorTickSpacing(25);
    localJSlider.setMinorTickSpacing(5);
    localJSlider.setPaintTicks(true);
    Hashtable localHashtable = new Hashtable();
    localHashtable.put(new Integer(100), new JLabel(com.biotools.poker.E.D("HandInfo.Loose")));
    localHashtable.put(new Integer(0), new JLabel(com.biotools.poker.E.D("HandInfo.Tight")));
    localJSlider.setLabelTable(localHashtable);
    localJSlider.setPaintLabels(true);
    localJSlider.setBorder(BorderFactory.createTitledBorder(W));
    localJSlider.addChangeListener(new ChangeListener()
    {
      public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
      {
        F.this.s();
      }
    });
    return localJSlider;
  }

  public Hand u()
  {
    Hand localHand = new Hand();
    for (int n = 0; n < 5; n++)
      if (this.Y[n].E() != null)
        localHand.addCard(this.Y[n].E());
      else
        return localHand;
    return localHand;
  }

  public Hand b()
  {
    Hand localHand = u();
    localHand.addCard(this.b.E());
    localHand.addCard(this.a.E());
    return localHand;
  }

  public void f()
  {
    Card localCard1 = this.b.E();
    Card localCard2 = this.a.E();
    Hand localHand = u();
    for (int n = 0; n < 5; n++)
    {
      if (n < 3)
        this.Y[n].setEnabled((localCard1 != null) && (localCard2 != null));
      else if (n == 3)
        this.Y[n].setEnabled((localCard1 != null) && (localCard2 != null) && (localHand.size() >= 3));
      else if (n == 4)
        this.Y[n].setEnabled((localCard1 != null) && (localCard2 != null) && (localHand.size() >= 4));
      if (!this.Y[n].isEnabled())
        this.Y[n].A(null);
    }
    if ((localCard1 == null) || (localCard2 == null))
    {
      this.g.setText("<html><i>" + com.biotools.poker.E.D("HandInfo.PleaseEnterHoleCards") + " </i></html>");
    }
    else
    {
      this.l.A(localCard1, localCard2, localHand);
      if (u().size() < 3)
        this.g.setText("<html><i>" + com.biotools.poker.E.D("HandInfo.PleaseEnterBoard") + " </i></html>");
      else
        this.g.setText("<html><b>" + com.biotools.poker.E.D("HandInfo.HandTypeTitle") + " </b>" + D.B(b()) + "</html>");
    }
    s();
  }

  private void v()
  {
    Card localCard1 = this.b.E();
    Card localCard2 = this.a.E();
    if ((localCard1 == null) || (localCard2 == null) || (u().size() < 3))
    {
      this.f.A();
      A(this.T, "<html><center><i>" + com.biotools.poker.E.D("HandInfo.PleaseEnterCards") + "</i></center></html>");
      return;
    }
    this.f.A(localCard1, localCard2, u(), this.S);
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<html>");
    localStringBuffer.append("<table border=\"0\" cellpadding=\"4\" >");
    localStringBuffer.append("<tr><td align=\"right\"><b>" + com.biotools.poker.E.D("HandInfo.TheNutsTitle") + "</b></td>");
    localStringBuffer.append("<td>" + D.B(C.B(localCard1, localCard2, u())) + "</td></tr>");
    localStringBuffer.append("</table>");
    localStringBuffer.append("</html>");
    A(this.T, localStringBuffer.toString());
  }

  private void p()
  {
    Card localCard1 = this.b.E();
    Card localCard2 = this.a.E();
    if ((localCard1 == null) || (localCard2 == null))
    {
      this.l.A();
      A(this.c, "<html><center><i>" + com.biotools.poker.E.D("HandInfo.PleaseEnterCards") + "</i></center></html>");
      return;
    }
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("<html>");
    if ((u().size() >= 3) && (u().size() < 5))
    {
      double[] arrayOfDouble = com.biotools.poker.D.A.B(localCard1, localCard2, u(), this.S);
      localStringBuffer.append("<table border=\"0\" cellpadding=\"4\" >");
      localStringBuffer.append("<tr><td align=\"right\"><b>" + com.biotools.poker.E.D("HandInfo.PositivePotentialTitle") + "</b></td>");
      localStringBuffer.append("<td>" + A(100.0D * arrayOfDouble[0], 1) + "%</td>");
      localStringBuffer.append("<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>");
      localStringBuffer.append("<td align=\"right\"><b>" + com.biotools.poker.E.D("HandInfo.NegativePotentialTitle") + "</b></td>");
      localStringBuffer.append("<td>" + A(100.0D * arrayOfDouble[1], 1) + "%</td></tr>");
      localStringBuffer.append("</table>");
    }
    else
    {
      localStringBuffer.append("--");
    }
    localStringBuffer.append("</html>");
    A(this.c, localStringBuffer.toString());
  }

  private void g()
  {
    Card localCard1 = this.b.E();
    Card localCard2 = this.a.E();
    if ((localCard1 == null) || (localCard2 == null))
    {
      this.j.A();
      A(this.U, "<html><center><i>" + com.biotools.poker.E.D("HandInfo.NA") + "</i></center></html>");
      return;
    }
    StringBuffer localStringBuffer = new StringBuffer();
    Object[] arrayOfObject1 = { Hand.getTranslatedCardString(localCard1, localCard2) };
    localStringBuffer.append("<html><center><b>" + com.biotools.poker.E.A("HandInfo.PreflopHandRankPattern", arrayOfObject1) + "</b>  ");
    Object[] arrayOfObject2 = { new Integer(com.biotools.poker.N.B.K.A(localCard1, localCard2, 7)) };
    localStringBuffer.append(com.biotools.poker.E.A("HandInfo.OutOfStartingHandTypesPattern", arrayOfObject2) + "</center></html>");
    A(this.U, localStringBuffer.toString());
    this.j.A(localCard1, localCard2, u(), this.S, -1);
  }

  private void s()
  {
    A(this.Z.getValue() / 100.0D);
    this.k.repaint();
    v();
    p();
    g();
    Card localCard1 = this.b.E();
    Card localCard2 = this.a.E();
    if ((localCard1 != null) && (localCard2 != null) && (u().size() >= 3))
    {
      double d1 = n();
      this.i.A(d1, u());
    }
    else
    {
      this.i.A();
    }
  }

  private void A(final JLabel paramJLabel, final String paramString)
  {
    SwingUtilities.invokeLater(new Runnable()
    {
      private final JLabel val$lbl;
      private final String val$txt;

      public void run()
      {
        paramJLabel.setText(paramString);
      }
    });
  }

  private JComponent d()
  {
    String str = "<html>" + com.biotools.poker.E.D("HandInfo.BiasDescription") + "</html>";
    JLabel localJLabel = new JLabel(str, 0);
    localJLabel.setFont(new Font("Sans Serif", 0, 11));
    localJLabel.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    localJLabel.setVerticalAlignment(1);
    localJLabel.setPreferredSize(new Dimension(300, 50));
    return localJLabel;
  }

  private JComponent i()
  {
    String str = "<html>" + com.biotools.poker.E.D("HandInfo.OpponentHandDescription") + "</html>";
    JLabel localJLabel = new JLabel(str, 0);
    localJLabel.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    localJLabel.setFont(new Font("Sans Serif", 0, 11));
    localJLabel.setVerticalAlignment(1);
    localJLabel.setPreferredSize(new Dimension(300, 60));
    return localJLabel;
  }

  private JComponent q()
  {
    String str = "<html>" + com.biotools.poker.E.D("HandInfo.DrawsDescription") + "</html>";
    JLabel localJLabel = new JLabel(str, 0);
    localJLabel.setFont(new Font("Sans Serif", 0, 11));
    localJLabel.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    localJLabel.setVerticalAlignment(1);
    localJLabel.setPreferredSize(new Dimension(300, 60));
    return localJLabel;
  }

  private JComponent h()
  {
    String str = "<html> " + com.biotools.poker.E.D("HandInfo.StrengthDescription") + "</html>";
    JLabel localJLabel = new JLabel(str, 0);
    localJLabel.setFont(new Font("Sans Serif", 0, 11));
    localJLabel.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    localJLabel.setVerticalAlignment(1);
    localJLabel.setPreferredSize(new Dimension(300, 60));
    return localJLabel;
  }

  public double n()
  {
    Card localCard1 = this.b.E();
    Card localCard2 = this.a.E();
    int n = 1;
    if (n == 0)
      n = 1;
    return HandEvaluator.handRank(localCard1, localCard2, u(), n);
  }

  private void A(double paramDouble)
  {
    this.S.A(1.0D);
    if (paramDouble == 0.0D)
      paramDouble = 0.01D;
    if (paramDouble <= 1.0D)
    {
      int n = (int)Math.round(1326.0D * paramDouble);
      if (n >= 1326)
        n = 1325;
      int i1 = com.biotools.poker.N.B.K.C[n];
      this.h.reset();
      for (int i2 = this.h.getTopCardIndex(); i2 < 52; i2++)
      {
        Card localCard = this.h.getCard(i2);
        for (i3 = i2 + 1; i3 < 52; i3++)
        {
          localObject = this.h.getCard(i3);
          int i4 = com.biotools.poker.N.B.K.A(localCard.getRank(), ((Card)localObject).getRank(), localCard.getSuit() == ((Card)localObject).getSuit(), 7);
          double d3 = A(i4, i1, 330.0D);
          this.S.A(localCard, (Card)localObject, Math.max(d3, 0.0001D));
        }
      }
    }
    double d1 = 0.0D;
    double d2 = this.S.E();
    for (int i3 = 0; i3 < this.S.F(); i3++)
      d1 += this.S.A(i3) / d2;
    d1 /= this.S.F();
    d1 = Math.round(1000.0D * d1) / 10.0D;
    TitledBorder localTitledBorder = (TitledBorder)this.Z.getBorder();
    Object localObject = { new Double(d1) };
    localTitledBorder.setTitle(com.biotools.poker.E.A("HandInfo.PreflopTightnessHandsPlayedPattern", (Object[])localObject));
  }

  private static final double A(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    int n = (int)((paramDouble1 - paramDouble2) / paramDouble3 * 10.0D);
    if (n >= 16)
      return 1.0D;
    if (n <= -16)
      return 0.01D;
    return e[(n + 16)];
  }

  public static double A(double paramDouble, int paramInt)
  {
    if (Double.isNaN(paramDouble))
      return paramDouble;
    double d1 = 1.0D;
    for (int n = 0; n < paramInt; n++)
      d1 *= 10.0D;
    return Math.round(paramDouble * d1) / d1;
  }

  public double A(Card paramCard1, Card paramCard2, int paramInt)
  {
    return com.biotools.poker.N.B.K.B(paramCard1, paramCard2, paramInt);
  }

  public void e()
  {
    R localR = R.B(com.biotools.poker.E.D("HandInfo.Help"));
    localR.A("evaluator.html");
  }

  private JFrame a()
  {
    if (this.d == null)
      k();
    return this.d;
  }

  private void k()
  {
    this.d = new JFrame(com.biotools.poker.E.D("HandInfo.HandEvaluatorHeading"));
    this.d.setIconImage(com.biotools.poker.E.¢);
    this.d.getContentPane().setLayout(new BorderLayout());
    this.d.getContentPane().add(this, "Center");
    this.V = new G(this);
    this.d.setJMenuBar(this.V);
    this.d.setDefaultCloseOperation(1);
    this.d.setResizable(false);
  }

  public void _()
  {
    com.biotools.poker.E.A("HEV_WINDOW", a());
    a().setVisible(true);
    if (this._)
      this._ = false;
    com.biotools.poker.E.q();
  }

  public void m()
  {
    if (this.d != null)
      this.d.setVisible(false);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.K.F
 * JD-Core Version:    0.6.2
 */