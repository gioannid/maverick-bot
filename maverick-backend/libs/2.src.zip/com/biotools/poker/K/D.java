package com.biotools.poker.K;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEval;
import com.biotools.poker.E;
import java.io.PrintStream;

public class D
  implements HandEval
{
  private static final int Z = -1;
  private static final int R = 9;
  private static final int N = 8;
  private static final int S = 7;
  private static final int U = 6;
  private static final int J = 5;
  private static final int H = 4;
  private static final int G = 3;
  private static final int T = 2;
  private static final int Q = 1;
  private static final int a = 1;
  private static final int P = 5;
  public static final int V = 0;
  public static final int _ = 1;
  public static final int X = 2;
  public static final int A = 3;
  public static final int O = 4;
  public static final int F = 5;
  public static final int K = 6;
  public static final int Y = 7;
  public static final int C = 8;
  public static final int M = 9;
  public static final int D = 10;
  private static final int W = 13;
  private static final int I = 371293;
  private static final String[] B = { E.D("UofAHandEval.HighCardCaps"), E.D("UofAHandEval.PairCaps"), E.D("UofAHandEval.TwoPairCaps"), E.D("UofAHandEval.ThreeOfAKindCaps"), E.D("UofAHandEval.StraightCaps"), E.D("UofAHandEval.FlushCaps"), E.D("UofAHandEval.FullHouseCaps"), E.D("UofAHandEval.FourOfAKindCaps"), E.D("UofAHandEval.StraightFlushCaps"), E.D("UofAHandEval.FiveOfAKindCaps") };
  private static final String[] L = { E.D("UofAHandEval.Two"), E.D("UofAHandEval.Three"), E.D("UofAHandEval.Four"), E.D("UofAHandEval.Five"), E.D("UofAHandEval.Six"), E.D("UofAHandEval.Seven"), E.D("UofAHandEval.Eight"), E.D("UofAHandEval.Nine"), E.D("UofAHandEval.Ten"), E.D("UofAHandEval.Jack"), E.D("UofAHandEval.Queen"), E.D("UofAHandEval.King"), E.D("UofAHandEval.Ace") };
  private static final String[] E = { E.D("UofAHandEval.Twos"), E.D("UofAHandEval.Threes"), E.D("UofAHandEval.Fours"), E.D("UofAHandEval.Fives"), E.D("UofAHandEval.Sixes"), E.D("UofAHandEval.Sevens"), E.D("UofAHandEval.Eights"), E.D("UofAHandEval.Nines"), E.D("UofAHandEval.Tens"), E.D("UofAHandEval.Jacks"), E.D("UofAHandEval.Queens"), E.D("UofAHandEval.Kings"), E.D("UofAHandEval.Aces") };

  public static Hand E(Hand paramHand)
  {
    int[] arrayOfInt1 = paramHand.getCardArray();
    int[] arrayOfInt2 = new int[6];
    int i = A(arrayOfInt1, arrayOfInt2);
    Hand localHand = new Hand();
    for (int j = 0; j < 5; j++)
      localHand.addCard(arrayOfInt2[(j + 1)]);
    return localHand;
  }

  private static String B(int paramInt)
  {
    switch (paramInt)
    {
    case -1:
      return E.D("UofAHandEval.HiddenHand");
    case 1:
      return E.D("UofAHandEval.HighCard");
    case 2:
      return E.D("UofAHandEval.Pair");
    case 3:
      return E.D("UofAHandEval.TwoPair");
    case 4:
      return E.D("UofAHandEval.ThreeOfAKind");
    case 5:
      return E.D("UofAHandEval.Straight");
    case 6:
      return E.D("UofAHandEval.Flush");
    case 7:
      return E.D("UofAHandEval.FullHouse");
    case 8:
      return E.D("UofAHandEval.FourOfAKind");
    case 9:
      return E.D("UofAHandEval.StraightFlush");
    case 0:
    }
    return "Very Weird hand indeed";
  }

  private static boolean E(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    int[] arrayOfInt = new int[14];
    boolean bool = false;
    for (int k = 0; k <= 3; k++)
    {
      arrayOfInt[0] = 13;
      for (int i = 1; i <= arrayOfInt[0]; i++)
        arrayOfInt[i] = 0;
      for (i = 1; i <= paramArrayOfInt1[0]; i++)
        if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] / 13 == k))
          arrayOfInt[(paramArrayOfInt1[i] % 13 + 1)] = 1;
      int m;
      if (arrayOfInt[13] >= 1)
        m = 1;
      else
        m = 0;
      int n = 0;
      for (i = 1; i <= 13; i++)
        if (arrayOfInt[i] >= 1)
        {
          m++;
          if (m >= 5)
            n = i - 1;
        }
        else
        {
          m = 0;
        }
      if (n > 0)
      {
        for (int j = 1; j <= 5; j++)
          paramArrayOfInt3[j] = (13 * k + n + 1 - j);
        if (n == 3)
          paramArrayOfInt3[5] += 13;
        bool = true;
      }
    }
    return bool;
  }

  private static void F(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    int k = 0;
    for (int i = 1; i <= 13; i++)
      if (paramArrayOfInt2[i] >= 4)
        k = i - 1;
    i = 1;
    int j = 1;
    while (j <= 4)
    {
      if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == k))
      {
        paramArrayOfInt3[j] = paramArrayOfInt1[i];
        j++;
      }
      i++;
    }
    int m = -1;
    for (i = 1; i <= 13; i++)
      if ((paramArrayOfInt2[i] >= 1) && (i - 1 != k))
        m = i - 1;
    if (m != -1)
    {
      for (i = 1; j <= 5; i++)
        if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == m))
        {
          paramArrayOfInt3[j] = paramArrayOfInt1[i];
          j++;
        }
    }
    else
    {
      paramArrayOfInt3[j] = -1;
      j++;
    }
  }

  private static void G(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    int k = 0;
    int m = 0;
    for (int i = 1; i <= 13; i++)
      if (paramArrayOfInt2[i] >= 3)
        k = i - 1;
    i = 1;
    int j = 1;
    while (j <= 3)
    {
      if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == k))
      {
        paramArrayOfInt3[j] = paramArrayOfInt1[i];
        j++;
      }
      i++;
    }
    i = 13;
    m = -1;
    while (m < 0)
      if ((paramArrayOfInt2[i] >= 2) && (i - 1 != k))
        m = i - 1;
      else
        i--;
    for (i = 1; j <= 5; i++)
      if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == m))
      {
        paramArrayOfInt3[j] = paramArrayOfInt1[i];
        j++;
      }
  }

  private static void I(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    int k = 0;
    int[] arrayOfInt = new int[14];
    for (int i = 14; i <= 17; i++)
      if (paramArrayOfInt2[i] >= 5)
        k = i - 14;
    arrayOfInt[0] = 13;
    for (i = 1; i <= arrayOfInt[0]; i++)
      arrayOfInt[i] = 0;
    for (i = 1; i <= paramArrayOfInt1[0]; i++)
      if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] / 13 == k))
        arrayOfInt[(paramArrayOfInt1[i] % 13 + 1)] = 1;
    i = 13;
    int j = 1;
    while (j <= 5)
    {
      if (arrayOfInt[i] >= 1)
      {
        paramArrayOfInt3[j] = (13 * k + i - 1);
        j++;
      }
      i--;
    }
  }

  private static void D(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    int k;
    if (paramArrayOfInt2[13] >= 1)
      k = 1;
    else
      k = 0;
    int m = 0;
    for (int i = 1; i <= 13; i++)
      if (paramArrayOfInt2[i] >= 1)
      {
        k++;
        if (k >= 5)
          m = i - 1;
      }
      else
      {
        k = 0;
      }
    int j;
    if (m > 3)
    {
      for (j = 1; j <= 5; j++)
        for (i = 1; i <= paramArrayOfInt1[0]; i++)
          if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == m + 1 - j))
            paramArrayOfInt3[j] = paramArrayOfInt1[i];
    }
    else if (m == 3)
    {
      for (j = 1; j <= 4; j++)
        for (i = 1; i <= paramArrayOfInt1[0]; i++)
          if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == m + 1 - j))
            paramArrayOfInt3[j] = paramArrayOfInt1[i];
      for (i = 1; i <= paramArrayOfInt1[0]; i++)
        if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == 12))
          paramArrayOfInt3[5] = paramArrayOfInt1[i];
    }
  }

  private static void A(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    int k = 0;
    for (int i = 1; i <= 13; i++)
      if (paramArrayOfInt2[i] >= 3)
        k = i - 1;
    i = 1;
    int j = 1;
    while (j <= 3)
    {
      if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == k))
      {
        paramArrayOfInt3[j] = paramArrayOfInt1[i];
        j++;
      }
      i++;
    }
    int m = -1;
    for (i = 1; i <= 13; i++)
      if ((paramArrayOfInt2[i] >= 1) && (i - 1 != k))
        m = i - 1;
    int n = -1;
    for (i = 1; i <= m; i++)
      if ((paramArrayOfInt2[i] >= 1) && (i - 1 != k))
        n = i - 1;
    if (m != -1)
    {
      for (i = 1; j <= 4; i++)
        if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == m))
        {
          paramArrayOfInt3[j] = paramArrayOfInt1[i];
          j++;
        }
    }
    else
    {
      paramArrayOfInt3[j] = -1;
      j++;
    }
    if (n != -1)
    {
      for (i = 1; j <= 5; i++)
        if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == n))
        {
          paramArrayOfInt3[j] = paramArrayOfInt1[i];
          j++;
        }
    }
    else
    {
      paramArrayOfInt3[j] = -1;
      j++;
    }
  }

  private static void B(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    int k = 0;
    int m = 0;
    for (int i = 1; i <= 13; i++)
      if (paramArrayOfInt2[i] >= 2)
        k = i - 1;
    for (i = 1; i <= 13; i++)
      if ((paramArrayOfInt2[i] >= 2) && (i - 1 != k))
        m = i - 1;
    i = 1;
    int j = 1;
    while (j <= 2)
    {
      if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == k))
      {
        paramArrayOfInt3[j] = paramArrayOfInt1[i];
        j++;
      }
      i++;
    }
    for (i = 1; j <= 4; i++)
      if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == m))
      {
        paramArrayOfInt3[j] = paramArrayOfInt1[i];
        j++;
      }
    int n = -1;
    for (i = 1; i <= 13; i++)
      if ((paramArrayOfInt2[i] >= 1) && (i - 1 != k) && (i - 1 != m))
        n = i - 1;
    if (n != -1)
    {
      for (i = 1; j <= 5; i++)
        if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == n))
        {
          paramArrayOfInt3[j] = paramArrayOfInt1[i];
          j++;
        }
    }
    else
    {
      paramArrayOfInt3[j] = -1;
      j++;
    }
  }

  private static void C(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    int k = 0;
    for (int i = 1; i <= 13; i++)
      if (paramArrayOfInt2[i] >= 2)
        k = i - 1;
    i = 1;
    int j = 1;
    while (j <= 2)
    {
      if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == k))
      {
        paramArrayOfInt3[j] = paramArrayOfInt1[i];
        j++;
      }
      i++;
    }
    int m = -1;
    for (i = 1; i <= 13; i++)
      if ((paramArrayOfInt2[i] >= 1) && (i - 1 != k))
        m = i - 1;
    int n = -1;
    for (i = 1; i <= m; i++)
      if ((paramArrayOfInt2[i] >= 1) && (i - 1 != k))
        n = i - 1;
    int i1 = -1;
    for (i = 1; i <= n; i++)
      if ((paramArrayOfInt2[i] >= 1) && (i - 1 != k))
        i1 = i - 1;
    if (m != -1)
    {
      for (i = 1; j <= 3; i++)
        if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == m))
        {
          paramArrayOfInt3[j] = paramArrayOfInt1[i];
          j++;
        }
    }
    else
    {
      paramArrayOfInt3[j] = -1;
      j++;
    }
    if (n != -1)
    {
      for (i = 1; j <= 4; i++)
        if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == n))
        {
          paramArrayOfInt3[j] = paramArrayOfInt1[i];
          j++;
        }
    }
    else
    {
      paramArrayOfInt3[j] = -1;
      j++;
    }
    if (i1 != -1)
    {
      for (i = 1; j <= 5; i++)
        if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == i1))
        {
          paramArrayOfInt3[j] = paramArrayOfInt1[i];
          j++;
        }
    }
    else
    {
      paramArrayOfInt3[j] = -1;
      j++;
    }
  }

  private static void H(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    int k = -1;
    for (int i = 1; i <= 13; i++)
      if (paramArrayOfInt2[i] >= 1)
        k = i - 1;
    int m = -1;
    for (i = 1; i <= k; i++)
      if (paramArrayOfInt2[i] >= 1)
        m = i - 1;
    int n = -1;
    for (i = 1; i <= m; i++)
      if (paramArrayOfInt2[i] >= 1)
        n = i - 1;
    int i1 = -1;
    for (i = 1; i <= n; i++)
      if (paramArrayOfInt2[i] >= 1)
        i1 = i - 1;
    int i2 = -1;
    for (i = 1; i <= i1; i++)
      if (paramArrayOfInt2[i] >= 1)
        i2 = i - 1;
    int j = 1;
    if (k != -1)
    {
      for (i = 1; j <= 1; i++)
        if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == k))
        {
          paramArrayOfInt3[j] = paramArrayOfInt1[i];
          j++;
        }
    }
    else
    {
      paramArrayOfInt3[j] = -1;
      j++;
    }
    if (m != -1)
    {
      for (i = 1; j <= 2; i++)
        if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == m))
        {
          paramArrayOfInt3[j] = paramArrayOfInt1[i];
          j++;
        }
    }
    else
    {
      paramArrayOfInt3[j] = -1;
      j++;
    }
    if (n != -1)
    {
      for (i = 1; j <= 3; i++)
        if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == n))
        {
          paramArrayOfInt3[j] = paramArrayOfInt1[i];
          j++;
        }
    }
    else
    {
      paramArrayOfInt3[j] = -1;
      j++;
    }
    if (i1 != -1)
    {
      for (i = 1; j <= 4; i++)
        if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == i1))
        {
          paramArrayOfInt3[j] = paramArrayOfInt1[i];
          j++;
        }
    }
    else
    {
      paramArrayOfInt3[j] = -1;
      j++;
    }
    if (i2 != -1)
    {
      for (i = 1; j <= 5; i++)
        if ((paramArrayOfInt1[i] != -1) && (paramArrayOfInt1[i] % 13 == i2))
        {
          paramArrayOfInt3[j] = paramArrayOfInt1[i];
          j++;
        }
    }
    else
    {
      paramArrayOfInt3[j] = -1;
      j++;
    }
  }

  private static int B(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    if (paramArrayOfInt1[1] % 13 > paramArrayOfInt2[1] % 13)
      return 1;
    if (paramArrayOfInt1[1] % 13 < paramArrayOfInt2[1] % 13)
      return 2;
    if (paramArrayOfInt1[2] % 13 > paramArrayOfInt2[2] % 13)
      return 1;
    if (paramArrayOfInt1[2] % 13 < paramArrayOfInt2[2] % 13)
      return 2;
    if (paramArrayOfInt1[3] % 13 > paramArrayOfInt2[3] % 13)
      return 1;
    if (paramArrayOfInt1[3] % 13 < paramArrayOfInt2[3] % 13)
      return 2;
    if (paramArrayOfInt1[4] % 13 > paramArrayOfInt2[4] % 13)
      return 1;
    if (paramArrayOfInt1[4] % 13 < paramArrayOfInt2[4] % 13)
      return 2;
    if (paramArrayOfInt1[5] % 13 > paramArrayOfInt2[5] % 13)
      return 1;
    if (paramArrayOfInt1[5] % 13 < paramArrayOfInt2[5] % 13)
      return 2;
    return 0;
  }

  public static int A(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    int[] arrayOfInt = new int[18];
    arrayOfInt[0] = 17;
    for (int i = 1; i <= arrayOfInt[0]; i++)
      arrayOfInt[i] = 0;
    for (i = 1; i <= paramArrayOfInt1[0]; i++)
      if (paramArrayOfInt1[i] != -1)
      {
        int j = paramArrayOfInt1[i];
        int k = j % 13;
        int m = j / 13;
        if ((k >= 0) && (k <= 12))
          arrayOfInt[(k + 1)] += 1;
        if ((m >= 0) && (m <= 3))
          arrayOfInt[(m + 14)] += 1;
      }
    int i1 = 0;
    int i2 = 0;
    int i3 = 0;
    int i5 = 0;
    int i4;
    if (arrayOfInt[13] >= 1)
      i4 = 1;
    else
      i4 = 0;
    for (i = 1; i <= 13; i++)
    {
      if (arrayOfInt[i] > i1)
      {
        i2 = i1;
        i1 = arrayOfInt[i];
      }
      else if (arrayOfInt[i] > i2)
      {
        i2 = arrayOfInt[i];
      }
      if (arrayOfInt[i] >= 1)
      {
        i4++;
        if (i4 > i5)
          i5 = i4;
      }
      else
      {
        i4 = 0;
      }
    }
    for (i = 14; i <= 17; i++)
      if (arrayOfInt[i] > i3)
        i3 = arrayOfInt[i];
    int n = -1;
    if ((i3 >= 5) && (i5 >= 5))
    {
      if (E(paramArrayOfInt1, arrayOfInt, paramArrayOfInt2))
      {
        n = 9;
      }
      else
      {
        n = 6;
        I(paramArrayOfInt1, arrayOfInt, paramArrayOfInt2);
      }
    }
    else if (i1 >= 4)
    {
      n = 8;
      F(paramArrayOfInt1, arrayOfInt, paramArrayOfInt2);
    }
    else if ((i1 >= 3) && (i2 >= 2))
    {
      n = 7;
      G(paramArrayOfInt1, arrayOfInt, paramArrayOfInt2);
    }
    else if (i3 >= 5)
    {
      n = 6;
      I(paramArrayOfInt1, arrayOfInt, paramArrayOfInt2);
    }
    else if (i5 >= 5)
    {
      n = 5;
      D(paramArrayOfInt1, arrayOfInt, paramArrayOfInt2);
    }
    else if (i1 >= 3)
    {
      n = 4;
      A(paramArrayOfInt1, arrayOfInt, paramArrayOfInt2);
    }
    else if ((i1 >= 2) && (i2 >= 2))
    {
      n = 3;
      B(paramArrayOfInt1, arrayOfInt, paramArrayOfInt2);
    }
    else if (i1 >= 2)
    {
      n = 2;
      C(paramArrayOfInt1, arrayOfInt, paramArrayOfInt2);
    }
    else
    {
      n = 1;
      H(paramArrayOfInt1, arrayOfInt, paramArrayOfInt2);
    }
    return n;
  }

  private static final byte A(Hand paramHand, byte paramByte)
  {
    boolean[] arrayOfBoolean = new boolean[13];
    for (int i = 0; i < paramHand.size(); i++)
    {
      j = paramHand.getCardIndex(i + 1);
      if (Card.getSuit(j) == paramByte)
        arrayOfBoolean[Card.getRank(j)] = true;
    }
    i = arrayOfBoolean[12] != 0 ? 1 : 0;
    int j = 0;
    for (int k = 0; k < 13; k++)
      if (arrayOfBoolean[k] != 0)
      {
        i++;
        if (i >= 5)
          j = (byte)k;
      }
      else
      {
        i = 0;
      }
    return j;
  }

  private static final int A(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
  {
    int i = 12;
    int j = 0;
    while (paramInt != 0)
    {
      while ((paramArrayOfByte1[i] == 0) || (i == paramArrayOfByte2[0]) || (i == paramArrayOfByte2[1]))
        i--;
      paramInt--;
      j += A(13, paramInt) * i;
      i--;
    }
    return j;
  }

  private static final int A(Hand paramHand, int paramInt, byte paramByte)
  {
    int j = 0;
    boolean[] arrayOfBoolean = new boolean[13];
    for (int i = 0; i < paramHand.size(); i++)
      if (paramHand.getCard(i + 1).getSuit() == paramByte)
        arrayOfBoolean[paramHand.getCard(i + 1).getRank()] = true;
    for (i = 12; paramInt != 0; i--)
    {
      while (arrayOfBoolean[i] == 0)
        i--;
      paramInt--;
      j += A(13, paramInt) * i;
    }
    return j;
  }

  public static final int C(Hand paramHand)
  {
    int i = 0;
    int j = 0;
    int k = (byte)(paramHand.size() >= 5 ? 5 : paramHand.size());
    byte[] arrayOfByte1 = new byte[6];
    byte[] arrayOfByte2 = new byte[13];
    byte[][] arrayOfByte = new byte[6][2];
    int i2 = 0;
    byte[] arrayOfByte3 = new byte[4];
    byte b2 = 0;
    for (int m = 0; m < paramHand.size(); m++)
    {
      i4 = paramHand.getCardIndex(m + 1);
      int i1 = (byte)Card.getRank(i4);
      byte b1 = (byte)Card.getSuit(i4);
      int tmp90_88 = i1;
      byte[] tmp90_86 = arrayOfByte2;
      tmp90_86[tmp90_88] = ((byte)(tmp90_86[tmp90_88] + 1));
      byte tmp103_102 = arrayOfByte2[i1];
      byte[] tmp103_96 = arrayOfByte1;
      tmp103_96[tmp103_102] = ((byte)(tmp103_96[tmp103_102] + 1));
      if (arrayOfByte2[i1] != 0)
      {
        int tmp126_125 = (arrayOfByte2[i1] - 1);
        byte[] tmp126_117 = arrayOfByte1;
        tmp126_117[tmp126_125] = ((byte)(tmp126_117[tmp126_125] - 1));
      }
      byte tmp136_134 = b1;
      byte[] tmp136_132 = arrayOfByte3;
      if ((tmp136_132[tmp136_134] = (byte)(tmp136_132[tmp136_134] + 1)) >= 5)
      {
        j = 1;
        b2 = b1;
      }
    }
    int i3 = (byte)(arrayOfByte2[12] != 0 ? 1 : 0);
    for (int i4 = 0; i4 < 6; i4++)
    {
      arrayOfByte[i4][0] = 13;
      arrayOfByte[i4][1] = 13;
    }
    for (m = 0; m < 13; m++)
    {
      if (arrayOfByte2[m] != 0)
      {
        if ((i3 = (byte)(i3 + 1)) >= 5)
        {
          i = 1;
          i2 = (byte)m;
        }
      }
      else
        i3 = 0;
      int n = arrayOfByte2[m];
      if (n != 0)
      {
        arrayOfByte[n][1] = arrayOfByte[n][0];
        arrayOfByte[n][0] = ((byte)m);
      }
    }
    if (arrayOfByte1[5] != 0)
    {
      i4 = 3341637;
      i4 += arrayOfByte[5][0];
      return i4;
    }
    if ((i != 0) && (j != 0))
    {
      int i5 = A(paramHand, b2);
      if (i5 > 0)
      {
        i4 = 2970344;
        i4 += i5;
        return i4;
      }
    }
    if (arrayOfByte1[4] != 0)
    {
      i4 = 2599051;
      i4 += arrayOfByte[4][0] * 13;
      arrayOfByte[4][1] = 13;
      i4 += A(arrayOfByte2, 1, arrayOfByte[4]);
    }
    else if (arrayOfByte1[3] >= 2)
    {
      i4 = 2227758;
      i4 += arrayOfByte[3][0] * 13;
      i4 += arrayOfByte[3][1];
    }
    else if ((arrayOfByte1[3] == 1) && (arrayOfByte1[2] != 0))
    {
      i4 = 2227758;
      i4 += arrayOfByte[3][0] * 13;
      i4 += arrayOfByte[2][0];
    }
    else if (j != 0)
    {
      i4 = 1856465;
      i4 += A(paramHand, 5, b2);
    }
    else if (i != 0)
    {
      i4 = 1485172;
      i4 += i2;
    }
    else if (arrayOfByte1[3] == 1)
    {
      i4 = 1113879;
      i4 += arrayOfByte[3][0] * 13 * 13;
      i4 += A(arrayOfByte2, k - 3, arrayOfByte[3]);
    }
    else if (arrayOfByte1[2] >= 2)
    {
      i4 = 742586;
      i4 += arrayOfByte[2][0] * 13 * 13;
      i4 += arrayOfByte[2][1] * 13;
      i4 += A(arrayOfByte2, k - 4, arrayOfByte[2]);
    }
    else if (arrayOfByte1[2] == 1)
    {
      i4 = 371293;
      i4 += arrayOfByte[2][0] * 13 * 13 * 13;
      i4 += A(arrayOfByte2, k - 2, arrayOfByte[2]);
    }
    else
    {
      i4 = 0;
      i4 += A(arrayOfByte2, k, arrayOfByte[2]);
    }
    return i4;
  }

  private static final int A(int paramInt1, int paramInt2)
  {
    int i = 1;
    while (paramInt2-- > 0)
      i *= paramInt1;
    return i;
  }

  private static String A(int paramInt)
  {
    int i = paramInt / 371293;
    int j = paramInt % 371293;
    String str = null;
    switch (i)
    {
    case 0:
      j /= 28561;
      Object[] arrayOfObject1 = { L[j] };
      str = E.A("UofAHandEval.HighCardPattern", arrayOfObject1);
      break;
    case 5:
      j /= 28561;
      Object[] arrayOfObject2 = { L[j] };
      str = E.A("UofAHandEval.FlushPattern", arrayOfObject2);
      break;
    case 1:
      j /= 2197;
      Object[] arrayOfObject3 = { E[j] };
      str = E.A("UofAHandEval.OnePairPattern", arrayOfObject3);
      break;
    case 2:
      int k = j / 169;
      j = j % 169 / 13;
      Object[] arrayOfObject4 = { E[k], E[j] };
      str = E.A("UofAHandEval.TwoPairPattern", arrayOfObject4);
      break;
    case 3:
      Object[] arrayOfObject5 = { E[(j / 169)] };
      str = E.A("UofAHandEval.ThreeOfAKindPattern", arrayOfObject5);
      break;
    case 6:
      Object[] arrayOfObject6 = { E[(j / 13)], E[(j % 13)] };
      str = E.A("UofAHandEval.FullHousePattern", arrayOfObject6);
      break;
    case 7:
      Object[] arrayOfObject7 = { E[(j / 13)] };
      str = E.A("UofAHandEval.FourOfAKindPattern", arrayOfObject7);
      break;
    case 4:
      Object[] arrayOfObject8 = { L[j] };
      if ((j == 6) || (j == 12))
        str = E.A("UofAHandEval.StraightPatternForVowels", arrayOfObject8);
      else
        str = E.A("UofAHandEval.StraightPattern", arrayOfObject8);
      break;
    case 8:
      Object[] arrayOfObject9 = { L[j] };
      if (j == 6)
        str = E.A("UofAHandEval.StraightFlushForEightPattern", arrayOfObject9);
      else if (j == 12)
        str = E.D("UofAHandEval.RoyalFlush");
      else
        str = E.A("UofAHandEval.StraightFlushPattern", arrayOfObject9);
      break;
    case 9:
      Object[] arrayOfObject10 = { E[j] };
      str = E.A("UofAHandEval.FiveOfAKindPattern", arrayOfObject10);
      break;
    default:
      str = B[i];
    }
    return str;
  }

  public static int D(Hand paramHand)
  {
    int i = C(paramHand);
    int j = i / 371293;
    int k = i % 371293;
    return j;
  }

  public static String B(int paramInt1, int paramInt2)
  {
    int i = paramInt1 / 371293;
    int j = paramInt1 % 371293;
    String str1 = new String();
    String str2 = new String(" kicker");
    String str3 = new String(", ");
    int k = j / 28561;
    int m = j / 2197 % 13;
    int n = j / 169 % 13;
    int i1 = j / 13 % 13;
    int i2 = j % 13;
    System.out.println("k = [" + k + " " + m + " " + n + " " + i1 + " " + i2 + "]");
    switch (i)
    {
    case 0:
      str1 = L[k] + " High";
      if (paramInt2 > 1)
        str1 = str1 + str3 + L[m];
      if (paramInt2 > 2)
        str1 = str1 + ", " + L[n];
      if (paramInt2 > 3)
        str1 = str1 + ", " + L[i1];
      if (paramInt2 > 4)
        str1 = str1 + ", " + L[i2];
      if (paramInt2 > 1)
        str1 = str1 + str2;
      break;
    case 1:
      str1 = "a Pair of " + E[m];
      if (paramInt2 > 2)
        str1 = str1 + str3 + L[n];
      if (paramInt2 > 3)
        str1 = str1 + ", " + L[i1];
      if (paramInt2 > 4)
        str1 = str1 + ", " + L[i2];
      if (paramInt2 > 2)
        str1 = str1 + str2;
      break;
    case 2:
      str1 = "Two Pair, " + E[n] + " and " + E[i1];
      if (paramInt2 > 4)
        str1 = str1 + str3 + L[i2] + str2;
      break;
    case 3:
      str1 = "Three of a Kind, " + E[n];
      if (paramInt2 > 3)
        str1 = str1 + str3 + L[i1];
      if (paramInt2 > 4)
        str1 = str1 + ", " + L[i2];
      if (paramInt2 > 3)
        str1 = str1 + str2;
      break;
    case 4:
      if ((i2 == 6) || (i2 == 12))
        str1 = "an " + L[i2] + " High Straight";
      else
        str1 = "a " + L[i2] + " High Straight";
      break;
    case 5:
      str1 = "a Flush, " + L[k] + " High";
      if (paramInt2 > 1)
        str1 = str1 + str3 + L[m];
      if (paramInt2 > 2)
        str1 = str1 + ", " + L[n];
      if (paramInt2 > 3)
        str1 = str1 + ", " + L[i1];
      if (paramInt2 > 4)
        str1 = str1 + ", " + L[i2];
      if (paramInt2 > 1)
        str1 = str1 + str2;
      break;
    case 6:
      str1 = "a Full House, " + E[i1] + " over " + E[i2];
      break;
    case 7:
      str1 = "Four of a Kind, " + E[i1];
      if (paramInt2 > 4)
        str1 = str1 + str3 + L[i2] + str2;
      break;
    case 8:
      if (i2 == 6)
        str1 = "an " + L[i2] + " High Straight Flush";
      else if (i2 == 12)
        str1 = "a Royal Flush";
      else
        str1 = "a " + L[i2] + " High Straight Flush";
      break;
    case 9:
      str1 = "Five of a Kind, " + E[i2];
      break;
    default:
      str1 = B[i];
    }
    return str1;
  }

  public static int D(int paramInt1, int paramInt2)
  {
    int i = paramInt1 / 371293;
    int j = paramInt2 / 371293;
    if (i != j)
      return 0;
    if (paramInt1 / 28561 != paramInt2 / 28561)
      return 1;
    if (paramInt1 / 2197 != paramInt2 / 2197)
      return 2;
    if (paramInt1 / 169 != paramInt2 / 169)
      return 3;
    if (paramInt1 / 13 != paramInt2 / 13)
      return 4;
    if (paramInt1 != paramInt2)
      return 5;
    return -1;
  }

  public static int E(int paramInt1, int paramInt2)
  {
    int i = 5;
    int[] arrayOfInt1 = new int[i];
    int[] arrayOfInt2 = new int[i];
    int j = paramInt1 / 371293;
    int k = paramInt2 / 371293;
    if (j != k)
      return -1;
    for (int m = 0; m < i; m++)
    {
      arrayOfInt1[m] = (paramInt1 / A(13, i - (m + 1)) % 13);
      arrayOfInt2[m] = (paramInt2 / A(13, i - (m + 1)) % 13);
      if (arrayOfInt1[m] != arrayOfInt2[m])
        return m;
    }
    return -1;
  }

  public static String C(int paramInt1, int paramInt2)
  {
    int i = paramInt1 / 371293;
    int j = paramInt1 % 371293;
    int k = 5;
    int[] arrayOfInt = new int[k];
    String str1 = new String();
    String str2 = new String(" kicker");
    String str3 = new String(", ");
    for (int m = 0; m < k; m++)
      arrayOfInt[m] = (j / A(13, k - (m + 1)) % 13);
    m = 0;
    switch (i)
    {
    case 0:
      m = paramInt2 > 0 ? 1 : 0;
      break;
    case 1:
      m = paramInt2 > 1 ? 1 : 0;
      break;
    case 2:
      m = paramInt2 > 3 ? 1 : 0;
      break;
    case 3:
      m = paramInt2 > 2 ? 1 : 0;
      break;
    case 4:
      break;
    case 5:
      m = paramInt2 > 0 ? 1 : 0;
      break;
    case 6:
      break;
    case 7:
      m = k > 4 ? 1 : 0;
      break;
    case 8:
      break;
    case 9:
    }
    Object[] arrayOfObject = { A(paramInt1), L[arrayOfInt[paramInt2]] };
    return m != 0 ? E.A("UofAHandEval.HandNameWithKickerPattern", arrayOfObject) : A(paramInt1);
  }

  public static String C(Card paramCard1, Card paramCard2, Hand paramHand)
  {
    System.out.println("Naming hand with two hole cards");
    Hand localHand = new Hand(paramHand);
    localHand.addCard(paramCard1);
    localHand.addCard(paramCard2);
    return A(C(localHand));
  }

  public static String B(Hand paramHand)
  {
    return A(C(paramHand));
  }

  public int B(Card paramCard1, Card paramCard2, Hand paramHand)
  {
    paramHand.addCard(paramCard1);
    paramHand.addCard(paramCard2);
    int i = C(paramHand);
    paramHand.removeCard();
    paramHand.removeCard();
    return i;
  }

  public int rankHand(Hand paramHand)
  {
    return C(paramHand);
  }

  public int rankHand7(Hand paramHand)
  {
    return C(paramHand);
  }

  public int rankHand6(Hand paramHand)
  {
    return C(paramHand);
  }

  public int rankHand5(Hand paramHand)
  {
    return C(paramHand);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.K.D
 * JD-Core Version:    0.6.2
 */