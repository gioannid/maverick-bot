package com.biotools.poker.K;

import com.biotools.poker.E;
import com.biotools.poker.PokerApp;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

public class G extends JMenuBar
{
  F C;
  JMenu B = new JMenu(E.D("HandEvalMenu.File"));
  JMenu A = new JMenu(E.D("HandEvalMenu.Help"));

  public G(F paramF)
  {
    this.C = paramF;
    add(B());
    add(A());
  }

  protected JMenu B()
  {
    this.B.add(E());
    this.B.add(C());
    return this.B;
  }

  protected JMenu A()
  {
    this.A.add(D());
    return this.A;
  }

  protected KeyStroke A(int paramInt)
  {
    return KeyStroke.getKeyStroke(paramInt, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask());
  }

  protected JMenuItem E()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("HandEvalMenu.Close"), 67);
    localJMenuItem.setAccelerator(A(87));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        G.this.C.m();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem C()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("HandEvalMenu.QuitProgram"), 81);
    localJMenuItem.setAccelerator(A(81));
    localJMenuItem.setToolTipText(E.D("HandEvalMenu.QuitProgramToolTip"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        PokerApp.Ȅ().ʠ();
      }
    });
    return localJMenuItem;
  }

  protected JMenuItem D()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("HandEvalMenu.Help"), 72);
    localJMenuItem.setAccelerator(A(47));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        G.this.C.e();
      }
    });
    return localJMenuItem;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.K.G
 * JD-Core Version:    0.6.2
 */