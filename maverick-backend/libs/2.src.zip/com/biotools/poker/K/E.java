package com.biotools.poker.K;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.Hand;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.text.DecimalFormat;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class E extends JPanel
{
  private static final Color C = new Color(240, 240, 255);
  protected static final DecimalFormat B = new DecimalFormat(com.biotools.poker.E.D("OppHandTable.DecimalFormat"));
  protected JTable E = new JTable()
  {
    public Component prepareRenderer(TableCellRenderer paramAnonymousTableCellRenderer, int paramAnonymousInt1, int paramAnonymousInt2)
    {
      Component localComponent = super.prepareRenderer(paramAnonymousTableCellRenderer, paramAnonymousInt1, paramAnonymousInt2);
      if (paramAnonymousInt1 % 2 != 0)
        localComponent.setBackground(Color.WHITE);
      else
        localComponent.setBackground(E.C);
      if (getSelectedRow() == paramAnonymousInt1)
        localComponent.setBackground(localComponent.getBackground().darker());
      return localComponent;
    }
  };
  protected _A A = new _A();
  protected C F;
  protected C D;

  public E()
  {
    this.E.setDragEnabled(false);
    this.E.setEnabled(false);
    JScrollPane localJScrollPane = new JScrollPane(this.E);
    localJScrollPane.getViewport().setBackground(Color.WHITE);
    localJScrollPane.setPreferredSize(new Dimension(200, 200));
    setLayout(new BorderLayout());
    add(localJScrollPane, "Center");
  }

  public void A()
  {
    this.E.setModel(new DefaultTableModel());
  }

  private void B()
  {
    TableColumnModel localTableColumnModel = this.E.getColumnModel();
    DefaultTableCellRenderer localDefaultTableCellRenderer = new DefaultTableCellRenderer();
    for (int i = 1; i < localTableColumnModel.getColumnCount(); i++)
    {
      TableColumn localTableColumn = localTableColumnModel.getColumn(i);
      localDefaultTableCellRenderer.setHorizontalAlignment(4);
      localTableColumn.setCellRenderer(localDefaultTableCellRenderer);
    }
  }

  public void A(Card paramCard1, Card paramCard2, Hand paramHand, com.biotools.poker.D.E paramE)
  {
    if ((paramHand.size() >= 3) && (paramHand.size() <= 5))
    {
      this.F = new C(paramCard1, paramCard2, paramHand);
      this.F.E();
      this.D = new C(paramCard1, paramCard2, paramHand);
      this.D.A(paramE);
      this.E.setModel(this.A);
    }
    else
    {
      this.F = null;
      this.D = null;
      A();
    }
    B();
    this.A.fireTableDataChanged();
  }

  public class _A extends AbstractTableModel
  {
    private String[] A = { com.biotools.poker.E.D("OppHandTable.Hand"), com.biotools.poker.E.D("OppHandTable.Uniform"), com.biotools.poker.E.D("OppHandTable.Biased") };

    public _A()
    {
    }

    public String[] A()
    {
      return this.A;
    }

    public String getColumnName(int paramInt)
    {
      return A()[paramInt].toString();
    }

    public int getRowCount()
    {
      return 10;
    }

    public int getColumnCount()
    {
      return A().length;
    }

    public Object getValueAt(int paramInt1, int paramInt2)
    {
      double d = 0.0D;
      switch (paramInt2)
      {
      case 0:
        return C.I[paramInt1];
      case 1:
        if (E.this.F == null)
          return " ";
        d = E.this.F.I(paramInt1);
        if (d == 0.0D)
          return " ";
        return E.B.format(d);
      case 2:
        if (E.this.D == null)
          return " ";
        d = E.this.D.I(paramInt1);
        if (d == 0.0D)
          return " ";
        return E.B.format(d);
      }
      return "";
    }

    public Class getColumnClass(int paramInt)
    {
      return getValueAt(0, paramInt).getClass();
    }

    public boolean isCellEditable(int paramInt1, int paramInt2)
    {
      return false;
    }

    public void setValueAt(Object paramObject, int paramInt1, int paramInt2)
    {
      fireTableCellUpdated(paramInt1, paramInt2);
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.K.E
 * JD-Core Version:    0.6.2
 */