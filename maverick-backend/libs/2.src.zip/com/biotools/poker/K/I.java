package com.biotools.poker.K;

import com.biotools.A.b;
import com.biotools.meerkat.Card;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.PrintStream;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;

public class I extends JComponent
  implements MouseListener, MouseMotionListener
{
  private com.biotools.poker.D.E B;
  private int C = 14;
  private boolean E = false;
  private int A = -1;
  private int D = -1;

  public static I A(com.biotools.poker.D.E paramE, int paramInt, String paramString)
  {
    JFrame localJFrame = new JFrame(paramString);
    I localI = new I(paramE, paramInt);
    localJFrame.getContentPane().add(localI);
    localJFrame.pack();
    localJFrame.setVisible(true);
    return localI;
  }

  public I(com.biotools.poker.D.E paramE, int paramInt)
  {
    this.B = paramE;
    this.C = paramInt;
    Dimension localDimension = new Dimension(this.C * 14, this.C * 15);
    setPreferredSize(localDimension);
    setBorder(new EmptyBorder(3, 3, 3, 3));
    addMouseMotionListener(this);
    addMouseListener(this);
  }

  public void A()
  {
    Timer localTimer = new Timer(1000, new I.1(this));
    localTimer.setRepeats(true);
    localTimer.start();
  }

  public void A(com.biotools.poker.D.E paramE)
  {
    this.B = paramE;
  }

  public void update(Graphics paramGraphics)
  {
    paint(paramGraphics);
  }

  public void paint(Graphics paramGraphics)
  {
    if (this.B == null)
      return;
    double d1 = 1.0D / this.B.E();
    for (int j = 0; j < 13; j++)
    {
      paramGraphics.setFont(new Font("Arial", 0, 9));
      paramGraphics.setColor(Color.black);
      int i = (Card.useTwoCharsFor10) && (j == 8) ? 2 : 0;
      paramGraphics.drawString(Card.getExpandedRankString(j), 5 + (12 - j) * this.C - i, 14 * this.C - 5);
      paramGraphics.drawString(Card.getExpandedRankString(j), 14 * this.C - 10 - i, (12 - j + 1) * this.C - 3);
      for (int k = 0; k < 13; k++)
      {
        double d2 = 1.0D - A(j, k, d1);
        try
        {
          paramGraphics.setColor(new Color((int)(255.0D * d2), (int)(255.0D * d2), (int)(255.0D * d2)));
        }
        catch (Exception localException)
        {
          System.err.println("* Error: Bad Color Value in table: " + d2);
          paramGraphics.setColor(Color.red);
        }
        paramGraphics.fillRect((12 - j) * this.C, (12 - k) * this.C, this.C, this.C);
        if (d2 == 0.0D)
        {
          paramGraphics.setColor(Color.red);
          paramGraphics.fillRect((6 - j) * this.C, (6 - k) * this.C, this.C, this.C);
        }
      }
    }
    for (j = 0; j < 13; j++)
    {
      paramGraphics.setColor(Color.gray);
      paramGraphics.drawRect(j * this.C, j * this.C, this.C - 1, this.C - 1);
    }
    if ((this.A != -1) && (this.D != -1) && (this.A < 13) && (this.D < 13))
    {
      paramGraphics.setColor(Color.red);
      paramGraphics.drawRect(this.A * this.C + 1, this.D * this.C + 1, this.C - 2, this.C - 2);
      String str = null;
      Object[] arrayOfObject = { Card.getExpandedRankString(12 - this.D), Card.getExpandedRankString(12 - this.A), new Double(b.A(A(12 - this.A, 12 - this.D, d1), 3)) };
      if (this.A > this.D)
        str = com.biotools.poker.E.A("WeightTableView.SuitedPattern", arrayOfObject);
      else if (this.A < this.D)
        str = com.biotools.poker.E.A("WeightTableView.OffsuitPattern", arrayOfObject);
      else
        str = com.biotools.poker.E.A("WeightTableView.PairPattern", arrayOfObject);
      paramGraphics.setColor(Color.black);
      paramGraphics.setFont(new Font("Arial", 1, 12));
      FontMetrics localFontMetrics = paramGraphics.getFontMetrics();
      paramGraphics.drawString(str, (13 * this.C - localFontMetrics.stringWidth(str)) / 2, 14 * this.C + 8);
    }
    paramGraphics.setColor(Color.black);
    paramGraphics.drawRect(0, 0, this.C * 13 - 1, this.C * 13 - 1);
  }

  private double A(int paramInt1, int paramInt2, double paramDouble)
  {
    double d2 = 0.0D;
    int i;
    double d1;
    if (paramInt1 < paramInt2)
    {
      if (this.E)
      {
        for (i = 0; i < 4; i++)
        {
          d1 = paramDouble * this.B.A(new Card(paramInt1, i), new Card(paramInt2, i));
          if (d1 > d2)
            d2 = d1;
        }
      }
      else
      {
        for (i = 0; i < 4; i++)
          d2 += paramDouble * this.B.A(new Card(paramInt1, i), new Card(paramInt2, i));
        d2 /= 4.0D;
      }
    }
    else
    {
      d2 = 0.0D;
      if (paramInt1 != paramInt2)
      {
        int j;
        if (this.E)
        {
          for (i = 0; i < 4; i++)
            for (j = 0; j < 4; j++)
              if (i != j)
              {
                d1 = paramDouble * this.B.A(new Card(paramInt1, i), new Card(paramInt2, j));
                if (d1 > d2)
                  d2 = d1;
              }
        }
        else
        {
          for (i = 0; i < 4; i++)
            for (j = 0; j < 4; j++)
              if (i != j)
                d2 += paramDouble * this.B.A(new Card(paramInt1, i), new Card(paramInt2, j));
          d2 /= 12.0D;
        }
      }
      else if (this.E)
      {
        d1 = paramDouble * this.B.A(new Card(paramInt1, 1), new Card(paramInt2, 2));
        if (d1 > d2)
          d2 = d1;
        d1 = paramDouble * this.B.A(new Card(paramInt1, 3), new Card(paramInt2, 2));
        if (d1 > d2)
          d2 = d1;
        d1 = paramDouble * this.B.A(new Card(paramInt1, 0), new Card(paramInt2, 2));
        if (d1 > d2)
          d2 = d1;
        d1 = paramDouble * this.B.A(new Card(paramInt1, 3), new Card(paramInt2, 1));
        if (d1 > d2)
          d2 = d1;
        d1 = paramDouble * this.B.A(new Card(paramInt1, 0), new Card(paramInt2, 1));
        if (d1 > d2)
          d2 = d1;
        d1 = paramDouble * this.B.A(new Card(paramInt1, 3), new Card(paramInt2, 0));
        if (d1 > d2)
          d2 = d1;
      }
      else
      {
        d2 += paramDouble * this.B.A(new Card(paramInt1, 1), new Card(paramInt2, 2));
        d2 += paramDouble * this.B.A(new Card(paramInt1, 3), new Card(paramInt2, 2));
        d2 += paramDouble * this.B.A(new Card(paramInt1, 0), new Card(paramInt2, 2));
        d2 += paramDouble * this.B.A(new Card(paramInt1, 3), new Card(paramInt2, 1));
        d2 += paramDouble * this.B.A(new Card(paramInt1, 0), new Card(paramInt2, 1));
        d2 += paramDouble * this.B.A(new Card(paramInt1, 3), new Card(paramInt2, 0));
        d2 /= 6.0D;
      }
    }
    return d2;
  }

  public void mouseMoved(MouseEvent paramMouseEvent)
  {
    this.A = (paramMouseEvent.getX() / this.C);
    this.D = (paramMouseEvent.getY() / this.C);
    repaint();
  }

  public void mouseExited(MouseEvent paramMouseEvent)
  {
    this.A = (this.D = -1);
    repaint();
  }

  public void mouseClicked(MouseEvent paramMouseEvent)
  {
  }

  public void mouseEntered(MouseEvent paramMouseEvent)
  {
  }

  public void mouseDragged(MouseEvent paramMouseEvent)
  {
  }

  public void mousePressed(MouseEvent paramMouseEvent)
  {
  }

  public void mouseReleased(MouseEvent paramMouseEvent)
  {
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.K.I
 * JD-Core Version:    0.6.2
 */