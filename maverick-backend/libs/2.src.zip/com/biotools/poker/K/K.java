package com.biotools.poker.K;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.Hand;
import com.biotools.poker.E;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.text.DecimalFormat;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class K extends JPanel
{
  private static final Color C = new Color(240, 240, 255);
  protected static final DecimalFormat F = new DecimalFormat(E.D("HandDrawTable.DecimalFormat"));
  protected JTable I = new JTable()
  {
    public Component prepareRenderer(TableCellRenderer paramAnonymousTableCellRenderer, int paramAnonymousInt1, int paramAnonymousInt2)
    {
      Component localComponent = super.prepareRenderer(paramAnonymousTableCellRenderer, paramAnonymousInt1, paramAnonymousInt2);
      if (paramAnonymousInt1 % 2 != 0)
        localComponent.setBackground(Color.WHITE);
      else
        localComponent.setBackground(K.C);
      if (getSelectedRow() == paramAnonymousInt1)
        localComponent.setBackground(localComponent.getBackground().darker());
      return localComponent;
    }
  };
  protected _A E = new _A();
  protected C D;
  protected C G;
  protected C J;
  protected int A = -1;
  protected int H = -1;
  protected int B = -1;

  public K()
  {
    this.I.setDragEnabled(false);
    this.I.setEnabled(false);
    JScrollPane localJScrollPane = new JScrollPane(this.I);
    localJScrollPane.getViewport().setBackground(Color.WHITE);
    localJScrollPane.setPreferredSize(new Dimension(200, 200));
    setLayout(new BorderLayout());
    add(localJScrollPane, "Center");
  }

  public void A()
  {
    this.I.setModel(new DefaultTableModel());
  }

  private void B()
  {
    TableColumnModel localTableColumnModel = this.I.getColumnModel();
    DefaultTableCellRenderer localDefaultTableCellRenderer = new DefaultTableCellRenderer();
    for (int i = 1; i < localTableColumnModel.getColumnCount(); i++)
    {
      TableColumn localTableColumn = localTableColumnModel.getColumn(i);
      localDefaultTableCellRenderer.setHorizontalAlignment(4);
      localTableColumn.setCellRenderer(localDefaultTableCellRenderer);
    }
  }

  public void A(Card paramCard1, Card paramCard2, Hand paramHand)
  {
    Hand localHand1;
    switch (paramHand.size())
    {
    case 0:
      this.D = new C(paramCard1, paramCard2);
      this.A = (this.H = this.B = -1);
      this.G = (this.J = null);
      break;
    case 3:
      this.A = C.A(paramCard1, paramCard2, paramHand);
      this.H = (this.B = -1);
      this.D = null;
      this.G = new C(paramCard1, paramCard2, paramHand);
      this.G.J(1);
      this.J = new C(paramCard1, paramCard2, paramHand);
      this.J.J(2);
      break;
    case 4:
      localHand1 = new Hand(paramHand);
      localHand1.removeCard(4);
      this.A = C.A(paramCard1, paramCard2, localHand1);
      this.H = C.A(paramCard1, paramCard2, paramHand);
      this.B = -1;
      this.D = (this.G = null);
      this.J = new C(paramCard1, paramCard2, paramHand);
      this.J.J(1);
      break;
    case 5:
      Hand localHand2 = new Hand(paramHand);
      localHand2.removeCard(5);
      localHand1 = new Hand(localHand2);
      localHand1.removeCard(4);
      this.D = (this.G = this.J = null);
      this.A = C.A(paramCard1, paramCard2, localHand1);
      this.H = C.A(paramCard1, paramCard2, localHand2);
      this.B = C.A(paramCard1, paramCard2, paramHand);
      break;
    case 1:
    case 2:
    default:
      this.A = (this.H = this.B = -1);
      this.D = (this.G = this.J = null);
      A();
    }
    this.I.setModel(this.E);
    B();
    this.E.fireTableDataChanged();
  }

  public class _A extends AbstractTableModel
  {
    private String[] A = { E.D("HandDrawTable.Hand"), E.D("HandDrawTable.Flop"), E.D("HandDrawTable.Turn"), E.D("HandDrawTable.River") };

    public _A()
    {
    }

    public String[] A()
    {
      return this.A;
    }

    public String getColumnName(int paramInt)
    {
      return A()[paramInt].toString();
    }

    public int getRowCount()
    {
      return 10;
    }

    public int getColumnCount()
    {
      return A().length;
    }

    public Object getValueAt(int paramInt1, int paramInt2)
    {
      double d = 0.0D;
      switch (paramInt2)
      {
      case 0:
        return C.I[paramInt1];
      case 1:
        if (K.this.A == paramInt1)
          return " * ";
        if (K.this.D != null)
          d = K.this.D.C(paramInt1);
        if (d == 0.0D)
          return " ";
        return K.F.format(d);
      case 2:
        if (K.this.H == paramInt1)
          return " * ";
        if (K.this.D != null)
        {
          d = K.this.D.E(paramInt1);
        }
        else
        {
          if (K.this.G == null)
            return " ";
          d = K.this.G.F(paramInt1);
        }
        if (d == 0.0D)
          return " ";
        return K.F.format(d);
      case 3:
        if (K.this.B == paramInt1)
          return " * ";
        if (K.this.D != null)
        {
          d = K.this.D.B(paramInt1);
        }
        else
        {
          if (K.this.J == null)
            return " ";
          d = K.this.J.F(paramInt1);
        }
        if (d == 0.0D)
          return " ";
        return K.F.format(d);
      }
      return "";
    }

    public Class getColumnClass(int paramInt)
    {
      return getValueAt(0, paramInt).getClass();
    }

    public boolean isCellEditable(int paramInt1, int paramInt2)
    {
      return false;
    }

    public void setValueAt(Object paramObject, int paramInt1, int paramInt2)
    {
      fireTableCellUpdated(paramInt1, paramInt2);
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.K.K
 * JD-Core Version:    0.6.2
 */