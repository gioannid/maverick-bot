package com.biotools.poker.K;

import com.biotools.A.I;
import com.biotools.B.L;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Hand;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import javax.swing.JComponent;

public class H extends JComponent
{
  private int E = -1;
  private J[] C = new J[9];
  private Thread B;
  private boolean A = false;
  double[][] D = new double[9][8];

  public H()
  {
    for (int i = 0; i < this.C.length; i++)
      this.C[i] = new J();
    setPreferredSize(new Dimension(200, 200));
  }

  public void A()
  {
    this.E = 0;
    for (int i = 0; i < this.C.length; i++)
      this.C[i].B();
    repaint();
  }

  public void paint(Graphics paramGraphics)
  {
    int i = 12;
    int j = getWidth() - i * 2;
    int k = getHeight() - i * 5;
    int m = j / this.C.length;
    int n = (getWidth() - this.C.length * m) / 2;
    paramGraphics.setColor(getBackground());
    paramGraphics.fillRect(0, 0, getWidth(), getHeight());
    paramGraphics.setColor(Color.black);
    paramGraphics.setFont(new Font("Sans Serif", 1, 11));
    FontMetrics localFontMetrics = paramGraphics.getFontMetrics();
    String str = com.biotools.poker.E.D("HandStrengthGraph.NumberOfOpponents");
    int i1 = localFontMetrics.stringWidth(str);
    paramGraphics.drawString(str, n + j / 2 - i1 / 2, k + localFontMetrics.getHeight() + i * 3 + 3);
    int i2 = 0;
    for (int i3 = 0; i3 < this.C.length; i3++)
      i2 += this.C[i3].C();
    Object[] arrayOfObject = { new Integer(i2) };
    str = com.biotools.poker.E.A("HandStrengthGraph.BasedOnSimulationTrialsPattern", arrayOfObject);
    i1 = localFontMetrics.stringWidth(str);
    paramGraphics.drawString(str, n + j / 2 - i1 / 2, i * 1);
    paramGraphics.setColor(Color.LIGHT_GRAY);
    paramGraphics.drawRect(n - 3, i * 2 - 3, m * 9 + 6, k + 6);
    for (int i4 = 0; i4 < this.C.length; i4++)
    {
      double d1 = A(i4);
      if (d1 > 0.0D)
      {
        double d2 = 0.0D;
        for (int i5 = 0; i5 < this.D[i4].length; i5++)
          if (Math.abs(this.D[i4][i5] - this.C[i4].A()) > 0.0001D)
            d2 += 1.0D / this.D[i4].length;
        paramGraphics.setColor(new Color((int)(170.0D * d2) + 80, 120, 80));
        if (i4 == this.E)
          paramGraphics.setColor(paramGraphics.getColor().brighter());
        paramGraphics.fill3DRect(n + m * i4, k - (int)(d1 * k) + i * 2, m, (int)(d1 * k), true);
        str = Integer.toString(i4 + 1);
        i1 = localFontMetrics.stringWidth(str);
        paramGraphics.setColor(Color.black);
        paramGraphics.drawString(str, n + m * i4 + m / 2 - i1 / 2, i * 2 + k + localFontMetrics.getHeight());
        str = (int)Math.round(d1 * 100.0D) + "%";
        i1 = localFontMetrics.stringWidth(str);
        paramGraphics.setColor(Color.black);
        paramGraphics.drawString(str, n + m * i4 + m / 2 - i1 / 2, k - (int)(d1 * k) + i * 2 - 3);
      }
    }
  }

  public void A(Card paramCard1, Card paramCard2, Hand paramHand, com.biotools.poker.D.E paramE, int paramInt)
  {
    for (int i = 0; i < this.C.length; i++)
    {
      for (int j = 0; j < this.D[i].length; j++)
        this.D[i][j] = -1.0D;
      this.E = paramInt;
      this.C[i].A(i + 1, paramE, paramCard1, paramCard2, paramHand);
    }
    if (this.B == null)
      C();
  }

  private double A(int paramInt)
  {
    double d = this.C[paramInt].A();
    if (Double.isNaN(d))
      return 0.0D;
    if (this.C[paramInt].C() < 1000)
      return 0.0D;
    return d;
  }

  private void C()
  {
    this.B = new Thread("Equity Thread")
    {
      public void run()
      {
        while (!H.this.A)
          try
          {
            H.this.B();
          }
          catch (Exception localException)
          {
            I.A("Error in Equity Thread", localException);
          }
      }
    };
    this.B.setPriority(1);
    this.B.start();
  }

  private void B()
  {
    for (int i = 0; i < this.C.length; i++)
    {
      double d = this.C[i].A();
      int j = this.C[i].C() < 10000 * (i + 1) ? 1 : 0;
      for (int k = 0; k < this.D[i].length - 1; k++)
      {
        if (Math.abs(this.D[i][k] - d) > 0.0001D)
          j = 1;
        this.D[i][k] = this.D[i][(k + 1)];
      }
      this.D[i][(this.D[i].length - 1)] = d;
      if (j != 0)
        this.C[i].A(500);
    }
    repaint();
    L.C(isShowing() ? 50 : 500);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.K.H
 * JD-Core Version:    0.6.2
 */