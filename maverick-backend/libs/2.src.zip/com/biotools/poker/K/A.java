package com.biotools.poker.K;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.meerkat.util.NChoose2IntTable;
import com.biotools.poker.A.J;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import javax.swing.JComponent;

public class A extends JComponent
{
  private com.biotools.poker.D.E A = new com.biotools.poker.D.E();
  private double[] G;
  private double F;
  private int E = -1;
  private Hand D = null;
  private String C = "";
  private com.biotools.poker.D.E B = new com.biotools.poker.D.E();
  private Deck H = new Deck();

  public A()
  {
  }

  public void A(double paramDouble)
  {
    this.F = paramDouble;
    repaint();
  }

  public void A(com.biotools.poker.D.E paramE)
  {
    this.A = paramE;
  }

  public A(double paramDouble, Hand paramHand)
  {
    A(paramDouble, paramHand);
    repaint();
  }

  public void A()
  {
    this.G = null;
    repaint();
  }

  public void A(double paramDouble, Hand paramHand)
  {
    this.F = paramDouble;
    this.D = paramHand;
    if (paramHand.size() == 0)
      this.G = null;
    else
      this.G = A(paramHand);
    repaint();
  }

  public void paint(Graphics paramGraphics)
  {
    int i = 7;
    int j = getWidth() - i * 2;
    int k = getHeight() - i * 4;
    if (this.G == null)
      return;
    this.E = (j / 4);
    if (this.E != this.G.length)
      this.G = A(this.D);
    if (this.G == null)
      return;
    int m = j / this.G.length;
    int n = (getWidth() - this.G.length * m) / 2;
    paramGraphics.setColor(getBackground());
    paramGraphics.fillRect(0, 0, getWidth(), getHeight());
    paramGraphics.setColor(Color.black);
    paramGraphics.setFont(new Font("Sans Serif", 0, 10));
    FontMetrics localFontMetrics = paramGraphics.getFontMetrics();
    String str = com.biotools.poker.E.D("HandHistogram.OpponenthandStrengths");
    int i1 = localFontMetrics.stringWidth(str);
    paramGraphics.drawString(str, n + j / 2 - i1 / 2, k + localFontMetrics.getHeight() + 5);
    paramGraphics.drawString(com.biotools.poker.E.D("HandHistogram.0Percent"), n, k + localFontMetrics.getHeight() + 2);
    paramGraphics.drawString(com.biotools.poker.E.D("HandHistogram.100Percent"), n + j - localFontMetrics.stringWidth(com.biotools.poker.E.D("HandHistogram.100Percent")), k + localFontMetrics.getHeight() + 2);
    for (int i2 = 0; i2 < this.G.length; i2++)
      if (this.G[i2] > 0.0D)
      {
        int i3 = i2 / this.G.length > this.F ? 200 : 80;
        paramGraphics.setColor(new Color(i3, 80, 80));
        paramGraphics.fill3DRect(n + m * i2, k - (int)(this.G[i2] * k) + i, m, (int)(this.G[i2] * k), true);
      }
  }

  public synchronized double[] A(Hand paramHand)
  {
    if (this.E < 0)
      this.E = 46;
    double[] arrayOfDouble = new double[this.E];
    this.H.reset();
    this.H.extractHand(paramHand);
    this.D = paramHand;
    if (!paramHand.toString().equals(this.C))
    {
      this.C = paramHand.toString();
      NChoose2IntTable localNChoose2IntTable = HandEvaluator.getRanks(paramHand);
      for (int j = this.H.getTopCardIndex(); j < 52; j++)
      {
        Card localCard2 = this.H.getCard(j);
        for (int m = j + 1; m < 52; m++)
        {
          Card localCard4 = this.H.getCard(m);
          double d2 = J.A(localCard2, localCard4, localNChoose2IntTable, this.H);
          if (d2 == 1.0D)
            d2 -= 1.0E-006D;
          this.B.A(localCard2, localCard4, d2);
        }
      }
    }
    for (int i = this.H.getTopCardIndex(); i < 52; i++)
    {
      Card localCard1 = this.H.getCard(i);
      for (int k = i + 1; k < 52; k++)
      {
        Card localCard3 = this.H.getCard(k);
        double d1 = this.B.A(localCard1, localCard3);
        arrayOfDouble[((int)(d1 * arrayOfDouble.length))] += this.A.A(localCard1, localCard3);
      }
    }
    J.A(arrayOfDouble);
    return arrayOfDouble;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.K.A
 * JD-Core Version:    0.6.2
 */