package com.biotools.poker.K;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.HandEvaluator;
import com.biotools.poker.D.E;

public class J
{
  private int[][] H;
  private double L;
  private double D = 0.0D;
  private double J = 0.0D;
  private E E;
  private Deck G = new Deck();
  private Deck A = new Deck();
  private int I;
  private Hand F;
  private int C;
  private int B;
  private int K = 0;

  public void B()
  {
    this.D = 0.0D;
    this.J = 0.0D;
    this.K = 0;
    this.L = 0.0D;
  }

  public double A()
  {
    return this.D / this.J;
  }

  public synchronized void A(int paramInt, E paramE, Card paramCard1, Card paramCard2, Hand paramHand)
  {
    this.J = (this.D = 0.0D);
    this.K = 0;
    this.F = paramHand;
    this.E = paramE;
    this.C = paramCard1.getIndex();
    this.B = paramCard2.getIndex();
    this.H = new int[paramInt][2];
    this.L = this.E.E();
    this.G.reset();
    this.G.extractCard(this.C);
    this.G.extractCard(this.B);
    this.G.extractHand(paramHand);
    this.I = (5 - paramHand.size());
  }

  public synchronized void A(int paramInt)
  {
    while (paramInt-- > 0)
    {
      this.A.copy(this.G);
      for (int i = 0; i < this.I; i++)
        this.F.addCard(this.A.dealCard().getIndex());
      double d = 1.0D;
      for (int j = 0; j < this.H.length; j++)
      {
        this.H[j][0] = this.A.dealCard().getIndex();
        this.H[j][1] = this.A.dealCard().getIndex();
        d *= this.E.C(this.H[j][0], this.H[j][1]) / this.L;
      }
      this.D += d * B(this.C, this.B, this.F);
      this.J += d;
      for (j = 0; j < this.I; j++)
        this.F.removeCard();
      this.K += 1;
    }
  }

  protected final double B(int paramInt1, int paramInt2, Hand paramHand)
  {
    int i = 0;
    int j = A(paramInt1, paramInt2, paramHand);
    for (int k = 0; k < this.H.length; k++)
    {
      int m = A(this.H[k][0], this.H[k][1], paramHand);
      if (m > j)
        return 0.0D;
      if (m == j)
        i++;
    }
    return 1.0D / (i + 1);
  }

  protected final int A(int paramInt1, int paramInt2, Hand paramHand)
  {
    paramHand.addCard(paramInt1);
    paramHand.addCard(paramInt2);
    int i = HandEvaluator.rankHand7(paramHand);
    paramHand.removeCard();
    paramHand.removeCard();
    return i;
  }

  public int C()
  {
    return this.K;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.K.J
 * JD-Core Version:    0.6.2
 */