package com.biotools.poker.E;

import com.biotools.meerkat.Player;
import com.biotools.meerkat.util.Preferences;
import javax.swing.JPanel;

public abstract interface D extends Player
{
  public abstract JPanel A();

  public abstract Preferences B();
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.E.D
 * JD-Core Version:    0.6.2
 */