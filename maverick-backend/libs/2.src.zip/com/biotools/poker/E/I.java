package com.biotools.poker.E;

import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.Player;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.InputStream;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.util.Hashtable;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public final class I extends ClassLoader
  implements D
{
  private static Hashtable J = new Hashtable();
  private ZipFile I;
  private Player K;
  private Preferences H;

  public Preferences B()
  {
    return this.H;
  }

  public void init(Preferences paramPreferences)
  {
    this.H = paramPreferences;
    String str1 = paramPreferences.getPreference("PLAYER_JAR_FILE");
    String str2 = paramPreferences.getPreference("BOT_PLAYER_CLASS");
    if ((str1 == null) || (str2 == null))
      return;
    try
    {
      this.I = new ZipFile(str1);
    }
    catch (Exception localException1)
    {
      localException1.printStackTrace();
    }
    this.K = H(str2);
    if (this.K != null)
      try
      {
        this.K.init(paramPreferences);
      }
      catch (Exception localException2)
      {
        this.K = null;
      }
    if (this.K == null)
    {
      Object[] arrayOfObject = { paramPreferences.getFileName() };
      JOptionPane.showMessageDialog(E.É(), E.A("PlugInOpponent.ErrorCouldNotLoadBotPattern", arrayOfObject));
    }
  }

  public Player H(String paramString)
  {
    if (E.Ú())
      return null;
    try
    {
      Class localClass = loadClass(paramString, true);
      return (Player)localClass.newInstance();
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return null;
  }

  protected Class loadClass(String paramString, boolean paramBoolean)
    throws ClassNotFoundException
  {
    if (J.containsKey(paramString))
      return (Class)J.get(paramString);
    if ((paramString.startsWith("com.biotools.")) && (!paramString.startsWith("com.biotools.meerkat.")) && (!paramString.equals("com.biotools.poker.E.D")))
      throw new ClassNotFoundException(paramString);
    if (paramString.startsWith("com.vastmind."))
      throw new ClassNotFoundException(paramString);
    if (paramString.startsWith("ca.spaz."))
      throw new ClassNotFoundException(paramString);
    if ((paramString.matches("com.biotools.meerkat\\..*\\.")) && (!paramString.startsWith("com.biotools.meerkat.util.")))
      throw new ClassNotFoundException(paramString);
    Class localClass = findLoadedClass(paramString);
    if (localClass == null)
      try
      {
        localClass = findSystemClass(paramString);
      }
      catch (Exception localException)
      {
      }
    if ((localClass == null) && (paramString.startsWith("com.biotools.meerkat.")))
      localClass = Class.forName(paramString);
    if (localClass == null)
    {
      if (paramString.startsWith("java."))
        throw new ClassNotFoundException(paramString);
      byte[] arrayOfByte = I(paramString);
      if (arrayOfByte == null)
        System.err.println("Null data: " + paramString);
      else
        localClass = defineClass(paramString, arrayOfByte, 0, arrayOfByte.length);
      if (localClass == null)
        throw new ClassNotFoundException(paramString);
    }
    if (paramBoolean)
      resolveClass(localClass);
    J.put(paramString, localClass);
    return localClass;
  }

  private byte[] I(String paramString)
  {
    try
    {
      paramString = paramString.replaceAll("\\.", "/");
      ZipEntry localZipEntry = this.I.getEntry(paramString + ".class");
      if (localZipEntry == null)
        return null;
      InputStream localInputStream = this.I.getInputStream(localZipEntry);
      byte[] arrayOfByte = new byte[(int)localZipEntry.getSize()];
      BufferedInputStream localBufferedInputStream = new BufferedInputStream(localInputStream);
      DataInputStream localDataInputStream = new DataInputStream(localBufferedInputStream);
      try
      {
        for (int i = 0; i < localZipEntry.getSize(); i++)
          arrayOfByte[i] = localDataInputStream.readByte();
      }
      catch (EOFException localEOFException)
      {
        localEOFException.printStackTrace();
      }
      localDataInputStream.close();
      return arrayOfByte;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return null;
  }

  public JPanel A()
  {
    if (this.K != null)
      try
      {
        Class[] arrayOfClass = new Class[0];
        Method localMethod = this.K.getClass().getMethod("getSettingsPanel", arrayOfClass);
        if (localMethod != null)
        {
          Object[] arrayOfObject = new Object[0];
          JPanel localJPanel = (JPanel)localMethod.invoke(this.K, arrayOfObject);
          if (localJPanel != null)
            return localJPanel;
        }
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
    return new JPanel();
  }

  public void holeCards(Card paramCard1, Card paramCard2, int paramInt)
  {
    if (this.K != null)
      try
      {
        this.K.holeCards(paramCard1, paramCard2, paramInt);
      }
      catch (NoSuchMethodError localNoSuchMethodError)
      {
        localNoSuchMethodError.printStackTrace();
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
    if (this.K != null)
      try
      {
        this.K.actionEvent(paramInt, paramAction);
      }
      catch (NoSuchMethodError localNoSuchMethodError)
      {
        localNoSuchMethodError.printStackTrace();
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
  }

  public void stageEvent(int paramInt)
  {
    if (this.K != null)
      try
      {
        this.K.stageEvent(paramInt);
      }
      catch (NoSuchMethodError localNoSuchMethodError)
      {
        localNoSuchMethodError.printStackTrace();
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
    if (this.K != null)
      try
      {
        this.K.showdownEvent(paramInt, paramCard1, paramCard2);
      }
      catch (NoSuchMethodError localNoSuchMethodError)
      {
        localNoSuchMethodError.printStackTrace();
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    if (this.K != null)
      try
      {
        this.K.gameStartEvent(paramGameInfo);
      }
      catch (NoSuchMethodError localNoSuchMethodError)
      {
        localNoSuchMethodError.printStackTrace();
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
  }

  public void gameOverEvent()
  {
    if (this.K != null)
      try
      {
        this.K.gameOverEvent();
      }
      catch (NoSuchMethodError localNoSuchMethodError)
      {
        localNoSuchMethodError.printStackTrace();
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
    if (this.K != null)
      try
      {
        this.K.winEvent(paramInt, paramDouble, paramString);
      }
      catch (NoSuchMethodError localNoSuchMethodError)
      {
        localNoSuchMethodError.printStackTrace();
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
  }

  public void gameStateChanged()
  {
    if (this.K != null)
      try
      {
        this.K.gameStateChanged();
      }
      catch (NoSuchMethodError localNoSuchMethodError)
      {
        localNoSuchMethodError.printStackTrace();
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
  }

  public Action getAction()
  {
    if (this.K != null)
      try
      {
        return this.K.getAction();
      }
      catch (NoSuchMethodError localNoSuchMethodError)
      {
        localNoSuchMethodError.printStackTrace();
      }
      catch (Exception localException)
      {
        Object[] arrayOfObject = { this.H.getFileName() };
        JOptionPane.showMessageDialog(E.É(), E.A("PlugInOpponent.ErrorPluginBotFailurePattern", arrayOfObject));
        localException.printStackTrace();
      }
    return null;
  }

  public void dealHoleCardsEvent()
  {
    if (this.K != null)
      try
      {
        this.K.dealHoleCardsEvent();
      }
      catch (NoSuchMethodError localNoSuchMethodError)
      {
        localNoSuchMethodError.printStackTrace();
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.E.I
 * JD-Core Version:    0.6.2
 */