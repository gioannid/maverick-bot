package com.biotools.poker.E;

import com.biotools.A.F;
import com.biotools.A.a;
import com.biotools.A.d;
import com.biotools.B.L;
import com.biotools.poker.PokerApp;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class E extends AbstractTableModel
  implements Comparable
{
  private static final String[] F = { "Alice Ace", "Betsy", "Daniel", "Fido", "Shiva", "Kramer", "Ripley", "Churchill", "Lester", "Sasquatch", "OgoPogo", "Vulcan", "Magoo", "Nessie", "Gordon", "Deuce", "Dirk", "Sally", "Carter", "Clinton", "Aubrey", "Thor", "Zeus", "Marla Singer", "Tyler Durden", "Lebowski", "Sonya", "Theodore", "Lambda", "Warrick", "Ipswitch", "Bicycle", "Cleaver", "Nova", "Thornton", "Rusty", "Tarquin", "Cadence", "Langerhans", "Absinthe", "Synth", "My Boat", "Chip", "Moe", "Terence", "Xenon", "Iona", "Inca", "Anne Elk", "Helen" };
  public static final int M = 0;
  public static final int K = 1;
  public static final int L = 2;
  public static final String C = com.biotools.poker.E.D("OpponentList.RandomWithBrackets");
  public static final String[] I = { com.biotools.poker.E.D("OpponentList.NumberSign"), com.biotools.poker.E.D("OpponentList.Type"), com.biotools.poker.E.D("OpponentList.Player") };
  private ArrayList G = new ArrayList();
  private boolean J = false;
  private boolean D = false;
  private String B = com.biotools.poker.E.D("OpponentList.Untitle");
  private String H = "";
  private File E;
  private boolean A = false;

  public E()
  {
    this.D = true;
  }

  public E(File paramFile)
    throws Exception
  {
    C(paramFile);
  }

  public E D()
  {
    E localE = new E();
    localE.G.addAll(this.G);
    localE.J = this.J;
    localE.D = this.D;
    localE.B = this.B;
    localE.E = this.E;
    return localE;
  }

  public void D(String paramString)
  {
    this.B = paramString;
    this.A = true;
  }

  public String J()
  {
    return this.B;
  }

  public B F(int paramInt)
  {
    return (B)this.G.get(paramInt);
  }

  public Object J(int paramInt)
  {
    return this.G.get(paramInt);
  }

  public void K(int paramInt)
  {
    assert (paramInt < this.G.size());
    this.G.remove(paramInt);
  }

  public boolean O()
  {
    return this.J;
  }

  public void C(boolean paramBoolean)
  {
    this.J = paramBoolean;
    this.A = true;
  }

  public boolean F()
  {
    return this.D;
  }

  public void A(boolean paramBoolean)
  {
    this.D = paramBoolean;
  }

  public int getRowCount()
  {
    return this.G.size();
  }

  public int R()
  {
    return this.G.size();
  }

  public int getColumnCount()
  {
    return I.length;
  }

  public boolean E(int paramInt)
  {
    return ((this.G.get(paramInt) instanceof String)) && (!((String)this.G.get(paramInt)).equals("RANDOM"));
  }

  public boolean I(int paramInt)
  {
    return ((this.G.get(paramInt) instanceof String)) && (((String)this.G.get(paramInt)).equals("RANDOM"));
  }

  public boolean G(int paramInt)
  {
    if (B(paramInt))
    {
      B localB = F(paramInt);
      if (localB.J() == null)
        return true;
    }
    return false;
  }

  public boolean B(int paramInt)
  {
    return this.G.get(paramInt) instanceof B;
  }

  public boolean D(int paramInt)
  {
    return this.G.get(paramInt) == null;
  }

  public Object getValueAt(int paramInt1, int paramInt2)
  {
    if (paramInt2 == 0)
      return paramInt1 + 1 + " ";
    if (D(paramInt1))
      return null;
    if (E(paramInt1))
    {
      switch (paramInt2)
      {
      case 1:
        return com.biotools.poker.E.D("OpponentList.Human");
      case 2:
        return this.G.get(paramInt1);
      }
      return null;
    }
    if (I(paramInt1))
    {
      switch (paramInt2)
      {
      case 1:
        return C;
      case 2:
        return C;
      }
      return null;
    }
    B localB = F(paramInt1);
    if (localB != null)
      switch (paramInt2)
      {
      case 1:
        return localB.C();
      case 2:
        if (localB.J() == null)
          return C;
        return localB.J();
      }
    return null;
  }

  public String getColumnName(int paramInt)
  {
    return I[paramInt];
  }

  public boolean isCellEditable(int paramInt1, int paramInt2)
  {
    return false;
  }

  public void setValueAt(Object paramObject, int paramInt1, int paramInt2)
  {
  }

  public void G()
  {
    this.G.clear();
    fireTableDataChanged();
  }

  public List A(List paramList)
  {
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < paramList.size(); i++)
    {
      B localB = (B)paramList.get(i);
      if ((localB.B() == O()) && (!localB.G()))
        localArrayList.add(localB);
    }
    return localArrayList;
  }

  public static List A(List paramList, String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < paramList.size(); i++)
    {
      B localB = (B)paramList.get(i);
      if (localB.C().equals(paramString))
        localArrayList.add(localB);
    }
    return localArrayList;
  }

  public void A(int paramInt1, int paramInt2)
  {
    Object localObject = B.N();
    localObject = A((List)localObject);
    for (int i = 0; i < paramInt2; i++)
      if (i < paramInt1)
        this.G.add(((List)localObject).get((int)(Math.random() * ((List)localObject).size())));
      else
        V();
    fireTableDataChanged();
    this.A = true;
  }

  public void M()
  {
    this.G.add(PokerApp.Ȅ().ɬ());
    fireTableDataChanged();
    this.A = true;
  }

  public void C(int paramInt, String paramString)
  {
    if (this.G.size() > paramInt)
    {
      this.G.set(paramInt, paramString);
      fireTableRowsUpdated(paramInt, paramInt);
    }
  }

  public void V()
  {
    this.G.add("RANDOM");
    fireTableDataChanged();
    this.A = true;
  }

  public void A(String paramString)
  {
    B localB = new B("");
    localB.B(paramString);
    this.G.add(localB);
  }

  public boolean B(String paramString)
  {
    Object localObject = B.N();
    localObject = A((List)localObject);
    for (int i = 0; i < ((List)localObject).size(); i++)
    {
      B localB = (B)((List)localObject).get(i);
      if (paramString.equals(localB.C()))
        return true;
    }
    return false;
  }

  public void A(String paramString1, String paramString2)
  {
    boolean bool = false;
    bool = B(paramString1, paramString2);
    if (!bool)
      B();
    fireTableDataChanged();
    this.A = true;
  }

  private boolean B(String paramString1, String paramString2)
  {
    boolean bool = false;
    B localB;
    if ((paramString2 == null) || (paramString2.length() == 0))
    {
      localB = new B("");
      if ((paramString1 == null) || (paramString1.length() == 0))
      {
        V();
        bool = true;
      }
      else
      {
        localB.B(paramString1);
        this.G.add(localB);
        bool = true;
      }
    }
    else
    {
      localB = B.D(paramString2);
      if ((localB != null) && (localB.B() == O()) && (localB.J().equals(paramString2)) && (localB.C().equals(paramString1)))
      {
        this.G.add(localB);
        bool = true;
      }
    }
    return bool;
  }

  public void C(String paramString1, String paramString2)
  {
    boolean bool = false;
    bool = B(paramString1, paramString2);
    if (!bool)
      V();
    fireTableDataChanged();
    this.A = true;
  }

  public void A(int paramInt, String paramString)
  {
    if (paramString.equals(com.biotools.poker.E.D("OpponentList.Empty")))
    {
      C(paramInt);
    }
    else if (paramString.equals(com.biotools.poker.E.D("OpponentList.Random")))
    {
      this.G.set(paramInt, "RANDOM");
    }
    else
    {
      B localB = new B("");
      localB.B(paramString);
      this.G.set(paramInt, localB);
    }
    fireTableRowsUpdated(paramInt, paramInt);
    this.A = true;
  }

  public void B()
  {
    this.G.add(null);
    this.A = true;
  }

  public void A(int paramInt, B paramB)
  {
    this.G.set(paramInt, paramB);
    fireTableRowsUpdated(paramInt, paramInt);
    this.A = true;
  }

  public void A(int paramInt, Object paramObject)
  {
    this.G.set(paramInt, paramObject);
    fireTableRowsUpdated(paramInt, paramInt);
    this.A = true;
  }

  public void B(int paramInt, String paramString)
  {
    ArrayList localArrayList = B.N();
    for (int i = 0; i < localArrayList.size(); i++)
    {
      B localB = (B)localArrayList.get(i);
      if (localB.J().equals(paramString))
      {
        this.G.set(paramInt, localB);
        fireTableRowsUpdated(paramInt, paramInt);
        this.A = true;
        return;
      }
    }
    C(paramInt);
  }

  public void C(int paramInt)
  {
    this.G.set(paramInt, null);
    fireTableRowsUpdated(paramInt, paramInt);
    this.A = true;
  }

  public void A(int paramInt)
  {
    if (B(paramInt))
    {
      B localB = F(paramInt);
      A(paramInt, localB.C());
    }
    else
    {
      this.G.set(paramInt, "RANDOM");
    }
    fireTableRowsUpdated(paramInt, paramInt);
    this.A = true;
  }

  public void N()
  {
    Object localObject = B.N();
    localObject = A((List)localObject);
    for (int i = 0; i < this.G.size(); i++)
    {
      B localB;
      if (I(i))
      {
        localB = (B)((List)localObject).get((int)(Math.random() * ((List)localObject).size()));
        A(i, localB);
      }
      else if (G(i))
      {
        localB = F(i);
        if (B(localB.C()))
        {
          List localList = A((List)localObject, localB.C());
          localB = (B)localList.get((int)(Math.random() * localList.size()));
          A(i, localB);
        }
        else
        {
          localB = (B)((List)localObject).get((int)(Math.random() * ((List)localObject).size()));
          A(i, localB);
        }
      }
    }
    fireTableDataChanged();
  }

  public void H(int paramInt)
  {
    while (R() > paramInt)
      this.G.remove(R() - 1);
    while (R() < paramInt)
      V();
    fireTableDataChanged();
    this.A = true;
  }

  public void H()
  {
    com.biotools.poker.E.H("START: OppList:instantiate() " + F.B());
    N();
    HashSet localHashSet = new HashSet();
    Enumeration localEnumeration = com.biotools.poker.P.N.Ñ().elements();
    while (localEnumeration.hasMoreElements())
      localHashSet.add((String)localEnumeration.nextElement());
    HashMap localHashMap = new HashMap();
    for (int i = 1; i < R(); i++)
    {
      B localB1 = F(i);
      if (localB1 != null)
      {
        B localB2 = new B(localB1);
        String str = a.B.I(localB2.F());
        if ((!localHashMap.containsKey(str)) && (!localHashSet.contains(str)))
        {
          localHashMap.put(str, localB2.F());
          a.B.A(str, localB2.F());
          localB2.C(str);
        }
        else
        {
          com.biotools.poker.E.H("Name Reserved: Try Again");
          for (str = a.B.I(localB2.F()); (localHashMap.containsKey(str)) || (localHashSet.contains(str)); str = a.B.I(localB2.F()));
          localHashMap.put(str, localB2.F());
          a.B.A(str, localB2.F());
          localB2.C(str);
        }
        A(i, localB2);
      }
    }
    com.biotools.poker.E.H("NAMES SIZE:  " + localHashMap.size() + " / " + R());
    a.B.A();
    com.biotools.poker.E.H("ENDDD: OppList:instantiate() " + F.B());
  }

  public com.biotools.A.N U()
  {
    com.biotools.A.N localN1 = new com.biotools.A.N("lineup");
    localN1.A("title", this.B);
    localN1.A("nolimit", O());
    localN1.B(this.H);
    for (int i = 0; i < R(); i++)
    {
      com.biotools.A.N localN2 = new com.biotools.A.N("seat");
      localN2.A(true);
      if (D(i))
      {
        localN2.A("type", "empty");
      }
      else if (E(i))
      {
        localN2.A("type", "human");
      }
      else if (I(i))
      {
        localN2.A("type", "random");
      }
      else if (G(i))
      {
        localN2.A("type", F(i).C());
      }
      else if (B(i))
      {
        localN2.A("type", F(i).C());
        localN2.A("name", F(i).J());
      }
      localN1.A(localN2);
    }
    localN1.A(true);
    return localN1;
  }

  public synchronized void L()
  {
    if (this.E != null)
      B(this.E);
  }

  public void T()
  {
    B(new File(K()));
  }

  public synchronized void E()
  {
    if (this.E != null)
    {
      try
      {
        C(this.E);
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
      }
      this.A = false;
    }
  }

  public static String K()
  {
    try
    {
      File localFile = File.createTempFile("ppt", ".tbl", com.biotools.poker.E.Q());
      return localFile.getCanonicalPath();
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
    return null;
  }

  public synchronized void B(File paramFile)
  {
    this.E = paramFile;
    try
    {
      BufferedWriter localBufferedWriter = new BufferedWriter(new FileWriter(paramFile));
      localBufferedWriter.write(U().toString());
      localBufferedWriter.close();
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
    this.A = false;
  }

  public void C(File paramFile)
    throws Exception
  {
    G();
    this.E = paramFile;
    DocumentBuilderFactory localDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
    localDocumentBuilderFactory.setNamespaceAware(true);
    DocumentBuilder localDocumentBuilder = localDocumentBuilderFactory.newDocumentBuilder();
    Document localDocument = localDocumentBuilder.parse(paramFile);
    Element localElement1 = localDocument.getDocumentElement();
    this.B = localElement1.getAttribute("title");
    C(Boolean.valueOf(localElement1.getAttribute("nolimit")).booleanValue());
    NodeList localNodeList = localElement1.getElementsByTagName("seat");
    this.H = L.A(localElement1).trim();
    for (int i = 0; i < localNodeList.getLength(); i++)
    {
      Element localElement2 = (Element)localNodeList.item(i);
      String str = localElement2.getAttribute("type");
      if (str != null)
        if (str.equalsIgnoreCase("empty"))
          B();
        else if (str.equalsIgnoreCase("human"))
          M();
        else if (str.equalsIgnoreCase("random"))
          V();
        else
          A(str, localElement2.getAttribute("name"));
    }
    this.A = false;
  }

  public void B(boolean paramBoolean)
  {
    this.A = paramBoolean;
  }

  public boolean C()
  {
    return this.A;
  }

  public void P()
  {
    if (this.E != null)
      this.E.delete();
  }

  public File Q()
  {
    return this.E;
  }

  public static Vector S()
  {
    Vector localVector = new Vector();
    File[] arrayOfFile = com.biotools.poker.E.Q().listFiles();
    for (int i = 0; i < arrayOfFile.length; i++)
      if (arrayOfFile[i].getName().endsWith(".tbl"))
        try
        {
          localVector.addElement(new E(arrayOfFile[i]));
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
        }
    Collections.sort(localVector);
    return localVector;
  }

  public int compareTo(Object paramObject)
  {
    E localE = (E)paramObject;
    if ((localE.O()) && (!O()))
      return -1;
    if ((!localE.O()) && (O()))
      return 1;
    return J().compareToIgnoreCase(localE.J());
  }

  public String A()
  {
    return this.H;
  }

  public void C(String paramString)
  {
    this.H = paramString;
  }

  public int I()
  {
    int i = 0;
    for (int j = 0; j < R(); j++)
      if (!D(j))
        i++;
    return i;
  }

  public void D(File paramFile)
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(Q());
    Object localObject;
    for (int i = 0; i < R(); i++)
      if ((B(i)) && (!G(i)))
      {
        localObject = F(i);
        localArrayList.add(new File(((B)localObject).M()));
      }
    try
    {
      ZipOutputStream localZipOutputStream = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(paramFile)));
      localZipOutputStream.setMethod(8);
      localObject = localArrayList.iterator();
      while (((Iterator)localObject).hasNext())
      {
        File localFile = (File)((Iterator)localObject).next();
        ZipEntry localZipEntry = new ZipEntry(localFile.getName());
        byte[] arrayOfByte = com.biotools.A.B.A(localFile).getBytes();
        localZipEntry.setSize(arrayOfByte.length);
        localZipEntry.setTime(System.currentTimeMillis());
        localZipOutputStream.putNextEntry(localZipEntry);
        localZipOutputStream.write(arrayOfByte, 0, arrayOfByte.length);
        localZipOutputStream.closeEntry();
      }
      localZipOutputStream.close();
    }
    catch (ZipException localZipException)
    {
      localZipException.printStackTrace();
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }

  public static E A(File paramFile)
  {
    try
    {
      Object localObject1 = null;
      ZipFile localZipFile = new ZipFile(paramFile);
      Enumeration localEnumeration = localZipFile.entries();
      Object localObject2;
      while (localEnumeration.hasMoreElements())
      {
        localObject2 = (ZipEntry)localEnumeration.nextElement();
        InputStream localInputStream = localZipFile.getInputStream((ZipEntry)localObject2);
        DataInputStream localDataInputStream = new DataInputStream(new BufferedInputStream(localInputStream));
        byte[] arrayOfByte = new byte[(int)((ZipEntry)localObject2).getSize()];
        for (int i = 0; i < ((ZipEntry)localObject2).getSize(); i++)
          arrayOfByte[i] = localDataInputStream.readByte();
        localDataInputStream.close();
        File localFile = null;
        Object localObject3;
        if (((ZipEntry)localObject2).getName().endsWith(".tbl"))
        {
          localFile = new File(com.biotools.poker.E.Q() + ((ZipEntry)localObject2).getName());
          localObject1 = localFile;
        }
        else
        {
          localFile = new File(com.biotools.poker.E.O() + ((ZipEntry)localObject2).getName());
          localObject3 = new StringTokenizer(((ZipEntry)localObject2).getName(), ".pd");
          a.B.B(((StringTokenizer)localObject3).nextToken());
        }
        if (localFile.exists())
        {
          localObject3 = new Object[] { ((ZipEntry)localObject2).getName() };
          int j = JOptionPane.showConfirmDialog(PokerApp.Ȅ(), com.biotools.poker.E.A("OpponentList.OverwriteItemDescriptionPattern", (Object[])localObject3), com.biotools.poker.E.D("OpponentList.OverwriteItem"), 0);
          if (j == 1);
        }
        else
        {
          com.biotools.A.B.A(arrayOfByte, localFile);
        }
      }
      if (localObject1 != null)
      {
        B.K();
        localObject2 = new E(localObject1);
        return localObject2;
      }
    }
    catch (Exception localException)
    {
      d.A(localException);
    }
    return null;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.E.E
 * JD-Core Version:    0.6.2
 */