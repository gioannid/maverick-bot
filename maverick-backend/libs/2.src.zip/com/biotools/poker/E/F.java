package com.biotools.poker.E;

import com.biotools.meerkat.Player;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;

public class F extends HashMap
{
  public F()
  {
    A();
  }

  private void A()
  {
    put("com/biotools/poker/opponent/PlugInOpponent", I.class);
    put("PlugInOpponent", I.class);
    put("PipedOpponent", H.class);
  }

  public Player B(String paramString)
  {
    Player localPlayer = null;
    Preferences localPreferences = new Preferences(paramString);
    if (localPreferences.empty())
    {
      System.err.println("File not found: [" + paramString + "]");
      return null;
    }
    String str = localPreferences.getPreference("PLAYER_CLASS");
    try
    {
      str = A(str);
      localPlayer = (Player)Class.forName(str).newInstance();
      localPlayer.init(localPreferences);
    }
    catch (Exception localException)
    {
      Object[] arrayOfObject = { paramString, str };
      com.biotools.A.I.A(E.A("BotRegistry.ErrorLoadingPlayerClassPattern", arrayOfObject), localException);
    }
    return localPlayer;
  }

  private String A(String paramString)
  {
    Class localClass = (Class)get(paramString.replaceAll("\\.", "/"));
    if (localClass != null)
      return localClass.getName();
    return paramString;
  }

  private static void A(Player paramPlayer)
  {
    try
    {
      Class[] arrayOfClass = { String.class };
      Method localMethod = paramPlayer.getClass().getMethod("unlock", arrayOfClass);
      if (localMethod != null)
      {
        Object[] arrayOfObject = { "Meerkat" };
        localMethod.invoke(paramPlayer, arrayOfObject);
      }
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      if (E.y())
        com.biotools.A.I.A("", localIllegalArgumentException);
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      if (E.y())
        com.biotools.A.I.A("", localIllegalAccessException);
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      if (E.y())
        com.biotools.A.I.A("", localInvocationTargetException);
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.E.F
 * JD-Core Version:    0.6.2
 */