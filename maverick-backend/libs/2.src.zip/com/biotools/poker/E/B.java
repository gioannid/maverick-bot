package com.biotools.poker.E;

import com.biotools.A.a;
import com.biotools.meerkat.Player;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Observable;
import java.util.Observer;

public class B
  implements Comparable, Observer
{
  private static F D;
  private static ArrayList A;
  private static ArrayList G;
  private static Observable F = new Observable()
  {
    public void notifyObservers(Object paramAnonymousObject)
    {
      setChanged();
      super.notifyObservers(paramAnonymousObject);
    }
  };
  private Preferences C;
  private String H;
  private String B;
  private String E;

  public B(String paramString1, String paramString2)
  {
    A(paramString1);
    this.B = paramString2;
    this.E = paramString2;
    K();
  }

  public B(String paramString)
  {
    A(paramString);
    Preferences localPreferences = I();
    this.B = Preferences.unmunkString(localPreferences.getPreference("PLAYER_NAME"));
    K();
  }

  public B(B paramB)
  {
    this.H = paramB.H;
    this.B = paramB.B;
    this.E = paramB.E;
    this.C = new Preferences(paramB.I());
  }

  public void A(String paramString)
  {
    if (paramString.startsWith("logs/players/"))
    {
      String str = E.O().getPath();
      str = str.replaceAll("\\\\", "/");
      paramString = paramString.replaceFirst("logs/players/", str);
    }
    this.H = paramString.replaceAll("\\\\", "/");
  }

  public Preferences I()
  {
    if (this.C == null)
      this.C = new Preferences(this.H);
    return this.C;
  }

  public void O()
  {
    this.C = null;
  }

  public String toString()
  {
    return this.B;
  }

  public String J()
  {
    return this.B;
  }

  public String C()
  {
    return I().getPreference("AI_NAME");
  }

  public String M()
  {
    return this.H;
  }

  public void E()
  {
    File localFile = new File(M());
    localFile.delete();
    K();
  }

  public static ArrayList N()
  {
    if (A == null)
      A = B(E.O());
    return A;
  }

  public static ArrayList H()
  {
    if (G == null)
      G = B(E.Ì());
    return G;
  }

  public static void K()
  {
    A = null;
    F.notifyObservers();
  }

  public static Observable A()
  {
    return F;
  }

  public static void A(Observer paramObserver)
  {
    F.addObserver(paramObserver);
  }

  public static void B(Observer paramObserver)
  {
    F.deleteObserver(paramObserver);
  }

  public static ArrayList B(File paramFile)
  {
    E.H("getOpponentList: S: " + com.biotools.A.F.B());
    ArrayList localArrayList = new ArrayList();
    File[] arrayOfFile = paramFile.listFiles();
    for (int i = 0; i < arrayOfFile.length; i++)
      if (arrayOfFile[i].getName().endsWith(".pd"))
        localArrayList.add(new B(arrayOfFile[i].getPath()));
    Collections.sort(localArrayList);
    E.H("getOpponentList: F: " + com.biotools.A.F.B());
    return localArrayList;
  }

  public static B D(String paramString)
  {
    String str = a.B.J(paramString);
    if (str != null)
      paramString = str;
    Object localObject = null;
    ArrayList localArrayList = N();
    for (int i = 0; i < localArrayList.size(); i++)
    {
      B localB = (B)localArrayList.get(i);
      if (localB.F().equals(paramString))
        return localB;
      if (paramString.matches(localB.F() + "\\-\\d*"))
        localObject = localB;
    }
    if (localObject != null)
    {
      localObject = new B(((B)localObject).M());
      ((B)localObject).C(paramString);
    }
    return localObject;
  }

  public static B E(String paramString)
  {
    Object localObject = null;
    ArrayList localArrayList = N();
    for (int i = 0; i < localArrayList.size(); i++)
    {
      B localB = (B)localArrayList.get(i);
      if (localB.J().equals(paramString))
        return localB;
      if (paramString.matches(localB.J() + "\\-\\d*"))
        localObject = localB;
    }
    if (localObject != null)
    {
      localObject = new B(((B)localObject).M());
      ((B)localObject).C(paramString);
    }
    return localObject;
  }

  public boolean G()
  {
    return I().getBooleanPreference("HEADS_UP_ONLY", false);
  }

  public boolean B()
  {
    return I().getBooleanPreference("NO_LIMIT", false);
  }

  public int compareTo(Object paramObject)
  {
    B localB = (B)paramObject;
    return J().compareTo(localB.J());
  }

  public boolean A(B paramB)
  {
    return M().equals(paramB.M());
  }

  public void B(String paramString)
  {
    I().setPreference("AI_NAME", paramString);
  }

  public void G(String paramString)
  {
    I().setPreference("ORIGINAL_NAME", paramString);
    this.E = paramString;
  }

  public String F()
  {
    if (this.E == null)
      this.E = this.B;
    return this.E;
  }

  public void C(String paramString)
  {
    this.B = paramString;
    I().setPreference("PLAYER_NAME", paramString);
  }

  public void update(Observable paramObservable, Object paramObject)
  {
    A = null;
  }

  public boolean D()
  {
    if (C() == null)
      return false;
    if (C().equals("Pokibot"))
      return true;
    return C().equals("Xenbot");
  }

  public static synchronized Player F(String paramString)
  {
    return L().B(paramString);
  }

  public static F L()
  {
    if (D == null)
      D = new F();
    return D;
  }

  public void A(File paramFile)
  {
    String str1 = Preferences.unmunkString(I().getPreference("PLAYER_NAME"));
    String str2 = new String(str1 + ".pd");
    File localFile = new File(paramFile, str2);
    A(localFile.getPath());
    I().savePreferences(localFile.getPath());
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.E.B
 * JD-Core Version:    0.6.2
 */