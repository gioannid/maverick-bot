package com.biotools.poker.E;

import B.A.A.B;
import com.biotools.A.d;
import com.biotools.B.L;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import com.biotools.poker.PokerApp;
import com.biotools.poker.Q.K;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class H
  implements D
{
  private int G;
  private Process A;
  private PrintStream D;
  private volatile Action F;
  private GameInfo C;
  private boolean B = false;
  private Preferences E;

  public H()
  {
    Runtime.getRuntime().addShutdownHook(new Thread()
    {
      public void run()
      {
        H.this.C();
      }
    });
    d.A(3);
    d.D(E.n() + "comm/");
  }

  public void init(Preferences paramPreferences)
  {
    this.E = paramPreferences;
  }

  private String G()
  {
    return this.E.get("EXECUTABLE", "");
  }

  private void F(String paramString)
  {
    this.E.setPreference("EXECUTABLE", paramString);
  }

  protected void G(String paramString)
  {
    D(paramString + "\n");
  }

  void D(String paramString)
  {
    System.out.print(paramString);
    System.out.flush();
    this.D.print(paramString);
    this.D.flush();
  }

  void C(String paramString)
  {
    System.err.println(paramString);
  }

  void E(String paramString)
  {
    System.err.println(paramString);
  }

  private void B(String paramString)
  {
    C(paramString);
  }

  public void C()
  {
    E();
    this.B = true;
  }

  private void E()
  {
    if (this.A != null)
    {
      this.A.destroy();
      this.A = null;
      PokerApp.Ȅ().ʐ().B(this.D);
    }
  }

  public void holeCards(Card paramCard1, Card paramCard2, int paramInt)
  {
    G("You are in seat: " + paramInt);
    G("Your cards are: " + paramCard1 + " " + paramCard2);
    this.G = paramInt;
  }

  public Action getAction()
  {
    this.F = null;
    G("GET_ACTION");
    while ((this.F == null) && (this.A != null) && (!this.B))
      L.C(25L);
    return this.F;
  }

  private void A(String paramString)
  {
    E(paramString);
    if ((this.C.getCurrentPlayerSeat() == this.G) && (paramString.startsWith("ACTION:")))
    {
      double d1 = this.C.getAmountToCall(this.G);
      if (paramString.startsWith("ACTION: FOLD"))
        this.F = Action.checkOrFoldAction(d1);
      if ((paramString.startsWith("ACTION: CHECK")) || (paramString.startsWith("ACTION: CALL")))
        this.F = Action.callAction(d1);
      if ((paramString.startsWith("ACTION: RAISE")) || (paramString.startsWith("ACTION: BET")))
      {
        String[] arrayOfString = paramString.split("$");
        if (arrayOfString.length != 2)
        {
          this.F = Action.raiseAction(d1, this.C.getCurrentBetSize());
        }
        else
        {
          double d2 = 0.0D;
          try
          {
            d2 = Double.parseDouble(arrayOfString[1].trim());
          }
          catch (Exception localException)
          {
            localException.printStackTrace();
            this.F = Action.raiseAction(d1, this.C.getCurrentBetSize());
          }
          this.F = Action.raiseAction(d1, d2);
        }
      }
    }
  }

  public void actionEvent(int paramInt, Action paramAction)
  {
  }

  public void stageEvent(int paramInt)
  {
    Hand localHand = this.C.getBoard();
  }

  public void showdownEvent(int paramInt, Card paramCard1, Card paramCard2)
  {
  }

  public void gameStartEvent(GameInfo paramGameInfo)
  {
    if (this.A == null)
    {
      D();
      if (this.D != null)
        PokerApp.Ȅ().ʐ().A(this.D);
    }
    this.C = paramGameInfo;
    G("\n---------------------------");
    G("The button is on seat " + paramGameInfo.getButtonSeat());
    G("The blinds are at " + Action.formatCash(paramGameInfo.getSmallBlindSize()) + "/" + Action.formatCash(paramGameInfo.getBigBlindSize()));
    for (int i = 0; i < paramGameInfo.getNumSeats(); i++)
      if (paramGameInfo.inGame(i))
        G("Seat " + i + ") " + Action.formatCash(paramGameInfo.getPlayer(i).getBankRoll()) + " " + paramGameInfo.getPlayerName(i));
  }

  public void dealHoleCardsEvent()
  {
  }

  public void gameOverEvent()
  {
  }

  public void winEvent(int paramInt, double paramDouble, String paramString)
  {
  }

  public void gameStateChanged()
  {
  }

  private boolean F()
  {
    E();
    if (!D())
    {
      JOptionPane.showMessageDialog(null, "Error: Problem loading EXE: '" + G() + "'", "Error", 0);
      return false;
    }
    return true;
  }

  private boolean D()
  {
    try
    {
      Runtime localRuntime = Runtime.getRuntime();
      this.A = localRuntime.exec(G());
      Thread local2 = new Thread()
      {
        public void run()
        {
          try
          {
            InputStreamReader localInputStreamReader = new InputStreamReader(H.this.A.getInputStream());
            BufferedReader localBufferedReader = new BufferedReader(localInputStreamReader);
            String str = null;
            while ((str = localBufferedReader.readLine()) != null)
              H.this.A(str);
          }
          catch (IOException localIOException)
          {
            localIOException.printStackTrace();
          }
        }
      };
      local2.start();
      Thread local3 = new Thread()
      {
        public void run()
        {
          try
          {
            InputStreamReader localInputStreamReader = new InputStreamReader(H.this.A.getErrorStream());
            BufferedReader localBufferedReader = new BufferedReader(localInputStreamReader);
            String str = null;
            while ((str = localBufferedReader.readLine()) != null)
              H.this.E(str);
          }
          catch (IOException localIOException)
          {
            localIOException.printStackTrace();
          }
        }
      };
      local3.start();
      this.D = new PrintStream(new BufferedOutputStream(this.A.getOutputStream()));
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      return false;
    }
    return true;
  }

  public void finalize()
  {
    C();
  }

  public Preferences B()
  {
    return this.E;
  }

  public JPanel A()
  {
    JPanel localJPanel = new JPanel(new B());
    JTextField localJTextField = new JTextField(20);
    localJTextField.setText(G());
    localJTextField.addActionListener(new H.4(this, localJTextField));
    localJPanel.add("br", new JLabel("Executable"));
    localJPanel.add("tab", localJTextField);
    return localJPanel;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.E.H
 * JD-Core Version:    0.6.2
 */