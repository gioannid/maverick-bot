package com.biotools.poker.Q;

import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.meerkat.util.Preferences;
import java.io.Serializable;

public class F
  implements Serializable, PlayerInfo
{
  private String T;
  private double E;
  private double P = 0.0D;
  private double J = 0.0D;
  private double K = 0.0D;
  private double C = 0.0D;
  private double L = 0.0D;
  private Hand S;
  private D N;
  private double D;
  private double I;
  private int F;
  private boolean O = false;
  private boolean G = false;
  private boolean Q = false;
  private boolean A = false;
  private boolean B = false;
  private boolean M = false;
  private boolean R = false;
  private boolean H = false;

  public F(String paramString, D paramD)
  {
    this.T = paramString;
    this.N = paramD;
    this.K = (this.E = D.E.getDouble("BANKROLL_" + getName(), 1000.0D));
    this.E = C(this.E);
    this.K = C(this.K);
  }

  public F(F paramF, D paramD)
  {
    this.N = paramD;
    this.T = paramF.T;
    this.E = paramF.E;
    this.C = paramF.C;
    this.K = paramF.K;
    this.P = paramF.P;
    this.J = paramF.J;
    this.S = paramF.S;
    this.F = paramF.F;
    this.D = paramF.D;
    this.I = paramF.I;
    this.O = paramF.O;
    this.G = paramF.G;
    this.A = paramF.A;
    this.Q = paramF.Q;
    this.L = paramF.L;
  }

  public void J()
  {
    D.E.putDouble("BANKROLL_" + getName(), this.E);
  }

  public double getNetGain()
  {
    return this.C;
  }

  public void E(double paramDouble)
  {
    this.E = paramDouble;
    this.E = C(this.E);
    D.E.putDouble("BANKROLL_" + getName(), this.E);
  }

  public void J(double paramDouble)
  {
    paramDouble = C(paramDouble);
    this.E = paramDouble;
  }

  public void C()
  {
    this.E = this.K;
  }

  public double getBankRoll()
  {
    return this.E;
  }

  public double getBankRollAtStartOfHand()
  {
    return this.K;
  }

  public double getBankRollInSmallBets()
  {
    return this.E / this.N.K();
  }

  public boolean inGame()
  {
    return this.Q;
  }

  public void F(boolean paramBoolean)
  {
    this.G = (this.Q = paramBoolean);
  }

  public int getSeat()
  {
    return this.N.getPlayerSeat(this.T);
  }

  public void D(boolean paramBoolean)
  {
    this.A = false;
    this.S = null;
    this.P = 0.0D;
    this.L = 0.0D;
    this.J = this.P;
    this.K = this.E;
    this.C = 0.0D;
    this.D = 0.0D;
    this.I = 0.0D;
    this.O = false;
    this.F = -1;
    this.G = paramBoolean;
  }

  public String getName()
  {
    return this.T;
  }

  public boolean isAllIn()
  {
    return this.E <= 0.0D;
  }

  protected void E()
  {
    double d = this.N.getBetsToCall(getSeat());
    this.G = false;
    this.A = true;
    this.I = d;
    this.F = 0;
  }

  protected void I()
  {
    this.A = true;
    this.G = false;
    this.F = 0;
  }

  protected void O()
  {
    this.D = this.P;
  }

  protected void F()
  {
    this.D = this.P;
  }

  protected void N()
  {
    this.D = this.P;
  }

  protected double G(double paramDouble)
  {
    double d1 = paramDouble - this.P;
    if (paramDouble - this.P == 0.0D)
    {
      B();
      return 0.0D;
    }
    d1 = I(paramDouble);
    double d2 = d1 / this.N.c();
    this.F = 1;
    this.A = true;
    this.I = d2;
    this.D = d1;
    this.O = true;
    return d1;
  }

  protected double B(double paramDouble)
  {
    double d = I(paramDouble);
    this.F = 2;
    this.O = true;
    this.A = true;
    this.D = d;
    this.I = 0.0D;
    return d;
  }

  protected void B()
  {
    this.F = 1;
    this.A = true;
    this.D = 0.0D;
    this.I = 0.0D;
  }

  protected double F(double paramDouble)
  {
    double d1 = I(paramDouble);
    double d2 = getAmountToCall() / this.N.c();
    this.F = 2;
    this.I = d2;
    this.O = true;
    this.A = true;
    this.D = d1;
    return d1;
  }

  protected double I(double paramDouble)
  {
    paramDouble = C(paramDouble);
    double d = C(paramDouble - this.P);
    if (d < 0.0D)
    {
      if (!$assertionsDisabled)
        throw new AssertionError("amount to pay < 0: amount = " + d + ", owed = " + paramDouble + ", amountIn = " + this.P);
      d = 0.0D;
    }
    d = C(d);
    if (this.E < d)
      d = this.E;
    this.P += d;
    this.P = C(this.P);
    this.E -= d;
    this.E = C(this.E);
    this.C = C(this.C - d);
    d = C(d);
    this.N.A(d, this);
    return d;
  }

  protected double D(double paramDouble)
  {
    paramDouble = C(paramDouble);
    if (this.E < paramDouble)
      paramDouble = this.E;
    this.E = C(this.E - paramDouble);
    this.C = C(this.C - paramDouble);
    this.P = C(this.P + paramDouble);
    this.L += paramDouble;
    this.N.A(paramDouble, this);
    this.P = C(this.P - paramDouble);
    return paramDouble;
  }

  private double C(double paramDouble)
  {
    return Math.round(paramDouble * 100.0D) / 100.0D;
  }

  protected void D()
  {
    this.A = false;
    this.O = false;
    this.D = 0.0D;
    this.I = 0.0D;
    this.J = this.P;
  }

  public void H(double paramDouble)
  {
    this.E += paramDouble;
    this.E = C(this.E);
    this.C = C(this.C + paramDouble);
  }

  protected void A(Card paramCard1, Card paramCard2)
  {
    if (this.S == null)
    {
      this.S = new Hand();
      this.S.addCard(paramCard1);
      this.S.addCard(paramCard2);
      return;
    }
    if (!this.S.getCard(1).valid())
      this.S.setCard(1, paramCard1);
    if (!this.S.getCard(2).valid())
      this.S.setCard(2, paramCard2);
  }

  public Hand getRevealedHand()
  {
    return this.S;
  }

  protected double A(double paramDouble)
  {
    double d = 0.0D;
    if (paramDouble > this.P)
      d = C(paramDouble - this.P);
    if (d > getBankRoll())
      d = getBankRoll();
    return C(d);
  }

  public double getAmountToCall()
  {
    return this.N.getAmountToCall(getSeat());
  }

  public boolean isCommitted()
  {
    return this.O;
  }

  public boolean hasActedThisRound()
  {
    return this.A;
  }

  public double H()
  {
    double d = A(this.N.getStakes());
    return d / (this.N.getEligiblePot(getSeat()) + d);
  }

  public double P()
  {
    return this.D;
  }

  public double K()
  {
    return this.I;
  }

  public double getAmountInPot()
  {
    return this.P;
  }

  public double getAmountInPotThisRound()
  {
    return C(this.P - this.J);
  }

  public double A()
  {
    return this.P / this.N.getTotalPotSize();
  }

  public int M()
  {
    return A(this.F, (int)K());
  }

  private static int A(int paramInt1, int paramInt2)
  {
    int i = -1;
    if ((paramInt1 == 1) && (paramInt2 == 0))
      i = 0;
    else if ((paramInt1 == 1) && (paramInt2 > 0))
      i = 1;
    else if ((paramInt1 == 2) && (paramInt2 == 0))
      i = 2;
    else if ((paramInt1 == 2) && (paramInt2 > 0))
      i = 3;
    return i;
  }

  public int getLastAction()
  {
    return this.F;
  }

  public GameInfo getGameInfo()
  {
    return this.N;
  }

  public boolean isActive()
  {
    return (this.G) && (this.Q);
  }

  public boolean isFolded()
  {
    return !this.G;
  }

  public boolean isButton()
  {
    return getGameInfo().getButtonSeat() == getSeat();
  }

  public boolean hasEnoughToRaise()
  {
    return getBankRoll() > this.N.getAmountToCall(getSeat());
  }

  public double getAmountRaiseable()
  {
    if (hasEnoughToRaise())
    {
      double d = C(getBankRoll() - this.N.getAmountToCall(getSeat()));
      if (d < this.N.getMinRaise())
        return d;
    }
    else
    {
      return 0.0D;
    }
    return this.N.getMinRaise();
  }

  public double getAmountCallable()
  {
    double d = this.N.getAmountToCall(getSeat());
    if (getBankRoll() < d)
      return getBankRoll();
    return d;
  }

  public String toString()
  {
    return this.T + (this.S == null ? "      " : new StringBuffer(" ").append(this.S.toString()).toString()) + " " + Action.formatCash(this.E) + (inGame() ? "   " : " NA");
  }

  public double getBankRollAtRisk()
  {
    double d1 = getBankRoll();
    double d2 = getAmountToCall();
    if (d2 > d1)
      d2 = d1;
    double d3 = 0.0D;
    int i = getSeat();
    for (int j = 0; j < this.N.getNumSeats(); j++)
      if ((j != i) && (this.N.isActive(j)))
      {
        double d4 = this.N.G(j).getBankRoll();
        double d5 = this.N.getAmountToCall(j);
        if (d5 > d4)
          d5 = d4;
        d4 = C(d4 - d5 + d2);
        if (d4 > d3)
          d3 = d4;
      }
    if (d3 > d1)
      d3 = d1;
    return d3;
  }

  protected void K(double paramDouble)
  {
    paramDouble = C(paramDouble);
    this.E += paramDouble;
    this.E = C(this.E);
    this.C = C(this.C + paramDouble);
    this.P = C(this.P - paramDouble);
  }

  public synchronized double getRaiseAmount(double paramDouble)
  {
    double d1 = paramDouble;
    double d2 = getAmountToCall();
    if (C(getBankRoll()) < C(d2 + d1))
      d1 = getBankRoll() - d2;
    d1 = C(d1);
    return d1;
  }

  public void E(boolean paramBoolean)
  {
    this.M = paramBoolean;
  }

  public boolean R()
  {
    return this.M;
  }

  public void C(boolean paramBoolean)
  {
    this.R = paramBoolean;
  }

  public boolean Q()
  {
    return this.R;
  }

  public void A(boolean paramBoolean)
  {
    this.H = paramBoolean;
  }

  public boolean G()
  {
    return this.H;
  }

  public void B(boolean paramBoolean)
  {
    this.B = paramBoolean;
  }

  public boolean isSittingOut()
  {
    return this.B;
  }

  public double L()
  {
    return this.L;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.Q.F
 * JD-Core Version:    0.6.2
 */