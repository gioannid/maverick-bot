package com.biotools.poker.Q;

import com.biotools.meerkat.PlayerInfo;
import java.io.Serializable;

public class H
  implements Serializable
{
  private double D = 0.0D;
  private double A = -1.0D;
  private D B;
  private H C;

  public H(D paramD)
  {
    this.B = paramD;
  }

  public H(H paramH)
  {
    this.D = paramH.D;
    this.A = paramH.A;
    this.B = paramH.B;
    if (paramH.C != null)
      this.C = new H(paramH.C);
  }

  public void A(D paramD)
  {
    this.B = paramD;
    if (this.C != null)
      this.C.A(paramD);
  }

  public void A(double paramDouble, PlayerInfo paramPlayerInfo)
  {
    A(paramDouble, paramPlayerInfo.getAmountInPot());
    if (paramPlayerInfo.isAllIn())
      B(paramPlayerInfo.getAmountInPot());
  }

  private void A(double paramDouble1, double paramDouble2)
  {
    assert (paramDouble1 >= 0.0D);
    if ((paramDouble2 <= this.A) || (this.A == -1.0D))
    {
      this.D = C(this.D + paramDouble1);
    }
    else
    {
      double d = paramDouble1;
      if (C(paramDouble2 - paramDouble1) < this.A)
      {
        d = C(paramDouble2 - this.A);
        this.D = C(this.D + (paramDouble1 - d));
      }
      F().A(d, paramDouble2);
    }
  }

  public H F()
  {
    if (this.C == null)
      this.C = new H(this.B);
    return this.C;
  }

  private void A(double paramDouble)
  {
    assert (paramDouble >= 0.0D);
    this.D = C(this.D + paramDouble);
  }

  public void B(double paramDouble)
  {
    if (paramDouble == this.A)
      return;
    double d3;
    if (this.A == -1.0D)
    {
      this.A = paramDouble;
      for (int i = 0; i < this.B.getNumSeats(); i++)
        if (this.B.inGame(i))
        {
          double d2 = this.B.G(i).getAmountInPot();
          if (d2 > this.A)
          {
            d3 = d2 - this.A;
            this.D = C(this.D - d3);
            F().A(d3);
          }
        }
    }
    else if (paramDouble < this.A)
    {
      double d1 = this.A;
      this.A = paramDouble;
      for (int j = 0; j < this.B.getNumSeats(); j++)
        if (this.B.inGame(j))
        {
          d3 = this.B.G(j).getAmountInPot();
          if (d3 > d1)
            d3 = d1;
          if (d3 > this.A)
          {
            double d4 = C(d3 - this.A);
            this.D = C(this.D - d4);
            F().A(d4);
          }
        }
      F().B(d1);
    }
    else
    {
      F().B(paramDouble);
    }
  }

  public double E()
  {
    return this.A;
  }

  public double H()
  {
    return this.D;
  }

  public H[] C()
  {
    H[] arrayOfH = new H[D()];
    int i = 0;
    for (H localH = this; localH != null; localH = localH.C)
      arrayOfH[(i++)] = localH;
    return arrayOfH;
  }

  public int D()
  {
    if (this.C == null)
      return 1;
    return 1 + this.C.D();
  }

  public String toString()
  {
    return "$" + this.D + (this.C != null ? ", " + this.C : "");
  }

  public boolean B()
  {
    return this.C != null;
  }

  public double G()
  {
    return A(null);
  }

  private void A()
  {
    this.C = null;
  }

  public double A(H paramH)
  {
    if (this.C != null)
      return this.C.A(this);
    double d1 = 0.0D;
    double d2 = 0.0D;
    int i = -1;
    for (int j = 0; j < this.B.getNumSeats(); j++)
      if (this.B.inGame(j))
      {
        double d4 = this.B.G(j).getAmountInPot();
        if (d4 > d1)
        {
          d2 = d1;
          d1 = d4;
          i = j;
        }
        else if (d4 > d2)
        {
          d2 = d4;
        }
      }
    if (d1 > d2)
    {
      double d3 = C(d1 - d2);
      this.D = C(this.D - d3);
      if (this.A > 0.0D)
        this.A -= d3;
      if ((this.D == 0.0D) && (paramH != null))
        paramH.A();
      this.B.G(i).K(d3);
      return d3;
    }
    return 0.0D;
  }

  private double C(double paramDouble)
  {
    return Math.round(paramDouble * 100.0D) / 100.0D;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.Q.H
 * JD-Core Version:    0.6.2
 */