package com.biotools.poker.Q;

import com.biotools.A.d;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Player;
import com.biotools.poker.N.N;
import com.biotools.poker.N.W;
import com.biotools.poker.R.V;

public class C extends B
{
  private boolean k = false;
  private K j;

  public C(com.biotools.poker.R.E paramE, K paramK, Player paramPlayer)
  {
    this.j = paramK;
    if ((paramK != null) && (paramK.C() != null))
      C().B(paramK.C().isNoLimit());
    this.a = paramPlayer;
    this._ = new V();
    this._.D(paramE);
    this.c = 0;
    A(paramK.P());
  }

  public boolean £()
  {
    return false;
  }

  protected boolean Á()
  {
    return false;
  }

  protected void y()
  {
    for (int i = 0; i < 10; i++)
      if (!this.i.N(i))
      {
        A(S(i), this.i.J(i), L(i));
        E(S(i)).E(this.i.P(i));
      }
  }

  public Player L(int paramInt)
  {
    if (paramInt == this.i.a())
      return this.a;
    Object localObject = this.B[S(paramInt)];
    if (localObject == null)
      localObject = this.j.L(S(paramInt));
    if (localObject == null)
    {
      com.biotools.poker.E.B localB = com.biotools.poker.E.B.D(this.i.J(paramInt));
      if (localB != null)
      {
        com.biotools.poker.E.H("Loading player '" + this.i.J(paramInt) + "'");
        localObject = com.biotools.poker.E.B.F(localB.M());
      }
    }
    if (localObject == null)
    {
      com.biotools.poker.E.H("Could not find player '" + this.i.J(paramInt) + "'");
      localObject = new N();
    }
    return localObject;
  }

  protected Action F()
  {
    int i = this.N.getCurrentPlayerSeat();
    Player localPlayer = L(i);
    double d = this.N.getAmountToCall(i);
    Action localAction1 = null;
    try
    {
      if (!this.k)
        if ((localPlayer instanceof W))
        {
          localAction1 = localPlayer.getAction();
          Action localAction2 = A(d, this.Y++);
          if (!localAction2.equivalent(localAction1))
          {
            com.biotools.poker.E.H("HUMAN DEVIATED!");
            this.k = true;
          }
        }
        else
        {
          com.biotools.poker.E.H("CHOOSING FIXED ACTION");
          localAction1 = A(d, this.Y++);
        }
      if (localAction1 == null)
        localAction1 = localPlayer.getAction();
    }
    catch (Exception localException)
    {
      localAction1 = Action.checkOrFoldAction(d);
      d.A("problem getting next action, doing call/fold");
      d.A(localException);
    }
    return localAction1;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.Q.C
 * JD-Core Version:    0.6.2
 */