package com.biotools.poker.Q;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.GameInfo;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.meerkat.util.Preferences;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class D
  implements GameInfo, Serializable
{
  public static Preferences E = new Preferences();
  private double Y = 5.0D;
  private double Q = 10.0D;
  private double N = 20.0D;
  private double T = 0.0D;
  private String _ = "logs/";
  private boolean I = false;
  private boolean a = false;
  private boolean b = false;
  private boolean R = false;
  private H d;
  private F[] V = new F[10];
  private Card[] L = new Card[5];
  private StringBuffer P;
  private int M = 0;
  private int O = 0;
  private int X = 0;
  private int H;
  private int A = -1;
  private int S = -1;
  private int B = -1;
  private String D;
  private double G = 0.0D;
  private double K;
  private int C = 1;
  private long e = 0L;
  private int Z = 0;
  private double F = 0.0D;
  private double c = 0.0D;
  private double W = 0.0D;
  private boolean J = true;
  private ArrayList U = new ArrayList();

  public void A(D paramD)
  {
    this.Y = paramD.Y;
    this.Q = paramD.Q;
    this.N = paramD.N;
    this.T = paramD.T;
    this._ = paramD._;
    this.I = paramD.I;
    this.a = paramD.a;
    this.b = paramD.b;
    this.R = paramD.R;
    this.M = paramD.M;
    this.O = paramD.O;
    this.X = paramD.X;
    this.H = paramD.H;
    this.A = paramD.A;
    this.S = paramD.S;
    this.B = paramD.B;
    this.D = paramD.D;
    this.G = paramD.G;
    this.K = paramD.K;
    this.C = paramD.C;
    this.e = paramD.e;
    this.Z = paramD.Z;
    this.F = paramD.F;
    this.c = paramD.c;
    this.W = paramD.W;
    this.J = paramD.J;
    this.U.clear();
    this.U.addAll(paramD.U);
    this.P = new StringBuffer();
    this.P.append(paramD.P);
    for (int i = 0; i < 5; i++)
      this.L[i] = paramD.L[i];
    this.d = new H(paramD.d);
    this.d.A(this);
    for (i = 0; i < this.V.length; i++)
      this.V[i] = new F(paramD.V[i], this);
  }

  private synchronized void e()
  {
    this.O = 0;
    for (int i = 0; i < this.V.length; i++)
      if (inGame(i))
        this.O += 1;
  }

  private void T()
  {
    this.e = (E.getInt("GAME_ID", 0) + 1);
    E.putLong("GAME_ID", this.e);
  }

  public static synchronized int R()
  {
    return E.getInt("GAME_ID", 0);
  }

  public static synchronized void B(long paramLong)
  {
    E.putLong("GAME_ID", paramLong);
  }

  public synchronized void C(String paramString)
  {
    this._ = paramString;
  }

  public synchronized String getLogDirectory()
  {
    return this._;
  }

  public void B(boolean paramBoolean)
  {
    this.b = paramBoolean;
  }

  public boolean isNoLimit()
  {
    return this.b;
  }

  public boolean isFixedLimit()
  {
    return !this.b;
  }

  public boolean isPotLimit()
  {
    return false;
  }

  public boolean isSimulation()
  {
    return this.I;
  }

  public void A(boolean paramBoolean)
  {
    this.I = paramBoolean;
  }

  public boolean isZipMode()
  {
    return this.a;
  }

  public void C(boolean paramBoolean)
  {
    this.a = paramBoolean;
  }

  public boolean P()
  {
    return this.R;
  }

  public void D(boolean paramBoolean)
  {
    this.R = paramBoolean;
  }

  public synchronized boolean inGame(int paramInt)
  {
    F localF = G(paramInt);
    if (localF != null)
      return localF.inGame();
    return false;
  }

  public synchronized boolean E(int paramInt)
  {
    return G(paramInt) == null;
  }

  public synchronized void U()
  {
    if (!isSimulation())
      T();
    A(this.e);
  }

  public synchronized void A(long paramLong)
  {
    e();
    for (int i = 0; i < getNumSeats(); i++)
      if (!E(i))
        G(i).D(inGame(i));
    J();
    F(this.T);
    this.P = new StringBuffer();
    this.X = this.O;
    this.H = this.X;
    this.F = 0.0D;
    this.c = 0.0D;
    this.e = paramLong;
    this.Z = 0;
    this.C = 1;
    this.W = c();
    for (i = 0; i < 5; i++)
      this.L[i] = null;
    this.D = null;
    this.d = new H(this);
    this.J = false;
    this.U.clear();
  }

  public void F(int paramInt)
  {
    if (inGame(paramInt))
    {
      G(paramInt).F(false);
      this.X -= 1;
      this.O -= 1;
      this.H -= 1;
    }
  }

  public synchronized PlayerInfo E(String paramString)
  {
    return new F(paramString, this);
  }

  public synchronized boolean A(String paramString, int paramInt)
  {
    if (A(paramString) != null)
      return false;
    M(paramInt);
    this.V[paramInt] = new F(paramString, this);
    this.O += 1;
    return true;
  }

  public synchronized void M(int paramInt)
  {
    if (this.V[paramInt] != null)
      this.O -= 1;
    this.V[paramInt] = null;
  }

  public synchronized boolean B(String paramString)
  {
    int i = getPlayerSeat(paramString);
    if (i >= 0)
    {
      M(i);
      return true;
    }
    return false;
  }

  public synchronized void X()
  {
    for (int i = 0; i < this.V.length; i++)
      M(i);
    assert (this.O == 0);
    this.O = 0;
  }

  public synchronized int M()
  {
    return this.A;
  }

  public synchronized int getButtonSeat()
  {
    return this.A;
  }

  public synchronized int getSmallBlindSeat()
  {
    return this.S;
  }

  public synchronized int getBigBlindSeat()
  {
    return this.B;
  }

  public synchronized void D(double paramDouble)
  {
    this.T = paramDouble;
    F(this.T);
  }

  public synchronized void L(int paramInt)
  {
    this.A = paramInt;
  }

  public synchronized void A(int paramInt)
  {
    this.S = paramInt;
  }

  public synchronized void B(int paramInt)
  {
    this.B = paramInt;
  }

  public synchronized double getSmallBlindSize()
  {
    return this.Y;
  }

  public synchronized double getBigBlindSize()
  {
    return this.Q;
  }

  public synchronized void A(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    this.Y = paramDouble1;
    this.Q = paramDouble2;
    this.N = paramDouble3;
  }

  public synchronized void A(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    this.Y = A(paramDouble1);
    this.Q = A(paramDouble2);
    this.N = A(paramDouble3);
    this.T = A(paramDouble4);
  }

  public synchronized double K()
  {
    return this.Q;
  }

  public synchronized double N()
  {
    return this.N;
  }

  public synchronized int getStage()
  {
    return this.Z;
  }

  public synchronized boolean isPreFlop()
  {
    return this.Z == 0;
  }

  public synchronized boolean isFlop()
  {
    return this.Z == 1;
  }

  public synchronized boolean isTurn()
  {
    return this.Z == 2;
  }

  public synchronized boolean isRiver()
  {
    return this.Z == 3;
  }

  public synchronized boolean isPostFlop()
  {
    return this.Z > 0;
  }

  public synchronized double getTotalPotSize()
  {
    return this.F;
  }

  public synchronized long b()
  {
    return this.e;
  }

  public synchronized long getGameID()
  {
    return this.e;
  }

  public void C(long paramLong)
  {
    this.e = paramLong;
  }

  public synchronized int getNumPlayers()
  {
    return this.O;
  }

  public synchronized int getNumActivePlayers()
  {
    return this.X;
  }

  public synchronized int getNumRaises()
  {
    return this.C;
  }

  public synchronized Card C(int paramInt)
  {
    return this.L[paramInt];
  }

  public synchronized Hand getBoard()
  {
    Hand localHand = new Hand();
    if (this.L != null)
    {
      if (this.Z >= 1)
      {
        localHand.addCard(this.L[0]);
        localHand.addCard(this.L[1]);
        localHand.addCard(this.L[2]);
      }
      if (this.Z >= 2)
        localHand.addCard(this.L[3]);
      if (this.Z >= 3)
        localHand.addCard(this.L[4]);
    }
    return localHand;
  }

  public synchronized int getPlayerSeat(String paramString)
  {
    for (int i = 0; i < this.V.length; i++)
    {
      F localF = G(i);
      if ((localF != null) && (localF.getName().equals(paramString)))
        return i;
    }
    return -1;
  }

  public synchronized String getPlayerName(int paramInt)
  {
    if ((paramInt >= 0) && (paramInt < this.V.length))
    {
      F localF = G(paramInt);
      if (localF != null)
        return localF.getName();
    }
    return null;
  }

  public synchronized String Y()
  {
    return getPlayerName(this.M);
  }

  public synchronized F G(int paramInt)
  {
    if ((paramInt >= 0) && (paramInt < getNumSeats()))
      return this.V[paramInt];
    return null;
  }

  public synchronized F A(String paramString)
  {
    for (int i = 0; i < this.V.length; i++)
    {
      F localF = G(i);
      if ((localF != null) && (localF.getName().equals(paramString)))
        return localF;
    }
    return null;
  }

  public synchronized F Q()
  {
    return G(this.M);
  }

  public synchronized int getCurrentPlayerSeat()
  {
    return this.M;
  }

  public synchronized void H(int paramInt)
  {
    this.M = paramInt;
  }

  public synchronized int C()
  {
    this.M = nextActivePlayer(this.M);
    return this.M;
  }

  public synchronized int nextPlayer(int paramInt)
  {
    assert ((paramInt >= 0) && (paramInt < getNumSeats()));
    if ((paramInt < 0) || (paramInt >= getNumSeats()))
      paramInt = 0;
    for (int i = (paramInt + 1) % getNumSeats(); i != paramInt; i = (i + 1) % getNumSeats())
      if (inGame(i))
        return i;
    return paramInt;
  }

  public synchronized int nextSeat(int paramInt)
  {
    assert ((paramInt >= 0) && (paramInt < getNumSeats()));
    if ((paramInt < 0) || (paramInt >= getNumSeats()))
      paramInt = 0;
    int i = (paramInt + 1) % getNumSeats();
    return i;
  }

  public synchronized int previousPlayer(int paramInt)
  {
    assert ((paramInt >= 0) && (paramInt < this.V.length));
    if ((paramInt < 0) || (paramInt >= this.V.length))
      paramInt = 0;
    int i = paramInt - 1;
    if (i < 0)
      i = this.V.length - 1;
    while (i != paramInt)
    {
      if (inGame(i))
        return i;
      i--;
      if (i < 0)
        i = this.V.length - 1;
    }
    return paramInt;
  }

  public synchronized int nextActivePlayer(int paramInt)
  {
    if (this.J)
      return -1;
    for (int i = nextPlayer(paramInt); (!isActive(i)) && (i != paramInt); i = nextPlayer(i));
    return i;
  }

  public synchronized boolean isActive(int paramInt)
  {
    F localF = G(paramInt);
    if (localF == null)
      return false;
    return localF.isActive();
  }

  public synchronized double getMinRaise()
  {
    return this.W;
  }

  public synchronized void L()
  {
    this.H -= 1;
    this.P.append('_');
  }

  public synchronized boolean B()
  {
    F localF = Q();
    if (localF != null)
      localF.E();
    this.P.append('f');
    this.X -= 1;
    this.H -= 1;
    J();
    return this.X == 1;
  }

  public synchronized void K(int paramInt)
  {
    this.X -= 1;
    this.H -= 1;
    G(paramInt).I();
    J();
  }

  public synchronized double getAnte()
  {
    return this.T;
  }

  public synchronized double D(int paramInt)
  {
    double d1 = G(paramInt).I(getStakes());
    this.F = A(this.F + d1);
    return d1;
  }

  public synchronized double getRake()
  {
    return this.c;
  }

  public synchronized void B(double paramDouble)
  {
    this.c = A(paramDouble);
  }

  public synchronized double I()
  {
    assert (inGame(this.M)) : this.M;
    F(this.T + getSmallBlindSize());
    double d1 = Q().I(getStakes());
    this.F = A(this.F + d1);
    Q().O();
    this.P.append('s');
    this.S = this.M;
    return d1;
  }

  public synchronized double A()
  {
    assert (inGame(this.M)) : this.M;
    F(this.Q + this.T);
    double d1 = Q().I(getStakes());
    this.F = A(this.F + d1);
    Q().F();
    this.P.append('B');
    this.B = this.M;
    J();
    return d1;
  }

  public synchronized double A(int paramInt, double paramDouble)
  {
    assert (inGame(paramInt)) : paramInt;
    paramDouble = G(paramInt).I(paramDouble);
    this.F = A(this.F + paramDouble);
    G(paramInt).N();
    this.P.append("P" + paramInt);
    return paramDouble;
  }

  public synchronized double B(int paramInt, double paramDouble)
  {
    assert (inGame(paramInt)) : paramInt;
    paramDouble = G(paramInt).D(paramDouble);
    this.F = A(this.F + paramDouble);
    this.P.append("D" + paramInt);
    return paramDouble;
  }

  public synchronized double S()
  {
    F localF = Q();
    if (localF != null)
    {
      double d1 = localF.G(getStakes());
      this.F = A(this.F + d1);
      this.H -= 1;
      this.P.append(d1 > 0.0D ? 'c' : 'k');
      return d1;
    }
    return 0.0D;
  }

  public synchronized double C(double paramDouble)
  {
    return Q().getRaiseAmount(paramDouble);
  }

  public synchronized double E(double paramDouble)
  {
    paramDouble = A(paramDouble);
    double d1 = C(paramDouble);
    if (d1 > this.W)
      this.W = d1;
    F(getStakes() + d1);
    this.U.add(new Double(d1));
    if (this.C == 0)
    {
      this.F = A(this.F + Q().B(getStakes()));
      this.P.append('b');
    }
    else
    {
      this.F = A(this.F + Q().F(getStakes()));
      this.P.append('r');
    }
    this.C += 1;
    this.H = (this.X - 1);
    return d1;
  }

  public ArrayList H()
  {
    return this.U;
  }

  public synchronized void A(Card paramCard1, Card paramCard2, Card paramCard3)
  {
    this.Z = 1;
    this.L[0] = paramCard1;
    this.L[1] = paramCard2;
    this.L[2] = paramCard3;
    for (int i = 0; i < getNumSeats(); i++)
      if (isActive(i))
        G(i).D();
    this.M = nextActivePlayer(this.A);
    this.C = 0;
    this.H = this.X;
    this.P.append('/');
    this.W = c();
  }

  public synchronized void B(Card paramCard)
  {
    this.Z = 2;
    this.L[3] = paramCard;
    for (int i = 0; i < getNumSeats(); i++)
      if (isActive(i))
        G(i).D();
    this.M = nextActivePlayer(this.A);
    this.C = 0;
    this.H = this.X;
    this.P.append('/');
    this.W = c();
  }

  public synchronized void A(Card paramCard)
  {
    this.Z = 3;
    this.L[4] = paramCard;
    for (int i = 0; i < getNumSeats(); i++)
      if (isActive(i))
        G(i).D();
    this.M = nextActivePlayer(this.A);
    this.C = 0;
    this.H = this.X;
    this.P.append('/');
    this.W = c();
  }

  public synchronized void D()
  {
    if (getNumActivePlayers() > 1)
      this.Z = 4;
    this.J = true;
  }

  public boolean isGameOver()
  {
    return this.J;
  }

  public synchronized void O()
  {
    if (isSimulation())
      return;
    for (int i = 0; i < getNumSeats(); i++)
      if (inGame(i))
        G(i).J();
  }

  public synchronized void A(String paramString, Card paramCard1, Card paramCard2)
  {
    A(getPlayerSeat(paramString), paramCard1, paramCard2);
  }

  public synchronized void A(int paramInt, Card paramCard1, Card paramCard2)
  {
    F localF = G(paramInt);
    if (localF == null)
      return;
    localF.A(paramCard1, paramCard2);
  }

  public synchronized void D(String paramString)
  {
    if (this.D == null)
      this.D = new String(paramString);
    else
      this.D = (this.D + "," + paramString);
  }

  public synchronized String Z()
  {
    return this.D;
  }

  public synchronized int getNumWinners()
  {
    if (this.D == null)
      return 0;
    return this.D.split(",").length;
  }

  public synchronized int getUnacted()
  {
    int i = 0;
    for (int j = 0; j < getNumSeats(); j++)
      if ((inGame(j)) && (!G(j).hasActedThisRound()))
        i++;
    return i;
  }

  public synchronized int _()
  {
    assert (M() != -1) : M();
    return nextPlayer(this.A);
  }

  public synchronized double getAmountToCall(int paramInt)
  {
    F localF = G(paramInt);
    if (localF != null)
      return localF.A(getStakes());
    return 0.0D;
  }

  public synchronized double getBetsToCall(int paramInt)
  {
    return G(paramInt).A(getStakes()) / c();
  }

  public synchronized boolean J(int paramInt)
  {
    return G(paramInt).isCommitted();
  }

  public synchronized double getStakes()
  {
    return this.G;
  }

  private void F(double paramDouble)
  {
    this.G = A(paramDouble);
    if (this.G > this.K)
      this.G = this.K;
  }

  private void J()
  {
    double d1 = 0.0D;
    double d2 = 0.0D;
    int i = 0;
    int j = 0;
    for (int k = 0; k < getNumSeats(); k++)
      if (isActive(k))
      {
        j++;
        F localF = G(k);
        double d3 = localF.getBankRoll() + localF.getAmountInPot();
        if (d3 > d1)
          d1 = d3;
        if (localF.isAllIn())
        {
          i++;
          if (d3 > d2)
            d2 = d3;
        }
      }
    if (j - i == 1)
      d1 = d2;
    this.K = d1;
    F(getStakes());
  }

  public synchronized double c()
  {
    if ((this.Z < 2) || (isNoLimit()))
      return this.Q;
    return this.N;
  }

  public synchronized double getCurrentBetSize()
  {
    return c();
  }

  public synchronized int getNumToAct()
  {
    return this.H;
  }

  public synchronized String d()
  {
    if (this.P != null)
      return this.P.toString();
    return null;
  }

  public final int getNumSeats()
  {
    return 10;
  }

  public synchronized void W()
  {
    this.A = previousPlayer(this.A);
  }

  public synchronized boolean a()
  {
    return A(Q());
  }

  public synchronized boolean canRaise(int paramInt)
  {
    return A(G(paramInt));
  }

  public synchronized boolean A(PlayerInfo paramPlayerInfo)
  {
    if (getNumRaises() >= 4)
    {
      if (getNumRaises() > 50)
        return false;
      if ((!this.b) && ((getNumActivePlayers() != 2) || (!this.R)))
        return false;
    }
    if (!paramPlayerInfo.hasEnoughToRaise())
      return false;
    return getNumActivePlayersNotAllIn() > 1;
  }

  public synchronized PlayerInfo E()
  {
    F localF = null;
    double d1 = -1.0D;
    int i = getCurrentPlayerSeat();
    for (int j = 0; j < getNumActivePlayers(); j++)
    {
      double d2 = G(i).getAmountInPot();
      if (d2 > d1)
      {
        localF = G(i);
        d1 = d2;
      }
      i = nextActivePlayer(i);
    }
    return localF;
  }

  public synchronized int getNumberOfAllInPlayers()
  {
    int i = 0;
    for (int j = 0; j < getNumSeats(); j++)
      if ((isActive(j)) && (G(j).isAllIn()))
        i++;
    return i;
  }

  public synchronized int getNumActivePlayersNotAllIn()
  {
    return getNumActivePlayers() - getNumberOfAllInPlayers();
  }

  public synchronized List getPlayersInPot(double paramDouble)
  {
    paramDouble = A(paramDouble);
    ArrayList localArrayList = new ArrayList();
    int i = getCurrentPlayerSeat();
    if (!G(i).isActive())
      i = nextActivePlayer(i);
    for (int j = 0; j < getNumActivePlayers(); j++)
    {
      if (G(i).getAmountInPot() >= paramDouble)
        localArrayList.add(G(i));
      i = nextActivePlayer(i);
    }
    return localArrayList;
  }

  public synchronized double getEligiblePot(int paramInt)
  {
    double d1 = 0.0D;
    double d2 = G(paramInt).getAmountInPot() + G(paramInt).getBankRoll();
    for (int i = 0; i < getNumSeats(); i++)
      if (inGame(i))
      {
        double d3 = G(i).getAmountInPot();
        if (d3 > d2)
          d3 = d2;
        d1 += d3;
        d3 = G(i).L();
        if (d3 > d2)
          d3 = d2;
        d1 += d3;
      }
    return A(d1);
  }

  public synchronized H F()
  {
    if (this.d == null)
      this.d = new H(this);
    return this.d;
  }

  public synchronized void A(double paramDouble, PlayerInfo paramPlayerInfo)
  {
    this.d.A(A(paramDouble), paramPlayerInfo);
  }

  private double A(double paramDouble)
  {
    return Math.round(paramDouble * 100.0D) / 100.0D;
  }

  public synchronized double V()
  {
    double d1 = this.d.G();
    d1 = A(d1);
    this.G = A(this.G - d1);
    this.F = A(this.F - d1);
    return d1;
  }

  public synchronized int G()
  {
    int i = 0;
    for (int j = 0; j < getNumSeats(); j++)
      if ((inGame(j)) && (!G(j).isAllIn()))
        i++;
    return i;
  }

  private int A(int paramInt1, int paramInt2)
  {
    if (paramInt1 < 0)
      return paramInt1;
    int i = paramInt1 - paramInt2;
    if (i < 0)
      i += 10;
    return i;
  }

  public void I(int paramInt)
  {
    F[] arrayOfF = new F[getNumSeats()];
    for (int i = 0; i < getNumSeats(); i++)
      arrayOfF[i] = this.V[i];
    for (i = 0; i < getNumSeats(); i++)
      this.V[A(i, paramInt)] = arrayOfF[i];
    this.A = A(this.A, paramInt);
    this.S = A(this.S, paramInt);
    this.B = A(this.B, paramInt);
    this.M = A(this.M, paramInt);
  }

  public void B(int paramInt1, int paramInt2)
  {
    F localF = this.V[paramInt1];
    this.V[paramInt1] = this.V[paramInt2];
    this.V[paramInt2] = localF;
  }

  public double getMainPotSize()
  {
    return F().H();
  }

  public int getNumSidePots()
  {
    return F().D() - 1;
  }

  public double getSidePotSize(int paramInt)
  {
    H localH = F().F();
    while ((paramInt > 0) && (localH != null))
    {
      localH = localH.F();
      paramInt--;
    }
    if (localH != null)
      return localH.H();
    return -1.0D;
  }

  public synchronized double getBankRoll(int paramInt)
  {
    if (inGame(paramInt))
      return G(paramInt).getBankRoll();
    return 0.0D;
  }

  public synchronized boolean isCommitted(int paramInt)
  {
    if (inGame(paramInt))
      return G(paramInt).isCommitted();
    return false;
  }

  public synchronized double getBankRollAtRisk(int paramInt)
  {
    if (inGame(paramInt))
      return G(paramInt).getBankRollAtRisk();
    return 0.0D;
  }

  public PlayerInfo getPlayer(int paramInt)
  {
    return G(paramInt);
  }

  public PlayerInfo getPlayer(String paramString)
  {
    return A(paramString);
  }

  public boolean isReverseBlinds()
  {
    return (getNumPlayers() == 2) && (getSmallBlindSeat() == getButtonSeat());
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.Q.D
 * JD-Core Version:    0.6.2
 */