package com.biotools.poker.Q;

import com.biotools.A.b;
import com.biotools.A.d;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.GameObserver;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.Player;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.poker.D.G;
import com.biotools.poker.F.N;
import com.biotools.poker.N.W;
import com.biotools.poker.Q.A.A;
import java.io.PrintStream;
import java.util.Collections;
import java.util.ConcurrentModificationException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Vector;

public class K
  implements Runnable
{
  public static final int D = 0;
  public static final int G = 1;
  public static final int L = 2;
  public static final int V = 3;
  public static final int C = 4;
  public static final int A = 5;
  public static final int R = 6;
  public boolean I = true;
  public static final int S = 10;
  protected com.biotools.poker.K.D E = new com.biotools.poker.K.D();
  protected Set T = Collections.synchronizedSet(new HashSet());
  protected D N;
  protected Deck W;
  protected boolean J = false;
  protected Player[] B;
  protected Hand[] F;
  protected int[] M;
  protected int Q = 0;
  protected boolean K = true;
  protected volatile boolean O = false;
  protected volatile boolean H = false;
  protected A U = null;
  private Vector P;

  public K()
  {
    N();
    this.W = new Deck();
  }

  public K(int paramInt)
  {
    N();
    this.W = new Deck(paramInt);
  }

  private double B(double paramDouble)
  {
    return Math.round(paramDouble * 100.0D) / 100.0D;
  }

  public void B(GameObserver paramGameObserver)
  {
    boolean bool = this.T.add(paramGameObserver);
  }

  public void l()
  {
    this.T.clear();
  }

  public void C(GameObserver paramGameObserver)
  {
    this.T.remove(paramGameObserver);
  }

  public Set q()
  {
    return this.T;
  }

  public boolean A(GameObserver paramGameObserver)
  {
    return this.T.contains(paramGameObserver);
  }

  public void J(int paramInt)
  {
    this.W = new Deck(paramInt);
  }

  protected void N()
  {
    this.F = new Hand[10];
    this.B = new Player[10];
    this.M = new int[10];
    this.N = new D();
    this.N.C(com.biotools.poker.E.n());
    B(new G());
  }

  public synchronized boolean A(int paramInt, String paramString, Player paramPlayer)
  {
    assert ((paramInt >= 0) && (paramInt < 10));
    this.B[paramInt] = paramPlayer;
    this.N.A(paramString, paramInt);
    if ((this.H) && (this.J))
    {
      F localF = this.N.G(paramInt);
      if (!localF.inGame())
        localF.E(true);
    }
    return true;
  }

  public synchronized void R(int paramInt)
  {
    if ((paramInt < 0) || (paramInt > 10))
      return;
    this.N.M(paramInt);
    this.B[paramInt] = null;
  }

  public synchronized void j()
  {
    for (int i = 0; i < 10; i++)
      R(i);
  }

  public String F(int paramInt)
  {
    return this.N.getPlayerName(paramInt);
  }

  public D C()
  {
    return this.N;
  }

  public void f()
  {
    Object[] arrayOfObject = { new Long(this.N.b()) };
    C("\n" + com.biotools.poker.E.A("RemoteDealer.HandNumberPattern", arrayOfObject), 3);
  }

  public boolean H(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= this.B.length))
      return false;
    return this.B[paramInt] != null;
  }

  public void G()
  {
    for (int i = 0; i < 10; i++)
      if (this.N.inGame(i))
        this.B[i].holeCards(this.F[i].getCard(1), this.F[i].getCard(2), i);
  }

  protected Hand P(int paramInt)
  {
    if (E.E(paramInt))
      return K(paramInt);
    if (E.C(paramInt))
      return B(paramInt);
    Hand localHand = new Hand();
    localHand.addCard(this.W.dealCard());
    localHand.addCard(this.W.dealCard());
    return localHand;
  }

  private Hand B(int paramInt)
  {
    Hand localHand = new Hand();
    Card localCard1 = E.B(paramInt, 0);
    if (localCard1 != null)
      localHand.addCard(localCard1);
    else
      localHand.addCard(this.W.dealCard());
    Card localCard2 = E.B(paramInt, 1);
    if (localCard2 != null)
      localHand.addCard(localCard2);
    else
      localHand.addCard(this.W.dealCard());
    return localHand;
  }

  private Hand K(int paramInt)
  {
    int i = 0;
    while (i++ < 2000)
    {
      localHand = new Hand();
      localHand.addCard(this.W.dealCard());
      localHand.addCard(this.W.dealCard());
      double d1 = com.biotools.poker.D.D.A(localHand.getCard(1), localHand.getCard(2), this.N.getNumPlayers());
      if (E.A(paramInt) == 0)
      {
        if (d1 >= 1.0D - E.F(paramInt) / 100.0D)
          return localHand;
      }
      else if (E.A(paramInt) == 1)
      {
        double d2 = (1.0D - E.F(paramInt) / 100.0D) / 2.0D;
        if ((d1 >= d2) && (d1 <= 1.0D - d2))
          return localHand;
      }
      else if ((E.A(paramInt) == 2) && (d1 <= E.F(paramInt) / 100.0D))
      {
        return localHand;
      }
      this.W.replaceCard(localHand.getCard(1));
      this.W.replaceCard(localHand.getCard(2));
    }
    com.biotools.poker.E.H("Failed to satisfy constraint!");
    Hand localHand = new Hand();
    localHand.addCard(this.W.dealCard());
    localHand.addCard(this.W.dealCard());
    return localHand;
  }

  protected void J()
  {
    this.Q = 0;
    this.W.shuffle();
    this.W.shuffle();
    E.A(this.W);
    for (int i = 0; i < 10; i++)
      if (this.N.inGame(i))
      {
        this.M[i] = -1;
        this.F[i] = P(i);
      }
      else
      {
        this.F[i] = null;
      }
  }

  protected Card K()
  {
    this.Q += 1;
    Card localCard = E.B(this.Q - 1);
    if (localCard != null)
      return localCard;
    return this.W.dealCard();
  }

  public void n()
  {
    if (!this.O)
    {
      Thread localThread = new Thread(this, "Dealer");
      localThread.start();
    }
  }

  public boolean R()
  {
    return this.O;
  }

  public void run()
  {
    try
    {
      V();
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  public boolean A(Player paramPlayer)
  {
    for (int i = 0; i < 10; i++)
      if (this.B[i] == paramPlayer)
        return true;
    return false;
  }

  public boolean D(int paramInt)
  {
    if (H(paramInt))
    {
      F localF = E(paramInt);
      if (!localF.isAllIn())
        return true;
    }
    return false;
  }

  protected void X()
  {
    if (this.K)
    {
      if (this.N.getSmallBlindSeat() == -1)
      {
        U();
      }
      else
      {
        this.N.inGame(this.N.getSmallBlindSeat());
        this.N.L(this.N.getSmallBlindSeat());
      }
      if (this.N.getBigBlindSeat() != -1)
      {
        this.N.inGame(this.N.getBigBlindSeat());
        this.N.A(this.N.getBigBlindSeat());
      }
      else
      {
        this.N.A(this.N.nextPlayer(this.N.M()));
      }
      this.N.B(this.N.nextPlayer(this.N.getSmallBlindSeat()));
      if (this.N.getButtonSeat() == this.N.getBigBlindSeat())
        this.N.L(this.N.previousPlayer(this.N.getSmallBlindSeat()));
    }
    else
    {
      assert (this.N.M() != -1);
      if (this.N.getSmallBlindSeat() == -1)
        this.N.A(this.N.nextPlayer(this.N.M()));
      if (this.N.getBigBlindSeat() == -1)
        this.N.B(this.N.nextPlayer(this.N.getSmallBlindSeat()));
    }
    this.K = true;
  }

  protected void B()
  {
    assert (this.N.getNumPlayers() == 2);
    if (this.K)
    {
      if (this.N.getBigBlindSeat() != -1)
      {
        if (this.N.inGame(this.N.getBigBlindSeat()))
        {
          this.N.B(this.N.nextPlayer(this.N.getBigBlindSeat()));
          this.N.A(this.N.nextPlayer(this.N.getBigBlindSeat()));
        }
        else
        {
          this.N.B(this.N.nextPlayer(this.N.getBigBlindSeat()));
          this.N.A(this.N.nextPlayer(this.N.getBigBlindSeat()));
        }
      }
      else
      {
        U();
        if (this.I)
        {
          this.N.A(this.N.M());
          this.N.B(this.N.nextPlayer(this.N.getSmallBlindSeat()));
        }
        else
        {
          this.N.A(this.N.nextPlayer(this.N.M()));
          this.N.B(this.N.nextPlayer(this.N.getSmallBlindSeat()));
        }
      }
      if (this.I)
        this.N.L(this.N.getSmallBlindSeat());
      else
        this.N.L(this.N.getBigBlindSeat());
    }
    else
    {
      assert (this.N.M() != -1);
      if (this.I)
      {
        this.N.B(this.N.nextPlayer(this.N.M()));
        this.N.A(this.N.nextPlayer(this.N.getBigBlindSeat()));
      }
      else
      {
        this.N.A(this.N.nextPlayer(this.N.M()));
        this.N.B(this.N.nextPlayer(this.N.getSmallBlindSeat()));
      }
    }
    this.K = true;
  }

  private void U()
  {
    if (this.N.M() != -1)
    {
      this.N.L(this.N.nextPlayer(this.N.M()));
    }
    else
    {
      int i = -1;
      for (int j = 0; j < 10; j++)
        if (this.N.inGame(j))
        {
          i = j;
          break;
        }
      assert (i != -1);
      this.N.L(i);
    }
  }

  protected void i()
  {
    int i = this.N.getButtonSeat();
    int j = this.N.getSmallBlindSeat();
    int k = this.N.getBigBlindSeat();
    if (this.N.getBigBlindSeat() == -1)
    {
      U();
      if (this.N.getNumPlayers() == 2)
      {
        if (this.I)
        {
          this.N.A(this.N.getButtonSeat());
          this.N.B(this.N.nextPlayer(this.N.getButtonSeat()));
        }
        else
        {
          this.N.B(this.N.getButtonSeat());
          this.N.A(this.N.nextPlayer(this.N.getButtonSeat()));
        }
      }
      else
      {
        this.N.A(this.N.nextPlayer(this.N.getButtonSeat()));
        this.N.B(this.N.nextPlayer(this.N.getSmallBlindSeat()));
      }
    }
    else
    {
      int m;
      if (this.N.getNumPlayers() == 2)
      {
        this.N.A(this.N.getBigBlindSeat());
        this.N.B(this.N.nextPlayer(this.N.getBigBlindSeat()));
        if (!this.N.inGame(this.N.getSmallBlindSeat()))
        {
          this.N.A(this.N.getBigBlindSeat());
          this.N.B(this.N.nextPlayer(this.N.getBigBlindSeat()));
        }
        if (this.I)
          this.N.L(this.N.getSmallBlindSeat());
        else
          this.N.L(this.N.getBigBlindSeat());
        assert (this.N.inGame(this.N.getSmallBlindSeat())) : "dead small blind heads up";
        assert (this.N.inGame(this.N.getBigBlindSeat())) : "dead big blind heads up";
        for (m = 0; m < 10; m++)
        {
          F localF1 = this.N.G(m);
          if (localF1 != null)
            if (localF1.inGame())
            {
              localF1.E(false);
              localF1.C(false);
              localF1.A(false);
            }
            else
            {
              localF1.E(true);
              localF1.C(false);
              localF1.A(false);
            }
        }
      }
      else
      {
        this.N.L(this.N.getSmallBlindSeat());
        this.N.A(this.N.getBigBlindSeat());
        this.N.B(this.N.nextPlayer(this.N.getBigBlindSeat()));
        if ((A(this.N.getButtonSeat(), this.N.getSmallBlindSeat(), this.N.getBigBlindSeat())) || (this.N.getButtonSeat() == this.N.getBigBlindSeat()))
        {
          this.N.L(this.N.getSmallBlindSeat());
          this.N.A(this.N.getBigBlindSeat());
          this.N.B(this.N.nextPlayer(this.N.getBigBlindSeat()));
        }
        m = 0;
        int n = 0;
        F localF3;
        for (int i1 = 0; i1 < 10; i1++)
        {
          localF3 = this.N.G(i1);
          if ((localF3 != null) && (localF3.inGame()))
            if (!A(this.N.getBigBlindSeat(), this.N.getButtonSeat(), i1))
            {
              if ((i1 != this.N.getBigBlindSeat()) && ((localF3.R()) || (localF3.Q()) || (localF3.G())))
                m++;
            }
            else if ((localF3.R()) || (localF3.Q()) || (localF3.G()))
              n++;
        }
        if (this.N.getNumPlayers() - m - n < 2)
        {
          F localF2;
          if (this.N.inGame(this.N.getSmallBlindSeat()))
          {
            localF2 = this.N.G(this.N.getSmallBlindSeat());
            localF2.E(false);
            localF2.C(false);
            localF2.A(false);
          }
          else
          {
            this.N.L(this.N.getSmallBlindSeat());
            this.N.A(this.N.getBigBlindSeat());
            this.N.B(this.N.nextPlayer(this.N.getBigBlindSeat()));
            localF2 = this.N.G(this.N.getSmallBlindSeat());
            localF2.E(false);
            localF2.C(false);
            localF2.A(false);
          }
        }
        for (int i2 = 0; i2 < 10; i2++)
        {
          localF3 = this.N.G(i2);
          if (localF3 != null)
            if (localF3.inGame())
            {
              if (!A(this.N.getBigBlindSeat(), this.N.getButtonSeat(), i2))
                if (i2 == this.N.getBigBlindSeat())
                {
                  localF3.E(false);
                  localF3.C(false);
                  localF3.A(false);
                }
                else if ((localF3.R()) || (localF3.Q()) || (localF3.G()))
                {
                  this.N.F(i2);
                  if (!localF3.R())
                    if (A(k, this.N.getBigBlindSeat(), i2))
                      localF3.A(true);
                    else if ((i2 == this.N.getSmallBlindSeat()) || (A(j, this.N.getSmallBlindSeat(), i2)))
                      localF3.C(true);
                }
            }
            else if (!localF3.R())
              if (A(k, this.N.getBigBlindSeat(), i2))
                localF3.A(true);
              else if ((i2 == this.N.getSmallBlindSeat()) || (A(j, this.N.getSmallBlindSeat(), i2)))
                localF3.C(true);
        }
        assert (this.N.getNumPlayers() >= 2) : (this.N.getNumPlayers() + " players when supposed to be >=2");
        assert (A(this.N.getButtonSeat(), this.N.getBigBlindSeat(), this.N.getSmallBlindSeat())) : "small blind not between button and big blind";
        assert (A(this.N.getSmallBlindSeat(), this.N.getButtonSeat(), this.N.getBigBlindSeat())) : "big blind not between small blind and button";
        assert (A(this.N.getBigBlindSeat(), this.N.getSmallBlindSeat(), this.N.getButtonSeat())) : "button not between big blind and small blind";
      }
    }
  }

  public void k()
  {
    this.N.A(-1);
    this.N.B(-1);
  }

  public void A(int paramInt, boolean paramBoolean)
  {
    this.K = paramBoolean;
    this.N.L(paramInt);
    this.N.A(-1);
    this.N.B(-1);
  }

  public void A(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    this.K = paramBoolean;
    this.N.L(paramInt1);
    this.N.A(paramInt2);
    this.N.B(paramInt3);
  }

  public void A(boolean paramBoolean)
  {
    this.K = paramBoolean;
  }

  public boolean Z()
  {
    return this.K;
  }

  protected void I()
  {
    if (this.N.getAnte() > 0.0D)
    {
      for (int i = 0; i < this.N.getNumSeats(); i++)
        if (this.N.inGame(i))
        {
          double d1 = this.N.getAnte();
          double d2 = this.N.G(i).getBankRoll();
          if (d2 < d1)
            d1 = d2;
          A(i, Action.postAnte(d1));
          this.N.D(i);
        }
      Object[] arrayOfObject = { Action.formatCash(this.N.getAnte()) };
      C(com.biotools.poker.E.A("RemoteDealer.EveryoneAntesPattern", arrayOfObject), 1);
      D();
    }
  }

  protected boolean A(PlayerInfo paramPlayerInfo)
  {
    return (!paramPlayerInfo.isAllIn()) && (!paramPlayerInfo.isSittingOut());
  }

  protected boolean A(int paramInt)
  {
    int i = this.N.getButtonSeat();
    while (i != this.N.getBigBlindSeat())
    {
      assert (i != -1);
      i = this.N.nextSeat(i);
      if (i == paramInt)
        return true;
    }
    return false;
  }

  protected void Y()
  {
    for (int i = 0; i < 10; i++)
    {
      F localF = this.N.G(i);
      if (localF != null)
        localF.F(A(localF));
    }
  }

  private boolean C(int paramInt)
  {
    int i = this.N.getSmallBlindSeat();
    if (paramInt == i)
      return false;
    for (int j = 0; j < this.N.getNumSeats(); j++)
    {
      i = this.N.nextSeat(i);
      if (i == paramInt)
        return false;
      if (i == this.N.getBigBlindSeat())
        return true;
    }
    return true;
  }

  public void c()
  {
    this.N.U();
  }

  public synchronized boolean V()
  {
    double d = 0.0D;
    this.O = true;
    this.N.C(false);
    Y();
    c();
    if (this.N.getNumPlayers() < 2)
    {
      this.O = false;
      this.H = false;
      try
      {
        Iterator localIterator = this.T.iterator();
        while (localIterator.hasNext())
          ((GameObserver)localIterator.next()).gameOverEvent();
      }
      catch (ConcurrentModificationException localConcurrentModificationException)
      {
        localConcurrentModificationException.printStackTrace();
      }
      return false;
    }
    if ((this.H) && (this.J))
      i();
    else if (this.N.getNumPlayers() == 2)
      B();
    else
      X();
    this.N.H(this.N.M());
    S();
    f();
    if (!this.O)
      return false;
    M(0);
    if (!this.O)
      return false;
    I();
    if (this.N.inGame(this.N.getSmallBlindSeat()))
    {
      this.N.H(this.N.getSmallBlindSeat());
      d = this.N.getSmallBlindSize();
      if (this.N.Q().getBankRoll() < d)
        d = this.N.Q().getBankRoll();
      A(this.N.getCurrentPlayerSeat(), Action.smallBlindAction(d));
      d = this.N.I();
      arrayOfObject1 = new Object[] { I(this.N.getCurrentPlayerSeat()), Action.formatCash(d) };
      C(com.biotools.poker.E.A("RemoteDealer.BlindsPattern", arrayOfObject1), 1);
      D();
    }
    if (!this.O)
      return false;
    this.N.H(this.N.getBigBlindSeat());
    d = this.N.getBigBlindSize();
    if (this.N.Q().getBankRoll() < d)
      d = (int)this.N.Q().getBankRoll();
    A(this.N.getCurrentPlayerSeat(), Action.bigBlindAction(d));
    d = this.N.A();
    Object[] arrayOfObject1 = { I(this.N.getCurrentPlayerSeat()), Action.formatCash(d) };
    C(com.biotools.poker.E.A("RemoteDealer.BlindsPattern", arrayOfObject1), 1);
    D();
    m();
    this.N.H(this.N.nextActivePlayer(this.N.getBigBlindSeat()));
    this.H = true;
    J();
    M();
    G();
    if (o())
      p();
    if (b())
      return true;
    if (!this.O)
      return false;
    this.N.A(K(), K(), K());
    M(1);
    Object[] arrayOfObject2 = { this.N.getBoard().toTranslatedString() };
    C("\n" + com.biotools.poker.E.A("RemoteDealer.FlopPattern", arrayOfObject2), 2);
    if (b())
      return true;
    if (!this.O)
      return false;
    this.N.B(K());
    M(2);
    Object[] arrayOfObject3 = { this.N.getBoard().toTranslatedString() };
    C("\n" + com.biotools.poker.E.A("RemoteDealer.TurnPattern", arrayOfObject3), 2);
    if (b())
      return true;
    if (!this.O)
      return false;
    this.N.A(K());
    M(3);
    Object[] arrayOfObject4 = { this.N.getBoard().toTranslatedString() };
    C("\n" + com.biotools.poker.E.A("RemoteDealer.RiverPattern", arrayOfObject4), 2);
    if (b())
      return true;
    if (!this.O)
      return false;
    W();
    if (!this.O)
      return false;
    L();
    return true;
  }

  protected void m()
  {
    int i = 0;
    if (i != 0)
    {
      System.err.println("============ POSTING BEGIN ============");
      for (j = 0; j < 10; j++)
      {
        F localF1 = this.N.G(j);
        if (localF1 != null)
          System.err.println(b.C(localF1.getName(), 10) + ": " + b.D(localF1.R() ? "true" : "", 4) + ", " + b.D(localF1.Q() ? "true" : "", 4) + ", " + b.D(localF1.G() ? "true" : "", 4));
      }
    }
    int j = this.N.getBigBlindSeat();
    double d1 = 0.0D;
    double d2 = 0.0D;
    int k;
    F localF2;
    if ((this.H) && (this.J))
      for (k = 0; k < 10; k++)
      {
        j = this.N.nextSeat(j);
        localF2 = this.N.G(j);
        if ((localF2 != null) && (localF2.inGame()) && (A(this.N.getBigBlindSeat(), this.N.getButtonSeat(), j)))
        {
          d1 = 0.0D;
          d2 = 0.0D;
          if (localF2.R())
          {
            d1 = this.N.getBigBlindSize();
            if (localF2.getBankRoll() < d1)
              d1 = localF2.getBankRoll();
          }
          else
          {
            if (localF2.Q())
            {
              d2 = this.N.getSmallBlindSize();
              if (localF2.getBankRoll() < d2)
                d2 = localF2.getBankRoll();
            }
            if (localF2.G())
            {
              d1 = this.N.getBigBlindSize();
              if (localF2.getBankRoll() - d2 < d1)
                d1 = localF2.getBankRoll() - d2;
            }
          }
          if ((d1 > 0.0D) || (d2 > 0.0D))
          {
            Action localAction = G(j);
            if (localAction.isPost())
            {
              localF2.E(false);
              localF2.C(false);
              localF2.A(false);
              Object[] arrayOfObject;
              if (d2 > 0.0D)
              {
                A(j, Action.postDeadBlindAction(d2));
                this.N.B(j, d2);
                arrayOfObject = new Object[] { I(j), Action.formatCash(d2) };
                C(com.biotools.poker.E.A("RemoteDealer.PostsDeadPattern", arrayOfObject), 1);
                D();
              }
              if (d1 > 0.0D)
              {
                A(j, Action.postBlindAction(d1));
                d1 = this.N.A(j, d1);
                arrayOfObject = new Object[] { I(j), Action.formatCash(d1) };
                C(com.biotools.poker.E.A("RemoteDealer.PostsPattern", arrayOfObject), 1);
                D();
              }
            }
            else
            {
              A(j, Action.sitout());
              this.N.F(j);
              D();
            }
          }
        }
      }
    if (i != 0)
    {
      System.err.println("--------------------------------------");
      for (k = 0; k < 10; k++)
      {
        localF2 = this.N.G(k);
        if (localF2 != null)
          System.err.println(b.C(localF2.getName(), 10) + ": " + b.D(localF2.R() ? "true" : "", 4) + ", " + b.D(localF2.Q() ? "true" : "", 4) + ", " + b.D(localF2.G() ? "true" : "", 4));
      }
      System.err.println("============ POSTING  END  ============");
    }
  }

  private boolean A(int paramInt1, int paramInt2, int paramInt3)
  {
    if ((paramInt3 == paramInt1) || (paramInt3 == paramInt2))
      return false;
    if ((paramInt1 < 0) || (paramInt1 > this.N.getNumSeats()) || (paramInt2 < 0) || (paramInt2 > this.N.getNumSeats()) || (paramInt3 < 0) || (paramInt3 > this.N.getNumSeats()))
    {
      if (!$assertionsDisabled)
        throw new AssertionError("bad call to isBetween(): " + paramInt1 + ", " + paramInt2 + ", " + paramInt3);
      return false;
    }
    int i = paramInt1;
    for (int j = 0; j < this.N.getNumSeats(); j++)
    {
      i = this.N.nextSeat(i);
      if (i == paramInt2)
        return false;
      if (i == paramInt3)
        return true;
    }
    return false;
  }

  public Player L(int paramInt)
  {
    return this.B[paramInt];
  }

  public boolean o()
  {
    int i = 0;
    for (int j = 0; j < this.N.getNumSeats(); j++)
      if (this.N.isActive(j))
      {
        if (!this.N.G(j).isAllIn())
        {
          i++;
          if (this.N.getAmountToCall(j) > 0.0D)
            return false;
        }
        if (i > 1)
          return false;
      }
    return true;
  }

  protected Action F()
  {
    int i = this.N.getCurrentPlayerSeat();
    Player localPlayer = L(i);
    Action localAction = null;
    try
    {
      localAction = localPlayer.getAction();
    }
    catch (Exception localException)
    {
      d.A("problem getting next action, doing fold");
      d.A(localException);
    }
    if (localAction == null)
      localAction = Action.foldAction(this.N.getAmountToCall(i));
    return localAction;
  }

  protected Action G(int paramInt)
  {
    Player localPlayer = L(paramInt);
    Action localAction = Action.sitout();
    if ((localPlayer instanceof W))
      try
      {
        localAction = ((W)localPlayer).Ċ();
      }
      catch (Exception localException)
      {
        d.A("problem getting next action, doing sit-out");
        d.A(localException);
      }
    return localAction;
  }

  private boolean b()
  {
    if (o())
      return false;
    while ((this.N.getNumToAct() > 0) && (this.O))
    {
      if (o())
      {
        p();
        return false;
      }
      if (this.N.Q().isAllIn())
      {
        a();
      }
      else
      {
        Action localAction = F();
        if (!this.O)
          return false;
        switch (localAction.getActionIndex())
        {
        case 0:
          if (O())
            return true;
          break;
        case 1:
          A();
          break;
        case 2:
          if (A(localAction.getAmount()))
            C(localAction.getAmount());
          else
            A();
          break;
        }
      }
      if (this.O)
        this.N.C();
    }
    if (o())
      p();
    return false;
  }

  private boolean A(double paramDouble)
  {
    if (!this.N.a())
      return false;
    int i = this.N.getCurrentPlayerSeat();
    double d = this.N.getAmountToCall(i);
    d = B(d);
    paramDouble = B(paramDouble);
    F localF = this.N.Q();
    if (paramDouble + d > localF.getBankRoll())
      paramDouble = localF.getBankRoll() - d;
    if ((paramDouble < this.N.getMinRaise()) && (paramDouble + d < localF.getBankRoll()))
    {
      com.biotools.poker.E.H("INVALID RAISE: " + paramDouble);
      return false;
    }
    return true;
  }

  protected boolean O()
  {
    Object[] arrayOfObject1 = { I(this.N.getCurrentPlayerSeat()) };
    C(com.biotools.poker.E.A("RemoteDealer.FoldsPattern", arrayOfObject1), 1);
    int i = this.N.getCurrentPlayerSeat();
    A(i, Action.foldAction(this.N.getAmountToCall(i)));
    boolean bool = this.N.B();
    D();
    if (bool)
    {
      this.N.C();
      this.N.V();
      this.N.D(this.N.Y());
      double d1 = 0.0D;
      if (this.U != null)
      {
        d1 = this.U.A(this.N, this.N.getTotalPotSize());
        d1 = Math.round(d1 * 100.0D) / 100.0D;
        this.N.B(d1);
      }
      double d2 = this.N.getTotalPotSize() - d1;
      this.N.Q().H(d2);
      A(this.N.getCurrentPlayerSeat(), d2, null);
      Object[] arrayOfObject2 = { I(this.N.getCurrentPlayerSeat()), Action.formatCash(d2) };
      C(com.biotools.poker.E.A("RemoteDealer.WinsAmountPattern", arrayOfObject2), 3);
      if (d1 > 0.0D)
      {
        Object[] arrayOfObject3 = { Action.formatCash(d1) };
        C(com.biotools.poker.E.A("RemoteDealer.RakedPattern", arrayOfObject3), 3);
      }
      L();
      return true;
    }
    return false;
  }

  protected void A()
  {
    double d = this.N.getAmountToCall(this.N.getCurrentPlayerSeat());
    Object[] arrayOfObject;
    if (d == 0.0D)
    {
      arrayOfObject = new Object[] { I(this.N.getCurrentPlayerSeat()) };
      C(com.biotools.poker.E.A("RemoteDealer.ChecksPattern", arrayOfObject), 1);
      A(this.N.getCurrentPlayerSeat(), Action.checkAction());
    }
    else
    {
      arrayOfObject = new Object[] { I(this.N.getCurrentPlayerSeat()), Action.formatCash(d) };
      C(com.biotools.poker.E.A("RemoteDealer.CallsPattern", arrayOfObject), 1);
      A(this.N.getCurrentPlayerSeat(), Action.callAction(d));
    }
    this.N.S();
    D();
  }

  protected void C(double paramDouble)
  {
    double d1 = this.N.Q().getBankRoll();
    double d2 = this.N.getAmountToCall(this.N.getCurrentPlayerSeat());
    d2 = B(d2);
    d1 = B(d1);
    paramDouble = B(paramDouble);
    if (B(paramDouble + d2) < d1)
    {
      d3 = this.N.getSmallBlindSize();
      double d4 = this.N.getBigBlindSize();
      if ((B(paramDouble % d3) != 0.0D) && (B(paramDouble % d4) != 0.0D))
        paramDouble = N.A(paramDouble, d3);
    }
    double d3 = this.N.C(paramDouble);
    Object[] arrayOfObject;
    if (this.N.getNumRaises() == 0)
    {
      arrayOfObject = new Object[] { I(this.N.getCurrentPlayerSeat()), Action.formatCash(d3) };
      C(com.biotools.poker.E.A("RemoteDealer.BetsPattern", arrayOfObject), 1);
      A(this.N.getCurrentPlayerSeat(), Action.betAction(d3));
    }
    else
    {
      arrayOfObject = new Object[] { I(this.N.getCurrentPlayerSeat()), Action.formatCash(d3) };
      C(com.biotools.poker.E.A("RemoteDealer.RaisesPattern", arrayOfObject), 1);
      A(this.N.getCurrentPlayerSeat(), Action.raiseAction(d2, d3));
    }
    this.N.E(paramDouble);
    D();
  }

  protected void a()
  {
    A(this.N.getCurrentPlayerSeat(), Action.allInPassAction());
    this.N.L();
    D();
  }

  protected void B(PlayerInfo paramPlayerInfo)
  {
    if (paramPlayerInfo.getRevealedHand() == null)
    {
      Object[] arrayOfObject = { I(paramPlayerInfo.getSeat()) };
      C(com.biotools.poker.E.A("RemoteDealer.MucksPattern", arrayOfObject), 1);
      A(paramPlayerInfo.getSeat(), Action.muckAction());
      this.N.K(paramPlayerInfo.getSeat());
      D();
    }
  }

  public int A(String paramString)
  {
    return this.N.getPlayerSeat(paramString);
  }

  protected void L()
  {
    this.N.D();
    for (int i = 0; i < this.N.getNumSeats(); i++)
      if ((this.N.inGame(i)) && (this.F[i] != null))
        this.N.A(i, this.F[i].getCard(1), this.F[i].getCard(2));
    r();
  }

  protected void p()
  {
    this.N.V();
    if (this.N.getStage() == 3)
      return;
    for (int i = 0; i < this.N.getNumSeats(); i++)
      if (this.N.isActive(i))
        Q(i);
  }

  public double s()
  {
    double d1 = this.N.getRake();
    double d2 = 0.25D;
    if ((d1 != 0.0D) && (d1 % 0.25D != 0.0D))
    {
      d2 = 0.1D;
      if (d1 % 0.1D != 0.0D)
        d2 = 0.05D;
    }
    if (this.N.getSmallBlindSize() <= 0.5D)
      d2 = 0.01D;
    else if (this.N.getSmallBlindSize() <= 2.0D)
      d2 = 0.05D;
    else if (this.N.getSmallBlindSize() <= 25.0D)
      d2 = 0.25D;
    else if (d1 == 0.0D)
      d2 = 1.0D;
    return d2;
  }

  protected void W()
  {
    int i = -1;
    double d1 = 0.0D;
    double[] arrayOfDouble = (double[])null;
    if (this.U != null)
    {
      arrayOfDouble = this.U.A(this.N);
      this.N.B(this.U.A(this.N, this.N.getTotalPotSize()));
    }
    H[] arrayOfH = this.N.F().C();
    for (int j = arrayOfH.length - 1; j >= 0; j--)
      if (arrayOfH[j].H() > 0.0D)
      {
        double d2 = 0.0D;
        if (arrayOfDouble != null)
        {
          d2 = B(arrayOfDouble[j]);
          d1 = B(d1 + d2);
        }
        i = A(arrayOfH[j], d2, i);
      }
    this.N.B(d1);
    if (d1 > 0.0D)
    {
      Object[] arrayOfObject = { Action.formatCash(d1) };
      C(com.biotools.poker.E.A("RemoteDealer.RakedPattern", arrayOfObject), 3);
    }
  }

  private int A(H paramH, double paramDouble, int paramInt)
  {
    double d1 = B(paramH.H() - paramDouble);
    double d2 = paramH.E();
    if (d2 == -1.0D)
      d2 = this.N.E().getAmountInPot();
    List localList = this.N.getPlayersInPot(d2);
    if (localList.size() == 1)
    {
      F localF1 = (F)localList.get(0);
      this.N.D(localF1.getName());
      localF1.H(d1);
      A(localF1.getSeat(), d1, null);
      Object[] arrayOfObject1 = { Action.formatCash(d1), I(localF1.getSeat()) };
      C(com.biotools.poker.E.A("RemoteDealer.ReturnedToPattern", arrayOfObject1), 1);
      return paramInt;
    }
    if (localList.size() == 0)
    {
      d.A("No players in pot! THRESH=" + d2);
      assert (localList.size() != 0);
      return paramInt;
    }
    int i = 0;
    int j = -1;
    int k = -1;
    for (int m = 0; m < localList.size(); m++)
    {
      localObject = (PlayerInfo)localList.get(m);
      n = ((PlayerInfo)localObject).getSeat();
      int i1 = this.M[n] >= 0 ? 1 : 0;
      if ((i1 == 0) && (this.F[n].getCard(1).valid()) && (this.F[n].getCard(2).valid()))
        this.M[n] = this.E.B(this.F[n].getCard(1), this.F[n].getCard(2), this.N.getBoard());
      if (this.M[n] > paramInt)
      {
        k = paramInt;
        paramInt = this.M[n];
        i = 1;
        j = ((PlayerInfo)localObject).getSeat();
      }
      else if (this.M[n] == paramInt)
      {
        i++;
        j = ((PlayerInfo)localObject).getSeat();
      }
      else if (this.M[n] > k)
      {
        k = this.M[n];
      }
      if (j == -1)
      {
        j = ((PlayerInfo)localObject).getSeat();
        paramInt = this.M[n];
      }
      if (i1 == 0)
        if ((!_()) || (this.M[n] == paramInt))
          Q(n);
        else
          B((PlayerInfo)localObject);
    }
    Hand localHand = new Hand(this.F[j]);
    localHand.addHand(this.N.getBoard());
    Object localObject = com.biotools.poker.K.D.B(localHand);
    int n = com.biotools.poker.K.D.E(this.M[j], k);
    if (n > 0)
      localObject = com.biotools.poker.K.D.C(this.M[j], n);
    double d3 = s();
    double d4 = 0.0D;
    int i2 = (int)(d1 * (1.0D / d3));
    int i3 = i2 - i * (i2 / i);
    double d5 = d1 - i2 * d3;
    for (int i4 = 0; i4 < localList.size(); i4++)
    {
      F localF2 = (F)localList.get(i4);
      int i5 = localF2.getSeat();
      if (this.M[i5] == paramInt)
      {
        int i6 = i3-- > 0 ? 1 : 0;
        double d6 = d3 * (i6 + i2 / i);
        if (d5 > 0.0D)
        {
          d6 += d5;
          d5 = 0.0D;
        }
        d6 = Math.round(d6 * 100.0D) / 100.0D;
        this.N.D(localF2.getName());
        localF2.H(d6);
        A(localF2.getSeat(), d6, (String)localObject);
        Object[] arrayOfObject2 = { I(localF2.getSeat()), Action.formatCash(d6), localObject };
        C(com.biotools.poker.E.A("RemoteDealer.WinsPattern", arrayOfObject2), 3);
        d4 += d6;
      }
    }
    assert (Math.abs(d4 - d1) < 0.001D) : ("SERIOUSLY BAD MATH:" + d4 + " != " + d1);
    return paramInt;
  }

  public void Q(int paramInt)
  {
    F localF = this.N.G(paramInt);
    if (localF.getRevealedHand() == null)
    {
      Card localCard1 = this.F[paramInt].getCard(1);
      Card localCard2 = this.F[paramInt].getCard(2);
      if ((localCard1.valid()) && (localCard2.valid()))
      {
        this.N.A(localF.getSeat(), localCard1, localCard2);
        Object[] arrayOfObject = { I(localF.getSeat()), this.F[paramInt].toTranslatedString() };
        C(com.biotools.poker.E.A("RemoteDealer.ShowsPattern", arrayOfObject), 1);
        A(localF.getSeat(), localCard1, localCard2);
      }
    }
  }

  protected void A(int paramInt, double paramDouble, String paramString)
  {
    try
    {
      Iterator localIterator = this.T.iterator();
      while (localIterator.hasNext())
      {
        GameObserver localGameObserver = (GameObserver)localIterator.next();
        try
        {
          localGameObserver.winEvent(paramInt, paramDouble, paramString);
        }
        catch (Exception localException2)
        {
          localException2.printStackTrace();
        }
      }
    }
    catch (ConcurrentModificationException localConcurrentModificationException)
    {
      localConcurrentModificationException.printStackTrace();
    }
    for (int i = 0; i < 10; i++)
      if (H(i))
        try
        {
          this.B[i].winEvent(paramInt, paramDouble, paramString);
        }
        catch (Exception localException1)
        {
          localException1.printStackTrace();
        }
  }

  protected void S()
  {
    if (!this.O)
      return;
    try
    {
      Iterator localIterator = this.T.iterator();
      while (localIterator.hasNext())
      {
        if (!this.O)
          return;
        GameObserver localGameObserver = (GameObserver)localIterator.next();
        try
        {
          localGameObserver.gameStartEvent(this.N);
        }
        catch (Exception localException2)
        {
          localException2.printStackTrace();
        }
      }
    }
    catch (ConcurrentModificationException localConcurrentModificationException)
    {
      localConcurrentModificationException.printStackTrace();
    }
    for (int i = 0; i < 10; i++)
    {
      if (!this.O)
        return;
      if (H(i))
        try
        {
          this.B[i].gameStartEvent(this.N);
        }
        catch (Exception localException1)
        {
          localException1.printStackTrace();
        }
    }
  }

  protected void M(int paramInt)
  {
    if (!this.O)
      return;
    if ((paramInt > 0) && (this.U != null))
      this.N.B(this.U.A(this.N, this.N.getTotalPotSize()));
    try
    {
      Iterator localIterator = this.T.iterator();
      while (localIterator.hasNext())
      {
        GameObserver localGameObserver = (GameObserver)localIterator.next();
        try
        {
          localGameObserver.stageEvent(paramInt);
        }
        catch (Exception localException2)
        {
          localException2.printStackTrace();
        }
      }
    }
    catch (ConcurrentModificationException localConcurrentModificationException)
    {
      localConcurrentModificationException.printStackTrace();
    }
    for (int i = 0; i < 10; i++)
      if (H(i))
        try
        {
          this.B[i].stageEvent(paramInt);
        }
        catch (Exception localException1)
        {
          localException1.printStackTrace();
        }
  }

  protected void A(int paramInt, Action paramAction)
  {
    try
    {
      Iterator localIterator = this.T.iterator();
      while (localIterator.hasNext())
      {
        GameObserver localGameObserver = (GameObserver)localIterator.next();
        try
        {
          localGameObserver.actionEvent(paramInt, paramAction);
        }
        catch (Exception localException2)
        {
          localException2.printStackTrace();
        }
      }
    }
    catch (ConcurrentModificationException localConcurrentModificationException)
    {
      localConcurrentModificationException.printStackTrace();
    }
    for (int i = 0; i < 10; i++)
      try
      {
        if (H(i))
          this.B[i].actionEvent(paramInt, paramAction);
      }
      catch (Exception localException1)
      {
        System.err.println(" * seat " + i);
        localException1.printStackTrace();
      }
  }

  protected void A(int paramInt, Card paramCard1, Card paramCard2)
  {
    try
    {
      Iterator localIterator = this.T.iterator();
      while (localIterator.hasNext())
      {
        GameObserver localGameObserver = (GameObserver)localIterator.next();
        try
        {
          localGameObserver.showdownEvent(paramInt, paramCard1, paramCard2);
        }
        catch (Exception localException2)
        {
          localException2.printStackTrace();
        }
      }
    }
    catch (ConcurrentModificationException localConcurrentModificationException)
    {
      localConcurrentModificationException.printStackTrace();
    }
    for (int i = 0; i < 10; i++)
      if (H(i))
        try
        {
          this.B[i].showdownEvent(paramInt, paramCard1, paramCard2);
        }
        catch (Exception localException1)
        {
          localException1.printStackTrace();
        }
  }

  protected void r()
  {
    if (!this.O)
      return;
    this.O = false;
    try
    {
      Iterator localIterator = this.T.iterator();
      while (localIterator.hasNext())
      {
        GameObserver localGameObserver = (GameObserver)localIterator.next();
        try
        {
          localGameObserver.gameOverEvent();
        }
        catch (Exception localException2)
        {
          localException2.printStackTrace();
        }
      }
    }
    catch (ConcurrentModificationException localConcurrentModificationException)
    {
      localConcurrentModificationException.printStackTrace();
    }
    for (int i = 0; i < 10; i++)
      if (H(i))
        try
        {
          this.B[i].gameOverEvent();
        }
        catch (Exception localException1)
        {
          localException1.printStackTrace();
        }
  }

  protected void D()
  {
    if (!this.O)
      return;
    try
    {
      Iterator localIterator = this.T.iterator();
      while (localIterator.hasNext())
      {
        GameObserver localGameObserver = (GameObserver)localIterator.next();
        try
        {
          localGameObserver.gameStateChanged();
        }
        catch (Exception localException2)
        {
          localException2.printStackTrace();
        }
      }
    }
    catch (ConcurrentModificationException localConcurrentModificationException)
    {
      localConcurrentModificationException.printStackTrace();
    }
    for (int i = 0; i < 10; i++)
      if (H(i))
        try
        {
          this.B[i].gameStateChanged();
        }
        catch (Exception localException1)
        {
          localException1.printStackTrace();
        }
  }

  protected void M()
  {
    if (!this.O)
      return;
    try
    {
      Iterator localIterator = this.T.iterator();
      while (localIterator.hasNext())
      {
        GameObserver localGameObserver = (GameObserver)localIterator.next();
        try
        {
          localGameObserver.dealHoleCardsEvent();
        }
        catch (Exception localException2)
        {
          localException2.printStackTrace();
        }
      }
    }
    catch (ConcurrentModificationException localConcurrentModificationException)
    {
      localConcurrentModificationException.printStackTrace();
    }
    for (int i = 0; i < 10; i++)
      if (H(i))
        try
        {
          this.B[i].dealHoleCardsEvent();
        }
        catch (Exception localException1)
        {
          localException1.printStackTrace();
        }
  }

  public Hand N(int paramInt)
  {
    return this.F[paramInt];
  }

  protected void B(String paramString, int paramInt)
  {
    if (!C().isSimulation())
      com.biotools.poker.E.A(paramString, paramInt);
    if (this.P != null)
      synchronized (this.P)
      {
        for (int i = 0; i < this.P.size(); i++)
          ((PrintStream)this.P.get(i)).print(paramString);
      }
  }

  public void A(PrintStream paramPrintStream)
  {
    if (this.P == null)
      this.P = new Vector();
    synchronized (this.P)
    {
      this.P.add(paramPrintStream);
    }
  }

  public void B(PrintStream paramPrintStream)
  {
    if (this.P != null)
      synchronized (this.P)
      {
        this.P.remove(paramPrintStream);
      }
  }

  protected void A(String paramString1, int paramInt1, String paramString2, int paramInt2)
  {
    if (!C().isSimulation())
      com.biotools.poker.E.A(paramString1, paramInt1, paramString2, paramInt2);
  }

  protected void C(String paramString, int paramInt)
  {
    B(paramString + "\n", paramInt);
  }

  public static String A(String paramString, int paramInt)
  {
    if (paramString.length() < paramInt)
      return A(paramString + " ", paramInt);
    return paramString;
  }

  public int e()
  {
    return this.N.nextActivePlayer(this.N.getCurrentPlayerSeat());
  }

  public int d()
  {
    return this.N.getCurrentPlayerSeat();
  }

  public boolean _()
  {
    return com.biotools.poker.E._();
  }

  public int H()
  {
    return this.N.M();
  }

  public void E()
  {
    this.O = false;
  }

  public void Q()
  {
    this.K = false;
    this.O = false;
    synchronized (this)
    {
      this.N.D();
      for (int i = 0; i < this.N.getNumSeats(); i++)
        if (this.N.inGame(i))
          this.N.G(i).C();
    }
  }

  public boolean T()
  {
    return E.A();
  }

  public F E(int paramInt)
  {
    F localF = this.N.G(paramInt);
    if ((localF == null) && (this.B[paramInt] != null))
      d.A("seat unexpectedly empty");
    return localF;
  }

  public int h()
  {
    return this.T.size();
  }

  private int A(int paramInt1, int paramInt2)
  {
    int i = paramInt1 - paramInt2;
    if (i < 0)
      i += 10;
    return i;
  }

  public void O(int paramInt)
  {
    Hand[] arrayOfHand = new Hand[10];
    int[] arrayOfInt = new int[10];
    Player[] arrayOfPlayer = new Player[10];
    for (int i = 0; i < 10; i++)
    {
      arrayOfHand[i] = this.F[i];
      arrayOfInt[i] = this.M[i];
      arrayOfPlayer[i] = this.B[i];
    }
    for (i = 0; i < 10; i++)
    {
      this.F[A(i, paramInt)] = arrayOfHand[i];
      this.M[A(i, paramInt)] = arrayOfInt[i];
      this.B[A(i, paramInt)] = arrayOfPlayer[i];
    }
    this.N.I(paramInt);
  }

  public void B(int paramInt1, int paramInt2)
  {
    Hand localHand = this.F[paramInt1];
    int i = this.M[paramInt1];
    Player localPlayer = this.B[paramInt1];
    this.F[paramInt1] = this.F[paramInt2];
    this.M[paramInt1] = this.M[paramInt2];
    this.B[paramInt1] = this.B[paramInt2];
    this.F[paramInt2] = localHand;
    this.M[paramInt2] = i;
    this.B[paramInt2] = localPlayer;
    this.N.B(paramInt1, paramInt2);
  }

  public void A(A paramA)
  {
    if (!com.biotools.poker.E.Ú())
      this.U = paramA;
  }

  public A P()
  {
    return this.U;
  }

  public void g()
  {
    G.B(C());
    this.T.clear();
  }

  public void finalize()
  {
    g();
  }

  public String I(int paramInt)
  {
    if ((com.biotools.poker.E.h()) && (this.N.G(paramInt) != null) && (paramInt != 0))
    {
      Object[] arrayOfObject = { new Integer(paramInt + 1) };
      return com.biotools.poker.E.A("Dealer.SeatPattern", arrayOfObject);
    }
    return this.N.getPlayerName(paramInt);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.Q.K
 * JD-Core Version:    0.6.2
 */