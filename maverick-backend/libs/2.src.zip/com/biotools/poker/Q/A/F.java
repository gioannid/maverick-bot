package com.biotools.poker.Q.A;

import com.biotools.poker.E;
import com.biotools.poker.Q.D;

public class F extends A
{
  public String A(int paramInt, boolean paramBoolean, double paramDouble)
  {
    String str = new String();
    Object[] arrayOfObject = new Object[4];
    if (paramBoolean)
    {
      if (paramDouble <= 0.25D)
      {
        if ((paramInt >= 2) && (paramInt <= 3))
        {
          arrayOfObject[0] = "0.05";
          arrayOfObject[1] = "1.00";
          arrayOfObject[2] = "1.00";
        }
        else if ((paramInt >= 4) && (paramInt <= 5))
        {
          arrayOfObject[0] = "0.05";
          arrayOfObject[1] = "1.00";
          arrayOfObject[2] = "2.00";
        }
        else if (paramInt >= 6)
        {
          arrayOfObject[0] = "0.05";
          arrayOfObject[1] = "1.00";
          arrayOfObject[2] = "3.00";
        }
      }
      else if (paramDouble > 0.25D)
        if ((paramInt >= 2) && (paramInt <= 3))
        {
          arrayOfObject[0] = "0.25";
          arrayOfObject[1] = "5.00";
          arrayOfObject[2] = "1.00";
        }
        else if ((paramInt >= 4) && (paramInt <= 5))
        {
          arrayOfObject[0] = "0.25";
          arrayOfObject[1] = "5.00";
          arrayOfObject[2] = "2.00";
        }
        else if (paramInt >= 6)
        {
          arrayOfObject[0] = "0.25";
          arrayOfObject[1] = "5.00";
          arrayOfObject[2] = "3.00";
        }
    }
    else if (paramDouble <= 1.0D)
    {
      arrayOfObject[0] = "0.25";
      arrayOfObject[1] = "5.00";
      arrayOfObject[2] = "1.00";
    }
    else if ((paramDouble >= 2.0D) && (paramDouble <= 10.0D))
    {
      if ((paramInt >= 2) && (paramInt <= 3))
      {
        arrayOfObject[0] = "1.00";
        arrayOfObject[1] = "20";
        arrayOfObject[2] = "1.00";
      }
      else if ((paramInt >= 4) && (paramInt <= 5))
      {
        arrayOfObject[0] = "1.00";
        arrayOfObject[1] = "20";
        arrayOfObject[2] = "2.00";
      }
      else if (paramInt >= 6)
      {
        arrayOfObject[0] = "1.00";
        arrayOfObject[1] = "20";
        arrayOfObject[2] = "3.00";
      }
    }
    else if ((paramDouble >= 15.0D) && (paramDouble <= 40.0D))
    {
      if ((paramInt >= 2) && (paramInt <= 3))
      {
        arrayOfObject[0] = "1.00";
        arrayOfObject[1] = "40";
        arrayOfObject[2] = "1.00";
      }
      else if ((paramInt >= 4) && (paramInt <= 5))
      {
        arrayOfObject[0] = "1.00";
        arrayOfObject[1] = "40";
        arrayOfObject[2] = "2.00";
        arrayOfObject[3] = "70";
      }
      else if (paramInt >= 6)
      {
        arrayOfObject[0] = "1.00";
        arrayOfObject[1] = "40";
        arrayOfObject[2] = "3.00";
        arrayOfObject[3] = "100";
      }
    }
    if (arrayOfObject[3] == null)
      str = E.A("Rake.RakeDescriptionPattern", arrayOfObject);
    else
      str = E.A("Rake.RakeDescriptionFromAFromAPattern", arrayOfObject);
    return str;
  }

  public String A()
  {
    return E.D("Rake.ParadisePokerRake.RakeTitleWussy");
  }

  public double A(D paramD, double paramDouble)
  {
    if (paramD.isPreFlop())
      return 0.0D;
    double d1 = paramD.getBigBlindSize();
    int i = paramD.getNumPlayers();
    double d2;
    if (paramD.isNoLimit())
    {
      d2 = 0.0D;
      if (d1 <= 0.25D)
      {
        if (paramDouble >= 1.0D)
          d2 = 0.05D * paramDouble;
      }
      else if ((d1 > 0.25D) && (paramDouble >= 5.0D))
        d2 = 0.25D * (int)(paramDouble / 5.0D);
      if ((i >= 2) && (i <= 3) && (d2 > 1.0D))
        d2 = 1.0D;
      if ((i >= 4) && (i <= 5) && (d2 > 2.0D))
        d2 = 2.0D;
      if ((i >= 6) && (d2 > 3.0D))
        d2 = 3.0D;
      return d2;
    }
    if (i == 2)
    {
      if (paramDouble < 20.0D)
        return 0.0D;
      if ((paramDouble >= 20.0D) && (paramDouble < 40.0D))
        return 0.25D;
      if (paramDouble >= 40.0D)
        return 0.5D;
    }
    if (((d1 == 0.1D) || (d1 == 0.25D)) && (paramDouble >= 1.0D))
    {
      d2 = 0.05D * (int)paramDouble;
      if (d2 > 1.0D)
        d2 = 1.0D;
      return d2;
    }
    if ((d1 == 0.5D) || (d1 == 1.0D))
    {
      if ((paramDouble >= 5.0D) && (paramDouble < 10.0D))
        return 0.25D;
      if ((paramDouble >= 10.0D) && (paramDouble < 15.0D))
        return 0.5D;
      if ((paramDouble >= 15.0D) && (paramDouble < 20.0D))
        return 0.75D;
      if (paramDouble >= 20.0D)
        return 1.0D;
    }
    if ((d1 >= 2.0D) && (d1 <= 10.0D))
    {
      if ((i >= 2) && (i <= 3) && (paramDouble >= 20.0D))
        return 1.0D;
      if ((i >= 4) && (i <= 5))
      {
        if ((paramDouble >= 20.0D) && (paramDouble < 40.0D))
          return 1.0D;
        if (paramDouble >= 40.0D)
          return 2.0D;
      }
      if (i >= 6)
      {
        if ((paramDouble >= 20.0D) && (paramDouble < 40.0D))
          return 1.0D;
        if ((paramDouble >= 40.0D) && (paramDouble < 60.0D))
          return 2.0D;
        if (paramDouble >= 60.0D)
          return 3.0D;
      }
    }
    if (d1 >= 15.0D)
    {
      if ((i >= 2) && (i <= 3) && (paramDouble >= 40.0D))
        return 1.0D;
      if ((i >= 4) && (i <= 5))
      {
        if ((paramDouble >= 40.0D) && (paramDouble < 70.0D))
          return 1.0D;
        if (paramDouble >= 70.0D)
          return 2.0D;
      }
      if (i >= 6)
      {
        if ((paramDouble >= 40.0D) && (paramDouble < 70.0D))
          return 1.0D;
        if ((paramDouble >= 70.0D) && (paramDouble < 100.0D))
          return 2.0D;
        if (paramDouble >= 100.0D)
          return 3.0D;
      }
    }
    return 0.0D;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.Q.A.F
 * JD-Core Version:    0.6.2
 */