package com.biotools.poker.Q.A;

import com.biotools.poker.Q.D;

public class E extends A
{
  public double A(D paramD, double paramDouble)
  {
    return 0.0D;
  }

  public String A(int paramInt, boolean paramBoolean, double paramDouble)
  {
    return "";
  }

  public String A()
  {
    return com.biotools.poker.E.D("Rake.NoRake.RakeTitle");
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.Q.A.E
 * JD-Core Version:    0.6.2
 */