package com.biotools.poker.Q.A;

import com.biotools.poker.E;
import com.biotools.poker.Q.D;

public class B extends A
{
  public String A(int paramInt, boolean paramBoolean, double paramDouble)
  {
    Object[] arrayOfObject = { "10", "4.00" };
    return E.A("Rake.RakeDescriptionPercentPattern", arrayOfObject);
  }

  public String A()
  {
    return E.D("Rake.MirageRake.RakeTitle");
  }

  public double A(D paramD, double paramDouble)
  {
    double d = paramD.getBigBlindSize();
    int i = paramD.getNumPlayers();
    if (paramD.isPreFlop())
      return 0.0D;
    int j = (int)(0.1D * paramDouble);
    if (j > 4.0D)
      j = 4;
    return j;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.Q.A.B
 * JD-Core Version:    0.6.2
 */