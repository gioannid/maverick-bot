package com.biotools.poker.Q.A;

import com.biotools.poker.E;

public class D extends A
{
  public String A(int paramInt, boolean paramBoolean, double paramDouble)
  {
    String str = new String();
    Object[] arrayOfObject = new Object[3];
    if (paramBoolean)
    {
      if (paramInt == 2)
      {
        arrayOfObject[0] = "0.05";
        arrayOfObject[1] = "1.00";
        arrayOfObject[2] = "0.50";
      }
      else if (paramInt == 3)
      {
        arrayOfObject[0] = "0.05";
        arrayOfObject[1] = "1.00";
        arrayOfObject[2] = "1.00";
      }
      else if ((paramInt >= 4) && (paramInt <= 5))
      {
        arrayOfObject[0] = "0.05";
        arrayOfObject[1] = "1.00";
        arrayOfObject[2] = "2.00";
      }
      else if ((paramInt >= 6) && (paramInt <= 10))
      {
        arrayOfObject[0] = "0.05";
        arrayOfObject[1] = "1.00";
        arrayOfObject[2] = "3.00";
      }
    }
    else if (paramDouble <= 1.0D)
    {
      if (paramInt == 2)
      {
        arrayOfObject[0] = "0.25";
        arrayOfObject[1] = "5.00";
        arrayOfObject[2] = "0.50";
      }
      else if ((paramInt >= 3) && (paramInt <= 10))
      {
        arrayOfObject[0] = "0.25";
        arrayOfObject[1] = "5.00";
        arrayOfObject[2] = "1.00";
      }
    }
    else if (paramDouble >= 2.0D)
    {
      if (paramInt == 2)
      {
        arrayOfObject[0] = "0.05";
        arrayOfObject[1] = "10";
        arrayOfObject[2] = "0.50";
      }
      if (paramInt == 3)
      {
        arrayOfObject[0] = "0.50";
        arrayOfObject[1] = "10";
        arrayOfObject[2] = "1.00";
      }
      if ((paramInt >= 4) && (paramInt <= 5))
      {
        arrayOfObject[0] = "1.00";
        arrayOfObject[1] = "20";
        arrayOfObject[2] = "2.00";
      }
      else if ((paramInt >= 6) && (paramInt <= 10))
      {
        arrayOfObject[0] = "1.00";
        arrayOfObject[1] = "20";
        arrayOfObject[2] = "3.00";
      }
    }
    str = E.A("Rake.RakeDescriptionPattern", arrayOfObject);
    return str;
  }

  public String A()
  {
    return E.D("Rake.FullTiltRake.RakeTitleWussy");
  }

  public double A(com.biotools.poker.Q.D paramD, double paramDouble)
  {
    double d1 = paramD.getBigBlindSize();
    int i = paramD.getNumPlayers();
    double d2;
    if (paramD.isNoLimit())
    {
      d2 = 0.05D * (int)paramDouble;
      if ((i == 2) && (d2 > 0.5D))
        d2 = 0.5D;
      if ((i == 3) && (d2 > 1.0D))
        d2 = 1.0D;
      if ((i >= 4) && (i <= 5) && (d2 > 2.0D))
        d2 = 2.0D;
      if ((i >= 6) && (i <= 10) && (d2 > 3.0D))
        d2 = 3.0D;
      return d2;
    }
    if (d1 <= 1.0D)
    {
      d2 = 0.25D * (int)(paramDouble / 5.0D);
      if (i == 2)
      {
        if (d2 > 0.5D)
          d2 = 0.5D;
      }
      else if (d2 > 1.0D)
        d2 = 1.0D;
      return d2;
    }
    if (d1 >= 2.0D)
    {
      d2 = 0.0D;
      if (i == 2)
      {
        d2 = 0.5D * (int)(paramDouble / 10.0D);
        if (d2 > 0.5D)
          d2 = 0.5D;
      }
      else if (i == 3)
      {
        d2 = 0.5D * (int)(paramDouble / 10.0D);
        if (d2 > 1.0D)
          d2 = 1.0D;
      }
      else if ((i >= 4) && (i <= 5))
      {
        d2 = 1.0D * (int)(paramDouble / 20.0D);
        if (d2 > 2.0D)
          d2 = 2.0D;
      }
      else if (i >= 6)
      {
        d2 = 1.0D * (int)(paramDouble / 20.0D);
        if (d2 > 3.0D)
          d2 = 3.0D;
      }
      return d2;
    }
    return 0.0D;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.Q.A.D
 * JD-Core Version:    0.6.2
 */