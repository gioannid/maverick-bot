package com.biotools.poker.Q.A;

import com.biotools.poker.E;
import com.biotools.poker.Q.D;

public class J extends A
{
  double G = 0.0D;
  double F = 0.0D;

  public J(double paramDouble1, double paramDouble2)
  {
    this.G = paramDouble1;
    this.F = paramDouble2;
  }

  public J(double paramDouble)
  {
    this(paramDouble, 0.0D);
  }

  public J()
  {
    this(0.0D, 0.0D);
  }

  public void B(double paramDouble)
  {
    this.G = paramDouble;
  }

  public double A(D paramD, double paramDouble)
  {
    if (paramDouble < this.F)
      return 0.0D;
    return this.G;
  }

  public String A(int paramInt, boolean paramBoolean, double paramDouble)
  {
    return E.D("Rake.FixedRake.RakeDescription");
  }

  public String A()
  {
    return E.D("Rake.FixedRake.RakeTitle");
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.Q.A.J
 * JD-Core Version:    0.6.2
 */