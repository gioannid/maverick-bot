package com.biotools.poker.Q.A;

import com.biotools.poker.Q.D;
import com.biotools.poker.Q.H;

public abstract class A
{
  protected static final boolean A = true;

  public abstract double A(D paramD, double paramDouble);

  public double[] A(D paramD)
  {
    int i = paramD.F().D();
    double[] arrayOfDouble = new double[i];
    double d1 = A(paramD, A(paramD.getTotalPotSize()));
    d1 = A(d1);
    double d2 = 0.0D;
    double d3 = 0.0D;
    H localH = paramD.F();
    for (int j = 0; j < i; j++)
    {
      d3 = A(d3 + localH.H());
      arrayOfDouble[j] = A(A(paramD, d3) - d2);
      d2 = A(d2 + arrayOfDouble[j]);
      assert (d2 <= d1) : (d2 + " != " + d1);
      if (arrayOfDouble[j] > localH.H())
      {
        d2 = A(d2 - arrayOfDouble[j]);
        arrayOfDouble[j] = 0.0D;
      }
      if (localH.B())
        localH = localH.F();
    }
    return arrayOfDouble;
  }

  private double A(double paramDouble)
  {
    return Math.round(paramDouble * 100.0D) / 100.0D;
  }

  public double B(D paramD)
  {
    return 0.0D;
  }

  public abstract String A(int paramInt, boolean paramBoolean, double paramDouble);

  public abstract String A();

  public String toString()
  {
    return A();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.Q.A.A
 * JD-Core Version:    0.6.2
 */