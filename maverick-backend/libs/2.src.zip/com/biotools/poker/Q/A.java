package com.biotools.poker.Q;

public abstract interface A
{
  public abstract void A(String paramString1, int paramInt1, String paramString2, int paramInt2);

  public abstract void B(String paramString, int paramInt);
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.Q.A
 * JD-Core Version:    0.6.2
 */