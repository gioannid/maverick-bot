package com.biotools.poker.Q;

import com.biotools.A.I;
import com.biotools.A.d;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.Player;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.F.H;
import com.biotools.poker.F.S;
import com.biotools.poker.G.G;
import com.biotools.poker.G.R;
import com.biotools.poker.G.T;
import com.biotools.poker.N.N;
import com.biotools.poker.P.W;
import com.biotools.poker.PokerApp;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import javax.swing.Timer;

public class J extends K
  implements com.biotools.poker.S.A.B
{
  private Player Í;
  private com.biotools.poker.S.E.K Ü;
  private int Ð = -1;
  private int Ø = 0;
  private String ã;
  private boolean Ç = false;
  private boolean Ô = false;
  private boolean â = true;
  private volatile boolean Ó = false;
  private List Þ;
  private boolean Õ;
  private Timer Ý;
  private long ß;
  private long Ù;
  private static final int Ë = 0;
  private static final int Ò = 1;
  private static final int Æ = 2;
  private static final int Ï = 3;
  private static final int Û = 5000;
  private volatile int È = 0;
  private R Ì = null;
  private R É = null;
  private com.biotools.poker.P.L Ê;
  private W á;
  private boolean Å = false;
  private com.biotools.poker.S.B.E à;
  private volatile boolean Ö = false;
  private volatile boolean Ú = false;
  private Vector Î = new Vector();
  private Vector Ñ = new Vector();

  public J(com.biotools.poker.S.E.K paramK, Player paramPlayer, String paramString)
  {
    this.Í = paramPlayer;
    this.Ð = -1;
    this.ã = paramString;
    this.Ü = paramK;
  }

  public com.biotools.poker.S.E.K ê()
  {
    return this.Ü;
  }

  public synchronized boolean V()
  {
    return false;
  }

  public void A(double paramDouble1, double paramDouble2, double paramDouble3, long paramLong, int paramInt, boolean paramBoolean, List paramList)
  {
    if (R())
    {
      com.biotools.poker.O.M.B(true);
      com.biotools.poker.O.M.A(false);
      PokerApp.Ȅ().ʋ().Ǩ().A();
      Q();
      com.biotools.poker.O.M.A(true);
      com.biotools.poker.O.M.B(false);
    }
    try
    {
      C().C(false);
      int i = -1;
      com.biotools.poker.S.F.B localB;
      for (int j = 0; j < paramList.size(); j++)
      {
        localB = (com.biotools.poker.S.F.B)paramList.get(j);
        if (localB.E().equals(this.ã))
        {
          i = localB.B();
          break;
        }
      }
      if (i != X(this.Ð))
        d.E("RemoteDealer seat doesn't match! (seatInList: " + i + ", seat: " + this.Ð + " rotate: " + this.Ø);
      if (i != -1)
      {
        this.Ø = i;
        this.Ð = Z(i);
        PokerApp.Ȅ();
        PokerApp.χ = this.Ð;
        this.Ó = true;
      }
      else
      {
        this.Ð = -1;
      }
      paramInt = Z(paramInt);
      this.O = true;
      this.N.B(!paramBoolean);
      if (this.â)
        this.â = false;
      j();
      for (j = 0; j < paramList.size(); j++)
      {
        localB = (com.biotools.poker.S.F.B)paramList.get(j);
        int k = Z(localB.B());
        N localN = k == this.Ð ? this.Í : new N();
        A(k, localB.E(), localN);
        F localF = this.N.G(k);
        if (localB.F() == 7)
        {
          localF.F(false);
          localF.J(localB.D());
          B(localB.B(), false);
        }
        else if (localB.F() == 3)
        {
          localF.F(false);
          localF.J(localB.D());
          B(localB.B(), true);
        }
        else if (localB.F() == 6)
        {
          localF.J(localB.D());
          localF.F(true);
          B(localB.B(), true);
        }
        else
        {
          localF.J(localB.D());
          localF.F(true);
          B(localB.B(), false);
        }
        this.F[k] = null;
        this.M[k] = -1;
      }
      this.N.L(paramInt);
      this.N.A(-1);
      this.N.B(-1);
      this.N.A(paramDouble3, paramDouble2, paramDouble1);
      this.N.A(paramLong);
      this.Õ = false;
      S();
      M(0);
      f();
    }
    catch (Exception localException)
    {
      I.A(localException);
    }
  }

  public void D(double paramDouble)
  {
    this.N.D(paramDouble);
    I();
  }

  public void Ë()
  {
    try
    {
      L();
      if (C().getRake() > 0.0D)
      {
        Object[] arrayOfObject = { Action.formatCash(C().getRake()) };
        C(com.biotools.poker.E.A("RemoteDealer.RakedPattern", arrayOfObject), 3);
      }
    }
    catch (Exception localException)
    {
      I.A(localException);
    }
  }

  public void ð()
  {
    K(this.à.E().A(C().b()));
  }

  public void A(int paramInt, long paramLong)
  {
    if (paramInt == 0)
      K(this.à.E().A(paramLong));
    else
      K(this.à.E().A(paramInt, paramLong));
  }

  public void B(int paramInt, Action paramAction)
  {
    try
    {
      paramInt = Z(paramInt);
      if (this.N.E(paramInt))
      {
        if (!$assertionsDisabled)
          throw new AssertionError("Got Action for Empty Seat! " + paramInt + " " + paramAction);
        return;
      }
      if (!this.N.isActive(paramInt))
      {
        if (!$assertionsDisabled)
          throw new AssertionError("Got action for folded player! " + paramInt + " " + paramAction);
        return;
      }
      if (!paramAction.isPost())
      {
        PokerApp.Ȅ().ʋ().ʴ[paramInt].A(System.currentTimeMillis());
        this.N.H(paramInt);
      }
      switch (paramAction.getType())
      {
      case 5:
        this.N.A(paramInt);
        A(paramInt, paramAction);
        this.N.H(paramInt);
        double d1 = this.N.I();
        Object[] arrayOfObject1 = { this.N.Y(), Action.formatCash(d1) };
        C(com.biotools.poker.E.A("RemoteDealer.BlindsPattern", arrayOfObject1), 1);
        D();
        break;
      case 6:
        this.N.B(paramInt);
        if (this.N.getSmallBlindSeat() == -1)
        {
          int i = paramInt - 1;
          if (i < 0)
            i += 10;
          this.N.A(i);
        }
        A(paramInt, paramAction);
        this.N.H(paramInt);
        double d2 = this.N.A();
        Object[] arrayOfObject2 = { this.N.Y(), Action.formatCash(d2) };
        C(com.biotools.poker.E.A("RemoteDealer.BlindsPattern", arrayOfObject2), 1);
        D();
        break;
      case 7:
        A(paramInt, paramAction);
        double d3 = this.N.A(paramInt, paramAction.getAmount());
        Object[] arrayOfObject3 = { this.N.Y(), Action.formatCash(d3) };
        C(com.biotools.poker.E.A("RemoteDealer.PostsPattern", arrayOfObject3), 1);
        D();
        break;
      case 12:
        A(paramInt, paramAction);
        double d4 = this.N.B(paramInt, paramAction.getAmount());
        Object[] arrayOfObject4 = { this.N.Y(), Action.formatCash(d4) };
        C(com.biotools.poker.E.A("RemoteDealer.PostsDeadPattern", arrayOfObject4), 1);
        D();
        break;
      case 11:
        A(paramInt, paramAction);
        this.N.F(paramInt);
        Object[] arrayOfObject5 = { this.N.Y() };
        C(com.biotools.poker.E.A("RemoteDealer.WaitsForBlindPattern", arrayOfObject5), 2);
        D();
        break;
      case 0:
        O();
        break;
      case 1:
      case 2:
        A();
        break;
      case 3:
      case 4:
        C(paramAction.getAmount());
        break;
      case 8:
        a();
        break;
      case 9:
        B(E(paramInt));
        break;
      case 10:
      }
      if ((!paramAction.isPost()) && (!paramAction.isSitout()))
        this.N.C();
    }
    catch (Exception localException)
    {
      I.A(localException);
    }
  }

  protected boolean O()
  {
    if (!this.O)
      return false;
    Object[] arrayOfObject = { this.N.Y() };
    C(com.biotools.poker.E.A("RemoteDealer.FoldsPattern", arrayOfObject), 1);
    A(this.N.getCurrentPlayerSeat(), Action.foldAction(this.N.getAmountToCall(this.N.getCurrentPlayerSeat())));
    boolean bool = this.N.B();
    D();
    if (bool)
    {
      this.N.C();
      this.N.V();
      return true;
    }
    return false;
  }

  public void B(int paramInt, double paramDouble, String paramString)
  {
    try
    {
      paramInt = Z(paramInt);
      if (this.N.E(paramInt))
      {
        if (!$assertionsDisabled)
          throw new AssertionError("Got Win Event for Empty Seat!");
        return;
      }
      if (paramString.equals("null"))
        paramString = null;
      F localF = this.N.G(paramInt);
      this.N.D(localF.getName());
      localF.H(paramDouble);
      Object[] arrayOfObject;
      if (paramString == null)
      {
        arrayOfObject = new Object[] { localF.getName(), Action.formatCash(paramDouble) };
        C(com.biotools.poker.E.A("RemoteDealer.WinsUncontestedPattern", arrayOfObject), 2);
      }
      else
      {
        arrayOfObject = new Object[] { localF.getName(), Action.formatCash(paramDouble), paramString };
        C(com.biotools.poker.E.A("RemoteDealer.WinsPattern", arrayOfObject), 2);
      }
      A(paramInt, paramDouble, paramString);
    }
    catch (Exception localException)
    {
      I.A(localException);
    }
  }

  public void A(double paramDouble1, double paramDouble2, double paramDouble3, int paramInt)
  {
    Thread localThread = new Thread(new J.1(this, paramDouble1, paramDouble2, paramDouble3, paramInt), "Want Action");
    localThread.start();
  }

  private void C(double paramDouble1, double paramDouble2, double paramDouble3, int paramInt)
  {
    com.biotools.poker.O.M.A(true);
    com.biotools.poker.O.M.B(false);
    if (this.N.getCurrentPlayerSeat() != this.Ð)
      this.N.H(this.Ð);
    Action localAction = null;
    if (!this.Õ)
      localAction = G(this.Ð);
    else
      localAction = this.Í.getAction();
    if (localAction == null)
    {
      com.biotools.poker.E.H("REMOTE DEALER trying to return null action - so not sending it!");
      return;
    }
    com.biotools.poker.E.H("REMOTE DEALER: sending action back...");
    K(this.à.E().A(localAction, paramInt));
    com.biotools.poker.E.H("REMOTE DEALER: sent action...");
  }

  public void ÿ()
  {
    K(this.à.E().R());
  }

  public void Ā()
  {
    K(this.à.E().S());
  }

  public void A(String paramString1, String paramString2, boolean paramBoolean)
  {
    try
    {
      boolean bool = com.biotools.poker.E.£().getBoolean("IGNORE_CHAT_" + Preferences.munkString(paramString1.toUpperCase()), false);
      if (paramString1.equals(this.ã))
        bool = false;
      if (bool)
        paramString2 = com.biotools.poker.E.D("RemoteDealer.ChatBlocked");
      Object[] arrayOfObject = { paramString1 };
      if (!paramBoolean)
        B(com.biotools.poker.E.A("RemoteDealer.ChatStringPattern", arrayOfObject), 5);
      C(paramString2, paramBoolean ? 6 : 4);
      if ((PokerApp.Ȅ() != null) && (!bool))
      {
        PokerApp.Ȅ().A(paramString1, paramString2, paramBoolean);
        com.biotools.poker.F.L.A(paramString2);
      }
    }
    catch (Exception localException)
    {
      I.A(localException);
    }
  }

  public void B(String paramString1, String paramString2)
  {
    K(this.à.E().Q(paramString2));
  }

  public void B(int paramInt, String paramString, double paramDouble)
  {
    try
    {
      if ((paramString.equals(this.ã)) && (paramDouble > 0.0D))
      {
        PokerApp.Ȅ().ʋ().M(false);
        if (!this.Ó)
          this.Ð = paramInt;
      }
      paramInt = Z(paramInt);
      com.biotools.poker.E.H("seatingChangeEvent: " + paramInt + " ==> " + this.Ð);
      F localF = this.N.A(paramString);
      if (localF != null)
        localF.J(paramDouble);
      else
        A(paramInt, paramString, paramDouble);
      PokerApp.Ȅ().ʋ().ǋ();
    }
    catch (Exception localException)
    {
      I.A(localException);
    }
  }

  private int Z(int paramInt)
  {
    int i = paramInt - this.Ø;
    if (i < 0)
      i += 10;
    return i;
  }

  private int X(int paramInt)
  {
    int i = paramInt + this.Ø;
    if (i >= 10)
      i -= 10;
    return i;
  }

  public void C(int paramInt, List paramList)
  {
    try
    {
      paramInt = Z(paramInt);
      if (this.N.E(paramInt))
      {
        if (!$assertionsDisabled)
          throw new AssertionError("Got showdown event for Empty Seat!");
        return;
      }
      assert (paramList.size() == 2);
      Card localCard1 = new Card((String)paramList.get(0));
      Card localCard2 = new Card((String)paramList.get(1));
      this.F[paramInt] = new Hand();
      this.F[paramInt].addCard(localCard1);
      this.F[paramInt].addCard(localCard2);
      this.N.V();
      this.N.A(paramInt, localCard1, localCard2);
      F localF = this.N.G(paramInt);
      if (localF.isActive())
      {
        Object[] arrayOfObject = { localF.getName(), this.F[paramInt].toTranslatedString() };
        C(com.biotools.poker.E.A("RemoteDealer.ShowsPattern", arrayOfObject), 1);
      }
      A(paramInt, localCard1, localCard2);
    }
    catch (Exception localException)
    {
      I.A(localException);
    }
  }

  public void B(int paramInt, List paramList)
  {
    try
    {
      paramInt = Z(paramInt);
      if (this.N.E(paramInt))
      {
        if (!$assertionsDisabled)
          throw new AssertionError("Got Action for Empty Seat!");
        return;
      }
      assert (paramList.size() == 2);
      Card localCard1 = new Card((String)paramList.get(0));
      Card localCard2 = new Card((String)paramList.get(1));
      if ((paramInt == 0) && ((!localCard1.valid()) || (!localCard2.valid())))
      {
        localF = this.N.G(paramInt);
        localObject = localCard1.valid() ? localCard1 : localCard2;
        Object[] arrayOfObject = { localF.getName(), localObject };
        C(com.biotools.poker.E.A("RemoteDealer.FlashesPattern", arrayOfObject), 1);
        return;
      }
      this.F[paramInt] = new Hand();
      this.F[paramInt].addCard(localCard1);
      this.F[paramInt].addCard(localCard2);
      F localF = this.N.G(paramInt);
      Object localObject = { localF.getName(), this.F[paramInt].flashingString() };
      C(com.biotools.poker.E.A("RemoteDealer.FlashesPattern", (Object[])localObject), 1);
      PokerApp.Ȅ().ʋ().B(paramInt, localCard1, localCard2);
    }
    catch (Exception localException)
    {
      I.A(localException);
    }
  }

  public void D(int paramInt, List paramList)
  {
    try
    {
      paramInt = Z(paramInt);
      assert (paramList.size() == 2);
      Card localCard1 = new Card((String)paramList.get(0));
      Card localCard2 = new Card((String)paramList.get(1));
      this.F[paramInt] = new Hand();
      this.F[paramInt].addCard(localCard1);
      this.F[paramInt].addCard(localCard2);
      this.Í.holeCards(localCard1, localCard2, paramInt);
      PokerApp.Ȅ().ʋ().Ǆ().C(false);
      PokerApp.Ȅ().ʋ().Ǆ().A(false);
    }
    catch (Exception localException)
    {
      I.A(localException);
    }
  }

  public void A(int paramInt, List paramList)
  {
    try
    {
      Object[] arrayOfObject;
      if (paramInt == 1)
      {
        this.N.A(new Card((String)paramList.get(0)), new Card((String)paramList.get(1)), new Card((String)paramList.get(2)));
        arrayOfObject = new Object[] { this.N.getBoard() };
        C("\n" + com.biotools.poker.E.A("RemoteDealer.FlopPattern", arrayOfObject), 2);
      }
      else if (paramInt == 2)
      {
        this.N.B(new Card((String)paramList.get(0)));
        arrayOfObject = new Object[] { this.N.getBoard() };
        C("\n" + com.biotools.poker.E.A("RemoteDealer.TurnPattern", arrayOfObject), 2);
      }
      else if (paramInt == 3)
      {
        this.N.A(new Card((String)paramList.get(0)));
        arrayOfObject = new Object[] { this.N.getBoard() };
        C("\n" + com.biotools.poker.E.A("RemoteDealer.RiverPattern", arrayOfObject), 2);
      }
      M(paramInt);
    }
    catch (Exception localException)
    {
      I.A(localException);
    }
  }

  public void L(String paramString)
  {
    System.out.println("CLIENT");
    this.Ö = false;
    com.biotools.poker.S.B.E.A(false);
    this.à = new com.biotools.poker.S.B.E();
    String str1 = this.à.A(this.Ü.W(), this.Ü.V());
    if (str1 != null)
    {
      d.A("oops, got error: " + str1);
      return;
    }
    this.à.K();
    ó();
    String str2 = this.à.E().F(this.ã, paramString);
    com.biotools.poker.E.H(this.ã + ": sending client login request message...");
    K(str2);
  }

  public boolean ë()
  {
    return this.Ð != -1;
  }

  public boolean ú()
  {
    return (ë()) && (this.Ó);
  }

  public void Y(int paramInt)
  {
    paramInt = X(paramInt);
    if (this.Ð == -1)
    {
      if (this.É != null)
      {
        com.biotools.poker.G.L localL = (com.biotools.poker.G.L)this.É.Q();
        if (!localL.t())
        {
          double d = PokerApp.Ȅ().ɔ().ķ().G();
          if (localL.v() > d)
          {
            Object[] arrayOfObject = { Action.formatCash(d), Action.formatCash(localL.v()) };
            PokerApp.Ȅ().ʋ().w(com.biotools.poker.E.D("RemoteDealer.NotEnoughForMinimumBuyIn") + "|" + com.biotools.poker.E.A("RemoteDealer.NotEnoughForMinimumBuyInPattern", arrayOfObject));
            return;
          }
        }
      }
      com.biotools.poker.E.H(this.ã + ": sending client seating request message...");
      K(this.à.E().A(1, paramInt));
    }
  }

  public void Ì()
  {
    I(false);
  }

  public void Ï()
  {
    if (this.Ì != null)
    {
      this.Ê = new com.biotools.poker.P.L(this);
      this.Ê.I(this.ã);
      PokerApp.Ȅ().A(this.Ê);
    }
  }

  public boolean I(boolean paramBoolean)
  {
    if (this.Ì != null)
    {
      if (!this.Ì.¢())
        return false;
      if (this.Ì.v() <= 1)
        return false;
      G localG = this.Ì.T(this.ã);
      if ((localG == null) || (this.Ì.B(localG)))
      {
        this.á = null;
        if (!ç().isShowing())
        {
          ç().H(paramBoolean);
          ç().L(this.Ì);
          PokerApp.Ȅ().A(this.á);
          return true;
        }
      }
    }
    return false;
  }

  public void ă()
  {
    K(this.à.E().G());
  }

  public void G(double paramDouble)
  {
    K(this.à.E().A(paramDouble));
  }

  private void ó()
  {
    this.Þ = new ArrayList();
    J localJ = this;
    Thread localThread = new Thread(new J.2(this, localJ), "RemoteDealer MessageLoop Thread");
    localThread.start();
  }

  private void K(String paramString)
  {
    if (!this.à.H())
      this.à.B(paramString);
    else
      com.biotools.poker.E.H("CLIENT: Can't send - dead connection!\n\t:[" + paramString + "]");
  }

  private String é()
  {
    if (!this.à.H())
    {
      String str = this.à.M();
      if (str != null)
      {
        this.Þ.add(str);
        return str;
      }
    }
    return null;
  }

  public void A(int paramInt, boolean paramBoolean1, boolean paramBoolean2)
  {
    com.biotools.poker.E.H(this.ã + ": LOGIN SUCCEEDED!");
    this.È = 1;
    this.Ç = paramBoolean1;
    this.Ô = paramBoolean2;
    PokerApp.Ȅ().ʕ();
    ã();
  }

  public boolean ý()
  {
    return this.Ç;
  }

  public boolean Ă()
  {
    return this.Ô;
  }

  public boolean ā()
  {
    if (this.Ì == null)
      return false;
    return this.Ì.U() != -1;
  }

  public boolean î()
  {
    return this.È == 1;
  }

  public void G(String paramString)
  {
    com.biotools.poker.E.H(this.ã + ": LOGIN FAILED! [" + paramString + "]");
    this.È = 2;
  }

  public void Í()
  {
    com.biotools.poker.E.H("starting sync");
    this.Å = true;
    þ();
    C().C(true);
    com.biotools.poker.O.M.B(true);
    com.biotools.poker.O.M.A(false);
    PokerApp.Ȅ().ʋ().Ǩ().A();
    if (R())
    {
      Q();
      j();
    }
    PokerApp.Ȅ().ʋ().Ǟ();
  }

  public void Æ()
  {
    this.Å = false;
    com.biotools.poker.E.H("sync done");
    com.biotools.poker.O.M.A(true);
    com.biotools.poker.O.M.B(false);
    C().C(false);
  }

  private void þ()
  {
    this.Ø = 0;
    this.Ð = -1;
    this.Ó = false;
  }

  public void ü()
  {
    this.O = false;
    å();
    þ();
    String str = this.à.E().G();
    K(str);
    com.biotools.B.L.C(100L);
    this.Ö = true;
    this.à.I();
    H(true);
    PokerApp.Ȅ().ɓ();
    PokerApp.Ȅ().ʋ().Ǟ();
    PokerApp.Ȅ().ʋ().w(com.biotools.poker.E.D("RemoteDealer.Disconnected"));
    PokerApp.Ȅ().ʜ();
    long l = System.currentTimeMillis();
    while ((this.Ú) && (System.currentTimeMillis() - l < 2000L))
      com.biotools.B.L.C(100L);
    g();
  }

  private void ä()
  {
    if (!this.Å)
    {
      com.biotools.poker.O.M.A(true);
      com.biotools.poker.O.M.B(false);
    }
  }

  public void F(String paramString)
  {
    ä();
    PokerApp.Ȅ().ʋ().w(paramString);
  }

  public void A(int paramInt, String paramString, double paramDouble)
  {
    try
    {
      if (paramInt < 0)
        return;
      paramInt = Z(paramInt);
      this.N.A(paramString, paramInt);
      if (this.N.G(paramInt) != null)
        this.N.G(paramInt).J(paramDouble);
      this.F[paramInt] = null;
      this.M[paramInt] = -1;
      this.B[paramInt] = new N();
      if (this.ã.equals(paramString))
      {
        this.Ð = paramInt;
        PokerApp.Ȅ();
        PokerApp.χ = paramInt;
        if ((ø()) && (paramDouble == 0.0D))
          û();
      }
      PokerApp.Ȅ().ʋ().ǋ();
      if ((ë()) && (this.Ð != paramInt))
        PokerApp.Ȅ().ȏ().D();
    }
    catch (Exception localException)
    {
      I.A(localException);
    }
  }

  private boolean ø()
  {
    return this.Ü.O();
  }

  public void Î()
  {
    PokerApp.Ȅ().ʋ().w(com.biotools.poker.E.D("RemoteDealer.TableHasClosed"));
    PokerApp.Ȅ().X(false);
  }

  public void E(String paramString)
  {
    M(paramString);
    PokerApp.Ȅ().ƙ();
    ô();
  }

  public void C(String paramString)
  {
    M(paramString);
    if ((this.Ì.U() != -1) && (this.Ì.E() > 0))
      PokerApp.Ȅ().Ƙ();
    ù();
    í();
  }

  private void M(String paramString)
  {
    R localR1 = this.Ì;
    boolean bool = æ();
    R localR2 = R.C(paramString);
    if (localR2 == null)
    {
      com.biotools.poker.E.H("RemoteDealer received null tournament information!");
      if (!$assertionsDisabled)
        throw new AssertionError();
      return;
    }
    if ((localR2.Q() == null) && (localR1 != null))
    {
      localR2.B(localR1.Q());
      localR2.a();
    }
    if (localR2.Q().k())
    {
      this.É = localR2;
      if (bool != æ())
        PokerApp.Ȅ().ʋ().Ǩ().E();
      return;
    }
    this.Ì = localR2;
    if ((localR1 == null) || ((localR1 != null) && (localR1.y() != this.Ì.y())))
    {
      R localR3 = com.biotools.poker.R.A.C(this.Ì.y());
      if (localR3 == null)
      {
        this.Ì.B(com.biotools.poker.E.L());
      }
      else
      {
        this.Ì.B(localR3.D());
        this.Ì.C(localR3.B());
      }
    }
    else
    {
      this.Ì.B(localR1.D());
      this.Ì.C(localR1.B());
    }
    assert (this.Ì.£() == null);
    this.Ì.E(PokerApp.Ȅ().ɬ());
    this.Ì.L();
    this.Ì.t();
    if (bool != æ())
      PokerApp.Ȅ().ʋ().Ǩ().E();
    if (this.Ê != null)
      this.Ê.Æ();
  }

  public R ö()
  {
    return this.Ì;
  }

  public void ì()
  {
    if (this.Ì == null)
      return;
    if (this.Ì.l() == null)
      this.Ì.t();
    com.biotools.poker.E.H("Saving client-side tournament information!");
    this.Ì.K();
  }

  public void H(boolean paramBoolean)
  {
    com.biotools.poker.E.H("Cleaning up client-side tournament info!");
    if (paramBoolean)
      ì();
    this.Ì = null;
  }

  public void V(int paramInt)
  {
    try
    {
      if (paramInt < 0)
        return;
      paramInt = Z(paramInt);
      this.N.M(paramInt);
      this.F[paramInt] = null;
      this.M[paramInt] = -1;
      this.B[paramInt] = null;
      if (paramInt == this.Ð)
      {
        PokerApp.Ȅ().ʋ().N(false);
        this.Ð = -1;
      }
      PokerApp.Ȅ().ʋ().ǋ();
    }
    catch (Exception localException)
    {
      I.A(localException);
    }
  }

  public boolean æ()
  {
    if (!î())
      return false;
    if (ë())
      return false;
    if (this.Ì != null)
      return false;
    if (this.É != null)
      return this.N.getNumPlayers() != this.É.Q().Á();
    return false;
  }

  public boolean õ()
  {
    if (ñ())
      return false;
    this.É.Q().o();
    return true;
  }

  public int è()
  {
    if (ñ())
      return 0;
    return this.É.Q().o();
  }

  public boolean ñ()
  {
    return !ø();
  }

  public void A(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3)
  {
    if (this.Ì != null)
      this.Ì.I(paramInt - 1);
    PokerApp.Ȅ().A(paramInt, paramDouble1, paramDouble2, paramDouble3);
    PokerApp.Ȅ().R(false);
  }

  private void ù()
  {
    synchronized (this.Î)
    {
      for (int i = this.Î.size() - 1; i >= 0; i--)
      {
        String str1 = (String)this.Î.get(i);
        PokerApp.Ȅ().r(str1);
        double d = ö().Q(str1);
        if (d <= 0.0D)
        {
          int j = ö().H(str1);
          String str2 = Integer.toString(j);
          if (com.biotools.poker.E.v())
            str2 = j + com.biotools.B.L.A(j);
          Object[] arrayOfObject = { str1, str2 };
          String str3 = com.biotools.poker.E.A("RemoteDealer.FinishedPattern", arrayOfObject);
          A("", str3, true);
        }
      }
      this.Î.clear();
    }
  }

  public void B(String paramString)
  {
    if (!this.Å)
      synchronized (this.Î)
      {
        this.Î.add(paramString);
      }
  }

  public void A(String paramString, double paramDouble)
  {
    if (!this.Å)
      synchronized (this.Ñ)
      {
        this.Ñ.add(paramString);
      }
  }

  private void í()
  {
    synchronized (this.Ñ)
    {
      for (int i = 0; i < this.Ñ.size(); i++)
      {
        String str1 = (String)this.Ñ.get(i);
        double d = ö().Q(str1);
        int j = ö().H(str1);
        String str2 = Integer.toString(j);
        if (com.biotools.poker.E.v())
          str2 = j + com.biotools.B.L.A(j);
        PokerApp.Ȅ().A(str1, d);
        Object[] arrayOfObject;
        String str3;
        if (d > 0.0D)
        {
          arrayOfObject = new Object[] { str1, Action.formatCash(d), str2 };
          str3 = com.biotools.poker.E.A("RemoteDealer.AwardPattern", arrayOfObject);
          A("", str3, true);
        }
        else if (j == 1)
        {
          arrayOfObject = new Object[] { str1, str2 };
          str3 = com.biotools.poker.E.A("RemoteDealer.FinishedPattern", arrayOfObject);
          A("", str3, true);
        }
      }
      this.Ñ.clear();
    }
  }

  public void Ê()
  {
    if (ñ())
    {
      PokerApp.Ȅ().Ɩ();
      this.Î.clear();
    }
  }

  public void Ç()
  {
    if (ñ())
    {
      this.Ê.B(true);
      this.Ê = null;
      PokerApp.Ȅ().Ɨ();
      PokerApp.Ȅ().ȏ().N();
    }
  }

  public void B(int paramInt, boolean paramBoolean)
  {
    if (paramInt == -1)
      return;
    paramInt = Z(paramInt);
    F localF = C().G(paramInt);
    if (localF != null)
      localF.B(paramBoolean);
    if (paramInt == this.Ð)
    {
      H localH = PokerApp.Ȅ().ʋ().Ǆ();
      if (!paramBoolean)
      {
        localH.E(false);
        localH.B(true);
        if ((localF != null) && (localF.isAllIn()))
          PokerApp.Ȅ().ʋ().N(true);
        else
          PokerApp.Ȅ().ʋ().N(false);
      }
      else
      {
        localH.E(true);
        localH.B(false);
        PokerApp.Ȅ().ʋ().N(true);
        PokerApp.Ȅ().ʋ().J(false);
      }
    }
  }

  public void F(boolean paramBoolean)
  {
    K(this.à.E().B(paramBoolean));
  }

  public void A(int paramInt1, int paramInt2, String paramString)
  {
    paramInt1 = Z(paramInt1);
    int i = paramInt1 == this.Ð ? 1 : 0;
    int j = (paramString != null) && (paramString.length() > 0) ? 1 : 0;
    int k = paramInt2 <= 0 ? 1 : 0;
    long l = System.currentTimeMillis() + paramInt2 * 1000;
    PokerApp.Ȅ().ʋ().ʴ[paramInt1].A(l);
    if ((k != 0) || (i == 0))
    {
      if (j != 0)
        A("", paramString, true);
      return;
    }
    if (j != 0)
    {
      A("", com.biotools.poker.E.D("RemoteDealer.YourTurnToAct"), true);
      return;
    }
    if (paramInt2 <= 10)
    {
      if (paramInt2 < 5)
        PokerApp.Ȅ().ȏ().O();
      else
        PokerApp.Ȅ().ȏ().M();
      Object[] arrayOfObject = { new Integer(paramInt2) };
      A("", com.biotools.poker.E.A("RemoteDealer.SecondsUntilTimeoutPattern", arrayOfObject), true);
    }
  }

  private void ò()
  {
    if (ñ())
      return;
    if (!ú())
      return;
    if (this.N.G(this.Ð).getBankRoll() <= 0.0D)
      PokerApp.Ȅ().ʋ().M(true);
  }

  public boolean _()
  {
    return false;
  }

  public void ï()
  {
    K(this.à.E().O());
    this.ß = com.biotools.A.F.A();
    if (this.à.H())
      å();
  }

  public void É()
  {
    this.Ù = (com.biotools.A.F.A() - this.ß);
    PokerApp.Ȅ().ɔ().A(this.Ù, PokerApp.Ȅ().ȗ(), this.à.C(), false);
  }

  private void å()
  {
    if (this.Ý != null)
      this.Ý.stop();
  }

  private void ã()
  {
    int i = 20000;
    if (com.biotools.poker.E.y())
      i = 10000;
    å();
    this.Ý = new Timer(i, new J.3(this));
    this.Ý.setCoalesce(true);
    this.Ý.setRepeats(true);
    this.Ý.setInitialDelay(0);
    this.Ý.start();
  }

  public void G(boolean paramBoolean)
  {
    K(this.à.E().C(paramBoolean));
    K(this.à.E().A(1, -1));
  }

  private void ô()
  {
    if ((this.Ì != null) && (this.á != null))
      ç().L(this.Ì);
  }

  public W ç()
  {
    if (this.á == null)
    {
      this.á = new W();
      this.á.setName(this.ã);
      this.á.A(this.à);
    }
    return this.á;
  }

  public void A(String paramString, boolean paramBoolean)
  {
    if (this.Ê != null)
      if (paramBoolean)
        this.Ê.G(paramString);
      else
        this.Ê.F(paramString);
  }

  public void A(String[] paramArrayOfString)
  {
    if (this.Ê != null)
      this.Ê.A(paramArrayOfString);
  }

  public void D(String paramString)
  {
    if (this.Ê != null)
      this.Ê.H(paramString);
  }

  public void û()
  {
    if (this.É == null)
      return;
    com.biotools.poker.G.L localL = (com.biotools.poker.G.L)this.É.Q();
    double d = 0.0D;
    PlayerInfo localPlayerInfo = C().getPlayer(this.Ð);
    if (localPlayerInfo != null)
      d = localPlayerInfo.getBankRoll();
    PokerApp.Ȅ().A(new com.biotools.poker.P.A(this.Ð, localL.Â(), d, localL.v(), localL.¥(), PokerApp.Ȅ().ɔ().ķ().G(), !localL.t(), localL.Y()));
  }

  public void È()
  {
    try
    {
      this.Õ = true;
      M();
    }
    catch (Exception localException)
    {
      I.A(localException);
    }
  }

  public void U(int paramInt)
  {
    try
    {
      paramInt = Z(paramInt);
      this.N.H(paramInt);
      PokerApp.Ȅ().o(paramInt);
    }
    catch (Exception localException)
    {
      I.A(localException);
    }
  }

  public void E(double paramDouble)
  {
    C().B(paramDouble);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.Q.J
 * JD-Core Version:    0.6.2
 */