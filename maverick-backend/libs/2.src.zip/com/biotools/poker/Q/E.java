package com.biotools.poker.Q;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.util.Preferences;

public class E
{
  public static final int B = 0;
  public static final int E = 1;
  public static final int D = 2;
  public static final int C = 0;
  public static final int F = 1;
  public static final int A = 2;

  public static boolean A()
  {
    return com.biotools.poker.E.£().getBoolean("LOG_HANDS", true);
  }

  public static boolean B()
  {
    return com.biotools.poker.E.£().getBoolean("NO_CAP_HU", false);
  }

  public static void A(boolean paramBoolean)
  {
    com.biotools.poker.E.£().putBoolean("LOG_HANDS", paramBoolean);
  }

  public static void B(boolean paramBoolean)
  {
    com.biotools.poker.E.£().putBoolean("NO_CAP_HU", paramBoolean);
  }

  public static boolean E(int paramInt)
  {
    int i = D(paramInt);
    return i == 1;
  }

  public static boolean C(int paramInt)
  {
    int i = D(paramInt);
    return (A(paramInt, 0)) || (A(paramInt, 1));
  }

  public static int D(int paramInt)
  {
    return com.biotools.poker.E.£().getInt("DEAL_METHOD_" + paramInt, 0);
  }

  public static int F(int paramInt)
  {
    return com.biotools.poker.E.£().getInt("DEAL_RANGE_" + paramInt, 25);
  }

  public static int A(int paramInt)
  {
    return com.biotools.poker.E.£().getInt("DEAL_RANGE_TYPE" + paramInt, 0);
  }

  public static boolean A(int paramInt1, int paramInt2)
  {
    int i = com.biotools.poker.E.£().getInt("DEAL_METHOD_" + paramInt1, 2);
    if (i == 1)
      return true;
    return B(paramInt1, paramInt2) != null;
  }

  public static Card B(int paramInt1, int paramInt2)
  {
    Card localCard = null;
    int i = com.biotools.poker.E.£().getInt("FDHC" + paramInt1 + "_" + paramInt2, -1);
    if (i != -1)
      localCard = new Card(i);
    return localCard;
  }

  public static Card B(int paramInt)
  {
    Card localCard = null;
    int i = com.biotools.poker.E.£().getInt("FDBC" + paramInt, -1);
    if (i != -1)
      localCard = new Card(i);
    return localCard;
  }

  public static void A(Deck paramDeck)
  {
    Card localCard = null;
    for (int i = 0; i < 5; i++)
    {
      localCard = B(i);
      if (localCard != null)
        paramDeck.extractCard(localCard);
    }
    for (i = 0; i < 10; i++)
    {
      localCard = B(i, 0);
      if (localCard != null)
        paramDeck.extractCard(localCard);
      localCard = B(i, 1);
      if (localCard != null)
        paramDeck.extractCard(localCard);
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.Q.E
 * JD-Core Version:    0.6.2
 */