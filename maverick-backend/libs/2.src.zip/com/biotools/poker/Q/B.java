package com.biotools.poker.Q;

import com.biotools.A.d;
import com.biotools.B.L;
import com.biotools.meerkat.Action;
import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.Hand;
import com.biotools.meerkat.Player;
import com.biotools.meerkat.PlayerInfo;
import com.biotools.poker.A;
import com.biotools.poker.N.N;
import com.biotools.poker.PokerApp;
import com.biotools.poker.Q.A.J;
import com.biotools.poker.R.V;

public class B extends K
{
  private static final boolean g = true;
  private boolean h = true;
  Action X = null;
  protected boolean b = false;
  protected V _;
  protected int c = 0;
  protected com.biotools.poker.R.E i;
  protected int Y = 0;
  protected int d = 0;
  private volatile boolean f = false;
  private volatile boolean e = false;
  protected N Z = new N();
  protected Player a;

  protected B()
  {
  }

  public B(V paramV, Player paramPlayer)
  {
    this._ = paramV;
    this.a = paramPlayer;
    this.c = 0;
  }

  public int Â()
  {
    return this._.size();
  }

  public boolean v()
  {
    return this.c < this._.size();
  }

  public int u()
  {
    return this.c;
  }

  public com.biotools.poker.R.E À()
  {
    return this.i;
  }

  public void t()
  {
    this.i = this._.D(this.c++);
    ¢();
  }

  public void c()
  {
    this.N.A(this.i.h());
  }

  public void B(boolean paramBoolean)
  {
    this.b = paramBoolean;
  }

  private void ¢()
  {
    this.Y = 0;
    this.d = 0;
    this.N.B(this.i.J());
    this.I = this.i.R();
    j();
    y();
    A(S(this.i.C()), S(this.i.F()), S(this.i.i()), false);
    this.N.A(this.i.f(), this.i.M(), (this.i.J() ? 1 : 2) * this.i.M(), this.i.l());
    if (!(this instanceof C))
      A(new J(this.i.Z()));
  }

  protected void y()
  {
    for (int j = 0; j < 10; j++)
      if (!this.i.N(j))
      {
        if ((j == this.i.a()) && (this.a != null))
          A(S(j), this.i.J(j), this.a);
        else
          A(S(j), this.i.J(j), this.Z);
        E(S(j)).E(this.i.P(j));
      }
  }

  protected int S(int paramInt)
  {
    int j = this.i.a();
    if ((!this.b) || (j < 0))
      return paramInt;
    int k = paramInt - j;
    if (k < 0)
      k += 10;
    return k;
  }

  protected int T(int paramInt)
  {
    int j = this.i.a();
    if ((!this.b) || (j < 0))
      return paramInt;
    int k = paramInt + j;
    if (k >= 10)
      k -= 10;
    return k;
  }

  protected boolean Á()
  {
    return (this.h) && (PokerApp.Ȅ() != null);
  }

  public void G()
  {
    super.G();
    z();
  }

  protected void M(int paramInt)
  {
    if (paramInt != 0)
      ª();
    if (paramInt == 1)
      this.N.B(this.i.Z());
    super.M(paramInt);
    z();
  }

  protected void A(int paramInt, Action paramAction)
  {
    super.A(paramInt, paramAction);
    this.X = paramAction;
  }

  protected void D()
  {
    super.D();
    if ((this.X != null) && (this.X.isFold()))
      z();
  }

  protected void J()
  {
    this.Q = 0;
    this.W.shuffle();
    w();
    for (int j = 0; j < 10; j++)
      if (this.N.inGame(j))
      {
        this.M[j] = -1;
        this.F[j] = P(T(j));
      }
      else
      {
        this.F[j] = null;
      }
  }

  protected Hand P(int paramInt)
  {
    Hand localHand = null;
    if (this.i.G(paramInt))
    {
      localHand = this.i.O(paramInt);
      Card localCard1 = localHand.getCard(1);
      Card localCard2 = localHand.getCard(2);
      if (((localCard1 == null) || (!localCard1.valid())) && (!£()))
      {
        if (!$assertionsDisabled)
          throw new AssertionError("Shouldn't have to guess at card in replay ever!");
        localHand.setCard(1, this.W.dealCard());
      }
      if (((localCard2 == null) || (!localCard2.valid())) && (!£()))
      {
        if (!$assertionsDisabled)
          throw new AssertionError("Shouldn't have to guess at card in replay ever!");
        localHand.setCard(2, this.W.dealCard());
      }
    }
    else
    {
      if (!$assertionsDisabled)
        throw new AssertionError("Have a player sitting in the dealer but not in the game record!");
      if (!£())
      {
        localHand = new Hand();
        localHand.addCard(this.W.dealCard());
        localHand.addCard(this.W.dealCard());
      }
    }
    return localHand;
  }

  protected Card K()
  {
    Hand localHand = this.i.H();
    Card localCard = null;
    this.Q += 1;
    if ((localHand != null) && (this.Q <= localHand.size()))
      localCard = localHand.getCard(this.Q);
    if ((localCard == null) || (!localCard.valid()))
    {
      assert (!£()) : "Shouldn't ever have to deal card in watch mode!";
      localCard = this.W.dealCard();
    }
    return localCard;
  }

  private void w()
  {
    for (int j = 0; j < 10; j++)
      if (this.i.G(T(j)))
        this.W.extractHand(this.i.O(T(j)));
    this.W.extractHand(this.i.H());
  }

  protected void X()
  {
    this.K = true;
  }

  protected void B()
  {
    this.K = true;
  }

  protected Action F()
  {
    int j = this.N.getCurrentPlayerSeat();
    double d1 = this.N.getAmountToCall(j);
    Action localAction = null;
    try
    {
      localAction = A(d1, this.Y++);
      if (localAction.isVoluntary())
        ª();
    }
    catch (Exception localException)
    {
      this.O = false;
      localAction = Action.checkOrFoldAction(d1);
      d.A("problem getting next action, doing call/fold");
      d.A(localException);
    }
    return localAction;
  }

  protected void m()
  {
    this.J = false;
    this.H = false;
    String str = this.i.k();
    if ((str == null) || (str.length() <= 1))
      return;
    for (int j = 0; j < str.length() - 1; j++)
    {
      int k = str.charAt(j);
      int m;
      F localF;
      double d1;
      if (k == 80)
      {
        j++;
        m = S(Integer.parseInt(Character.toString(str.charAt(j))));
        localF = this.N.G(m);
        d1 = this.N.getBigBlindSize();
        if ((localF != null) && (localF.getBankRoll() < this.N.getBigBlindSize()))
          d1 = localF.getBankRoll();
        A(m, Action.postBlindAction(d1));
        d1 = this.N.A(m, d1);
        C(I(m) + " posts " + Action.formatCash(d1), 1);
        D();
      }
      else if (k == 68)
      {
        j++;
        m = S(Integer.parseInt(Character.toString(str.charAt(j))));
        localF = this.N.G(m);
        d1 = this.N.getSmallBlindSize();
        if ((localF != null) && (localF.getBankRoll() < this.N.getSmallBlindSize()))
          d1 = localF.getBankRoll();
        A(m, Action.postDeadBlindAction(d1));
        d1 = this.N.B(m, d1);
        C(I(m) + " posts dead " + Action.formatCash(d1), 1);
        D();
      }
    }
  }

  protected Action G(int paramInt)
  {
    if (!$assertionsDisabled)
      throw new AssertionError("Should not be called in replayer");
    return Action.postBlindAction(this.N.getBigBlindSize());
  }

  protected Action A(double paramDouble, int paramInt)
  {
    String str = this.i.k();
    int j = 0;
    int k = 0;
    for (int m = 0; m < str.length(); m++)
    {
      int n = str.charAt(m);
      if (n == 47)
      {
        k++;
      }
      else if (n == 102)
      {
        if (j == paramInt)
          return Action.foldAction(paramDouble);
        j++;
      }
      else if (n == 107)
      {
        if (j == paramInt)
          return Action.checkAction();
        j++;
      }
      else if (n == 99)
      {
        if (j == paramInt)
          return Action.callAction(paramDouble);
        j++;
      }
      else
      {
        double d1;
        if (n == 98)
        {
          if (j == paramInt)
          {
            d1 = this.i.W() * (k >= 2 ? 2 : 1);
            if (this.i.G() != null)
              d1 = this.i.R(this.d++);
            return Action.betAction(d1);
          }
          j++;
        }
        else if (n == 114)
        {
          if (j == paramInt)
          {
            d1 = this.i.W() * (k >= 2 ? 2 : 1);
            if (this.i.G() != null)
              d1 = this.i.R(this.d++);
            return Action.raiseAction(paramDouble, d1);
          }
          j++;
        }
      }
    }
    return null;
  }

  public boolean £()
  {
    return true;
  }

  public boolean T()
  {
    return false;
  }

  private void ª()
  {
    if (this.f)
    {
      while ((this.O) && (this.f) && (!this.e))
        L.C(50L);
      this.e = false;
    }
  }

  public void º()
  {
    ¤();
    this.e = true;
  }

  public void x()
  {
    this.f = false;
  }

  public void ¤()
  {
    this.f = true;
  }

  public void Ä()
  {
    this.c -= 1;
    if ((this.c > 0) && (!R()))
      this.c -= 1;
  }

  public boolean ¥()
  {
    return this.f;
  }

  private void z()
  {
    if (!Á())
      return;
    com.biotools.poker.E.H("Updating equity vals...");
    String[] arrayOfString = Ã();
    PokerApp.Ȅ().ʋ().E(arrayOfString);
    com.biotools.poker.E.H("Done updating equity vals");
  }

  private String[] Ã()
  {
    Hand[] arrayOfHand = new Hand[C().getNumActivePlayers()];
    int j = 0;
    for (int k = 0; k < 10; k++)
    {
      F localF1 = E(k);
      if ((localF1 != null) && (localF1.isActive()))
      {
        Hand localHand = N(k);
        if (localHand == null)
          localHand = new Hand();
        if (localHand.size() == 0)
        {
          localHand.addCard(new Card());
          localHand.addCard(new Card());
        }
        else if (localHand.size() == 1)
        {
          localHand.addCard(new Card());
        }
        else if (localHand.size() > 2)
        {
          if (!$assertionsDisabled)
            throw new AssertionError("Too many hole cards!");
          while (localHand.size() > 2)
            localHand.removeCard();
        }
        arrayOfHand[j] = localHand;
        j++;
      }
    }
    Object localObject1 = null;
    long l1 = com.biotools.poker.L.E.B(C().getBoard(), arrayOfHand);
    if ((l1 < 0L) || (l1 > 10000L))
    {
      localObject2 = new com.biotools.poker.L.B(C().getBoard(), arrayOfHand);
      ((com.biotools.poker.L.B)localObject2).G(10000);
      localObject1 = localObject2;
    }
    else
    {
      localObject2 = new com.biotools.poker.L.E(C().getBoard(), arrayOfHand);
      localObject1 = localObject2;
    }
    localObject1.run();
    Object localObject2 = new String[10];
    j = 0;
    for (int m = 0; m < 10; m++)
    {
      F localF2 = E(m);
      if ((localF2 != null) && (localF2.isActive()))
      {
        double d1 = localObject1.C(j);
        d1 *= 100.0D;
        long l2 = Math.round(Math.floor(d1));
        long l3 = Math.round((d1 - l2) * 10.0D);
        Object[] arrayOfObject = { new Long(l2), new Long(l3) };
        String str = com.biotools.poker.E.A("PokerTable.WinPercentStringPattern", arrayOfObject);
        if (d1 == 100.0D)
          str = com.biotools.poker.E.D("PokerTable.WinnerString");
        if (d1 == 0.0D)
          str = com.biotools.poker.E.D("PokerTable.LoserString");
        localObject2[m] = str;
        j++;
      }
    }
    return localObject2;
  }

  public boolean µ()
  {
    return this.h;
  }

  public void C(boolean paramBoolean)
  {
    this.h = paramBoolean;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.Q.B
 * JD-Core Version:    0.6.2
 */