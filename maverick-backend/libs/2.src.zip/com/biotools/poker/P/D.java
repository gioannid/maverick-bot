package com.biotools.poker.P;

import B.A.A.B;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import com.biotools.poker.O.A;
import com.biotools.poker.PokerApp;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class D extends V
{
  private static final String[] Ã = { E.D("AnimationOptions.UseRegularSoundEngine"), E.D("AnimationOptions.UseAppletSoundEngine"), E.D("AnimationOptions.UseStreamingSoundEngine") };
  private static final int[] ¤ = { 7, 4, 6 };
  JComboBox Á = new JComboBox(Ã);
  JCheckBox Å = new JCheckBox(E.D("AnimationOptions.AnimateDealing"));
  JCheckBox Â = new JCheckBox(E.D("AnimationOptions.AnimateFolding"));
  JCheckBox º = new JCheckBox(E.D("AnimationOptions.AnimateChipSliding"));
  JCheckBox À = new JCheckBox(E.D("AnimationOptions.AnimateActiveSeat"));
  JCheckBox ¥ = new JCheckBox(E.D("AnimationOptions.AnimateBoardFlip"));
  JCheckBox ¢ = new JCheckBox(E.D("AnimationOptions.AnimateBoardSwirl"));
  JCheckBox z = new JCheckBox(E.D("AnimationOptions.AnimateBoardFadeIn"));
  JCheckBox µ = new JCheckBox(E.D("AnimationOptions.PlayerChatBubbles"));
  JCheckBox £ = new JCheckBox(E.D("AnimationOptions.PlayBeepSound"));
  JCheckBox ª = new JCheckBox(E.D("AnimationOptions.PlayTableSounds"));
  JCheckBox Ä = new JCheckBox(E.D("AnimationOptions.PlayOtherSounds"));

  public JLabel F()
  {
    return new JLabel(E.D("AnimationOptions.AnimationAndSoundOptionsTitle"), 0);
  }

  public JPanel A()
  {
    b();
    JButton localJButton1 = new JButton(E.D("AnimationOptions.OKButton"));
    JButton localJButton2 = new JButton(E.D("AnimationOptions.CancelButton"));
    localJButton1.addActionListener(new D.1(this));
    localJButton2.addActionListener(new D.2(this));
    JLabel localJLabel1 = new JLabel(E.D("AnimationOptions.ToggleAnimationLabel1"));
    JLabel localJLabel2 = new JLabel(E.D("AnimationOptions.ToggleAnimationLabel2"));
    JLabel localJLabel3 = new JLabel(E.D("AnimationOptions.ToggleAnimationLabel3"));
    JPanel localJPanel1 = new JPanel(new BorderLayout(5, 1));
    localJPanel1.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
    localJPanel1.add(localJLabel1, "North");
    localJPanel1.add(localJLabel2, "Center");
    localJPanel1.add(localJLabel3, "South");
    JPanel localJPanel2 = new JPanel();
    localJPanel2.setLayout(new BoxLayout(localJPanel2, 0));
    localJPanel2.setBorder(BorderFactory.createEmptyBorder(15, 3, 3, 3));
    localJPanel2.add(Box.createHorizontalGlue());
    localJPanel2.add(localJButton1);
    localJPanel2.add(Box.createHorizontalStrut(5));
    localJPanel2.add(localJButton2);
    localJPanel2.add(Box.createHorizontalGlue());
    JPanel localJPanel3 = new JPanel();
    localJPanel3.setLayout(new GridLayout(0, 2, 5, 5));
    localJPanel3.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(E.D("AnimationOptions.AnimationOptionsTitle")), BorderFactory.createEmptyBorder(10, 10, 10, 10)));
    localJPanel3.add(this.Å);
    localJPanel3.add(this.¥);
    localJPanel3.add(this.Â);
    localJPanel3.add(this.¢);
    localJPanel3.add(this.º);
    localJPanel3.add(this.z);
    localJPanel3.add(this.À);
    localJPanel3.add(this.µ);
    JPanel localJPanel4 = new JPanel();
    localJPanel4.setLayout(new GridLayout(4, 1, 5, 5));
    localJPanel4.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(E.D("AnimationOptions.SoundOptionsTitle")), BorderFactory.createEmptyBorder(10, 40, 10, 40)));
    localJPanel4.add(this.£);
    localJPanel4.add(this.ª);
    localJPanel4.add(this.Ä);
    localJPanel4.add(a());
    JPanel localJPanel5 = new JPanel();
    localJPanel5.setLayout(new BorderLayout(5, 5));
    localJPanel5.add(localJPanel3, "North");
    localJPanel5.add(localJPanel4, "Center");
    Z localZ = new Z();
    localZ.setLayout(new BorderLayout(5, 5));
    localZ.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 10));
    localZ.add(localJPanel1, "North");
    localZ.add(localJPanel5, "Center");
    localZ.add(localJPanel2, "South");
    localZ.setMaximumSize(localZ.getMinimumSize());
    return localZ;
  }

  private JPanel a()
  {
    JPanel localJPanel = new JPanel(new B(0, 0));
    localJPanel.add("center", this.Á);
    return localJPanel;
  }

  public void c()
  {
    E.£().putBoolean("USE_DEAL_ANIMATION", this.Å.isSelected());
    E.£().putBoolean("USE_FOLD_ANIMATION", this.Â.isSelected());
    E.£().putBoolean("USE_CHIP_ANIMATION", this.º.isSelected());
    E.£().putBoolean("USE_TO_ACT_ANIMATION", this.À.isSelected());
    E.£().putBoolean("USE_BOARD_FLIP_ANIMATION", this.¥.isSelected());
    E.£().putBoolean("USE_BOARD_SWIRL_ANIMATION", this.¢.isSelected());
    E.£().putBoolean("USE_BOARD_FADE_ANIMATION", this.z.isSelected());
    E.£().putBoolean("USE_PLAYER_CHAT_ANIMATION", this.µ.isSelected());
    E.£().putBoolean("USE_SOUND_TABLE", this.ª.isSelected());
    E.£().putBoolean("USE_SOUND_BEEP", this.£.isSelected());
    E.£().putBoolean("USE_SOUND_OTHER", this.Ä.isSelected());
    E.£().putInt("SOUND_ENGINE", ¤[this.Á.getSelectedIndex()]);
    A.Q();
    I().ȏ().E();
  }

  private void b()
  {
    this.Å.setSelected(E.£().getBoolean("USE_DEAL_ANIMATION", true));
    this.Â.setSelected(E.£().getBoolean("USE_FOLD_ANIMATION", true));
    this.º.setSelected(E.£().getBoolean("USE_CHIP_ANIMATION", true));
    this.À.setSelected(E.£().getBoolean("USE_TO_ACT_ANIMATION", true));
    this.¥.setSelected(E.£().getBoolean("USE_BOARD_FLIP_ANIMATION", true));
    this.¢.setSelected(E.£().getBoolean("USE_BOARD_SWIRL_ANIMATION", true));
    this.z.setSelected(E.£().getBoolean("USE_BOARD_FADE_ANIMATION", true));
    this.µ.setSelected(E.£().getBoolean("USE_PLAYER_CHAT_ANIMATION", true));
    this.ª.setSelected(E.£().getBoolean("USE_SOUND_TABLE", true));
    this.£.setSelected(E.£().getBoolean("USE_SOUND_BEEP", true));
    this.Ä.setSelected(E.£().getBoolean("USE_SOUND_OTHER", true));
    this.Á.setSelectedIndex(B(com.biotools.poker.F.D.Q()));
  }

  private int B(int paramInt)
  {
    for (int i = 0; i < ¤.length; i++)
      if (¤[i] == paramInt)
        return i;
    return 0;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.P.D
 * JD-Core Version:    0.6.2
 */