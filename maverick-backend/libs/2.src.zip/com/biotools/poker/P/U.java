package com.biotools.poker.P;

import com.biotools.poker.A;
import com.biotools.poker.E;
import com.biotools.poker.O.M;
import com.biotools.poker.PokerApp;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;

public class U extends JPanel
{
  PokerApp D;
  public Image B = null;
  List C;
  boolean A;

  public U(PokerApp paramPokerApp)
  {
    this.D = paramPokerApp;
    setDoubleBuffered(false);
    setOpaque(false);
    setVisible(true);
    setLayout(null);
    this.C = new ArrayList();
    this.A = false;
  }

  public void A(V paramV1, V paramV2)
  {
    paramV2.B(this);
    if (paramV1 != null)
    {
      this.C.add(paramV1);
      if (!paramV2.J())
        E.H("ERROR: stacking an unstackable overlay " + paramV2);
    }
    A(paramV2, -1, -1, this.A);
    paramV2.K();
    this.A = true;
  }

  public void A(V paramV, boolean paramBoolean)
  {
    V localV1 = paramV;
    while (this.C.size() > 0)
    {
      V localV2 = (V)this.C.remove(this.C.size() - 1);
      if (localV2.C(paramBoolean))
      {
        A(localV2, -1, -1, true);
        break;
      }
    }
    this.D.ɪ();
    this.A = false;
  }

  public void A(JPanel paramJPanel, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    int i = paramInt1;
    int j = paramInt2;
    Dimension localDimension = paramJPanel.getPreferredSize();
    if (i < 0)
      i = (this.D.ʋ().Ǩ().H() - localDimension.width) / 2;
    if (j < 0)
      j = (this.D.ʋ().Ǩ().I() - localDimension.height) / 2;
    removeAll();
    if (paramBoolean)
      this.D.repaint();
    paramJPanel.setMinimumSize(localDimension);
    paramJPanel.setBounds(i, j, localDimension.width, localDimension.height);
    add(paramJPanel);
    revalidate();
  }

  public void paintComponent(Graphics paramGraphics)
  {
    Image localImage = this.D.ʋ().Ǩ().B();
    int i = localImage.getWidth(null);
    int j = localImage.getHeight(null);
    paramGraphics.drawImage(localImage, 0, 0, null);
    Graphics2D localGraphics2D = (Graphics2D)paramGraphics;
    Composite localComposite = localGraphics2D.getComposite();
    AlphaComposite localAlphaComposite;
    if (this.B != null)
    {
      localAlphaComposite = AlphaComposite.getInstance(3, 0.8F);
      localGraphics2D.setComposite(localAlphaComposite);
      localGraphics2D.setColor(Color.BLACK);
      localGraphics2D.fillRect(0, 0, i, j);
      paramGraphics.drawImage(this.B, 0, 0, null);
    }
    else
    {
      localAlphaComposite = AlphaComposite.getInstance(3, 0.3F);
      localGraphics2D.setComposite(localAlphaComposite);
      localGraphics2D.setColor(Color.BLACK);
      localGraphics2D.fillRect(0, 0, i, j);
    }
    localGraphics2D.setComposite(localComposite);
  }

  public PokerApp A()
  {
    return this.D;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.P.U
 * JD-Core Version:    0.6.2
 */