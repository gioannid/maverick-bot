package com.biotools.poker.P;

import com.biotools.poker.C.R;
import java.awt.Toolkit;
import java.util.ArrayList;
import javax.swing.ComboBoxEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;

public class J extends JComboBox
{
  private DefaultComboBoxModel D;
  private ArrayList A;
  private ArrayList F;
  private double C;
  private double G;
  private static double E = 100000000.0D;
  private static double B = 0.0D;

  public J(double paramDouble)
  {
    this(paramDouble, -1.0D);
  }

  public J(double paramDouble1, double paramDouble2)
  {
    this.C = paramDouble1;
    this.G = paramDouble2;
    A();
  }

  public void H()
  {
    requestFocus();
    requestFocusInWindow();
    getEditor().selectAll();
  }

  private DefaultComboBoxModel E()
  {
    if (this.D == null)
      this.D = new DefaultComboBoxModel(G().toArray());
    return this.D;
  }

  private void A()
  {
    setModel(E());
    setEditable(true);
    a locala = new a();
    setEditor(locala);
    if (this.G > 0.0D)
      setSelectedIndex(0);
    else
      setSelectedIndex(5);
    requestFocus();
    getEditor().selectAll();
  }

  private void I()
  {
    this.A = new ArrayList();
    this.F = new ArrayList();
    if (this.G > 0.0D)
    {
      this.F.add(new Double(this.G));
      this.A.add(Integer.toString((int)this.G));
    }
    for (int i = 0; i < R.Z.length; i++)
    {
      double d = this.C * R.Z[i];
      this.F.add(new Double(d));
      this.A.add(Integer.toString((int)d));
    }
  }

  private ArrayList G()
  {
    if (this.A == null)
      I();
    return this.A;
  }

  private ArrayList B()
  {
    if (this.F == null)
      I();
    return this.F;
  }

  public double D()
  {
    int i = getSelectedIndex();
    Object localObject = getSelectedItem();
    Double localDouble;
    if (i >= 0)
    {
      localDouble = (Double)B().get(i);
      return localDouble.doubleValue();
    }
    if (localObject.getClass() == Double.class)
    {
      localDouble = (Double)localObject;
      if (localDouble.doubleValue() < 0.0D)
        localDouble = new Double(localDouble.doubleValue() * -1.0D);
      return localDouble.doubleValue();
    }
    String str = (String)getSelectedItem();
    StringBuffer localStringBuffer = A(str);
    try
    {
      localDouble = new Double(localStringBuffer.toString());
    }
    catch (NumberFormatException localNumberFormatException)
    {
      localDouble = new Double(-1.0D);
    }
    return localDouble.doubleValue();
  }

  public double A(double paramDouble)
  {
    if (paramDouble > E)
      return E;
    if (paramDouble < B)
      return B;
    return paramDouble;
  }

  public StringBuffer A(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer(paramString);
    int i = localStringBuffer.indexOf("$");
    if (i >= 0)
      localStringBuffer.deleteCharAt(i);
    for (i = localStringBuffer.indexOf(","); i != -1; i = localStringBuffer.indexOf(","))
      localStringBuffer.deleteCharAt(i);
    return localStringBuffer;
  }

  public void F()
  {
    E().setSelectedItem(new Double(D()));
  }

  public void B(double paramDouble)
  {
    E = paramDouble;
  }

  public void C(double paramDouble)
  {
    B = paramDouble;
  }

  public boolean C()
  {
    double d = D();
    if (d != A(d))
    {
      Toolkit.getDefaultToolkit().beep();
      E().setSelectedItem(new Double(A(d)));
      return false;
    }
    return true;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.P.J
 * JD-Core Version:    0.6.2
 */