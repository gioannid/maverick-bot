package com.biotools.poker.P;

import com.biotools.poker.A;
import com.biotools.poker.E;
import com.biotools.poker.PokerApp;
import com.biotools.poker.Q.F;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;

public class G extends V
{
  private ArrayList Ø = new ArrayList();
  private JButton Ö;
  private JButton Ù;
  private JButton Ü;
  private A Ú;
  private J Õ;
  private double Ô;
  private int Û;

  public G(double paramDouble)
  {
    this.Ô = paramDouble;
  }

  public G(double paramDouble, int paramInt)
  {
    this.Ô = paramDouble;
    this.Û = paramInt;
  }

  public JLabel F()
  {
    return new JLabel(E.D("BankrollManager.SetBankrollsTitle"), 0);
  }

  public JPanel r()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setDoubleBuffered(false);
    localJPanel.setOpaque(false);
    localJPanel.setLayout(new BoxLayout(localJPanel, 1));
    this.Ú = I().ʋ();
    for (int i = 0; i < 10; i++)
      if (this.Ú.b(i))
      {
        G._A local_A = new G._A(this, this.Ú.Z(i).getName(), (int)this.Ú.Z(i).getBankRoll());
        this.Ø.add(local_A);
        localJPanel.add(local_A);
        localJPanel.add(Box.createVerticalStrut(5));
      }
    return localJPanel;
  }

  public JPanel p()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setDoubleBuffered(false);
    localJPanel.setOpaque(false);
    localJPanel.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(u());
    localJPanel.add(Box.createHorizontalStrut(20));
    localJPanel.add(o());
    localJPanel.add(Box.createHorizontalGlue());
    return localJPanel;
  }

  public JPanel q()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new GridLayout(1, 2, 6, 6));
    localJPanel.add(t());
    localJPanel.add(s());
    localJPanel.setDoubleBuffered(false);
    localJPanel.setOpaque(false);
    return localJPanel;
  }

  public JPanel A()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 1));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    localJPanel.setDoubleBuffered(false);
    localJPanel.setOpaque(false);
    localJPanel.add(Box.createVerticalGlue());
    localJPanel.add(q());
    localJPanel.add(Box.createVerticalStrut(20));
    localJPanel.add(new JSeparator());
    localJPanel.add(Box.createVerticalStrut(20));
    localJPanel.add(r());
    localJPanel.add(Box.createVerticalStrut(15));
    localJPanel.add(p());
    localJPanel.add(Box.createVerticalGlue());
    Z localZ = new Z();
    localZ.setLayout(new BorderLayout(10, 10));
    localZ.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    localZ.add(localJPanel, "Center");
    return localZ;
  }

  private JButton u()
  {
    if (this.Ö == null)
    {
      this.Ö = new JButton(E.D("BankrollManager.OKButton"));
      this.Ö.addActionListener(new G.1(this));
    }
    return this.Ö;
  }

  private JButton o()
  {
    if (this.Ù == null)
    {
      this.Ù = new JButton(E.D("BankrollManager.CancelButton"));
      this.Ù.addActionListener(new G.2(this));
    }
    return this.Ù;
  }

  private JButton t()
  {
    if (this.Ü == null)
    {
      this.Ü = new JButton(E.D("BankrollManager.SetAllTitle"));
      this.Ü.addActionListener(new G.3(this));
    }
    return this.Ü;
  }

  private J s()
  {
    if (this.Õ == null)
      this.Õ = new J(this.Ô, this.Û);
    return this.Õ;
  }

  private void v()
  {
    I().ʡ();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.P.G
 * JD-Core Version:    0.6.2
 */