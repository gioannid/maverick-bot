package com.biotools.poker.P;

import com.biotools.B.A;
import com.biotools.poker.E;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JViewport;
import javax.swing.border.CompoundBorder;
import javax.swing.border.TitledBorder;

public abstract class Q extends JPanel
{
  private boolean A = false;

  public abstract JLabel F();

  public abstract JPanel A();

  public void G()
  {
  }

  public boolean C()
  {
    return this.A;
  }

  public void A(boolean paramBoolean)
  {
    this.A = paramBoolean;
  }

  public JComponent B()
  {
    JButton localJButton = new JButton(new ImageIcon("data/pix/Stop24.gif"));
    localJButton.setRolloverEnabled(true);
    localJButton.setRolloverIcon(new ImageIcon("data/pix/Stop24-on.gif"));
    localJButton.setContentAreaFilled(false);
    localJButton.setBorderPainted(false);
    localJButton.addActionListener(new Q.1(this));
    return localJButton;
  }

  public void D()
  {
    JPanel localJPanel = A();
    A(localJPanel);
    localJPanel.setDoubleBuffered(false);
    localJPanel.setOpaque(false);
    localJPanel.setMaximumSize(localJPanel.getMinimumSize());
    JLabel localJLabel = E();
    Z localZ = new Z();
    setLayout(new BoxLayout(this, 1));
    if (localJLabel != null)
    {
      localZ.setLayout(new BorderLayout(5, 5));
      localZ.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
      localZ.add(E(), "Center");
      if (C())
        localZ.add(B(), "East");
      localZ.setDoubleBuffered(false);
      localZ.setOpaque(false);
      localZ.setMaximumSize(new Dimension(localJPanel.getMinimumSize().width, localZ.getMinimumSize().height));
      add(localZ);
      add(Box.createVerticalStrut(1));
    }
    add(localJPanel);
    add(Box.createVerticalStrut(5));
    setDoubleBuffered(false);
    setOpaque(false);
    setVisible(true);
  }

  protected JLabel E()
  {
    JLabel localJLabel = F();
    if (localJLabel == null)
      return null;
    localJLabel.setFont(new Font("Arial", 1, 12));
    localJLabel.setForeground(A.D);
    return localJLabel;
  }

  public static void A(JComponent paramJComponent)
  {
    if (E.¤())
      if ((paramJComponent instanceof JButton))
      {
        if (((JButton)paramJComponent).isContentAreaFilled())
          paramJComponent.setOpaque(false);
      }
      else if ((paramJComponent instanceof JComboBox))
        paramJComponent.setOpaque(false);
    (paramJComponent instanceof JButton);
    if ((paramJComponent instanceof JPanel))
      ((JPanel)paramJComponent).setOpaque(false);
    if (((paramJComponent instanceof JLabel)) || ((paramJComponent instanceof JCheckBox)) || ((paramJComponent instanceof JRadioButton)))
      paramJComponent.setForeground(A.D);
    if ((paramJComponent instanceof JSlider))
    {
      ((JSlider)paramJComponent).setBackground(Z.C);
      paramJComponent.setOpaque(false);
    }
    if ((paramJComponent.getBorder() instanceof TitledBorder))
      ((TitledBorder)paramJComponent.getBorder()).setTitleColor(A.D);
    if ((paramJComponent.getBorder() instanceof CompoundBorder))
    {
      localObject = ((CompoundBorder)paramJComponent.getBorder()).getOutsideBorder();
      if ((localObject instanceof TitledBorder))
        ((TitledBorder)localObject).setTitleColor(A.D);
    }
    if (((paramJComponent instanceof JCheckBox)) || ((paramJComponent instanceof JRadioButton)))
      paramJComponent.setOpaque(false);
    if ((paramJComponent instanceof JEditorPane))
      ((JEditorPane)paramJComponent).setOpaque(false);
    if ((paramJComponent instanceof JTextArea))
    {
      ((JTextArea)paramJComponent).setOpaque(false);
      ((JTextArea)paramJComponent).setBackground(Z.C);
      ((JTextArea)paramJComponent).setForeground(A.D);
    }
    if ((paramJComponent instanceof JScrollPane))
    {
      ((JScrollPane)paramJComponent).setOpaque(false);
      ((JScrollPane)paramJComponent).getViewport().setOpaque(false);
    }
    if ((paramJComponent instanceof JTabbedPane))
      return;
    Object localObject = paramJComponent.getComponents();
    for (int i = 0; i < localObject.length; i++)
      if ((localObject[i] instanceof JComponent))
        A((JComponent)localObject[i]);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.P.Q
 * JD-Core Version:    0.6.2
 */