package com.biotools.poker.P;

import com.biotools.B.L;
import com.biotools.poker.E;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class R extends V
{
  private JButton ē = new JButton(KeyEvent.getKeyText(E.À()));
  private JButton Đ = new JButton(KeyEvent.getKeyText(E.G()));
  private JButton Ē = new JButton(KeyEvent.getKeyText(E.g()));
  private JButton Č = new JButton(KeyEvent.getKeyText(E.k()));
  private JButton ď = new JButton(KeyEvent.getKeyText(E.ª()));
  private JButton ċ = new JButton(KeyEvent.getKeyText(E.E()));
  private JButton č = new JButton(KeyEvent.getKeyText(E.Ñ()));
  private JButton đ = new JButton(KeyEvent.getKeyText(E.P()));
  private JButton Ĕ = new JButton(KeyEvent.getKeyText(E.r()));
  private JButton ė = new JButton(KeyEvent.getKeyText(E.È()));
  private JButton Ė = new JButton(KeyEvent.getKeyText(E.Ö()));
  private JButton Ď = new JButton(KeyEvent.getKeyText(E.Ó()));
  private int ĕ = -1;

  public JLabel F()
  {
    return new JLabel(E.D("HotKeyEditor.HotKeyEditorHeading"), 0);
  }

  public JPanel A()
  {
    this.ē.addActionListener(new R.1(this));
    this.Đ.addActionListener(new R.2(this));
    this.Ē.addActionListener(new R.3(this));
    this.Č.addActionListener(new R.4(this));
    this.ď.addActionListener(new R.5(this));
    this.ċ.addActionListener(new R.6(this));
    this.č.addActionListener(new R.7(this));
    this.Ĕ.addActionListener(new R.8(this));
    this.ė.addActionListener(new R.9(this));
    this.Ė.addActionListener(new R.10(this));
    this.đ.addActionListener(new R.11(this));
    this.Ď.addActionListener(new R.12(this));
    JButton localJButton = new JButton(E.D("HotKeyEditor.OKButton"));
    localJButton.addActionListener(new R.13(this));
    JPanel localJPanel1 = new JPanel();
    localJPanel1.setLayout(new BoxLayout(localJPanel1, 0));
    localJPanel1.add(Box.createHorizontalGlue());
    localJPanel1.add(localJButton);
    localJPanel1.add(Box.createHorizontalGlue());
    JPanel localJPanel2 = new JPanel(new GridLayout(4, 6, 12, 6));
    localJPanel2.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
    localJPanel2.add(new JLabel(E.D("HotKeyEditor.FoldTitle"), 4));
    localJPanel2.add(this.ē);
    localJPanel2.add(new JLabel(E.D("HotKeyEditor.HalfPotTitle"), 4));
    localJPanel2.add(this.Ĕ);
    localJPanel2.add(new JLabel(E.D("HotKeyEditor.DealTitle"), 4));
    localJPanel2.add(this.Č);
    localJPanel2.add(new JLabel(E.D("HotKeyEditor.CheckCallTitle"), 4));
    localJPanel2.add(this.Đ);
    localJPanel2.add(new JLabel(E.D("HotKeyEditor.BetPotTitle"), 4));
    localJPanel2.add(this.ė);
    localJPanel2.add(new JLabel(E.D("HotKeyEditor.ZipTitle"), 4));
    localJPanel2.add(this.ď);
    localJPanel2.add(new JLabel(E.D("HotKeyEditor.BetRaiseTitle"), 4));
    localJPanel2.add(this.Ē);
    localJPanel2.add(new JLabel(E.D("HotKeyEditor.Bet2TimesTitle"), 4));
    localJPanel2.add(this.Ė);
    localJPanel2.add(new JLabel(E.D("HotKeyEditor.ChatTitle"), 4));
    localJPanel2.add(this.č);
    localJPanel2.add(new JLabel(E.D("HotKeyEditor.EnterRaiseTitle"), 4));
    localJPanel2.add(this.đ);
    localJPanel2.add(new JLabel(E.D("HotKeyEditor.AllInTitle"), 4));
    localJPanel2.add(this.Ď);
    localJPanel2.add(new JLabel(E.D("HotKeyEditor.FlashCardsTitle"), 4));
    localJPanel2.add(this.ċ);
    Z localZ = new Z();
    localZ.setLayout(new BorderLayout(10, 10));
    localZ.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
    localZ.add(new JLabel(E.D("HotKeyEditor.ClickButtonsToChange"), 0), "North");
    localZ.add(localJPanel2, "Center");
    localZ.add(localJPanel1, "South");
    return localZ;
  }

  private int Ü()
  {
    this.ĕ = -1;
    JPanel localJPanel = new JPanel(new BorderLayout());
    localJPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
    localJPanel.add(new JLabel(E.D("HotKeyEditor.PleaseTypeAKey")));
    JDialog localJDialog = new JDialog(I());
    localJDialog.getContentPane().add(localJPanel);
    localJDialog.addKeyListener(new R.14(this, localJDialog));
    localJDialog.setModal(true);
    localJDialog.setResizable(true);
    localJDialog.setDefaultCloseOperation(0);
    localJDialog.setTitle(E.D("HotKeyEditor.ActionHotKey"));
    localJDialog.getContentPane().add(localJPanel);
    L.A(localJDialog);
    localJDialog.setVisible(true);
    return this.ĕ;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.P.R
 * JD-Core Version:    0.6.2
 */