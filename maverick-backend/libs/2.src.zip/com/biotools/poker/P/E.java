package com.biotools.poker.P;

import com.biotools.A.B;
import com.biotools.B.L;
import com.biotools.meerkat.util.Preferences;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;

public class E extends V
{
  private static int Ï;
  private static int É;
  private static int Î;
  public static final String Ê = "FAST_FOLDS";
  public static final String Í = "INSTANT_FOLDS";
  public static final String È = "AUTODEAL_THROTTLE";
  public static final String Ñ = "ACTION_THROTTLE";
  public static final String Ë = "SHOWDOWN_THROTTLE";
  private Preferences Ó = com.biotools.poker.E.£();
  private JSlider Æ;
  private JSlider Ð;
  private JSlider Ì;
  private JCheckBox Ç;
  private JCheckBox Ò;

  public JLabel F()
  {
    return new JLabel(com.biotools.poker.E.D("ThrottlePrefs.EditThrottleControllsHeading"), 0);
  }

  private void f()
  {
    this.Ð.setValue(this.Ó.getInt("SHOWDOWN_THROTTLE", 2000));
    this.Æ.setValue(this.Ó.getInt("ACTION_THROTTLE", 750));
    this.Ì.setValue(this.Ó.getInt("AUTODEAL_THROTTLE", 1000));
    this.Ç.setSelected(this.Ó.getBoolean("FAST_FOLDS", false));
    this.Ò.setSelected(this.Ó.getBoolean("INSTANT_FOLDS", false));
  }

  private void d()
  {
    this.Ó.putInt("SHOWDOWN_THROTTLE", this.Ð.getValue());
    this.Ó.putInt("ACTION_THROTTLE", this.Æ.getValue());
    this.Ó.putInt("AUTODEAL_THROTTLE", this.Ì.getValue());
    this.Ó.putBoolean("FAST_FOLDS", this.Ç.isSelected());
    this.Ó.putBoolean("INSTANT_FOLDS", this.Ò.isSelected());
  }

  private JPanel C(int paramInt)
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(Box.createHorizontalStrut(3));
    localJPanel.add(new JLabel(com.biotools.poker.E.D("ThrottlePrefs.0Sec")));
    localJPanel.add(Box.createHorizontalGlue());
    Object[] arrayOfObject1 = { new Integer(paramInt) };
    localJPanel.add(new JLabel(com.biotools.poker.E.A("ThrottlePrefs.SecPattern", arrayOfObject1)));
    localJPanel.add(Box.createHorizontalGlue());
    Object[] arrayOfObject2 = { new Integer(paramInt) };
    localJPanel.add(new JLabel(paramInt + paramInt + com.biotools.poker.E.A("ThrottlePrefs.SecPattern", arrayOfObject2)));
    localJPanel.add(Box.createHorizontalStrut(3));
    return localJPanel;
  }

  private JComponent A(JSlider paramJSlider, String paramString, int paramInt)
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 1));
    localJPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createTitledBorder(paramString), BorderFactory.createEmptyBorder(4, 4, 4, 4)));
    localJPanel.add(paramJSlider);
    localJPanel.add(C(paramInt));
    return localJPanel;
  }

  public JComponent g()
  {
    this.Æ = new JSlider(0, 4000);
    this.Æ.setToolTipText(com.biotools.poker.E.D("ThrottlePrefs.ActionsToolTip"));
    return A(this.Æ, com.biotools.poker.E.D("ThrottlePrefs.ActionsTitle"), 2);
  }

  public JComponent l()
  {
    this.Ð = new JSlider(0, 4000);
    this.Ð.setToolTipText(com.biotools.poker.E.D("ThrottlePrefs.ShowdownsToolTip"));
    return A(this.Ð, com.biotools.poker.E.D("ThrottlePrefs.ShowdownsTitle"), 2);
  }

  public JComponent n()
  {
    this.Ì = new JSlider(0, 8000);
    this.Ì.setToolTipText(com.biotools.poker.E.D("ThrottlePrefs.AutoDealToolTip") + "(when auto-dealing is activated).");
    return A(this.Ì, com.biotools.poker.E.D("ThrottlePrefs.AutoDealTitle"), 4);
  }

  public JPanel e()
  {
    JButton localJButton1 = new JButton(com.biotools.poker.E.D("ThrottlePrefs.CancelButton"));
    localJButton1.addActionListener(new E.1(this));
    JButton localJButton2 = new JButton(com.biotools.poker.E.D("ThrottlePrefs.ResetButton"));
    localJButton2.addActionListener(new E.2(this));
    JButton localJButton3 = new JButton(com.biotools.poker.E.D("ThrottlePrefs.OKButton"));
    localJButton3.addActionListener(new E.3(this));
    JPanel localJPanel = new JPanel();
    localJPanel.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(localJButton3);
    localJPanel.add(Box.createHorizontalStrut(10));
    localJPanel.add(localJButton1);
    localJPanel.add(Box.createHorizontalStrut(30));
    localJPanel.add(localJButton2);
    localJPanel.add(Box.createHorizontalGlue());
    return localJPanel;
  }

  public JPanel A()
  {
    this.Ç = new JCheckBox(com.biotools.poker.E.D("ThrottlePrefs.FastFolds"));
    this.Ç.setToolTipText(com.biotools.poker.E.D("ThrottlePrefs.FastFoldsToolTip"));
    this.Ò = new JCheckBox(com.biotools.poker.E.D("ThrottlePrefs.AutoZip"));
    this.Ò.setToolTipText(com.biotools.poker.E.D("ThrottlePrefs.AutoZipToolTip"));
    JPanel localJPanel1 = new JPanel(new GridLayout(1, 2, 4, 4));
    localJPanel1.add(this.Ç);
    localJPanel1.add(this.Ò);
    JPanel localJPanel2 = new JPanel();
    localJPanel2.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    localJPanel2.setLayout(new BoxLayout(localJPanel2, 1));
    localJPanel2.add(g());
    localJPanel2.add(Box.createVerticalStrut(5));
    localJPanel2.add(l());
    localJPanel2.add(Box.createVerticalStrut(15));
    localJPanel2.add(n());
    localJPanel2.add(Box.createVerticalStrut(15));
    localJPanel2.add(localJPanel1);
    String str = B.A(com.biotools.poker.E.K("help/throttlesUI.html"));
    str = str.replaceFirst("%FGCOL%", L.A(com.biotools.B.A.D));
    com.A.B.A localA = new com.A.B.A();
    localA.A(str);
    localA.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
    localA.setPreferredSize(new Dimension(300, 300));
    Z localZ = new Z();
    localZ.setLayout(new BorderLayout(8, 8));
    localZ.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
    localZ.add(localJPanel2, "West");
    localZ.add(e(), "South");
    localZ.add(localA, "Center");
    f();
    return localZ;
  }

  public static void j()
  {
    Ï = com.biotools.poker.E.£().getInt("ACTION_THROTTLE", 750);
    É = com.biotools.poker.E.£().getInt("SHOWDOWN_THROTTLE", 2000);
    Î = com.biotools.poker.E.£().getInt("AUTODEAL_THROTTLE", 4000);
  }

  public static boolean i()
  {
    return com.biotools.poker.E.£().getBoolean("FAST_FOLDS", false);
  }

  public static int h()
  {
    return Î;
  }

  public static int m()
  {
    return Ï;
  }

  public static int k()
  {
    return É;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.P.E
 * JD-Core Version:    0.6.2
 */