package com.biotools.poker.P;

import com.biotools.B.L;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import java.awt.Container;
import java.awt.GridLayout;
import java.util.Properties;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class _ extends JDialog
{
  private JTextField A = new JTextField(F());
  private JTextField F = new JTextField(E());
  private JTextField E = new JTextField(G());
  private JPasswordField D = new JPasswordField(D());
  private JCheckBox B = new JCheckBox(E.D("ProxySetup.Authentication"), I());
  private JCheckBox C = new JCheckBox(E.D("ProxySetup.UseProxyServer"), C());

  public _(JFrame paramJFrame)
  {
    super(paramJFrame, true);
    A();
  }

  public _(JDialog paramJDialog)
  {
    super(paramJDialog, true);
    A();
  }

  private void A()
  {
    this.C.addItemListener(new _.1(this));
    this.B.addItemListener(new _.2(this));
    JButton localJButton = new JButton(E.D("ProxySetup.OK"));
    localJButton.addActionListener(new _.3(this));
    JPanel localJPanel = new JPanel(new GridLayout(3, 3, 8, 8));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    localJPanel.add(this.C);
    localJPanel.add(this.A);
    localJPanel.add(this.F);
    localJPanel.add(this.B);
    localJPanel.add(this.E);
    localJPanel.add(this.D);
    localJPanel.add(new JLabel(""));
    localJPanel.add(localJButton);
    localJPanel.add(new JLabel(""));
    B();
    setTitle(E.D("ProxySetup.ProxyServerSettings"));
    getContentPane().add(localJPanel);
    setDefaultCloseOperation(2);
    L.A(this);
    setVisible(true);
  }

  private void B()
  {
    this.B.setEnabled(this.C.isSelected());
    this.A.setEnabled(this.C.isSelected());
    this.F.setEnabled(this.C.isSelected());
    this.E.setEnabled((this.C.isSelected()) && (this.B.isSelected()));
    this.D.setEnabled((this.C.isSelected()) && (this.B.isSelected()));
  }

  public void dispose()
  {
    super.dispose();
    E.£().put("http.proxyHost", this.A.getText());
    E.£().put("http.proxyPort", this.F.getText());
    E.£().put("http.proxyUser", this.E.getText());
    E.£().put("http.proxyPassword", new String(this.D.getPassword()));
    E.£().putBoolean("proxySet", this.C.isSelected());
    E.£().putBoolean("proxyPwd", this.B.isSelected());
    H();
  }

  private static String F()
  {
    return E.£().get("http.proxyHost", "localhost");
  }

  private static String E()
  {
    return E.£().get("http.proxyPort", "8080");
  }

  private static String G()
  {
    return E.£().get("http.proxyUser", "");
  }

  private static String D()
  {
    return E.£().get("http.proxyPassword", "");
  }

  private static boolean C()
  {
    return E.£().getBoolean("proxySet", false);
  }

  private static boolean I()
  {
    return E.£().getBoolean("proxyPwd", false);
  }

  public static void H()
  {
    System.setProperty("http.proxySet", Boolean.toString(C()));
    System.setProperty("proxySet", Boolean.toString(C()));
    if (!C())
    {
      System.getProperties().remove("http.proxyHost");
      System.getProperties().remove("http.proxyPort");
      System.getProperties().remove("http.proxyUser");
      System.getProperties().remove("http.proxyPassword");
      return;
    }
    System.setProperty("http.proxyHost", F());
    System.setProperty("http.proxyPort", E());
    if (I())
    {
      System.setProperty("http.proxyUser", G());
      System.setProperty("http.proxyPassword", D());
    }
    else
    {
      System.getProperties().remove("http.proxyUser");
      System.getProperties().remove("http.proxyPassword");
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.P._
 * JD-Core Version:    0.6.2
 */