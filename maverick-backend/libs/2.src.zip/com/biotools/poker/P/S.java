package com.biotools.poker.P;

import com.biotools.meerkat.Card;
import com.biotools.meerkat.Deck;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.PokerApp;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class S extends V
{
  private static final String[] ę = { com.biotools.poker.E.D("DealerOptionsPanel.Top"), com.biotools.poker.E.D("DealerOptionsPanel.Middle"), com.biotools.poker.E.D("DealerOptionsPanel.Bottom") };
  private Deck Ě = new Deck();
  private S._A[] Ĝ = new S._A[10];
  private com.biotools.poker.L.K[] ě = new com.biotools.poker.L.K[5];
  private JCheckBox Ę;
  private JCheckBox ĝ;

  public JLabel F()
  {
    return new JLabel(com.biotools.poker.E.D("DealerOptionsPanel.DealerOptionsHeading"), 0);
  }

  public JPanel A()
  {
    PokerApp localPokerApp = I();
    Z localZ = new Z();
    localZ.setLayout(new BorderLayout(8, 8));
    localZ.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    localZ.add(A(localPokerApp.ʐ(), localPokerApp.ɬ()), "West");
    localZ.add(Ý(), "East");
    return localZ;
  }

  private JPanel A(com.biotools.poker.Q.K paramK, String paramString)
  {
    JPanel localJPanel = new JPanel(new GridLayout(10, 1));
    localJPanel.setBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("DealerOptionsPanel.FixedHoleCardsTitle")));
    this.Ĝ[0] = new S._A(this, 0, paramString);
    localJPanel.add(this.Ĝ[0]);
    for (int i = 1; i < 10; i++)
    {
      String str = com.biotools.poker.E.D("DealerOptionsPanel.Emtpy");
      if (paramK.H(i))
        str = paramK.F(i);
      this.Ĝ[i] = new S._A(this, i, str);
      localJPanel.add(this.Ĝ[i]);
    }
    return localJPanel;
  }

  private JPanel Ý()
  {
    JPanel localJPanel = new JPanel(new BorderLayout(10, 10));
    localJPanel.add(á(), "Center");
    localJPanel.add(à(), "North");
    localJPanel.add(Þ(), "South");
    return localJPanel;
  }

  private JPanel á()
  {
    this.Ę = new JCheckBox(com.biotools.poker.E.D("DealerOptionsPanel.LogHistoriesAndStatistics"), com.biotools.poker.Q.E.A());
    this.ĝ = new JCheckBox(com.biotools.poker.E.D("DealerOptionsPanel.RemoveCapOnceHeadsUp"), com.biotools.poker.Q.E.B());
    JPanel localJPanel = new JPanel();
    localJPanel.setBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("DealerOptionsPanel.OtherOptionsTitle")));
    localJPanel.setLayout(new BoxLayout(localJPanel, 1));
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.add(this.Ę);
    localJPanel.add(Box.createVerticalStrut(10));
    localJPanel.add(this.ĝ);
    localJPanel.add(Box.createVerticalStrut(5));
    localJPanel.add(Box.createVerticalGlue());
    return localJPanel;
  }

  private void B(int paramInt1, int paramInt2)
  {
    com.biotools.poker.E.£().putInt("DEAL_METHOD_" + paramInt1, paramInt2);
  }

  private void C(int paramInt1, int paramInt2)
  {
    com.biotools.poker.E.£().putInt("DEAL_RANGE_" + paramInt1, paramInt2);
  }

  private void A(int paramInt1, int paramInt2)
  {
    com.biotools.poker.E.£().putInt("DEAL_RANGE_TYPE" + paramInt1, paramInt2);
  }

  private void A(int paramInt, Card paramCard1, Card paramCard2)
  {
    int i = -1;
    if (paramCard1 != null)
      i = paramCard1.getIndex();
    com.biotools.poker.E.£().putInt("FDHC" + paramInt + "_" + 0, i);
    i = -1;
    if (paramCard2 != null)
      i = paramCard2.getIndex();
    com.biotools.poker.E.£().putInt("FDHC" + paramInt + "_" + 1, i);
  }

  private void A(int paramInt, Card paramCard)
  {
    int i = -1;
    if (paramCard != null)
      i = paramCard.getIndex();
    com.biotools.poker.E.£().putInt("FDBC" + paramInt, i);
  }

  private JPanel à()
  {
    JPanel localJPanel1 = new JPanel();
    localJPanel1.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    localJPanel1.setLayout(new BoxLayout(localJPanel1, 0));
    for (int i = 0; i < 5; i++)
    {
      this.ě[i] = new com.biotools.poker.L.K(this.Ě, I());
      this.ě[i].C();
      this.ě[i].setBackground(Z.C);
      this.ě[i].A(com.biotools.poker.Q.E.B(i));
      localJPanel1.add(this.ě[i]);
      localJPanel1.add(Box.createHorizontalStrut(5));
    }
    localJPanel1.add(Box.createHorizontalGlue());
    JPanel localJPanel2 = new JPanel();
    localJPanel2.setBorder(BorderFactory.createTitledBorder(com.biotools.poker.E.D("DealerOptionsPanel.FixedBoardCardsTitle")));
    localJPanel2.add(localJPanel1);
    return localJPanel2;
  }

  private JPanel Þ()
  {
    JButton localJButton1 = new JButton(com.biotools.poker.E.D("DealerOptionsPanel.OKButton"));
    localJButton1.addActionListener(new S.5(this));
    JButton localJButton2 = new JButton(com.biotools.poker.E.D("DealerOptionsPanel.CancelButton"));
    localJButton2.addActionListener(new S.6(this));
    JButton localJButton3 = new JButton(com.biotools.poker.E.D("DealerOptionsPanel.ResetButton"));
    localJButton3.addActionListener(new S.7(this));
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(localJButton1);
    localJPanel.add(Box.createHorizontalStrut(10));
    localJPanel.add(localJButton2);
    localJPanel.add(Box.createHorizontalStrut(30));
    localJPanel.add(localJButton3);
    localJPanel.add(Box.createHorizontalGlue());
    return localJPanel;
  }

  public void ß()
  {
    for (int i = 0; i < 5; i++)
    {
      A(i, null);
      this.ě[i].A(null);
    }
    for (i = 0; i < 10; i++)
      S._A.access$1(this.Ĝ[i]);
    this.Ě.reset();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.P.S
 * JD-Core Version:    0.6.2
 */