package com.biotools.poker.P;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class b extends V
{
  public JLabel F()
  {
    return null;
  }

  public JPanel A()
  {
    return new JPanel();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.P.b
 * JD-Core Version:    0.6.2
 */