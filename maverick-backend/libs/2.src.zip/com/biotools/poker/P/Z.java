package com.biotools.poker.P;

import com.biotools.B.A;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LayoutManager;
import javax.swing.JPanel;

public class Z extends JPanel
{
  public static final Color C = A.M;
  private Color B = C;
  private float A = 0.9F;

  public Z(LayoutManager paramLayoutManager)
  {
    super(paramLayoutManager);
  }

  public Z()
  {
  }

  public Z(Color paramColor, float paramFloat)
  {
    this.B = paramColor;
    this.A = paramFloat;
  }

  public void paintComponent(Graphics paramGraphics)
  {
    Graphics2D localGraphics2D = (Graphics2D)paramGraphics;
    Composite localComposite = localGraphics2D.getComposite();
    AlphaComposite localAlphaComposite = AlphaComposite.getInstance(3, 0.05F);
    localGraphics2D.setComposite(localAlphaComposite);
    localGraphics2D.setColor(A.D);
    localGraphics2D.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
    localAlphaComposite = AlphaComposite.getInstance(3, this.A);
    localGraphics2D.setComposite(localAlphaComposite);
    localGraphics2D.setColor(this.B);
    localGraphics2D.fillRoundRect(2, 2, getWidth() - 4, getHeight() - 4, 20, 20);
    localGraphics2D.setComposite(localComposite);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.P.Z
 * JD-Core Version:    0.6.2
 */