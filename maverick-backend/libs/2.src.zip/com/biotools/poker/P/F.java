package com.biotools.poker.P;

import com.biotools.B.A;
import com.biotools.poker.E;
import com.biotools.poker.H.D;
import java.awt.Font;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

public class F extends JPopupMenu
{
  public F()
  {
    JMenuItem localJMenuItem = new JMenuItem(E.D("TranscriptOptions.TranscriptOptionsTitle"));
    localJMenuItem.setEnabled(false);
    localJMenuItem.setFont(localJMenuItem.getFont().deriveFont(1));
    add(localJMenuItem);
    addSeparator();
    add(new D(E.D("TranscriptOptions.PlayerActions"), E.D("TranscriptOptions.PlayerActionsToolTip"), "TRANSCRIPT_DISPLAY_GAME_ACTIONS", true));
    add(new D(E.D("TranscriptOptions.HandEvents"), E.D("TranscriptOptions.HandEventsToolTip"), "TRANSCRIPT_DISPLAY_GAME_EVENTS", true));
    add(new D(E.D("TranscriptOptions.HandSummary"), E.D("TranscriptOptions.HandSummaryToolTip"), "TRANSCRIPT_DISPLAY_GAME_SUMMARY", true));
    addSeparator();
    add(new D(E.D("TranscriptOptions.PlayerChat"), E.D("TranscriptOptions.PlayerChatToolTip"), "TRANSCRIPT_DISPLAY_CHAT", true));
    A.A(this);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.P.F
 * JD-Core Version:    0.6.2
 */