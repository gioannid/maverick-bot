package com.biotools.poker.P;

import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import com.biotools.poker.PokerApp;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.io.File;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class N extends V
  implements ListSelectionListener
{
  private JList ö = null;
  private DefaultListModel ú = new DefaultListModel();
  private JButton û = new JButton(E.D("ProfileManager.AddButton"));
  private JButton ù = new JButton(E.D("ProfileManager.DeleteButton"));
  private JButton ø = new JButton(E.D("ProfileManager.SelectProfileButton"));
  private JCheckBox ô = new JCheckBox(E.D("ProfileManager.ShowScreenAtStartup"));
  private boolean ü;
  private static boolean õ = false;

  public N(boolean paramBoolean)
  {
    õ = true;
    this.ü = paramBoolean;
    A(true);
  }

  public void G()
  {
    õ = false;
    B(false);
  }

  public JPanel A()
  {
    Ò();
    this.û.setPreferredSize(this.ù.getPreferredSize());
    this.ö = new JList(this.ú);
    this.ö.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    this.ö.addListSelectionListener(this);
    this.ö.setSelectionMode(0);
    String str = I().ɬ();
    if (str != null)
    {
      int i = this.ú.indexOf(str);
      if (i != -1)
        this.ö.setSelectedIndex(i);
      else
        this.ö.setSelectedIndex(0);
    }
    else
    {
      this.ö.setSelectedIndex(0);
    }
    this.ö.addKeyListener(new N.1(this));
    N.2 local2 = new N.2(this);
    this.ö.addMouseListener(local2);
    if (this.ú.size() == 0)
      Ô();
    this.û.addActionListener(new N.3(this));
    this.ù.addActionListener(new N.4(this));
    this.ø.addActionListener(new N.5(this));
    JScrollPane localJScrollPane = new JScrollPane(this.ö);
    Dimension localDimension = new Dimension(100, 150);
    localJScrollPane.setPreferredSize(localDimension);
    localJScrollPane.setMinimumSize(localDimension);
    localJScrollPane.setMaximumSize(localDimension);
    localJScrollPane.setOpaque(false);
    JPanel localJPanel1 = new JPanel();
    localJPanel1.setLayout(new GridLayout(2, 1, 0, 5));
    localJPanel1.add(this.û);
    localJPanel1.add(this.ù);
    localDimension = localJPanel1.getPreferredSize();
    localJPanel1.setMinimumSize(localDimension);
    localJPanel1.setMaximumSize(localDimension);
    localJPanel1.setOpaque(false);
    JPanel localJPanel2 = new JPanel();
    localJPanel2.setLayout(new BoxLayout(localJPanel2, 1));
    localJPanel2.add(localJPanel1);
    localJPanel2.add(Box.createVerticalGlue());
    localJPanel2.setOpaque(false);
    this.ô.setOpaque(false);
    this.ô.setForeground(Color.WHITE);
    this.ô.setSelected(E.£().getBoolean("SHOW_PROFILE_AT_STARTUP", true));
    JButton localJButton = this.ø;
    JPanel localJPanel3 = new JPanel();
    localJPanel3.setLayout(new BoxLayout(localJPanel3, 1));
    localJPanel3.setBorder(BorderFactory.createEmptyBorder(10, 3, 3, 3));
    localJButton.setAlignmentX(0.5F);
    this.ô.setAlignmentX(0.5F);
    localJPanel3.add(localJButton);
    localJPanel3.add(Box.createVerticalStrut(5));
    localJPanel3.add(this.ô);
    localJPanel3.setOpaque(false);
    Z localZ = new Z();
    localZ.setLayout(new BorderLayout(4, 4));
    localZ.setBorder(BorderFactory.createEmptyBorder(13, 13, 13, 13));
    localZ.add(localJScrollPane, "West");
    localZ.add(localJPanel2, "East");
    localZ.add(localJPanel3, "South");
    return localZ;
  }

  public void valueChanged(ListSelectionEvent paramListSelectionEvent)
  {
    int i = this.ö.getSelectedIndex();
    boolean bool = (i >= 0) && (i < this.ú.size());
    this.ù.setEnabled(bool);
    this.ø.setEnabled(bool);
  }

  public void J(String paramString)
  {
    if (paramString != null)
    {
      I().y(paramString);
      E.£().putBoolean("SHOW_PROFILE_AT_STARTUP", this.ô.isSelected());
      if (this.ü)
        PokerApp.Ȅ().ȍ();
      else
        B(true);
    }
  }

  private void Ô()
  {
    String str = JOptionPane.showInputDialog(this, E.D("ProfileManager.EnterNameForNewProfile"));
    if (A(this, str))
    {
      str = str.trim();
      this.ú.addElement(str);
      this.ö.setSelectedIndex(this.ú.size() - 1);
    }
  }

  public static String A(Component paramComponent)
  {
    String str = JOptionPane.showInputDialog(paramComponent, E.D("ProfileManager.EnterNameForNewProfile"));
    if (A(paramComponent, str))
    {
      str = str.trim();
      return str;
    }
    return null;
  }

  protected static boolean A(Component paramComponent, String paramString)
  {
    if (paramString != null)
    {
      paramString = paramString.trim();
      if ((A(paramString, 1, 12)) && (E.E(paramString)))
      {
        K(paramString);
        return true;
      }
      JOptionPane.showMessageDialog(paramComponent, E.D("ProfileManager.IncorrectProfileNameText"), E.D("ProfileManager.IncorrectProfileName"), 0);
      return false;
    }
    return false;
  }

  protected static void K(String paramString)
  {
    File localFile = new File(E.n() + paramString + ".dat");
    Preferences localPreferences = new Preferences(localFile);
    localPreferences.setPreference("NAME", paramString);
    localPreferences.setPreference("PROFILE", true);
    localPreferences.savePreferences();
  }

  public static boolean A(String paramString, int paramInt1, int paramInt2)
  {
    int i = (paramString.length() >= paramInt1) && (paramString.length() <= paramInt2) ? 1 : 0;
    int j = 1;
    if (i != 0)
      for (int k = 0; k < paramString.length(); k++)
      {
        char c = paramString.charAt(k);
        if ((!Character.isLetterOrDigit(c)) && (c != '_') && (c != '-') && (!Character.isSpaceChar(c)))
        {
          j = 0;
          break;
        }
      }
    return (i != 0) && (j != 0);
  }

  private void Ó()
  {
    E.q();
    int i = this.ö.getSelectedIndex();
    if ((i >= 0) && (i < this.ú.size()))
    {
      String str = (String)this.ö.getSelectedValue();
      Object[] arrayOfObject = { str };
      int j = JOptionPane.showConfirmDialog(this, E.A("ProfileManager.DeleteProfileDialogTextPattern", arrayOfObject), E.D("ProfileManager.DeleteProfileDialog"), 0);
      if (j == 0)
      {
        File localFile = new File(E.n() + str + ".dat");
        localFile.delete();
        this.ú.remove(i);
      }
    }
  }

  public static boolean B(Component paramComponent, String paramString)
  {
    E.q();
    Object[] arrayOfObject = { paramString };
    int i = JOptionPane.showConfirmDialog(paramComponent, E.A("ProfileManager.DeleteProfileDialogTextPattern", arrayOfObject), E.D("ProfileManager.DeleteProfileDialog"), 0);
    if (i == 0)
    {
      File localFile = new File(E.n() + paramString + ".dat");
      localFile.delete();
      return true;
    }
    return false;
  }

  private void Ò()
  {
    Vector localVector = Ñ();
    Enumeration localEnumeration = localVector.elements();
    while (localEnumeration.hasMoreElements())
      this.ú.addElement(localEnumeration.nextElement());
  }

  public static Vector Ñ()
  {
    Vector localVector = new Vector();
    File localFile = new File(E.n());
    File[] arrayOfFile = localFile.listFiles();
    for (int i = 0; i < arrayOfFile.length; i++)
      if (arrayOfFile[i].getName().endsWith(".dat"))
      {
        Preferences localPreferences = new Preferences(arrayOfFile[i]);
        if (localPreferences.getBooleanPreference("PROFILE", false))
          localVector.addElement(localPreferences.getPreference("NAME", "?"));
      }
    if (localVector.size() > 1)
      Collections.sort(localVector);
    return localVector;
  }

  public static boolean Õ()
  {
    boolean bool = õ;
    õ = false;
    return bool;
  }

  public JLabel F()
  {
    return new JLabel(E.D("ProfileManager.SelectUserProfile"), 0);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.P.N
 * JD-Core Version:    0.6.2
 */