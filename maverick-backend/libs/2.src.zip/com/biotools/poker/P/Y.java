package com.biotools.poker.P;

import com.biotools.poker.A;
import com.biotools.poker.E;
import com.biotools.poker.PokerApp;
import com.biotools.poker.Q.F;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Y extends V
{
  private J ĩ;
  private JButton Ĩ;
  private JButton Ī;
  private double ħ;
  private int Ĭ = -1;
  private double ī = -1.0D;

  public Y()
  {
  }

  public Y(int paramInt, double paramDouble1, double paramDouble2)
  {
    this.ħ = paramDouble1;
    this.Ĭ = paramInt;
    this.ī = paramDouble2;
  }

  public JLabel F()
  {
    if (this.Ĭ != -1)
    {
      Object[] arrayOfObject = { I().ʋ().Z(this.Ĭ).getName() };
      return new JLabel(E.A("SetBankrollPrompt.SetBankrollForPattern", arrayOfObject), 0);
    }
    return new JLabel(E.D("SetBankrollPrompt.SetBuyIn"), 0);
  }

  public void K()
  {
    this.ĩ.H();
  }

  private J í()
  {
    if (this.ĩ == null)
      this.ĩ = new J(this.ħ, this.ī);
    return this.ĩ;
  }

  private JButton î()
  {
    if (this.Ĩ == null)
    {
      this.Ĩ = new JButton(E.D("SetBankrollPrompt.OKButton"));
      this.Ĩ.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          Y.this.I(true);
        }
      });
    }
    return this.Ĩ;
  }

  private JButton ê()
  {
    if (this.Ī == null)
    {
      this.Ī = new JButton(E.D("SetBankrollPrompt.CancelButton"));
      this.Ī.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          Y.this.I(false);
        }
      });
    }
    return this.Ī;
  }

  public JPanel A()
  {
    Z localZ = new Z();
    localZ.setLayout(new BorderLayout(10, 10));
    localZ.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    localZ.add(ì(), "Center");
    localZ.add(ë(), "South");
    return localZ;
  }

  private JPanel ì()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(new JLabel(E.D("SetBankrollPrompt.SetBankrollTo")));
    localJPanel.add(Box.createHorizontalStrut(5));
    localJPanel.add(í());
    localJPanel.add(Box.createHorizontalGlue());
    return localJPanel;
  }

  private JPanel ë()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    localJPanel.add(Box.createHorizontalGlue());
    localJPanel.add(Box.createHorizontalStrut(30));
    localJPanel.add(î());
    localJPanel.add(Box.createHorizontalStrut(5));
    localJPanel.add(ê());
    localJPanel.add(Box.createHorizontalStrut(30));
    localJPanel.add(Box.createHorizontalGlue());
    return localJPanel;
  }

  public void I(boolean paramBoolean)
  {
    if (this.Ĭ == -1)
    {
      B(true);
      if (paramBoolean)
        I().N(í().D());
    }
    else
    {
      if (paramBoolean)
      {
        if (!í().C())
          return;
        if (í().D() >= 0.0D)
          I().ʋ().Z(this.Ĭ).E(í().D());
        else
          return;
      }
      B(true);
      I().ʡ();
    }
  }

  public void F(double paramDouble)
  {
    í().B(paramDouble);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.P.Y
 * JD-Core Version:    0.6.2
 */