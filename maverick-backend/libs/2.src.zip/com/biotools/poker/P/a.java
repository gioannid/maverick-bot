package com.biotools.poker.P;

import java.awt.Component;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.util.EventObject;
import java.util.Locale;
import javax.swing.ComboBoxEditor;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.CellEditorListener;
import javax.swing.table.TableCellEditor;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.PlainDocument;

public class a extends JTextField
  implements ComboBoxEditor, TableCellEditor
{
  private static Toolkit B = Toolkit.getDefaultToolkit();
  private NumberFormat A = NumberFormat.getNumberInstance(Locale.getDefault());

  public a()
  {
    this(0, 20);
  }

  public a(int paramInt)
  {
    this(paramInt, 20);
  }

  public a(int paramInt1, int paramInt2)
  {
    super(paramInt2);
    this.A.setParseIntegerOnly(false);
    A(paramInt1);
  }

  public double B()
  {
    double d = 0.0D;
    try
    {
      d = Double.parseDouble(getText());
    }
    catch (Exception localException)
    {
      B.beep();
    }
    return d;
  }

  public void A(double paramDouble)
  {
    try
    {
      setText(this.A.format(paramDouble));
    }
    catch (Exception localException)
    {
      setText("0");
    }
  }

  protected Document createDefaultModel()
  {
    return new _B();
  }

  public boolean C()
  {
    String str = getText();
    char[] arrayOfChar = str.toCharArray();
    for (int i = 0; i < arrayOfChar.length; i++)
      if (arrayOfChar[i] == '.')
        return true;
    return false;
  }

  public int A()
  {
    String str = getText();
    int i = 0;
    int j = 0;
    char[] arrayOfChar = str.toCharArray();
    for (int k = 0; k < arrayOfChar.length; k++)
    {
      if ((i != 0) && (Character.isDigit(arrayOfChar[k])))
        j++;
      if (arrayOfChar[k] == '.')
        i = 1;
    }
    return j;
  }

  public Component getEditorComponent()
  {
    return this;
  }

  public void setItem(Object paramObject)
  {
    A(Double.parseDouble(paramObject.toString()));
  }

  public Object getItem()
  {
    return B();
  }

  public void addActionListener(ActionListener paramActionListener)
  {
    super.addActionListener(paramActionListener);
  }

  public void removeActionListener(ActionListener paramActionListener)
  {
    super.removeActionListener(paramActionListener);
  }

  public Component getTableCellEditorComponent(JTable paramJTable, Object paramObject, boolean paramBoolean, int paramInt1, int paramInt2)
  {
    return this;
  }

  public void addCellEditorListener(CellEditorListener paramCellEditorListener)
  {
  }

  public void cancelCellEditing()
  {
  }

  public Object getCellEditorValue()
  {
    return new Double(B());
  }

  public boolean isCellEditable(EventObject paramEventObject)
  {
    return true;
  }

  public void removeCellEditorListener(CellEditorListener paramCellEditorListener)
  {
  }

  public boolean shouldSelectCell(EventObject paramEventObject)
  {
    return true;
  }

  public boolean stopCellEditing()
  {
    return false;
  }

  protected class _B extends PlainDocument
  {
    int B = 0;
    boolean C = false;
    int A = 0;

    protected _B()
    {
    }

    public void insertString(int paramInt, String paramString, AttributeSet paramAttributeSet)
      throws BadLocationException
    {
      this.C = a.this.C();
      this.A = a.this.A();
      char[] arrayOfChar1 = paramString.toCharArray();
      char[] arrayOfChar2 = new char[arrayOfChar1.length];
      int i = 0;
      for (int j = 0; j < arrayOfChar2.length; j++)
        if (Character.isDigit(arrayOfChar1[j]))
        {
          if (!this.C)
          {
            arrayOfChar2[(i++)] = arrayOfChar1[j];
          }
          else if ((this.C) && (this.A < 2))
          {
            arrayOfChar2[(i++)] = arrayOfChar1[j];
            this.A += 1;
          }
          else
          {
            a.B.beep();
          }
        }
        else if (arrayOfChar1[j] == '.')
        {
          if (!this.C)
          {
            arrayOfChar2[(i++)] = arrayOfChar1[j];
            this.C = true;
          }
          else
          {
            a.B.beep();
          }
        }
        else if ((arrayOfChar1[j] != ',') && (arrayOfChar1[j] != '$'))
          a.B.beep();
      super.insertString(paramInt, new String(arrayOfChar2, 0, i), paramAttributeSet);
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.P.a
 * JD-Core Version:    0.6.2
 */