package com.biotools.poker.P;

import com.biotools.poker.PokerApp;

public abstract class V extends Q
{
  U B;

  public void B(U paramU)
  {
    A(paramU);
    D();
  }

  public void K()
  {
    requestFocus();
    requestFocusInWindow();
  }

  public boolean C(boolean paramBoolean)
  {
    return false;
  }

  public void B(boolean paramBoolean)
  {
    this.B.A(this, paramBoolean);
  }

  public boolean J()
  {
    return false;
  }

  public U H()
  {
    return this.B;
  }

  public PokerApp I()
  {
    return this.B.A();
  }

  public void A(U paramU)
  {
    this.B = paramU;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.P.V
 * JD-Core Version:    0.6.2
 */