package com.biotools.poker.P;

import B.A.A.B;
import com.biotools.B.A;
import com.biotools.meerkat.util.Preferences;
import com.biotools.poker.E;
import java.awt.Component;
import java.awt.GridLayout;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class O extends V
{
  public static final String Ć = "ASK_ALWAYS";
  public static final String ą = "ASK_IF_SMALL";
  public static final String Ą = "ALWAYS_SMALL";
  public static final String þ = "ALWAYS_BIG";
  JRadioButton ÿ = new JRadioButton(E.D("WindowOptions.AskIfSmall"));
  JRadioButton ă = new JRadioButton(E.D("WindowOptions.AskAlways"));
  JRadioButton ý = new JRadioButton(E.D("WindowOptions.AlwaysSmall"));
  JRadioButton Ă = new JRadioButton(E.D("WindowOptions.AlwaysBig"));
  JComboBox ā;
  private HashMap Ā;

  public JLabel F()
  {
    return new JLabel(E.D("WindowOptions.WindowOptionsHeading"), 0);
  }

  public JPanel A()
  {
    Ö();
    JButton localJButton1 = new JButton(E.D("WindowOptions.OKButton"));
    JButton localJButton2 = new JButton(E.D("WindowOptions.CancelButton"));
    localJButton1.addActionListener(new O.1(this));
    localJButton2.addActionListener(new O.2(this));
    JPanel localJPanel1 = new JPanel();
    localJPanel1.setLayout(new B());
    localJPanel1.add("left", new JLabel(E.D("WindowOptions.WindowColourSchemeTitle")));
    this.ā = new JComboBox();
    this.ā.setEditable(false);
    String str1 = E.¤() ? E.D("WindowOptions.LightGrey") : E.D("WindowOptions.DarkRed");
    String str2 = E.£().get("COLOR_SCHEME", str1);
    List localList = A.A();
    for (int i = 0; i < localList.size(); i++)
    {
      localObject1 = (String)localList.get(i);
      localObject2 = M((String)localObject1);
      this.ā.addItem(localObject2);
      if (((String)localObject1).equals(str2))
        this.ā.setSelectedItem(localObject2);
    }
    localJPanel1.add(this.ā);
    JLabel localJLabel1 = new JLabel(E.D("WindowOptions.NoteAppliedOnRestart"));
    Object localObject1 = new JLabel("");
    Object localObject2 = new JLabel(E.D("WindowOptions.CompactWindowLabel1"));
    JLabel localJLabel2 = new JLabel(E.D("WindowOptions.CompactWindowLabel2"));
    JLabel localJLabel3 = new JLabel(E.D("WindowOptions.CompactWindowLabel3"));
    JPanel localJPanel2 = new JPanel(new GridLayout(0, 1, 2, 2));
    localJPanel2.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
    localJPanel2.add(localJLabel1);
    localJPanel2.add((Component)localObject1);
    localJPanel2.add((Component)localObject2);
    localJPanel2.add(localJLabel2);
    localJPanel2.add(localJLabel3);
    JPanel localJPanel3 = new JPanel();
    localJPanel3.setLayout(new BoxLayout(localJPanel3, 0));
    localJPanel3.setBorder(BorderFactory.createEmptyBorder(15, 3, 3, 3));
    localJPanel3.add(Box.createHorizontalGlue());
    localJPanel3.add(localJButton1);
    localJPanel3.add(Box.createHorizontalStrut(10));
    localJPanel3.add(localJButton2);
    localJPanel3.add(Box.createHorizontalGlue());
    ButtonGroup localButtonGroup = new ButtonGroup();
    localButtonGroup.add(this.ÿ);
    localButtonGroup.add(this.ă);
    localButtonGroup.add(this.ý);
    localButtonGroup.add(this.Ă);
    JPanel localJPanel4 = new JPanel();
    localJPanel4.setLayout(new GridLayout(0, 1, 5, 5));
    localJPanel4.setBorder(BorderFactory.createEmptyBorder(0, 40, 0, 40));
    localJPanel4.add(this.ÿ);
    localJPanel4.add(this.ă);
    localJPanel4.add(this.ý);
    localJPanel4.add(this.Ă);
    Z localZ = new Z();
    localZ.setLayout(new BoxLayout(localZ, 1));
    localZ.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
    localZ.add(localJPanel2);
    localZ.add(localJPanel4);
    localZ.add(Box.createVerticalStrut(15));
    localZ.add(localJPanel1);
    localZ.add(Box.createVerticalStrut(5));
    localZ.add(localJPanel3);
    localZ.setMaximumSize(localZ.getMinimumSize());
    return localZ;
  }

  private HashMap Ù()
  {
    if (this.Ā == null)
      this.Ā = new HashMap();
    return this.Ā;
  }

  private String M(String paramString)
  {
    if (Ù().containsKey(paramString))
      return (String)Ù().get(paramString);
    String str = E.D("WindowOptions." + paramString.replaceAll(" ", ""));
    Ù().put(paramString, str);
    return str;
  }

  private String L(String paramString)
  {
    if (!Ù().containsValue(paramString))
      return paramString;
    Iterator localIterator = Ù().keySet().iterator();
    while (localIterator.hasNext())
    {
      String str1 = (String)localIterator.next();
      String str2 = (String)Ù().get(str1);
      if (str2.compareTo(paramString) == 0)
        return str1;
    }
    return "";
  }

  public void Ø()
  {
    String str = "ASK_IF_SMALL";
    if (this.ÿ.isSelected())
      str = "ASK_IF_SMALL";
    if (this.ă.isSelected())
      str = "ASK_ALWAYS";
    if (this.Ă.isSelected())
      str = "ALWAYS_BIG";
    if (this.ý.isSelected())
      str = "ALWAYS_SMALL";
    E.£().put("WINDOW_SIZE", str);
    E.£().put("COLOR_SCHEME", L((String)this.ā.getSelectedItem()));
  }

  private void Ö()
  {
    String str = E.£().get("WINDOW_SIZE", "ASK_IF_SMALL");
    if (str.equals("ASK_IF_SMALL"))
      this.ÿ.setSelected(true);
    if (str.equals("ASK_ALWAYS"))
      this.ă.setSelected(true);
    if (str.equals("ALWAYS_BIG"))
      this.Ă.setSelected(true);
    if (str.equals("ALWAYS_SMALL"))
      this.ý.setSelected(true);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.P.O
 * JD-Core Version:    0.6.2
 */