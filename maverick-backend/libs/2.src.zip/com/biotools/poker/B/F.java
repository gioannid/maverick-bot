package com.biotools.poker.B;

import com.biotools.poker.E;
import com.biotools.poker.E.I;
import java.io.FileDescriptor;
import java.net.InetAddress;
import java.security.Permission;

public class F extends SecurityManager
{
  public static void A()
  {
    Class localClass = I.class;
    System.setSecurityManager(new F());
  }

  public void checkAccept(String paramString, int paramInt)
  {
  }

  public void checkAccess(Thread paramThread)
  {
  }

  public void checkAccess(ThreadGroup paramThreadGroup)
  {
  }

  public void checkAwtEventQueueAccess()
  {
  }

  public void checkConnect(String paramString, int paramInt, Object paramObject)
  {
  }

  public void checkConnect(String paramString, int paramInt)
  {
  }

  public void checkCreateClassLoader()
  {
  }

  public void checkDelete(String paramString)
  {
  }

  public void checkExec(String paramString)
  {
  }

  public void checkExit(int paramInt)
  {
  }

  public void checkLink(String paramString)
  {
  }

  public void checkListen(int paramInt)
  {
  }

  public void checkMemberAccess(Class paramClass, int paramInt)
  {
  }

  public void checkMulticast(InetAddress paramInetAddress)
  {
  }

  public void checkPackageDefinition(String paramString)
  {
  }

  public void checkPermission(Permission paramPermission, Object paramObject)
  {
  }

  public void checkPermission(Permission paramPermission)
  {
  }

  public void checkPrintJobAccess()
  {
  }

  public void checkPropertiesAccess()
  {
  }

  public void checkPropertyAccess(String paramString)
  {
  }

  public void checkRead(FileDescriptor paramFileDescriptor)
  {
  }

  public void checkRead(String paramString, Object paramObject)
  {
  }

  public void checkRead(String paramString)
  {
  }

  public void checkSecurityAccess(String paramString)
  {
  }

  public void checkSetFactory()
  {
  }

  public void checkSystemClipboardAccess()
  {
  }

  public void checkWrite(FileDescriptor paramFileDescriptor)
  {
  }

  public void checkWrite(String paramString)
  {
  }

  public void checkPackageAccess(String paramString)
  {
    int i = 0;
    if ((paramString.startsWith("com.biotools")) && (!paramString.startsWith("com.biotools.meerkat")))
      i = 1;
    if (paramString.startsWith("com.vastmind"))
      i = 1;
    if (paramString.startsWith("ca.spaz"))
      i = 1;
    if (i == 0)
      return;
    Class[] arrayOfClass = getClassContext();
    for (int j = 0; j < arrayOfClass.length; j++)
      if ((arrayOfClass[j].getClassLoader() != null) && ((arrayOfClass[j].getClassLoader() instanceof I)))
      {
        Object[] arrayOfObject = { paramString };
        throw new SecurityException(E.A("MeerkatSecurityManager.AccessDeniedPattern", arrayOfObject));
      }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.B.F
 * JD-Core Version:    0.6.2
 */