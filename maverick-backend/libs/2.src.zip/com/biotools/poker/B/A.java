/*    */ package com.biotools.poker.B;
/*    */ 
/*    */ public final class A
/*    */ {
/*    */   public boolean D(String paramString)
/*    */   {
/* 16 */     return true;
/*    */   }
/*    */ 
/*    */   public static String B()
/*    */   {
/* 21 */     return "";
/*    */   }
/*    */ 
/*    */   public void B(String paramString)
/*    */   {
/*    */   }
/*    */ 
/*    */   public boolean A()
/*    */   {
/* 30 */     return true;
/*    */   }
/*    */ 
/*    */   public static String F()
/*    */   {
/* 35 */     return "";
/*    */   }
/*    */ 
/*    */   public static boolean C()
/*    */   {
/* 40 */     return true;
/*    */   }
/*    */ 
/*    */   public static String D()
/*    */   {
/* 45 */     return "";
/*    */   }
/*    */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.poker.B.A
 * JD-Core Version:    0.6.2
 */