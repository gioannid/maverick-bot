package com.biotools.A;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class H extends ClassLoader
{
  private File A;

  public H()
  {
  }

  public H(File paramFile)
  {
    this.A = paramFile;
  }

  protected Class loadClass(String paramString, boolean paramBoolean)
    throws ClassNotFoundException
  {
    Class localClass = findLoadedClass(paramString);
    if (localClass == null)
      try
      {
        localClass = findSystemClass(paramString);
      }
      catch (Exception localException)
      {
      }
    if (localClass == null)
      try
      {
        InputStream localInputStream = getResourceAsStream(paramString);
        if (localInputStream != null)
        {
          ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
          for (int i = localInputStream.read(); i >= 0; i = localInputStream.read())
            localByteArrayOutputStream.write((byte)i);
          byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
          if (arrayOfByte != null)
            localClass = defineClass(paramString, arrayOfByte, 0, arrayOfByte.length);
        }
        if (localClass == null)
          throw new ClassNotFoundException(paramString);
      }
      catch (IOException localIOException)
      {
        throw new ClassNotFoundException("Error reading class: " + paramString);
      }
    if (paramBoolean)
      resolveClass(localClass);
    return localClass;
  }

  public InputStream getResourceAsStream(String paramString)
  {
    URL localURL = getResource(paramString);
    try
    {
      if (localURL != null)
        return localURL.openStream();
      paramString = paramString.replaceAll("/", "\\.");
      File localFile = new File(this.A, paramString);
      if (localFile.exists())
        return new FileInputStream(localFile);
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
    return null;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.H
 * JD-Core Version:    0.6.2
 */