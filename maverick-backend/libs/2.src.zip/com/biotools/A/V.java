package com.biotools.A;

public class V extends Y
{
  String H;

  static
  {
    System.loadLibrary("soundLib");
  }

  private native void playSound(String paramString);

  public V(String paramString)
  {
    super(paramString);
  }

  public void A()
  {
    playSound(this.H);
  }

  public boolean B()
  {
    return true;
  }

  public void A(String paramString)
  {
    this.H = paramString;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.V
 * JD-Core Version:    0.6.2
 */