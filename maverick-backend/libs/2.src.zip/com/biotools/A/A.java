package com.biotools.A;

import com.biotools.poker.E;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Date;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine.Info;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.UnsupportedAudioFileException;

public class A extends Y
{
  protected static final int Y = 8192;
  SourceDataLine T;
  static SourceDataLine W;
  static SourceDataLine S;
  static AudioFormat X;
  byte[] V;
  Date U;

  public A(String paramString)
  {
    super(paramString);
    if (W == null)
      C(paramString);
    B(paramString);
    System.out.println("Init and playing clip: " + paramString);
  }

  private void C(String paramString)
  {
    try
    {
      AudioInputStream localAudioInputStream = AudioSystem.getAudioInputStream(new ByteArrayInputStream(this.V));
      ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(this.V);
      X = localAudioInputStream.getFormat();
      DataLine.Info localInfo = new DataLine.Info(SourceDataLine.class, localAudioInputStream.getFormat(), (int)localAudioInputStream.getFrameLength() * X.getFrameSize());
      W = (SourceDataLine)AudioSystem.getLine(localInfo);
      W.open(localAudioInputStream.getFormat());
      S = (SourceDataLine)AudioSystem.getLine(localInfo);
      S.open(localAudioInputStream.getFormat());
      localAudioInputStream.close();
    }
    catch (Exception localException)
    {
      throw new Error("AudioError", localException);
    }
  }

  public void A()
  {
    E.H("BBB new sound class");
    this.U = new Date();
    A.1 local1 = new A.1(this, "streamChipPlayer playSound thread");
    local1.start();
  }

  public void D()
  {
    try
    {
      AudioInputStream localAudioInputStream = AudioSystem.getAudioInputStream(new ByteArrayInputStream(this.V));
      Date localDate = new Date();
      System.out.println("thread time (1): " + (localDate.getTime() - this.U.getTime()));
      if (this.T == null)
      {
        System.out.println("never");
        System.exit(-1);
      }
      this.T.start();
      localDate = new Date();
      System.out.println("thread time (3): " + (localDate.getTime() - this.U.getTime()));
      int i = 0;
      byte[] arrayOfByte = new byte[this.T.getBufferSize()];
      while ((i = localAudioInputStream.read(arrayOfByte, 0, arrayOfByte.length)) >= 0)
      {
        int j = 0;
        while (j < i)
          j += this.T.write(arrayOfByte, j, i - j);
      }
      float f = X.getSampleRate();
      if (f == -1.0F)
        f = 11025.0F;
      int k = X.getSampleSizeInBits();
      if (k == -1)
        k = 16;
      int m = (int)Math.ceil(65536000.0F / (f * k));
      m += 500;
      try
      {
        Thread.sleep(m);
      }
      catch (InterruptedException localInterruptedException)
      {
      }
      this.T.flush();
      localDate = new Date();
      System.out.println("thread time (4): " + (localDate.getTime() - this.U.getTime()));
    }
    catch (UnsupportedAudioFileException localUnsupportedAudioFileException)
    {
      I.A("", localUnsupportedAudioFileException);
    }
    catch (IOException localIOException)
    {
      I.A("", localIOException);
    }
  }

  public boolean B()
  {
    return true;
  }

  public void A(String paramString)
  {
    FileInputStream localFileInputStream = null;
    File localFile = new File(paramString);
    this.V = new byte[(int)localFile.length()];
    try
    {
      localFileInputStream = new FileInputStream(localFile);
      localFileInputStream.read(this.V);
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      I.A("", localFileNotFoundException);
    }
    catch (IOException localIOException)
    {
      I.A("", localIOException);
    }
  }

  private void B(String paramString)
  {
    String[] arrayOfString = { "aggression", "bigHand", "rollout" };
    for (int i = 0; i < arrayOfString.length; i++)
    {
      String str = arrayOfString[i];
      int j = paramString.length() - 5 - str.length();
      System.out.println(paramString.substring(j, paramString.length() - 5));
      if (paramString.substring(j, paramString.length() - 5).equals(str))
      {
        this.T = S;
        System.out.println("long");
        return;
      }
    }
    this.T = W;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.A
 * JD-Core Version:    0.6.2
 */