package com.biotools.A;

class F$_A extends F._B
{
  final F this$0;

  private F$_A(F paramF)
  {
    super(paramF, null);
  }

  final long A()
  {
    return System.currentTimeMillis() * 1000L;
  }

  F$_A(F paramF, _A param_A)
  {
    this(paramF);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.F._A
 * JD-Core Version:    0.6.2
 */