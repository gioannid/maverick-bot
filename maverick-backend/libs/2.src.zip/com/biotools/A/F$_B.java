package com.biotools.A;

abstract class F$_B
{
  final F this$0;

  private F$_B(F paramF)
  {
  }

  void B()
  {
  }

  abstract long A();

  F$_B(F paramF, _B param_B)
  {
    this(paramF);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.F._B
 * JD-Core Version:    0.6.2
 */