package com.biotools.A;

import sun.misc.Perf;

class F$_D extends F._B
{
  final Perf A = Perf.getPerf();
  final long C;
  final long B;
  final F this$0;

  private F$_D(F paramF)
  {
    super(paramF, null);
    long l1 = 1000000L;
    long l2 = this.A.highResFrequency();
    long l3 = A(l1, l2);
    this.C = (l1 / l3);
    this.B = (l2 / l3);
  }

  public long A()
  {
    long l = this.A.highResCounter();
    return l / this.B * this.C + l % this.B * this.C / this.B;
  }

  private long A(long paramLong1, long paramLong2)
  {
    while (paramLong2 > 0L)
    {
      long l = paramLong1 % paramLong2;
      paramLong1 = paramLong2;
      paramLong2 = l;
    }
    return paramLong1;
  }

  F$_D(F paramF, _D param_D)
  {
    this(paramF);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.F._D
 * JD-Core Version:    0.6.2
 */