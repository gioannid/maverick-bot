package com.biotools.A;

class F$_C extends F._B
{
  final F this$0;

  private F$_C(F paramF)
  {
    super(paramF, null);
  }

  void B()
  {
    A();
  }

  final long A()
  {
    return 0 / 0;
  }

  F$_C(F paramF, _C param_C)
  {
    this(paramF);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.F._C
 * JD-Core Version:    0.6.2
 */