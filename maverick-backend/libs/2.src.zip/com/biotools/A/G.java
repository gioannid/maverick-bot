package com.biotools.A;

import com.biotools.poker.E;
import java.io.ByteArrayOutputStream;
import java.io.File;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFileFormat.Type;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine.Info;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;

public class G extends Y
  implements LineListener
{
  private static final int C = 8;
  private static Clip[] A = new Clip[8];
  private static G[] B = new G[8];
  private static int D = 0;
  AudioFormat F;
  byte[] E;

  private static synchronized Clip A(G paramG)
  {
    for (int i = 0; i < 8; i++)
      if (B[i] == paramG)
        return A[i];
    D = (D + 1) % 8;
    B[D] = paramG;
    long l;
    if (A[D] != null)
    {
      if (A[D].isOpen())
      {
        l = System.currentTimeMillis();
        A[D].close();
        E.H("Closing Line: " + (System.currentTimeMillis() - l));
      }
    }
    else
      try
      {
        l = System.currentTimeMillis();
        DataLine.Info localInfo = new DataLine.Info(Clip.class, paramG.F);
        A[D] = ((Clip)AudioSystem.getLine(localInfo));
        E.H("Creating Line: " + (System.currentTimeMillis() - l));
        A[D].addLineListener(new G.1());
      }
      catch (Exception localException)
      {
        I.A("", localException);
      }
    return A[D];
  }

  public G(String paramString)
  {
    super(paramString);
  }

  public void A(String paramString)
  {
    try
    {
      File localFile = new File(paramString);
      AudioFileFormat localAudioFileFormat = AudioSystem.getAudioFileFormat(localFile);
      AudioFileFormat.Type localType = localAudioFileFormat.getType();
      AudioFormat localAudioFormat = localAudioFileFormat.getFormat();
      AudioInputStream localAudioInputStream = AudioSystem.getAudioInputStream(localFile);
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      int i = 1024 * localAudioFormat.getFrameSize();
      byte[] arrayOfByte = new byte[i];
      while (true)
      {
        int j = localAudioInputStream.read(arrayOfByte);
        if (j == -1)
          break;
        localByteArrayOutputStream.write(arrayOfByte, 0, j);
      }
      this.E = localByteArrayOutputStream.toByteArray();
      this.F = localAudioFormat;
    }
    catch (Exception localException)
    {
      I.A("", localException);
    }
  }

  public boolean B()
  {
    return this.E != null;
  }

  public void A()
  {
    try
    {
      Clip localClip = A(this);
      if (localClip == null)
        return;
      if (localClip.isRunning())
        localClip.stop();
      if (!localClip.isOpen())
      {
        long l = System.currentTimeMillis();
        localClip.open(this.F, this.E, 0, this.E.length);
        E.H("Opening Clip: " + (System.currentTimeMillis() - l));
      }
      localClip.setFramePosition(0);
      localClip.start();
    }
    catch (Exception localException)
    {
      I.A("", localException);
    }
  }

  public void update(LineEvent paramLineEvent)
  {
    E.H(paramLineEvent.toString());
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.G
 * JD-Core Version:    0.6.2
 */