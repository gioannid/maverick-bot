package com.biotools.A;

import java.util.LinkedList;

public class L
{
  private LinkedList A = new LinkedList();

  public synchronized void A(Object paramObject)
  {
    this.A.add(paramObject);
    notifyAll();
  }

  public synchronized Object C()
    throws InterruptedException
  {
    while (this.A.size() == 0)
      wait();
    return this.A.removeFirst();
  }

  public synchronized int B()
  {
    return this.A.size();
  }

  public synchronized void A()
  {
    this.A.clear();
  }

  public synchronized boolean B(Object paramObject)
  {
    return this.A.contains(paramObject);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.L
 * JD-Core Version:    0.6.2
 */