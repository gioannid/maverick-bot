package com.biotools.A;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class U
  implements Map
{
  private _A[] C;
  private int B;
  private int A;
  private float D;

  public U(int paramInt, float paramFloat)
  {
    if ((paramInt <= 0) || (paramFloat <= 0.0D))
      throw new IllegalArgumentException();
    this.D = paramFloat;
    this.C = new _A[paramInt];
    this.A = ((int)(paramInt * paramFloat));
  }

  public U(int paramInt)
  {
    this(paramInt, 0.75F);
  }

  public U()
  {
    this(101, 0.75F);
  }

  protected void A()
  {
    int i = this.C.length;
    _A[] arrayOf_A1 = this.C;
    int j = i * 2 + 1;
    _A[] arrayOf_A2 = new _A[j];
    this.A = ((int)(j * this.D));
    this.C = arrayOf_A2;
    int k = i;
    while (k-- > 0)
    {
      _A local_A1 = arrayOf_A1[k];
      while (local_A1 != null)
      {
        _A local_A2 = local_A1;
        int m = (local_A2.D & 0x7FFFFFFF) % j;
        local_A1 = local_A1.B;
        local_A2.B = arrayOf_A2[m];
        arrayOf_A2[m] = local_A2;
      }
    }
  }

  public final boolean A(int paramInt)
  {
    int i = (paramInt & 0x7FFFFFFF) % this.C.length;
    for (_A local_A = this.C[i]; local_A != null; local_A = local_A.B)
      if ((local_A.D == paramInt) && (local_A.A == paramInt))
        return true;
    return false;
  }

  public final Object C(int paramInt)
  {
    int i = (paramInt & 0x7FFFFFFF) % this.C.length;
    for (_A local_A = this.C[i]; local_A != null; local_A = local_A.B)
      if ((local_A.D == paramInt) && (local_A.A == paramInt))
        return local_A.C;
    return null;
  }

  public final Object A(int paramInt, Object paramObject)
  {
    int i = (paramInt & 0x7FFFFFFF) % this.C.length;
    if (paramObject == null)
      throw new IllegalArgumentException();
    for (_A local_A = this.C[i]; local_A != null; local_A = local_A.B)
      if ((local_A.D == paramInt) && (local_A.A == paramInt))
      {
        Object localObject = local_A.C;
        local_A.C = paramObject;
        return localObject;
      }
    if (this.B >= this.A)
    {
      A();
      return A(paramInt, paramObject);
    }
    local_A = new _A();
    local_A.D = paramInt;
    local_A.A = paramInt;
    local_A.C = paramObject;
    local_A.B = this.C[i];
    this.C[i] = local_A;
    this.B += 1;
    return null;
  }

  public final Object B(int paramInt)
  {
    int i = (paramInt & 0x7FFFFFFF) % this.C.length;
    _A local_A1 = this.C[i];
    _A local_A2 = null;
    while (local_A1 != null)
    {
      if ((local_A1.D == paramInt) && (local_A1.A == paramInt))
      {
        if (local_A2 != null)
          local_A2.B = local_A1.B;
        else
          this.C[i] = local_A1.B;
        this.B -= 1;
        return local_A1.C;
      }
      local_A2 = local_A1;
      local_A1 = local_A1.B;
    }
    return null;
  }

  public int size()
  {
    return this.B;
  }

  public boolean isEmpty()
  {
    return this.B == 0;
  }

  public Object get(Object paramObject)
  {
    if (!(paramObject instanceof Number))
      throw new IllegalArgumentException("key is not an Number subclass");
    return C(((Number)paramObject).intValue());
  }

  public Object put(Object paramObject1, Object paramObject2)
  {
    if (!(paramObject1 instanceof Number))
      throw new IllegalArgumentException("key cannot be null");
    return A(((Number)paramObject1).intValue(), paramObject2);
  }

  public void putAll(Map paramMap)
  {
    Iterator localIterator = paramMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      Object localObject = localIterator.next();
      put(localObject, paramMap.get(localObject));
    }
  }

  public Object remove(Object paramObject)
  {
    if (!(paramObject instanceof Number))
      throw new IllegalArgumentException("key cannot be null");
    return B(((Number)paramObject).intValue());
  }

  public void clear()
  {
    _A[] arrayOf_A = this.C;
    int i = arrayOf_A.length;
    do
    {
      arrayOf_A[i] = null;
      i--;
    }
    while (i >= 0);
    this.B = 0;
  }

  public boolean containsKey(Object paramObject)
  {
    if (!(paramObject instanceof Number))
      throw new InternalError("key is not an Number subclass");
    return A(((Number)paramObject).intValue());
  }

  public boolean containsValue(Object paramObject)
  {
    _A[] arrayOf_A = this.C;
    if (paramObject == null)
      throw new IllegalArgumentException();
    int i = arrayOf_A.length;
    while (i-- > 0)
      for (_A local_A = arrayOf_A[i]; local_A != null; local_A = local_A.B)
        if (local_A.C.equals(paramObject))
          return true;
    return false;
  }

  public _A A(Object paramObject)
  {
    _A[] arrayOf_A = this.C;
    if (paramObject == null)
      throw new IllegalArgumentException();
    int i = arrayOf_A.length;
    while (i-- > 0)
      for (_A local_A = arrayOf_A[i]; local_A != null; local_A = local_A.B)
        if (local_A.C.equals(paramObject))
          return local_A;
    return null;
  }

  public Set keySet()
  {
    HashSet localHashSet = new HashSet();
    U._B local_B = new U._B(this.C, true);
    while (local_B.hasNext())
      localHashSet.add(local_B.next());
    return localHashSet;
  }

  public Collection values()
  {
    ArrayList localArrayList = new ArrayList();
    U._B local_B = new U._B(this.C, false);
    while (local_B.hasNext())
      localArrayList.add(local_B.next());
    return localArrayList;
  }

  public Iterator B()
  {
    return new U._B(this.C, false);
  }

  public Iterator C()
  {
    return new U._B(this.C, true);
  }

  public Set entrySet()
  {
    throw new UnsupportedOperationException("entrySet");
  }

  public static class _A
  {
    int D;
    int A;
    Object C;
    _A B;

    public int A()
    {
      return this.A;
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.U
 * JD-Core Version:    0.6.2
 */