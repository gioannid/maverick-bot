package com.biotools.A;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class d
{
  public static final int P = 0;
  public static final int J = 1;
  public static final int S = 2;
  public static final int L = 3;
  private static final int E = 6000000;
  private static final int G = 10;
  private static final int B = 1000;
  private static int K = 3;
  private static String Q = null;
  private static String D = null;
  private static String M = null;
  private static d H = null;
  private static String N = null;
  private static boolean C = false;
  PrintWriter O = null;
  PrintWriter A = null;
  String R = null;
  String F = null;
  int I = 0;

  public static int F()
  {
    int i = -1;
    String str1 = "./bin/get_parent_pid";
    try
    {
      Process localProcess = Runtime.getRuntime().exec(str1);
      BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(localProcess.getInputStream()));
      String str2 = null;
      str2 = localBufferedReader.readLine();
      if (str2 != null)
        i = Integer.parseInt(str2);
    }
    catch (Exception localException)
    {
    }
    return i;
  }

  public static void D(String paramString)
  {
    N = paramString;
    String str1 = N + "log.log";
    String str2 = null;
    Q = N + "games.log";
    new File(N).mkdirs();
    if ((K == 1) || (K == 2))
    {
      String str3 = N + ".pid";
      B(F(), str3);
      str2 = N + "chat.log";
      if (!C)
      {
        D = N + "stdout.txt";
        M = N + "stderr.txt";
      }
    }
    H = new d(str1, str2);
  }

  public static String B()
  {
    return N;
  }

  public static void G()
  {
    if (D == null)
      return;
    try
    {
      System.setOut(new PrintStream(new FileOutputStream(D)));
      System.setErr(new PrintStream(new FileOutputStream(M)));
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  public static String E()
  {
    return Q;
  }

  private static void B(int paramInt, String paramString)
  {
    PrintWriter localPrintWriter = null;
    try
    {
      localPrintWriter = new PrintWriter(new BufferedOutputStream(new FileOutputStream(paramString)));
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      System.err.println("ERROR: can't write pid to: " + paramString);
      localFileNotFoundException.printStackTrace();
    }
    if (localPrintWriter != null)
    {
      localPrintWriter.println(paramInt);
      localPrintWriter.close();
    }
  }

  public static void C(String paramString)
  {
    if (K == 0)
      return;
    if (K == 3)
      System.out.println(paramString);
    if (H != null)
      H.B("DBG", paramString);
  }

  public static void F(String paramString)
  {
    if (K == 0)
      return;
    if (K == 3)
      System.out.print(paramString);
    if (H != null)
      H.B("DBG", paramString);
  }

  public static void B(String paramString)
  {
    if (K == 0)
      return;
    if (K == 3)
      System.out.print(paramString);
    if (H != null)
      H.B("OK  TRAN", paramString);
  }

  public static void E(String paramString)
  {
    if (K == 0)
      return;
    if (K == 3)
      System.out.println(paramString);
    if (H != null)
      H.B("OK  INFO", paramString);
  }

  public static void C(String paramString1, String paramString2)
  {
    if (H != null)
      H.A(paramString1, paramString2);
  }

  public static void A(String paramString)
  {
    if (K == 3)
      System.out.println("ERR " + paramString);
    if (H != null)
      H.B("ERR", paramString);
  }

  public static void A(Throwable paramThrowable)
  {
    if (K == 3)
      paramThrowable.printStackTrace();
    if (H != null)
      H.B("STACK", B(paramThrowable));
  }

  public static void A(String paramString, Throwable paramThrowable)
  {
    A(paramString);
    A(paramThrowable);
  }

  public static String B(Throwable paramThrowable)
  {
    StringWriter localStringWriter = new StringWriter();
    PrintWriter localPrintWriter = new PrintWriter(localStringWriter, true);
    paramThrowable.printStackTrace(localPrintWriter);
    localPrintWriter.flush();
    localStringWriter.flush();
    return localStringWriter.toString();
  }

  public static void A(int paramInt, String paramString)
  {
    if (K == 0)
      return;
    String str = "s" + paramInt + ": " + paramString;
    if (K == 3)
      System.out.println(str);
    if (H != null)
      H.B("s" + paramInt + ":", paramString);
  }

  public static void C(int paramInt, String paramString)
  {
    if (K == 0)
      return;
    String str = "r" + paramInt + ": " + paramString;
    if (K == 3)
      System.out.println(str);
    if (H != null)
      H.B("r" + paramInt + ":", paramString);
  }

  public static String[] D()
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyyMMdd-hhmmss");
    Date localDate = new Date();
    String str1 = localSimpleDateFormat.format(localDate);
    localSimpleDateFormat = new SimpleDateFormat("yyyy-MM");
    String str2 = localSimpleDateFormat.format(localDate);
    String[] arrayOfString = new String[2];
    arrayOfString[0] = str1;
    arrayOfString[1] = str2;
    return arrayOfString;
  }

  public static void A(int paramInt)
  {
    K = paramInt;
  }

  public static int A()
  {
    return K;
  }

  public d(String paramString)
  {
    this.R = paramString;
    A(true);
  }

  public d(String paramString1, String paramString2)
  {
    this(paramString1);
    this.F = paramString2;
  }

  private void C()
  {
    this.O = null;
    try
    {
      this.O = new PrintWriter(new BufferedOutputStream(new FileOutputStream(this.R)));
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      System.err.println("ERROR: can't write to log file: " + this.R + " no logging");
      localFileNotFoundException.printStackTrace();
    }
  }

  private synchronized void B(String paramString1, String paramString2)
  {
    long l = Math.round(F.B() * 1000.0D);
    String str = Thread.currentThread().getName();
    if (C)
      System.out.println(l + " [" + str + "] " + paramString1 + " " + paramString2);
    if (this.O == null)
      return;
    paramString2 = paramString2.replaceAll("\n", "<br>");
    this.O.print(l);
    this.O.print(" [");
    this.O.print(str);
    this.O.print("] ");
    this.O.print(paramString1);
    this.O.print(' ');
    this.O.println(paramString2);
    this.O.flush();
    this.I += 1;
    if (this.I % 1000 == 0)
      A(false);
  }

  private synchronized void A(String paramString1, String paramString2)
  {
    if (this.F == null)
      return;
    if (this.A == null)
      try
      {
        this.A = new PrintWriter(new BufferedOutputStream(new FileOutputStream(this.F, true)));
        this.A.println("-------");
      }
      catch (FileNotFoundException localFileNotFoundException)
      {
        System.err.println("ERROR: can't write to chat file: " + this.F);
        localFileNotFoundException.printStackTrace();
      }
    paramString2 = paramString2.replaceAll("\n", "<br>");
    double d = F.B();
    long l1 = Math.round(Math.floor(d / 3600.0D));
    d -= l1 * 3600L;
    long l2 = Math.round(Math.floor(d / 60.0D));
    d -= l2 * 60L;
    long l3 = Math.round(d);
    this.A.print(l1 + ":" + l2 + ":" + l3);
    this.A.print(" [");
    this.A.print(paramString1);
    this.A.print("] ");
    this.A.println(paramString2);
    this.A.flush();
  }

  private void A(boolean paramBoolean)
  {
    if ((A(this.R, paramBoolean, true)) || (paramBoolean))
    {
      C();
      A(D, true, false);
      A(M, true, false);
      G();
    }
    A(Q, false, false);
  }

  private boolean A(String paramString, boolean paramBoolean1, boolean paramBoolean2)
  {
    if (paramString == null)
      return false;
    if (K == 0)
      return false;
    File localFile1 = new File(paramString);
    if (!localFile1.exists())
      return false;
    long l = localFile1.length();
    if ((l < 6000000L) && (!paramBoolean1))
      return false;
    if ((paramBoolean2) && (this.O != null))
    {
      this.O.close();
      this.O = null;
    }
    File localFile2 = A(localFile1);
    if (localFile2 == null)
      return false;
    localFile1.renameTo(localFile2);
    B(localFile2);
    return true;
  }

  private void B(File paramFile)
  {
    String str = "gzip " + paramFile.getAbsolutePath();
    try
    {
      Runtime.getRuntime().exec(str);
    }
    catch (IOException localIOException)
    {
      System.err.println("gzip " + paramFile.getAbsolutePath() + " failed");
    }
  }

  private File A(File paramFile)
  {
    File localFile = paramFile.getParentFile();
    if (localFile == null)
    {
      System.err.println("ERR: rotate - no parent dir");
      return null;
    }
    String[] arrayOfString1 = localFile.list();
    if (arrayOfString1 == null)
    {
      System.err.println("ERR: rotate - bad file list");
      return null;
    }
    ArrayList localArrayList = new ArrayList();
    int i = 0;
    int j = 0;
    String str1 = null;
    String str2 = paramFile.getName();
    for (int k = 0; k < arrayOfString1.length; k++)
      if (arrayOfString1[k].startsWith(str2))
      {
        String[] arrayOfString2 = arrayOfString1[k].split("\\.");
        if (arrayOfString2.length >= 3)
        {
          localArrayList.add(arrayOfString1[k]);
          int m = Integer.parseInt(arrayOfString2[2]);
          if (localArrayList.size() == 1)
          {
            j = m;
            i = m;
            str1 = arrayOfString1[k];
          }
          else
          {
            i = Math.max(i, m);
            if (m < j)
            {
              j = m;
              str1 = arrayOfString1[k];
            }
          }
        }
      }
    if ((localArrayList.size() > 10) && (!paramFile.equals(new File(Q))))
      new File(localFile, str1).delete();
    i++;
    return new File(localFile, str2 + "." + i);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.d
 * JD-Core Version:    0.6.2
 */