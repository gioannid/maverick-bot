package com.biotools.A;

import java.io.File;
import java.io.PrintStream;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine.Info;

public class f extends Y
{
  private Clip R;

  public f(String paramString)
  {
    super(paramString);
  }

  public void A(String paramString)
  {
    File localFile = new File(paramString);
    this.R = null;
    AudioInputStream localAudioInputStream = null;
    try
    {
      localAudioInputStream = AudioSystem.getAudioInputStream(localFile);
    }
    catch (Exception localException1)
    {
      I.A("", localException1);
    }
    if (localAudioInputStream != null)
    {
      AudioFormat localAudioFormat = localAudioInputStream.getFormat();
      DataLine.Info localInfo = new DataLine.Info(Clip.class, localAudioFormat);
      try
      {
        this.R = ((Clip)AudioSystem.getLine(localInfo));
        this.R.open(localAudioInputStream);
        localAudioInputStream.close();
      }
      catch (Exception localException2)
      {
        I.A("", localException2);
        this.R = null;
      }
    }
    else
    {
      System.out.println("ClipPlayer.<init>(): can't get data from file " + localFile.getName());
    }
  }

  public boolean B()
  {
    return this.R != null;
  }

  public void A()
  {
    this.R.setFramePosition(0);
    this.R.start();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.f
 * JD-Core Version:    0.6.2
 */