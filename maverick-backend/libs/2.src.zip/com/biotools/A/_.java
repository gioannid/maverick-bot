package com.biotools.A;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.Vector;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFileFormat.Type;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine.Info;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineEvent.Type;
import javax.sound.sampled.LineListener;

public class _ extends Y
  implements LineListener
{
  private static final int M = 8;
  private AudioFormat Q;
  private byte[] O;
  private Clip N;
  private String L;
  private static Thread K;
  private static Vector P;

  private static Vector C()
  {
    if (P == null)
    {
      P = new Vector();
      K = new Thread("Sound Clip Closer")
      {
        public void run()
        {
          while (_.P != null)
          {
            while (_.P.size() > 6)
            {
              Clip localClip = (Clip)_.P.remove(0);
              localClip.close();
            }
            try
            {
              synchronized (_.P)
              {
                _.P.wait();
              }
            }
            catch (InterruptedException localInterruptedException)
            {
              localInterruptedException.printStackTrace();
            }
          }
        }
      };
      K.setDaemon(true);
      K.start();
    }
    return P;
  }

  public _(String paramString)
  {
    super(paramString);
    this.L = paramString;
  }

  public void A(String paramString)
  {
    try
    {
      File localFile = new File(paramString);
      AudioFileFormat localAudioFileFormat = AudioSystem.getAudioFileFormat(localFile);
      AudioFileFormat.Type localType = localAudioFileFormat.getType();
      AudioFormat localAudioFormat = localAudioFileFormat.getFormat();
      AudioInputStream localAudioInputStream = AudioSystem.getAudioInputStream(localFile);
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      int i = 1024 * localAudioFormat.getFrameSize();
      byte[] arrayOfByte = new byte[i];
      while (true)
      {
        int j = localAudioInputStream.read(arrayOfByte);
        if (j == -1)
          break;
        localByteArrayOutputStream.write(arrayOfByte, 0, j);
      }
      this.O = localByteArrayOutputStream.toByteArray();
      this.Q = localAudioFormat;
    }
    catch (Exception localException)
    {
      I.A("", localException);
    }
  }

  public boolean B()
  {
    return this.O != null;
  }

  public void A()
  {
    try
    {
      synchronized (C())
      {
        if (C().contains(this.N))
        {
          C().remove(this.N);
        }
        else
        {
          DataLine.Info localInfo = new DataLine.Info(Clip.class, this.Q);
          this.N = ((Clip)AudioSystem.getLine(localInfo));
          this.N.addLineListener(this);
        }
      }
      if (this.N == null)
        return;
      if (this.N.isRunning())
        this.N.stop();
      if (!this.N.isOpen())
      {
        long l = System.currentTimeMillis();
        this.N.open(this.Q, this.O, 0, this.O.length);
      }
      this.N.setFramePosition(0);
      this.N.start();
    }
    catch (Exception localException)
    {
      throw new Error("AudioError", localException);
    }
  }

  public void update(LineEvent paramLineEvent)
  {
    if (paramLineEvent.getType() == LineEvent.Type.STOP)
    {
      C().add(paramLineEvent.getSource());
      synchronized (C())
      {
        C().notifyAll();
      }
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A._
 * JD-Core Version:    0.6.2
 */