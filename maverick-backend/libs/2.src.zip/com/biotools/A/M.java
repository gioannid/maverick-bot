package com.biotools.A;

import java.applet.AudioClip;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URI;
import javax.swing.JApplet;

public class M extends Y
{
  AudioClip G;

  public M(String paramString)
  {
    super(paramString);
  }

  public void A()
  {
    this.G.play();
  }

  public boolean B()
  {
    return this.G != null;
  }

  public void A(String paramString)
  {
    File localFile = new File(paramString);
    try
    {
      this.G = JApplet.newAudioClip(localFile.toURI().toURL());
    }
    catch (MalformedURLException localMalformedURLException)
    {
      I.A("", localMalformedURLException);
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.M
 * JD-Core Version:    0.6.2
 */