package com.biotools.A;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.util.Vector;

public class b
{
  private boolean E = true;
  private Vector F = new Vector();
  private boolean D = true;
  private boolean G;
  private boolean C = false;
  private String A;
  private volatile RandomAccessFile I;
  private static b H = null;
  public int B = 0;

  public static synchronized b D()
  {
    if (H == null)
      H = new b();
    return H;
  }

  public b()
  {
  }

  public b(String paramString)
  {
    I(paramString);
  }

  public synchronized void I(String paramString)
  {
    this.G = (paramString != null);
    this.A = paramString;
    try
    {
      if (this.I != null)
        this.I.close();
      if (this.G)
      {
        this.I = new RandomAccessFile(paramString, "rw");
        this.I.seek(this.I.length());
      }
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }

  public void B(boolean paramBoolean)
  {
    this.C = paramBoolean;
  }

  public void A(boolean paramBoolean)
  {
    this.D = paramBoolean;
  }

  public void B(String paramString)
  {
    if (this.C)
      K(paramString);
  }

  public void H(String paramString)
  {
    if (this.C)
      G(paramString);
  }

  public void A(X paramX)
  {
    this.F.addElement(paramX);
  }

  public void B(X paramX)
  {
    this.F.removeElement(paramX);
  }

  private void N(String paramString)
  {
    for (int i = 0; i < this.F.size(); i++)
      ((X)this.F.elementAt(i)).A(paramString);
  }

  public void E()
  {
    this.E = false;
  }

  public void B()
  {
    this.E = true;
  }

  public synchronized void M(String paramString)
  {
    K(paramString);
  }

  public synchronized void D(String paramString)
  {
    G(paramString);
  }

  public synchronized void K(String paramString)
  {
    if (this.D)
    {
      if (this.E)
        System.err.println(paramString);
      if (this.G)
        E(paramString + "\n");
      N(paramString + "\n");
    }
  }

  public synchronized void G(String paramString)
  {
    if (this.D)
    {
      if (this.E)
        System.err.print(paramString);
      if (this.G)
        E(paramString);
      N(paramString);
    }
  }

  public synchronized void B(String paramString, int paramInt)
  {
    if (this.D)
    {
      if (paramInt > this.B)
        return;
      if (this.E)
        System.err.println(paramString);
      if (this.G)
        E(paramString + "\n");
      N(paramString);
    }
  }

  public static synchronized void A(String paramString1, String paramString2)
  {
    try
    {
      RandomAccessFile localRandomAccessFile = new RandomAccessFile(paramString2, "rw");
      localRandomAccessFile.seek(localRandomAccessFile.length());
      localRandomAccessFile.writeBytes(paramString1);
      localRandomAccessFile.close();
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }

  public synchronized void E(String paramString)
  {
    if (this.A == null)
      return;
    if (this.D)
    {
      if (this.I == null)
        try
        {
          this.I = new RandomAccessFile(this.A, "rw");
          this.I.seek(this.I.length());
        }
        catch (IOException localIOException1)
        {
          System.err.println("APPENDLOG ERROR #1");
          return;
        }
      if (this.I != null)
        try
        {
          this.I.writeBytes(paramString);
        }
        catch (IOException localIOException2)
        {
          System.err.println("APPENDLOG ERROR #2");
        }
    }
  }

  public static String C()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    try
    {
      char c = '\000';
      while (c != '\n')
      {
        c = (char)System.in.read();
        if (c != '\n')
          localStringBuffer.append(c);
      }
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
    return localStringBuffer.toString();
  }

  public static double A(double paramDouble, int paramInt)
  {
    if (Double.isNaN(paramDouble))
      return paramDouble;
    double d = 1.0D;
    for (int i = 0; i < paramInt; i++)
      d *= 10.0D;
    return Math.round(paramDouble * d) / d;
  }

  public static String D(String paramString, int paramInt)
  {
    if (paramString.length() < paramInt)
      return D(paramString + " ", paramInt);
    return paramString;
  }

  public static String C(String paramString, int paramInt)
  {
    if (paramString.length() < paramInt)
      return C(" " + paramString, paramInt);
    return paramString;
  }

  public static String A(String paramString, int paramInt)
  {
    if (paramString.length() < paramInt)
    {
      StringBuffer localStringBuffer = new StringBuffer();
      for (int i = 0; i < (paramInt - paramString.length()) / 2; i++)
        localStringBuffer.append(" ");
      localStringBuffer.append(paramString);
      i = localStringBuffer.length();
      for (int j = 0; j < paramInt - i; j++)
        localStringBuffer.append(" ");
      assert (localStringBuffer.length() == paramInt);
      paramString = localStringBuffer.toString();
    }
    return paramString;
  }

  public void finalize()
  {
    try
    {
      this.I.close();
      this.I = null;
    }
    catch (IOException localIOException)
    {
      System.err.println("FINALIZE ERROR");
    }
  }

  public static String F(String paramString)
  {
    return A(new File(paramString));
  }

  public static String A(File paramFile)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    try
    {
      BufferedInputStream localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramFile));
      int i = -1;
      while ((i = localBufferedInputStream.read()) != -1)
        localStringBuffer.append((char)i);
      localBufferedInputStream.close();
    }
    catch (IOException localIOException)
    {
      return null;
    }
    return localStringBuffer.toString();
  }

  public static String L(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    try
    {
      Runtime localRuntime = Runtime.getRuntime();
      Process localProcess = localRuntime.exec(paramString);
      BufferedInputStream localBufferedInputStream = new BufferedInputStream(localProcess.getInputStream());
      localProcess.waitFor();
      int i = -1;
      while ((i = localBufferedInputStream.read()) != -1)
        localStringBuffer.append((char)i);
    }
    catch (InterruptedException localInterruptedException)
    {
      return null;
    }
    catch (IOException localIOException)
    {
      return null;
    }
    return localStringBuffer.toString();
  }

  public String C(String paramString)
  {
    G(paramString);
    String str = A();
    if ((str != null) && (str.length() > 0))
      return str;
    return C(paramString);
  }

  public static String A()
  {
    System.out.flush();
    String str;
    try
    {
      BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(System.in));
      str = localBufferedReader.readLine();
      localBufferedReader.close();
    }
    catch (Exception localException)
    {
      return null;
    }
    return str;
  }

  public static void F()
  {
    try
    {
      BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(System.in));
      localBufferedReader.readLine();
      localBufferedReader.close();
    }
    catch (Exception localException)
    {
    }
  }

  public String J(String paramString)
  {
    return paramString.toLowerCase().trim();
  }

  public static boolean A(String paramString)
  {
    File localFile = new File(paramString);
    return localFile.exists();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.b
 * JD-Core Version:    0.6.2
 */