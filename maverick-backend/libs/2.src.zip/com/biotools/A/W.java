package com.biotools.A;

import java.security.SecureRandom;

public class W extends SecureRandom
{
  private static W A = null;

  public static synchronized W A()
  {
    if (A == null)
      A = new W();
    return A;
  }

  public int A(int paramInt)
  {
    return (int)(nextDouble() * paramInt) % paramInt;
  }

  public double nextDouble()
  {
    return super.nextDouble();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.W
 * JD-Core Version:    0.6.2
 */