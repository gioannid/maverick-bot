package com.biotools.A;

public abstract class Y
{
  public Y(String paramString)
  {
    A(paramString);
  }

  public abstract void A();

  public abstract boolean B();

  public abstract void A(String paramString);
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.Y
 * JD-Core Version:    0.6.2
 */