package com.biotools.A;

import java.io.File;
import javax.swing.filechooser.FileFilter;

public class J extends FileFilter
{
  public static final String A = "xml";

  public boolean accept(File paramFile)
  {
    if (paramFile.isDirectory())
      return true;
    String str = A(paramFile);
    return (str != null) && (str.equals("xml"));
  }

  public String getDescription()
  {
    return "XML Files";
  }

  public static String A(File paramFile)
  {
    String str1 = null;
    String str2 = paramFile.getName();
    int i = str2.lastIndexOf('.');
    if ((i > 0) && (i < str2.length() - 1))
      str1 = str2.substring(i + 1).toLowerCase();
    return str1;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.J
 * JD-Core Version:    0.6.2
 */