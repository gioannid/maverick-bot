package com.biotools.A;

import java.io.File;

public class Z extends Y
{
  private volatile int J;
  private String I;

  public Z(String paramString)
  {
    super(paramString);
  }

  public void A()
  {
    S.B(this.J);
  }

  public boolean B()
  {
    return this.J >= 0;
  }

  public void A(String paramString)
  {
    this.I = paramString;
    this.J = -1;
    try
    {
      this.J = S.A(new File(paramString));
    }
    catch (Exception localException)
    {
      I.A("", localException);
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.Z
 * JD-Core Version:    0.6.2
 */