package com.biotools.A;

public class O extends U
{
  public int C(String paramString)
  {
    U._A local_A = A(paramString);
    if (local_A != null)
      return local_A.A();
    int i = size();
    A(i, paramString);
    return i;
  }

  public void A(String paramString, int paramInt)
  {
    A(paramInt, paramString);
  }

  public boolean B(String paramString)
  {
    return A(paramString) == null;
  }

  public int A(String paramString)
  {
    U._A local_A = A(paramString);
    if (local_A != null)
      return local_A.A();
    return -1;
  }

  public String D(int paramInt)
  {
    return (String)C(paramInt);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.biotools.A.O
 * JD-Core Version:    0.6.2
 */