package com.A.B;

import com.biotools.A.I;
import com.biotools.B.R;
import com.biotools.poker.E;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.File;
import java.net.ConnectException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.UnknownHostException;
import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkEvent.EventType;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.Document;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.HTMLFrameHyperlinkEvent;

public class A extends JPanel
{
  private JEditorPane A = new JEditorPane();
  private JScrollPane B = C();
  private boolean C = false;

  public A(URL paramURL)
  {
    A(paramURL);
    setLayout(new BorderLayout());
    add(this.B, "Center");
  }

  public JScrollPane D()
  {
    return this.B;
  }

  public void setPreferredSize(Dimension paramDimension)
  {
    super.setPreferredSize(paramDimension);
    if (this.B != null)
    {
      this.B.setPreferredSize(paramDimension);
      this.B.setMinimumSize(paramDimension);
    }
  }

  public void A(int paramInt1, int paramInt2)
  {
    this.B.setHorizontalScrollBarPolicy(paramInt1);
    this.B.setVerticalScrollBarPolicy(paramInt2);
  }

  public A(String paramString)
  {
    A(paramString);
    setLayout(new BorderLayout());
    add(this.B, "Center");
  }

  public A()
  {
    setLayout(new BorderLayout());
    add(this.B, "Center");
  }

  public A(boolean paramBoolean)
  {
    setLayout(new BorderLayout());
    if (paramBoolean)
      add(this.B, "Center");
    else
      add(this.A, "Center");
  }

  public void A()
  {
    this.B.setBorder(null);
  }

  private JScrollPane C()
  {
    this.A.setContentType("text/html");
    this.A.setEditable(false);
    this.A.setBorder(new EmptyBorder(4, 4, 4, 4));
    this.A.addHyperlinkListener(new _A());
    JScrollPane localJScrollPane = new JScrollPane(this.A);
    localJScrollPane.setBorder(new BevelBorder(1));
    return localJScrollPane;
  }

  public void B(String paramString)
  {
    try
    {
      A(new URL(paramString));
    }
    catch (MalformedURLException localMalformedURLException)
    {
      I.A("", localMalformedURLException);
    }
  }

  public void A(final URL paramURL)
  {
    Runnable local1 = new Runnable()
    {
      private final URL val$url;

      public void run()
      {
        try
        {
          A.this.A.setDocument(new HTMLEditorKit().createDefaultDocument());
          File localFile = R.A(paramURL);
          if ((localFile != null) && (localFile.exists()))
          {
            A.this.A.setPage(paramURL);
            A.this.A.setText(R.A(localFile));
            A.this.A.setCaretPosition(0);
          }
          else
          {
            A.this.A.setPage(paramURL);
          }
        }
        catch (UnknownHostException localUnknownHostException)
        {
          A.this.A("<html><body><h2 align=\"center\">Unknown Host Exception:</h2><h3 align=\"center\">'" + paramURL.getHost() + "'</h3>" + "</body></html>");
        }
        catch (ConnectException localConnectException)
        {
          A.this.A("<html><body><h2 align=\"center\">Connect Exception:" + localConnectException.getLocalizedMessage() + "</h2>" + "<h3 align=\"center\">'" + paramURL.getHost() + "'</h3>" + "</body></html>");
        }
        catch (Exception localException)
        {
          I.A("", localException);
        }
      }
    };
    if (SwingUtilities.isEventDispatchThread())
      local1.run();
    else
      SwingUtilities.invokeLater(local1);
  }

  public void A(String paramString)
  {
    this.A.setContentType("text/html");
    this.A.setText(paramString);
    E();
  }

  public void F()
  {
    try
    {
      Document localDocument = this.A.getDocument();
      localDocument.remove(0, localDocument.getLength());
    }
    catch (Exception localException)
    {
      I.A("", localException);
    }
  }

  public void E()
  {
    SwingUtilities.invokeLater(new Runnable()
    {
      public void run()
      {
        try
        {
          A.this.A.setCaretPosition(0);
        }
        catch (Exception localException)
        {
          I.A("", localException);
        }
      }
    });
  }

  public void A(File paramFile)
  {
    try
    {
      A(paramFile.toURI().toURL());
    }
    catch (MalformedURLException localMalformedURLException)
    {
      I.A("", localMalformedURLException);
    }
  }

  public void A(boolean paramBoolean)
  {
    this.C = paramBoolean;
  }

  public JEditorPane B()
  {
    return this.A;
  }

  public class _A
    implements HyperlinkListener
  {
    public _A()
    {
    }

    public void hyperlinkUpdate(HyperlinkEvent paramHyperlinkEvent)
    {
      if (paramHyperlinkEvent.getEventType() == HyperlinkEvent.EventType.ACTIVATED)
      {
        JEditorPane localJEditorPane = (JEditorPane)paramHyperlinkEvent.getSource();
        if ((paramHyperlinkEvent instanceof HTMLFrameHyperlinkEvent))
        {
          HTMLFrameHyperlinkEvent localHTMLFrameHyperlinkEvent = (HTMLFrameHyperlinkEvent)paramHyperlinkEvent;
          HTMLDocument localHTMLDocument = (HTMLDocument)localJEditorPane.getDocument();
          localHTMLDocument.processHTMLFrameHyperlinkEvent(localHTMLFrameHyperlinkEvent);
        }
        else
        {
          try
          {
            if (A.this.C)
              E.A(A.this.B(), paramHyperlinkEvent.getURL().toString());
            else
              A.this.A(paramHyperlinkEvent.getURL());
          }
          catch (Exception localException)
          {
            I.A("", localException);
          }
        }
      }
    }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.A.B.A
 * JD-Core Version:    0.6.2
 */