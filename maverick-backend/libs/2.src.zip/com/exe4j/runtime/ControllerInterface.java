package com.exe4j.runtime;

public abstract interface ControllerInterface
{
  public abstract void writeMessage(String paramString)
    throws BaseConnectionException;

  public abstract void hide()
    throws BaseConnectionException;
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.exe4j.runtime.ControllerInterface
 * JD-Core Version:    0.6.2
 */