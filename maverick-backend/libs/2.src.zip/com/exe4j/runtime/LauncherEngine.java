package com.exe4j.runtime;

import com.exe4j.runtime.util.InternalErrorFrame;
import com.exe4j.runtime.util.LazyFileOutputStream;
import com.exe4j.runtime.util.NullOutputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Properties;

public class LauncherEngine
{
  private static Properties properties;
  public static final String DEV_NULL = "/dev/null";

  public static void launch(String paramString1, String[] paramArrayOfString, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2, ClassLoader paramClassLoader)
  {
    try
    {
      doRedirection(paramString2, paramString3);
      try
      {
        Class[] arrayOfClass = new Class[1];
        arrayOfClass[0] = new String[0].getClass();
        Object[] arrayOfObject = new Object[1];
        arrayOfObject[0] = paramArrayOfString;
        Class localClass = paramClassLoader.loadClass(paramString1);
        Method localMethod = localClass.getDeclaredMethod("main", arrayOfClass);
        localMethod.setAccessible(true);
        localMethod.invoke(null, arrayOfObject);
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        handleFailure(paramBoolean1, paramBoolean2, localInvocationTargetException.getCause());
      }
      catch (Throwable localThrowable1)
      {
        handleFailure(paramBoolean1, paramBoolean2, localThrowable1);
      }
    }
    catch (Throwable localThrowable2)
    {
      handleFailure(true, paramBoolean2, localThrowable2);
    }
  }

  public static String getProperty(int paramInt)
  {
    return properties.getProperty(String.valueOf(paramInt));
  }

  public static boolean getBooleanProperty(int paramInt)
  {
    return Integer.parseInt(getProperty(paramInt)) == 1;
  }

  public static int getIntProperty(int paramInt)
  {
    return Integer.parseInt(getProperty(paramInt));
  }

  public static void setProperties(Properties paramProperties)
  {
    properties = paramProperties;
  }

  private static void handleFailure(boolean paramBoolean1, boolean paramBoolean2, Throwable paramThrowable)
  {
    paramThrowable.printStackTrace();
    if (paramBoolean1)
      if (paramBoolean2)
        new InternalErrorFrame(paramThrowable).setVisible(true);
      else
        System.exit(1);
  }

  private static void doRedirection(String paramString1, String paramString2)
    throws FileNotFoundException
  {
    PrintStream localPrintStream1 = null;
    if (paramString2.equals("/dev/null"))
    {
      System.setOut(new PrintStream(new NullOutputStream()));
    }
    else if ((paramString2.length() > 0) && (checkRedirectionFile(paramString2)))
    {
      localPrintStream1 = new PrintStream(new BufferedOutputStream(new LazyFileOutputStream(paramString2)), true);
      System.setOut(localPrintStream1);
    }
    if (paramString1.equals("/dev/null"))
    {
      System.setErr(new PrintStream(new NullOutputStream()));
    }
    else if ((paramString1.length() > 0) && (checkRedirectionFile(paramString1)))
    {
      PrintStream localPrintStream2;
      if (paramString1.equalsIgnoreCase(paramString2))
        localPrintStream2 = localPrintStream1;
      else
        localPrintStream2 = new PrintStream(new LazyFileOutputStream(paramString1), true);
      System.setErr(localPrintStream2);
    }
  }

  private static boolean checkRedirectionFile(String paramString)
    throws FileNotFoundException
  {
    File localFile1 = new File(paramString);
    File localFile2 = localFile1.getParentFile();
    if (!localFile2.exists())
      throw new FileNotFoundException("log file directory '" + localFile2 + "' doesn't exist.");
    if (localFile1.exists())
      return localFile1.canWrite();
    return localFile2.canWrite();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.exe4j.runtime.LauncherEngine
 * JD-Core Version:    0.6.2
 */