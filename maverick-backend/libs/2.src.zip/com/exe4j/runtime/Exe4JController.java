package com.exe4j.runtime;

public class Exe4JController
  implements ControllerInterface
{
  private static Exe4JController exe4JController;
  private static final int ACTION_NONE = 0;
  private static final int ACTION_HIDE = 1;
  private static final int ACTION_WRITE_MESSAGE = 2;
  private static int currentAction = 0;
  private static String currentMessage = "";

  public static Exe4JController getInstance()
    throws BaseConnectionException
  {
    if (exe4JController == null)
      exe4JController = new Exe4JController();
    return exe4JController;
  }

  public void writeMessage(String paramString)
    throws BaseConnectionException
  {
    if (currentAction != 1)
    {
      currentMessage = paramString;
      currentAction = 2;
    }
  }

  public void hide()
    throws BaseConnectionException
  {
    currentAction = 1;
  }

  public static int getAction()
  {
    int i = currentAction;
    currentAction = 0;
    return i;
  }

  public static String getText()
  {
    return currentMessage;
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.exe4j.runtime.Exe4JController
 * JD-Core Version:    0.6.2
 */