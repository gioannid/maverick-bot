package com.exe4j.runtime;

import com.exe4j.runtime.util.ArgumentStack;
import java.io.File;

public class WinLauncher
{
  public static final String PROCESS_COMM_FILE_NAME = System.getProperty("exe4j.processCommFile");

  public static void main(String[] paramArrayOfString)
  {
    if (PROCESS_COMM_FILE_NAME != null)
      new File(PROCESS_COMM_FILE_NAME).deleteOnExit();
    ArgumentStack localArgumentStack = new ArgumentStack(paramArrayOfString);
    boolean bool1 = localArgumentStack.popBoolean();
    String str1 = localArgumentStack.popString();
    String str2 = localArgumentStack.popString();
    String str3 = localArgumentStack.popString();
    boolean bool2 = localArgumentStack.popBoolean();
    LauncherEngine.launch(str1, localArgumentStack.getStringArray(), str2, str3, bool2, bool1, ClassLoader.getSystemClassLoader());
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.exe4j.runtime.WinLauncher
 * JD-Core Version:    0.6.2
 */