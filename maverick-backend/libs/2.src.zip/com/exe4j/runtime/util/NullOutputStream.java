package com.exe4j.runtime.util;

import java.io.IOException;
import java.io.OutputStream;

public class NullOutputStream extends OutputStream
{
  public void write(int paramInt)
    throws IOException
  {
  }

  public void write(byte[] paramArrayOfByte)
    throws IOException
  {
  }

  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.exe4j.runtime.util.NullOutputStream
 * JD-Core Version:    0.6.2
 */