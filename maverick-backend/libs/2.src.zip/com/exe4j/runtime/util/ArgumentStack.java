package com.exe4j.runtime.util;

import java.util.LinkedList;

public class ArgumentStack
{
  private LinkedList list = new LinkedList();

  public ArgumentStack(String[] paramArrayOfString)
  {
    for (int i = 0; i < paramArrayOfString.length; i++)
      this.list.add(paramArrayOfString[i]);
  }

  public String popString()
  {
    return (String)this.list.removeFirst();
  }

  public boolean popBoolean()
  {
    return new Boolean(popString()).booleanValue();
  }

  public int popInt()
  {
    try
    {
      return Integer.parseInt(popString());
    }
    catch (NumberFormatException localNumberFormatException)
    {
    }
    return 0;
  }

  public String[] getStringArray()
  {
    int i = this.list.size();
    String[] arrayOfString = new String[i];
    for (int j = 0; j < i; j++)
      arrayOfString[j] = popString();
    return arrayOfString;
  }

  public int size()
  {
    return this.list.size();
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.exe4j.runtime.util.ArgumentStack
 * JD-Core Version:    0.6.2
 */