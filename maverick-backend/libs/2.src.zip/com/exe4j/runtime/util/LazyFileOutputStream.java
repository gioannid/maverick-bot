package com.exe4j.runtime.util;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class LazyFileOutputStream extends OutputStream
{
  private String fileName;
  private OutputStream fos;

  public LazyFileOutputStream(String paramString)
  {
    this.fileName = paramString;
  }

  public void write(byte[] paramArrayOfByte)
    throws IOException
  {
    init();
    this.fos.write(paramArrayOfByte);
  }

  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    init();
    this.fos.write(paramArrayOfByte, paramInt1, paramInt2);
  }

  public void write(int paramInt)
    throws IOException
  {
    init();
    this.fos.write(paramInt);
  }

  private void init()
  {
    if (this.fos == null)
      try
      {
        this.fos = new FileOutputStream(this.fileName);
      }
      catch (FileNotFoundException localFileNotFoundException)
      {
        this.fos = new NullOutputStream();
      }
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.exe4j.runtime.util.LazyFileOutputStream
 * JD-Core Version:    0.6.2
 */