/*     */ package com.jgoodies.looks;
/*     */ 
/*     */ public final class FontSizeHints
/*     */ {
/*  53 */   public static final FontSizeHints LARGE = new FontSizeHints(12, 12, 14, 14);
/*  54 */   public static final FontSizeHints SYSTEM = new FontSizeHints(11, 11, 14, 14);
/*  55 */   public static final FontSizeHints MIXED2 = new FontSizeHints(11, 11, 14, 13);
/*  56 */   public static final FontSizeHints MIXED = new FontSizeHints(11, 11, 14, 12);
/*  57 */   public static final FontSizeHints SMALL = new FontSizeHints(11, 11, 12, 12);
/*  58 */   public static final FontSizeHints FIXED = new FontSizeHints(12, 12, 12, 12);
/*     */ 
/*  60 */   public static final FontSizeHints DEFAULT = SYSTEM;
/*     */   private final int loResMenuFontSize;
/*     */   private final int loResControlFontSize;
/*     */   private final int hiResMenuFontSize;
/*     */   private final int hiResControlFontSize;
/*     */ 
/*     */   public FontSizeHints(int loResMenuFontSize, int loResControlFontSize, int hiResMenuFontSize, int hiResControlFontSize)
/*     */   {
/*  80 */     this.loResMenuFontSize = loResMenuFontSize;
/*  81 */     this.loResControlFontSize = loResControlFontSize;
/*  82 */     this.hiResMenuFontSize = hiResMenuFontSize;
/*  83 */     this.hiResControlFontSize = hiResControlFontSize;
/*     */   }
/*     */ 
/*     */   public int loResMenuFontSize()
/*     */   {
/*  92 */     return this.loResMenuFontSize;
/*     */   }
/*     */ 
/*     */   public int loResControlFontSize()
/*     */   {
/* 100 */     return this.loResControlFontSize;
/*     */   }
/*     */ 
/*     */   public int hiResMenuFontSize()
/*     */   {
/* 108 */     return this.hiResMenuFontSize;
/*     */   }
/*     */ 
/*     */   public int hiResControlFontSize()
/*     */   {
/* 116 */     return this.hiResControlFontSize;
/*     */   }
/*     */ 
/*     */   public int menuFontSize()
/*     */   {
/* 125 */     return LookUtils.IS_LOW_RESOLUTION ? this.loResMenuFontSize : hiResMenuFontSize();
/*     */   }
/*     */ 
/*     */   public int controlFontSize()
/*     */   {
/* 135 */     return LookUtils.IS_LOW_RESOLUTION ? this.loResControlFontSize : hiResControlFontSize();
/*     */   }
/*     */ 
/*     */   public float menuFontSizeDelta()
/*     */   {
/* 147 */     return menuFontSize() - SYSTEM.menuFontSize();
/*     */   }
/*     */ 
/*     */   public float controlFontSizeDelta()
/*     */   {
/* 159 */     return controlFontSize() - SYSTEM.controlFontSize();
/*     */   }
/*     */ 
/*     */   public static FontSizeHints valueOf(String name)
/*     */   {
/* 171 */     if (name.equalsIgnoreCase("LARGE"))
/* 172 */       return LARGE;
/* 173 */     if (name.equalsIgnoreCase("SYSTEM"))
/* 174 */       return SYSTEM;
/* 175 */     if (name.equalsIgnoreCase("MIXED"))
/* 176 */       return MIXED;
/* 177 */     if (name.equalsIgnoreCase("SMALL"))
/* 178 */       return SMALL;
/* 179 */     if (name.equalsIgnoreCase("FIXED")) {
/* 180 */       return FIXED;
/*     */     }
/* 182 */     throw new IllegalArgumentException("Unknown font size hints name: " + name);
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.FontSizeHints
 * JD-Core Version:    0.6.2
 */