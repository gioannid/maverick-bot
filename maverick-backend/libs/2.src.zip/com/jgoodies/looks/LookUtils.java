/*     */ package com.jgoodies.looks;
/*     */ 
/*     */ import com.jgoodies.looks.plastic.PlasticLookAndFeel;
/*     */ import com.jgoodies.looks.plastic.PlasticTheme;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.UnsupportedLookAndFeelException;
/*     */ import javax.swing.plaf.InsetsUIResource;
/*     */ import javax.swing.plaf.UIResource;
/*     */ 
/*     */ public final class LookUtils
/*     */ {
/*  69 */   private static final String JAVA_VERSION = getSystemProperty("java.version");
/*     */ 
/*  77 */   private static final String OS_NAME = getSystemProperty("os.name");
/*     */ 
/*  85 */   private static final String OS_VERSION = getSystemProperty("os.version");
/*     */ 
/*  94 */   public static final boolean IS_JAVA_1_4 = startsWith(JAVA_VERSION, "1.4");
/*     */ 
/*  99 */   static final boolean IS_JAVA_1_4_0 = startsWith(JAVA_VERSION, "1.4.0");
/*     */ 
/* 106 */   public static final boolean IS_JAVA_1_4_2_OR_LATER = (!startsWith(JAVA_VERSION, "1.4.0")) && 
/* 107 */     (!startsWith(JAVA_VERSION, "1.4.1"));
/*     */ 
/* 114 */   public static final boolean IS_JAVA_5 = startsWith(JAVA_VERSION, "1.5");
/*     */ 
/* 123 */   public static final boolean IS_OS_FREEBSD = startsWithIgnoreCase(OS_NAME, "FreeBSD");
/*     */ 
/* 129 */   public static final boolean IS_OS_LINUX = startsWithIgnoreCase(OS_NAME, "Linux");
/*     */ 
/* 135 */   public static final boolean IS_OS_OS2 = startsWith(OS_NAME, "OS/2");
/*     */ 
/* 141 */   public static final boolean IS_OS_MAC = startsWith(OS_NAME, "Mac");
/*     */ 
/* 147 */   public static final boolean IS_OS_WINDOWS = startsWith(OS_NAME, "Windows");
/*     */ 
/* 153 */   public static final boolean IS_OS_WINDOWS_MODERN = (startsWith(OS_NAME, "Windows")) && (!startsWith(OS_VERSION, "4.0"));
/*     */ 
/* 159 */   public static final boolean IS_OS_WINDOWS_XP = (startsWith(OS_NAME, "Windows")) && (startsWith(OS_VERSION, "5.1"));
/*     */ 
/* 165 */   public static final boolean IS_OS_SOLARIS = startsWith(OS_NAME, "Solaris");
/*     */ 
/* 173 */   public static final boolean IS_LAF_WINDOWS_XP_ENABLED = isWindowsXPLafEnabled();
/*     */ 
/* 180 */   public static final boolean IS_LOW_RESOLUTION = isLowResolution();
/*     */ 
/* 182 */   private static boolean loggingEnabled = true;
/*     */ 
/*     */   public static String getSystemProperty(String key)
/*     */   {
/*     */     try
/*     */     {
/* 203 */       return System.getProperty(key);
/*     */     } catch (SecurityException e) {
/* 205 */       log("Can't read the System property " + key + ".");
/* 206 */     }return null;
/*     */   }
/*     */ 
/*     */   public static String getSystemProperty(String key, String defaultValue)
/*     */   {
/*     */     try
/*     */     {
/* 222 */       return System.getProperty(key, defaultValue);
/*     */     } catch (SecurityException e) {
/* 224 */       log("Can't read the System property " + key + ".");
/* 225 */     }return defaultValue;
/*     */   }
/*     */ 
/*     */   public static Boolean getBooleanSystemProperty(String key, String logMessage)
/*     */   {
/* 243 */     String value = getSystemProperty(key, "");
/*     */     Boolean result;
/*     */     Boolean result;
/* 245 */     if (value.equalsIgnoreCase("false")) {
/* 246 */       result = Boolean.FALSE;
/*     */     }
/*     */     else
/*     */     {
/*     */       Boolean result;
/* 247 */       if (value.equalsIgnoreCase("true"))
/* 248 */         result = Boolean.TRUE;
/*     */       else
/* 250 */         result = null; 
/*     */     }
/* 251 */     if (result != null) {
/* 252 */       log(
/* 253 */         logMessage + 
/* 254 */         " have been " + (
/* 255 */         result.booleanValue() ? "en" : "dis") + 
/* 256 */         "abled in the system properties.");
/*     */     }
/* 258 */     return result;
/*     */   }
/*     */ 
/*     */   private static boolean isWindowsXPLafEnabled()
/*     */   {
/* 278 */     if ((IS_OS_WINDOWS_XP) && 
/* 279 */       (IS_JAVA_1_4_2_OR_LATER) && 
/* 280 */       (Boolean.TRUE.equals(
/* 281 */       Toolkit.getDefaultToolkit().getDesktopProperty("win.xpstyle.themeActive"))))
/* 282 */       if (getSystemProperty("swing.noxp") == null) return true;
/* 278 */     return 
/* 282 */       false;
/*     */   }
/*     */ 
/*     */   public static boolean isTrueColor(Component c)
/*     */   {
/* 293 */     return c.getToolkit().getColorModel().getPixelSize() >= 24;
/*     */   }
/*     */ 
/*     */   public static void installNarrowMargin(AbstractButton b, String propertyPrefix)
/*     */   {
/* 308 */     Object value = b.getClientProperty("jgoodies.isNarrow");
/* 309 */     boolean isNarrow = Boolean.TRUE.equals(value);
/* 310 */     String defaultsKey = 
/* 311 */       propertyPrefix + (isNarrow ? "narrowMargin" : "margin");
/* 312 */     Insets insets = b.getMargin();
/* 313 */     if ((insets == null) || ((insets instanceof UIResource)))
/* 314 */       b.setMargin(UIManager.getInsets(defaultsKey));
/*     */   }
/*     */ 
/*     */   public static Insets createButtonMargin(boolean narrow)
/*     */   {
/* 330 */     int pad = (narrow) || (Options.getUseNarrowButtons()) ? 4 : 14;
/* 331 */     return IS_LOW_RESOLUTION ? 
/* 332 */       new InsetsUIResource(2, pad, 1, pad) : 
/* 333 */       new InsetsUIResource(3, pad, 3, pad);
/*     */   }
/*     */ 
/*     */   public static Color getSlightlyBrighter(Color color)
/*     */   {
/* 346 */     return getSlightlyBrighter(color, 1.1F);
/*     */   }
/*     */ 
/*     */   public static Color getSlightlyBrighter(Color color, float factor)
/*     */   {
/* 358 */     float[] hsbValues = new float[3];
/* 359 */     Color.RGBtoHSB(
/* 360 */       color.getRed(), 
/* 361 */       color.getGreen(), 
/* 362 */       color.getBlue(), 
/* 363 */       hsbValues);
/* 364 */     float hue = hsbValues[0];
/* 365 */     float saturation = hsbValues[1];
/* 366 */     float brightness = hsbValues[2];
/* 367 */     float newBrightness = Math.min(brightness * factor, 1.0F);
/* 368 */     return Color.getHSBColor(hue, saturation, newBrightness);
/*     */   }
/*     */ 
/*     */   public static void setLookAndTheme(LookAndFeel laf, Object theme)
/*     */     throws UnsupportedLookAndFeelException
/*     */   {
/* 376 */     if (((laf instanceof PlasticLookAndFeel)) && 
/* 377 */       (theme != null) && 
/* 378 */       ((theme instanceof PlasticTheme))) {
/* 379 */       PlasticLookAndFeel.setMyCurrentTheme((PlasticTheme)theme);
/*     */     }
/* 381 */     UIManager.setLookAndFeel(laf);
/*     */   }
/*     */ 
/*     */   public static Object getDefaultTheme(LookAndFeel laf) {
/* 385 */     return (laf instanceof PlasticLookAndFeel) ? 
/* 386 */       PlasticLookAndFeel.createMyDefaultTheme() : 
/* 387 */       null;
/*     */   }
/*     */ 
/*     */   public static List getInstalledThemes(LookAndFeel laf) {
/* 391 */     return (laf instanceof PlasticLookAndFeel) ? 
/* 392 */       PlasticLookAndFeel.getInstalledThemes() : 
/* 393 */       Collections.EMPTY_LIST;
/*     */   }
/*     */ 
/*     */   public static void setLoggingEnabled(boolean enabled)
/*     */   {
/* 404 */     loggingEnabled = enabled;
/*     */   }
/*     */ 
/*     */   public static void log()
/*     */   {
/* 411 */     if (loggingEnabled)
/* 412 */       System.out.println();
/*     */   }
/*     */ 
/*     */   public static void log(String message)
/*     */   {
/* 422 */     if (loggingEnabled)
/* 423 */       System.out.println("JGoodies Looks: " + message);
/*     */   }
/*     */ 
/*     */   private static boolean isLowResolution()
/*     */   {
/* 436 */     return Toolkit.getDefaultToolkit().getScreenResolution() < 120;
/*     */   }
/*     */ 
/*     */   private static boolean startsWith(String str, String prefix) {
/* 440 */     return (str != null) && (str.startsWith(prefix));
/*     */   }
/*     */ 
/*     */   private static boolean startsWithIgnoreCase(String str, String prefix) {
/* 444 */     return (str != null) && (str.toUpperCase().startsWith(prefix.toUpperCase()));
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.LookUtils
 * JD-Core Version:    0.6.2
 */