/*     */ package com.jgoodies.looks;
/*     */ 
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JToolBar;
/*     */ 
/*     */ public final class BorderStyle
/*     */ {
/*  48 */   public static final BorderStyle EMPTY = new BorderStyle("Empty");
/*  49 */   public static final BorderStyle SEPARATOR = new BorderStyle("Separator");
/*  50 */   public static final BorderStyle ETCHED = new BorderStyle("Etched");
/*     */   private final String name;
/*     */ 
/*     */   private BorderStyle(String name)
/*     */   {
/*  58 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public static BorderStyle from(JToolBar toolBar, String clientPropertyKey)
/*     */   {
/*  72 */     return from0(toolBar, clientPropertyKey);
/*     */   }
/*     */ 
/*     */   public static BorderStyle from(JMenuBar menuBar, String clientPropertyKey)
/*     */   {
/*  84 */     return from0(menuBar, clientPropertyKey);
/*     */   }
/*     */ 
/*     */   private static BorderStyle from0(JComponent c, String clientPropertyKey)
/*     */   {
/*  98 */     Object value = c.getClientProperty(clientPropertyKey);
/*  99 */     if ((value instanceof BorderStyle)) {
/* 100 */       return (BorderStyle)value;
/*     */     }
/* 102 */     if ((value instanceof String)) {
/* 103 */       return valueOf((String)value);
/*     */     }
/*     */ 
/* 106 */     return null;
/*     */   }
/*     */ 
/*     */   private static BorderStyle valueOf(String name) {
/* 110 */     if (name.equalsIgnoreCase(EMPTY.name))
/* 111 */       return EMPTY;
/* 112 */     if (name.equalsIgnoreCase(SEPARATOR.name))
/* 113 */       return SEPARATOR;
/* 114 */     if (name.equalsIgnoreCase(ETCHED.name)) {
/* 115 */       return ETCHED;
/*     */     }
/* 117 */     throw new IllegalArgumentException("Invalid BorderStyle name " + 
/* 118 */       name);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 122 */     return this.name;
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.BorderStyle
 * JD-Core Version:    0.6.2
 */