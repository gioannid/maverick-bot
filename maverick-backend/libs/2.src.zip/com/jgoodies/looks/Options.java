/*     */ package com.jgoodies.looks;
/*     */ 
/*     */ import com.jgoodies.looks.common.ShadowPopup;
/*     */ import java.awt.Dimension;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.UIManager;
/*     */ 
/*     */ public final class Options
/*     */ {
/*     */   public static final String PLASTIC_NAME = "com.jgoodies.looks.plastic.PlasticLookAndFeel";
/*     */   public static final String PLASTIC3D_NAME = "com.jgoodies.looks.plastic.Plastic3DLookAndFeel";
/*     */   public static final String PLASTICXP_NAME = "com.jgoodies.looks.plastic.PlasticXPLookAndFeel";
/*     */   public static final String JGOODIES_WINDOWS_NAME = "com.jgoodies.looks.windows.WindowsLookAndFeel";
/*     */ 
/*     */   /** @deprecated */
/*     */   public static final String EXT_WINDOWS_NAME = "com.jgoodies.looks.windows.WindowsLookAndFeel";
/*     */   public static final String DEFAULT_LOOK_NAME = "com.jgoodies.looks.plastic.Plastic3DLookAndFeel";
/*  84 */   private static final Map LAF_REPLACEMENTS = new HashMap();
/*     */   public static final String MENU_FONT_KEY = "jgoodies.menuFont";
/*     */   public static final String CONTROL_FONT_KEY = "jgoodies.controlFont";
/*     */   public static final String FONT_SIZE_HINTS_KEY = "jgoodies.fontSizeHints";
/*     */   public static final String USE_SYSTEM_FONTS_KEY = "swing.useSystemFontSettings";
/*     */   public static final String USE_SYSTEM_FONTS_APP_KEY = "Application.useSystemFontSettings";
/*     */   public static final String DEFAULT_ICON_SIZE_KEY = "jgoodies.defaultIconSize";
/*     */   public static final String USE_NARROW_BUTTONS_KEY = "jgoodies.useNarrowButtons";
/*     */   public static final String TAB_ICONS_ENABLED_KEY = "jgoodies.tabIconsEnabled";
/*     */   public static final String POPUP_DROP_SHADOW_ENABLED_KEY = "jgoodies.popupDropShadowEnabled";
/*     */   public static final String IS_NARROW_KEY = "jgoodies.isNarrow";
/*     */   public static final String IS_ETCHED_KEY = "jgoodies.isEtched";
/*     */   public static final String HEADER_STYLE_KEY = "jgoodies.headerStyle";
/*     */   public static final String NO_ICONS_KEY = "jgoodies.noIcons";
/*     */   public static final String TREE_LINE_STYLE_KEY = "JTree.lineStyle";
/*     */   public static final String TREE_LINE_STYLE_ANGLED_VALUE = "Angled";
/*     */   public static final String TREE_LINE_STYLE_NONE_VALUE = "None";
/*     */   public static final String NO_CONTENT_BORDER_KEY = "jgoodies.noContentBorder";
/*     */   public static final String EMBEDDED_TABS_KEY = "jgoodies.embeddedTabs";
/* 194 */   private static final Boolean TAB_ICONS_ENABLED_SYSTEM_VALUE = LookUtils.getBooleanSystemProperty(
/* 195 */     "jgoodies.tabIconsEnabled", "Icons in tabbed panes");
/*     */ 
/* 212 */   private static final Boolean POPUP_DROP_SHADOW_ENABLED_SYSTEM_VALUE = LookUtils.getBooleanSystemProperty(
/* 213 */     "jgoodies.popupDropShadowEnabled", "Popup drop shadows");
/*     */ 
/* 219 */   private static final Dimension DEFAULT_ICON_SIZE = new Dimension(20, 20);
/*     */ 
/*     */   static
/*     */   {
/*  85 */     initializeDefaultReplacements();
/*     */   }
/*     */ 
/*     */   public static boolean getUseSystemFonts()
/*     */   {
/* 236 */     return UIManager.get("Application.useSystemFontSettings").equals(Boolean.TRUE);
/*     */   }
/*     */ 
/*     */   public static void setUseSystemFonts(boolean useSystemFonts)
/*     */   {
/* 247 */     UIManager.put("Application.useSystemFontSettings", Boolean.valueOf(useSystemFonts));
/*     */   }
/*     */ 
/*     */   public static Dimension getDefaultIconSize()
/*     */   {
/* 259 */     Dimension size = UIManager.getDimension("jgoodies.defaultIconSize");
/* 260 */     return size == null ? DEFAULT_ICON_SIZE : size;
/*     */   }
/*     */ 
/*     */   public static void setDefaultIconSize(Dimension defaultIconSize)
/*     */   {
/* 270 */     UIManager.put("jgoodies.defaultIconSize", defaultIconSize);
/*     */   }
/*     */ 
/*     */   public static FontSizeHints getGlobalFontSizeHints()
/*     */   {
/* 281 */     Object value = UIManager.get("jgoodies.fontSizeHints");
/* 282 */     if (value != null) {
/* 283 */       return (FontSizeHints)value;
/*     */     }
/* 285 */     String name = LookUtils.getSystemProperty("jgoodies.fontSizeHints", "");
/*     */     try {
/* 287 */       return FontSizeHints.valueOf(name); } catch (IllegalArgumentException e) {
/*     */     }
/* 289 */     return FontSizeHints.DEFAULT;
/*     */   }
/*     */ 
/*     */   public static void setGlobalFontSizeHints(FontSizeHints hints)
/*     */   {
/* 300 */     UIManager.put("jgoodies.fontSizeHints", hints);
/*     */   }
/*     */ 
/*     */   public static boolean getUseNarrowButtons()
/*     */   {
/* 318 */     return UIManager.getBoolean("jgoodies.useNarrowButtons");
/*     */   }
/*     */ 
/*     */   public static void setUseNarrowButtons(boolean b)
/*     */   {
/* 328 */     UIManager.put("jgoodies.useNarrowButtons", Boolean.valueOf(b));
/*     */   }
/*     */ 
/*     */   public static boolean isTabIconsEnabled()
/*     */   {
/* 340 */     return TAB_ICONS_ENABLED_SYSTEM_VALUE == null ? 
/* 341 */       true : Boolean.FALSE.equals(UIManager.get("jgoodies.tabIconsEnabled")) ? false : 
/* 342 */       TAB_ICONS_ENABLED_SYSTEM_VALUE.booleanValue();
/*     */   }
/*     */ 
/*     */   public static void setTabIconsEnabled(boolean b)
/*     */   {
/* 352 */     UIManager.put("jgoodies.tabIconsEnabled", Boolean.valueOf(b));
/*     */   }
/*     */ 
/*     */   public static boolean isPopupDropShadowActive()
/*     */   {
/* 376 */     boolean toolkitUsesNativeDropShadows = 
/* 377 */       LookUtils.IS_OS_MAC;
/*     */ 
/* 381 */     return (!toolkitUsesNativeDropShadows) && 
/* 380 */       (ShadowPopup.canSnapshot()) && 
/* 381 */       (isPopupDropShadowEnabled());
/*     */   }
/*     */ 
/*     */   public static boolean isPopupDropShadowEnabled()
/*     */   {
/* 394 */     if (POPUP_DROP_SHADOW_ENABLED_SYSTEM_VALUE != null) {
/* 395 */       return POPUP_DROP_SHADOW_ENABLED_SYSTEM_VALUE.booleanValue();
/*     */     }
/* 397 */     Object value = UIManager.get("jgoodies.popupDropShadowEnabled");
/* 398 */     return value == null ? 
/* 399 */       isPopupDropShadowEnabledDefault() : 
/* 400 */       Boolean.TRUE.equals(value);
/*     */   }
/*     */ 
/*     */   public static void setPopupDropShadowEnabled(boolean b)
/*     */   {
/* 417 */     UIManager.put("jgoodies.popupDropShadowEnabled", Boolean.valueOf(b));
/*     */   }
/*     */ 
/*     */   private static boolean isPopupDropShadowEnabledDefault()
/*     */   {
/* 435 */     return LookUtils.IS_OS_WINDOWS_MODERN;
/*     */   }
/*     */ 
/*     */   public static void putLookAndFeelReplacement(String original, String replacement)
/*     */   {
/* 453 */     LAF_REPLACEMENTS.put(original, replacement);
/*     */   }
/*     */ 
/*     */   public static void removeLookAndFeelReplacement(String original)
/*     */   {
/* 465 */     LAF_REPLACEMENTS.remove(original);
/*     */   }
/*     */ 
/*     */   public static void initializeDefaultReplacements()
/*     */   {
/* 478 */     putLookAndFeelReplacement(
/* 479 */       "javax.swing.plaf.metal.MetalLookAndFeel", 
/* 480 */       "com.jgoodies.looks.plastic.Plastic3DLookAndFeel");
/* 481 */     putLookAndFeelReplacement(
/* 482 */       "com.sun.java.swing.plaf.windows.WindowsLookAndFeel", 
/* 483 */       "com.jgoodies.looks.windows.WindowsLookAndFeel");
/*     */   }
/*     */ 
/*     */   public static String getReplacementClassNameFor(String className)
/*     */   {
/* 497 */     String replacement = (String)LAF_REPLACEMENTS.get(className);
/* 498 */     return replacement == null ? className : replacement;
/*     */   }
/*     */ 
/*     */   public static String getCrossPlatformLookAndFeelClassName()
/*     */   {
/* 508 */     return "com.jgoodies.looks.plastic.Plastic3DLookAndFeel";
/*     */   }
/*     */ 
/*     */   public static String getSystemLookAndFeelClassName()
/*     */   {
/* 518 */     String osName = System.getProperty("os.name");
/* 519 */     if (osName.startsWith("Windows"))
/* 520 */       return "com.jgoodies.looks.windows.WindowsLookAndFeel";
/* 521 */     if (osName.startsWith("Mac")) {
/* 522 */       return UIManager.getSystemLookAndFeelClassName();
/*     */     }
/* 524 */     return getCrossPlatformLookAndFeelClassName();
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.Options
 * JD-Core Version:    0.6.2
 */