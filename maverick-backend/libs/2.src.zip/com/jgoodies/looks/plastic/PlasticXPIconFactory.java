/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import com.jgoodies.looks.LookUtils;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.GradientPaint;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import java.io.Serializable;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ColorUIResource;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*     */ 
/*     */ public final class PlasticXPIconFactory
/*     */ {
/*     */   private static CheckBoxIcon checkBoxIcon;
/*     */   private static RadioButtonIcon radioButtonIcon;
/*     */ 
/*     */   static Icon getCheckBoxIcon()
/*     */   {
/*  72 */     if (checkBoxIcon == null) {
/*  73 */       checkBoxIcon = new CheckBoxIcon();
/*     */     }
/*  75 */     return checkBoxIcon;
/*     */   }
/*     */ 
/*     */   static Icon getRadioButtonIcon()
/*     */   {
/*  84 */     if (radioButtonIcon == null) {
/*  85 */       radioButtonIcon = new RadioButtonIcon();
/*     */     }
/*  87 */     return radioButtonIcon;
/*     */   }
/*     */ 
/*     */   private static class CheckBoxIcon
/*     */     implements Icon, UIResource, Serializable
/*     */   {
/*  93 */     private static final int SIZE = LookUtils.IS_LOW_RESOLUTION ? 13 : 15;
/*     */ 
/*  95 */     public int getIconWidth() { return SIZE; } 
/*  96 */     public int getIconHeight() { return SIZE; }
/*     */ 
/*     */     public void paintIcon(Component c, Graphics g, int x, int y) {
/*  99 */       JCheckBox cb = (JCheckBox)c;
/* 100 */       ButtonModel model = cb.getModel();
/* 101 */       Graphics2D g2 = (Graphics2D)g;
/* 102 */       Object hint = g2.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
/* 103 */       g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */ 
/* 105 */       drawBorder(g2, model.isEnabled(), x, y, SIZE - 1, SIZE - 1);
/* 106 */       drawFill(g2, model.isPressed(), x + 1, y + 1, SIZE - 2, SIZE - 2);
/* 107 */       if ((model.isEnabled()) && (model.isArmed()) && (!model.isPressed())) {
/* 108 */         drawFocus(g2, x + 1, y + 1, SIZE - 3, SIZE - 3);
/*     */       }
/* 110 */       if (model.isSelected()) {
/* 111 */         drawCheck(g2, model.isEnabled(), x + 3, y + 3, SIZE - 7, SIZE - 7);
/*     */       }
/* 113 */       g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, hint);
/*     */     }
/*     */ 
/*     */     private void drawBorder(Graphics2D g2, boolean enabled, int x, int y, int width, int height) {
/* 117 */       g2.setColor(enabled ? 
/* 118 */         PlasticLookAndFeel.getControlDarkShadow() : 
/* 119 */         MetalLookAndFeel.getControlDisabled());
/* 120 */       g2.drawRect(x, y, width, height);
/*     */     }
/*     */ 
/*     */     private void drawCheck(Graphics2D g2, boolean enabled, int x, int y, int width, int height) {
/* 124 */       g2.setColor(enabled ? 
/* 125 */         UIManager.getColor("CheckBox.check") : 
/* 126 */         MetalLookAndFeel.getControlDisabled());
/* 127 */       int right = x + width;
/* 128 */       int bottom = y + height;
/* 129 */       int startY = y + height / 3;
/* 130 */       int turnX = x + width / 2 - 2;
/* 131 */       g2.drawLine(x, startY, turnX, bottom - 3);
/* 132 */       g2.drawLine(x, startY + 1, turnX, bottom - 2);
/* 133 */       g2.drawLine(x, startY + 2, turnX, bottom - 1);
/* 134 */       g2.drawLine(turnX + 1, bottom - 2, right, y);
/* 135 */       g2.drawLine(turnX + 1, bottom - 1, right, y + 1);
/* 136 */       g2.drawLine(turnX + 1, bottom, right, y + 2);
/*     */     }
/*     */ 
/*     */     private void drawFill(Graphics2D g2, boolean pressed, int x, int y, int w, int h)
/*     */     {
/*     */       Color lowerRight;
/*     */       Color upperLeft;
/*     */       Color lowerRight;
/* 142 */       if (pressed) {
/* 143 */         Color upperLeft = MetalLookAndFeel.getControlShadow();
/* 144 */         lowerRight = PlasticLookAndFeel.getControlHighlight();
/*     */       } else {
/* 146 */         upperLeft = PlasticLookAndFeel.getControl();
/* 147 */         lowerRight = PlasticLookAndFeel.getControlHighlight().brighter();
/*     */       }
/* 149 */       g2.setPaint(new GradientPaint(x, y, upperLeft, x + w, y + h, lowerRight));
/* 150 */       g2.fillRect(x, y, w, h);
/*     */     }
/*     */ 
/*     */     private void drawFocus(Graphics2D g2, int x, int y, int width, int height) {
/* 154 */       g2.setPaint(new GradientPaint(
/* 155 */         x, 
/* 156 */         y, 
/* 157 */         PlasticLookAndFeel.getFocusColor().brighter(), 
/* 158 */         width, 
/* 159 */         height, 
/* 160 */         PlasticLookAndFeel.getFocusColor()));
/*     */ 
/* 162 */       g2.drawRect(x, y, width, height);
/* 163 */       g2.drawRect(x + 1, y + 1, width - 2, height - 2);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class RadioButtonIcon
/*     */     implements Icon, UIResource, Serializable
/*     */   {
/* 171 */     private static final int SIZE = LookUtils.IS_LOW_RESOLUTION ? 13 : 15;
/*     */ 
/* 173 */     private static final Stroke FOCUS_STROKE = new BasicStroke(2.0F);
/*     */ 
/* 175 */     public int getIconWidth() { return SIZE; } 
/* 176 */     public int getIconHeight() { return SIZE; }
/*     */ 
/*     */     public void paintIcon(Component c, Graphics g, int x, int y) {
/* 179 */       Graphics2D g2 = (Graphics2D)g;
/* 180 */       AbstractButton b = (AbstractButton)c;
/* 181 */       ButtonModel model = b.getModel();
/*     */ 
/* 183 */       Object hint = g2.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
/* 184 */       g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */ 
/* 186 */       drawFill(g2, model.isPressed(), x, y, SIZE - 1, SIZE - 1);
/*     */ 
/* 188 */       if ((model.isArmed()) && (!model.isPressed())) {
/* 189 */         drawFocus(g2, x + 1, y + 1, SIZE - 3, SIZE - 3);
/*     */       }
/* 191 */       if (model.isSelected()) {
/* 192 */         drawCheck(g2, c, model.isEnabled(), x + 4, y + 4, SIZE - 8, SIZE - 8);
/*     */       }
/* 194 */       drawBorder(g2, model.isEnabled(), x, y, SIZE - 1, SIZE - 1);
/* 195 */       g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, hint);
/*     */     }
/*     */ 
/*     */     private void drawBorder(Graphics2D g2, boolean enabled, int x, int y, int w, int h) {
/* 199 */       g2.setColor(enabled ? 
/* 200 */         PlasticLookAndFeel.getControlDarkShadow() : 
/* 201 */         MetalLookAndFeel.getControlDisabled());
/* 202 */       g2.drawOval(x, y, w, h);
/*     */     }
/*     */ 
/*     */     private void drawCheck(Graphics2D g2, Component c, boolean enabled, int x, int y, int w, int h) {
/* 206 */       g2.translate(x, y);
/* 207 */       if (enabled) {
/* 208 */         g2.setColor(UIManager.getColor("RadioButton.check"));
/* 209 */         g2.fillOval(0, 0, w, h);
/* 210 */         UIManager.getIcon("RadioButton.checkIcon").paintIcon(c, g2, 0, 0);
/*     */       } else {
/* 212 */         g2.setColor(MetalLookAndFeel.getControlDisabled());
/* 213 */         g2.fillOval(0, 0, w, h);
/*     */       }
/* 215 */       g2.translate(-x, -y);
/*     */     }
/*     */ 
/*     */     private void drawFill(Graphics2D g2, boolean pressed, int x, int y, int w, int h)
/*     */     {
/*     */       Color lowerRight;
/*     */       Color upperLeft;
/*     */       Color lowerRight;
/* 221 */       if (pressed) {
/* 222 */         Color upperLeft = MetalLookAndFeel.getControlShadow();
/* 223 */         lowerRight = PlasticLookAndFeel.getControlHighlight();
/*     */       } else {
/* 225 */         upperLeft = PlasticLookAndFeel.getControl();
/* 226 */         lowerRight = PlasticLookAndFeel.getControlHighlight().brighter();
/*     */       }
/* 228 */       g2.setPaint(new GradientPaint(x, y, upperLeft, x + w, y + h, lowerRight));
/* 229 */       g2.fillOval(x, y, w, h);
/*     */     }
/*     */ 
/*     */     private void drawFocus(Graphics2D g2, int x, int y, int w, int h) {
/* 233 */       g2.setPaint(
/* 234 */         new GradientPaint(
/* 235 */         x, 
/* 236 */         y, 
/* 237 */         PlasticLookAndFeel.getFocusColor().brighter(), 
/* 238 */         w, 
/* 239 */         h, 
/* 240 */         PlasticLookAndFeel.getFocusColor()));
/* 241 */       Stroke stroke = g2.getStroke();
/* 242 */       g2.setStroke(FOCUS_STROKE);
/* 243 */       g2.drawOval(x, y, w, h);
/* 244 */       g2.setStroke(stroke);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticXPIconFactory
 * JD-Core Version:    0.6.2
 */