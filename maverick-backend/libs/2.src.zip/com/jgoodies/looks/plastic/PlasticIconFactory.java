/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.io.Serializable;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*     */ 
/*     */ final class PlasticIconFactory
/*     */ {
/*     */   private static Icon checkBoxIcon;
/*     */   private static Icon checkBoxMenuItemIcon;
/*     */   private static Icon radioButtonMenuItemIcon;
/*     */   private static Icon menuArrowIcon;
/*     */   private static Icon expandedTreeIcon;
/*     */   private static Icon collapsedTreeIcon;
/*     */ 
/*     */   private static void drawCheck(Graphics g, int x, int y)
/*     */   {
/*  65 */     g.translate(x, y);
/*  66 */     g.drawLine(3, 5, 3, 5);
/*  67 */     g.fillRect(3, 6, 2, 2);
/*  68 */     g.drawLine(4, 8, 9, 3);
/*  69 */     g.drawLine(5, 8, 9, 4);
/*  70 */     g.drawLine(5, 9, 9, 5);
/*  71 */     g.translate(-x, -y);
/*     */   }
/*     */ 
/*     */   static Icon getCheckBoxIcon()
/*     */   {
/* 272 */     if (checkBoxIcon == null) {
/* 273 */       checkBoxIcon = new CheckBoxIcon();
/*     */     }
/* 275 */     return checkBoxIcon;
/*     */   }
/*     */ 
/*     */   static Icon getCheckBoxMenuItemIcon()
/*     */   {
/* 283 */     if (checkBoxMenuItemIcon == null) {
/* 284 */       checkBoxMenuItemIcon = new CheckBoxMenuItemIcon();
/*     */     }
/* 286 */     return checkBoxMenuItemIcon;
/*     */   }
/*     */ 
/*     */   static Icon getRadioButtonMenuItemIcon()
/*     */   {
/* 294 */     if (radioButtonMenuItemIcon == null) {
/* 295 */       radioButtonMenuItemIcon = new RadioButtonMenuItemIcon();
/*     */     }
/* 297 */     return radioButtonMenuItemIcon;
/*     */   }
/*     */ 
/*     */   static Icon getMenuArrowIcon()
/*     */   {
/* 305 */     if (menuArrowIcon == null) {
/* 306 */       menuArrowIcon = new MenuArrowIcon();
/*     */     }
/* 308 */     return menuArrowIcon;
/*     */   }
/*     */ 
/*     */   static Icon getExpandedTreeIcon()
/*     */   {
/* 316 */     if (expandedTreeIcon == null) {
/* 317 */       expandedTreeIcon = new ExpandedTreeIcon();
/*     */     }
/* 319 */     return expandedTreeIcon;
/*     */   }
/*     */ 
/*     */   static Icon getCollapsedTreeIcon()
/*     */   {
/* 326 */     if (collapsedTreeIcon == null) {
/* 327 */       collapsedTreeIcon = new CollapsedTreeIcon();
/*     */     }
/* 329 */     return collapsedTreeIcon;
/*     */   }
/*     */ 
/*     */   static Icon getComboBoxButtonIcon()
/*     */   {
/* 336 */     return new ComboBoxButtonIcon();
/*     */   }
/*     */ 
/*     */   private static class CheckBoxIcon
/*     */     implements Icon, UIResource, Serializable
/*     */   {
/*     */     private static final int SIZE = 13;
/*     */ 
/*     */     public int getIconWidth()
/*     */     {
/*  79 */       return 13; } 
/*  80 */     public int getIconHeight() { return 13; }
/*     */ 
/*     */     public void paintIcon(Component c, Graphics g, int x, int y) {
/*  83 */       JCheckBox cb = (JCheckBox)c;
/*  84 */       ButtonModel model = cb.getModel();
/*     */ 
/*  86 */       if (model.isEnabled()) {
/*  87 */         if (cb.isBorderPaintedFlat()) {
/*  88 */           g.setColor(PlasticLookAndFeel.getControlDarkShadow());
/*  89 */           g.drawRect(x, y, 11, 11);
/*     */ 
/*  91 */           g.setColor(PlasticLookAndFeel.getControlHighlight());
/*  92 */           g.fillRect(x + 1, y + 1, 10, 10);
/*  93 */         } else if ((model.isPressed()) && (model.isArmed())) {
/*  94 */           g.setColor(MetalLookAndFeel.getControlShadow());
/*  95 */           g.fillRect(x, y, 12, 12);
/*  96 */           PlasticUtils.drawPressed3DBorder(g, x, y, 13, 13);
/*     */         } else {
/*  98 */           PlasticUtils.drawFlush3DBorder(g, x, y, 13, 13);
/*     */         }
/* 100 */         g.setColor(MetalLookAndFeel.getControlInfo());
/*     */       } else {
/* 102 */         g.setColor(MetalLookAndFeel.getControlShadow());
/* 103 */         g.drawRect(x, y, 11, 11);
/*     */       }
/*     */ 
/* 106 */       if (model.isSelected())
/* 107 */         PlasticIconFactory.drawCheck(g, x, y);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class CheckBoxMenuItemIcon
/*     */     implements Icon, UIResource, Serializable
/*     */   {
/*     */     private static final int SIZE = 13;
/*     */ 
/*     */     public int getIconWidth()
/*     */     {
/* 118 */       return 13; } 
/* 119 */     public int getIconHeight() { return 13; }
/*     */ 
/*     */     public void paintIcon(Component c, Graphics g, int x, int y) {
/* 122 */       JMenuItem b = (JMenuItem)c;
/* 123 */       if (b.isSelected())
/* 124 */         PlasticIconFactory.drawCheck(g, x, y + 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class RadioButtonMenuItemIcon implements Icon, UIResource, Serializable
/*     */   {
/*     */     private static final int SIZE = 13;
/*     */ 
/*     */     public int getIconWidth()
/*     */     {
/* 134 */       return 13; } 
/* 135 */     public int getIconHeight() { return 13; }
/*     */ 
/*     */     public void paintIcon(Component c, Graphics g, int x, int y) {
/* 138 */       JMenuItem b = (JMenuItem)c;
/* 139 */       if (b.isSelected())
/* 140 */         drawDot(g, x, y);
/*     */     }
/*     */ 
/*     */     private void drawDot(Graphics g, int x, int y)
/*     */     {
/* 145 */       g.translate(x, y);
/* 146 */       g.drawLine(5, 4, 8, 4);
/* 147 */       g.fillRect(4, 5, 6, 4);
/* 148 */       g.drawLine(5, 9, 8, 9);
/* 149 */       g.translate(-x, -y);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class MenuArrowIcon implements Icon, UIResource, Serializable
/*     */   {
/*     */     private static final int WIDTH = 4;
/*     */     private static final int HEIGHT = 8;
/*     */ 
/*     */     public void paintIcon(Component c, Graphics g, int x, int y) {
/* 160 */       JMenuItem b = (JMenuItem)c;
/*     */ 
/* 162 */       g.translate(x, y);
/* 163 */       if (PlasticUtils.isLeftToRight(b)) {
/* 164 */         g.drawLine(0, 0, 0, 7);
/* 165 */         g.drawLine(1, 1, 1, 6);
/* 166 */         g.drawLine(2, 2, 2, 5);
/* 167 */         g.drawLine(3, 3, 3, 4);
/*     */       } else {
/* 169 */         g.drawLine(4, 0, 4, 7);
/* 170 */         g.drawLine(3, 1, 3, 6);
/* 171 */         g.drawLine(2, 2, 2, 5);
/* 172 */         g.drawLine(1, 3, 1, 4);
/*     */       }
/* 174 */       g.translate(-x, -y);
/*     */     }
/*     */     public int getIconWidth() {
/* 177 */       return 4; } 
/* 178 */     public int getIconHeight() { return 8; }
/*     */ 
/*     */   }
/*     */ 
/*     */   private static class ExpandedTreeIcon
/*     */     implements Icon, Serializable
/*     */   {
/*     */     protected static final int SIZE = 9;
/*     */     protected static final int HALF_SIZE = 4;
/*     */ 
/*     */     public void paintIcon(Component c, Graphics g, int x, int y)
/*     */     {
/* 192 */       Color backgroundColor = c.getBackground();
/*     */ 
/* 194 */       g.setColor(backgroundColor != null ? backgroundColor : Color.WHITE);
/* 195 */       g.fillRect(x, y, 8, 8);
/* 196 */       g.setColor(Color.GRAY);
/* 197 */       g.drawRect(x, y, 8, 8);
/* 198 */       g.setColor(Color.BLACK);
/* 199 */       g.drawLine(x + 2, y + 4, x + 6, y + 4);
/*     */     }
/*     */     public int getIconWidth() {
/* 202 */       return 9; } 
/* 203 */     public int getIconHeight() { return 9; }
/*     */ 
/*     */   }
/*     */ 
/*     */   private static class CollapsedTreeIcon extends PlasticIconFactory.ExpandedTreeIcon
/*     */   {
/*     */     public void paintIcon(Component c, Graphics g, int x, int y)
/*     */     {
/* 212 */       super.paintIcon(c, g, x, y);
/* 213 */       g.drawLine(x + 4, y + 2, x + 4, y + 6);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ComboBoxButtonIcon
/*     */     implements Icon, Serializable
/*     */   {
/*     */     public void paintIcon(Component c, Graphics g, int x, int y)
/*     */     {
/* 224 */       JComponent component = (JComponent)c;
/* 225 */       int iconWidth = getIconWidth();
/*     */ 
/* 227 */       g.translate(x, y);
/*     */ 
/* 229 */       g.setColor(component.isEnabled() ? 
/* 230 */         MetalLookAndFeel.getControlInfo() : 
/* 231 */         MetalLookAndFeel.getControlShadow());
/* 232 */       g.drawLine(0, 0, iconWidth - 1, 0);
/* 233 */       g.drawLine(1, 1, 1 + (iconWidth - 3), 1);
/* 234 */       g.drawLine(2, 2, 2 + (iconWidth - 5), 2);
/* 235 */       g.drawLine(3, 3, 3 + (iconWidth - 7), 3);
/*     */ 
/* 250 */       g.translate(-x, -y);
/*     */     }
/*     */     public int getIconWidth() {
/* 253 */       return 8; } 
/* 254 */     public int getIconHeight() { return 4; }
/*     */ 
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticIconFactory
 * JD-Core Version:    0.6.2
 */