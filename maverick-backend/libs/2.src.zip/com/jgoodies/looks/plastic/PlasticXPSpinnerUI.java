/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import com.jgoodies.looks.common.ExtBasicArrowButtonHandler;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ 
/*     */ public final class PlasticXPSpinnerUI extends PlasticSpinnerUI
/*     */ {
/*  69 */   private static final ExtBasicArrowButtonHandler nextButtonHandler = new ExtBasicArrowButtonHandler("increment", true);
/*     */ 
/*  71 */   private static final ExtBasicArrowButtonHandler previousButtonHandler = new ExtBasicArrowButtonHandler("decrement", false);
/*     */ 
/*     */   public static ComponentUI createUI(JComponent b)
/*     */   {
/*  56 */     return new PlasticXPSpinnerUI();
/*     */   }
/*     */ 
/*     */   protected Component createPreviousButton()
/*     */   {
/*  88 */     return new SpinnerXPArrowButton(5, previousButtonHandler);
/*     */   }
/*     */ 
/*     */   protected Component createNextButton()
/*     */   {
/* 106 */     return new SpinnerXPArrowButton(1, nextButtonHandler);
/*     */   }
/*     */ 
/*     */   private static class SpinnerXPArrowButton extends PlasticArrowButton
/*     */   {
/*     */     SpinnerXPArrowButton(int direction, ExtBasicArrowButtonHandler handler)
/*     */     {
/* 118 */       super(UIManager.getInt("ScrollBar.width") - 2, false);
/* 119 */       addActionListener(handler);
/* 120 */       addMouseListener(handler);
/*     */     }
/*     */ 
/*     */     protected int calculateArrowHeight(int height, int width) {
/* 124 */       int arrowHeight = Math.min((height - 4) / 3, (width - 4) / 3);
/* 125 */       return Math.max(arrowHeight, 3);
/*     */     }
/*     */ 
/*     */     protected boolean isPaintingNorthBottom() {
/* 129 */       return true;
/*     */     }
/*     */ 
/*     */     protected void paintNorth(Graphics g, boolean leftToRight, boolean isEnabled, Color arrowColor, boolean isPressed, int width, int height, int w, int h, int arrowHeight, int arrowOffset, boolean paintBottom)
/*     */     {
/* 136 */       if (!this.isFreeStanding) {
/* 137 */         height++;
/* 138 */         g.translate(0, -1);
/* 139 */         if (!leftToRight) {
/* 140 */           width++;
/* 141 */           g.translate(-1, 0);
/*     */         } else {
/* 143 */           width += 2;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 148 */       g.setColor(arrowColor);
/* 149 */       int startY = (h + 1 - arrowHeight) / 2;
/* 150 */       int startX = w / 2;
/*     */ 
/* 152 */       for (int line = 0; line < arrowHeight; line++) {
/* 153 */         g.fillRect(startX - line - arrowOffset, startY + line, 2 * (line + 1), 1);
/*     */       }
/*     */ 
/* 156 */       if (isEnabled) {
/* 157 */         Color shadowColor = UIManager.getColor("ScrollBar.darkShadow");
/*     */ 
/* 159 */         g.setColor(shadowColor);
/* 160 */         g.drawLine(0, 0, width - 2, 0);
/* 161 */         g.drawLine(0, 0, 0, height - 1);
/* 162 */         g.drawLine(width - 2, 1, width - 2, height - 1);
/* 163 */         if (paintBottom)
/* 164 */           g.fillRect(0, height - 1, width - 1, 1);
/*     */       }
/*     */       else {
/* 167 */         PlasticUtils.drawDisabledBorder(g, 0, 0, width, height + 1);
/* 168 */         if (paintBottom) {
/* 169 */           g.setColor(PlasticLookAndFeel.getControlShadow());
/* 170 */           g.fillRect(0, height - 1, width - 1, 1);
/*     */         }
/*     */       }
/* 173 */       if (!this.isFreeStanding) {
/* 174 */         height--;
/* 175 */         g.translate(0, 1);
/* 176 */         if (!leftToRight) {
/* 177 */           width--;
/* 178 */           g.translate(1, 0);
/*     */         } else {
/* 180 */           width -= 2;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     protected void paintSouth(Graphics g, boolean leftToRight, boolean isEnabled, Color arrowColor, boolean isPressed, int width, int height, int w, int h, int arrowHeight, int arrowOffset)
/*     */     {
/* 189 */       if (!this.isFreeStanding) {
/* 190 */         height++;
/* 191 */         if (!leftToRight) {
/* 192 */           width++;
/* 193 */           g.translate(-1, 0);
/*     */         } else {
/* 195 */           width += 2;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 200 */       g.setColor(arrowColor);
/*     */ 
/* 202 */       int startY = (h + 0 - arrowHeight) / 2 + arrowHeight - 1;
/* 203 */       int startX = w / 2;
/*     */ 
/* 207 */       for (int line = 0; line < arrowHeight; line++) {
/* 208 */         g.fillRect(startX - line - arrowOffset, startY - line, 2 * (line + 1), 1);
/*     */       }
/*     */ 
/* 211 */       if (isEnabled) {
/* 212 */         Color shadowColor = UIManager.getColor("ScrollBar.darkShadow");
/* 213 */         g.setColor(shadowColor);
/* 214 */         g.drawLine(0, 0, 0, height - 2);
/* 215 */         g.drawLine(width - 2, 0, width - 2, height - 2);
/*     */       }
/*     */       else {
/* 218 */         PlasticUtils.drawDisabledBorder(g, 0, -1, width, height + 1);
/*     */       }
/*     */ 
/* 221 */       if (!this.isFreeStanding) {
/* 222 */         height--;
/* 223 */         if (!leftToRight) {
/* 224 */           width--;
/* 225 */           g.translate(1, 0);
/*     */         } else {
/* 227 */           width -= 2;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticXPSpinnerUI
 * JD-Core Version:    0.6.2
 */