/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import com.jgoodies.looks.LookUtils;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.border.AbstractBorder;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.CompoundBorder;
/*     */ import javax.swing.plaf.BorderUIResource.CompoundBorderUIResource;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicBorders.MarginBorder;
/*     */ import javax.swing.plaf.metal.MetalBorders.ScrollPaneBorder;
/*     */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*     */ import javax.swing.text.JTextComponent;
/*     */ 
/*     */ final class PlasticXPBorders
/*     */ {
/*     */   private static Border buttonBorder;
/*     */   private static Border comboBoxArrowButtonBorder;
/*     */   private static Border comboBoxEditorBorder;
/*     */   private static Border scrollPaneBorder;
/*     */   private static Border textFieldBorder;
/*     */   private static Border toggleButtonBorder;
/*     */ 
/*     */   static Border getButtonBorder()
/*     */   {
/*  79 */     if (buttonBorder == null) {
/*  80 */       buttonBorder = new BorderUIResource.CompoundBorderUIResource(
/*  81 */         new XPButtonBorder(), 
/*  82 */         new BasicBorders.MarginBorder());
/*     */     }
/*  84 */     return buttonBorder;
/*     */   }
/*     */ 
/*     */   static Border getComboBoxArrowButtonBorder()
/*     */   {
/*  91 */     if (comboBoxArrowButtonBorder == null) {
/*  92 */       comboBoxArrowButtonBorder = new CompoundBorder(
/*  93 */         new XPComboBoxArrowButtonBorder(), 
/*  94 */         new BasicBorders.MarginBorder());
/*     */     }
/*  96 */     return comboBoxArrowButtonBorder;
/*     */   }
/*     */ 
/*     */   static Border getComboBoxEditorBorder()
/*     */   {
/* 103 */     if (comboBoxEditorBorder == null) {
/* 104 */       comboBoxEditorBorder = new CompoundBorder(
/* 105 */         new XPComboBoxEditorBorder(), 
/* 106 */         new BasicBorders.MarginBorder());
/*     */     }
/* 108 */     return comboBoxEditorBorder;
/*     */   }
/*     */ 
/*     */   static Border getScrollPaneBorder()
/*     */   {
/* 115 */     if (scrollPaneBorder == null) {
/* 116 */       scrollPaneBorder = new XPScrollPaneBorder();
/*     */     }
/* 118 */     return scrollPaneBorder;
/*     */   }
/*     */ 
/*     */   static Border getTextFieldBorder()
/*     */   {
/* 125 */     if (textFieldBorder == null) {
/* 126 */       textFieldBorder = new BorderUIResource.CompoundBorderUIResource(
/* 127 */         new XPTextFieldBorder(), 
/* 128 */         new BasicBorders.MarginBorder());
/*     */     }
/* 130 */     return textFieldBorder;
/*     */   }
/*     */ 
/*     */   static Border getToggleButtonBorder()
/*     */   {
/* 137 */     if (toggleButtonBorder == null) {
/* 138 */       toggleButtonBorder = new BorderUIResource.CompoundBorderUIResource(
/* 139 */         new XPButtonBorder(), 
/* 140 */         new BasicBorders.MarginBorder());
/*     */     }
/* 142 */     return toggleButtonBorder;
/*     */   }
/*     */ 
/*     */   private static class XPButtonBorder extends AbstractBorder
/*     */     implements UIResource
/*     */   {
/* 150 */     protected static final Insets INSETS = LookUtils.IS_LOW_RESOLUTION ? 
/* 151 */       new Insets(3, 2, 3, 2) : 
/* 152 */       new Insets(2, 2, 2, 2);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 155 */       AbstractButton button = (AbstractButton)c;
/* 156 */       ButtonModel model = button.getModel();
/*     */ 
/* 158 */       if (!model.isEnabled()) {
/* 159 */         PlasticXPUtils.drawDisabledButtonBorder(g, x, y, w, h);
/* 160 */         return;
/*     */       }
/*     */ 
/* 163 */       boolean isPressed = (model.isPressed()) && (model.isArmed());
/* 164 */       boolean isDefault = ((button instanceof JButton)) && 
/* 165 */         (((JButton)button).isDefaultButton());
/* 166 */       if (button.isFocusPainted()) button.hasFocus(); boolean isFocused = false;
/*     */ 
/* 168 */       if (isPressed)
/* 169 */         PlasticXPUtils.drawPressedButtonBorder(g, x, y, w, h);
/* 170 */       else if (isFocused)
/* 171 */         PlasticXPUtils.drawFocusedButtonBorder(g, x, y, w, h);
/* 172 */       else if (isDefault)
/* 173 */         PlasticXPUtils.drawDefaultButtonBorder(g, x, y, w, h);
/*     */       else
/* 175 */         PlasticXPUtils.drawPlainButtonBorder(g, x, y, w, h); 
/*     */     }
/*     */ 
/* 178 */     public Insets getBorderInsets(Component c) { return INSETS; }
/*     */ 
/*     */     public Insets getBorderInsets(Component c, Insets newInsets) {
/* 181 */       newInsets.top = INSETS.top;
/* 182 */       newInsets.left = INSETS.left;
/* 183 */       newInsets.bottom = INSETS.bottom;
/* 184 */       newInsets.right = INSETS.right;
/* 185 */       return newInsets;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class XPComboBoxArrowButtonBorder extends AbstractBorder
/*     */     implements UIResource
/*     */   {
/* 195 */     protected static final Insets INSETS = new Insets(1, 1, 1, 1);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
/* 198 */       PlasticComboBoxButton button = (PlasticComboBoxButton)c;
/* 199 */       JComboBox comboBox = button.getComboBox();
/* 200 */       ButtonModel model = button.getModel();
/*     */ 
/* 202 */       if (!model.isEnabled()) {
/* 203 */         PlasticXPUtils.drawDisabledButtonBorder(g, x, y, w, h);
/*     */       } else {
/* 205 */         boolean isPressed = (model.isPressed()) && (model.isArmed());
/* 206 */         comboBox.hasFocus(); boolean isFocused = false;
/* 207 */         if (isPressed)
/* 208 */           PlasticXPUtils.drawPressedButtonBorder(g, x, y, w, h);
/* 209 */         else if (isFocused)
/* 210 */           PlasticXPUtils.drawFocusedButtonBorder(g, x, y, w, h);
/*     */         else
/* 212 */           PlasticXPUtils.drawPlainButtonBorder(g, x, y, w, h);
/*     */       }
/* 214 */       if (comboBox.isEditable())
/*     */       {
/* 216 */         g.setColor(model.isEnabled() ? 
/* 217 */           PlasticLookAndFeel.getControlDarkShadow() : 
/* 218 */           MetalLookAndFeel.getControlShadow());
/* 219 */         g.fillRect(x, y, 1, 1);
/* 220 */         g.fillRect(x, y + h - 1, 1, 1);
/*     */       }
/*     */     }
/*     */ 
/* 224 */     public Insets getBorderInsets(Component c) { return INSETS; }
/*     */ 
/*     */   }
/*     */ 
/*     */   private static class XPComboBoxEditorBorder extends AbstractBorder
/*     */   {
/* 233 */     private static final Insets INSETS = new Insets(1, 1, 1, 0);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
/* 236 */       g.setColor(c.isEnabled() ? 
/* 237 */         PlasticLookAndFeel.getControlDarkShadow() : 
/* 238 */         MetalLookAndFeel.getControlShadow());
/* 239 */       PlasticXPUtils.drawRect(g, x, y, w + 1, h - 1);
/*     */     }
/*     */     public Insets getBorderInsets(Component c) {
/* 242 */       return INSETS;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class XPTextFieldBorder extends AbstractBorder
/*     */   {
/* 251 */     private static final Insets INSETS = new Insets(1, 1, 1, 1);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 255 */       if ((!(c instanceof JTextComponent)) || 
/* 256 */         (!c.isEnabled()) || (!((JTextComponent)c).isEditable()));
/* 255 */       boolean enabled = 
/* 258 */         c.isEnabled();
/*     */ 
/* 260 */       g.setColor(enabled ? 
/* 261 */         PlasticLookAndFeel.getControlDarkShadow() : 
/* 262 */         MetalLookAndFeel.getControlShadow());
/* 263 */       PlasticXPUtils.drawRect(g, x, y, w - 1, h - 1);
/*     */     }
/*     */     public Insets getBorderInsets(Component c) {
/* 266 */       return INSETS;
/*     */     }
/*     */     public Insets getBorderInsets(Component c, Insets newInsets) {
/* 269 */       newInsets.top = INSETS.top;
/* 270 */       newInsets.left = INSETS.left;
/* 271 */       newInsets.bottom = INSETS.bottom;
/* 272 */       newInsets.right = INSETS.right;
/* 273 */       return newInsets;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class XPScrollPaneBorder extends MetalBorders.ScrollPaneBorder
/*     */   {
/* 284 */     private static final Insets INSETS = new Insets(1, 1, 1, 1);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
/* 287 */       g.setColor(c.isEnabled() ? 
/* 288 */         PlasticLookAndFeel.getControlDarkShadow() : 
/* 289 */         MetalLookAndFeel.getControlShadow());
/* 290 */       PlasticXPUtils.drawRect(g, x, y, w - 1, h - 1);
/*     */     }
/*     */     public Insets getBorderInsets(Component c) {
/* 293 */       return INSETS;
/*     */     }
/*     */     public Insets getBorderInsets(Component c, Insets newInsets) {
/* 296 */       newInsets.top = INSETS.top;
/* 297 */       newInsets.left = INSETS.left;
/* 298 */       newInsets.bottom = INSETS.bottom;
/* 299 */       newInsets.right = INSETS.right;
/* 300 */       return newInsets;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticXPBorders
 * JD-Core Version:    0.6.2
 */