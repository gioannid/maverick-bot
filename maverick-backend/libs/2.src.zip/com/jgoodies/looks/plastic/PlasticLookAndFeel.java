/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import com.jgoodies.looks.FontSizeHints;
/*     */ import com.jgoodies.looks.LookUtils;
/*     */ import com.jgoodies.looks.Options;
/*     */ import com.jgoodies.looks.common.MinimumSizedIcon;
/*     */ import com.jgoodies.looks.common.ShadowPopupFactory;
/*     */ import com.jgoodies.looks.plastic.theme.SkyBluerTahoma;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.UIDefaults;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.BorderUIResource;
/*     */ import javax.swing.plaf.ColorUIResource;
/*     */ import javax.swing.plaf.FontUIResource;
/*     */ import javax.swing.plaf.InsetsUIResource;
/*     */ import javax.swing.plaf.basic.BasicBorders.MarginBorder;
/*     */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*     */ 
/*     */ public class PlasticLookAndFeel extends MetalLookAndFeel
/*     */ {
/*     */   public static final String BORDER_STYLE_KEY = "Plastic.borderStyle";
/*     */   public static final String IS_3D_KEY = "Plastic.is3D";
/*     */   public static final String DEFAULT_THEME_KEY = "Plastic.defaultTheme";
/*     */   public static final String HIGH_CONTRAST_FOCUS_ENABLED_KEY = "Plastic.highContrastFocus";
/*     */   protected static final String TAB_STYLE_KEY = "Plastic.tabStyle";
/*     */   public static final String TAB_STYLE_DEFAULT_VALUE = "default";
/*     */   public static final String TAB_STYLE_METAL_VALUE = "metal";
/* 124 */   private static boolean useMetalTabs = LookUtils.getSystemProperty("Plastic.tabStyle", "")
/* 124 */     .equalsIgnoreCase("metal");
/*     */ 
/* 130 */   public static boolean useHighContrastFocusColors = LookUtils.getSystemProperty("Plastic.highContrastFocus") != null;
/*     */   private static List installedThemes;
/*     */   private static PlasticTheme myCurrentTheme;
/* 142 */   private static boolean is3DEnabled = false;
/*     */   private static FontSizeHints fontSizeHints;
/*     */   private static final String THEME_CLASSNAME_PREFIX = "com.jgoodies.looks.plastic.theme.";
/*     */ 
/*     */   public PlasticLookAndFeel()
/*     */   {
/* 153 */     if (myCurrentTheme == null)
/* 154 */       setMyCurrentTheme(createMyDefaultTheme());
/*     */   }
/*     */ 
/*     */   public String getID() {
/* 158 */     return "JGoodies Plastic";
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 162 */     return "JGoodies Plastic";
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/* 166 */     return "The JGoodies Plastic Look and Feel - © 2001-2005 JGoodies Karsten Lentzsch";
/*     */   }
/*     */ 
/*     */   public static FontSizeHints getFontSizeHints()
/*     */   {
/* 182 */     return fontSizeHints != null ? 
/* 183 */       fontSizeHints : 
/* 184 */       Options.getGlobalFontSizeHints();
/*     */   }
/*     */ 
/*     */   public static void setFontSizeHints(FontSizeHints newHints)
/*     */   {
/* 195 */     fontSizeHints = newHints;
/*     */   }
/*     */ 
/*     */   protected boolean is3DEnabled() {
/* 199 */     return is3DEnabled;
/*     */   }
/*     */ 
/*     */   public static void set3DEnabled(boolean b) {
/* 203 */     is3DEnabled = b;
/*     */   }
/*     */ 
/*     */   public static String getTabStyle() {
/* 207 */     return useMetalTabs ? "metal" : "default";
/*     */   }
/*     */ 
/*     */   public static void setTabStyle(String tabStyle) {
/* 211 */     useMetalTabs = tabStyle.equalsIgnoreCase("metal");
/*     */   }
/*     */ 
/*     */   public static boolean getHighContrastFocusColorsEnabled() {
/* 215 */     return useHighContrastFocusColors;
/*     */   }
/*     */ 
/*     */   public static void setHighContrastFocusColorsEnabled(boolean b) {
/* 219 */     useHighContrastFocusColors = b;
/*     */   }
/*     */ 
/*     */   public void initialize()
/*     */   {
/* 231 */     super.initialize();
/* 232 */     ShadowPopupFactory.install();
/*     */   }
/*     */ 
/*     */   public void uninitialize()
/*     */   {
/* 243 */     super.uninitialize();
/* 244 */     ShadowPopupFactory.uninstall();
/*     */   }
/*     */ 
/*     */   protected void initClassDefaults(UIDefaults table)
/*     */   {
/* 256 */     super.initClassDefaults(table);
/*     */ 
/* 258 */     String PLASTIC_PREFIX = "com.jgoodies.looks.plastic.Plastic";
/* 259 */     String COMMON_PREFIX = "com.jgoodies.looks.common.ExtBasic";
/*     */ 
/* 262 */     Object[] uiDefaults = { 
/* 264 */       "ButtonUI", PLASTIC_PREFIX + "ButtonUI", 
/* 265 */       "ToggleButtonUI", PLASTIC_PREFIX + "ToggleButtonUI", 
/* 268 */       "ComboBoxUI", PLASTIC_PREFIX + "ComboBoxUI", 
/* 269 */       "ScrollBarUI", PLASTIC_PREFIX + "ScrollBarUI", 
/* 270 */       "SpinnerUI", PLASTIC_PREFIX + "SpinnerUI", 
/* 273 */       "MenuBarUI", PLASTIC_PREFIX + "MenuBarUI", 
/* 274 */       "ToolBarUI", PLASTIC_PREFIX + "ToolBarUI", 
/* 277 */       "MenuUI", PLASTIC_PREFIX + "MenuUI", 
/* 278 */       "MenuItemUI", COMMON_PREFIX + "MenuItemUI", 
/* 279 */       "CheckBoxMenuItemUI", COMMON_PREFIX + "CheckBoxMenuItemUI", 
/* 280 */       "RadioButtonMenuItemUI", COMMON_PREFIX + "RadioButtonMenuItemUI", 
/* 283 */       "PopupMenuSeparatorUI", COMMON_PREFIX + "PopupMenuSeparatorUI", 
/* 286 */       "OptionPaneUI", PLASTIC_PREFIX + "OptionPaneUI", 
/* 289 */       "ScrollPaneUI", PLASTIC_PREFIX + "ScrollPaneUI", 
/* 292 */       "SplitPaneUI", PLASTIC_PREFIX + "SplitPaneUI", 
/* 295 */       "TreeUI", PLASTIC_PREFIX + "TreeUI", 
/* 298 */       "InternalFrameUI", PLASTIC_PREFIX + "InternalFrameUI", 
/* 301 */       "SeparatorUI", PLASTIC_PREFIX + "SeparatorUI", 
/* 302 */       "ToolBarSeparatorUI", PLASTIC_PREFIX + "ToolBarSeparatorUI" };
/*     */ 
/* 305 */     table.putDefaults(uiDefaults);
/* 306 */     if (!useMetalTabs)
/*     */     {
/* 308 */       table.put("TabbedPaneUI", PLASTIC_PREFIX + "TabbedPaneUI");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void initComponentDefaults(UIDefaults table)
/*     */   {
/* 314 */     super.initComponentDefaults(table);
/*     */ 
/* 316 */     Object marginBorder = new BasicBorders.MarginBorder();
/*     */ 
/* 318 */     Object buttonBorder = PlasticBorders.getButtonBorder();
/* 319 */     Object menuItemBorder = PlasticBorders.getMenuItemBorder();
/* 320 */     Object textFieldBorder = PlasticBorders.getTextFieldBorder();
/* 321 */     Object toggleButtonBorder = PlasticBorders.getToggleButtonBorder();
/*     */ 
/* 323 */     Object popupMenuBorder = PlasticBorders.getPopupMenuBorder();
/*     */ 
/* 325 */     Object scrollPaneBorder = PlasticBorders.getScrollPaneBorder();
/* 326 */     Object tableHeaderBorder = new BorderUIResource(
/* 327 */       (Border)table.get("TableHeader.cellBorder"));
/*     */ 
/* 329 */     Object menuBarEmptyBorder = marginBorder;
/* 330 */     Object menuBarSeparatorBorder = PlasticBorders.getSeparatorBorder();
/* 331 */     Object menuBarEtchedBorder = PlasticBorders.getEtchedBorder();
/* 332 */     Object menuBarHeaderBorder = PlasticBorders.getMenuBarHeaderBorder();
/*     */ 
/* 334 */     Object toolBarEmptyBorder = marginBorder;
/* 335 */     Object toolBarSeparatorBorder = PlasticBorders.getSeparatorBorder();
/* 336 */     Object toolBarEtchedBorder = PlasticBorders.getEtchedBorder();
/* 337 */     Object toolBarHeaderBorder = PlasticBorders.getToolBarHeaderBorder();
/*     */ 
/* 339 */     Object internalFrameBorder = getInternalFrameBorder();
/* 340 */     Object paletteBorder = getPaletteBorder();
/*     */ 
/* 342 */     Color controlColor = table.getColor("control");
/*     */ 
/* 344 */     Object checkBoxIcon = PlasticIconFactory.getCheckBoxIcon();
/* 345 */     Object checkBoxMargin = new InsetsUIResource(2, 0, 2, 1);
/*     */ 
/* 347 */     Object defaultButtonMargin = LookUtils.createButtonMargin(false);
/* 348 */     Object narrowButtonMargin = LookUtils.createButtonMargin(true);
/*     */ 
/* 351 */     Object textInsets = new InsetsUIResource(1, 2, 1, 2);
/* 352 */     Object wrappedTextInsets = new InsetsUIResource(2, 3, 1, 2);
/*     */ 
/* 354 */     Object menuItemMargin = LookUtils.IS_LOW_RESOLUTION ? 
/* 355 */       new InsetsUIResource(3, 0, 3, 0) : 
/* 356 */       new InsetsUIResource(2, 0, 2, 0);
/* 357 */     Object menuMargin = new InsetsUIResource(2, 4, 2, 4);
/*     */ 
/* 359 */     Icon menuItemCheckIcon = new MinimumSizedIcon();
/* 360 */     Icon checkBoxMenuItemIcon = PlasticIconFactory.getCheckBoxMenuItemIcon();
/* 361 */     Icon radioButtonMenuItemIcon = PlasticIconFactory.getRadioButtonMenuItemIcon();
/*     */ 
/* 363 */     Color menuItemForeground = table.getColor("MenuItem.foreground");
/*     */ 
/* 366 */     int treeFontSize = table.getFont("Tree.font").getSize();
/* 367 */     Integer rowHeight = new Integer(treeFontSize + 6);
/* 368 */     Object treeExpandedIcon = PlasticIconFactory.getExpandedTreeIcon();
/* 369 */     Object treeCollapsedIcon = PlasticIconFactory.getCollapsedTreeIcon();
/* 370 */     ColorUIResource gray = new ColorUIResource(Color.GRAY);
/*     */ 
/* 372 */     Boolean is3D = Boolean.valueOf(is3DEnabled());
/*     */ 
/* 374 */     Object[] defaults = { 
/* 375 */       "Button.border", buttonBorder, 
/* 376 */       "Button.margin", defaultButtonMargin, 
/* 377 */       "Button.narrowMargin", narrowButtonMargin, 
/* 379 */       "CheckBox.margin", checkBoxMargin, 
/* 382 */       "CheckBox.icon", checkBoxIcon, 
/* 384 */       "CheckBoxMenuItem.border", menuItemBorder, 
/* 385 */       "CheckBoxMenuItem.margin", menuItemMargin, 
/* 386 */       "CheckBoxMenuItem.checkIcon", checkBoxMenuItemIcon, 
/* 387 */       "CheckBoxMenuItem.background", getMenuItemBackground(), 
/* 388 */       "CheckBoxMenuItem.selectionForeground", getMenuItemSelectedForeground(), 
/* 389 */       "CheckBoxMenuItem.selectionBackground", getMenuItemSelectedBackground(), 
/* 390 */       "CheckBoxMenuItem.acceleratorForeground", menuItemForeground, 
/* 391 */       "CheckBoxMenuItem.acceleratorSelectionForeground", getMenuItemSelectedForeground(), 
/* 392 */       "CheckBoxMenuItem.acceleratorSelectionBackground", getMenuItemSelectedBackground(), 
/* 395 */       "ComboBox.selectionForeground", getMenuSelectedForeground(), 
/* 396 */       "ComboBox.selectionBackground", getMenuSelectedBackground(), 
/* 397 */       "ComboBox.arrowButtonBorder", PlasticBorders.getComboBoxArrowButtonBorder(), 
/* 398 */       "ComboBox.editorBorder", PlasticBorders.getComboBoxEditorBorder(), 
/* 399 */       "ComboBox.editorColumns", new Integer(5), 
/* 401 */       "EditorPane.margin", wrappedTextInsets, 
/* 403 */       "InternalFrame.border", internalFrameBorder, 
/* 404 */       "InternalFrame.paletteBorder", paletteBorder, 
/* 406 */       "List.font", getControlTextFont(), 
/* 407 */       "Menu.border", PlasticBorders.getMenuBorder(), 
/* 408 */       "Menu.margin", menuMargin, 
/* 409 */       "Menu.arrowIcon", PlasticIconFactory.getMenuArrowIcon(), 
/* 411 */       "MenuBar.emptyBorder", menuBarEmptyBorder, 
/* 412 */       "MenuBar.separatorBorder", menuBarSeparatorBorder, 
/* 413 */       "MenuBar.etchedBorder", menuBarEtchedBorder, 
/* 414 */       "MenuBar.headerBorder", menuBarHeaderBorder, 
/* 416 */       "MenuItem.border", menuItemBorder, 
/* 417 */       "MenuItem.checkIcon", menuItemCheckIcon, 
/* 418 */       "MenuItem.margin", menuItemMargin, 
/* 419 */       "MenuItem.background", getMenuItemBackground(), 
/* 420 */       "MenuItem.selectionForeground", getMenuItemSelectedForeground(), 
/* 421 */       "MenuItem.selectionBackground", getMenuItemSelectedBackground(), 
/* 422 */       "MenuItem.acceleratorForeground", menuItemForeground, 
/* 423 */       "MenuItem.acceleratorSelectionForeground", getMenuItemSelectedForeground(), 
/* 424 */       "MenuItem.acceleratorSelectionBackground", getMenuItemSelectedBackground(), 
/* 426 */       "OptionPane.errorIcon", makeIcon(getClass(), "icons/Error.png"), 
/* 427 */       "OptionPane.informationIcon", makeIcon(getClass(), "icons/Inform.png"), 
/* 428 */       "OptionPane.warningIcon", makeIcon(getClass(), "icons/Warn.png"), 
/* 429 */       "OptionPane.questionIcon", makeIcon(getClass(), "icons/Question.png"), 
/* 432 */       "FileView.computerIcon", makeIcon(getClass(), "icons/Computer.gif"), 
/* 433 */       "FileView.directoryIcon", makeIcon(getClass(), "icons/TreeClosed.gif"), 
/* 434 */       "FileView.fileIcon", makeIcon(getClass(), "icons/File.gif"), 
/* 435 */       "FileView.floppyDriveIcon", makeIcon(getClass(), "icons/FloppyDrive.gif"), 
/* 436 */       "FileView.hardDriveIcon", makeIcon(getClass(), "icons/HardDrive.gif"), 
/* 437 */       "FileChooser.homeFolderIcon", makeIcon(getClass(), "icons/HomeFolder.gif"), 
/* 438 */       "FileChooser.newFolderIcon", makeIcon(getClass(), "icons/NewFolder.gif"), 
/* 439 */       "FileChooser.upFolderIcon", makeIcon(getClass(), "icons/UpFolder.gif"), 
/* 440 */       "Tree.closedIcon", makeIcon(getClass(), "icons/TreeClosed.gif"), 
/* 441 */       "Tree.openIcon", makeIcon(getClass(), "icons/TreeOpen.gif"), 
/* 442 */       "Tree.leafIcon", makeIcon(getClass(), "icons/TreeLeaf.gif"), 
/* 444 */       "FormattedTextField.border", textFieldBorder, 
/* 445 */       "FormattedTextField.margin", textInsets, 
/* 447 */       "PasswordField.border", textFieldBorder, 
/* 448 */       "PasswordField.margin", textInsets, 
/* 450 */       "PopupMenu.border", popupMenuBorder, 
/* 451 */       "PopupMenuSeparator.margin", new InsetsUIResource(3, 4, 3, 4), 
/* 453 */       "RadioButton.margin", checkBoxMargin, 
/* 454 */       "RadioButtonMenuItem.border", menuItemBorder, 
/* 455 */       "RadioButtonMenuItem.checkIcon", radioButtonMenuItemIcon, 
/* 456 */       "RadioButtonMenuItem.margin", menuItemMargin, 
/* 457 */       "RadioButtonMenuItem.background", getMenuItemBackground(), 
/* 458 */       "RadioButtonMenuItem.selectionForeground", getMenuItemSelectedForeground(), 
/* 459 */       "RadioButtonMenuItem.selectionBackground", getMenuItemSelectedBackground(), 
/* 460 */       "RadioButtonMenuItem.acceleratorForeground", menuItemForeground, 
/* 461 */       "RadioButtonMenuItem.acceleratorSelectionForeground", getMenuItemSelectedForeground(), 
/* 462 */       "RadioButtonMenuItem.acceleratorSelectionBackground", getMenuItemSelectedBackground(), 
/* 463 */       "Separator.foreground", getControlDarkShadow(), 
/* 464 */       "ScrollPane.border", scrollPaneBorder, 
/* 465 */       "ScrollPane.etchedBorder", scrollPaneBorder, 
/* 468 */       "SimpleInternalFrame.activeTitleForeground", getSimpleInternalFrameForeground(), 
/* 469 */       "SimpleInternalFrame.activeTitleBackground", getSimpleInternalFrameBackground(), 
/* 471 */       "Spinner.border", PlasticBorders.getFlush3DBorder(), 
/* 472 */       "Spinner.defaultEditorInsets", textInsets, 
/* 474 */       "SplitPane.dividerSize", new Integer(7), 
/* 475 */       "TabbedPane.focus", getFocusColor(), 
/* 476 */       "TabbedPane.tabInsets", new InsetsUIResource(1, 9, 1, 8), 
/* 477 */       "Table.foreground", table.get("textText"), 
/* 478 */       "Table.gridColor", controlColor, 
/* 479 */       "Table.scrollPaneBorder", scrollPaneBorder, 
/* 480 */       "TableHeader.cellBorder", tableHeaderBorder, 
/* 481 */       "TextArea.margin", wrappedTextInsets, 
/* 482 */       "TextField.border", textFieldBorder, 
/* 483 */       "TextField.margin", textInsets, 
/* 484 */       "TitledBorder.font", getTitleTextFont(), 
/* 485 */       "TitledBorder.titleColor", getTitleTextColor(), 
/* 486 */       "ToggleButton.border", toggleButtonBorder, 
/* 487 */       "ToggleButton.margin", defaultButtonMargin, 
/* 488 */       "ToggleButton.narrowMargin", narrowButtonMargin, 
/* 490 */       "ToolBar.emptyBorder", toolBarEmptyBorder, 
/* 491 */       "ToolBar.separatorBorder", toolBarSeparatorBorder, 
/* 492 */       "ToolBar.etchedBorder", toolBarEtchedBorder, 
/* 493 */       "ToolBar.headerBorder", toolBarHeaderBorder, 
/* 495 */       "ToolTip.hideAccelerator", Boolean.TRUE, 
/* 497 */       "Tree.expandedIcon", treeExpandedIcon, 
/* 498 */       "Tree.collapsedIcon", treeCollapsedIcon, 
/* 499 */       "Tree.line", gray, 
/* 500 */       "Tree.hash", gray, 
/* 501 */       "Tree.rowHeight", rowHeight, 
/* 503 */       "Button.is3DEnabled", is3D, 
/* 504 */       "ComboBox.is3DEnabled", is3D, 
/* 505 */       "MenuBar.is3DEnabled", is3D, 
/* 506 */       "ToolBar.is3DEnabled", is3D, 
/* 507 */       "ScrollBar.is3DEnabled", is3D, 
/* 508 */       "ToggleButton.is3DEnabled", is3D, 
/* 512 */       "CheckBox.border", marginBorder, 
/* 513 */       "RadioButton.border", marginBorder, 
/* 516 */       "ProgressBar.selectionForeground", getSystemTextColor(), 
/* 517 */       "ProgressBar.selectionBackground", getSystemTextColor() };
/*     */ 
/* 519 */     table.putDefaults(defaults);
/*     */ 
/* 522 */     String soundPathPrefix = "/javax/swing/plaf/metal/";
/* 523 */     Object[] auditoryCues = (Object[])table.get("AuditoryCues.allAuditoryCues");
/* 524 */     if (auditoryCues != null) {
/* 525 */       Object[] audioDefaults = new String[auditoryCues.length * 2];
/* 526 */       for (int i = 0; i < auditoryCues.length; i++) {
/* 527 */         Object auditoryCue = auditoryCues[i];
/* 528 */         audioDefaults[(2 * i)] = auditoryCue;
/* 529 */         audioDefaults[(2 * i + 1)] = (soundPathPrefix + table.getString(auditoryCue));
/*     */       }
/* 531 */       table.putDefaults(audioDefaults);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void initSystemColorDefaults(UIDefaults table)
/*     */   {
/* 543 */     super.initSystemColorDefaults(table);
/* 544 */     table.put("unifiedControlShadow", table.getColor("controlDkShadow"));
/* 545 */     table.put("primaryControlHighlight", getPrimaryControlHighlight());
/*     */   }
/*     */ 
/*     */   public static PlasticTheme createMyDefaultTheme()
/*     */   {
/* 560 */     String defaultName = 
/* 562 */       LookUtils.IS_OS_WINDOWS_MODERN ? "DesertBluer" : LookUtils.IS_LAF_WINDOWS_XP_ENABLED ? 
/* 561 */       "ExperienceBlue" : 
/* 562 */       "SkyBlue";
/*     */ 
/* 564 */     String userName = LookUtils.getSystemProperty("Plastic.defaultTheme", "");
/* 565 */     boolean overridden = userName.length() > 0;
/* 566 */     String themeName = overridden ? userName : defaultName;
/* 567 */     PlasticTheme theme = createTheme(themeName);
/* 568 */     PlasticTheme result = theme != null ? theme : new SkyBluerTahoma();
/*     */ 
/* 571 */     if (overridden) {
/* 572 */       String className = theme.getClass().getName().substring(
/* 573 */         "com.jgoodies.looks.plastic.theme.".length());
/* 574 */       if (className.equals(userName)) {
/* 575 */         LookUtils.log("I have successfully installed the '" + theme.getName() + "' theme.");
/*     */       } else {
/* 577 */         LookUtils.log("I could not install the Plastic theme '" + userName + "'.");
/* 578 */         LookUtils.log("I have installed the '" + theme.getName() + "' theme, instead.");
/*     */       }
/*     */     }
/* 581 */     return result;
/*     */   }
/*     */ 
/*     */   public static List getInstalledThemes()
/*     */   {
/* 593 */     if (installedThemes == null) {
/* 594 */       installDefaultThemes();
/*     */     }
/* 596 */     Collections.sort(installedThemes, new PlasticLookAndFeel.1());
/*     */ 
/* 604 */     return installedThemes;
/*     */   }
/*     */ 
/*     */   protected static void installDefaultThemes()
/*     */   {
/* 612 */     installedThemes = new ArrayList();
/* 613 */     String[] themeNames = { 
/* 614 */       "BrownSugar", 
/* 615 */       "DarkStar", 
/* 616 */       "DesertBlue", 
/* 617 */       "DesertBluer", 
/* 618 */       "DesertGreen", 
/* 619 */       "DesertRed", 
/* 620 */       "DesertYellow", 
/* 621 */       "ExperienceBlue", 
/* 622 */       "ExperienceGreen", 
/* 623 */       "Silver", 
/* 624 */       "SkyBlue", 
/* 625 */       "SkyBluer", 
/* 626 */       "SkyBluerTahoma", 
/* 627 */       "SkyGreen", 
/* 628 */       "SkyKrupp", 
/* 629 */       "SkyPink", 
/* 630 */       "SkyRed", 
/* 631 */       "SkyYellow" };
/* 632 */     for (int i = themeNames.length - 1; i >= 0; i--)
/* 633 */       installTheme(createTheme(themeNames[i]));
/*     */   }
/*     */ 
/*     */   protected static PlasticTheme createTheme(String themeName)
/*     */   {
/* 645 */     String className = "com.jgoodies.looks.plastic.theme." + themeName;
/*     */     try {
/* 647 */       Class cl = Class.forName(className);
/* 648 */       return (PlasticTheme)cl.newInstance();
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException) {
/*     */     }
/*     */     catch (IllegalAccessException localIllegalAccessException) {
/*     */     }
/*     */     catch (InstantiationException localInstantiationException) {
/*     */     }
/* 656 */     LookUtils.log("Can't create theme " + className);
/* 657 */     return null;
/*     */   }
/*     */ 
/*     */   public static void installTheme(PlasticTheme theme)
/*     */   {
/* 667 */     if (installedThemes == null)
/* 668 */       installDefaultThemes();
/* 669 */     installedThemes.add(theme);
/*     */   }
/*     */ 
/*     */   public static PlasticTheme getMyCurrentTheme()
/*     */   {
/* 679 */     return myCurrentTheme;
/*     */   }
/*     */ 
/*     */   public static void setMyCurrentTheme(PlasticTheme theme)
/*     */   {
/* 689 */     myCurrentTheme = theme;
/* 690 */     setCurrentTheme(theme);
/*     */   }
/*     */ 
/*     */   public static BorderUIResource getInternalFrameBorder()
/*     */   {
/* 697 */     return new BorderUIResource(PlasticBorders.getInternalFrameBorder());
/*     */   }
/*     */ 
/*     */   public static BorderUIResource getPaletteBorder() {
/* 701 */     return new BorderUIResource(PlasticBorders.getPaletteBorder());
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getPrimaryControlDarkShadow()
/*     */   {
/* 710 */     return getMyCurrentTheme().getPrimaryControlDarkShadow();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getPrimaryControlHighlight() {
/* 714 */     return getMyCurrentTheme().getPrimaryControlHighlight();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getPrimaryControlInfo() {
/* 718 */     return getMyCurrentTheme().getPrimaryControlInfo();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getPrimaryControlShadow() {
/* 722 */     return getMyCurrentTheme().getPrimaryControlShadow();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getPrimaryControl() {
/* 726 */     return getMyCurrentTheme().getPrimaryControl();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getControlHighlight() {
/* 730 */     return getMyCurrentTheme().getControlHighlight();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getControlDarkShadow() {
/* 734 */     return getMyCurrentTheme().getControlDarkShadow();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getControl() {
/* 738 */     return getMyCurrentTheme().getControl();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getFocusColor() {
/* 742 */     return getMyCurrentTheme().getFocusColor();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getMenuItemBackground() {
/* 746 */     return getMyCurrentTheme().getMenuItemBackground();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getMenuItemSelectedBackground() {
/* 750 */     return getMyCurrentTheme().getMenuItemSelectedBackground();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getMenuItemSelectedForeground() {
/* 754 */     return getMyCurrentTheme().getMenuItemSelectedForeground();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getWindowTitleBackground() {
/* 758 */     return getMyCurrentTheme().getWindowTitleBackground();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getWindowTitleForeground() {
/* 762 */     return getMyCurrentTheme().getWindowTitleForeground();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getWindowTitleInactiveBackground() {
/* 766 */     return getMyCurrentTheme().getWindowTitleInactiveBackground();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getWindowTitleInactiveForeground() {
/* 770 */     return getMyCurrentTheme().getWindowTitleInactiveForeground();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getSimpleInternalFrameForeground() {
/* 774 */     return getMyCurrentTheme().getSimpleInternalFrameForeground();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getSimpleInternalFrameBackground() {
/* 778 */     return getMyCurrentTheme().getSimpleInternalFrameBackground();
/*     */   }
/*     */ 
/*     */   public static ColorUIResource getTitleTextColor() {
/* 782 */     return getMyCurrentTheme().getTitleTextColor();
/*     */   }
/*     */ 
/*     */   public static FontUIResource getTitleTextFont() {
/* 786 */     return getMyCurrentTheme().getTitleTextFont();
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticLookAndFeel
 * JD-Core Version:    0.6.2
 */