/*    */ package com.jgoodies.looks.plastic.theme;
/*    */ 
/*    */ import com.jgoodies.looks.FontSizeHints;
/*    */ import com.jgoodies.looks.LookUtils;
/*    */ import com.jgoodies.looks.plastic.PlasticLookAndFeel;
/*    */ import java.awt.Font;
/*    */ import javax.swing.plaf.FontUIResource;
/*    */ 
/*    */ public class SkyBluerTahoma extends SkyBluer
/*    */ {
/*    */   public String getName()
/*    */   {
/* 52 */     return "Sky Bluer - Tahoma";
/*    */   }
/*    */ 
/*    */   protected Font getFont0() {
/* 56 */     FontSizeHints sizeHints = PlasticLookAndFeel.getFontSizeHints();
/* 57 */     return getFont0(sizeHints.controlFontSize());
/*    */   }
/*    */ 
/*    */   protected Font getFont0(int size) {
/* 61 */     if (LookUtils.IS_OS_MAC) {
/* 62 */       return super.getFont0();
/*    */     }
/* 64 */     return new Font("Tahoma", 0, size);
/*    */   }
/*    */ 
/*    */   public FontUIResource getSubTextFont() {
/* 68 */     if (this.smallFont == null) {
/* 69 */       this.smallFont = new FontUIResource(getFont0(10));
/*    */     }
/* 71 */     return this.smallFont;
/*    */   }
/*    */ 
/*    */   public FontUIResource getSystemTextFont() {
/* 75 */     return getFont();
/*    */   }
/*    */ 
/*    */   public FontUIResource getUserTextFont() {
/* 79 */     return getFont();
/*    */   }
/*    */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.theme.SkyBluerTahoma
 * JD-Core Version:    0.6.2
 */