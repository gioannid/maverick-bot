/*     */ package com.jgoodies.looks.plastic.theme;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import javax.swing.plaf.ColorUIResource;
/*     */ 
/*     */ final class Colors
/*     */ {
/*  58 */   static final ColorUIResource GRAY_DARKEST = new ColorUIResource(64, 64, 64);
/*  59 */   static final ColorUIResource GRAY_DARKER = new ColorUIResource(82, 82, 82);
/*  60 */   static final ColorUIResource GRAY_DARK = new ColorUIResource(90, 90, 90);
/*  61 */   static final ColorUIResource GRAY_MEDIUMDARK = new ColorUIResource(110, 110, 110);
/*  62 */   static final ColorUIResource GRAY_MEDIUM = new ColorUIResource(128, 128, 128);
/*  63 */   static final ColorUIResource GRAY_MEDIUMLIGHT = new ColorUIResource(150, 150, 150);
/*  64 */   static final ColorUIResource GRAY_LIGHT = new ColorUIResource(170, 170, 170);
/*  65 */   static final ColorUIResource GRAY_LIGHTER = new ColorUIResource(220, 220, 220);
/*  66 */   static final ColorUIResource GRAY_LIGHTER2 = new ColorUIResource(230, 230, 230);
/*  67 */   static final ColorUIResource GRAY_LIGHTEST = new ColorUIResource(240, 240, 240);
/*     */ 
/*  72 */   static final ColorUIResource BROWN_LIGHTEST = new ColorUIResource(242, 241, 238);
/*     */ 
/*  77 */   static final ColorUIResource BLUE_LOW_MEDIUM = new ColorUIResource(166, 202, 240);
/*  78 */   static final ColorUIResource BLUE_LOW_LIGHTEST = new ColorUIResource(195, 212, 232);
/*     */ 
/*  80 */   static final ColorUIResource BLUE_MEDIUM_DARKEST = new ColorUIResource(44, 73, 135);
/*  81 */   static final ColorUIResource BLUE_MEDIUM_DARK = new ColorUIResource(49, 106, 196);
/*  82 */   static final ColorUIResource BLUE_MEDIUM_MEDIUM = new ColorUIResource(85, 115, 170);
/*  83 */   static final ColorUIResource BLUE_MEDIUM_LIGHTEST = new ColorUIResource(172, 210, 248);
/*     */ 
/*  88 */   static final ColorUIResource GREEN_LOW_DARK = new ColorUIResource(75, 148, 75);
/*  89 */   static final ColorUIResource GREEN_LOW_MEDIUM = new ColorUIResource(112, 190, 112);
/*  90 */   static final ColorUIResource GREEN_LOW_LIGHTEST = new ColorUIResource(200, 222, 200);
/*     */ 
/*  92 */   static final ColorUIResource GREEN_CHECK = new ColorUIResource(33, 161, 33);
/*     */ 
/*  97 */   static final ColorUIResource PINK_HIGH_DARK = new ColorUIResource(128, 0, 128);
/*  98 */   static final ColorUIResource PINK_LOW_DARK = new ColorUIResource(128, 70, 128);
/*  99 */   static final ColorUIResource PINK_LOW_MEDIUM = new ColorUIResource(190, 150, 190);
/* 100 */   static final ColorUIResource PINK_LOW_LIGHTER = new ColorUIResource(233, 207, 233);
/*     */ 
/* 105 */   static final ColorUIResource RED_LOW_DARK = new ColorUIResource(128, 70, 70);
/* 106 */   static final ColorUIResource RED_LOW_MEDIUM = new ColorUIResource(190, 112, 112);
/* 107 */   static final ColorUIResource RED_LOW_LIGHTER = new ColorUIResource(222, 200, 200);
/*     */ 
/* 112 */   static final ColorUIResource YELLOW_LOW_MEDIUMDARK = new ColorUIResource(182, 149, 18);
/* 113 */   static final ColorUIResource YELLOW_LOW_MEDIUM = new ColorUIResource(244, 214, 96);
/* 114 */   static final ColorUIResource YELLOW_LOW_LIGHTEST = new ColorUIResource(249, 225, 131);
/*     */ 
/* 118 */   static final ColorUIResource BLUE_FOCUS = BLUE_MEDIUM_LIGHTEST;
/* 119 */   static final ColorUIResource ORANGE_FOCUS = new ColorUIResource(245, 165, 16);
/* 120 */   static final ColorUIResource YELLOW_FOCUS = new ColorUIResource(255, 223, 63);
/* 121 */   static final ColorUIResource GRAY_FOCUS = new ColorUIResource(Color.LIGHT_GRAY);
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.theme.Colors
 * JD-Core Version:    0.6.2
 */