/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import com.jgoodies.looks.common.ExtBasicArrowButtonHandler;
/*     */ import com.jgoodies.looks.common.ExtBasicSpinnerLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.JSpinner.DefaultEditor;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.BorderUIResource;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicBorders.MarginBorder;
/*     */ import javax.swing.plaf.basic.BasicSpinnerUI;
/*     */ 
/*     */ public class PlasticSpinnerUI extends BasicSpinnerUI
/*     */ {
/*  62 */   private static final Border MARGIN_BORDER = new BorderUIResource(new BasicBorders.MarginBorder());
/*     */ 
/*  79 */   private static final ExtBasicArrowButtonHandler nextButtonHandler = new ExtBasicArrowButtonHandler("increment", true);
/*     */ 
/*  81 */   private static final ExtBasicArrowButtonHandler previousButtonHandler = new ExtBasicArrowButtonHandler("decrement", false);
/*     */ 
/*     */   public static ComponentUI createUI(JComponent b)
/*     */   {
/*  66 */     return new PlasticSpinnerUI();
/*     */   }
/*     */ 
/*     */   protected Component createPreviousButton()
/*     */   {
/*  98 */     return new SpinnerArrowButton(5, previousButtonHandler);
/*     */   }
/*     */ 
/*     */   protected Component createNextButton()
/*     */   {
/* 116 */     return new SpinnerArrowButton(1, nextButtonHandler);
/*     */   }
/*     */ 
/*     */   protected LayoutManager createLayout()
/*     */   {
/* 134 */     return new ExtBasicSpinnerLayout();
/*     */   }
/*     */ 
/*     */   protected JComponent createEditor()
/*     */   {
/* 162 */     JComponent editor = this.spinner.getEditor();
/* 163 */     configureEditor(editor);
/* 164 */     return editor;
/*     */   }
/*     */ 
/*     */   protected void replaceEditor(JComponent oldEditor, JComponent newEditor)
/*     */   {
/* 183 */     this.spinner.remove(oldEditor);
/* 184 */     configureEditor(newEditor);
/* 185 */     this.spinner.add(newEditor, "Editor");
/*     */   }
/*     */ 
/*     */   private void configureEditor(JComponent editor)
/*     */   {
/* 193 */     if ((editor instanceof JSpinner.DefaultEditor)) {
/* 194 */       JSpinner.DefaultEditor defaultEditor = (JSpinner.DefaultEditor)editor;
/* 195 */       defaultEditor.getTextField().getUI();
/* 196 */       defaultEditor.getTextField().setBorder(MARGIN_BORDER);
/* 197 */       Insets insets = UIManager.getInsets("Spinner.defaultEditorInsets");
/* 198 */       defaultEditor.getTextField().setMargin(insets);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class SpinnerArrowButton extends PlasticArrowButton
/*     */   {
/*     */     SpinnerArrowButton(int direction, ExtBasicArrowButtonHandler handler)
/*     */     {
/* 209 */       super(UIManager.getInt("ScrollBar.width"), true);
/* 210 */       addActionListener(handler);
/* 211 */       addMouseListener(handler);
/*     */     }
/*     */ 
/*     */     protected int calculateArrowHeight(int height, int width) {
/* 215 */       int arrowHeight = Math.min((height - 4) / 3, (width - 4) / 3);
/* 216 */       return Math.max(arrowHeight, 3);
/*     */     }
/*     */ 
/*     */     protected int calculateArrowOffset() {
/* 220 */       return 1;
/*     */     }
/*     */ 
/*     */     protected boolean isPaintingNorthBottom() {
/* 224 */       return true;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticSpinnerUI
 * JD-Core Version:    0.6.2
 */