/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import com.jgoodies.looks.LookUtils;
/*     */ import com.jgoodies.looks.common.ButtonMarginListener;
/*     */ import java.awt.Container;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JToolBar;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.metal.MetalButtonUI;
/*     */ 
/*     */ public class PlasticButtonUI extends MetalButtonUI
/*     */ {
/*  57 */   private static final PlasticButtonUI INSTANCE = new PlasticButtonUI();
/*     */   private boolean borderPaintsFocus;
/*     */   private PropertyChangeListener buttonMarginListener;
/*     */ 
/*     */   public static ComponentUI createUI(JComponent b)
/*     */   {
/*  63 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   public void installDefaults(AbstractButton b)
/*     */   {
/*  70 */     super.installDefaults(b);
/*  71 */     LookUtils.installNarrowMargin(b, getPropertyPrefix());
/*  72 */     this.borderPaintsFocus = 
/*  73 */       Boolean.TRUE.equals(UIManager.get("Button.borderPaintsFocus"));
/*     */   }
/*     */ 
/*     */   public void installListeners(AbstractButton b)
/*     */   {
/*  80 */     super.installListeners(b);
/*  81 */     if (this.buttonMarginListener == null) {
/*  82 */       this.buttonMarginListener = new ButtonMarginListener(getPropertyPrefix());
/*     */     }
/*  84 */     b.addPropertyChangeListener("jgoodies.isNarrow", this.buttonMarginListener);
/*     */   }
/*     */ 
/*     */   public void uninstallListeners(AbstractButton b)
/*     */   {
/*  91 */     super.uninstallListeners(b);
/*  92 */     b.removePropertyChangeListener(this.buttonMarginListener);
/*     */   }
/*     */ 
/*     */   public void update(Graphics g, JComponent c)
/*     */   {
/*  98 */     if (c.isOpaque()) {
/*  99 */       AbstractButton b = (AbstractButton)c;
/* 100 */       if (isToolBarButton(b)) {
/* 101 */         c.setOpaque(false);
/* 102 */       } else if (b.isContentAreaFilled()) {
/* 103 */         g.setColor(c.getBackground());
/* 104 */         if (b.isBorderPainted())
/* 105 */           g.fillRect(1, 1, c.getWidth() - 2, c.getHeight() - 2);
/*     */         else {
/* 107 */           g.fillRect(0, 0, c.getWidth(), c.getHeight());
/*     */         }
/* 109 */         if (is3D(b)) {
/* 110 */           Rectangle r = 
/* 111 */             new Rectangle(
/* 112 */             1, 
/* 113 */             1, 
/* 114 */             c.getWidth() - 2, 
/* 115 */             c.getHeight() - 1);
/* 116 */           PlasticUtils.add3DEffekt(g, r);
/*     */         }
/*     */       }
/*     */     }
/* 120 */     paint(g, c);
/*     */   }
/*     */ 
/*     */   protected void paintFocus(Graphics g, AbstractButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect)
/*     */   {
/* 133 */     if (this.borderPaintsFocus) {
/* 134 */       return;
/*     */     }
/*     */ 
/* 137 */     boolean isDefault = 
/* 138 */       ((b instanceof JButton)) && (((JButton)b).isDefaultButton());
/* 139 */     int topLeftInset = isDefault ? 3 : 2;
/* 140 */     int width = b.getWidth() - 1 - topLeftInset * 2;
/* 141 */     int height = b.getHeight() - 1 - topLeftInset * 2;
/*     */ 
/* 143 */     g.setColor(getFocusColor());
/* 144 */     g.drawRect(topLeftInset, topLeftInset, width - 1, height - 1);
/*     */   }
/*     */ 
/*     */   protected void paintButtonPressed(Graphics g, AbstractButton b)
/*     */   {
/* 151 */     if (b.isContentAreaFilled()) {
/* 152 */       if (b.isBorderPainted()) g.setColor(getSelectColor()); else
/* 153 */         g.setColor(b.getBackground());
/* 154 */       g.fillRect(1, 1, b.getWidth() - 2, b.getHeight() - 2);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isToolBarButton(AbstractButton b)
/*     */   {
/* 168 */     Container parent = b.getParent();
/*     */ 
/* 171 */     return (parent != null) && (
/* 170 */       ((parent instanceof JToolBar)) || 
/* 171 */       ((parent.getParent() instanceof JToolBar)));
/*     */   }
/*     */ 
/*     */   protected boolean is3D(AbstractButton b)
/*     */   {
/* 181 */     if (PlasticUtils.force3D(b))
/* 182 */       return true;
/* 183 */     if (PlasticUtils.forceFlat(b))
/* 184 */       return false;
/* 185 */     ButtonModel model = b.getModel();
/*     */ 
/* 190 */     return (PlasticUtils.is3D("Button.")) && 
/* 187 */       (b.isBorderPainted()) && 
/* 188 */       (model.isEnabled()) && 
/* 189 */       ((!model.isPressed()) || (!model.isArmed())) && 
/* 190 */       (!(b.getBorder() instanceof EmptyBorder));
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticButtonUI
 * JD-Core Version:    0.6.2
 */