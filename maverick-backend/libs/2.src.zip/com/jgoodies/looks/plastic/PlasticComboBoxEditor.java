/*    */ package com.jgoodies.looks.plastic;
/*    */ 
/*    */ import javax.swing.JTextField;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.UIResource;
/*    */ import javax.swing.plaf.basic.BasicComboBoxEditor;
/*    */ 
/*    */ class PlasticComboBoxEditor extends BasicComboBoxEditor
/*    */ {
/*    */   PlasticComboBoxEditor()
/*    */   {
/* 51 */     this.editor = new JTextField("", UIManager.getInt("ComboBox.editorColumns"));
/* 52 */     this.editor.setBorder(UIManager.getBorder("ComboBox.editorBorder"));
/*    */   }
/*    */ 
/*    */   static final class UIResource extends PlasticComboBoxEditor
/*    */     implements UIResource
/*    */   {
/*    */   }
/*    */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticComboBoxEditor
 * JD-Core Version:    0.6.2
 */