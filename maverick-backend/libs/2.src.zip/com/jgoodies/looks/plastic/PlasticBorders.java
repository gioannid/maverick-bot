/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import com.jgoodies.looks.LookUtils;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JToggleButton;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.AbstractBorder;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.CompoundBorder;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.plaf.BorderUIResource;
/*     */ import javax.swing.plaf.BorderUIResource.CompoundBorderUIResource;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicBorders.MarginBorder;
/*     */ import javax.swing.plaf.metal.MetalBorders.ScrollPaneBorder;
/*     */ import javax.swing.text.JTextComponent;
/*     */ 
/*     */ final class PlasticBorders
/*     */ {
/*     */   private static Border buttonBorder;
/*     */   private static Border comboBoxEditorBorder;
/*     */   private static Border comboBoxArrowButtonBorder;
/*     */   private static Border etchedBorder;
/*     */   private static Border flush3DBorder;
/*     */   private static Border menuBarHeaderBorder;
/*     */   private static Border menuBorder;
/*     */   private static Border menuItemBorder;
/*     */   private static Border popupMenuBorder;
/*     */   private static Border rolloverButtonBorder;
/*     */   private static Border scrollPaneBorder;
/*     */   private static Border separatorBorder;
/*     */   private static Border textFieldBorder;
/*     */   private static Border thinLoweredBorder;
/*     */   private static Border thinRaisedBorder;
/*     */   private static Border toggleButtonBorder;
/*     */   private static Border toolBarHeaderBorder;
/*     */ 
/*     */   static Border getButtonBorder()
/*     */   {
/*  93 */     if (buttonBorder == null) {
/*  94 */       buttonBorder = new BorderUIResource.CompoundBorderUIResource(
/*  95 */         new ButtonBorder(), new BasicBorders.MarginBorder());
/*     */     }
/*  97 */     return buttonBorder;
/*     */   }
/*     */ 
/*     */   static Border getComboBoxArrowButtonBorder()
/*     */   {
/* 106 */     if (comboBoxArrowButtonBorder == null) {
/* 107 */       comboBoxArrowButtonBorder = new CompoundBorder(
/* 108 */         new ComboBoxArrowButtonBorder(), new BasicBorders.MarginBorder());
/*     */     }
/* 110 */     return comboBoxArrowButtonBorder;
/*     */   }
/*     */ 
/*     */   static Border getComboBoxEditorBorder()
/*     */   {
/* 119 */     if (comboBoxEditorBorder == null) {
/* 120 */       comboBoxEditorBorder = new CompoundBorder(
/* 121 */         new ComboBoxEditorBorder(), new BasicBorders.MarginBorder());
/*     */     }
/* 123 */     return comboBoxEditorBorder;
/*     */   }
/*     */ 
/*     */   static Border getEtchedBorder()
/*     */   {
/* 133 */     if (etchedBorder == null) {
/* 134 */       etchedBorder = new BorderUIResource.CompoundBorderUIResource(
/* 135 */         new EtchedBorder(), new BasicBorders.MarginBorder());
/*     */     }
/* 137 */     return etchedBorder;
/*     */   }
/*     */ 
/*     */   static Border getFlush3DBorder()
/*     */   {
/* 146 */     if (flush3DBorder == null) {
/* 147 */       flush3DBorder = new Flush3DBorder();
/*     */     }
/* 149 */     return flush3DBorder;
/*     */   }
/*     */ 
/*     */   static Border getInternalFrameBorder()
/*     */   {
/* 158 */     return new InternalFrameBorder();
/*     */   }
/*     */ 
/*     */   static Border getMenuBarHeaderBorder()
/*     */   {
/* 168 */     if (menuBarHeaderBorder == null) {
/* 169 */       menuBarHeaderBorder = new BorderUIResource.CompoundBorderUIResource(
/* 170 */         new MenuBarHeaderBorder(), new BasicBorders.MarginBorder());
/*     */     }
/* 172 */     return menuBarHeaderBorder;
/*     */   }
/*     */ 
/*     */   static Border getMenuBorder()
/*     */   {
/* 181 */     if (menuBorder == null) {
/* 182 */       menuBorder = new BorderUIResource.CompoundBorderUIResource(
/* 183 */         new MenuBorder(), new BasicBorders.MarginBorder());
/*     */     }
/* 185 */     return menuBorder;
/*     */   }
/*     */ 
/*     */   static Border getMenuItemBorder()
/*     */   {
/* 194 */     if (menuItemBorder == null) {
/* 195 */       menuItemBorder = new BorderUIResource(new BasicBorders.MarginBorder());
/*     */     }
/* 197 */     return menuItemBorder;
/*     */   }
/*     */ 
/*     */   static Border getPopupMenuBorder()
/*     */   {
/* 206 */     if (popupMenuBorder == null) {
/* 207 */       popupMenuBorder = new PopupMenuBorder();
/*     */     }
/* 209 */     return popupMenuBorder;
/*     */   }
/*     */ 
/*     */   static Border getPaletteBorder()
/*     */   {
/* 218 */     return new PaletteBorder();
/*     */   }
/*     */ 
/*     */   static Border getRolloverButtonBorder()
/*     */   {
/* 227 */     if (rolloverButtonBorder == null) {
/* 228 */       rolloverButtonBorder = new BorderUIResource.CompoundBorderUIResource(
/* 229 */         new RolloverButtonBorder(), new RolloverMarginBorder());
/*     */     }
/* 231 */     return rolloverButtonBorder;
/*     */   }
/*     */ 
/*     */   static Border getScrollPaneBorder()
/*     */   {
/* 240 */     if (scrollPaneBorder == null) {
/* 241 */       scrollPaneBorder = new ScrollPaneBorder();
/*     */     }
/* 243 */     return scrollPaneBorder;
/*     */   }
/*     */ 
/*     */   static Border getSeparatorBorder()
/*     */   {
/* 253 */     if (separatorBorder == null) {
/* 254 */       separatorBorder = new BorderUIResource.CompoundBorderUIResource(
/* 255 */         new SeparatorBorder(), new BasicBorders.MarginBorder());
/*     */     }
/* 257 */     return separatorBorder;
/*     */   }
/*     */ 
/*     */   static Border getTextFieldBorder()
/*     */   {
/* 266 */     if (textFieldBorder == null) {
/* 267 */       textFieldBorder = new BorderUIResource.CompoundBorderUIResource(
/* 268 */         new TextFieldBorder(), new BasicBorders.MarginBorder());
/*     */     }
/* 270 */     return textFieldBorder;
/*     */   }
/*     */ 
/*     */   static Border getThinLoweredBorder()
/*     */   {
/* 279 */     if (thinLoweredBorder == null) {
/* 280 */       thinLoweredBorder = new PlasticBorders.ThinLoweredBorder();
/*     */     }
/* 282 */     return thinLoweredBorder;
/*     */   }
/*     */ 
/*     */   static Border getThinRaisedBorder()
/*     */   {
/* 291 */     if (thinRaisedBorder == null) {
/* 292 */       thinRaisedBorder = new ThinRaisedBorder();
/*     */     }
/* 294 */     return thinRaisedBorder;
/*     */   }
/*     */ 
/*     */   static Border getToggleButtonBorder()
/*     */   {
/* 303 */     if (toggleButtonBorder == null) {
/* 304 */       toggleButtonBorder = new BorderUIResource.CompoundBorderUIResource(
/* 305 */         new ToggleButtonBorder(), new BasicBorders.MarginBorder());
/*     */     }
/* 307 */     return toggleButtonBorder;
/*     */   }
/*     */ 
/*     */   static Border getToolBarHeaderBorder()
/*     */   {
/* 317 */     if (toolBarHeaderBorder == null) {
/* 318 */       toolBarHeaderBorder = new BorderUIResource.CompoundBorderUIResource(
/* 319 */         new ToolBarHeaderBorder(), new BasicBorders.MarginBorder());
/*     */     }
/* 321 */     return toolBarHeaderBorder;
/*     */   }
/*     */ 
/*     */   private static class Flush3DBorder extends AbstractBorder
/*     */     implements UIResource
/*     */   {
/* 327 */     private static final Insets INSETS = new Insets(2, 2, 2, 2);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 331 */       if (c.isEnabled())
/* 332 */         PlasticUtils.drawFlush3DBorder(g, x, y, w, h);
/*     */       else
/* 334 */         PlasticUtils.drawDisabledBorder(g, x, y, w, h);
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c) {
/* 338 */       return INSETS;
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c, Insets newInsets) {
/* 342 */       newInsets.top = INSETS.top;
/* 343 */       newInsets.left = INSETS.left;
/* 344 */       newInsets.bottom = INSETS.bottom;
/* 345 */       newInsets.right = INSETS.right;
/* 346 */       return newInsets;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ButtonBorder extends AbstractBorder
/*     */     implements UIResource
/*     */   {
/* 353 */     protected static final Insets INSETS = LookUtils.IS_LOW_RESOLUTION ? new Insets(
/* 354 */       2, 3, 3, 3) : 
/* 355 */       new Insets(1, 3, 1, 3);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 359 */       AbstractButton button = (AbstractButton)c;
/* 360 */       ButtonModel model = button.getModel();
/*     */ 
/* 362 */       if (model.isEnabled()) {
/* 363 */         boolean isPressed = (model.isPressed()) && (model.isArmed());
/* 364 */         boolean isDefault = ((button instanceof JButton)) && 
/* 365 */           (((JButton)button).isDefaultButton());
/*     */ 
/* 367 */         if ((isPressed) && (isDefault))
/* 368 */           PlasticUtils.drawDefaultButtonPressedBorder(g, x, y, w, h);
/* 369 */         else if (isPressed)
/* 370 */           PlasticUtils.drawPressed3DBorder(g, x, y, w, h);
/* 371 */         else if (isDefault)
/* 372 */           PlasticUtils.drawDefaultButtonBorder(g, x, y, w, h, false);
/*     */         else
/* 374 */           PlasticUtils.drawButtonBorder(g, x, y, w, h, false);
/*     */       } else {
/* 376 */         PlasticUtils.drawDisabledBorder(g, x, y, w - 1, h - 1);
/*     */       }
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c) {
/* 381 */       return INSETS;
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c, Insets newInsets) {
/* 385 */       newInsets.top = INSETS.top;
/* 386 */       newInsets.left = INSETS.left;
/* 387 */       newInsets.bottom = INSETS.bottom;
/* 388 */       newInsets.right = INSETS.right;
/* 389 */       return newInsets;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ComboBoxArrowButtonBorder extends AbstractBorder
/*     */     implements UIResource
/*     */   {
/* 396 */     protected static final Insets INSETS = new Insets(1, 1, 1, 1);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 400 */       AbstractButton button = (AbstractButton)c;
/* 401 */       ButtonModel model = button.getModel();
/*     */ 
/* 403 */       if (model.isEnabled()) {
/* 404 */         boolean isPressed = (model.isPressed()) && (model.isArmed());
/*     */ 
/* 406 */         if (isPressed)
/* 407 */           PlasticUtils.drawPressed3DBorder(g, x, y, w, h);
/*     */         else
/* 409 */           PlasticUtils.drawButtonBorder(g, x, y, w, h, false);
/*     */       } else {
/* 411 */         PlasticUtils.drawDisabledBorder(g, x, y, w - 1, h - 1);
/*     */       }
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c) {
/* 416 */       return INSETS;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ComboBoxEditorBorder extends AbstractBorder
/*     */   {
/* 422 */     private static final Insets INSETS = new Insets(2, 2, 2, 0);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 426 */       if (c.isEnabled()) {
/* 427 */         PlasticUtils.drawFlush3DBorder(g, x, y, w + 2, h);
/*     */       } else {
/* 429 */         PlasticUtils.drawDisabledBorder(g, x, y, w + 2, h - 1);
/* 430 */         g.setColor(UIManager.getColor("control"));
/* 431 */         g.drawLine(x, y + h - 1, x + w, y + h - 1);
/*     */       }
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c) {
/* 436 */       return INSETS;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class InternalFrameBorder extends AbstractBorder
/*     */     implements UIResource
/*     */   {
/* 446 */     private static final Insets NORMAL_INSETS = new Insets(2, 2, 3, 3);
/* 447 */     private static final Insets MAXIMIZED_INSETS = new Insets(2, 2, 2, 2);
/*     */     static final int ALPHA1 = 150;
/*     */     static final int ALPHA2 = 50;
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 453 */       JInternalFrame frame = (JInternalFrame)c;
/* 454 */       if (frame.isMaximum())
/* 455 */         PlasticUtils.drawFlush3DBorder(g, x, y, w, h);
/*     */       else
/* 457 */         paintShadowedBorder(g, x, y, w, h);
/*     */     }
/*     */ 
/*     */     private void paintShadowedBorder(Graphics g, int x, int y, int w, int h) {
/* 461 */       Color background = UIManager.getColor("desktop");
/* 462 */       Color highlight = UIManager.getColor("controlLtHighlight");
/* 463 */       Color darkShadow = UIManager.getColor("controlDkShadow");
/* 464 */       Color lightShadow = new Color(darkShadow.getRed(), 
/* 465 */         darkShadow.getGreen(), darkShadow.getBlue(), 150);
/* 466 */       Color lighterShadow = new Color(darkShadow.getRed(), 
/* 467 */         darkShadow.getGreen(), darkShadow.getBlue(), 50);
/* 468 */       g.translate(x, y);
/*     */ 
/* 470 */       g.setColor(darkShadow);
/* 471 */       g.drawRect(0, 0, w - 3, h - 3);
/*     */ 
/* 473 */       g.setColor(highlight);
/* 474 */       g.drawLine(1, 1, w - 4, 1);
/* 475 */       g.drawLine(1, 1, 1, h - 4);
/*     */ 
/* 477 */       g.setColor(background);
/* 478 */       g.fillRect(w - 2, 0, 2, h);
/* 479 */       g.fillRect(0, h - 2, w, 2);
/*     */ 
/* 481 */       g.setColor(lightShadow);
/* 482 */       g.drawLine(w - 2, 1, w - 2, h - 2);
/* 483 */       g.drawLine(1, h - 2, w - 3, h - 2);
/*     */ 
/* 485 */       g.setColor(lighterShadow);
/* 486 */       g.drawLine(w - 1, 2, w - 1, h - 2);
/* 487 */       g.drawLine(2, h - 1, w - 2, h - 1);
/* 488 */       g.translate(-x, -y);
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c) {
/* 492 */       return ((JInternalFrame)c).isMaximum() ? MAXIMIZED_INSETS : 
/* 493 */         NORMAL_INSETS;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class PaletteBorder extends AbstractBorder
/*     */     implements UIResource
/*     */   {
/* 503 */     private static final Insets INSETS = new Insets(1, 1, 1, 1);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 507 */       g.translate(x, y);
/* 508 */       g.setColor(PlasticLookAndFeel.getControlDarkShadow());
/* 509 */       g.drawRect(0, 0, w - 1, h - 1);
/* 510 */       g.translate(-x, -y);
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c) {
/* 514 */       return INSETS;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class SeparatorBorder extends AbstractBorder
/*     */     implements UIResource
/*     */   {
/* 525 */     private static final Insets INSETS = new Insets(0, 0, 2, 1);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 529 */       g.translate(x, y);
/* 530 */       g.setColor(UIManager.getColor("Separator.foreground"));
/* 531 */       g.drawLine(0, h - 2, w - 1, h - 2);
/*     */ 
/* 533 */       g.setColor(UIManager.getColor("Separator.background"));
/* 534 */       g.drawLine(0, h - 1, w - 1, h - 1);
/* 535 */       g.translate(-x, -y);
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c) {
/* 539 */       return INSETS;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ThinRaisedBorder extends AbstractBorder implements UIResource
/*     */   {
/* 545 */     private static final Insets INSETS = new Insets(2, 2, 2, 2);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 549 */       PlasticUtils.drawThinFlush3DBorder(g, x, y, w, h);
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c) {
/* 553 */       return INSETS;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class EtchedBorder extends AbstractBorder
/*     */     implements UIResource
/*     */   {
/* 579 */     private static final Insets INSETS = new Insets(2, 2, 2, 2);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 583 */       PlasticUtils.drawThinPressed3DBorder(g, x, y, w, h);
/* 584 */       PlasticUtils.drawThinFlush3DBorder(g, x + 1, y + 1, w - 2, h - 2);
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c) {
/* 588 */       return INSETS;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class MenuBarHeaderBorder extends AbstractBorder
/*     */     implements UIResource
/*     */   {
/* 600 */     private static final Insets INSETS = new Insets(2, 2, 1, 2);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 604 */       PlasticUtils.drawThinPressed3DBorder(g, x, y, w, h + 1);
/* 605 */       PlasticUtils.drawThinFlush3DBorder(g, x + 1, y + 1, w - 2, h - 1);
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c) {
/* 609 */       return INSETS;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ToolBarHeaderBorder extends AbstractBorder
/*     */     implements UIResource
/*     */   {
/* 621 */     private static final Insets INSETS = new Insets(1, 2, 2, 2);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 625 */       PlasticUtils.drawThinPressed3DBorder(g, x, y - 1, w, h + 1);
/* 626 */       PlasticUtils.drawThinFlush3DBorder(g, x + 1, y, w - 2, h - 1);
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c) {
/* 630 */       return INSETS;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class MenuBorder extends AbstractBorder implements UIResource {
/* 635 */     private static final Insets INSETS = new Insets(2, 2, 2, 2);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 639 */       JMenuItem b = (JMenuItem)c;
/* 640 */       ButtonModel model = b.getModel();
/*     */ 
/* 642 */       if ((!model.isArmed()) && (!model.isSelected()) && (!model.isRollover()))
/*     */       {
/* 650 */         if (model.isRollover()) {
/* 651 */           g.translate(x, y);
/* 652 */           PlasticUtils.drawFlush3DBorder(g, x, y, w, h);
/* 653 */           g.translate(-x, -y);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 658 */     public Insets getBorderInsets(Component c) { return INSETS; }
/*     */ 
/*     */     public Insets getBorderInsets(Component c, Insets newInsets)
/*     */     {
/* 662 */       newInsets.top = INSETS.top;
/* 663 */       newInsets.left = INSETS.left;
/* 664 */       newInsets.bottom = INSETS.bottom;
/* 665 */       newInsets.right = INSETS.right;
/* 666 */       return newInsets;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class PopupMenuBorder extends AbstractBorder implements UIResource
/*     */   {
/* 672 */     private static final Insets INSETS = new Insets(3, 3, 3, 3);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 676 */       g.translate(x, y);
/* 677 */       g.setColor(PlasticLookAndFeel.getControlDarkShadow());
/* 678 */       g.drawRect(0, 0, w - 1, h - 1);
/*     */ 
/* 680 */       g.setColor(c.getBackground());
/* 681 */       g.drawRect(1, 1, w - 3, h - 3);
/* 682 */       g.drawRect(2, 2, w - 5, h - 5);
/* 683 */       g.translate(-x, -y);
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c) {
/* 687 */       return INSETS;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class RolloverButtonBorder extends PlasticBorders.ButtonBorder {
/* 692 */     private static final Insets INSETS_3 = new Insets(3, 3, 3, 3);
/*     */ 
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 696 */       AbstractButton b = (AbstractButton)c;
/* 697 */       ButtonModel model = b.getModel();
/*     */ 
/* 699 */       if (!model.isEnabled()) {
/* 700 */         return;
/*     */       }
/* 702 */       if (!(c instanceof JToggleButton)) {
/* 703 */         if ((model.isRollover()) && ((!model.isPressed()) || (model.isArmed()))) {
/* 704 */           super.paintBorder(c, g, x, y, w, h);
/*     */         }
/* 706 */         return;
/*     */       }
/*     */ 
/* 714 */       if (model.isRollover()) {
/* 715 */         if ((model.isPressed()) && (model.isArmed()))
/* 716 */           PlasticUtils.drawPressed3DBorder(g, x, y, w, h);
/*     */         else
/* 718 */           PlasticUtils.drawFlush3DBorder(g, x, y, w, h);
/*     */       }
/* 720 */       else if (model.isSelected())
/* 721 */         PlasticUtils.drawDark3DBorder(g, x, y, w, h);
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c) {
/* 725 */       return INSETS_3;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class RolloverMarginBorder extends EmptyBorder
/*     */   {
/*     */     RolloverMarginBorder()
/*     */     {
/* 736 */       super(1, 1, 1);
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c) {
/* 740 */       return getBorderInsets(c, new Insets(0, 0, 0, 0));
/*     */     }
/*     */ 
/*     */     public Insets getBorderInsets(Component c, Insets insets) {
/* 744 */       Insets margin = null;
/*     */ 
/* 746 */       if ((c instanceof AbstractButton)) {
/* 747 */         margin = ((AbstractButton)c).getMargin();
/*     */       }
/* 749 */       if ((margin == null) || ((margin instanceof UIResource)))
/*     */       {
/* 751 */         insets.left = this.left;
/* 752 */         insets.top = this.top;
/* 753 */         insets.right = this.right;
/* 754 */         insets.bottom = this.bottom;
/*     */       }
/*     */       else {
/* 757 */         insets.left = margin.left;
/* 758 */         insets.top = margin.top;
/* 759 */         insets.right = margin.right;
/* 760 */         insets.bottom = margin.bottom;
/*     */       }
/* 762 */       return insets;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ScrollPaneBorder extends MetalBorders.ScrollPaneBorder
/*     */   {
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 775 */       g.translate(x, y);
/*     */ 
/* 777 */       g.setColor(PlasticLookAndFeel.getControlDarkShadow());
/* 778 */       g.drawRect(0, 0, w - 2, h - 2);
/* 779 */       g.setColor(PlasticLookAndFeel.getControlHighlight());
/* 780 */       g.drawLine(w - 1, 0, w - 1, h - 1);
/* 781 */       g.drawLine(0, h - 1, w - 1, h - 1);
/*     */ 
/* 783 */       g.translate(-x, -y);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class TextFieldBorder extends PlasticBorders.Flush3DBorder
/*     */   {
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h)
/*     */     {
/* 791 */       if (!(c instanceof JTextComponent))
/*     */       {
/* 793 */         if (c.isEnabled())
/* 794 */           PlasticUtils.drawFlush3DBorder(g, x, y, w, h);
/*     */         else {
/* 796 */           PlasticUtils.drawDisabledBorder(g, x, y, w, h);
/*     */         }
/* 798 */         return;
/*     */       }
/*     */ 
/* 801 */       if ((c.isEnabled()) && (((JTextComponent)c).isEditable()))
/* 802 */         PlasticUtils.drawFlush3DBorder(g, x, y, w, h);
/*     */       else
/* 804 */         PlasticUtils.drawDisabledBorder(g, x, y, w, h);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ToggleButtonBorder extends PlasticBorders.ButtonBorder
/*     */   {
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
/* 811 */       if (!c.isEnabled()) {
/* 812 */         PlasticUtils.drawDisabledBorder(g, x, y, w - 1, h - 1);
/*     */       } else {
/* 814 */         AbstractButton button = (AbstractButton)c;
/* 815 */         ButtonModel model = button.getModel();
/* 816 */         if ((model.isPressed()) && (model.isArmed()))
/* 817 */           PlasticUtils.drawPressed3DBorder(g, x, y, w, h);
/* 818 */         else if (model.isSelected())
/* 819 */           PlasticUtils.drawDark3DBorder(g, x, y, w, h);
/*     */         else
/* 821 */           PlasticUtils.drawFlush3DBorder(g, x, y, w, h);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticBorders
 * JD-Core Version:    0.6.2
 */