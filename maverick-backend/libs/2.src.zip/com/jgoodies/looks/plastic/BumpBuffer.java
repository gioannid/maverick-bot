/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.awt.Image;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.IndexColorModel;
/*     */ 
/*     */ final class BumpBuffer
/*     */ {
/*     */   static final int IMAGE_SIZE = 64;
/* 145 */   static Dimension imageSize = new Dimension(64, 64);
/*     */   transient Image image;
/*     */   Color topColor;
/*     */   Color shadowColor;
/*     */   Color backColor;
/*     */   private GraphicsConfiguration gc;
/*     */ 
/*     */   public BumpBuffer(GraphicsConfiguration gc, Color aTopColor, Color aShadowColor, Color aBackColor)
/*     */   {
/* 158 */     this.gc = gc;
/* 159 */     this.topColor = aTopColor;
/* 160 */     this.shadowColor = aShadowColor;
/* 161 */     this.backColor = aBackColor;
/* 162 */     createImage();
/* 163 */     fillBumpBuffer();
/*     */   }
/*     */ 
/*     */   public boolean hasSameConfiguration(GraphicsConfiguration aGC, Color aTopColor, Color aShadowColor, Color aBackColor)
/*     */   {
/* 171 */     if (this.gc != null) {
/* 172 */       if (!this.gc.equals(aGC))
/* 173 */         return false;
/*     */     }
/* 175 */     else if (aGC != null) {
/* 176 */       return false;
/*     */     }
/*     */ 
/* 180 */     return (this.topColor.equals(aTopColor)) && 
/* 179 */       (this.shadowColor.equals(aShadowColor)) && 
/* 180 */       (this.backColor.equals(aBackColor));
/*     */   }
/*     */ 
/*     */   public Image getImage()
/*     */   {
/* 187 */     return this.image;
/*     */   }
/* 189 */   public Dimension getImageSize() { return imageSize; }
/*     */ 
/*     */ 
/*     */   private void fillBumpBuffer()
/*     */   {
/* 195 */     Graphics g = this.image.getGraphics();
/*     */ 
/* 197 */     g.setColor(this.backColor);
/* 198 */     g.fillRect(0, 0, 64, 64);
/*     */ 
/* 200 */     g.setColor(this.topColor);
/* 201 */     for (int x = 0; x < 64; x += 4) {
/* 202 */       for (int y = 0; y < 64; y += 4) {
/* 203 */         g.drawLine(x, y, x, y);
/* 204 */         g.drawLine(x + 2, y + 2, x + 2, y + 2);
/*     */       }
/*     */     }
/*     */ 
/* 208 */     g.setColor(this.shadowColor);
/* 209 */     for (int x = 0; x < 64; x += 4) {
/* 210 */       for (int y = 0; y < 64; y += 4) {
/* 211 */         g.drawLine(x + 1, y + 1, x + 1, y + 1);
/* 212 */         g.drawLine(x + 3, y + 3, x + 3, y + 3);
/*     */       }
/*     */     }
/* 215 */     g.dispose();
/*     */   }
/*     */ 
/*     */   private void createImage()
/*     */   {
/* 223 */     if (this.gc != null) {
/* 224 */       this.image = this.gc.createCompatibleImage(64, 64);
/*     */     } else {
/* 226 */       int[] cmap = { this.backColor.getRGB(), this.topColor.getRGB(), this.shadowColor.getRGB() };
/* 227 */       IndexColorModel icm = 
/* 228 */         new IndexColorModel(8, 3, cmap, 0, false, -1, 0);
/* 229 */       this.image = new BufferedImage(64, 64, 13, icm);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.BumpBuffer
 * JD-Core Version:    0.6.2
 */