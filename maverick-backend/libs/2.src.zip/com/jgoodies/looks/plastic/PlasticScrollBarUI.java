/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JScrollBar;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.metal.MetalScrollBarUI;
/*     */ 
/*     */ public final class PlasticScrollBarUI extends MetalScrollBarUI
/*     */ {
/*     */   private static final String PROPERTY_PREFIX = "ScrollBar.";
/*     */   public static final String MAX_BUMPS_WIDTH_KEY = "ScrollBar.maxBumpsWidth";
/*     */   private static Color shadowColor;
/*     */   private static Color highlightColor;
/*     */   private static Color darkShadowColor;
/*     */   private static Color thumbColor;
/*     */   private static Color thumbShadow;
/*     */   private static Color thumbHighlightColor;
/*     */   private static Color shadowColor2;
/*     */   private static Color highlightColor2;
/*     */   private static Color darkShadowColor2;
/*     */   private static Color thumbColor2;
/*     */   private static Color thumbShadow2;
/*     */   private static Color thumbHighlightColor2;
/*     */   private PlasticBumps bumps;
/*     */   private PlasticBumps bumps2;
/*     */ 
/*     */   public static ComponentUI createUI(JComponent b)
/*     */   {
/*  72 */     return new PlasticScrollBarUI();
/*     */   }
/*     */ 
/*     */   protected void installDefaults() {
/*  76 */     super.installDefaults();
/*  77 */     this.bumps = new PlasticBumps(10, 10, thumbHighlightColor, thumbShadow, thumbColor);
/*  78 */     this.bumps2 = new PlasticBumps(10, 10, thumbHighlightColor2, thumbShadow2, thumbColor2);
/*     */   }
/*     */ 
/*     */   protected JButton createDecreaseButton(int orientation) {
/*  82 */     this.decreaseButton = new PlasticArrowButton(orientation, this.scrollBarWidth, this.isFreeStanding);
/*  83 */     return this.decreaseButton;
/*     */   }
/*     */ 
/*     */   protected JButton createIncreaseButton(int orientation) {
/*  87 */     this.increaseButton = new PlasticArrowButton(orientation, this.scrollBarWidth, this.isFreeStanding);
/*  88 */     return this.increaseButton;
/*     */   }
/*     */ 
/*     */   protected void configureScrollBarColors() {
/*  92 */     super.configureScrollBarColors();
/*  93 */     shadowColor = UIManager.getColor("ScrollBar.shadow");
/*  94 */     highlightColor = UIManager.getColor("ScrollBar.highlight");
/*  95 */     darkShadowColor = UIManager.getColor("ScrollBar.darkShadow");
/*  96 */     thumbColor = UIManager.getColor("ScrollBar.thumb");
/*  97 */     thumbShadow = UIManager.getColor("ScrollBar.thumbShadow");
/*  98 */     thumbHighlightColor = UIManager.getColor("ScrollBar.thumbHighlight");
/*     */ 
/* 100 */     shadowColor2 = PlasticXPUtils.SB_SHADOW;
/* 101 */     highlightColor2 = PlasticXPUtils.SB_HILIGHT;
/* 102 */     darkShadowColor2 = PlasticXPUtils.SB_DARK_SHADOW;
/* 103 */     thumbColor2 = PlasticXPUtils.SB_THUMB;
/* 104 */     thumbShadow2 = PlasticXPUtils.SB_THUMB_SHADOW;
/* 105 */     thumbHighlightColor2 = PlasticXPUtils.SB_THUMB_HILIGHT;
/*     */   }
/*     */ 
/*     */   public void update(Graphics g, JComponent c)
/*     */   {
/* 110 */     boolean useNorm = !c.getBackground().equals(PlasticXPUtils.BGCOL);
/* 111 */     if (c.isOpaque()) {
/* 112 */       g.setColor(useNorm ? c.getBackground() : PlasticXPUtils.SB_BG);
/* 113 */       g.fillRect(0, 0, c.getWidth(), c.getHeight());
/*     */     }
/* 115 */     paint(g, c);
/*     */   }
/*     */ 
/*     */   protected void paintTrack(Graphics g, JComponent c, Rectangle trackBounds) {
/* 119 */     boolean useNorm = !c.getBackground().equals(PlasticXPUtils.BGCOL);
/* 120 */     g.translate(trackBounds.x, trackBounds.y);
/*     */ 
/* 122 */     boolean leftToRight = PlasticUtils.isLeftToRight(c);
/*     */ 
/* 124 */     if (this.scrollbar.getOrientation() == 1) {
/* 125 */       if (!this.isFreeStanding) {
/* 126 */         if (!leftToRight) {
/* 127 */           trackBounds.width += 1;
/* 128 */           g.translate(-1, 0);
/*     */         } else {
/* 130 */           trackBounds.width += 2;
/*     */         }
/*     */       }
/*     */ 
/* 134 */       if (c.isEnabled()) {
/* 135 */         g.setColor(useNorm ? darkShadowColor : darkShadowColor2);
/* 136 */         g.drawLine(0, 0, 0, trackBounds.height - 1);
/* 137 */         g.drawLine(trackBounds.width - 2, 0, trackBounds.width - 2, 
/* 138 */           trackBounds.height - 1);
/* 139 */         g.drawLine(1, trackBounds.height - 1, trackBounds.width - 1, 
/* 140 */           trackBounds.height - 1);
/* 141 */         g.drawLine(1, 0, trackBounds.width - 2, 0);
/*     */ 
/* 143 */         g.setColor(useNorm ? shadowColor : shadowColor2);
/*     */ 
/* 145 */         g.drawLine(1, 1, 1, trackBounds.height - 2);
/* 146 */         g.drawLine(1, 1, trackBounds.width - 3, 1);
/* 147 */         if (this.scrollbar.getValue() != this.scrollbar.getMaximum())
/*     */         {
/* 149 */           int y = this.thumbRect.y + this.thumbRect.height - trackBounds.y;
/* 150 */           g.drawLine(1, y, trackBounds.width - 1, y);
/*     */         }
/* 152 */         g.setColor(useNorm ? highlightColor : highlightColor2);
/* 153 */         g.drawLine(trackBounds.width - 1, 0, trackBounds.width - 1, 
/* 154 */           trackBounds.height - 1);
/*     */       } else {
/* 156 */         PlasticUtils.drawDisabledBorder(g, 0, 0, trackBounds.width, 
/* 157 */           trackBounds.height);
/*     */       }
/*     */ 
/* 160 */       if (!this.isFreeStanding)
/* 161 */         if (!leftToRight) {
/* 162 */           trackBounds.width -= 1;
/* 163 */           g.translate(1, 0);
/*     */         } else {
/* 165 */           trackBounds.width -= 2;
/*     */         }
/*     */     }
/*     */     else {
/* 169 */       if (!this.isFreeStanding) {
/* 170 */         trackBounds.height += 2;
/*     */       }
/*     */ 
/* 173 */       if (c.isEnabled()) {
/* 174 */         g.setColor(useNorm ? darkShadowColor : darkShadowColor2);
/* 175 */         g.drawLine(0, 0, trackBounds.width - 1, 0);
/* 176 */         g.drawLine(0, 1, 0, trackBounds.height - 2);
/* 177 */         g.drawLine(0, trackBounds.height - 2, trackBounds.width - 1, 
/* 178 */           trackBounds.height - 2);
/*     */ 
/* 180 */         g.drawLine(trackBounds.width - 1, 1, trackBounds.width - 1, 
/* 181 */           trackBounds.height - 1);
/*     */ 
/* 184 */         g.setColor(useNorm ? shadowColor : shadowColor2);
/*     */ 
/* 186 */         g.drawLine(1, 1, trackBounds.width - 2, 1);
/* 187 */         g.drawLine(1, 1, 1, trackBounds.height - 3);
/* 188 */         g.drawLine(0, trackBounds.height - 1, trackBounds.width - 1, 
/* 189 */           trackBounds.height - 1);
/*     */ 
/* 191 */         if (this.scrollbar.getValue() != this.scrollbar.getMaximum())
/*     */         {
/* 193 */           int x = this.thumbRect.x + this.thumbRect.width - trackBounds.x;
/* 194 */           g.drawLine(x, 1, x, trackBounds.height - 1);
/*     */         }
/*     */       } else {
/* 197 */         PlasticUtils.drawDisabledBorder(g, 0, 0, trackBounds.width, 
/* 198 */           trackBounds.height);
/*     */       }
/*     */ 
/* 201 */       if (!this.isFreeStanding) {
/* 202 */         trackBounds.height -= 2;
/*     */       }
/*     */     }
/* 205 */     g.translate(-trackBounds.x, -trackBounds.y);
/*     */   }
/*     */ 
/*     */   protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
/* 209 */     boolean useNorm = !c.getBackground().equals(PlasticXPUtils.BGCOL);
/* 210 */     if (!c.isEnabled()) {
/* 211 */       return;
/*     */     }
/*     */ 
/* 214 */     boolean leftToRight = PlasticUtils.isLeftToRight(c);
/*     */ 
/* 216 */     g.translate(thumbBounds.x, thumbBounds.y);
/*     */ 
/* 218 */     if (this.scrollbar.getOrientation() == 1) {
/* 219 */       if (!this.isFreeStanding) {
/* 220 */         if (!leftToRight) {
/* 221 */           thumbBounds.width += 1;
/* 222 */           g.translate(-1, 0);
/*     */         } else {
/* 224 */           thumbBounds.width += 2;
/*     */         }
/*     */       }
/*     */ 
/* 228 */       g.setColor(useNorm ? thumbColor : thumbColor2);
/* 229 */       g.fillRect(0, 0, thumbBounds.width - 2, thumbBounds.height - 1);
/*     */ 
/* 231 */       g.setColor(useNorm ? thumbShadow : thumbShadow2);
/* 232 */       g.drawRect(0, 0, thumbBounds.width - 2, thumbBounds.height - 1);
/*     */ 
/* 234 */       g.setColor(useNorm ? thumbHighlightColor : thumbHighlightColor2);
/* 235 */       g.drawLine(1, 1, thumbBounds.width - 3, 1);
/* 236 */       g.drawLine(1, 1, 1, thumbBounds.height - 2);
/*     */ 
/* 238 */       paintBumps(g, c, 3, 4, thumbBounds.width - 6, thumbBounds.height - 7);
/*     */ 
/* 240 */       if (!this.isFreeStanding)
/* 241 */         if (!leftToRight) {
/* 242 */           thumbBounds.width -= 1;
/* 243 */           g.translate(1, 0);
/*     */         } else {
/* 245 */           thumbBounds.width -= 2;
/*     */         }
/*     */     }
/*     */     else {
/* 249 */       if (!this.isFreeStanding) {
/* 250 */         thumbBounds.height += 2;
/*     */       }
/*     */ 
/* 253 */       g.setColor(useNorm ? thumbColor : thumbColor2);
/* 254 */       g.fillRect(0, 0, thumbBounds.width - 1, thumbBounds.height - 2);
/*     */ 
/* 256 */       g.setColor(useNorm ? thumbShadow : thumbShadow2);
/* 257 */       g.drawRect(0, 0, thumbBounds.width - 1, thumbBounds.height - 2);
/*     */ 
/* 259 */       g.setColor(useNorm ? thumbHighlightColor : thumbHighlightColor2);
/* 260 */       g.drawLine(1, 1, thumbBounds.width - 2, 1);
/* 261 */       g.drawLine(1, 1, 1, thumbBounds.height - 3);
/*     */ 
/* 263 */       paintBumps(g, c, 4, 3, thumbBounds.width - 7, thumbBounds.height - 6);
/*     */ 
/* 265 */       if (!this.isFreeStanding) {
/* 266 */         thumbBounds.height -= 2;
/*     */       }
/*     */     }
/* 269 */     g.translate(-thumbBounds.x, -thumbBounds.y);
/*     */ 
/* 271 */     if (PlasticUtils.is3D("ScrollBar."))
/* 272 */       paintThumb3D(g, thumbBounds);
/*     */   }
/*     */ 
/*     */   private void paintBumps(Graphics g, JComponent c, int x, int y, int width, int height)
/*     */   {
/* 277 */     boolean useNorm = !c.getBackground().equals(PlasticXPUtils.BGCOL);
/* 278 */     PlasticBumps theBumps = useNorm ? this.bumps : this.bumps2;
/*     */ 
/* 281 */     if (!useNarrowBumps()) {
/* 282 */       theBumps.setBumpArea(width, height);
/* 283 */       theBumps.paintIcon(c, g, x, y);
/*     */     } else {
/* 285 */       int MAX_WIDTH = UIManager.getInt("ScrollBar.maxBumpsWidth");
/* 286 */       int myWidth = Math.min(MAX_WIDTH, width);
/* 287 */       int myHeight = Math.min(MAX_WIDTH, height);
/* 288 */       int myX = x + (width - myWidth) / 2;
/* 289 */       int myY = y + (height - myHeight) / 2;
/* 290 */       theBumps.setBumpArea(myWidth, myHeight);
/* 291 */       theBumps.paintIcon(c, g, myX, myY);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void paintThumb3D(Graphics g, Rectangle thumbBounds) {
/* 296 */     boolean isHorizontal = this.scrollbar.getOrientation() == 0;
/* 297 */     int width = thumbBounds.width - (isHorizontal ? 3 : 1);
/* 298 */     int height = thumbBounds.height - (isHorizontal ? 1 : 3);
/* 299 */     Rectangle r = new Rectangle(thumbBounds.x + 2, thumbBounds.y + 2, width, height);
/* 300 */     PlasticUtils.addLight3DEffekt(g, r, isHorizontal);
/*     */   }
/*     */ 
/*     */   private boolean useNarrowBumps()
/*     */   {
/* 307 */     Object value = UIManager.get("ScrollBar.maxBumpsWidth");
/* 308 */     return (value != null) && ((value instanceof Integer));
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticScrollBarUI
 * JD-Core Version:    0.6.2
 */