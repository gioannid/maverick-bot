/*      */ package com.jgoodies.looks.plastic;
/*      */ 
/*      */ import com.jgoodies.looks.LookUtils;
/*      */ import com.jgoodies.looks.Options;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Insets;
/*      */ import java.awt.LayoutManager;
/*      */ import java.awt.Point;
/*      */ import java.awt.Polygon;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Shape;
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import javax.swing.Action;
/*      */ import javax.swing.ActionMap;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JTabbedPane;
/*      */ import javax.swing.JViewport;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.UIManager;
/*      */ import javax.swing.event.ChangeEvent;
/*      */ import javax.swing.event.ChangeListener;
/*      */ import javax.swing.plaf.ComponentUI;
/*      */ import javax.swing.plaf.UIResource;
/*      */ import javax.swing.plaf.basic.BasicTabbedPaneUI;
/*      */ import javax.swing.plaf.basic.BasicTabbedPaneUI.PropertyChangeHandler;
/*      */ import javax.swing.plaf.basic.BasicTabbedPaneUI.TabbedPaneLayout;
/*      */ import javax.swing.plaf.metal.MetalTabbedPaneUI;
/*      */ import javax.swing.text.View;
/*      */ 
/*      */ public final class PlasticTabbedPaneUI extends MetalTabbedPaneUI
/*      */ {
/*  126 */   private static boolean isTabIconsEnabled = Options.isTabIconsEnabled();
/*      */   private Boolean noContentBorder;
/*      */   private Boolean embeddedTabs;
/*      */   private AbstractRenderer renderer;
/*      */   private PlasticTabbedPaneUI.ScrollableTabSupport tabScroller;
/*  448 */   private int[] xCropLen = { 1, 1, 0, 0, 1, 1, 2, 2 };
/*      */ 
/*  450 */   private int[] yCropLen = { 0, 3, 3, 6, 6, 9, 9, 12 };
/*      */   private static final int CROP_SEGMENT = 12;
/*      */ 
/*      */   public static ComponentUI createUI(JComponent tabPane)
/*      */   {
/*  157 */     return new PlasticTabbedPaneUI();
/*      */   }
/*      */ 
/*      */   public void installUI(JComponent c)
/*      */   {
/*  166 */     super.installUI(c);
/*  167 */     this.embeddedTabs = ((Boolean)c.getClientProperty("jgoodies.embeddedTabs"));
/*  168 */     this.noContentBorder = ((Boolean)c.getClientProperty("jgoodies.noContentBorder"));
/*  169 */     this.renderer = createRenderer(this.tabPane);
/*      */   }
/*      */ 
/*      */   public void uninstallUI(JComponent c)
/*      */   {
/*  178 */     this.renderer = null;
/*  179 */     super.uninstallUI(c);
/*      */   }
/*      */ 
/*      */   protected void installComponents()
/*      */   {
/*  189 */     if ((scrollableTabLayoutEnabled()) && 
/*  190 */       (this.tabScroller == null)) {
/*  191 */       this.tabScroller = new PlasticTabbedPaneUI.ScrollableTabSupport(this, this.tabPane.getTabPlacement());
/*  192 */       this.tabPane.add(this.tabScroller.viewport);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void uninstallComponents()
/*      */   {
/*  204 */     if (scrollableTabLayoutEnabled()) {
/*  205 */       this.tabPane.remove(this.tabScroller.viewport);
/*  206 */       this.tabPane.remove(this.tabScroller.scrollForwardButton);
/*  207 */       this.tabPane.remove(this.tabScroller.scrollBackwardButton);
/*  208 */       this.tabScroller = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void installListeners() {
/*  213 */     super.installListeners();
/*      */ 
/*  220 */     if ((this.mouseListener != null) && (LookUtils.IS_JAVA_1_4) && 
/*  221 */       (scrollableTabLayoutEnabled())) {
/*  222 */       this.tabPane.removeMouseListener(this.mouseListener);
/*  223 */       this.tabScroller.tabPanel.addMouseListener(this.mouseListener);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void uninstallListeners()
/*      */   {
/*  229 */     if ((this.mouseListener != null) && (LookUtils.IS_JAVA_1_4)) {
/*  230 */       if (scrollableTabLayoutEnabled())
/*  231 */         this.tabScroller.tabPanel.removeMouseListener(this.mouseListener);
/*      */       else {
/*  233 */         this.tabPane.removeMouseListener(this.mouseListener);
/*      */       }
/*  235 */       this.mouseListener = null;
/*      */     }
/*  237 */     super.uninstallListeners();
/*      */   }
/*      */ 
/*      */   protected void installKeyboardActions() {
/*  241 */     super.installKeyboardActions();
/*      */ 
/*  245 */     if (scrollableTabLayoutEnabled()) {
/*  246 */       Action forwardAction = new PlasticTabbedPaneUI.ScrollTabsForwardAction();
/*  247 */       Action backwardAction = new PlasticTabbedPaneUI.ScrollTabsBackwardAction();
/*  248 */       ActionMap am = SwingUtilities.getUIActionMap(this.tabPane);
/*  249 */       am.put("scrollTabsForwardAction", forwardAction);
/*  250 */       am.put("scrollTabsBackwardAction", backwardAction);
/*  251 */       this.tabScroller.scrollForwardButton.setAction(forwardAction);
/*  252 */       this.tabScroller.scrollBackwardButton.setAction(backwardAction);
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean hasNoContentBorder()
/*      */   {
/*  262 */     return Boolean.TRUE.equals(this.noContentBorder);
/*      */   }
/*      */ 
/*      */   private boolean hasEmbeddedTabs()
/*      */   {
/*  269 */     return Boolean.TRUE.equals(this.embeddedTabs);
/*      */   }
/*      */ 
/*      */   private AbstractRenderer createRenderer(JTabbedPane tabbedPane)
/*      */   {
/*  280 */     return hasEmbeddedTabs() ? 
/*  281 */       AbstractRenderer.createEmbeddedRenderer(tabbedPane) : 
/*  282 */       AbstractRenderer.createRenderer(this.tabPane);
/*      */   }
/*      */ 
/*      */   protected PropertyChangeListener createPropertyChangeListener()
/*      */   {
/*  291 */     return new MyPropertyChangeHandler();
/*      */   }
/*      */ 
/*      */   protected ChangeListener createChangeListener() {
/*  295 */     return new TabSelectionHandler();
/*      */   }
/*      */ 
/*      */   private void doLayout()
/*      */   {
/*  302 */     this.tabPane.revalidate();
/*  303 */     this.tabPane.repaint();
/*      */   }
/*      */ 
/*      */   private void tabPlacementChanged()
/*      */   {
/*  311 */     this.renderer = createRenderer(this.tabPane);
/*  312 */     if (scrollableTabLayoutEnabled()) {
/*  313 */       this.tabScroller.createButtons();
/*      */     }
/*  315 */     doLayout();
/*      */   }
/*      */ 
/*      */   private void embeddedTabsPropertyChanged(Boolean newValue)
/*      */   {
/*  323 */     this.embeddedTabs = newValue;
/*  324 */     this.renderer = createRenderer(this.tabPane);
/*  325 */     doLayout();
/*      */   }
/*      */ 
/*      */   private void noContentBorderPropertyChanged(Boolean newValue)
/*      */   {
/*  333 */     this.noContentBorder = newValue;
/*  334 */     this.tabPane.repaint();
/*      */   }
/*      */ 
/*      */   public void paint(Graphics g, JComponent c) {
/*  338 */     int selectedIndex = this.tabPane.getSelectedIndex();
/*  339 */     int tabPlacement = this.tabPane.getTabPlacement();
/*      */ 
/*  341 */     ensureCurrentLayout();
/*      */ 
/*  347 */     if (!scrollableTabLayoutEnabled()) {
/*  348 */       paintTabArea(g, tabPlacement, selectedIndex);
/*      */     }
/*      */ 
/*  352 */     paintContentBorder(g, tabPlacement, selectedIndex);
/*      */   }
/*      */ 
/*      */   protected void paintTab(Graphics g, int tabPlacement, Rectangle[] theRects, int tabIndex, Rectangle iconRect, Rectangle textRect)
/*      */   {
/*  357 */     Rectangle tabRect = theRects[tabIndex];
/*  358 */     int selectedIndex = this.tabPane.getSelectedIndex();
/*  359 */     boolean isSelected = selectedIndex == tabIndex;
/*  360 */     Graphics2D g2 = null;
/*  361 */     Polygon cropShape = null;
/*  362 */     Shape save = null;
/*  363 */     int cropx = 0;
/*  364 */     int cropy = 0;
/*      */ 
/*  366 */     if ((scrollableTabLayoutEnabled()) && 
/*  367 */       ((g instanceof Graphics2D))) {
/*  368 */       g2 = (Graphics2D)g;
/*      */ 
/*  371 */       Rectangle viewRect = this.tabScroller.viewport.getViewRect();
/*      */ 
/*  373 */       switch (tabPlacement) {
/*      */       case 2:
/*      */       case 4:
/*  376 */         int cropline = viewRect.y + viewRect.height;
/*  377 */         if ((tabRect.y < cropline) && 
/*  378 */           (tabRect.y + tabRect.height > cropline)) {
/*  379 */           cropShape = createCroppedTabClip(tabPlacement, tabRect, 
/*  380 */             cropline);
/*  381 */           cropx = tabRect.x;
/*  382 */           cropy = cropline - 1;
/*      */         }
/*  384 */         break;
/*      */       case 1:
/*      */       case 3:
/*      */       default:
/*  388 */         int cropline = viewRect.x + viewRect.width;
/*  389 */         if ((tabRect.x < cropline) && 
/*  390 */           (tabRect.x + tabRect.width > cropline)) {
/*  391 */           cropShape = createCroppedTabClip(tabPlacement, tabRect, 
/*  392 */             cropline);
/*  393 */           cropx = cropline - 1;
/*  394 */           cropy = tabRect.y;
/*      */         }break;
/*      */       }
/*  397 */       if (cropShape != null) {
/*  398 */         save = g2.getClip();
/*  399 */         g2.clip(cropShape);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  404 */     paintTabBackground(g, tabPlacement, tabIndex, tabRect.x, tabRect.y, 
/*  405 */       tabRect.width, tabRect.height, isSelected);
/*      */ 
/*  407 */     paintTabBorder(g, tabPlacement, tabIndex, tabRect.x, tabRect.y, 
/*  408 */       tabRect.width, tabRect.height, isSelected);
/*      */ 
/*  410 */     String title = this.tabPane.getTitleAt(tabIndex);
/*  411 */     Font font = this.tabPane.getFont();
/*  412 */     FontMetrics metrics = g.getFontMetrics(font);
/*  413 */     Icon icon = getIconForTab(tabIndex);
/*      */ 
/*  415 */     layoutLabel(tabPlacement, metrics, tabIndex, title, icon, tabRect, 
/*  416 */       iconRect, textRect, isSelected);
/*      */ 
/*  418 */     paintText(g, tabPlacement, font, metrics, tabIndex, title, textRect, 
/*  419 */       isSelected);
/*      */ 
/*  421 */     paintIcon(g, tabPlacement, tabIndex, icon, iconRect, isSelected);
/*      */ 
/*  426 */     if (cropShape != null) {
/*  427 */       paintCroppedTabEdge(g, tabPlacement, tabIndex, isSelected, cropx, 
/*  428 */         cropy);
/*  429 */       g2.setClip(save);
/*      */     }
/*      */   }
/*      */ 
/*      */   private Polygon createCroppedTabClip(int tabPlacement, Rectangle tabRect, int cropline)
/*      */   {
/*  456 */     int rlen = 0;
/*  457 */     int start = 0;
/*  458 */     int end = 0;
/*  459 */     int ostart = 0;
/*      */ 
/*  461 */     switch (tabPlacement) {
/*      */     case 2:
/*      */     case 4:
/*  464 */       rlen = tabRect.width;
/*  465 */       start = tabRect.x;
/*  466 */       end = tabRect.x + tabRect.width;
/*  467 */       ostart = tabRect.y;
/*  468 */       break;
/*      */     case 1:
/*      */     case 3:
/*      */     default:
/*  472 */       rlen = tabRect.height;
/*  473 */       start = tabRect.y;
/*  474 */       end = tabRect.y + tabRect.height;
/*  475 */       ostart = tabRect.x;
/*      */     }
/*  477 */     int rcnt = rlen / 12;
/*  478 */     if (rlen % 12 > 0) {
/*  479 */       rcnt++;
/*      */     }
/*  481 */     int npts = 2 + rcnt * 8;
/*  482 */     int[] xp = new int[npts];
/*  483 */     int[] yp = new int[npts];
/*  484 */     int pcnt = 0;
/*      */ 
/*  486 */     xp[pcnt] = ostart;
/*  487 */     yp[(pcnt++)] = end;
/*  488 */     xp[pcnt] = ostart;
/*  489 */     yp[(pcnt++)] = start;
/*  490 */     for (int i = 0; i < rcnt; i++) {
/*  491 */       for (int j = 0; j < this.xCropLen.length; j++) {
/*  492 */         xp[pcnt] = (cropline - this.xCropLen[j]);
/*  493 */         yp[pcnt] = (start + i * 12 + this.yCropLen[j]);
/*  494 */         if (yp[pcnt] >= end) {
/*  495 */           yp[pcnt] = end;
/*  496 */           pcnt++;
/*  497 */           break;
/*      */         }
/*  499 */         pcnt++;
/*      */       }
/*      */     }
/*  502 */     if ((tabPlacement == 1) || 
/*  503 */       (tabPlacement == 3)) {
/*  504 */       return new Polygon(xp, yp, pcnt);
/*      */     }
/*      */ 
/*  508 */     return new Polygon(yp, xp, pcnt);
/*      */   }
/*      */ 
/*      */   private void paintCroppedTabEdge(Graphics g, int tabPlacement, int tabIndex, boolean isSelected, int x, int y)
/*      */   {
/*  517 */     switch (tabPlacement) {
/*      */     case 2:
/*      */     case 4:
/*  520 */       int xx = x;
/*  521 */       g.setColor(this.shadow);
/*  522 */       while (xx <= x + this.rects[tabIndex].width) {
/*  523 */         for (int i = 0; i < this.xCropLen.length; i += 2) {
/*  524 */           g.drawLine(xx + this.yCropLen[i], y - this.xCropLen[i], xx + 
/*  525 */             this.yCropLen[(i + 1)] - 1, y - this.xCropLen[(i + 1)]);
/*      */         }
/*  527 */         xx += 12;
/*      */       }
/*  529 */       break;
/*      */     case 1:
/*      */     case 3:
/*      */     default:
/*  533 */       int yy = y;
/*  534 */       g.setColor(this.shadow);
/*  535 */       while (yy <= y + this.rects[tabIndex].height) {
/*  536 */         for (int i = 0; i < this.xCropLen.length; i += 2) {
/*  537 */           g.drawLine(x - this.xCropLen[i], yy + this.yCropLen[i], x - 
/*  538 */             this.xCropLen[(i + 1)], yy + this.yCropLen[(i + 1)] - 1);
/*      */         }
/*  540 */         yy += 12;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void ensureCurrentLayout() {
/*  546 */     if (!this.tabPane.isValid()) {
/*  547 */       this.tabPane.validate();
/*      */     }
/*      */ 
/*  554 */     if (!this.tabPane.isValid()) {
/*  555 */       TabbedPaneLayout layout = (TabbedPaneLayout)this.tabPane.getLayout();
/*  556 */       layout.calculateLayoutInfo();
/*      */     }
/*      */   }
/*      */ 
/*      */   public int tabForCoordinate(JTabbedPane pane, int x, int y)
/*      */   {
/*  565 */     ensureCurrentLayout();
/*  566 */     Point p = new Point(x, y);
/*      */ 
/*  568 */     if (scrollableTabLayoutEnabled()) {
/*  569 */       translatePointToTabPanel(x, y, p);
/*  570 */       Rectangle viewRect = this.tabScroller.viewport.getViewRect();
/*  571 */       if (!viewRect.contains(p)) {
/*  572 */         return -1;
/*      */       }
/*      */     }
/*  575 */     int tabCount = this.tabPane.getTabCount();
/*  576 */     for (int i = 0; i < tabCount; i++) {
/*  577 */       if (this.rects[i].contains(p.x, p.y)) {
/*  578 */         return i;
/*      */       }
/*      */     }
/*  581 */     return -1;
/*      */   }
/*      */ 
/*      */   protected Rectangle getTabBounds(int tabIndex, Rectangle dest) {
/*  585 */     dest.width = this.rects[tabIndex].width;
/*  586 */     dest.height = this.rects[tabIndex].height;
/*  587 */     if (scrollableTabLayoutEnabled())
/*      */     {
/*  590 */       Point vpp = this.tabScroller.viewport.getLocation();
/*  591 */       Point viewp = this.tabScroller.viewport.getViewPosition();
/*  592 */       dest.x = (this.rects[tabIndex].x + vpp.x - viewp.x);
/*  593 */       dest.y = (this.rects[tabIndex].y + vpp.y - viewp.y);
/*      */     } else {
/*  595 */       dest.x = this.rects[tabIndex].x;
/*  596 */       dest.y = this.rects[tabIndex].y;
/*      */     }
/*  598 */     return dest;
/*      */   }
/*      */ 
/*      */   private int getClosestTab(int x, int y)
/*      */   {
/*  606 */     int min = 0;
/*  607 */     int tabCount = Math.min(this.rects.length, this.tabPane.getTabCount());
/*  608 */     int max = tabCount;
/*  609 */     int tabPlacement = this.tabPane.getTabPlacement();
/*  610 */     boolean useX = (tabPlacement == 1) || (tabPlacement == 3);
/*  611 */     int want = useX ? x : y;
/*      */ 
/*  613 */     while (min != max) {
/*  614 */       int current = (max + min) / 2;
/*      */       int maxLoc;
/*      */       int minLoc;
/*      */       int maxLoc;
/*  618 */       if (useX) {
/*  619 */         int minLoc = this.rects[current].x;
/*  620 */         maxLoc = minLoc + this.rects[current].width;
/*      */       } else {
/*  622 */         minLoc = this.rects[current].y;
/*  623 */         maxLoc = minLoc + this.rects[current].height;
/*      */       }
/*  625 */       if (want < minLoc) {
/*  626 */         max = current;
/*  627 */         if (min == max)
/*  628 */           return Math.max(0, current - 1);
/*      */       }
/*  630 */       else if (want >= maxLoc) {
/*  631 */         min = current;
/*  632 */         if (max - min <= 1)
/*  633 */           return Math.max(current + 1, tabCount - 1);
/*      */       }
/*      */       else {
/*  636 */         return current;
/*      */       }
/*      */     }
/*  639 */     return min;
/*      */   }
/*      */ 
/*      */   private Point translatePointToTabPanel(int srcx, int srcy, Point dest)
/*      */   {
/*  648 */     Point vpp = this.tabScroller.viewport.getLocation();
/*  649 */     Point viewp = this.tabScroller.viewport.getViewPosition();
/*  650 */     dest.x = (srcx - vpp.x + viewp.x);
/*  651 */     dest.y = (srcy - vpp.y + viewp.y);
/*  652 */     return dest;
/*      */   }
/*      */ 
/*      */   protected void paintTabArea(Graphics g, int tabPlacement, int selectedIndex) {
/*  656 */     int tabCount = this.tabPane.getTabCount();
/*      */ 
/*  658 */     Rectangle iconRect = new Rectangle(); Rectangle textRect = new Rectangle();
/*  659 */     Rectangle clipRect = g.getClipBounds();
/*      */ 
/*  662 */     for (int i = this.runCount - 1; i >= 0; i--) {
/*  663 */       int start = this.tabRuns[i];
/*  664 */       int next = this.tabRuns[(i + 1)];
/*  665 */       int end = next != 0 ? next - 1 : tabCount - 1;
/*  666 */       for (int j = end; j >= start; j--) {
/*  667 */         if ((j != selectedIndex) && (this.rects[j].intersects(clipRect))) {
/*  668 */           paintTab(g, tabPlacement, this.rects, j, iconRect, textRect);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  675 */     if ((selectedIndex >= 0) && (this.rects[selectedIndex].intersects(clipRect)))
/*  676 */       paintTab(g, tabPlacement, this.rects, selectedIndex, iconRect, textRect);
/*      */   }
/*      */ 
/*      */   protected void layoutLabel(int tabPlacement, FontMetrics metrics, int tabIndex, String title, Icon icon, Rectangle tabRect, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/*      */   {
/*  687 */     textRect.x = (textRect.y = iconRect.x = iconRect.y = 0);
/*      */ 
/*  689 */     View v = getTextViewForTab(tabIndex);
/*  690 */     if (v != null) {
/*  691 */       this.tabPane.putClientProperty("html", v);
/*      */     }
/*      */ 
/*  694 */     Rectangle calcRectangle = new Rectangle(tabRect);
/*  695 */     if (isSelected) {
/*  696 */       Insets calcInsets = getSelectedTabPadInsets(tabPlacement);
/*  697 */       calcRectangle.x += calcInsets.left;
/*  698 */       calcRectangle.y += calcInsets.top;
/*  699 */       calcRectangle.width -= calcInsets.left + calcInsets.right;
/*  700 */       calcRectangle.height -= calcInsets.bottom + calcInsets.top;
/*      */     }
/*  702 */     int xNudge = getTabLabelShiftX(tabPlacement, tabIndex, isSelected);
/*  703 */     int yNudge = getTabLabelShiftY(tabPlacement, tabIndex, isSelected);
/*  704 */     if (((tabPlacement == 4) || (tabPlacement == 2)) && (icon != null) && 
/*  705 */       (title != null) && (!title.equals(""))) {
/*  706 */       SwingUtilities.layoutCompoundLabel(this.tabPane, metrics, title, icon, 
/*  707 */         0, 2, 
/*  708 */         0, 11, calcRectangle, 
/*  709 */         iconRect, textRect, this.textIconGap);
/*  710 */       xNudge += 4;
/*      */     } else {
/*  712 */       SwingUtilities.layoutCompoundLabel(this.tabPane, metrics, title, icon, 
/*  713 */         0, 0, 
/*  714 */         0, 11, calcRectangle, 
/*  715 */         iconRect, textRect, this.textIconGap);
/*  716 */       iconRect.y += calcRectangle.height % 2;
/*      */     }
/*      */ 
/*  720 */     this.tabPane.putClientProperty("html", null);
/*      */ 
/*  722 */     iconRect.x += xNudge;
/*  723 */     iconRect.y += yNudge;
/*  724 */     textRect.x += xNudge;
/*  725 */     textRect.y += yNudge;
/*      */   }
/*      */ 
/*      */   protected Icon getIconForTab(int tabIndex)
/*      */   {
/*  734 */     String title = this.tabPane.getTitleAt(tabIndex);
/*  735 */     boolean hasTitle = (title != null) && (title.length() > 0);
/*  736 */     return (!isTabIconsEnabled) && (hasTitle) ? null : 
/*  737 */       super.getIconForTab(tabIndex);
/*      */   }
/*      */ 
/*      */   protected LayoutManager createLayoutManager()
/*      */   {
/*  744 */     if (this.tabPane.getTabLayoutPolicy() == 1) {
/*  745 */       return new TabbedPaneScrollLayout();
/*      */     }
/*      */ 
/*  748 */     return new TabbedPaneLayout();
/*      */   }
/*      */ 
/*      */   private boolean scrollableTabLayoutEnabled()
/*      */   {
/*  758 */     return this.tabPane.getLayout() instanceof TabbedPaneScrollLayout;
/*      */   }
/*      */ 
/*      */   protected boolean isTabInFirstRun(int tabIndex) {
/*  762 */     return getRunForTab(this.tabPane.getTabCount(), tabIndex) == 0;
/*      */   }
/*      */ 
/*      */   protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex)
/*      */   {
/*  767 */     int width = this.tabPane.getWidth();
/*  768 */     int height = this.tabPane.getHeight();
/*  769 */     Insets insets = this.tabPane.getInsets();
/*      */ 
/*  771 */     int x = insets.left;
/*  772 */     int y = insets.top;
/*  773 */     int w = width - insets.right - insets.left;
/*  774 */     int h = height - insets.top - insets.bottom;
/*      */ 
/*  776 */     switch (tabPlacement) {
/*      */     case 2:
/*  778 */       x += calculateTabAreaWidth(tabPlacement, this.runCount, this.maxTabWidth);
/*  779 */       w -= x - insets.left;
/*  780 */       break;
/*      */     case 4:
/*  782 */       w -= calculateTabAreaWidth(tabPlacement, this.runCount, this.maxTabWidth);
/*  783 */       break;
/*      */     case 3:
/*  785 */       h -= calculateTabAreaHeight(tabPlacement, this.runCount, this.maxTabHeight);
/*  786 */       break;
/*      */     case 1:
/*      */     default:
/*  789 */       y += calculateTabAreaHeight(tabPlacement, this.runCount, this.maxTabHeight);
/*  790 */       h -= y - insets.top;
/*      */     }
/*      */ 
/*  793 */     g.setColor(this.selectColor == null ? this.tabPane.getBackground() : this.selectColor);
/*  794 */     g.fillRect(x, y, w, h);
/*      */ 
/*  797 */     Rectangle selRect = selectedIndex < 0 ? null : 
/*  798 */       getTabBounds(selectedIndex, 
/*  798 */       this.calcRect);
/*  799 */     boolean drawBroken = (selectedIndex >= 0) && (isTabInFirstRun(selectedIndex));
/*  800 */     boolean isContentBorderPainted = !hasNoContentBorder();
/*      */ 
/*  805 */     this.renderer.paintContentBorderTopEdge(g, x, y, w, h, drawBroken, selRect, 
/*  806 */       isContentBorderPainted);
/*  807 */     this.renderer.paintContentBorderLeftEdge(g, x, y, w, h, drawBroken, selRect, 
/*  808 */       isContentBorderPainted);
/*  809 */     this.renderer.paintContentBorderBottomEdge(g, x, y, w, h, drawBroken, selRect, 
/*  810 */       isContentBorderPainted);
/*  811 */     this.renderer.paintContentBorderRightEdge(g, x, y, w, h, drawBroken, selRect, 
/*  812 */       isContentBorderPainted);
/*      */   }
/*      */ 
/*      */   protected Insets getContentBorderInsets(int tabPlacement)
/*      */   {
/*  823 */     return this.renderer.getContentBorderInsets(
/*  824 */       super.getContentBorderInsets(tabPlacement));
/*      */   }
/*      */ 
/*      */   protected Insets getTabAreaInsets(int tabPlacement)
/*      */   {
/*  831 */     return this.renderer.getTabAreaInsets(super.getTabAreaInsets(tabPlacement));
/*      */   }
/*      */ 
/*      */   protected int getTabLabelShiftX(int tabPlacement, int tabIndex, boolean isSelected)
/*      */   {
/*  839 */     return this.renderer.getTabLabelShiftX(tabIndex, isSelected);
/*      */   }
/*      */ 
/*      */   protected int getTabLabelShiftY(int tabPlacement, int tabIndex, boolean isSelected)
/*      */   {
/*  847 */     return this.renderer.getTabLabelShiftY(tabIndex, isSelected);
/*      */   }
/*      */ 
/*      */   protected int getTabRunOverlay(int tabPlacement)
/*      */   {
/*  854 */     return this.renderer.getTabRunOverlay(this.tabRunOverlay);
/*      */   }
/*      */ 
/*      */   protected boolean shouldPadTabRun(int tabPlacement, int run)
/*      */   {
/*  862 */     return this.renderer.shouldPadTabRun(run, super
/*  863 */       .shouldPadTabRun(tabPlacement, 
/*  863 */       run));
/*      */   }
/*      */ 
/*      */   protected int getTabRunIndent(int tabPlacement, int run)
/*      */   {
/*  871 */     return this.renderer.getTabRunIndent(run);
/*      */   }
/*      */ 
/*      */   protected Insets getTabInsets(int tabPlacement, int tabIndex)
/*      */   {
/*  878 */     return this.renderer.getTabInsets(tabIndex, this.tabInsets);
/*      */   }
/*      */ 
/*      */   protected Insets getSelectedTabPadInsets(int tabPlacement)
/*      */   {
/*  885 */     return this.renderer.getSelectedTabPadInsets();
/*      */   }
/*      */ 
/*      */   protected void paintFocusIndicator(Graphics g, int tabPlacement, Rectangle[] rectangles, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/*      */   {
/*  894 */     this.renderer.paintFocusIndicator(g, rectangles, tabIndex, iconRect, textRect, 
/*  895 */       isSelected);
/*      */   }
/*      */ 
/*      */   protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */   {
/*  905 */     this.renderer.paintTabBackground(g, tabIndex, x, y, w, h, isSelected);
/*      */   }
/*      */ 
/*      */   protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */   {
/*  915 */     this.renderer.paintTabBorder(g, tabIndex, x, y, w, h, isSelected);
/*      */   }
/*      */ 
/*      */   protected boolean shouldRotateTabRuns(int tabPlacement)
/*      */   {
/*  924 */     return false;
/*      */   }
/*      */ 
/*      */   private boolean requestFocusForVisibleComponent()
/*      */   {
/* 1207 */     Component visibleComponent = getVisibleComponent();
/* 1208 */     if (visibleComponent.isFocusable()) {
/* 1209 */       visibleComponent.requestFocus();
/* 1210 */       return true;
/* 1211 */     }if (((visibleComponent instanceof JComponent)) && 
/* 1212 */       (((JComponent)visibleComponent).requestDefaultFocus())) {
/* 1213 */       return true;
/*      */     }
/*      */ 
/* 1216 */     return false;
/*      */   }
/*      */ 
/*      */   private class TabSelectionHandler
/*      */     implements ChangeListener
/*      */   {
/*  929 */     private Rectangle rect = new Rectangle();
/*      */ 
/*      */     TabSelectionHandler() {  } 
/*  932 */     public void stateChanged(ChangeEvent e) { JTabbedPane tp = (JTabbedPane)e.getSource();
/*  933 */       tp.revalidate();
/*  934 */       tp.repaint();
/*      */ 
/*  936 */       if (tp.getTabLayoutPolicy() == 1) {
/*  937 */         int index = tp.getSelectedIndex();
/*  938 */         if ((index < PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this).length) && (index != -1)) {
/*  939 */           this.rect.setBounds(PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[index]);
/*  940 */           Point viewPosition = PlasticTabbedPaneUI.this.tabScroller.viewport.getViewPosition();
/*  941 */           if (this.rect.x < viewPosition.x)
/*  942 */             this.rect.x -= PlasticTabbedPaneUI.this.renderer.getTabsOverlay();
/*      */           else {
/*  944 */             this.rect.x += PlasticTabbedPaneUI.this.renderer.getTabsOverlay();
/*      */           }
/*  946 */           PlasticTabbedPaneUI.this.tabScroller.tabPanel.scrollRectToVisible(this.rect);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private class MyPropertyChangeHandler extends BasicTabbedPaneUI.PropertyChangeHandler
/*      */   {
/*      */     MyPropertyChangeHandler()
/*      */     {
/*  957 */       super();
/*      */     }
/*      */     public void propertyChange(PropertyChangeEvent e) {
/*  960 */       String pName = e.getPropertyName();
/*      */ 
/*  962 */       if (pName == null) {
/*  963 */         return;
/*      */       }
/*      */ 
/*  966 */       super.propertyChange(e);
/*      */ 
/*  968 */       if (pName.equals("tabPlacement")) {
/*  969 */         PlasticTabbedPaneUI.this.tabPlacementChanged();
/*  970 */         return;
/*      */       }
/*  972 */       if (pName.equals("jgoodies.embeddedTabs")) {
/*  973 */         PlasticTabbedPaneUI.this.embeddedTabsPropertyChanged((Boolean)e.getNewValue());
/*  974 */         return;
/*      */       }
/*  976 */       if (pName.equals("jgoodies.noContentBorder")) {
/*  977 */         PlasticTabbedPaneUI.this.noContentBorderPropertyChanged((Boolean)e.getNewValue());
/*  978 */         return;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private class TabbedPaneLayout extends BasicTabbedPaneUI.TabbedPaneLayout implements LayoutManager
/*      */   {
/*      */     TabbedPaneLayout()
/*      */     {
/*  987 */       super();
/*      */     }
/*      */ 
/*      */     protected void calculateTabRects(int tabPlacement, int tabCount) {
/*  991 */       FontMetrics metrics = PlasticTabbedPaneUI.this.getFontMetrics();
/*  992 */       Dimension size = PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this).getSize();
/*  993 */       Insets insets = PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this).getInsets();
/*  994 */       Insets theTabAreaInsets = PlasticTabbedPaneUI.this.getTabAreaInsets(tabPlacement);
/*  995 */       int fontHeight = metrics.getHeight();
/*  996 */       int selectedIndex = PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this).getSelectedIndex();
/*      */ 
/* 1001 */       boolean verticalTabRuns = (tabPlacement == 2) || (tabPlacement == 4);
/* 1002 */       boolean leftToRight = PlasticUtils.isLeftToRight(PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this));
/*      */       int returnAt;
/*      */       int returnAt;
/*      */       int returnAt;
/*      */       int x;
/*      */       int y;
/*      */       int returnAt;
/* 1007 */       switch (tabPlacement) {
/*      */       case 2:
/* 1009 */         PlasticTabbedPaneUI.access$9(PlasticTabbedPaneUI.this, PlasticTabbedPaneUI.this.calculateMaxTabWidth(tabPlacement));
/* 1010 */         int x = insets.left + theTabAreaInsets.left;
/* 1011 */         int y = insets.top + theTabAreaInsets.top;
/* 1012 */         returnAt = size.height - (insets.bottom + theTabAreaInsets.bottom);
/* 1013 */         break;
/*      */       case 4:
/* 1015 */         PlasticTabbedPaneUI.access$9(PlasticTabbedPaneUI.this, PlasticTabbedPaneUI.this.calculateMaxTabWidth(tabPlacement));
/* 1016 */         int x = size.width - insets.right - theTabAreaInsets.right - 
/* 1017 */           PlasticTabbedPaneUI.access$10(PlasticTabbedPaneUI.this);
/* 1018 */         int y = insets.top + theTabAreaInsets.top;
/* 1019 */         returnAt = size.height - (insets.bottom + theTabAreaInsets.bottom);
/* 1020 */         break;
/*      */       case 3:
/* 1022 */         PlasticTabbedPaneUI.access$12(PlasticTabbedPaneUI.this, PlasticTabbedPaneUI.this.calculateMaxTabHeight(tabPlacement));
/* 1023 */         int x = insets.left + theTabAreaInsets.left;
/* 1024 */         int y = size.height - insets.bottom - theTabAreaInsets.bottom - 
/* 1025 */           PlasticTabbedPaneUI.access$13(PlasticTabbedPaneUI.this);
/* 1026 */         returnAt = size.width - (insets.right + theTabAreaInsets.right);
/* 1027 */         break;
/*      */       case 1:
/*      */       default:
/* 1030 */         PlasticTabbedPaneUI.access$12(PlasticTabbedPaneUI.this, PlasticTabbedPaneUI.this.calculateMaxTabHeight(tabPlacement));
/* 1031 */         x = insets.left + theTabAreaInsets.left;
/* 1032 */         y = insets.top + theTabAreaInsets.top;
/* 1033 */         returnAt = size.width - (insets.right + theTabAreaInsets.right);
/*      */       }
/*      */ 
/* 1037 */       int theTabRunOverlay = PlasticTabbedPaneUI.this.getTabRunOverlay(tabPlacement);
/*      */ 
/* 1039 */       PlasticTabbedPaneUI.access$14(PlasticTabbedPaneUI.this, 0);
/* 1040 */       PlasticTabbedPaneUI.access$15(PlasticTabbedPaneUI.this, -1);
/*      */ 
/* 1045 */       int tabInRun = -1;
/*      */ 
/* 1048 */       int runReturnAt = returnAt;
/*      */ 
/* 1050 */       if (tabCount == 0) {
/* 1051 */         return;
/*      */       }
/*      */ 
/* 1056 */       for (int i = 0; i < tabCount; i++) {
/* 1057 */         Rectangle rect = PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[i];
/* 1058 */         tabInRun++;
/*      */ 
/* 1060 */         if (!verticalTabRuns)
/*      */         {
/* 1062 */           if (i > 0) {
/* 1063 */             rect.x = (PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[(i - 1)].x + PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[(i - 1)].width);
/*      */           } else {
/* 1065 */             PlasticTabbedPaneUI.access$16(PlasticTabbedPaneUI.this)[0] = 0;
/* 1066 */             PlasticTabbedPaneUI.access$14(PlasticTabbedPaneUI.this, 1);
/* 1067 */             PlasticTabbedPaneUI.access$9(PlasticTabbedPaneUI.this, 0);
/* 1068 */             rect.x = x;
/*      */           }
/*      */ 
/* 1071 */           rect.width = PlasticTabbedPaneUI.this.calculateTabWidth(tabPlacement, i, metrics);
/* 1072 */           PlasticTabbedPaneUI.access$9(PlasticTabbedPaneUI.this, Math.max(PlasticTabbedPaneUI.access$10(PlasticTabbedPaneUI.this), rect.width));
/*      */ 
/* 1081 */           if ((tabInRun != 0) && (rect.x + rect.width > runReturnAt)) {
/* 1082 */             if (PlasticTabbedPaneUI.access$18(PlasticTabbedPaneUI.this) > PlasticTabbedPaneUI.access$16(PlasticTabbedPaneUI.this).length - 1) {
/* 1083 */               PlasticTabbedPaneUI.this.expandTabRunsArray();
/*      */             }
/*      */ 
/* 1086 */             tabInRun = 0;
/* 1087 */             PlasticTabbedPaneUI.access$16(PlasticTabbedPaneUI.this)[PlasticTabbedPaneUI.access$18(PlasticTabbedPaneUI.this)] = i;
/*      */             PlasticTabbedPaneUI tmp648_645 = PlasticTabbedPaneUI.this; PlasticTabbedPaneUI.access$14(tmp648_645, PlasticTabbedPaneUI.access$18(tmp648_645) + 1);
/* 1089 */             rect.x = x;
/*      */ 
/* 1091 */             runReturnAt = runReturnAt - 2 * 
/* 1091 */               PlasticTabbedPaneUI.this.getTabRunIndent(tabPlacement, PlasticTabbedPaneUI.access$18(PlasticTabbedPaneUI.this));
/*      */           }
/*      */ 
/* 1094 */           rect.y = y;
/* 1095 */           rect.height = PlasticTabbedPaneUI.access$13(PlasticTabbedPaneUI.this);
/*      */         }
/*      */         else
/*      */         {
/* 1099 */           if (i > 0) {
/* 1100 */             rect.y = (PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[(i - 1)].y + PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[(i - 1)].height);
/*      */           } else {
/* 1102 */             PlasticTabbedPaneUI.access$16(PlasticTabbedPaneUI.this)[0] = 0;
/* 1103 */             PlasticTabbedPaneUI.access$14(PlasticTabbedPaneUI.this, 1);
/* 1104 */             PlasticTabbedPaneUI.access$12(PlasticTabbedPaneUI.this, 0);
/* 1105 */             rect.y = y;
/*      */           }
/*      */ 
/* 1108 */           rect.height = PlasticTabbedPaneUI.this.calculateTabHeight(tabPlacement, i, fontHeight);
/* 1109 */           PlasticTabbedPaneUI.access$12(PlasticTabbedPaneUI.this, Math.max(PlasticTabbedPaneUI.access$13(PlasticTabbedPaneUI.this), rect.height));
/*      */ 
/* 1116 */           if ((tabInRun != 0) && (rect.y + rect.height > runReturnAt)) {
/* 1117 */             if (PlasticTabbedPaneUI.access$18(PlasticTabbedPaneUI.this) > PlasticTabbedPaneUI.access$16(PlasticTabbedPaneUI.this).length - 1) {
/* 1118 */               PlasticTabbedPaneUI.this.expandTabRunsArray();
/*      */             }
/* 1120 */             PlasticTabbedPaneUI.access$16(PlasticTabbedPaneUI.this)[PlasticTabbedPaneUI.access$18(PlasticTabbedPaneUI.this)] = i;
/*      */             PlasticTabbedPaneUI tmp893_890 = PlasticTabbedPaneUI.this; PlasticTabbedPaneUI.access$14(tmp893_890, PlasticTabbedPaneUI.access$18(tmp893_890) + 1);
/* 1122 */             rect.y = y;
/* 1123 */             tabInRun = 0;
/* 1124 */             runReturnAt -= 2 * PlasticTabbedPaneUI.this.getTabRunIndent(tabPlacement, PlasticTabbedPaneUI.access$18(PlasticTabbedPaneUI.this));
/*      */           }
/*      */ 
/* 1127 */           rect.x = x;
/* 1128 */           rect.width = PlasticTabbedPaneUI.access$10(PlasticTabbedPaneUI.this);
/*      */         }
/*      */ 
/* 1131 */         if (i == selectedIndex) {
/* 1132 */           PlasticTabbedPaneUI.access$15(PlasticTabbedPaneUI.this, PlasticTabbedPaneUI.access$18(PlasticTabbedPaneUI.this) - 1);
/*      */         }
/*      */       }
/*      */ 
/* 1136 */       if (PlasticTabbedPaneUI.access$18(PlasticTabbedPaneUI.this) > 1)
/*      */       {
/* 1145 */         if (PlasticTabbedPaneUI.this.shouldRotateTabRuns(tabPlacement)) {
/* 1146 */           rotateTabRuns(tabPlacement, PlasticTabbedPaneUI.access$21(PlasticTabbedPaneUI.this));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1152 */       for (i = PlasticTabbedPaneUI.access$18(PlasticTabbedPaneUI.this) - 1; i >= 0; i--) {
/* 1153 */         int start = PlasticTabbedPaneUI.access$16(PlasticTabbedPaneUI.this)[i];
/* 1154 */         int next = PlasticTabbedPaneUI.access$16(PlasticTabbedPaneUI.this)[(i + 1)];
/* 1155 */         int end = next != 0 ? next - 1 : tabCount - 1;
/* 1156 */         int indent = PlasticTabbedPaneUI.this.getTabRunIndent(tabPlacement, i);
/* 1157 */         if (!verticalTabRuns) {
/* 1158 */           for (int j = start; j <= end; j++) {
/* 1159 */             Rectangle rect = PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[j];
/* 1160 */             rect.y = y;
/* 1161 */             rect.x += indent;
/*      */           }
/*      */ 
/* 1165 */           if (PlasticTabbedPaneUI.this.shouldPadTabRun(tabPlacement, i)) {
/* 1166 */             padTabRun(tabPlacement, start, end, returnAt - 2 * indent);
/*      */           }
/* 1168 */           if (tabPlacement == 3)
/* 1169 */             y -= PlasticTabbedPaneUI.access$13(PlasticTabbedPaneUI.this) - theTabRunOverlay;
/*      */           else
/* 1171 */             y += PlasticTabbedPaneUI.access$13(PlasticTabbedPaneUI.this) - theTabRunOverlay;
/*      */         }
/*      */         else {
/* 1174 */           for (int j = start; j <= end; j++) {
/* 1175 */             Rectangle rect = PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[j];
/* 1176 */             rect.x = x;
/* 1177 */             rect.y += indent;
/*      */           }
/* 1179 */           if (PlasticTabbedPaneUI.this.shouldPadTabRun(tabPlacement, i)) {
/* 1180 */             padTabRun(tabPlacement, start, end, returnAt - 2 * indent);
/*      */           }
/* 1182 */           if (tabPlacement == 4)
/* 1183 */             x -= PlasticTabbedPaneUI.access$10(PlasticTabbedPaneUI.this) - theTabRunOverlay;
/*      */           else {
/* 1185 */             x += PlasticTabbedPaneUI.access$10(PlasticTabbedPaneUI.this) - theTabRunOverlay;
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1191 */       padSelectedTab(tabPlacement, selectedIndex);
/*      */ 
/* 1195 */       if ((!leftToRight) && (!verticalTabRuns)) {
/* 1196 */         int rightMargin = size.width - (
/* 1197 */           insets.right + theTabAreaInsets.right);
/* 1198 */         for (i = 0; i < tabCount; i++)
/* 1199 */           PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[i].x = 
/* 1200 */             (rightMargin - PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[i].x - PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[i].width + 
/* 1200 */             PlasticTabbedPaneUI.this.renderer.getTabsOverlay());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private class TabbedPaneScrollLayout extends PlasticTabbedPaneUI.TabbedPaneLayout
/*      */   {
/*      */     TabbedPaneScrollLayout()
/*      */     {
/* 1259 */       super();
/*      */     }
/*      */     protected int preferredTabAreaHeight(int tabPlacement, int width) {
/* 1262 */       return PlasticTabbedPaneUI.this.calculateMaxTabHeight(tabPlacement);
/*      */     }
/*      */ 
/*      */     protected int preferredTabAreaWidth(int tabPlacement, int height) {
/* 1266 */       return PlasticTabbedPaneUI.this.calculateMaxTabWidth(tabPlacement);
/*      */     }
/*      */ 
/*      */     public void layoutContainer(Container parent) {
/* 1270 */       int tabPlacement = PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this).getTabPlacement();
/* 1271 */       int tabCount = PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this).getTabCount();
/* 1272 */       Insets insets = PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this).getInsets();
/* 1273 */       int selectedIndex = PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this).getSelectedIndex();
/* 1274 */       Component visibleComponent = PlasticTabbedPaneUI.this.getVisibleComponent();
/*      */ 
/* 1276 */       calculateLayoutInfo();
/*      */ 
/* 1278 */       if (selectedIndex < 0) {
/* 1279 */         if (visibleComponent != null)
/*      */         {
/* 1281 */           PlasticTabbedPaneUI.this.setVisibleComponent(null);
/*      */         }
/*      */       } else {
/* 1284 */         Component selectedComponent = PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this).getComponentAt(selectedIndex);
/* 1285 */         boolean shouldChangeFocus = false;
/*      */ 
/* 1294 */         if (selectedComponent != null) {
/* 1295 */           if ((selectedComponent != visibleComponent) && 
/* 1296 */             (visibleComponent != null) && 
/* 1297 */             (SwingUtilities.findFocusOwner(visibleComponent) != null)) {
/* 1298 */             shouldChangeFocus = true;
/*      */           }
/*      */ 
/* 1301 */           PlasticTabbedPaneUI.this.setVisibleComponent(selectedComponent);
/*      */         }
/*      */ 
/* 1305 */         Insets contentInsets = PlasticTabbedPaneUI.this.getContentBorderInsets(tabPlacement);
/* 1306 */         Rectangle bounds = PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this).getBounds();
/* 1307 */         int numChildren = PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this).getComponentCount();
/*      */ 
/* 1309 */         if (numChildren > 0)
/*      */         {
/*      */           int ch;
/*      */           int ch;
/*      */           int ch;
/*      */           int tw;
/*      */           int th;
/*      */           int tx;
/*      */           int ty;
/*      */           int cx;
/*      */           int cy;
/*      */           int cw;
/*      */           int ch;
/* 1310 */           switch (tabPlacement)
/*      */           {
/*      */           case 2:
/* 1313 */             int tw = PlasticTabbedPaneUI.this
/* 1314 */               .calculateTabAreaWidth(tabPlacement, PlasticTabbedPaneUI.access$18(PlasticTabbedPaneUI.this), 
/* 1314 */               PlasticTabbedPaneUI.access$10(PlasticTabbedPaneUI.this));
/* 1315 */             int th = bounds.height - insets.top - insets.bottom;
/* 1316 */             int tx = insets.left;
/* 1317 */             int ty = insets.top;
/*      */ 
/* 1320 */             int cx = tx + tw + contentInsets.left;
/* 1321 */             int cy = ty + contentInsets.top;
/* 1322 */             int cw = bounds.width - insets.left - insets.right - tw - 
/* 1323 */               contentInsets.left - contentInsets.right;
/* 1324 */             ch = bounds.height - insets.top - insets.bottom - 
/* 1325 */               contentInsets.top - contentInsets.bottom;
/* 1326 */             break;
/*      */           case 4:
/* 1329 */             int tw = PlasticTabbedPaneUI.this
/* 1330 */               .calculateTabAreaWidth(tabPlacement, PlasticTabbedPaneUI.access$18(PlasticTabbedPaneUI.this), 
/* 1330 */               PlasticTabbedPaneUI.access$10(PlasticTabbedPaneUI.this));
/* 1331 */             int th = bounds.height - insets.top - insets.bottom;
/* 1332 */             int tx = bounds.width - insets.right - tw;
/* 1333 */             int ty = insets.top;
/*      */ 
/* 1336 */             int cx = insets.left + contentInsets.left;
/* 1337 */             int cy = insets.top + contentInsets.top;
/* 1338 */             int cw = bounds.width - insets.left - insets.right - tw - 
/* 1339 */               contentInsets.left - contentInsets.right;
/* 1340 */             ch = bounds.height - insets.top - insets.bottom - 
/* 1341 */               contentInsets.top - contentInsets.bottom;
/* 1342 */             break;
/*      */           case 3:
/* 1345 */             int tw = bounds.width - insets.left - insets.right;
/* 1346 */             int th = PlasticTabbedPaneUI.this
/* 1347 */               .calculateTabAreaHeight(tabPlacement, PlasticTabbedPaneUI.access$18(PlasticTabbedPaneUI.this), 
/* 1347 */               PlasticTabbedPaneUI.access$13(PlasticTabbedPaneUI.this));
/* 1348 */             int tx = insets.left;
/* 1349 */             int ty = bounds.height - insets.bottom - th;
/*      */ 
/* 1352 */             int cx = insets.left + contentInsets.left;
/* 1353 */             int cy = insets.top + contentInsets.top;
/* 1354 */             int cw = bounds.width - insets.left - insets.right - 
/* 1355 */               contentInsets.left - contentInsets.right;
/* 1356 */             ch = bounds.height - insets.top - insets.bottom - th - 
/* 1357 */               contentInsets.top - contentInsets.bottom;
/* 1358 */             break;
/*      */           case 1:
/*      */           default:
/* 1362 */             tw = bounds.width - insets.left - insets.right;
/* 1363 */             th = PlasticTabbedPaneUI.this
/* 1364 */               .calculateTabAreaHeight(tabPlacement, PlasticTabbedPaneUI.access$18(PlasticTabbedPaneUI.this), 
/* 1364 */               PlasticTabbedPaneUI.access$13(PlasticTabbedPaneUI.this));
/* 1365 */             tx = insets.left;
/* 1366 */             ty = insets.top;
/*      */ 
/* 1369 */             cx = tx + contentInsets.left;
/* 1370 */             cy = ty + th + contentInsets.top;
/* 1371 */             cw = bounds.width - insets.left - insets.right - 
/* 1372 */               contentInsets.left - contentInsets.right;
/* 1373 */             ch = bounds.height - insets.top - insets.bottom - th - 
/* 1374 */               contentInsets.top - contentInsets.bottom;
/*      */           }
/*      */ 
/* 1377 */           for (int i = 0; i < numChildren; i++) {
/* 1378 */             Component child = PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this).getComponent(i);
/*      */ 
/* 1380 */             if ((PlasticTabbedPaneUI.this.tabScroller != null) && (child == PlasticTabbedPaneUI.this.tabScroller.viewport)) {
/* 1381 */               JViewport viewport = (JViewport)child;
/* 1382 */               Rectangle viewRect = viewport.getViewRect();
/* 1383 */               int vw = tw;
/* 1384 */               int vh = th;
/* 1385 */               Dimension butSize = PlasticTabbedPaneUI.this.tabScroller.scrollForwardButton
/* 1386 */                 .getPreferredSize();
/* 1387 */               switch (tabPlacement) {
/*      */               case 2:
/*      */               case 4:
/* 1390 */                 int totalTabHeight = PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[(tabCount - 1)].y + 
/* 1391 */                   PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[(tabCount - 1)].height;
/* 1392 */                 if (totalTabHeight > th)
/*      */                 {
/* 1394 */                   vh = th > 2 * butSize.height ? th - 2 * 
/* 1395 */                     butSize.height : 0;
/* 1396 */                   if (totalTabHeight - viewRect.y <= vh)
/*      */                   {
/* 1401 */                     vh = totalTabHeight - viewRect.y;
/*      */                   }
/*      */                 }
/* 1404 */                 break;
/*      */               case 1:
/*      */               case 3:
/*      */               default:
/* 1408 */                 int totalTabWidth = PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[(tabCount - 1)].x + 
/* 1409 */                   PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[(tabCount - 1)].width + 
/* 1410 */                   PlasticTabbedPaneUI.this.renderer.getTabsOverlay();
/* 1411 */                 if (totalTabWidth > tw)
/*      */                 {
/* 1413 */                   vw = tw > 2 * butSize.width ? tw - 2 * 
/* 1414 */                     butSize.width : 0;
/* 1415 */                   if (totalTabWidth - viewRect.x <= vw)
/*      */                   {
/* 1420 */                     vw = totalTabWidth - viewRect.x;
/*      */                   }
/*      */                 }
/*      */                 break;
/*      */               }
/* 1424 */               child.setBounds(tx, ty, vw, vh);
/*      */             }
/* 1426 */             else if ((PlasticTabbedPaneUI.this.tabScroller != null) && (
/* 1427 */               (child == PlasticTabbedPaneUI.this.tabScroller.scrollForwardButton) || (child == PlasticTabbedPaneUI.this.tabScroller.scrollBackwardButton))) {
/* 1428 */               Component scrollbutton = child;
/* 1429 */               Dimension bsize = scrollbutton.getPreferredSize();
/* 1430 */               int bx = 0;
/* 1431 */               int by = 0;
/* 1432 */               int bw = bsize.width;
/* 1433 */               int bh = bsize.height;
/* 1434 */               boolean visible = false;
/*      */ 
/* 1436 */               switch (tabPlacement) {
/*      */               case 2:
/*      */               case 4:
/* 1439 */                 int totalTabHeight = PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[(tabCount - 1)].y + 
/* 1440 */                   PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[(tabCount - 1)].height;
/* 1441 */                 if (totalTabHeight > th) {
/* 1442 */                   visible = true;
/* 1443 */                   bx = tabPlacement == 2 ? tx + tw - bsize.width : 
/* 1444 */                     tx;
/* 1445 */                   by = child == PlasticTabbedPaneUI.this.tabScroller.scrollForwardButton ? bounds.height - 
/* 1446 */                     insets.bottom - bsize.height : 
/* 1447 */                     bounds.height - insets.bottom - 2 * 
/* 1448 */                     bsize.height;
/*      */                 }
/* 1450 */                 break;
/*      */               case 1:
/*      */               case 3:
/*      */               default:
/* 1455 */                 int totalTabWidth = PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[(tabCount - 1)].x + 
/* 1456 */                   PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[(tabCount - 1)].width;
/*      */ 
/* 1458 */                 if (totalTabWidth > tw) {
/* 1459 */                   visible = true;
/* 1460 */                   bx = child == PlasticTabbedPaneUI.this.tabScroller.scrollForwardButton ? bounds.width - 
/* 1461 */                     insets.left - bsize.width : 
/* 1462 */                     bounds.width - insets.left - 2 * bsize.width;
/* 1463 */                   by = tabPlacement == 1 ? ty + th - bsize.height : 
/* 1464 */                     ty;
/*      */                 }break;
/*      */               }
/* 1467 */               child.setVisible(visible);
/* 1468 */               if (visible) {
/* 1469 */                 child.setBounds(bx, by, bw, bh);
/*      */               }
/*      */             }
/*      */             else
/*      */             {
/* 1474 */               child.setBounds(cx, cy, cw, ch);
/*      */             }
/*      */           }
/* 1477 */           if ((shouldChangeFocus) && 
/* 1478 */             (!PlasticTabbedPaneUI.this.requestFocusForVisibleComponent()))
/* 1479 */             PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this).requestFocus();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     protected void calculateTabRects(int tabPlacement, int tabCount)
/*      */     {
/* 1487 */       FontMetrics metrics = PlasticTabbedPaneUI.this.getFontMetrics();
/* 1488 */       Dimension size = PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this).getSize();
/* 1489 */       Insets insets = PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this).getInsets();
/* 1490 */       Insets tabAreaInsets1 = PlasticTabbedPaneUI.this.getTabAreaInsets(tabPlacement);
/* 1491 */       int fontHeight = metrics.getHeight();
/* 1492 */       int selectedIndex = PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this).getSelectedIndex();
/*      */ 
/* 1494 */       boolean verticalTabRuns = (tabPlacement == 2) || (tabPlacement == 4);
/* 1495 */       boolean leftToRight = PlasticUtils.isLeftToRight(PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this));
/* 1496 */       int x = tabAreaInsets1.left;
/* 1497 */       int y = tabAreaInsets1.top;
/* 1498 */       int totalWidth = 0;
/* 1499 */       int totalHeight = 0;
/*      */ 
/* 1504 */       switch (tabPlacement) {
/*      */       case 2:
/*      */       case 4:
/* 1507 */         PlasticTabbedPaneUI.access$9(PlasticTabbedPaneUI.this, PlasticTabbedPaneUI.this.calculateMaxTabWidth(tabPlacement));
/* 1508 */         break;
/*      */       case 1:
/*      */       case 3:
/*      */       default:
/* 1512 */         PlasticTabbedPaneUI.access$12(PlasticTabbedPaneUI.this, PlasticTabbedPaneUI.this.calculateMaxTabHeight(tabPlacement));
/*      */       }
/*      */ 
/* 1515 */       PlasticTabbedPaneUI.access$14(PlasticTabbedPaneUI.this, 0);
/* 1516 */       PlasticTabbedPaneUI.access$15(PlasticTabbedPaneUI.this, -1);
/*      */ 
/* 1518 */       if (tabCount == 0) {
/* 1519 */         return;
/*      */       }
/*      */ 
/* 1522 */       PlasticTabbedPaneUI.access$15(PlasticTabbedPaneUI.this, 0);
/* 1523 */       PlasticTabbedPaneUI.access$14(PlasticTabbedPaneUI.this, 1);
/*      */ 
/* 1527 */       for (int i = 0; i < tabCount; i++) {
/* 1528 */         Rectangle rect = PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[i];
/*      */ 
/* 1530 */         if (!verticalTabRuns)
/*      */         {
/* 1532 */           if (i > 0) {
/* 1533 */             rect.x = (PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[(i - 1)].x + PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[(i - 1)].width);
/*      */           } else {
/* 1535 */             PlasticTabbedPaneUI.access$16(PlasticTabbedPaneUI.this)[0] = 0;
/* 1536 */             PlasticTabbedPaneUI.access$9(PlasticTabbedPaneUI.this, 0);
/* 1537 */             totalHeight += PlasticTabbedPaneUI.access$13(PlasticTabbedPaneUI.this);
/* 1538 */             rect.x = x;
/*      */           }
/* 1540 */           rect.width = PlasticTabbedPaneUI.this.calculateTabWidth(tabPlacement, i, metrics);
/* 1541 */           totalWidth = rect.x + rect.width + PlasticTabbedPaneUI.this.renderer.getTabsOverlay();
/* 1542 */           PlasticTabbedPaneUI.access$9(PlasticTabbedPaneUI.this, Math.max(PlasticTabbedPaneUI.access$10(PlasticTabbedPaneUI.this), rect.width));
/*      */ 
/* 1544 */           rect.y = y;
/* 1545 */           rect.height = PlasticTabbedPaneUI.access$13(PlasticTabbedPaneUI.this);
/*      */         }
/*      */         else
/*      */         {
/* 1549 */           if (i > 0) {
/* 1550 */             rect.y = (PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[(i - 1)].y + PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[(i - 1)].height);
/*      */           } else {
/* 1552 */             PlasticTabbedPaneUI.access$16(PlasticTabbedPaneUI.this)[0] = 0;
/* 1553 */             PlasticTabbedPaneUI.access$12(PlasticTabbedPaneUI.this, 0);
/* 1554 */             totalWidth = PlasticTabbedPaneUI.access$10(PlasticTabbedPaneUI.this);
/* 1555 */             rect.y = y;
/*      */           }
/* 1557 */           rect.height = PlasticTabbedPaneUI.this.calculateTabHeight(tabPlacement, i, fontHeight);
/* 1558 */           totalHeight = rect.y + rect.height;
/* 1559 */           PlasticTabbedPaneUI.access$12(PlasticTabbedPaneUI.this, Math.max(PlasticTabbedPaneUI.access$13(PlasticTabbedPaneUI.this), rect.height));
/*      */ 
/* 1561 */           rect.x = x;
/* 1562 */           rect.width = PlasticTabbedPaneUI.access$10(PlasticTabbedPaneUI.this);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1568 */       padSelectedTab(tabPlacement, selectedIndex);
/*      */ 
/* 1572 */       if ((!leftToRight) && (!verticalTabRuns)) {
/* 1573 */         int rightMargin = size.width - (insets.right + tabAreaInsets1.right);
/* 1574 */         for (i = 0; i < tabCount; i++) {
/* 1575 */           PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[i].x = (rightMargin - PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[i].x - PlasticTabbedPaneUI.access$0(PlasticTabbedPaneUI.this)[i].width);
/*      */         }
/*      */       }
/* 1578 */       PlasticTabbedPaneUI.this.tabScroller.tabPanel.setPreferredSize(new Dimension(totalWidth, 
/* 1579 */         totalHeight));
/*      */     }
/*      */   }
/*      */ 
/*      */   private class ScrollableTabViewport extends JViewport
/*      */     implements UIResource
/*      */   {
/*      */     public ScrollableTabViewport()
/*      */     {
/* 1784 */       setName("TabbedPane.scrollableViewport");
/* 1785 */       setScrollMode(0);
/* 1786 */       setOpaque(PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this).isOpaque());
/* 1787 */       Color bgColor = UIManager.getColor("TabbedPane.tabAreaBackground");
/* 1788 */       if (bgColor == null) {
/* 1789 */         bgColor = PlasticTabbedPaneUI.access$7(PlasticTabbedPaneUI.this).getBackground();
/*      */       }
/* 1791 */       setBackground(bgColor);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static abstract class AbstractRenderer
/*      */   {
/* 1962 */     protected static final Insets EMPTY_INSETS = new Insets(0, 0, 0, 0);
/*      */ 
/* 1964 */     protected static final Insets NORTH_INSETS = new Insets(1, 0, 0, 0);
/*      */ 
/* 1966 */     protected static final Insets WEST_INSETS = new Insets(0, 1, 0, 0);
/*      */ 
/* 1968 */     protected static final Insets SOUTH_INSETS = new Insets(0, 0, 1, 0);
/*      */ 
/* 1970 */     protected static final Insets EAST_INSETS = new Insets(0, 0, 0, 1);
/*      */     protected final JTabbedPane tabPane;
/*      */     protected final int tabPlacement;
/*      */     protected Color shadowColor;
/*      */     protected Color darkShadow;
/*      */     protected Color selectColor;
/*      */     protected Color selectLight;
/*      */     protected Color selectHighlight;
/*      */     protected Color lightHighlight;
/*      */     protected Color focus;
/*      */ 
/*      */     AbstractRenderer(JTabbedPane tabPane)
/*      */     {
/* 1991 */       initColors();
/* 1992 */       this.tabPane = tabPane;
/* 1993 */       this.tabPlacement = tabPane.getTabPlacement();
/*      */     }
/*      */ 
/*      */     private static AbstractRenderer createRenderer(JTabbedPane tabPane) {
/* 1997 */       switch (tabPane.getTabPlacement()) {
/*      */       case 1:
/* 1999 */         return new PlasticTabbedPaneUI.TopRenderer(tabPane);
/*      */       case 3:
/* 2001 */         return new PlasticTabbedPaneUI.BottomRenderer(tabPane);
/*      */       case 2:
/* 2003 */         return new PlasticTabbedPaneUI.LeftRenderer(tabPane);
/*      */       case 4:
/* 2005 */         return new PlasticTabbedPaneUI.RightRenderer(tabPane);
/*      */       }
/* 2007 */       return new PlasticTabbedPaneUI.TopRenderer(tabPane);
/*      */     }
/*      */ 
/*      */     private static AbstractRenderer createEmbeddedRenderer(JTabbedPane tabPane)
/*      */     {
/* 2012 */       switch (tabPane.getTabPlacement()) {
/*      */       case 1:
/* 2014 */         return new PlasticTabbedPaneUI.TopEmbeddedRenderer(tabPane);
/*      */       case 3:
/* 2016 */         return new PlasticTabbedPaneUI.BottomEmbeddedRenderer(tabPane);
/*      */       case 2:
/* 2018 */         return new PlasticTabbedPaneUI.LeftEmbeddedRenderer(tabPane);
/*      */       case 4:
/* 2020 */         return new PlasticTabbedPaneUI.RightEmbeddedRenderer(tabPane);
/*      */       }
/* 2022 */       return new PlasticTabbedPaneUI.TopEmbeddedRenderer(tabPane);
/*      */     }
/*      */ 
/*      */     private void initColors()
/*      */     {
/* 2027 */       this.shadowColor = UIManager.getColor("TabbedPane.shadow");
/* 2028 */       this.darkShadow = UIManager.getColor("TabbedPane.darkShadow");
/* 2029 */       this.selectColor = UIManager.getColor("TabbedPane.selected");
/* 2030 */       this.focus = UIManager.getColor("TabbedPane.focus");
/* 2031 */       this.selectHighlight = UIManager.getColor("TabbedPane.selectHighlight");
/* 2032 */       this.lightHighlight = UIManager.getColor("TabbedPane.highlight");
/* 2033 */       this.selectLight = new Color(
/* 2034 */         (2 * this.selectColor.getRed() + 
/* 2034 */         this.selectHighlight.getRed()) / 3, 
/* 2035 */         (2 * this.selectColor.getGreen() + 
/* 2035 */         this.selectHighlight.getGreen()) / 3, 
/* 2036 */         (2 * this.selectColor.getBlue() + 
/* 2036 */         this.selectHighlight.getBlue()) / 3);
/*      */     }
/*      */ 
/*      */     protected boolean isFirstDisplayedTab(int tabIndex, int position, int paneBorder)
/*      */     {
/* 2041 */       return tabIndex == 0;
/*      */     }
/*      */ 
/*      */     protected Insets getTabAreaInsets(Insets defaultInsets)
/*      */     {
/* 2046 */       return defaultInsets;
/*      */     }
/*      */ 
/*      */     protected Insets getContentBorderInsets(Insets defaultInsets) {
/* 2050 */       return defaultInsets;
/*      */     }
/*      */ 
/*      */     protected int getTabLabelShiftX(int tabIndex, boolean isSelected)
/*      */     {
/* 2057 */       return 0;
/*      */     }
/*      */ 
/*      */     protected int getTabLabelShiftY(int tabIndex, boolean isSelected)
/*      */     {
/* 2064 */       return 0;
/*      */     }
/*      */ 
/*      */     protected int getTabRunOverlay(int tabRunOverlay)
/*      */     {
/* 2071 */       return tabRunOverlay;
/*      */     }
/*      */ 
/*      */     protected boolean shouldPadTabRun(int run, boolean aPriori)
/*      */     {
/* 2079 */       return aPriori;
/*      */     }
/*      */ 
/*      */     protected int getTabRunIndent(int run)
/*      */     {
/* 2087 */       return 0;
/*      */     }
/*      */ 
/*      */     protected abstract Insets getTabInsets(int paramInt, Insets paramInsets);
/*      */ 
/*      */     protected abstract void paintFocusIndicator(Graphics paramGraphics, Rectangle[] paramArrayOfRectangle, int paramInt, Rectangle paramRectangle1, Rectangle paramRectangle2, boolean paramBoolean);
/*      */ 
/*      */     protected abstract void paintTabBackground(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean);
/*      */ 
/*      */     protected abstract void paintTabBorder(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean);
/*      */ 
/*      */     protected Insets getSelectedTabPadInsets()
/*      */     {
/* 2120 */       return EMPTY_INSETS;
/*      */     }
/*      */ 
/*      */     protected void paintContentBorderTopEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/*      */     {
/* 2130 */       if (isContentBorderPainted) {
/* 2131 */         g.setColor(this.selectHighlight);
/* 2132 */         g.fillRect(x, y, w - 1, 1);
/*      */       }
/*      */     }
/*      */ 
/*      */     protected void paintContentBorderBottomEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/*      */     {
/* 2144 */       if (isContentBorderPainted) {
/* 2145 */         g.setColor(this.darkShadow);
/* 2146 */         g.fillRect(x, y + h - 1, w - 1, 1);
/*      */       }
/*      */     }
/*      */ 
/*      */     protected void paintContentBorderLeftEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/*      */     {
/* 2158 */       if (isContentBorderPainted) {
/* 2159 */         g.setColor(this.selectHighlight);
/* 2160 */         g.fillRect(x, y, 1, h - 1);
/*      */       }
/*      */     }
/*      */ 
/*      */     protected void paintContentBorderRightEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/*      */     {
/* 2172 */       if (isContentBorderPainted) {
/* 2173 */         g.setColor(this.darkShadow);
/* 2174 */         g.fillRect(x + w - 1, y, 1, h);
/*      */       }
/*      */     }
/*      */ 
/*      */     protected int getTabsOverlay()
/*      */     {
/* 2182 */       return 0;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class BottomEmbeddedRenderer extends PlasticTabbedPaneUI.AbstractRenderer
/*      */   {
/*      */     BottomEmbeddedRenderer(JTabbedPane tabPane)
/*      */     {
/* 2193 */       super();
/*      */     }
/*      */ 
/*      */     protected Insets getTabAreaInsets(Insets insets) {
/* 2197 */       return EMPTY_INSETS;
/*      */     }
/*      */ 
/*      */     protected Insets getContentBorderInsets(Insets defaultInsets) {
/* 2201 */       return SOUTH_INSETS;
/*      */     }
/*      */ 
/*      */     protected Insets getSelectedTabPadInsets() {
/* 2205 */       return EMPTY_INSETS;
/*      */     }
/*      */ 
/*      */     protected Insets getTabInsets(int tabIndex, Insets tabInsets) {
/* 2209 */       return new Insets(tabInsets.top, tabInsets.left, tabInsets.bottom, 
/* 2210 */         tabInsets.right);
/*      */     }
/*      */ 
/*      */     protected void paintFocusIndicator(Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/*      */     {
/*      */     }
/*      */ 
/*      */     protected void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */     {
/* 2225 */       g.setColor(this.selectColor);
/* 2226 */       g.fillRect(x, y, w + 1, h);
/*      */     }
/*      */ 
/*      */     protected void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */     {
/* 2232 */       int bottom = h;
/* 2233 */       int right = w + 1;
/*      */ 
/* 2235 */       g.translate(x, y);
/* 2236 */       if (isFirstDisplayedTab(tabIndex, x, this.tabPane.getBounds().x)) {
/* 2237 */         if (isSelected)
/*      */         {
/* 2239 */           g.setColor(this.shadowColor);
/* 2240 */           g.fillRect(right, 0, 1, bottom - 1);
/* 2241 */           g.fillRect(right - 1, bottom - 1, 1, 1);
/*      */ 
/* 2247 */           g.setColor(this.selectHighlight);
/* 2248 */           g.fillRect(0, 0, 1, bottom);
/* 2249 */           g.fillRect(right - 1, 0, 1, bottom - 1);
/* 2250 */           g.fillRect(1, bottom - 1, right - 2, 1);
/*      */         }
/*      */ 
/*      */       }
/* 2255 */       else if (isSelected)
/*      */       {
/* 2257 */         g.setColor(this.shadowColor);
/* 2258 */         g.fillRect(0, 0, 1, bottom - 1);
/* 2259 */         g.fillRect(1, bottom - 1, 1, 1);
/* 2260 */         g.fillRect(right, 0, 1, bottom - 1);
/* 2261 */         g.fillRect(right - 1, bottom - 1, 1, 1);
/*      */ 
/* 2264 */         g.setColor(this.selectHighlight);
/* 2265 */         g.fillRect(1, 0, 1, bottom - 1);
/* 2266 */         g.fillRect(right - 1, 0, 1, bottom - 1);
/* 2267 */         g.fillRect(2, bottom - 1, right - 3, 1);
/*      */       } else {
/* 2269 */         g.setColor(this.shadowColor);
/* 2270 */         g.fillRect(1, h / 2, 1, h - h / 2);
/*      */       }
/*      */ 
/* 2273 */       g.translate(-x, -y);
/*      */     }
/*      */ 
/*      */     protected void paintContentBorderBottomEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/*      */     {
/* 2280 */       g.setColor(this.shadowColor);
/* 2281 */       g.fillRect(x, y + h - 1, w, 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class BottomRenderer extends PlasticTabbedPaneUI.AbstractRenderer
/*      */   {
/*      */     BottomRenderer(JTabbedPane tabPane)
/*      */     {
/* 2293 */       super();
/*      */     }
/*      */ 
/*      */     protected Insets getTabAreaInsets(Insets defaultInsets) {
/* 2297 */       return new Insets(defaultInsets.top, defaultInsets.left + 5, 
/* 2298 */         defaultInsets.bottom, defaultInsets.right);
/*      */     }
/*      */ 
/*      */     protected int getTabLabelShiftY(int tabIndex, boolean isSelected) {
/* 2302 */       return isSelected ? 0 : -1;
/*      */     }
/*      */ 
/*      */     protected int getTabRunOverlay(int tabRunOverlay) {
/* 2306 */       return tabRunOverlay - 2;
/*      */     }
/*      */ 
/*      */     protected int getTabRunIndent(int run) {
/* 2310 */       return 6 * run;
/*      */     }
/*      */ 
/*      */     protected Insets getSelectedTabPadInsets() {
/* 2314 */       return SOUTH_INSETS;
/*      */     }
/*      */ 
/*      */     protected Insets getTabInsets(int tabIndex, Insets tabInsets) {
/* 2318 */       return new Insets(tabInsets.top, tabInsets.left - 2, tabInsets.bottom, 
/* 2319 */         tabInsets.right - 2);
/*      */     }
/*      */ 
/*      */     protected void paintFocusIndicator(Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/*      */     {
/* 2326 */       if ((!this.tabPane.hasFocus()) || (!isSelected))
/* 2327 */         return;
/* 2328 */       Rectangle tabRect = rects[tabIndex];
/* 2329 */       int top = tabRect.y;
/* 2330 */       int left = tabRect.x + 6;
/* 2331 */       int height = tabRect.height - 3;
/* 2332 */       int width = tabRect.width - 12;
/* 2333 */       g.setColor(this.focus);
/* 2334 */       g.drawRect(left, top, width, height);
/*      */     }
/*      */ 
/*      */     protected void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */     {
/* 2340 */       g.setColor(this.selectColor);
/* 2341 */       g.fillRect(x, y, w, h);
/*      */     }
/*      */ 
/*      */     protected void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */     {
/* 2347 */       int bottom = h - 1;
/* 2348 */       int right = w + 4;
/*      */ 
/* 2350 */       g.translate(x - 3, y);
/*      */ 
/* 2353 */       g.setColor(this.selectHighlight);
/*      */ 
/* 2356 */       g.fillRect(0, 0, 1, 2);
/* 2357 */       g.drawLine(0, 2, 4, bottom - 4);
/* 2358 */       g.fillRect(5, bottom - 3, 1, 2);
/* 2359 */       g.fillRect(6, bottom - 1, 1, 1);
/*      */ 
/* 2362 */       g.fillRect(7, bottom, 1, 1);
/* 2363 */       g.setColor(this.darkShadow);
/* 2364 */       g.fillRect(8, bottom, right - 13, 1);
/*      */ 
/* 2367 */       g.drawLine(right + 1, 0, right - 3, bottom - 4);
/* 2368 */       g.fillRect(right - 4, bottom - 3, 1, 2);
/* 2369 */       g.fillRect(right - 5, bottom - 1, 1, 1);
/*      */ 
/* 2371 */       g.translate(-x + 3, -y);
/*      */     }
/*      */ 
/*      */     protected void paintContentBorderBottomEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/*      */     {
/* 2377 */       int bottom = y + h - 1;
/* 2378 */       int right = x + w - 1;
/* 2379 */       g.translate(x, bottom);
/* 2380 */       if ((drawBroken) && (selRect.x >= x) && (selRect.x <= x + w))
/*      */       {
/* 2382 */         g.setColor(this.darkShadow);
/* 2383 */         g.fillRect(0, 0, selRect.x - x - 2, 1);
/* 2384 */         if (selRect.x + selRect.width < x + w - 2) {
/* 2385 */           g.setColor(this.darkShadow);
/* 2386 */           g.fillRect(selRect.x + selRect.width + 2 - x, 0, right - 
/* 2387 */             selRect.x - selRect.width - 2, 1);
/*      */         }
/*      */       } else {
/* 2390 */         g.setColor(this.darkShadow);
/* 2391 */         g.fillRect(0, 0, w - 1, 1);
/*      */       }
/* 2393 */       g.translate(-x, -bottom);
/*      */     }
/*      */ 
/*      */     protected int getTabsOverlay() {
/* 2397 */       return 4;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class LeftEmbeddedRenderer extends PlasticTabbedPaneUI.AbstractRenderer
/*      */   {
/*      */     LeftEmbeddedRenderer(JTabbedPane tabPane)
/*      */     {
/* 2408 */       super();
/*      */     }
/*      */ 
/*      */     protected Insets getTabAreaInsets(Insets insets) {
/* 2412 */       return EMPTY_INSETS;
/*      */     }
/*      */ 
/*      */     protected Insets getContentBorderInsets(Insets defaultInsets) {
/* 2416 */       return WEST_INSETS;
/*      */     }
/*      */ 
/*      */     protected int getTabRunOverlay(int tabRunOverlay) {
/* 2420 */       return 0;
/*      */     }
/*      */ 
/*      */     protected boolean shouldPadTabRun(int run, boolean aPriori) {
/* 2424 */       return false;
/*      */     }
/*      */ 
/*      */     protected Insets getTabInsets(int tabIndex, Insets tabInsets) {
/* 2428 */       return new Insets(tabInsets.top, tabInsets.left, tabInsets.bottom, 
/* 2429 */         tabInsets.right);
/*      */     }
/*      */ 
/*      */     protected Insets getSelectedTabPadInsets() {
/* 2433 */       return EMPTY_INSETS;
/*      */     }
/*      */ 
/*      */     protected void paintFocusIndicator(Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/*      */     {
/*      */     }
/*      */ 
/*      */     protected void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */     {
/* 2447 */       g.setColor(this.selectColor);
/* 2448 */       g.fillRect(x, y, w, h);
/*      */     }
/*      */ 
/*      */     protected void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */     {
/* 2454 */       int bottom = h;
/* 2455 */       int right = w;
/*      */ 
/* 2457 */       g.translate(x, y);
/*      */ 
/* 2459 */       if (isFirstDisplayedTab(tabIndex, y, this.tabPane.getBounds().y)) {
/* 2460 */         if (isSelected)
/*      */         {
/* 2462 */           g.setColor(this.selectHighlight);
/* 2463 */           g.fillRect(0, 0, right, 1);
/* 2464 */           g.fillRect(0, 0, 1, bottom - 1);
/* 2465 */           g.fillRect(1, bottom - 1, right - 1, 1);
/* 2466 */           g.setColor(this.shadowColor);
/* 2467 */           g.fillRect(0, bottom - 1, 1, 1);
/* 2468 */           g.fillRect(1, bottom, right - 1, 1);
/*      */         }
/*      */ 
/*      */       }
/* 2475 */       else if (isSelected)
/*      */       {
/* 2477 */         g.setColor(this.selectHighlight);
/* 2478 */         g.fillRect(1, 1, right - 1, 1);
/* 2479 */         g.fillRect(0, 2, 1, bottom - 2);
/* 2480 */         g.fillRect(1, bottom - 1, right - 1, 1);
/* 2481 */         g.setColor(this.shadowColor);
/* 2482 */         g.fillRect(1, 0, right - 1, 1);
/* 2483 */         g.fillRect(0, 1, 1, 1);
/* 2484 */         g.fillRect(0, bottom - 1, 1, 1);
/* 2485 */         g.fillRect(1, bottom, right - 1, 1);
/*      */       }
/*      */       else
/*      */       {
/* 2489 */         g.setColor(this.shadowColor);
/* 2490 */         g.fillRect(0, 0, right / 3, 1);
/*      */       }
/*      */ 
/* 2494 */       g.translate(-x, -y);
/*      */     }
/*      */ 
/*      */     protected void paintContentBorderLeftEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/*      */     {
/* 2500 */       g.setColor(this.shadowColor);
/* 2501 */       g.fillRect(x, y, 1, h);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class LeftRenderer extends PlasticTabbedPaneUI.AbstractRenderer
/*      */   {
/*      */     LeftRenderer(JTabbedPane tabPane)
/*      */     {
/* 2511 */       super();
/*      */     }
/*      */ 
/*      */     protected Insets getTabAreaInsets(Insets defaultInsets) {
/* 2515 */       return new Insets(defaultInsets.top + 4, defaultInsets.left, 
/* 2516 */         defaultInsets.bottom, defaultInsets.right);
/*      */     }
/*      */ 
/*      */     protected int getTabLabelShiftX(int tabIndex, boolean isSelected) {
/* 2520 */       return 1;
/*      */     }
/*      */ 
/*      */     protected int getTabRunOverlay(int tabRunOverlay) {
/* 2524 */       return 1;
/*      */     }
/*      */ 
/*      */     protected boolean shouldPadTabRun(int run, boolean aPriori) {
/* 2528 */       return false;
/*      */     }
/*      */ 
/*      */     protected Insets getTabInsets(int tabIndex, Insets tabInsets) {
/* 2532 */       return new Insets(tabInsets.top, tabInsets.left - 5, 
/* 2533 */         tabInsets.bottom + 1, tabInsets.right - 5);
/*      */     }
/*      */ 
/*      */     protected Insets getSelectedTabPadInsets() {
/* 2537 */       return WEST_INSETS;
/*      */     }
/*      */ 
/*      */     protected void paintFocusIndicator(Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/*      */     {
/* 2544 */       if ((!this.tabPane.hasFocus()) || (!isSelected))
/* 2545 */         return;
/* 2546 */       Rectangle tabRect = rects[tabIndex];
/* 2547 */       int top = tabRect.y + 2;
/* 2548 */       int left = tabRect.x + 3;
/* 2549 */       int height = tabRect.height - 5;
/* 2550 */       int width = tabRect.width - 6;
/* 2551 */       g.setColor(this.focus);
/* 2552 */       g.drawRect(left, top, width, height);
/*      */     }
/*      */ 
/*      */     protected void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */     {
/* 2557 */       if (!isSelected) {
/* 2558 */         g.setColor(this.selectLight);
/* 2559 */         g.fillRect(x + 1, y + 1, w - 1, h - 2);
/*      */       } else {
/* 2561 */         g.setColor(this.selectColor);
/* 2562 */         g.fillRect(x + 1, y + 1, w - 3, h - 2);
/*      */       }
/*      */     }
/*      */ 
/*      */     protected void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */     {
/* 2569 */       int bottom = h - 1;
/* 2570 */       int left = 0;
/* 2571 */       g.translate(x, y);
/*      */ 
/* 2574 */       g.setColor(this.selectHighlight);
/*      */ 
/* 2576 */       g.fillRect(left + 2, 0, w - 2 - left, 1);
/*      */ 
/* 2579 */       g.fillRect(left + 1, 1, 1, 1);
/* 2580 */       g.fillRect(left, 2, 1, bottom - 3);
/* 2581 */       g.setColor(this.darkShadow);
/* 2582 */       g.fillRect(left + 1, bottom - 1, 1, 1);
/*      */ 
/* 2585 */       g.fillRect(left + 2, bottom, w - 2 - left, 1);
/*      */ 
/* 2587 */       g.translate(-x, -y);
/*      */     }
/*      */ 
/*      */     protected void paintContentBorderLeftEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/*      */     {
/* 2593 */       g.setColor(this.selectHighlight);
/* 2594 */       if ((drawBroken) && (selRect.y >= y) && (selRect.y <= y + h))
/*      */       {
/* 2596 */         g.fillRect(x, y, 1, selRect.y + 1 - y);
/* 2597 */         if (selRect.y + selRect.height < y + h - 2)
/* 2598 */           g.fillRect(x, selRect.y + selRect.height - 1, 1, y + h - 
/* 2599 */             selRect.y - selRect.height);
/*      */       }
/*      */       else {
/* 2602 */         g.fillRect(x, y, 1, h - 1);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class RightEmbeddedRenderer extends PlasticTabbedPaneUI.AbstractRenderer
/*      */   {
/*      */     RightEmbeddedRenderer(JTabbedPane tabPane)
/*      */     {
/* 2614 */       super();
/*      */     }
/*      */ 
/*      */     protected Insets getTabAreaInsets(Insets insets) {
/* 2618 */       return EMPTY_INSETS;
/*      */     }
/*      */ 
/*      */     protected Insets getContentBorderInsets(Insets defaultInsets) {
/* 2622 */       return EAST_INSETS;
/*      */     }
/*      */ 
/*      */     protected int getTabRunIndent(int run) {
/* 2626 */       return 4 * run;
/*      */     }
/*      */ 
/*      */     protected int getTabRunOverlay(int tabRunOverlay) {
/* 2630 */       return 0;
/*      */     }
/*      */ 
/*      */     protected boolean shouldPadTabRun(int run, boolean aPriori) {
/* 2634 */       return false;
/*      */     }
/*      */ 
/*      */     protected Insets getTabInsets(int tabIndex, Insets tabInsets) {
/* 2638 */       return new Insets(tabInsets.top, tabInsets.left, tabInsets.bottom, 
/* 2639 */         tabInsets.right);
/*      */     }
/*      */ 
/*      */     protected Insets getSelectedTabPadInsets() {
/* 2643 */       return EMPTY_INSETS;
/*      */     }
/*      */ 
/*      */     protected void paintFocusIndicator(Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/*      */     {
/*      */     }
/*      */ 
/*      */     protected void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */     {
/* 2658 */       g.setColor(this.selectColor);
/* 2659 */       g.fillRect(x, y, w, h);
/*      */     }
/*      */ 
/*      */     protected void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */     {
/* 2665 */       int bottom = h;
/* 2666 */       int right = w - 1;
/*      */ 
/* 2668 */       g.translate(x + 1, y);
/*      */ 
/* 2670 */       if (isFirstDisplayedTab(tabIndex, y, this.tabPane.getBounds().y)) {
/* 2671 */         if (isSelected)
/*      */         {
/* 2673 */           g.setColor(this.shadowColor);
/*      */ 
/* 2677 */           g.fillRect(right - 1, bottom - 1, 1, 1);
/* 2678 */           g.fillRect(0, bottom, right - 1, 1);
/* 2679 */           g.setColor(this.selectHighlight);
/* 2680 */           g.fillRect(0, 0, right - 1, 1);
/* 2681 */           g.fillRect(right - 1, 0, 1, bottom - 1);
/* 2682 */           g.fillRect(0, bottom - 1, right - 1, 1);
/*      */         }
/*      */       }
/* 2685 */       else if (isSelected)
/*      */       {
/* 2687 */         g.setColor(this.shadowColor);
/* 2688 */         g.fillRect(0, -1, right - 1, 1);
/* 2689 */         g.fillRect(right - 1, 0, 1, 1);
/*      */ 
/* 2692 */         g.fillRect(right - 1, bottom - 1, 1, 1);
/* 2693 */         g.fillRect(0, bottom, right - 1, 1);
/* 2694 */         g.setColor(this.selectHighlight);
/* 2695 */         g.fillRect(0, 0, right - 1, 1);
/* 2696 */         g.fillRect(right - 1, 1, 1, bottom - 2);
/* 2697 */         g.fillRect(0, bottom - 1, right - 1, 1);
/*      */       }
/*      */       else {
/* 2700 */         g.setColor(this.shadowColor);
/* 2701 */         g.fillRect(2 * right / 3, 0, right / 3, 1);
/*      */       }
/*      */ 
/* 2704 */       g.translate(-x - 1, -y);
/*      */     }
/*      */ 
/*      */     protected void paintContentBorderRightEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/*      */     {
/* 2710 */       g.setColor(this.shadowColor);
/* 2711 */       g.fillRect(x + w - 1, y, 1, h);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class RightRenderer extends PlasticTabbedPaneUI.AbstractRenderer
/*      */   {
/*      */     RightRenderer(JTabbedPane tabPane)
/*      */     {
/* 2722 */       super();
/*      */     }
/*      */ 
/*      */     protected int getTabLabelShiftX(int tabIndex, boolean isSelected) {
/* 2726 */       return 1;
/*      */     }
/*      */ 
/*      */     protected int getTabRunOverlay(int tabRunOverlay) {
/* 2730 */       return 1;
/*      */     }
/*      */ 
/*      */     protected boolean shouldPadTabRun(int run, boolean aPriori) {
/* 2734 */       return false;
/*      */     }
/*      */ 
/*      */     protected Insets getTabInsets(int tabIndex, Insets tabInsets) {
/* 2738 */       return new Insets(tabInsets.top, tabInsets.left - 5, 
/* 2739 */         tabInsets.bottom + 1, tabInsets.right - 5);
/*      */     }
/*      */ 
/*      */     protected Insets getSelectedTabPadInsets() {
/* 2743 */       return EAST_INSETS;
/*      */     }
/*      */ 
/*      */     protected void paintFocusIndicator(Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/*      */     {
/* 2750 */       if ((!this.tabPane.hasFocus()) || (!isSelected))
/* 2751 */         return;
/* 2752 */       Rectangle tabRect = rects[tabIndex];
/* 2753 */       int top = tabRect.y + 2;
/* 2754 */       int left = tabRect.x + 3;
/* 2755 */       int height = tabRect.height - 5;
/* 2756 */       int width = tabRect.width - 6;
/* 2757 */       g.setColor(this.focus);
/* 2758 */       g.drawRect(left, top, width, height);
/*      */     }
/*      */ 
/*      */     protected void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */     {
/* 2763 */       if (!isSelected) {
/* 2764 */         g.setColor(this.selectLight);
/* 2765 */         g.fillRect(x, y, w, h);
/*      */       } else {
/* 2767 */         g.setColor(this.selectColor);
/* 2768 */         g.fillRect(x + 2, y, w - 2, h);
/*      */       }
/*      */     }
/*      */ 
/*      */     protected void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */     {
/* 2775 */       int bottom = h - 1;
/* 2776 */       int right = w;
/*      */ 
/* 2778 */       g.translate(x, y);
/*      */ 
/* 2782 */       g.setColor(this.selectHighlight);
/* 2783 */       g.fillRect(0, 0, right - 1, 1);
/*      */ 
/* 2785 */       g.setColor(this.darkShadow);
/* 2786 */       g.fillRect(right - 1, 1, 1, 1);
/* 2787 */       g.fillRect(right, 2, 1, bottom - 3);
/*      */ 
/* 2789 */       g.fillRect(right - 1, bottom - 1, 1, 1);
/* 2790 */       g.fillRect(0, bottom, right - 1, 1);
/*      */ 
/* 2792 */       g.translate(-x, -y);
/*      */     }
/*      */ 
/*      */     protected void paintContentBorderRightEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/*      */     {
/* 2798 */       g.setColor(this.darkShadow);
/* 2799 */       if ((drawBroken) && (selRect.y >= y) && (selRect.y <= y + h))
/*      */       {
/* 2801 */         g.fillRect(x + w - 1, y, 1, selRect.y - y);
/* 2802 */         if (selRect.y + selRect.height < y + h - 2)
/* 2803 */           g.fillRect(x + w - 1, selRect.y + selRect.height, 1, y + h - 
/* 2804 */             selRect.y - selRect.height);
/*      */       }
/*      */       else {
/* 2807 */         g.fillRect(x + w - 1, y, 1, h - 1);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class TopEmbeddedRenderer extends PlasticTabbedPaneUI.AbstractRenderer
/*      */   {
/*      */     TopEmbeddedRenderer(JTabbedPane tabPane)
/*      */     {
/* 2818 */       super();
/*      */     }
/*      */ 
/*      */     protected Insets getTabAreaInsets(Insets insets) {
/* 2822 */       return EMPTY_INSETS;
/*      */     }
/*      */ 
/*      */     protected Insets getContentBorderInsets(Insets defaultInsets) {
/* 2826 */       return NORTH_INSETS;
/*      */     }
/*      */ 
/*      */     protected Insets getTabInsets(int tabIndex, Insets tabInsets) {
/* 2830 */       return new Insets(tabInsets.top, tabInsets.left + 1, tabInsets.bottom, 
/* 2831 */         tabInsets.right);
/*      */     }
/*      */ 
/*      */     protected Insets getSelectedTabPadInsets() {
/* 2835 */       return EMPTY_INSETS;
/*      */     }
/*      */ 
/*      */     protected void paintFocusIndicator(Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/*      */     {
/*      */     }
/*      */ 
/*      */     protected void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */     {
/* 2850 */       g.setColor(this.selectColor);
/* 2851 */       g.fillRect(x, y, w, h);
/*      */     }
/*      */ 
/*      */     protected void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */     {
/* 2857 */       g.translate(x, y);
/*      */ 
/* 2859 */       int right = w;
/* 2860 */       int bottom = h;
/*      */ 
/* 2862 */       if (isFirstDisplayedTab(tabIndex, x, this.tabPane.getBounds().x)) {
/* 2863 */         if (isSelected) {
/* 2864 */           g.setColor(this.selectHighlight);
/*      */ 
/* 2866 */           g.fillRect(0, 0, 1, bottom);
/*      */ 
/* 2868 */           g.fillRect(0, 0, right - 1, 1);
/*      */ 
/* 2870 */           g.fillRect(right - 1, 0, 1, bottom);
/* 2871 */           g.setColor(this.shadowColor);
/*      */ 
/* 2873 */           g.fillRect(right - 1, 0, 1, 1);
/*      */ 
/* 2875 */           g.fillRect(right, 1, 1, bottom);
/*      */         }
/*      */       }
/* 2878 */       else if (isSelected) {
/* 2879 */         g.setColor(this.selectHighlight);
/*      */ 
/* 2881 */         g.fillRect(1, 1, 1, bottom - 1);
/*      */ 
/* 2883 */         g.fillRect(2, 0, right - 3, 1);
/*      */ 
/* 2885 */         g.fillRect(right - 1, 1, 1, bottom - 1);
/* 2886 */         g.setColor(this.shadowColor);
/*      */ 
/* 2888 */         g.fillRect(0, 1, 1, bottom - 1);
/*      */ 
/* 2890 */         g.fillRect(1, 0, 1, 1);
/*      */ 
/* 2892 */         g.fillRect(right - 1, 0, 1, 1);
/*      */ 
/* 2894 */         g.fillRect(right, 1, 1, bottom);
/*      */       } else {
/* 2896 */         g.setColor(this.shadowColor);
/* 2897 */         g.fillRect(0, 0, 1, bottom + 2 - bottom / 2);
/*      */       }
/*      */ 
/* 2900 */       g.translate(-x, -y);
/*      */     }
/*      */ 
/*      */     protected void paintContentBorderTopEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/*      */     {
/* 2906 */       g.setColor(this.shadowColor);
/* 2907 */       g.fillRect(x, y, w, 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class TopRenderer extends PlasticTabbedPaneUI.AbstractRenderer
/*      */   {
/*      */     TopRenderer(JTabbedPane tabPane)
/*      */     {
/* 2918 */       super();
/*      */     }
/*      */ 
/*      */     protected Insets getTabAreaInsets(Insets defaultInsets) {
/* 2922 */       return new Insets(defaultInsets.top, defaultInsets.left + 4, 
/* 2923 */         defaultInsets.bottom, defaultInsets.right);
/*      */     }
/*      */ 
/*      */     protected int getTabLabelShiftY(int tabIndex, boolean isSelected) {
/* 2927 */       return isSelected ? -1 : 0;
/*      */     }
/*      */ 
/*      */     protected int getTabRunOverlay(int tabRunOverlay) {
/* 2931 */       return tabRunOverlay - 2;
/*      */     }
/*      */ 
/*      */     protected int getTabRunIndent(int run) {
/* 2935 */       return 6 * run;
/*      */     }
/*      */ 
/*      */     protected Insets getSelectedTabPadInsets() {
/* 2939 */       return NORTH_INSETS;
/*      */     }
/*      */ 
/*      */     protected Insets getTabInsets(int tabIndex, Insets tabInsets) {
/* 2943 */       return new Insets(tabInsets.top - 1, tabInsets.left - 4, 
/* 2944 */         tabInsets.bottom, tabInsets.right - 4);
/*      */     }
/*      */ 
/*      */     protected void paintFocusIndicator(Graphics g, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected)
/*      */     {
/* 2951 */       if ((!this.tabPane.hasFocus()) || (!isSelected))
/* 2952 */         return;
/* 2953 */       Rectangle tabRect = rects[tabIndex];
/* 2954 */       int top = tabRect.y + 1;
/* 2955 */       int left = tabRect.x + 4;
/* 2956 */       int height = tabRect.height - 3;
/* 2957 */       int width = tabRect.width - 9;
/* 2958 */       g.setColor(this.focus);
/* 2959 */       g.drawRect(left, top, width, height);
/*      */     }
/*      */ 
/*      */     protected void paintTabBackground(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */     {
/* 2965 */       int sel = isSelected ? 0 : 1;
/* 2966 */       g.setColor(this.selectColor);
/* 2967 */       if (!isSelected) g.setColor(this.shadowColor);
/* 2968 */       g.fillRect(x, y + sel, w, h);
/*      */     }
/*      */ 
/*      */     protected void paintTabBorder(Graphics g, int tabIndex, int x, int y, int w, int h, boolean isSelected)
/*      */     {
/* 2975 */       g.translate(x, y);
/*      */ 
/* 2977 */       g.setColor(isSelected ? this.selectHighlight : this.shadowColor);
/* 2978 */       g.fillRect(0, 0, 1, h);
/* 2979 */       g.fillRect(0, 0, w, 1);
/* 2980 */       g.setColor(this.darkShadow);
/* 2981 */       g.fillRect(w - 1, 0, 1, h);
/*      */ 
/* 2983 */       g.translate(-x, -y);
/*      */     }
/*      */ 
/*      */     protected void paintContentBorderTopEdge(Graphics g, int x, int y, int w, int h, boolean drawBroken, Rectangle selRect, boolean isContentBorderPainted)
/*      */     {
/* 3014 */       int right = x + w - 1;
/* 3015 */       int top = y;
/* 3016 */       g.setColor(this.selectHighlight);
/*      */ 
/* 3018 */       if ((drawBroken) && (selRect.x >= x) && (selRect.x <= x + w))
/*      */       {
/* 3020 */         g.fillRect(x, top, selRect.x - 2 - x, 1);
/* 3021 */         if (selRect.x + selRect.width < x + w - 2)
/* 3022 */           g.fillRect(selRect.x + selRect.width + 2, top, right - 2 - 
/* 3023 */             selRect.x - selRect.width, 1);
/*      */         else
/* 3025 */           g.fillRect(x + w - 2, top, 1, 1);
/*      */       }
/*      */       else {
/* 3028 */         g.fillRect(x, top, w - 1, 1);
/*      */       }
/*      */     }
/*      */ 
/*      */     protected int getTabsOverlay() {
/* 3033 */       return 6;
/*      */     }
/*      */   }
/*      */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticTabbedPaneUI
 * JD-Core Version:    0.6.2
 */