/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.ComponentOrientation;
/*     */ import java.awt.GradientPaint;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.UIManager;
/*     */ 
/*     */ public final class PlasticUtils
/*     */ {
/* 218 */   private static float FRACTION_3D = 0.5F;
/*     */ 
/*     */   static void drawDark3DBorder(Graphics g, int x, int y, int w, int h)
/*     */   {
/*  48 */     drawFlush3DBorder(g, x, y, w, h);
/*  49 */     g.setColor(PlasticLookAndFeel.getControl());
/*  50 */     g.drawLine(x + 1, y + 1, 1, h - 3);
/*  51 */     g.drawLine(y + 1, y + 1, w - 3, 1);
/*     */   }
/*     */ 
/*     */   static void drawDisabledBorder(Graphics g, int x, int y, int w, int h)
/*     */   {
/*  56 */     g.setColor(PlasticLookAndFeel.getControlShadow());
/*  57 */     drawRect(g, x, y, w - 1, h - 1);
/*     */   }
/*     */ 
/*     */   static void drawFlush3DBorder(Graphics g, int x, int y, int w, int h)
/*     */   {
/*  65 */     g.translate(x, y);
/*  66 */     g.setColor(PlasticLookAndFeel.getControlHighlight());
/*  67 */     drawRect(g, 1, 1, w - 2, h - 2);
/*  68 */     g.drawLine(0, h - 1, 0, h - 1);
/*  69 */     g.drawLine(w - 1, 0, w - 1, 0);
/*  70 */     g.setColor(PlasticLookAndFeel.getControlDarkShadow());
/*  71 */     drawRect(g, 0, 0, w - 2, h - 2);
/*  72 */     g.translate(-x, -y);
/*     */   }
/*     */ 
/*     */   static void drawPressed3DBorder(Graphics g, int x, int y, int w, int h)
/*     */   {
/*  80 */     g.translate(x, y);
/*  81 */     drawFlush3DBorder(g, 0, 0, w, h);
/*  82 */     g.setColor(PlasticLookAndFeel.getControlShadow());
/*  83 */     g.drawLine(1, 1, 1, h - 3);
/*  84 */     g.drawLine(1, 1, w - 3, 1);
/*  85 */     g.translate(-x, -y);
/*     */   }
/*     */ 
/*     */   static void drawButtonBorder(Graphics g, int x, int y, int w, int h, boolean active)
/*     */   {
/*  93 */     if (active)
/*  94 */       drawActiveButtonBorder(g, x, y, w, h);
/*     */     else
/*  96 */       drawFlush3DBorder(g, x, y, w, h);
/*     */   }
/*     */ 
/*     */   static void drawActiveButtonBorder(Graphics g, int x, int y, int w, int h)
/*     */   {
/* 104 */     drawFlush3DBorder(g, x, y, w, h);
/* 105 */     g.setColor(PlasticLookAndFeel.getPrimaryControl());
/* 106 */     g.drawLine(x + 1, y + 1, x + 1, h - 3);
/* 107 */     g.drawLine(x + 1, y + 1, w - 3, x + 1);
/* 108 */     g.setColor(PlasticLookAndFeel.getPrimaryControlDarkShadow());
/* 109 */     g.drawLine(x + 2, h - 2, w - 2, h - 2);
/* 110 */     g.drawLine(w - 2, y + 2, w - 2, h - 2);
/*     */   }
/*     */ 
/*     */   static void drawDefaultButtonBorder(Graphics g, int x, int y, int w, int h, boolean active)
/*     */   {
/* 117 */     drawButtonBorder(g, x + 1, y + 1, w - 1, h - 1, active);
/* 118 */     g.translate(x, y);
/* 119 */     g.setColor(PlasticLookAndFeel.getControlDarkShadow());
/* 120 */     drawRect(g, 0, 0, w - 3, h - 3);
/* 121 */     g.drawLine(w - 2, 0, w - 2, 0);
/* 122 */     g.drawLine(0, h - 2, 0, h - 2);
/* 123 */     g.setColor(PlasticLookAndFeel.getControl());
/* 124 */     g.drawLine(w - 1, 0, w - 1, 0);
/* 125 */     g.drawLine(0, h - 1, 0, h - 1);
/* 126 */     g.translate(-x, -y);
/*     */   }
/*     */ 
/*     */   static void drawDefaultButtonPressedBorder(Graphics g, int x, int y, int w, int h) {
/* 130 */     drawPressed3DBorder(g, x + 1, y + 1, w - 1, h - 1);
/* 131 */     g.translate(x, y);
/* 132 */     g.setColor(PlasticLookAndFeel.getControlDarkShadow());
/* 133 */     drawRect(g, 0, 0, w - 3, h - 3);
/* 134 */     g.drawLine(w - 2, 0, w - 2, 0);
/* 135 */     g.drawLine(0, h - 2, 0, h - 2);
/* 136 */     g.setColor(PlasticLookAndFeel.getControl());
/* 137 */     g.drawLine(w - 1, 0, w - 1, 0);
/* 138 */     g.drawLine(0, h - 1, 0, h - 1);
/* 139 */     g.translate(-x, -y);
/*     */   }
/*     */ 
/*     */   static void drawThinFlush3DBorder(Graphics g, int x, int y, int w, int h) {
/* 143 */     g.translate(x, y);
/* 144 */     g.setColor(PlasticLookAndFeel.getControlHighlight());
/* 145 */     g.drawLine(0, 0, w - 2, 0);
/* 146 */     g.drawLine(0, 0, 0, h - 2);
/* 147 */     g.setColor(PlasticLookAndFeel.getControlDarkShadow());
/* 148 */     g.drawLine(w - 1, 0, w - 1, h - 1);
/* 149 */     g.drawLine(0, h - 1, w - 1, h - 1);
/* 150 */     g.translate(-x, -y);
/*     */   }
/*     */ 
/*     */   static void drawThinPressed3DBorder(Graphics g, int x, int y, int w, int h)
/*     */   {
/* 155 */     g.translate(x, y);
/* 156 */     g.setColor(PlasticLookAndFeel.getControlDarkShadow());
/* 157 */     g.drawLine(0, 0, w - 2, 0);
/* 158 */     g.drawLine(0, 0, 0, h - 2);
/* 159 */     g.setColor(PlasticLookAndFeel.getControlHighlight());
/* 160 */     g.drawLine(w - 1, 0, w - 1, h - 1);
/* 161 */     g.drawLine(0, h - 1, w - 1, h - 1);
/* 162 */     g.translate(-x, -y);
/*     */   }
/*     */ 
/*     */   static boolean isLeftToRight(Component c)
/*     */   {
/* 170 */     return c.getComponentOrientation().isLeftToRight();
/*     */   }
/*     */ 
/*     */   static boolean is3D(String keyPrefix)
/*     */   {
/* 185 */     Object value = UIManager.get(keyPrefix + "is3DEnabled");
/* 186 */     return Boolean.TRUE.equals(value);
/*     */   }
/*     */ 
/*     */   static boolean force3D(JComponent c)
/*     */   {
/* 198 */     Object value = c.getClientProperty("Plastic.is3D");
/* 199 */     return Boolean.TRUE.equals(value);
/*     */   }
/*     */ 
/*     */   static boolean forceFlat(JComponent c)
/*     */   {
/* 211 */     Object value = c.getClientProperty("Plastic.is3D");
/* 212 */     return Boolean.FALSE.equals(value);
/*     */   }
/*     */ 
/*     */   private static void add3DEffekt(Graphics g, Rectangle r, boolean isHorizontal, Color startC0, Color stopC0, Color startC1, Color stopC1)
/*     */   {
/* 224 */     Graphics2D g2 = (Graphics2D)g;
/*     */     int yd1;
/*     */     int width;
/*     */     int height;
/*     */     int xb0;
/*     */     int yb0;
/*     */     int xb1;
/*     */     int yb1;
/*     */     int xd0;
/*     */     int yd0;
/*     */     int xd1;
/*     */     int yd1;
/* 226 */     if (isHorizontal) {
/* 227 */       int width = r.width;
/* 228 */       int height = (int)(r.height * FRACTION_3D);
/* 229 */       int xb0 = r.x;
/* 230 */       int yb0 = r.y;
/* 231 */       int xb1 = xb0;
/* 232 */       int yb1 = yb0 + height;
/* 233 */       int xd0 = xb1;
/* 234 */       int yd0 = yb1;
/* 235 */       int xd1 = xd0;
/* 236 */       yd1 = r.y + r.height;
/*     */     } else {
/* 238 */       width = (int)(r.width * FRACTION_3D);
/* 239 */       height = r.height;
/* 240 */       xb0 = r.x;
/* 241 */       yb0 = r.y;
/* 242 */       xb1 = xb0 + width;
/* 243 */       yb1 = yb0;
/* 244 */       xd0 = xb1;
/* 245 */       yd0 = yb0;
/* 246 */       xd1 = r.x + r.width;
/* 247 */       yd1 = yd0;
/*     */     }
/* 249 */     g2.setPaint(new GradientPaint(xb0, yb0, stopC0, xb1, yb1, startC0));
/* 250 */     g2.fillRect(r.x, r.y, width, height);
/* 251 */     g2.setPaint(new GradientPaint(xd0, yd0, startC1, xd1, yd1, stopC1));
/* 252 */     g2.fillRect(xd0, yd0, width, height);
/*     */   }
/*     */ 
/*     */   static void add3DEffekt(Graphics g, Rectangle r)
/*     */   {
/* 257 */     Color brightenStop = UIManager.getColor("Plastic.brightenStop");
/* 258 */     if (brightenStop == null) {
/* 259 */       brightenStop = PlasticTheme.BRIGHTEN_STOP;
/*     */     }
/*     */ 
/* 262 */     Graphics2D g2 = (Graphics2D)g;
/* 263 */     int border = 10;
/* 264 */     g2.setPaint(new GradientPaint(r.x, r.y, brightenStop, r.x + border, r.y, PlasticTheme.BRIGHTEN_START));
/* 265 */     g2.fillRect(r.x, r.y, border, r.height);
/* 266 */     int x = r.x + r.width - border;
/* 267 */     int y = r.y;
/* 268 */     g2.setPaint(new GradientPaint(x, y, PlasticTheme.DARKEN_START, x + border, y, PlasticTheme.LT_DARKEN_STOP));
/* 269 */     g2.fillRect(x, y, border, r.height);
/*     */ 
/* 271 */     add3DEffekt(g, r, true, PlasticTheme.BRIGHTEN_START, brightenStop, PlasticTheme.DARKEN_START, PlasticTheme.LT_DARKEN_STOP);
/*     */   }
/*     */ 
/*     */   static void addLight3DEffekt(Graphics g, Rectangle r, boolean isHorizontal)
/*     */   {
/* 276 */     Color ltBrightenStop = UIManager.getColor("Plastic.ltBrightenStop");
/* 277 */     if (ltBrightenStop == null) {
/* 278 */       ltBrightenStop = PlasticTheme.LT_BRIGHTEN_STOP;
/*     */     }
/* 280 */     add3DEffekt(g, r, isHorizontal, PlasticTheme.BRIGHTEN_START, ltBrightenStop, PlasticTheme.DARKEN_START, PlasticTheme.LT_DARKEN_STOP);
/*     */   }
/*     */ 
/*     */   public static void addLight3DEffekt(Graphics g, Rectangle r)
/*     */   {
/* 289 */     Color ltBrightenStop = UIManager.getColor("Plastic.ltBrightenStop");
/* 290 */     if (ltBrightenStop == null) {
/* 291 */       ltBrightenStop = PlasticTheme.LT_BRIGHTEN_STOP;
/*     */     }
/* 293 */     add3DEffekt(g, r, true, PlasticTheme.DARKEN_START, PlasticTheme.LT_DARKEN_STOP, PlasticTheme.BRIGHTEN_START, ltBrightenStop);
/*     */   }
/*     */ 
/*     */   private static void drawRect(Graphics g, int x, int y, int w, int h)
/*     */   {
/* 303 */     g.fillRect(x, y, w + 1, 1);
/* 304 */     g.fillRect(x, y + 1, 1, h);
/* 305 */     g.fillRect(x + 1, y + h, w, 1);
/* 306 */     g.fillRect(x + w, y + 1, 1, h);
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticUtils
 * JD-Core Version:    0.6.2
 */