/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.ComponentOrientation;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.ComboBoxEditor;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JScrollBar;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JToolBar;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicComboBoxUI;
/*     */ import javax.swing.plaf.basic.BasicComboBoxUI.PropertyChangeHandler;
/*     */ import javax.swing.plaf.basic.ComboPopup;
/*     */ import javax.swing.plaf.metal.MetalComboBoxUI;
/*     */ import javax.swing.plaf.metal.MetalComboBoxUI.MetalComboBoxLayoutManager;
/*     */ import javax.swing.plaf.metal.MetalComboBoxUI.MetalComboPopup;
/*     */ 
/*     */ public final class PlasticComboBoxUI extends MetalComboBoxUI
/*     */ {
/*     */   public static ComponentUI createUI(JComponent b)
/*     */   {
/*  56 */     return new PlasticComboBoxUI();
/*     */   }
/*     */ 
/*     */   protected ComboBoxEditor createEditor()
/*     */   {
/*  65 */     return new PlasticComboBoxEditor.UIResource();
/*     */   }
/*     */ 
/*     */   protected ComboPopup createPopup()
/*     */   {
/*  70 */     return new PlasticComboPopup(this.comboBox);
/*     */   }
/*     */ 
/*     */   private Insets getEditorInsets()
/*     */   {
/*  78 */     if ((this.editor instanceof JComponent)) {
/*  79 */       return ((JComponent)this.editor).getInsets();
/*     */     }
/*  81 */     return new Insets(0, 0, 0, 0);
/*     */   }
/*     */ 
/*     */   private int getEditableButtonWidth()
/*     */   {
/*  93 */     return UIManager.getInt("ScrollBar.width") - 1;
/*     */   }
/*     */ 
/*     */   public Dimension getMinimumSize(JComponent c)
/*     */   {
/* 100 */     if (!this.isMinimumSizeDirty) {
/* 101 */       return new Dimension(this.cachedMinimumSize);
/*     */     }
/*     */ 
/* 104 */     Dimension size = null;
/*     */ 
/* 106 */     if ((!this.comboBox.isEditable()) && 
/* 107 */       (this.arrowButton != null) && 
/* 108 */       ((this.arrowButton instanceof PlasticComboBoxButton)))
/*     */     {
/* 110 */       PlasticComboBoxButton button = 
/* 111 */         (PlasticComboBoxButton)this.arrowButton;
/* 112 */       Insets buttonInsets = button.getInsets();
/* 113 */       Insets buttonMargin = button.getMargin();
/* 114 */       Insets insets = this.comboBox.getInsets();
/* 115 */       size = getDisplaySize();
/*     */ 
/* 125 */       size.height += 2;
/* 126 */       size.width += insets.left + insets.right;
/* 127 */       size.width += buttonInsets.left + buttonInsets.right;
/* 128 */       size.width += buttonMargin.left + buttonMargin.right;
/* 129 */       size.width += button.getComboIcon().getIconWidth();
/* 130 */       size.height += insets.top + insets.bottom;
/* 131 */       size.height += buttonInsets.top + buttonInsets.bottom;
/*     */     }
/* 133 */     else if ((this.comboBox.isEditable()) && (this.arrowButton != null) && (this.editor != null))
/*     */     {
/* 136 */       size = getDisplaySize();
/* 137 */       Insets insets = this.comboBox.getInsets();
/* 138 */       Insets editorInsets = getEditorInsets();
/* 139 */       int buttonWidth = getEditableButtonWidth();
/*     */ 
/* 141 */       size.width += insets.left + insets.right;
/* 142 */       size.width += editorInsets.left + editorInsets.right - 1;
/* 143 */       size.width += buttonWidth;
/* 144 */       size.height += insets.top + insets.bottom;
/*     */     } else {
/* 146 */       size = super.getMinimumSize(c);
/*     */     }
/*     */ 
/* 149 */     this.cachedMinimumSize.setSize(size.width, size.height);
/* 150 */     this.isMinimumSizeDirty = false;
/*     */ 
/* 152 */     return new Dimension(this.cachedMinimumSize);
/*     */   }
/*     */ 
/*     */   protected JButton createArrowButton()
/*     */   {
/* 161 */     return new PlasticComboBoxButton(
/* 162 */       this.comboBox, 
/* 163 */       PlasticIconFactory.getComboBoxButtonIcon(), 
/* 164 */       this.comboBox.isEditable(), 
/* 165 */       this.currentValuePane, 
/* 166 */       this.listBox);
/*     */   }
/*     */ 
/*     */   protected LayoutManager createLayoutManager()
/*     */   {
/* 178 */     return new PlasticComboBoxLayoutManager();
/*     */   }
/*     */ 
/*     */   public void update(Graphics g, JComponent c)
/*     */   {
/* 184 */     if (c.isOpaque()) {
/* 185 */       g.setColor(c.getBackground());
/* 186 */       g.fillRect(0, 0, c.getWidth(), c.getHeight());
/* 187 */       if (isToolBarComboBox(c))
/* 188 */         c.setOpaque(false);
/*     */     }
/* 190 */     paint(g, c);
/*     */   }
/*     */ 
/*     */   protected boolean isToolBarComboBox(JComponent c)
/*     */   {
/* 201 */     Container parent = c.getParent();
/*     */ 
/* 204 */     return (parent != null) && (
/* 203 */       ((parent instanceof JToolBar)) || 
/* 204 */       ((parent.getParent() instanceof JToolBar)));
/*     */   }
/*     */ 
/*     */   public PropertyChangeListener createPropertyChangeListener()
/*     */   {
/* 259 */     return new PlasticPropertyChangeListener();
/*     */   }
/*     */ 
/*     */   private class PlasticComboBoxLayoutManager extends MetalComboBoxUI.MetalComboBoxLayoutManager
/*     */   {
/*     */     PlasticComboBoxLayoutManager()
/*     */     {
/* 217 */       super();
/*     */     }
/*     */ 
/*     */     public void layoutContainer(Container parent) {
/* 221 */       JComboBox cb = (JComboBox)parent;
/*     */ 
/* 224 */       if (!cb.isEditable()) {
/* 225 */         super.layoutContainer(parent);
/* 226 */         return;
/*     */       }
/*     */ 
/* 229 */       int width = cb.getWidth();
/* 230 */       int height = cb.getHeight();
/*     */ 
/* 232 */       Insets insets = PlasticComboBoxUI.this.getInsets();
/* 233 */       int buttonWidth = PlasticComboBoxUI.this.getEditableButtonWidth();
/* 234 */       int buttonHeight = height - (insets.top + insets.bottom);
/*     */ 
/* 236 */       if (PlasticComboBoxUI.access$2(PlasticComboBoxUI.this) != null) {
/* 237 */         if (cb.getComponentOrientation().isLeftToRight())
/* 238 */           PlasticComboBoxUI.access$2(PlasticComboBoxUI.this).setBounds(
/* 239 */             width - (insets.right + buttonWidth), 
/* 240 */             insets.top, 
/* 241 */             buttonWidth, 
/* 242 */             buttonHeight);
/*     */         else {
/* 244 */           PlasticComboBoxUI.access$2(PlasticComboBoxUI.this).setBounds(
/* 245 */             insets.left, 
/* 246 */             insets.top, 
/* 247 */             buttonWidth, 
/* 248 */             buttonHeight);
/*     */         }
/*     */       }
/* 251 */       if (PlasticComboBoxUI.access$3(PlasticComboBoxUI.this) != null)
/* 252 */         PlasticComboBoxUI.access$3(PlasticComboBoxUI.this).setBounds(PlasticComboBoxUI.this.rectangleForCurrentValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   private class PlasticPropertyChangeListener extends BasicComboBoxUI.PropertyChangeHandler
/*     */   {
/*     */     PlasticPropertyChangeListener()
/*     */     {
/* 264 */       super();
/*     */     }
/*     */ 
/*     */     public void propertyChange(PropertyChangeEvent e) {
/* 268 */       super.propertyChange(e);
/* 269 */       String propertyName = e.getPropertyName();
/*     */ 
/* 271 */       if (propertyName.equals("editable")) {
/* 272 */         PlasticComboBoxButton button = 
/* 273 */           (PlasticComboBoxButton)PlasticComboBoxUI.access$2(PlasticComboBoxUI.this);
/* 274 */         button.setIconOnly(PlasticComboBoxUI.access$5(PlasticComboBoxUI.this).isEditable());
/* 275 */         PlasticComboBoxUI.access$5(PlasticComboBoxUI.this).repaint();
/* 276 */       } else if (propertyName.equals("background")) {
/* 277 */         Color color = (Color)e.getNewValue();
/* 278 */         PlasticComboBoxUI.access$2(PlasticComboBoxUI.this).setBackground(color);
/* 279 */         PlasticComboBoxUI.access$6(PlasticComboBoxUI.this).setBackground(color);
/*     */       }
/* 281 */       else if (propertyName.equals("foreground")) {
/* 282 */         Color color = (Color)e.getNewValue();
/* 283 */         PlasticComboBoxUI.access$2(PlasticComboBoxUI.this).setForeground(color);
/* 284 */         PlasticComboBoxUI.access$6(PlasticComboBoxUI.this).setForeground(color);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class PlasticComboPopup extends MetalComboBoxUI.MetalComboPopup
/*     */   {
/*     */     PlasticComboPopup(JComboBox combo)
/*     */     {
/* 293 */       super(combo);
/*     */     }
/*     */ 
/*     */     protected void configureList()
/*     */     {
/* 300 */       super.configureList();
/* 301 */       this.list.setForeground(UIManager.getColor("MenuItem.foreground"));
/* 302 */       this.list.setBackground(UIManager.getColor("MenuItem.background"));
/*     */     }
/*     */ 
/*     */     protected void configureScroller()
/*     */     {
/* 309 */       super.configureScroller();
/* 310 */       this.scroller.getVerticalScrollBar().putClientProperty(
/* 311 */         "JScrollBar.isFreeStanding", 
/* 312 */         Boolean.FALSE);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticComboBoxUI
 * JD-Core Version:    0.6.2
 */