/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import com.jgoodies.looks.BorderStyle;
/*     */ import com.jgoodies.looks.HeaderStyle;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JToolBar;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.metal.MetalToolBarUI;
/*     */ 
/*     */ public final class PlasticToolBarUI extends MetalToolBarUI
/*     */ {
/*     */   private static final String PROPERTY_PREFIX = "ToolBar.";
/*     */   private PropertyChangeListener listener;
/*     */ 
/*     */   public static ComponentUI createUI(JComponent b)
/*     */   {
/*  69 */     return new PlasticToolBarUI();
/*     */   }
/*     */ 
/*     */   protected Border createRolloverBorder()
/*     */   {
/*  75 */     return PlasticBorders.getRolloverButtonBorder();
/*     */   }
/*     */ 
/*     */   protected void setBorderToRollover(Component c) {
/*  79 */     if ((c instanceof AbstractButton)) {
/*  80 */       super.setBorderToRollover(c);
/*  81 */     } else if ((c instanceof Container)) {
/*  82 */       Container cont = (Container)c;
/*  83 */       for (int i = 0; i < cont.getComponentCount(); i++)
/*  84 */         super.setBorderToRollover(cont.getComponent(i));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void installDefaults()
/*     */   {
/*  94 */     super.installDefaults();
/*  95 */     installSpecialBorder();
/*     */   }
/*     */ 
/*     */   protected void installListeners() {
/*  99 */     super.installListeners();
/* 100 */     this.listener = createBorderStyleListener();
/* 101 */     this.toolBar.addPropertyChangeListener(this.listener);
/*     */   }
/*     */ 
/*     */   protected void uninstallListeners() {
/* 105 */     this.toolBar.removePropertyChangeListener(this.listener);
/* 106 */     super.uninstallListeners();
/*     */   }
/*     */ 
/*     */   private PropertyChangeListener createBorderStyleListener() {
/* 110 */     return new PropertyChangeListener()
/*     */     {
/*     */       public void propertyChange(PropertyChangeEvent e) {
/* 113 */         String prop = e.getPropertyName();
/* 114 */         if ((prop.equals("jgoodies.headerStyle")) || 
/* 115 */           (prop.equals("Plastic.borderStyle")))
/* 116 */           PlasticToolBarUI.this.installSpecialBorder();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   private void installSpecialBorder()
/*     */   {
/* 134 */     BorderStyle borderStyle = 
/* 135 */       BorderStyle.from(this.toolBar, "Plastic.borderStyle");
/*     */     String suffix;
/*     */     String suffix;
/* 136 */     if (borderStyle == BorderStyle.EMPTY) {
/* 137 */       suffix = "emptyBorder";
/*     */     }
/*     */     else
/*     */     {
/*     */       String suffix;
/* 138 */       if (borderStyle == BorderStyle.ETCHED) {
/* 139 */         suffix = "etchedBorder";
/*     */       }
/*     */       else
/*     */       {
/*     */         String suffix;
/* 140 */         if (borderStyle == BorderStyle.SEPARATOR) {
/* 141 */           suffix = "separatorBorder";
/*     */         } else {
/* 143 */           HeaderStyle headerStyle = HeaderStyle.from(this.toolBar);
/*     */           String suffix;
/* 144 */           if (headerStyle == HeaderStyle.BOTH)
/* 145 */             suffix = "headerBorder";
/* 146 */           else if ((headerStyle == HeaderStyle.SINGLE) && (is3D()))
/* 147 */             suffix = "etchedBorder";
/*     */           else
/* 149 */             return; 
/*     */         }
/*     */       }
/*     */     }
/* 152 */     LookAndFeel.installBorder(this.toolBar, "ToolBar." + suffix);
/*     */   }
/*     */ 
/*     */   public void update(Graphics g, JComponent c)
/*     */   {
/* 158 */     if (c.isOpaque()) {
/* 159 */       g.setColor(c.getBackground());
/* 160 */       g.fillRect(0, 0, c.getWidth(), c.getHeight());
/*     */     }
/* 162 */     if (is3D()) {
/* 163 */       Rectangle bounds = 
/* 164 */         new Rectangle(0, 0, c.getWidth(), c.getHeight());
/* 165 */       PlasticUtils.addLight3DEffekt(g, bounds, true);
/*     */     }
/* 167 */     paint(g, c);
/*     */   }
/*     */ 
/*     */   private boolean is3D()
/*     */   {
/* 174 */     if (PlasticUtils.force3D(this.toolBar))
/* 175 */       return true;
/* 176 */     if (PlasticUtils.forceFlat(this.toolBar)) {
/* 177 */       return false;
/*     */     }
/*     */ 
/* 180 */     return (PlasticUtils.is3D("ToolBar.")) && 
/* 179 */       (HeaderStyle.from(this.toolBar) != null) && 
/* 180 */       (BorderStyle.from(this.toolBar, "Plastic.borderStyle") != 
/* 181 */       BorderStyle.EMPTY);
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticToolBarUI
 * JD-Core Version:    0.6.2
 */