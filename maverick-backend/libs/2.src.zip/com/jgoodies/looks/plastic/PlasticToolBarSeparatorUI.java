/*    */ package com.jgoodies.looks.plastic;
/*    */ 
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicToolBarSeparatorUI;
/*    */ 
/*    */ public final class PlasticToolBarSeparatorUI extends BasicToolBarSeparatorUI
/*    */ {
/*    */   private static ComponentUI toolBarSeparatorUI;
/*    */ 
/*    */   public static ComponentUI createUI(JComponent c)
/*    */   {
/* 50 */     if (toolBarSeparatorUI == null) {
/* 51 */       toolBarSeparatorUI = new PlasticToolBarSeparatorUI();
/*    */     }
/* 53 */     return toolBarSeparatorUI;
/*    */   }
/*    */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticToolBarSeparatorUI
 * JD-Core Version:    0.6.2
 */