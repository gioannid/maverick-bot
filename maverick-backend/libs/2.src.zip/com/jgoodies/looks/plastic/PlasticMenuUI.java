package com.jgoodies.looks.plastic;

import com.jgoodies.looks.common.ExtBasicMenuUI;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;
import javax.swing.ButtonModel;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicGraphicsUtils;

public final class PlasticMenuUI extends ExtBasicMenuUI
{
  public static ComponentUI createUI(JComponent paramJComponent)
  {
    return new PlasticMenuUI();
  }

  protected void paintMenuItem(Graphics paramGraphics, JComponent paramJComponent, Icon paramIcon1, Icon paramIcon2, Color paramColor1, Color paramColor2, int paramInt)
  {
    JMenuItem localJMenuItem = (JMenuItem)paramJComponent;
    if (((JMenu)this.menuItem).isTopLevelMenu())
    {
      localJMenuItem.setOpaque(false);
      if ((localJMenuItem.getModel().isSelected()) || (localJMenuItem.getModel().isRollover()))
      {
        int i = this.menuItem.getWidth();
        int j = this.menuItem.getHeight();
        Color localColor = paramGraphics.getColor();
        paramGraphics.setColor(paramColor1);
        paramGraphics.fillRect(0, 0, i, j);
        paramGraphics.setColor(localColor);
      }
    }
    super.paintMenuItem(paramGraphics, paramJComponent, paramIcon1, paramIcon2, paramColor1, paramColor2, paramInt);
  }

  protected void paintText(Graphics paramGraphics, JMenuItem paramJMenuItem, Rectangle paramRectangle, String paramString)
  {
    ButtonModel localButtonModel = paramJMenuItem.getModel();
    Font localFont1 = paramJMenuItem.getFont();
    Font localFont2 = paramGraphics.getFont();
    paramGraphics.setFont(localFont1);
    FontMetrics localFontMetrics = paramGraphics.getFontMetrics();
    int i = paramJMenuItem.getDisplayedMnemonicIndex();
    if (!localButtonModel.isEnabled())
      paramGraphics.setColor(PlasticXPUtils.MB_DISCOL);
    else if ((localButtonModel.isArmed()) || (((paramJMenuItem instanceof JMenu)) && ((localButtonModel.isSelected()) || (localButtonModel.isRollover()))))
      paramGraphics.setColor(this.selectionForeground);
    BasicGraphicsUtils.drawStringUnderlineCharAt(paramGraphics, paramString, i, paramRectangle.x, paramRectangle.y + localFontMetrics.getAscent());
    paramGraphics.setFont(localFont2);
  }
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticMenuUI
 * JD-Core Version:    0.6.2
 */