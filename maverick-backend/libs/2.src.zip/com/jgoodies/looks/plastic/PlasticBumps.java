/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import javax.swing.Icon;
/*     */ 
/*     */ final class PlasticBumps
/*     */   implements Icon
/*     */ {
/*     */   protected int xBumps;
/*     */   protected int yBumps;
/*     */   protected Color topColor;
/*     */   protected Color shadowColor;
/*     */   protected Color backColor;
/*  56 */   protected static Vector buffers = new Vector();
/*     */   protected BumpBuffer buffer;
/*     */ 
/*     */   public PlasticBumps(Dimension bumpArea)
/*     */   {
/*  60 */     this(bumpArea.width, bumpArea.height);
/*     */   }
/*     */ 
/*     */   public PlasticBumps(int width, int height)
/*     */   {
/*  67 */     this(width, height, 
/*  65 */       PlasticLookAndFeel.getPrimaryControlHighlight(), 
/*  66 */       PlasticLookAndFeel.getPrimaryControlDarkShadow(), 
/*  67 */       PlasticLookAndFeel.getPrimaryControlShadow());
/*     */   }
/*     */ 
/*     */   public PlasticBumps(int width, int height, Color newTopColor, Color newShadowColor, Color newBackColor)
/*     */   {
/*  72 */     setBumpArea(width, height);
/*  73 */     setBumpColors(newTopColor, newShadowColor, newBackColor);
/*     */   }
/*     */ 
/*     */   private BumpBuffer getBuffer(GraphicsConfiguration gc, Color aTopColor, Color aShadowColor, Color aBackColor)
/*     */   {
/*  78 */     if ((this.buffer != null) && 
/*  79 */       (this.buffer.hasSameConfiguration(gc, aTopColor, aShadowColor, aBackColor))) {
/*  80 */       return this.buffer;
/*     */     }
/*  82 */     BumpBuffer result = null;
/*  83 */     Enumeration elements = buffers.elements();
/*  84 */     while (elements.hasMoreElements()) {
/*  85 */       BumpBuffer aBuffer = (BumpBuffer)elements.nextElement();
/*  86 */       if (aBuffer.hasSameConfiguration(gc, aTopColor, aShadowColor, aBackColor)) {
/*  87 */         result = aBuffer;
/*  88 */         break;
/*     */       }
/*     */     }
/*  91 */     if (result == null) {
/*  92 */       result = new BumpBuffer(gc, this.topColor, this.shadowColor, this.backColor);
/*  93 */       buffers.addElement(result);
/*     */     }
/*  95 */     return result;
/*     */   }
/*     */ 
/*     */   public void setBumpArea(Dimension bumpArea) {
/*  99 */     setBumpArea(bumpArea.width, bumpArea.height);
/*     */   }
/*     */ 
/*     */   public void setBumpArea(int width, int height) {
/* 103 */     this.xBumps = (width / 2);
/* 104 */     this.yBumps = (height / 2);
/*     */   }
/*     */ 
/*     */   public void setBumpColors(Color newTopColor, Color newShadowColor, Color newBackColor) {
/* 108 */     this.topColor = newTopColor;
/* 109 */     this.shadowColor = newShadowColor;
/* 110 */     this.backColor = newBackColor;
/*     */   }
/*     */ 
/*     */   public void paintIcon(Component c, Graphics g, int x, int y) {
/* 114 */     GraphicsConfiguration gc = (g instanceof Graphics2D) ? 
/* 115 */       ((Graphics2D)g).getDeviceConfiguration() : 
/* 116 */       null;
/*     */ 
/* 118 */     this.buffer = getBuffer(gc, this.topColor, this.shadowColor, this.backColor);
/*     */ 
/* 120 */     int bufferWidth = this.buffer.getImageSize().width;
/* 121 */     int bufferHeight = this.buffer.getImageSize().height;
/* 122 */     int iconWidth = getIconWidth();
/* 123 */     int iconHeight = getIconHeight();
/* 124 */     int x2 = x + iconWidth;
/* 125 */     int y2 = y + iconHeight;
/* 126 */     int savex = x;
/*     */ 
/* 128 */     while (y < y2) {
/* 129 */       int h = Math.min(y2 - y, bufferHeight);
/* 130 */       for (x = savex; x < x2; x += bufferWidth) {
/* 131 */         int w = Math.min(x2 - x, bufferWidth);
/* 132 */         g.drawImage(this.buffer.getImage(), x, y, x + w, y + h, 0, 0, w, h, null);
/*     */       }
/* 134 */       y += bufferHeight;
/*     */     }
/*     */   }
/*     */ 
/* 138 */   public int getIconWidth() { return this.xBumps * 2; } 
/* 139 */   public int getIconHeight() { return this.yBumps * 2; }
/*     */ 
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticBumps
 * JD-Core Version:    0.6.2
 */