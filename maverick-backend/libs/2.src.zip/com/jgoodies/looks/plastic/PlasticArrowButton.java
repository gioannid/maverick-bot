/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.metal.MetalScrollButton;
/*     */ 
/*     */ class PlasticArrowButton extends MetalScrollButton
/*     */ {
/*     */   private static Color shadowColor;
/*     */   private static Color highlightColor;
/*     */   private static Color shadowColor2;
/*     */   private static Color highlightColor2;
/*     */   protected boolean isFreeStanding;
/*     */ 
/*     */   public PlasticArrowButton(int direction, int width, boolean freeStanding)
/*     */   {
/*  55 */     super(direction, width, freeStanding);
/*  56 */     shadowColor = UIManager.getColor("ScrollBar.darkShadow");
/*  57 */     highlightColor = UIManager.getColor("ScrollBar.highlight");
/*  58 */     shadowColor2 = PlasticXPUtils.SB_BG;
/*  59 */     highlightColor2 = PlasticXPUtils.SB_FG;
/*  60 */     this.isFreeStanding = freeStanding;
/*     */   }
/*     */ 
/*     */   public void setFreeStanding(boolean freeStanding) {
/*  64 */     super.setFreeStanding(freeStanding);
/*  65 */     this.isFreeStanding = freeStanding;
/*     */   }
/*     */ 
/*     */   public void paint(Graphics g) {
/*  69 */     boolean leftToRight = PlasticUtils.isLeftToRight(this);
/*  70 */     boolean isEnabled = getParent().isEnabled();
/*  71 */     boolean isPressed = getModel().isPressed();
/*     */ 
/*  73 */     int width = getWidth();
/*  74 */     int height = getHeight();
/*  75 */     int w = width;
/*  76 */     int h = height;
/*  77 */     int arrowHeight = calculateArrowHeight(height, width);
/*  78 */     int arrowOffset = calculateArrowOffset();
/*  79 */     boolean paintNorthBottom = isPaintingNorthBottom();
/*  80 */     Color bgColor = getBackground();
/*     */ 
/*  82 */     boolean useNorm = !bgColor.equals(PlasticXPUtils.BGCOL);
/*     */     Color arrowColor;
/*  83 */     if (!useNorm) {
/*  84 */       Color arrowColor = isEnabled ? getForeground() : PlasticXPUtils.SB_ARROW;
/*  85 */       bgColor = isPressed ? bgColor.darker() : bgColor;
/*     */     } else {
/*  87 */       arrowColor = isEnabled ? PlasticLookAndFeel.getControlInfo() : PlasticLookAndFeel.getControlDisabled();
/*  88 */       bgColor = isPressed ? PlasticLookAndFeel.getControlShadow() : bgColor;
/*     */     }
/*     */ 
/*  91 */     g.setColor(bgColor);
/*  92 */     g.fillRect(0, 0, width, height);
/*     */ 
/*  94 */     if (getDirection() == 1)
/*  95 */       paintNorth(g, leftToRight, isEnabled, arrowColor, isPressed, width, 
/*  96 */         height, w, h, arrowHeight, arrowOffset, paintNorthBottom, useNorm);
/*  97 */     else if (getDirection() == 5)
/*  98 */       paintSouth(g, leftToRight, isEnabled, arrowColor, isPressed, width, 
/*  99 */         height, w, h, arrowHeight, arrowOffset, useNorm);
/* 100 */     else if (getDirection() == 3)
/* 101 */       paintEast(g, isEnabled, arrowColor, isPressed, width, height, w, h, 
/* 102 */         arrowHeight, useNorm);
/* 103 */     else if (getDirection() == 7) {
/* 104 */       paintWest(g, isEnabled, arrowColor, isPressed, width, height, w, h, 
/* 105 */         arrowHeight, useNorm);
/*     */     }
/* 107 */     if (PlasticUtils.is3D("ScrollBar."))
/* 108 */       paint3D(g);
/*     */   }
/*     */ 
/*     */   protected int calculateArrowHeight(int height, int width)
/*     */   {
/* 122 */     return (height + 1) / 4;
/*     */   }
/*     */ 
/*     */   protected int calculateArrowOffset() {
/* 126 */     return 0;
/*     */   }
/*     */ 
/*     */   protected boolean isPaintingNorthBottom() {
/* 130 */     return false;
/*     */   }
/*     */ 
/*     */   private void paintWest(Graphics g, boolean isEnabled, Color arrowColor, boolean isPressed, int width, int height, int w, int h, int arrowHeight, boolean useNorm)
/*     */   {
/* 136 */     if (!this.isFreeStanding) {
/* 137 */       height += 2;
/* 138 */       width++;
/* 139 */       g.translate(-1, 0);
/*     */     }
/*     */ 
/* 143 */     g.setColor(arrowColor);
/*     */ 
/* 145 */     int startX = (w + 1 - arrowHeight) / 2;
/* 146 */     int startY = h / 2;
/*     */ 
/* 148 */     for (int line = 0; line < arrowHeight; line++) {
/* 149 */       g.drawLine(startX + line, startY - line, startX + line, startY + line + 
/* 150 */         1);
/*     */     }
/*     */ 
/* 153 */     if (isEnabled) {
/* 154 */       g.setColor(useNorm ? highlightColor : highlightColor2);
/*     */ 
/* 156 */       if (!isPressed) {
/* 157 */         g.drawLine(1, 1, width - 1, 1);
/* 158 */         g.drawLine(1, 1, 1, height - 3);
/*     */       }
/* 160 */       g.drawLine(1, height - 1, width - 1, height - 1);
/* 161 */       g.setColor(useNorm ? shadowColor : shadowColor2);
/* 162 */       g.drawLine(0, 0, width - 1, 0);
/* 163 */       g.drawLine(0, 0, 0, height - 2);
/* 164 */       g.drawLine(1, height - 2, width - 1, height - 2);
/*     */     } else {
/* 166 */       PlasticUtils.drawDisabledBorder(g, 0, 0, width + 1, height);
/*     */     }
/*     */ 
/* 169 */     if (!this.isFreeStanding) {
/* 170 */       height -= 2;
/* 171 */       width--;
/* 172 */       g.translate(1, 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void paintEast(Graphics g, boolean isEnabled, Color arrowColor, boolean isPressed, int width, int height, int w, int h, int arrowHeight, boolean useNorm)
/*     */   {
/* 178 */     if (!this.isFreeStanding) {
/* 179 */       height += 2;
/* 180 */       width++;
/*     */     }
/*     */ 
/* 184 */     g.setColor(arrowColor);
/*     */ 
/* 186 */     int startX = (w + 1 - arrowHeight) / 2 + arrowHeight - 1;
/* 187 */     int startY = h / 2;
/* 188 */     for (int line = 0; line < arrowHeight; line++) {
/* 189 */       g.drawLine(startX - line, startY - line, startX - line, startY + line + 
/* 190 */         1);
/*     */     }
/*     */ 
/* 193 */     if (isEnabled) {
/* 194 */       g.setColor(useNorm ? highlightColor : highlightColor2);
/* 195 */       if (!isPressed) {
/* 196 */         g.drawLine(0, 1, width - 3, 1);
/* 197 */         g.drawLine(0, 1, 0, height - 3);
/*     */       }
/* 199 */       g.drawLine(width - 1, 1, width - 1, height - 1);
/* 200 */       g.drawLine(0, height - 1, width - 1, height - 1);
/*     */ 
/* 202 */       g.setColor(useNorm ? shadowColor : shadowColor2);
/* 203 */       g.drawLine(0, 0, width - 2, 0);
/* 204 */       g.drawLine(width - 2, 1, width - 2, height - 2);
/* 205 */       g.drawLine(0, height - 2, width - 2, height - 2);
/*     */     } else {
/* 207 */       PlasticUtils.drawDisabledBorder(g, -1, 0, width + 1, height);
/*     */     }
/* 209 */     if (!this.isFreeStanding) {
/* 210 */       height -= 2;
/* 211 */       width--;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void paintSouth(Graphics g, boolean leftToRight, boolean isEnabled, Color arrowColor, boolean isPressed, int width, int height, int w, int h, int arrowHeight, int arrowOffset, boolean useNorm)
/*     */   {
/* 219 */     if (!this.isFreeStanding) {
/* 220 */       height++;
/* 221 */       if (!leftToRight) {
/* 222 */         width++;
/* 223 */         g.translate(-1, 0);
/*     */       } else {
/* 225 */         width += 2;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 230 */     g.setColor(arrowColor);
/*     */ 
/* 232 */     int startY = (h + 0 - arrowHeight) / 2 + arrowHeight - 1;
/*     */ 
/* 234 */     int startX = w / 2;
/*     */ 
/* 238 */     for (int line = 0; line < arrowHeight; line++) {
/* 239 */       g.fillRect(startX - line - arrowOffset, startY - line, 2 * (line + 1), 
/* 240 */         1);
/*     */     }
/*     */ 
/* 243 */     if (isEnabled) {
/* 244 */       g.setColor(useNorm ? highlightColor : highlightColor2);
/* 245 */       if (!isPressed) {
/* 246 */         g.drawLine(1, 0, width - 3, 0);
/* 247 */         g.drawLine(1, 0, 1, height - 3);
/*     */       }
/* 249 */       g.drawLine(0, height - 1, width - 1, height - 1);
/* 250 */       g.drawLine(width - 1, 0, width - 1, height - 1);
/*     */ 
/* 252 */       g.setColor(useNorm ? shadowColor : shadowColor2);
/* 253 */       g.drawLine(0, 0, 0, height - 2);
/* 254 */       g.drawLine(width - 2, 0, width - 2, height - 2);
/* 255 */       g.drawLine(1, height - 2, width - 2, height - 2);
/*     */     } else {
/* 257 */       PlasticUtils.drawDisabledBorder(g, 0, -1, width, height + 1);
/*     */     }
/*     */ 
/* 260 */     if (!this.isFreeStanding) {
/* 261 */       height--;
/* 262 */       if (!leftToRight) {
/* 263 */         width--;
/* 264 */         g.translate(1, 0);
/*     */       } else {
/* 266 */         width -= 2;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void paintNorth(Graphics g, boolean leftToRight, boolean isEnabled, Color arrowColor, boolean isPressed, int width, int height, int w, int h, int arrowHeight, int arrowOffset, boolean paintBottom, boolean useNorm)
/*     */   {
/* 275 */     if (!this.isFreeStanding) {
/* 276 */       height++;
/* 277 */       g.translate(0, -1);
/* 278 */       if (!leftToRight) {
/* 279 */         width++;
/* 280 */         g.translate(-1, 0);
/*     */       } else {
/* 282 */         width += 2;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 287 */     g.setColor(arrowColor);
/* 288 */     int startY = (h + 1 - arrowHeight) / 2;
/* 289 */     int startX = w / 2;
/*     */ 
/* 291 */     for (int line = 0; line < arrowHeight; line++) {
/* 292 */       g.fillRect(startX - line - arrowOffset, startY + line, 2 * (line + 1), 
/* 293 */         1);
/*     */     }
/*     */ 
/* 296 */     if (isEnabled) {
/* 297 */       g.setColor(useNorm ? highlightColor : highlightColor2);
/*     */ 
/* 299 */       if (!isPressed) {
/* 300 */         g.drawLine(1, 1, width - 3, 1);
/* 301 */         g.drawLine(1, 1, 1, height - 1);
/*     */       }
/*     */ 
/* 304 */       g.drawLine(width - 1, 1, width - 1, height - 1);
/*     */ 
/* 306 */       g.setColor(useNorm ? shadowColor : shadowColor2);
/* 307 */       g.drawLine(0, 0, width - 2, 0);
/* 308 */       g.drawLine(0, 0, 0, height - 1);
/* 309 */       g.drawLine(width - 2, 1, width - 2, height - 1);
/* 310 */       if (paintBottom)
/* 311 */         g.fillRect(0, height - 1, width - 1, 1);
/*     */     }
/*     */     else {
/* 314 */       PlasticUtils.drawDisabledBorder(g, 0, 0, width, height + 1);
/* 315 */       if (paintBottom) {
/* 316 */         g.setColor(PlasticLookAndFeel.getControlShadow());
/* 317 */         g.fillRect(0, height - 1, width - 1, 1);
/*     */       }
/*     */     }
/* 320 */     if (!this.isFreeStanding) {
/* 321 */       height--;
/* 322 */       g.translate(0, 1);
/* 323 */       if (!leftToRight) {
/* 324 */         width--;
/* 325 */         g.translate(1, 0);
/*     */       } else {
/* 327 */         width -= 2;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void paint3D(Graphics g) {
/* 333 */     ButtonModel buttonModel = getModel();
/* 334 */     if (((buttonModel.isArmed()) && (buttonModel.isPressed())) || 
/* 335 */       (buttonModel.isSelected())) {
/* 336 */       return;
/*     */     }
/* 338 */     int width = getWidth();
/* 339 */     int height = getHeight();
/* 340 */     if (getDirection() == 3)
/* 341 */       width -= 2;
/* 342 */     else if (getDirection() == 5) {
/* 343 */       height -= 2;
/*     */     }
/* 345 */     Rectangle r = new Rectangle(1, 1, width, height);
/* 346 */     boolean isHorizontal = (getDirection() == 3) || (getDirection() == 7);
/* 347 */     PlasticUtils.addLight3DEffekt(g, r, isHorizontal);
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticArrowButton
 * JD-Core Version:    0.6.2
 */