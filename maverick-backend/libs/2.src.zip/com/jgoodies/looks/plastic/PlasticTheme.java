/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import javax.swing.plaf.ColorUIResource;
/*     */ import javax.swing.plaf.FontUIResource;
/*     */ import javax.swing.plaf.metal.DefaultMetalTheme;
/*     */ 
/*     */ public abstract class PlasticTheme extends DefaultMetalTheme
/*     */ {
/*  50 */   public static final Color DARKEN_START = new Color(0, 0, 0, 0);
/*  51 */   public static final Color DARKEN_STOP = new Color(0, 0, 0, 64);
/*  52 */   public static final Color LT_DARKEN_STOP = new Color(0, 0, 0, 32);
/*  53 */   public static final Color BRIGHTEN_START = new Color(255, 255, 255, 0);
/*  54 */   public static final Color BRIGHTEN_STOP = new Color(255, 255, 255, 128);
/*  55 */   public static final Color LT_BRIGHTEN_STOP = new Color(255, 255, 255, 64);
/*     */ 
/*  58 */   protected static final ColorUIResource WHITE = new ColorUIResource(255, 255, 255);
/*     */ 
/*  60 */   protected static final ColorUIResource BLACK = new ColorUIResource(0, 0, 0);
/*     */   protected FontUIResource titleFont;
/*     */   protected FontUIResource controlFont;
/*     */   protected FontUIResource systemFont;
/*     */   protected FontUIResource userFont;
/*     */   protected FontUIResource smallFont;
/*     */ 
/*     */   protected ColorUIResource getBlack()
/*     */   {
/*  71 */     return BLACK;
/*     */   }
/*     */ 
/*     */   protected ColorUIResource getWhite() {
/*  75 */     return WHITE;
/*     */   }
/*     */ 
/*     */   public ColorUIResource getSystemTextColor() {
/*  79 */     return getControlInfo();
/*     */   }
/*     */ 
/*     */   public ColorUIResource getTitleTextColor() {
/*  83 */     return getPrimary1();
/*     */   }
/*     */ 
/*     */   public ColorUIResource getMenuForeground() {
/*  87 */     return getControlInfo();
/*     */   }
/*     */ 
/*     */   public ColorUIResource getMenuItemBackground() {
/*  91 */     return getMenuBackground();
/*     */   }
/*     */ 
/*     */   public ColorUIResource getMenuItemSelectedBackground() {
/*  95 */     return getMenuSelectedBackground();
/*     */   }
/*     */ 
/*     */   public ColorUIResource getMenuItemSelectedForeground() {
/*  99 */     return getMenuSelectedForeground();
/*     */   }
/*     */ 
/*     */   public ColorUIResource getSimpleInternalFrameForeground() {
/* 103 */     return getWhite();
/*     */   }
/*     */ 
/*     */   public ColorUIResource getSimpleInternalFrameBackground() {
/* 107 */     return getPrimary1();
/*     */   }
/*     */ 
/*     */   public ColorUIResource getToggleButtonCheckColor() {
/* 111 */     return getPrimary1();
/*     */   }
/*     */ 
/*     */   public FontUIResource getTitleTextFont()
/*     */   {
/* 119 */     if (this.titleFont == null) {
/* 120 */       this.titleFont = 
/* 121 */         new FontUIResource(
/* 122 */         Font.getFont(
/* 123 */         "swing.plaf.metal.controlFont", 
/* 124 */         new Font("Dialog", 1, 12)));
/*     */     }
/* 126 */     return this.titleFont;
/*     */   }
/*     */ 
/*     */   public FontUIResource getControlTextFont() {
/* 130 */     return getFont();
/*     */   }
/*     */ 
/*     */   public FontUIResource getMenuTextFont() {
/* 134 */     return getFont();
/*     */   }
/*     */ 
/*     */   public FontUIResource getSubTextFont() {
/* 138 */     if (this.smallFont == null) {
/* 139 */       this.smallFont = 
/* 140 */         new FontUIResource(
/* 141 */         Font.getFont(
/* 142 */         "swing.plaf.metal.smallFont", 
/* 143 */         new Font("Dialog", 0, 10)));
/*     */     }
/* 145 */     return this.smallFont;
/*     */   }
/*     */ 
/*     */   public FontUIResource getSystemTextFont() {
/* 149 */     if (this.systemFont == null) {
/* 150 */       this.systemFont = 
/* 151 */         new FontUIResource(
/* 152 */         Font.getFont(
/* 153 */         "swing.plaf.metal.systemFont", 
/* 154 */         new Font("Dialog", 0, 12)));
/*     */     }
/* 156 */     return this.systemFont;
/*     */   }
/*     */ 
/*     */   public FontUIResource getUserTextFont() {
/* 160 */     if (this.userFont == null) {
/* 161 */       this.userFont = 
/* 162 */         new FontUIResource(
/* 163 */         Font.getFont(
/* 164 */         "swing.plaf.metal.userFont", 
/* 165 */         new Font("Dialog", 0, 12)));
/*     */     }
/* 167 */     return this.userFont;
/*     */   }
/*     */ 
/*     */   public FontUIResource getWindowTitleFont() {
/* 171 */     return getFont();
/*     */   }
/*     */ 
/*     */   protected FontUIResource getFont()
/*     */   {
/* 178 */     if (this.controlFont == null) {
/* 179 */       this.controlFont = new FontUIResource(getFont0());
/*     */     }
/* 181 */     return this.controlFont;
/*     */   }
/*     */ 
/*     */   protected Font getFont0() {
/* 185 */     Font font = Font.getFont("swing.plaf.metal.controlFont");
/* 186 */     return font != null ? 
/* 187 */       font.deriveFont(0) : 
/* 188 */       new Font("Dialog", 0, 12);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 200 */     if (this == o)
/* 201 */       return true;
/* 202 */     if (o == null)
/* 203 */       return false;
/* 204 */     return getClass().equals(o.getClass());
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 214 */     return getClass().hashCode();
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticTheme
 * JD-Core Version:    0.6.2
 */