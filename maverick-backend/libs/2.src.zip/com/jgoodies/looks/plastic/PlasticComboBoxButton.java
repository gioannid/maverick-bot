/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.CellRendererPane;
/*     */ import javax.swing.DefaultButtonModel;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.ListCellRenderer;
/*     */ import javax.swing.UIManager;
/*     */ 
/*     */ final class PlasticComboBoxButton extends JButton
/*     */ {
/*     */   private static final int LEFT_INSET = 2;
/*     */   private static final int RIGHT_INSET = 3;
/*     */   private final JList listBox;
/*     */   private final CellRendererPane rendererPane;
/*     */   private JComboBox comboBox;
/*     */   private Icon comboIcon;
/*  63 */   protected boolean iconOnly = false;
/*     */   private boolean borderPaintsFocus;
/*     */ 
/*     */   PlasticComboBoxButton(JComboBox comboBox, Icon comboIcon, boolean iconOnly, CellRendererPane rendererPane, JList listBox)
/*     */   {
/*  75 */     super("");
/*  76 */     setModel(new DefaultButtonModel() {
/*     */       public void setArmed(boolean armed) {
/*  78 */         super.setArmed((isPressed()) || (armed));
/*     */       }
/*     */     });
/*  81 */     this.comboBox = comboBox;
/*  82 */     this.comboIcon = comboIcon;
/*  83 */     this.iconOnly = iconOnly;
/*  84 */     this.rendererPane = rendererPane;
/*  85 */     this.listBox = listBox;
/*  86 */     setEnabled(comboBox.isEnabled());
/*  87 */     setFocusable(false);
/*  88 */     setRequestFocusEnabled(comboBox.isEnabled());
/*  89 */     setBorder(UIManager.getBorder("ComboBox.arrowButtonBorder"));
/*  90 */     setMargin(new Insets(0, 2, 0, 3));
/*  91 */     this.borderPaintsFocus = UIManager.getBoolean("ComboBox.borderPaintsFocus");
/*     */   }
/*     */ 
/*     */   public JComboBox getComboBox() {
/*  95 */     return this.comboBox;
/*     */   }
/*     */ 
/*     */   public void setComboBox(JComboBox cb) {
/*  99 */     this.comboBox = cb;
/*     */   }
/*     */ 
/*     */   public Icon getComboIcon() {
/* 103 */     return this.comboIcon;
/*     */   }
/*     */ 
/*     */   public void setComboIcon(Icon i) {
/* 107 */     this.comboIcon = i;
/*     */   }
/*     */ 
/*     */   public boolean isIconOnly() {
/* 111 */     return this.iconOnly;
/*     */   }
/*     */ 
/*     */   public void setIconOnly(boolean b) {
/* 115 */     this.iconOnly = b;
/*     */   }
/*     */ 
/*     */   public void setEnabled(boolean enabled) {
/* 119 */     super.setEnabled(enabled);
/*     */ 
/* 121 */     if (enabled) {
/* 122 */       setBackground(this.comboBox.getBackground());
/* 123 */       setForeground(this.comboBox.getForeground());
/*     */     } else {
/* 125 */       setBackground(UIManager.getColor("ComboBox.disabledBackground"));
/* 126 */       setForeground(UIManager.getColor("ComboBox.disabledForeground"));
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean is3D()
/*     */   {
/* 134 */     if (PlasticUtils.force3D(this.comboBox))
/* 135 */       return true;
/* 136 */     if (PlasticUtils.forceFlat(this.comboBox))
/* 137 */       return false;
/* 138 */     return PlasticUtils.is3D("ComboBox.");
/*     */   }
/*     */ 
/*     */   public void paintComponent(Graphics g)
/*     */   {
/* 146 */     super.paintComponent(g);
/* 147 */     boolean leftToRight = PlasticUtils.isLeftToRight(this.comboBox);
/*     */ 
/* 149 */     Insets insets = getInsets();
/*     */ 
/* 151 */     int width = getWidth() - (insets.left + insets.right);
/* 152 */     int height = getHeight() - (insets.top + insets.bottom);
/*     */ 
/* 154 */     if ((height <= 0) || (width <= 0)) {
/* 155 */       return;
/*     */     }
/*     */ 
/* 158 */     int left = insets.left;
/* 159 */     int top = insets.top;
/* 160 */     int right = left + (width - 1);
/*     */ 
/* 162 */     int iconWidth = 0;
/* 163 */     int iconLeft = leftToRight ? right : left;
/*     */ 
/* 166 */     if (this.comboIcon != null) {
/* 167 */       iconWidth = this.comboIcon.getIconWidth();
/* 168 */       int iconHeight = this.comboIcon.getIconHeight();
/*     */       int iconTop;
/*     */       int iconTop;
/* 171 */       if (this.iconOnly) {
/* 172 */         iconLeft = (getWidth() - iconWidth) / 2;
/* 173 */         iconTop = (getHeight() - iconHeight) / 2;
/*     */       } else {
/* 175 */         if (leftToRight)
/* 176 */           iconLeft = left + (width - 1) - iconWidth;
/*     */         else {
/* 178 */           iconLeft = left;
/*     */         }
/* 180 */         iconTop = (getHeight() - iconHeight) / 2;
/*     */       }
/*     */ 
/* 183 */       this.comboIcon.paintIcon(this, g, iconLeft, iconTop);
/*     */     }
/*     */ 
/* 188 */     if ((!this.iconOnly) && (this.comboBox != null)) {
/* 189 */       ListCellRenderer renderer = this.comboBox.getRenderer();
/* 190 */       boolean renderPressed = getModel().isPressed();
/* 191 */       Component c = 
/* 192 */         renderer.getListCellRendererComponent(
/* 193 */         this.listBox, 
/* 194 */         this.comboBox.getSelectedItem(), 
/* 195 */         -1, 
/* 196 */         renderPressed, 
/* 197 */         false);
/* 198 */       c.setFont(this.rendererPane.getFont());
/*     */ 
/* 200 */       if ((this.model.isArmed()) && (this.model.isPressed())) {
/* 201 */         if (isOpaque()) {
/* 202 */           c.setBackground(UIManager.getColor("Button.select"));
/*     */         }
/* 204 */         c.setForeground(this.comboBox.getForeground());
/* 205 */       } else if (!this.comboBox.isEnabled()) {
/* 206 */         if (isOpaque()) {
/* 207 */           c.setBackground(
/* 208 */             UIManager.getColor("ComboBox.disabledBackground"));
/*     */         }
/* 210 */         c.setForeground(
/* 211 */           UIManager.getColor("ComboBox.disabledForeground"));
/*     */       } else {
/* 213 */         c.setForeground(this.comboBox.getForeground());
/* 214 */         c.setBackground(this.comboBox.getBackground());
/*     */       }
/*     */ 
/* 217 */       int cWidth = width - (insets.right + iconWidth);
/*     */ 
/* 220 */       boolean shouldValidate = c instanceof JPanel;
/* 221 */       int x = leftToRight ? left : left + iconWidth;
/* 222 */       int myHeight = getHeight() - 2 - 3 - 1;
/*     */ 
/* 224 */       if (!is3D()) {
/* 225 */         this.rendererPane.paintComponent(
/* 226 */           g, 
/* 227 */           c, 
/* 228 */           this, 
/* 229 */           x, 
/* 230 */           top + 2, 
/* 231 */           cWidth, 
/* 232 */           myHeight, 
/* 233 */           shouldValidate);
/* 234 */       } else if (!(c instanceof JComponent)) {
/* 235 */         this.rendererPane.paintComponent(
/* 236 */           g, 
/* 237 */           c, 
/* 238 */           this, 
/* 239 */           x, 
/* 240 */           top + 2, 
/* 241 */           cWidth, 
/* 242 */           myHeight, 
/* 243 */           shouldValidate);
/*     */       }
/* 246 */       else if (!c.isOpaque()) {
/* 247 */         this.rendererPane.paintComponent(
/* 248 */           g, 
/* 249 */           c, 
/* 250 */           this, 
/* 251 */           x, 
/* 252 */           top + 2, 
/* 253 */           cWidth, 
/* 254 */           myHeight, 
/* 255 */           shouldValidate);
/*     */       }
/*     */       else
/*     */       {
/* 260 */         JComponent component = (JComponent)c;
/* 261 */         boolean hasBeenOpaque = component.isOpaque();
/* 262 */         component.setOpaque(false);
/* 263 */         this.rendererPane.paintComponent(
/* 264 */           g, 
/* 265 */           c, 
/* 266 */           this, 
/* 267 */           x, 
/* 268 */           top + 2, 
/* 269 */           cWidth, 
/* 270 */           myHeight, 
/* 271 */           shouldValidate);
/* 272 */         component.setOpaque(hasBeenOpaque);
/*     */       }
/*     */     }
/*     */ 
/* 276 */     if (this.comboIcon != null)
/*     */     {
/* 278 */       boolean hasFocus = this.comboBox.hasFocus();
/* 279 */       if ((!this.borderPaintsFocus) && (hasFocus)) {
/* 280 */         g.setColor(PlasticLookAndFeel.getFocusColor());
/* 281 */         int x = 2;
/* 282 */         int y = 2;
/* 283 */         int w = getWidth() - 2 - 3;
/* 284 */         int h = getHeight() - 2 - 3;
/* 285 */         g.drawRect(x, y, w - 1, h - 1);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticComboBoxButton
 * JD-Core Version:    0.6.2
 */