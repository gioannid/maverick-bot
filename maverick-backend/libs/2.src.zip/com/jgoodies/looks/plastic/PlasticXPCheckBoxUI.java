/*    */ package com.jgoodies.looks.plastic;
/*    */ 
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Rectangle;
/*    */ import javax.swing.AbstractButton;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicButtonListener;
/*    */ import javax.swing.plaf.metal.MetalCheckBoxUI;
/*    */ 
/*    */ public final class PlasticXPCheckBoxUI extends MetalCheckBoxUI
/*    */ {
/* 51 */   private static final PlasticXPCheckBoxUI INSTANCE = new PlasticXPCheckBoxUI();
/*    */ 
/*    */   public static ComponentUI createUI(JComponent b) {
/* 54 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */   protected BasicButtonListener createButtonListener(AbstractButton b) {
/* 58 */     return new ActiveBasicButtonListener(b);
/*    */   }
/*    */ 
/*    */   protected void paintFocus(Graphics g, Rectangle t, Dimension d)
/*    */   {
/*    */   }
/*    */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticXPCheckBoxUI
 * JD-Core Version:    0.6.2
 */