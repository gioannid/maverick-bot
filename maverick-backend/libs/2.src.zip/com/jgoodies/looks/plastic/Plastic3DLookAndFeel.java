/*    */ package com.jgoodies.looks.plastic;
/*    */ 
/*    */ import javax.swing.UIDefaults;
/*    */ 
/*    */ public class Plastic3DLookAndFeel extends PlasticLookAndFeel
/*    */ {
/*    */   public Plastic3DLookAndFeel()
/*    */   {
/* 48 */     if (getMyCurrentTheme() == null)
/* 49 */       setMyCurrentTheme(createMyDefaultTheme());
/*    */   }
/*    */ 
/*    */   public String getID() {
/* 53 */     return "JGoodies Plastic 3D";
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 57 */     return "JGoodies Plastic 3D";
/*    */   }
/*    */ 
/*    */   public String getDescription() {
/* 61 */     return "The JGoodies Plastic 3D Look and Feel - © 2001-2005 JGoodies Karsten Lentzsch";
/*    */   }
/*    */ 
/*    */   protected boolean is3DEnabled()
/*    */   {
/* 66 */     return true;
/*    */   }
/*    */ 
/*    */   protected void initComponentDefaults(UIDefaults table)
/*    */   {
/* 75 */     super.initComponentDefaults(table);
/*    */ 
/* 77 */     Object menuBarBorder = PlasticBorders.getThinRaisedBorder();
/* 78 */     Object toolBarBorder = PlasticBorders.getThinRaisedBorder();
/*    */ 
/* 80 */     Object[] defaults = { 
/* 81 */       "MenuBar.border", menuBarBorder, 
/* 82 */       "ToolBar.border", toolBarBorder };
/*    */ 
/* 84 */     table.putDefaults(defaults);
/*    */   }
/*    */ 
/*    */   protected static void installDefaultThemes()
/*    */   {
/*    */   }
/*    */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.Plastic3DLookAndFeel
 * JD-Core Version:    0.6.2
 */