/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import com.jgoodies.looks.LookUtils;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*     */ 
/*     */ public final class PlasticXPUtils
/*     */ {
/*  50 */   public static Color BGCOL = new Color(93, 27, 27);
/*  51 */   public static Color FGCOL = new Color(255, 190, 140);
/*     */ 
/*  53 */   public static Color MB_BGCOL = BGCOL;
/*  54 */   public static Color MB_FGCOL = FGCOL;
/*  55 */   public static Color MB_DISCOL = BGCOL.brighter().brighter();
/*     */ 
/*  57 */   public static Color SB_BG = BGCOL.brighter();
/*  58 */   public static Color SB_FG = FGCOL;
/*  59 */   public static Color SB_ARROW = FGCOL;
/*  60 */   public static Color SB_SHADOW = FGCOL;
/*  61 */   public static Color SB_DARK_SHADOW = BGCOL;
/*  62 */   public static Color SB_HILIGHT = FGCOL;
/*  63 */   public static Color SB_THUMB = BGCOL;
/*  64 */   public static Color SB_THUMB_SHADOW = BGCOL;
/*  65 */   public static Color SB_THUMB_HILIGHT = FGCOL;
/*     */ 
/*     */   static {
/*  68 */     setColors(true, new Color(255, 190, 140), new Color(93, 27, 27));
/*     */   }
/*     */ 
/*     */   public static void setColors(boolean inverted, Color fg, Color bg) {
/*  72 */     BGCOL = bg;
/*  73 */     FGCOL = fg;
/*  74 */     MB_BGCOL = bg;
/*  75 */     MB_FGCOL = fg;
/*  76 */     MB_DISCOL = inverted ? bg.brighter().brighter() : fg.brighter().brighter();
/*  77 */     SB_BG = inverted ? fg.darker() : bg;
/*  78 */     SB_FG = fg;
/*  79 */     SB_ARROW = fg;
/*  80 */     SB_SHADOW = inverted ? fg : bg;
/*  81 */     SB_DARK_SHADOW = bg;
/*  82 */     SB_HILIGHT = fg;
/*  83 */     SB_THUMB = inverted ? bg : fg;
/*  84 */     SB_THUMB_SHADOW = inverted ? bg : fg;
/*  85 */     SB_THUMB_HILIGHT = inverted ? fg : bg;
/*     */   }
/*     */ 
/*     */   public static void setColors(Map colors) {
/*  89 */     Iterator i = colors.keySet().iterator();
/*  90 */     while (i.hasNext()) {
/*  91 */       String key = (String)i.next();
/*  92 */       Color c = (Color)colors.get(key);
/*  93 */       if (key.equals("BGCOL")) BGCOL = c;
/*  94 */       if (key.equals("FGCOL")) FGCOL = c;
/*  95 */       if (key.equals("MB_BGCOL")) MB_BGCOL = c;
/*  96 */       if (key.equals("MB_FGCOL")) MB_FGCOL = c;
/*  97 */       if (key.equals("MB_DISCOL")) MB_DISCOL = c;
/*  98 */       if (key.equals("SB_BG")) SB_BG = c;
/*  99 */       if (key.equals("SB_FG")) SB_FG = c;
/* 100 */       if (key.equals("SB_ARROW")) SB_ARROW = c;
/* 101 */       if (key.equals("SB_SHADOW")) SB_SHADOW = c;
/* 102 */       if (key.equals("SB_DARK_SHADOW")) SB_DARK_SHADOW = c;
/* 103 */       if (key.equals("SB_HILIGHT")) SB_HILIGHT = c;
/* 104 */       if (key.equals("SB_THUMB")) SB_THUMB = c;
/* 105 */       if (key.equals("SB_THUMB_SHADOW")) SB_THUMB_SHADOW = c;
/* 106 */       if (key.equals("SB_THUMB_HILIGHT")) SB_THUMB_HILIGHT = c;
/*     */     }
/*     */   }
/*     */ 
/*     */   static void drawPlainButtonBorder(Graphics g, int x, int y, int w, int h)
/*     */   {
/* 115 */     drawButtonBorder(g, x, y, w, h, 
/* 116 */       PlasticLookAndFeel.getControl(), 
/* 117 */       PlasticLookAndFeel.getControlDarkShadow(), 
/* 118 */       LookUtils.getSlightlyBrighter(
/* 119 */       PlasticLookAndFeel.getControlDarkShadow(), 
/* 120 */       1.25F));
/*     */   }
/*     */ 
/*     */   static void drawPressedButtonBorder(Graphics g, int x, int y, int w, int h)
/*     */   {
/* 128 */     drawPlainButtonBorder(g, x, y, w, h);
/* 129 */     Color darkColor = 
/* 130 */       translucentColor(PlasticLookAndFeel.getControlDarkShadow(), 
/* 131 */       128);
/* 132 */     Color lightColor = 
/* 133 */       translucentColor(PlasticLookAndFeel.getControlHighlight(), 
/* 134 */       80);
/* 135 */     g.translate(x, y);
/* 136 */     g.setColor(darkColor);
/* 137 */     g.fillRect(2, 1, w - 4, 1);
/*     */ 
/* 139 */     g.setColor(lightColor);
/* 140 */     g.fillRect(2, h - 2, w - 4, 1);
/* 141 */     g.translate(-x, -y);
/*     */   }
/*     */ 
/*     */   static void drawDefaultButtonBorder(Graphics g, int x, int y, int w, int h)
/*     */   {
/* 148 */     drawPlainButtonBorder(g, x, y, w, h);
/* 149 */     drawInnerButtonDecoration(g, x, y, w, h, 
/* 150 */       PlasticLookAndFeel.getPrimaryControlDarkShadow());
/*     */   }
/*     */ 
/*     */   static void drawFocusedButtonBorder(Graphics g, int x, int y, int w, int h)
/*     */   {
/* 157 */     drawPlainButtonBorder(g, x, y, w, h);
/* 158 */     drawInnerButtonDecoration(g, x, y, w, h, 
/* 159 */       PlasticLookAndFeel.getFocusColor());
/*     */   }
/*     */ 
/*     */   static void drawDisabledButtonBorder(Graphics g, int x, int y, int w, int h)
/*     */   {
/* 166 */     drawButtonBorder(g, x, y, w, h, 
/* 167 */       PlasticLookAndFeel.getControl(), 
/* 168 */       MetalLookAndFeel.getControlShadow(), 
/* 169 */       LookUtils.getSlightlyBrighter(
/* 170 */       MetalLookAndFeel.getControlShadow()));
/*     */   }
/*     */ 
/*     */   public static void drawButtonBorder(Graphics g, int x, int y, int w, int h, Color backgroundColor, Color edgeColor, Color cornerColor)
/*     */   {
/* 184 */     g.translate(x, y);
/*     */ 
/* 186 */     g.setColor(edgeColor);
/* 187 */     g.fillRect(2, 0, w - 4, 1);
/* 188 */     g.fillRect(2, h - 1, w - 4, 1);
/* 189 */     g.fillRect(0, 2, 1, h - 4);
/* 190 */     g.fillRect(w - 1, 2, 1, h - 4);
/*     */ 
/* 194 */     g.setColor(cornerColor);
/* 195 */     g.fillRect(1, 0, 1, 2);
/* 196 */     g.fillRect(0, 1, 1, 1);
/*     */ 
/* 198 */     g.fillRect(w - 2, 0, 1, 2);
/* 199 */     g.fillRect(w - 1, 1, 1, 1);
/*     */ 
/* 201 */     g.fillRect(1, h - 2, 1, 2);
/* 202 */     g.fillRect(0, h - 2, 1, 1);
/*     */ 
/* 204 */     g.fillRect(w - 2, h - 2, 1, 2);
/* 205 */     g.fillRect(w - 1, h - 2, 1, 1);
/*     */ 
/* 215 */     g.translate(-x, -y);
/*     */   }
/*     */ 
/*     */   private static void drawInnerButtonDecoration(Graphics g, int x, int y, int w, int h, Color baseColor)
/*     */   {
/* 226 */     Color lightColor = translucentColor(baseColor, 90);
/* 227 */     Color mediumColor = translucentColor(baseColor, 120);
/* 228 */     Color darkColor = translucentColor(baseColor, 200);
/*     */ 
/* 230 */     g.translate(x, y);
/* 231 */     g.setColor(lightColor);
/* 232 */     g.fillRect(2, 1, w - 4, 1);
/*     */ 
/* 234 */     g.setColor(mediumColor);
/* 235 */     g.fillRect(1, 2, 1, h - 4);
/* 236 */     g.fillRect(w - 2, 2, 1, h - 4);
/* 237 */     drawRect(g, 2, 2, w - 5, h - 5);
/*     */ 
/* 239 */     g.setColor(darkColor);
/* 240 */     g.fillRect(2, h - 2, w - 4, 1);
/* 241 */     g.translate(-x, -y);
/*     */   }
/*     */ 
/*     */   static void drawRect(Graphics g, int x, int y, int w, int h)
/*     */   {
/* 249 */     g.fillRect(x, y, w + 1, 1);
/* 250 */     g.fillRect(x, y + 1, 1, h);
/* 251 */     g.fillRect(x + 1, y + h, w, 1);
/* 252 */     g.fillRect(x + w, y + 1, 1, h);
/*     */   }
/*     */ 
/*     */   private static Color translucentColor(Color baseColor, int alpha)
/*     */   {
/* 264 */     return new Color(baseColor.getRed(), 
/* 265 */       baseColor.getGreen(), 
/* 266 */       baseColor.getBlue(), 
/* 267 */       alpha);
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticXPUtils
 * JD-Core Version:    0.6.2
 */