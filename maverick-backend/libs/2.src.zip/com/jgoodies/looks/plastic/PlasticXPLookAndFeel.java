/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import com.jgoodies.looks.LookUtils;
/*     */ import com.jgoodies.looks.Options;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.UIDefaults;
/*     */ import javax.swing.plaf.ColorUIResource;
/*     */ import javax.swing.plaf.InsetsUIResource;
/*     */ 
/*     */ public class PlasticXPLookAndFeel extends Plastic3DLookAndFeel
/*     */ {
/*     */   public String getID()
/*     */   {
/*  60 */     return "JGoodies Plastic XP";
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  64 */     return "JGoodies Plastic XP";
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/*  68 */     return "The JGoodies Plastic XP Look and Feel - © 2001-2005 JGoodies Karsten Lentzsch";
/*     */   }
/*     */ 
/*     */   protected void initClassDefaults(UIDefaults table)
/*     */   {
/*  79 */     super.initClassDefaults(table);
/*     */ 
/*  81 */     String UI_CLASSNAME_PREFIX = "com.jgoodies.looks.plastic.PlasticXP";
/*  82 */     Object[] uiDefaults = { 
/*  84 */       "CheckBoxUI", UI_CLASSNAME_PREFIX + "CheckBoxUI", 
/*  87 */       "PasswordFieldUI", UI_CLASSNAME_PREFIX + "PasswordFieldUI", 
/*  90 */       "RadioButtonUI", UI_CLASSNAME_PREFIX + "RadioButtonUI", 
/*  93 */       "SpinnerUI", UI_CLASSNAME_PREFIX + "SpinnerUI" };
/*     */ 
/*  96 */     table.putDefaults(uiDefaults);
/*     */   }
/*     */ 
/*     */   protected void initComponentDefaults(UIDefaults table)
/*     */   {
/* 106 */     super.initComponentDefaults(table);
/*     */ 
/* 108 */     Object buttonBorder = PlasticXPBorders.getButtonBorder();
/* 109 */     Object checkBoxIcon = PlasticXPIconFactory.getCheckBoxIcon();
/* 110 */     Object comboBoxButtonBorder = PlasticXPBorders.getComboBoxArrowButtonBorder();
/* 111 */     Object comboBoxEditorBorder = PlasticXPBorders.getComboBoxEditorBorder();
/* 112 */     Object radioButtonIcon = PlasticXPIconFactory.getRadioButtonIcon();
/* 113 */     Object scrollPaneBorder = PlasticXPBorders.getScrollPaneBorder();
/* 114 */     Object textFieldBorder = PlasticXPBorders.getTextFieldBorder();
/* 115 */     Object toggleButtonBorder = PlasticXPBorders.getToggleButtonBorder();
/*     */ 
/* 117 */     Object defaultButtonMargin = createButtonMargin(false);
/* 118 */     Object narrowButtonMargin = createButtonMargin(true);
/*     */ 
/* 120 */     String radioCheckIconName = LookUtils.IS_LOW_RESOLUTION ? 
/* 121 */       "icons/RadioLight5x5.png" : 
/* 122 */       "icons/RadioLight7x7.png";
/*     */ 
/* 125 */     Object textInsets = new InsetsUIResource(2, 3, 2, 2);
/*     */ 
/* 127 */     Object[] defaults = { 
/* 128 */       "Button.border", buttonBorder, 
/* 129 */       "Button.margin", defaultButtonMargin, 
/* 130 */       "Button.narrowMargin", narrowButtonMargin, 
/* 131 */       "Button.borderPaintsFocus", Boolean.TRUE, 
/* 133 */       "CheckBox.icon", checkBoxIcon, 
/* 134 */       "CheckBox.check", getToggleButtonCheckColor(), 
/* 136 */       "ComboBox.arrowButtonBorder", comboBoxButtonBorder, 
/* 137 */       "ComboBox.editorBorder", comboBoxEditorBorder, 
/* 138 */       "ComboBox.borderPaintsFocus", Boolean.TRUE, 
/* 140 */       "EditorPane.margin", textInsets, 
/* 142 */       "FormattedTextField.border", textFieldBorder, 
/* 143 */       "FormattedTextField.margin", textInsets, 
/* 144 */       "PasswordField.border", textFieldBorder, 
/* 145 */       "PasswordField.margin", textInsets, 
/* 146 */       "Spinner.border", scrollPaneBorder, 
/* 147 */       "Spinner.defaultEditorInsets", textInsets, 
/* 148 */       "Spinner.arrowButtonInsets", 
/* 150 */       0, "ScrollPane.border", scrollPaneBorder, 
/* 151 */       "Table.scrollPaneBorder", scrollPaneBorder, 
/* 153 */       "RadioButton.icon", radioButtonIcon, 
/* 154 */       "RadioButton.check", getToggleButtonCheckColor(), 
/* 155 */       "RadioButton.interiorBackground", getControlHighlight(), 
/* 156 */       "RadioButton.checkIcon", makeIcon(getClass(), radioCheckIconName), 
/* 158 */       "TextArea.margin", textInsets, 
/* 159 */       "TextField.border", textFieldBorder, 
/* 160 */       "TextField.margin", textInsets, 
/* 162 */       "ToggleButton.border", toggleButtonBorder, 
/* 163 */       "ToggleButton.margin", defaultButtonMargin, 
/* 164 */       "ToggleButton.narrowMargin", narrowButtonMargin, 
/* 165 */       "ToggleButton.borderPaintsFocus", Boolean.TRUE };
/*     */ 
/* 167 */     table.putDefaults(defaults);
/*     */   }
/*     */ 
/*     */   protected static void installDefaultThemes()
/*     */   {
/*     */   }
/*     */ 
/*     */   private static Insets createButtonMargin(boolean narrow)
/*     */   {
/* 184 */     int pad = (narrow) || (Options.getUseNarrowButtons()) ? 4 : 14;
/* 185 */     return LookUtils.IS_LOW_RESOLUTION ? 
/* 186 */       new InsetsUIResource(1, pad, 1, pad) : 
/* 187 */       new InsetsUIResource(2, pad, 2, pad);
/*     */   }
/*     */ 
/*     */   private ColorUIResource getToggleButtonCheckColor()
/*     */   {
/* 192 */     return getMyCurrentTheme().getToggleButtonCheckColor();
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticXPLookAndFeel
 * JD-Core Version:    0.6.2
 */