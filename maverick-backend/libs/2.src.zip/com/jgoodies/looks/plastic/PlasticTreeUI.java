/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicTreeUI;
/*     */ 
/*     */ public final class PlasticTreeUI extends BasicTreeUI
/*     */ {
/*  78 */   private boolean linesEnabled = true;
/*     */   private PropertyChangeListener lineStyleHandler;
/*     */ 
/*     */   public static ComponentUI createUI(JComponent b)
/*     */   {
/*  83 */     return new PlasticTreeUI();
/*     */   }
/*     */ 
/*     */   public void installUI(JComponent c)
/*     */   {
/*  89 */     super.installUI(c);
/*  90 */     updateLineStyle(c.getClientProperty("JTree.lineStyle"));
/*  91 */     this.lineStyleHandler = new LineStyleHandler();
/*  92 */     c.addPropertyChangeListener(this.lineStyleHandler);
/*     */   }
/*     */ 
/*     */   public void uninstallUI(JComponent c) {
/*  96 */     c.removePropertyChangeListener(this.lineStyleHandler);
/*  97 */     super.uninstallUI(c);
/*     */   }
/*     */ 
/*     */   protected void paintVerticalLine(Graphics g, JComponent c, int x, int top, int bottom)
/*     */   {
/* 104 */     if (this.linesEnabled)
/* 105 */       drawDashedVerticalLine(g, x, top, bottom);
/*     */   }
/*     */ 
/*     */   protected void paintHorizontalLine(Graphics g, JComponent c, int y, int left, int right)
/*     */   {
/* 110 */     if (this.linesEnabled)
/* 111 */       drawDashedHorizontalLine(g, y, left, right);
/*     */   }
/*     */ 
/*     */   protected void drawCentered(Component c, Graphics graphics, Icon icon, int x, int y)
/*     */   {
/* 117 */     icon.paintIcon(
/* 118 */       c, 
/* 119 */       graphics, 
/* 120 */       x - icon.getIconWidth() / 2 - 1, 
/* 121 */       y - icon.getIconHeight() / 2);
/*     */   }
/*     */ 
/*     */   private void updateLineStyle(Object lineStyle)
/*     */   {
/* 127 */     this.linesEnabled = (!"None".equals(lineStyle));
/*     */   }
/*     */   private class LineStyleHandler implements PropertyChangeListener {
/*     */     LineStyleHandler() {
/*     */     }
/*     */     public void propertyChange(PropertyChangeEvent e) {
/* 133 */       String name = e.getPropertyName();
/* 134 */       Object value = e.getNewValue();
/* 135 */       if (name.equals("JTree.lineStyle"))
/* 136 */         PlasticTreeUI.this.updateLineStyle(value);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticTreeUI
 * JD-Core Version:    0.6.2
 */