/*     */ package com.jgoodies.looks.plastic;
/*     */ 
/*     */ import com.jgoodies.looks.BorderStyle;
/*     */ import com.jgoodies.looks.HeaderStyle;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicMenuBarUI;
/*     */ 
/*     */ public final class PlasticMenuBarUI extends BasicMenuBarUI
/*     */ {
/*     */   private PropertyChangeListener listener;
/*     */ 
/*     */   public static ComponentUI createUI(JComponent b)
/*     */   {
/*  63 */     return new PlasticMenuBarUI();
/*     */   }
/*     */ 
/*     */   protected void installDefaults()
/*     */   {
/*  70 */     super.installDefaults();
/*  71 */     installSpecialBorder();
/*     */   }
/*     */ 
/*     */   protected void installListeners()
/*     */   {
/*  76 */     super.installListeners();
/*  77 */     this.listener = createBorderStyleListener();
/*  78 */     this.menuBar.addPropertyChangeListener(this.listener);
/*     */   }
/*     */ 
/*     */   protected void uninstallListeners()
/*     */   {
/*  83 */     this.menuBar.removePropertyChangeListener(this.listener);
/*  84 */     super.uninstallListeners();
/*     */   }
/*     */ 
/*     */   private PropertyChangeListener createBorderStyleListener()
/*     */   {
/*  89 */     return new PropertyChangeListener()
/*     */     {
/*     */       public void propertyChange(PropertyChangeEvent e) {
/*  92 */         String prop = e.getPropertyName();
/*  93 */         if ((prop.equals("jgoodies.headerStyle")) || 
/*  94 */           (prop.equals("Plastic.borderStyle")))
/*  95 */           PlasticMenuBarUI.this.installSpecialBorder();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public void installSpecialBorder()
/*     */   {
/* 112 */     BorderStyle borderStyle = BorderStyle.from(this.menuBar, 
/* 113 */       "Plastic.borderStyle");
/*     */     String suffix;
/*     */     String suffix;
/* 114 */     if (borderStyle == BorderStyle.EMPTY) {
/* 115 */       suffix = "emptyBorder";
/*     */     }
/*     */     else
/*     */     {
/*     */       String suffix;
/* 116 */       if (borderStyle == BorderStyle.ETCHED) {
/* 117 */         suffix = "etchedBorder";
/*     */       }
/*     */       else
/*     */       {
/*     */         String suffix;
/* 118 */         if (borderStyle == BorderStyle.SEPARATOR) {
/* 119 */           suffix = "separatorBorder";
/*     */         } else {
/* 121 */           HeaderStyle headerStyle = HeaderStyle.from(this.menuBar);
/*     */           String suffix;
/* 122 */           if (headerStyle == HeaderStyle.BOTH)
/* 123 */             suffix = "headerBorder";
/* 124 */           else if ((headerStyle == HeaderStyle.SINGLE) && (is3D()))
/* 125 */             suffix = "etchedBorder";
/*     */           else
/* 127 */             return; 
/*     */         }
/*     */       }
/*     */     }
/* 130 */     LookAndFeel.installBorder(this.menuBar, "MenuBar." + suffix);
/*     */   }
/*     */ 
/*     */   public void update(Graphics g, JComponent c)
/*     */   {
/* 137 */     if (c.isOpaque()) {
/* 138 */       g.setColor(c.getBackground());
/* 139 */       g.fillRect(0, 0, c.getWidth(), c.getHeight());
/*     */     }
/* 141 */     if (is3D()) {
/* 142 */       PlasticUtils.addLight3DEffekt(g, new Rectangle(0, 0, c.getWidth(), c.getHeight()), true);
/*     */     }
/* 144 */     paint(g, c);
/*     */   }
/*     */ 
/*     */   private boolean is3D()
/*     */   {
/* 152 */     if (PlasticUtils.force3D(this.menuBar))
/* 153 */       return true;
/* 154 */     if (PlasticUtils.forceFlat(this.menuBar)) {
/* 155 */       return false;
/*     */     }
/*     */ 
/* 158 */     return (PlasticUtils.is3D("MenuBar.")) && 
/* 157 */       (HeaderStyle.from(this.menuBar) != null) && 
/* 158 */       (BorderStyle.from(this.menuBar, "Plastic.borderStyle") != 
/* 159 */       BorderStyle.EMPTY);
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticMenuBarUI
 * JD-Core Version:    0.6.2
 */