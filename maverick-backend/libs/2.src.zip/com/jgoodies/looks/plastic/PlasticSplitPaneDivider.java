/*    */ package com.jgoodies.looks.plastic;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.plaf.basic.BasicSplitPaneDivider;
/*    */ import javax.swing.plaf.basic.BasicSplitPaneUI;
/*    */ 
/*    */ final class PlasticSplitPaneDivider extends BasicSplitPaneDivider
/*    */ {
/*    */   PlasticSplitPaneDivider(BasicSplitPaneUI ui)
/*    */   {
/* 53 */     super(ui);
/*    */   }
/*    */ 
/*    */   public void paint(Graphics g)
/*    */   {
/* 58 */     Dimension size = getSize();
/* 59 */     Color bgColor = getBackground();
/*    */ 
/* 61 */     if (bgColor != null) {
/* 62 */       g.setColor(bgColor);
/* 63 */       g.fillRect(0, 0, size.width, size.height);
/*    */     }
/*    */ 
/* 75 */     super.paint(g);
/*    */   }
/*    */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.plastic.PlasticSplitPaneDivider
 * JD-Core Version:    0.6.2
 */