/*    */ package com.jgoodies.looks.common;
/*    */ 
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ 
/*    */ public final class ExtBasicCheckBoxMenuItemUI extends ExtBasicRadioButtonMenuItemUI
/*    */ {
/*    */   protected String getPropertyPrefix()
/*    */   {
/* 45 */     return "CheckBoxMenuItem";
/*    */   }
/*    */ 
/*    */   public static ComponentUI createUI(JComponent b) {
/* 49 */     return new ExtBasicCheckBoxMenuItemUI();
/*    */   }
/*    */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.common.ExtBasicCheckBoxMenuItemUI
 * JD-Core Version:    0.6.2
 */