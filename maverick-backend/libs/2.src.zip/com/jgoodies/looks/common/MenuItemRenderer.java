/*     */ package com.jgoodies.looks.common;
/*     */ 
/*     */ import com.jgoodies.looks.plastic.PlasticXPUtils;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.ComponentOrientation;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.KeyStroke;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.basic.BasicGraphicsUtils;
/*     */ import javax.swing.text.View;
/*     */ 
/*     */ public final class MenuItemRenderer
/*     */ {
/*     */   protected static final String HTML_KEY = "html";
/*     */   private static final String MAX_TEXT_WIDTH = "maxTextWidth";
/*     */   private static final String MAX_ACC_WIDTH = "maxAccWidth";
/*  63 */   private static final Icon NO_ICON = new NullIcon();
/*     */ 
/*  65 */   static Rectangle zeroRect = new Rectangle(0, 0, 0, 0);
/*  66 */   static Rectangle iconRect = new Rectangle();
/*  67 */   static Rectangle textRect = new Rectangle();
/*  68 */   static Rectangle acceleratorRect = new Rectangle();
/*  69 */   static Rectangle checkIconRect = new Rectangle();
/*  70 */   static Rectangle arrowIconRect = new Rectangle();
/*  71 */   static Rectangle viewRect = new Rectangle(32767, 32767);
/*  72 */   static Rectangle r = new Rectangle();
/*     */   private final JMenuItem menuItem;
/*     */   private final boolean iconBorderEnabled;
/*     */   private final Font acceleratorFont;
/*     */   private final Color selectionForeground;
/*     */   private final String acceleratorDelimiter;
/*     */   private final Icon fillerIcon;
/*     */ 
/*     */   public MenuItemRenderer(JMenuItem menuItem, boolean iconBorderEnabled, Font acceleratorFont, Color selectionForeground, Color disabledForeground, Color acceleratorForeground, Color acceleratorSelectionForeground)
/*     */   {
/*  88 */     this.menuItem = menuItem;
/*  89 */     this.iconBorderEnabled = iconBorderEnabled;
/*  90 */     this.acceleratorFont = acceleratorFont;
/*  91 */     this.selectionForeground = selectionForeground;
/*     */ 
/*  95 */     this.acceleratorDelimiter = 
/*  96 */       UIManager.getString("MenuItem.acceleratorDelimiter");
/*  97 */     this.fillerIcon = new MinimumSizedIcon();
/*     */   }
/*     */ 
/*     */   private Icon getIcon(JMenuItem aMenuItem, Icon defaultIcon)
/*     */   {
/* 104 */     Icon icon = aMenuItem.getIcon();
/* 105 */     if (icon == null) {
/* 106 */       return defaultIcon;
/*     */     }
/* 108 */     ButtonModel model = aMenuItem.getModel();
/* 109 */     if (!model.isEnabled())
/* 110 */       return model.isSelected() ? aMenuItem.getDisabledSelectedIcon() : 
/* 111 */         aMenuItem.getDisabledIcon();
/* 112 */     if ((model.isPressed()) && (model.isArmed())) {
/* 113 */       Icon pressedIcon = aMenuItem.getPressedIcon();
/* 114 */       return pressedIcon != null ? pressedIcon : icon;
/* 115 */     }if (model.isSelected()) {
/* 116 */       Icon selectedIcon = aMenuItem.getSelectedIcon();
/* 117 */       return selectedIcon != null ? selectedIcon : icon;
/*     */     }
/* 119 */     return icon;
/*     */   }
/*     */ 
/*     */   private boolean hasCustomIcon()
/*     */   {
/* 126 */     return getIcon(this.menuItem, null) != null;
/*     */   }
/*     */ 
/*     */   private Icon getWrappedIcon(Icon icon)
/*     */   {
/* 133 */     if (hideIcons())
/* 134 */       return NO_ICON;
/* 135 */     if (icon == null)
/* 136 */       return this.fillerIcon;
/* 137 */     return (this.iconBorderEnabled) && (hasCustomIcon()) ? new MinimumSizedCheckIcon(
/* 138 */       icon, this.menuItem) : new MinimumSizedIcon(icon);
/*     */   }
/*     */ 
/*     */   private void resetRects() {
/* 142 */     iconRect.setBounds(zeroRect);
/* 143 */     textRect.setBounds(zeroRect);
/* 144 */     acceleratorRect.setBounds(zeroRect);
/* 145 */     checkIconRect.setBounds(zeroRect);
/* 146 */     arrowIconRect.setBounds(zeroRect);
/* 147 */     viewRect.setBounds(0, 0, 32767, 32767);
/* 148 */     r.setBounds(zeroRect);
/*     */   }
/*     */ 
/*     */   public Dimension getPreferredMenuItemSize(JComponent c, Icon checkIcon, Icon arrowIcon, int defaultTextIconGap)
/*     */   {
/* 154 */     JMenuItem b = (JMenuItem)c;
/* 155 */     String text = b.getText();
/* 156 */     KeyStroke accelerator = b.getAccelerator();
/* 157 */     String acceleratorText = "";
/*     */ 
/* 159 */     if (accelerator != null) {
/* 160 */       int modifiers = accelerator.getModifiers();
/* 161 */       if (modifiers > 0) {
/* 162 */         acceleratorText = KeyEvent.getKeyModifiersText(modifiers);
/* 163 */         acceleratorText = acceleratorText + this.acceleratorDelimiter;
/*     */       }
/* 165 */       int keyCode = accelerator.getKeyCode();
/* 166 */       if (keyCode != 0)
/* 167 */         acceleratorText = acceleratorText + KeyEvent.getKeyText(keyCode);
/*     */       else {
/* 169 */         acceleratorText = acceleratorText + accelerator.getKeyChar();
/*     */       }
/*     */     }
/*     */ 
/* 173 */     Font font = b.getFont();
/* 174 */     FontMetrics fm = b.getFontMetrics(font);
/* 175 */     FontMetrics fmAccel = b.getFontMetrics(this.acceleratorFont);
/*     */ 
/* 177 */     resetRects();
/*     */ 
/* 179 */     Icon wrappedIcon = getWrappedIcon(getIcon(this.menuItem, checkIcon));
/* 180 */     Icon wrappedArrowIcon = getWrappedIcon(arrowIcon);
/* 181 */     Icon icon = wrappedIcon.getIconHeight() > this.fillerIcon.getIconHeight() ? wrappedIcon : 
/* 182 */       null;
/*     */ 
/* 184 */     layoutMenuItem(fm, text, fmAccel, acceleratorText, 
/* 186 */       icon, wrappedIcon, wrappedArrowIcon, 
/* 187 */       b.getVerticalAlignment(), b.getHorizontalAlignment(), 
/* 188 */       b.getVerticalTextPosition(), b.getHorizontalTextPosition(), 
/* 189 */       viewRect, iconRect, textRect, acceleratorRect, checkIconRect, 
/* 190 */       arrowIconRect, text == null ? 0 : defaultTextIconGap, 
/* 191 */       defaultTextIconGap);
/*     */ 
/* 193 */     r.setBounds(textRect);
/* 194 */     r = SwingUtilities.computeUnion(iconRect.x, iconRect.y, iconRect.width, 
/* 195 */       iconRect.height, r);
/*     */ 
/* 203 */     Container parent = this.menuItem.getParent();
/*     */ 
/* 206 */     if ((parent != null) && 
/* 207 */       ((parent instanceof JComponent)) && (
/* 208 */       (!(this.menuItem instanceof JMenu)) || 
/* 209 */       (!((JMenu)this.menuItem).isTopLevelMenu()))) {
/* 210 */       JComponent p = (JComponent)parent;
/*     */ 
/* 214 */       Integer maxTextWidth = (Integer)p.getClientProperty("maxTextWidth");
/* 215 */       Integer maxAccWidth = (Integer)p.getClientProperty("maxAccWidth");
/*     */ 
/* 217 */       int maxTextValue = maxTextWidth != null ? maxTextWidth.intValue() : 0;
/* 218 */       int maxAccValue = maxAccWidth != null ? maxAccWidth.intValue() : 0;
/*     */ 
/* 221 */       if (r.width < maxTextValue)
/* 222 */         r.width = maxTextValue;
/*     */       else {
/* 224 */         p.putClientProperty("maxTextWidth", new Integer(r.width));
/*     */       }
/*     */ 
/* 228 */       if (acceleratorRect.width > maxAccValue) {
/* 229 */         maxAccValue = acceleratorRect.width;
/* 230 */         p.putClientProperty("maxAccWidth", new Integer(
/* 231 */           acceleratorRect.width));
/*     */       }
/*     */ 
/* 235 */       r.width += maxAccValue;
/* 236 */       r.width += 10;
/*     */     }
/*     */ 
/* 239 */     if (useCheckAndArrow())
/*     */     {
/* 241 */       r.width += checkIconRect.width;
/* 242 */       r.width += defaultTextIconGap;
/*     */ 
/* 245 */       r.width += defaultTextIconGap;
/* 246 */       r.width += arrowIconRect.width;
/*     */     }
/*     */ 
/* 249 */     r.width += 2 * defaultTextIconGap;
/*     */ 
/* 251 */     Insets insets = b.getInsets();
/* 252 */     if (insets != null) {
/* 253 */       r.width += insets.left + insets.right;
/* 254 */       r.height += insets.top + insets.bottom;
/*     */     }
/*     */ 
/* 266 */     if (r.height % 2 == 1) {
/* 267 */       r.height += 1;
/*     */     }
/* 269 */     return r.getSize();
/*     */   }
/*     */ 
/*     */   public void paintMenuItem(Graphics g, JComponent c, Icon checkIcon, Icon arrowIcon, Color background, Color foreground, int defaultTextIconGap)
/*     */   {
/* 275 */     JMenuItem b = (JMenuItem)c;
/* 276 */     ButtonModel model = b.getModel();
/*     */ 
/* 279 */     int menuWidth = b.getWidth();
/* 280 */     int menuHeight = b.getHeight();
/* 281 */     Insets i = c.getInsets();
/*     */ 
/* 283 */     resetRects();
/*     */ 
/* 285 */     viewRect.setBounds(0, 0, menuWidth, menuHeight);
/*     */ 
/* 287 */     viewRect.x += i.left;
/* 288 */     viewRect.y += i.top;
/* 289 */     viewRect.width -= i.right + viewRect.x;
/* 290 */     viewRect.height -= i.bottom + viewRect.y;
/*     */ 
/* 292 */     Font holdf = g.getFont();
/* 293 */     Font f = c.getFont();
/* 294 */     g.setFont(f);
/* 295 */     FontMetrics fm = g.getFontMetrics(f);
/* 296 */     FontMetrics fmAccel = g.getFontMetrics(this.acceleratorFont);
/*     */ 
/* 299 */     KeyStroke accelerator = b.getAccelerator();
/* 300 */     String acceleratorText = "";
/* 301 */     if (accelerator != null) {
/* 302 */       int modifiers = accelerator.getModifiers();
/* 303 */       if (modifiers > 0) {
/* 304 */         acceleratorText = KeyEvent.getKeyModifiersText(modifiers);
/* 305 */         acceleratorText = acceleratorText + this.acceleratorDelimiter;
/*     */       }
/*     */ 
/* 308 */       int keyCode = accelerator.getKeyCode();
/* 309 */       if (keyCode != 0)
/* 310 */         acceleratorText = acceleratorText + KeyEvent.getKeyText(keyCode);
/*     */       else {
/* 312 */         acceleratorText = acceleratorText + accelerator.getKeyChar();
/*     */       }
/*     */     }
/*     */ 
/* 316 */     Icon wrappedIcon = getWrappedIcon(getIcon(this.menuItem, checkIcon));
/* 317 */     Icon wrappedArrowIcon = new MinimumSizedIcon(arrowIcon);
/*     */ 
/* 320 */     String text = layoutMenuItem(fm, b.getText(), fmAccel, acceleratorText, 
/* 322 */       null, wrappedIcon, wrappedArrowIcon, 
/* 323 */       b.getVerticalAlignment(), b.getHorizontalAlignment(), 
/* 324 */       b.getVerticalTextPosition(), b.getHorizontalTextPosition(), 
/* 325 */       viewRect, iconRect, textRect, acceleratorRect, checkIconRect, 
/* 326 */       arrowIconRect, b.getText() == null ? 0 : defaultTextIconGap, 
/* 327 */       defaultTextIconGap);
/*     */ 
/* 330 */     paintBackground(g, b, background);
/*     */ 
/* 333 */     Color holdc = g.getColor();
/* 334 */     if ((model.isArmed()) || (((c instanceof JMenu)) && (model.isSelected()))) {
/* 335 */       g.setColor(foreground);
/*     */     }
/* 337 */     wrappedIcon.paintIcon(c, g, checkIconRect.x, checkIconRect.y);
/* 338 */     g.setColor(holdc);
/*     */ 
/* 341 */     if (text != null) {
/* 342 */       View v = (View)c.getClientProperty("html");
/* 343 */       if (v != null)
/* 344 */         v.paint(g, textRect);
/*     */       else {
/* 346 */         paintText(g, b, textRect, text);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 351 */     if ((acceleratorText != null) && (!acceleratorText.equals("")))
/*     */     {
/* 354 */       int accOffset = 0;
/* 355 */       Container parent = this.menuItem.getParent();
/* 356 */       if ((parent != null) && ((parent instanceof JComponent))) {
/* 357 */         JComponent p = (JComponent)parent;
/* 358 */         Integer maxValueInt = (Integer)p.getClientProperty("maxAccWidth");
/* 359 */         int maxValue = maxValueInt != null ? maxValueInt.intValue() : 
/* 360 */           acceleratorRect.width;
/*     */ 
/* 364 */         accOffset = maxValue - acceleratorRect.width;
/*     */       }
/*     */ 
/* 367 */       g.setFont(this.acceleratorFont);
/* 368 */       setForegroundTextColor(g, b);
/* 369 */       BasicGraphicsUtils.drawString(g, acceleratorText, 0, 
/* 370 */         acceleratorRect.x - accOffset, acceleratorRect.y + 
/* 371 */         fmAccel.getAscent());
/*     */     }
/*     */ 
/* 377 */     if (arrowIcon != null) {
/* 378 */       if ((model.isArmed()) || (((c instanceof JMenu)) && (model.isSelected())))
/* 379 */         g.setColor(foreground);
/* 380 */       if (useCheckAndArrow())
/* 381 */         wrappedArrowIcon.paintIcon(c, g, arrowIconRect.x, arrowIconRect.y);
/*     */     }
/* 383 */     g.setColor(holdc);
/* 384 */     g.setFont(holdf);
/*     */   }
/*     */ 
/*     */   private String layoutMenuItem(FontMetrics fm, String text, FontMetrics fmAccel, String acceleratorText, Icon icon, Icon checkIcon, Icon arrowIcon, int verticalAlignment, int horizontalAlignment, int verticalTextPosition, int horizontalTextPosition, Rectangle viewRectangle, Rectangle iconRectangle, Rectangle textRectangle, Rectangle acceleratorRectangle, Rectangle checkIconRectangle, Rectangle arrowIconRectangle, int textIconGap, int menuItemGap)
/*     */   {
/* 402 */     SwingUtilities.layoutCompoundLabel(this.menuItem, fm, text, icon, 
/* 403 */       verticalAlignment, horizontalAlignment, verticalTextPosition, 
/* 404 */       horizontalTextPosition, viewRectangle, iconRectangle, 
/* 405 */       textRectangle, textIconGap);
/*     */ 
/* 412 */     if ((acceleratorText == null) || (acceleratorText.equals(""))) {
/* 413 */       acceleratorRectangle.width = (acceleratorRectangle.height = 0);
/* 414 */       acceleratorText = "";
/*     */     } else {
/* 416 */       acceleratorRectangle.width = SwingUtilities.computeStringWidth(
/* 417 */         fmAccel, acceleratorText);
/* 418 */       acceleratorRectangle.height = fmAccel.getHeight();
/*     */     }
/*     */ 
/* 421 */     boolean useCheckAndArrow = useCheckAndArrow();
/*     */ 
/* 425 */     if (useCheckAndArrow) {
/* 426 */       if (checkIcon != null) {
/* 427 */         checkIconRectangle.width = checkIcon.getIconWidth();
/* 428 */         checkIconRectangle.height = checkIcon.getIconHeight();
/*     */       } else {
/* 430 */         checkIconRectangle.width = (checkIconRectangle.height = 0);
/*     */       }
/*     */ 
/* 435 */       if (arrowIcon != null) {
/* 436 */         arrowIconRectangle.width = arrowIcon.getIconWidth();
/* 437 */         arrowIconRectangle.height = arrowIcon.getIconHeight();
/*     */       } else {
/* 439 */         arrowIconRectangle.width = (arrowIconRectangle.height = 0);
/*     */       }
/*     */     }
/*     */ 
/* 443 */     Rectangle labelRect = iconRectangle.union(textRectangle);
/* 444 */     if (isLeftToRight(this.menuItem)) {
/* 445 */       textRectangle.x += menuItemGap;
/* 446 */       iconRectangle.x += menuItemGap;
/*     */ 
/* 449 */       acceleratorRectangle.x = 
/* 451 */         (viewRectangle.x + viewRectangle.width - 
/* 450 */         arrowIconRectangle.width - menuItemGap - 
/* 451 */         acceleratorRectangle.width);
/*     */ 
/* 454 */       if (useCheckAndArrow) {
/* 455 */         checkIconRectangle.x = viewRectangle.x;
/*     */ 
/* 458 */         textRectangle.x += menuItemGap + checkIconRectangle.width;
/* 459 */         iconRectangle.x += menuItemGap + checkIconRectangle.width;
/* 460 */         arrowIconRectangle.x = 
/* 461 */           (viewRectangle.x + viewRectangle.width - 
/* 461 */           menuItemGap - arrowIconRectangle.width);
/*     */       }
/*     */     } else {
/* 464 */       textRectangle.x -= menuItemGap;
/* 465 */       iconRectangle.x -= menuItemGap;
/*     */ 
/* 468 */       acceleratorRectangle.x = 
/* 469 */         (viewRectangle.x + arrowIconRectangle.width + 
/* 469 */         menuItemGap);
/*     */ 
/* 472 */       if (useCheckAndArrow)
/*     */       {
/* 474 */         checkIconRectangle.x = 
/* 475 */           (viewRectangle.x + viewRectangle.width - 
/* 475 */           checkIconRectangle.width);
/* 476 */         textRectangle.x -= menuItemGap + checkIconRectangle.width;
/* 477 */         iconRectangle.x -= menuItemGap + checkIconRectangle.width;
/* 478 */         viewRectangle.x += menuItemGap;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 484 */     acceleratorRectangle.y = 
/* 485 */       (labelRect.y + labelRect.height / 2 - 
/* 485 */       acceleratorRectangle.height / 2);
/* 486 */     if (useCheckAndArrow) {
/* 487 */       arrowIconRectangle.y = 
/* 488 */         (labelRect.y + labelRect.height / 2 - 
/* 488 */         arrowIconRectangle.height / 2);
/* 489 */       checkIconRectangle.y = 
/* 490 */         (labelRect.y + labelRect.height / 2 - 
/* 490 */         checkIconRectangle.height / 2);
/*     */     }
/*     */ 
/* 500 */     return text;
/*     */   }
/*     */ 
/*     */   private boolean useCheckAndArrow()
/*     */   {
/* 508 */     boolean isTopLevelMenu = ((this.menuItem instanceof JMenu)) && 
/* 509 */       (((JMenu)this.menuItem).isTopLevelMenu());
/* 510 */     return !isTopLevelMenu;
/*     */   }
/*     */ 
/*     */   private boolean isLeftToRight(Component c) {
/* 514 */     return c.getComponentOrientation().isLeftToRight();
/*     */   }
/*     */ 
/*     */   public void paintBackground(Graphics g, JMenuItem aMenuItem, Color bgColor)
/*     */   {
/* 532 */     ButtonModel model = aMenuItem.getModel();
/*     */ 
/* 534 */     if (aMenuItem.isOpaque()) {
/* 535 */       int menuWidth = aMenuItem.getWidth();
/* 536 */       int menuHeight = aMenuItem.getHeight();
/* 537 */       Color c = (model.isArmed()) || (
/* 538 */         ((aMenuItem instanceof JMenu)) && (model.isSelected())) ? bgColor : 
/* 539 */         aMenuItem.getBackground();
/* 540 */       Color oldColor = g.getColor();
/* 541 */       g.setColor(c);
/* 542 */       g.fillRect(0, 0, menuWidth, menuHeight);
/* 543 */       g.setColor(oldColor);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void paintText(Graphics g, JMenuItem aMenuItem, Rectangle textRectangle, String text)
/*     */   {
/* 562 */     FontMetrics fm = g.getFontMetrics();
/* 563 */     int mnemIndex = aMenuItem.getDisplayedMnemonicIndex();
/* 564 */     setForegroundTextColor(g, aMenuItem);
/* 565 */     BasicGraphicsUtils.drawStringUnderlineCharAt(g, text, mnemIndex, 
/* 566 */       textRectangle.x, textRectangle.y + fm.getAscent());
/*     */   }
/*     */ 
/*     */   private void setForegroundTextColor(Graphics g, JMenuItem aMenuItem) {
/* 570 */     ButtonModel model = aMenuItem.getModel();
/* 571 */     Color col = null;
/* 572 */     if (!model.isEnabled()) {
/* 573 */       col = aMenuItem.getBackground();
/* 574 */       if (col.equals(PlasticXPUtils.MB_BGCOL)) {
/* 575 */         col = PlasticXPUtils.MB_DISCOL;
/*     */       }
/* 577 */       else if ((UIManager.get("MenuItem.disabledForeground") instanceof Color))
/* 578 */         col = UIManager.getColor("MenuItem.disabledForeground");
/*     */       else {
/* 580 */         col = col.brighter();
/*     */       }
/*     */ 
/*     */     }
/* 584 */     else if ((model.isArmed()) || (((aMenuItem instanceof JMenu)) && (model.isSelected()))) {
/* 585 */       col = this.selectionForeground;
/*     */     }
/*     */ 
/* 588 */     if (col != null) g.setColor(col);
/*     */   }
/*     */ 
/*     */   private boolean hideIcons()
/*     */   {
/* 599 */     Component parent = this.menuItem.getParent();
/* 600 */     if (!(parent instanceof JPopupMenu)) {
/* 601 */       return false;
/*     */     }
/* 603 */     JPopupMenu popupMenu = (JPopupMenu)parent;
/* 604 */     Object value = popupMenu.getClientProperty("jgoodies.noIcons");
/* 605 */     if (value == null) {
/* 606 */       Component invoker = popupMenu.getInvoker();
/* 607 */       if ((invoker != null) && ((invoker instanceof JMenu)))
/* 608 */         value = ((JMenu)invoker).getClientProperty("jgoodies.noIcons");
/*     */     }
/* 610 */     return Boolean.TRUE.equals(value);
/*     */   }
/*     */ 
/*     */   private static class NullIcon implements Icon
/*     */   {
/*     */     public int getIconWidth() {
/* 616 */       return 0;
/*     */     }
/*     */ 
/*     */     public int getIconHeight() {
/* 620 */       return 0;
/*     */     }
/*     */ 
/*     */     public void paintIcon(Component c, Graphics g, int x, int y)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.common.MenuItemRenderer
 * JD-Core Version:    0.6.2
 */