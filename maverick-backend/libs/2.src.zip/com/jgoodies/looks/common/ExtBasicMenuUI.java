/*     */ package com.jgoodies.looks.common;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicMenuUI;
/*     */ 
/*     */ public class ExtBasicMenuUI extends BasicMenuUI
/*     */ {
/*     */   private static final String MENU_PROPERTY_PREFIX = "Menu";
/*     */   private static final String SUBMENU_PROPERTY_PREFIX = "MenuItem";
/*  64 */   private String propertyPrefix = "Menu";
/*     */   private MenuItemRenderer renderer;
/*     */   private MouseListener mouseListener;
/*     */ 
/*     */   public static ComponentUI createUI(JComponent b)
/*     */   {
/*  71 */     return new ExtBasicMenuUI();
/*     */   }
/*     */ 
/*     */   protected void installDefaults()
/*     */   {
/*  78 */     super.installDefaults();
/*  79 */     if ((this.arrowIcon == null) || ((this.arrowIcon instanceof UIResource))) {
/*  80 */       this.arrowIcon = UIManager.getIcon("Menu.arrowIcon");
/*     */     }
/*  82 */     this.renderer = 
/*  83 */       new MenuItemRenderer(
/*  84 */       this.menuItem, 
/*  85 */       false, 
/*  86 */       this.acceleratorFont, 
/*  87 */       this.selectionForeground, 
/*  88 */       this.disabledForeground, 
/*  89 */       this.acceleratorForeground, 
/*  90 */       this.acceleratorSelectionForeground);
/*  91 */     Integer gap = 
/*  92 */       (Integer)UIManager.get(getPropertyPrefix() + ".textIconGap");
/*  93 */     this.defaultTextIconGap = (gap != null ? gap.intValue() : 2);
/*     */   }
/*     */ 
/*     */   protected void uninstallDefaults() {
/*  97 */     super.uninstallDefaults();
/*  98 */     this.renderer = null;
/*     */   }
/*     */ 
/*     */   protected String getPropertyPrefix() {
/* 102 */     return this.propertyPrefix;
/*     */   }
/*     */ 
/*     */   protected Dimension getPreferredMenuItemSize(JComponent c, Icon aCheckIcon, Icon anArrowIcon, int textIconGap)
/*     */   {
/* 111 */     if (isSubMenu(this.menuItem)) {
/* 112 */       ensureSubMenuInstalled();
/* 113 */       return this.renderer.getPreferredMenuItemSize(
/* 114 */         c, 
/* 115 */         aCheckIcon, 
/* 116 */         anArrowIcon, 
/* 117 */         textIconGap);
/*     */     }
/* 119 */     return super.getPreferredMenuItemSize(
/* 120 */       c, 
/* 121 */       aCheckIcon, 
/* 122 */       anArrowIcon, 
/* 123 */       textIconGap);
/*     */   }
/*     */ 
/*     */   protected void paintMenuItem(Graphics g, JComponent c, Icon aCheckIcon, Icon anArrowIcon, Color background, Color foreground, int textIconGap)
/*     */   {
/* 134 */     if (isSubMenu(this.menuItem))
/* 135 */       this.renderer.paintMenuItem(
/* 136 */         g, 
/* 137 */         c, 
/* 138 */         aCheckIcon, 
/* 139 */         anArrowIcon, 
/* 140 */         background, 
/* 141 */         foreground, 
/* 142 */         textIconGap);
/*     */     else
/* 144 */       super.paintMenuItem(
/* 145 */         g, 
/* 146 */         c, 
/* 147 */         aCheckIcon, 
/* 148 */         anArrowIcon, 
/* 149 */         background, 
/* 150 */         foreground, 
/* 151 */         textIconGap);
/*     */   }
/*     */ 
/*     */   private void ensureSubMenuInstalled()
/*     */   {
/* 160 */     if (this.propertyPrefix.equals("MenuItem")) {
/* 161 */       return;
/*     */     }
/*     */ 
/* 164 */     uninstallRolloverListener();
/* 165 */     uninstallDefaults();
/* 166 */     this.propertyPrefix = "MenuItem";
/* 167 */     installDefaults();
/*     */   }
/*     */ 
/*     */   protected void installListeners()
/*     */   {
/* 173 */     super.installListeners();
/* 174 */     this.mouseListener = createRolloverListener();
/* 175 */     this.menuItem.addMouseListener(this.mouseListener);
/*     */   }
/*     */ 
/*     */   protected void uninstallListeners() {
/* 179 */     super.uninstallListeners();
/* 180 */     uninstallRolloverListener();
/*     */   }
/*     */ 
/*     */   private void uninstallRolloverListener() {
/* 184 */     if (this.mouseListener != null) {
/* 185 */       this.menuItem.removeMouseListener(this.mouseListener);
/* 186 */       this.mouseListener = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected MouseListener createRolloverListener() {
/* 191 */     return new MouseAdapter() {
/*     */       public void mouseEntered(MouseEvent e) {
/* 193 */         AbstractButton b = (AbstractButton)e.getSource();
/* 194 */         b.getModel().setRollover(true);
/*     */       }
/*     */       public void mouseExited(MouseEvent e) {
/* 197 */         AbstractButton b = (AbstractButton)e.getSource();
/* 198 */         b.getModel().setRollover(false);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   private boolean isSubMenu(JMenuItem aMenuItem)
/*     */   {
/* 207 */     return !((JMenu)aMenuItem).isTopLevelMenu();
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.common.ExtBasicMenuUI
 * JD-Core Version:    0.6.2
 */