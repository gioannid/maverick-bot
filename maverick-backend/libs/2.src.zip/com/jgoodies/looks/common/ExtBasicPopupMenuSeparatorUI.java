/*     */ package com.jgoodies.looks.common;
/*     */ 
/*     */ import com.jgoodies.looks.plastic.PlasticXPUtils;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JSeparator;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicPopupMenuSeparatorUI;
/*     */ 
/*     */ public final class ExtBasicPopupMenuSeparatorUI extends BasicPopupMenuSeparatorUI
/*     */ {
/*     */   private static final int SEPARATOR_HEIGHT = 2;
/*     */   private Insets insets;
/*     */   private static ComponentUI popupMenuSeparatorUI;
/*     */ 
/*     */   public static ComponentUI createUI(JComponent b)
/*     */   {
/*  61 */     if (popupMenuSeparatorUI == null) {
/*  62 */       popupMenuSeparatorUI = new ExtBasicPopupMenuSeparatorUI();
/*     */     }
/*  64 */     return popupMenuSeparatorUI;
/*     */   }
/*     */ 
/*     */   protected void installDefaults(JSeparator s)
/*     */   {
/*  69 */     super.installDefaults(s);
/*  70 */     this.insets = UIManager.getInsets("PopupMenuSeparator.margin");
/*     */   }
/*     */ 
/*     */   public void paint(Graphics g, JComponent c)
/*     */   {
/*  75 */     Dimension s = c.getSize();
/*     */ 
/*  77 */     int topInset = this.insets.top;
/*  78 */     int leftInset = this.insets.left;
/*  79 */     int rightInset = this.insets.right;
/*     */ 
/*  82 */     if (!c.getBackground().equals(PlasticXPUtils.BGCOL))
/*     */     {
/*  84 */       g.setColor(UIManager.getColor("MenuItem.background"));
/*  85 */       g.fillRect(0, 0, s.width, s.height);
/*     */     }
/*     */ 
/*  95 */     g.translate(0, topInset);
/*  96 */     g.setColor(c.getForeground());
/*  97 */     g.drawLine(leftInset, 0, s.width - rightInset, 0);
/*     */ 
/*  99 */     g.setColor(c.getBackground());
/* 100 */     g.drawLine(leftInset, 1, s.width - rightInset, 1);
/* 101 */     g.translate(0, -topInset);
/*     */   }
/*     */ 
/*     */   public Dimension getPreferredSize(JComponent c)
/*     */   {
/* 106 */     return new Dimension(0, this.insets.top + 2 + this.insets.bottom);
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.common.ExtBasicPopupMenuSeparatorUI
 * JD-Core Version:    0.6.2
 */