/*     */ package com.jgoodies.looks.common;
/*     */ 
/*     */ import java.awt.AWTException;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Panel;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Robot;
/*     */ import java.awt.Window;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JApplet;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JRootPane;
/*     */ import javax.swing.JWindow;
/*     */ import javax.swing.Popup;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.border.Border;
/*     */ 
/*     */ public final class ShadowPopup extends Popup
/*     */ {
/*     */   private static final int MAX_CACHE_SIZE = 5;
/*     */   private static List cache;
/*  68 */   private static final Border SHADOW_BORDER = ShadowPopupBorder.getInstance();
/*     */   private static final int SHADOW_SIZE = 5;
/*  78 */   private static boolean canSnapshot = true;
/*     */   private Component owner;
/*     */   private Component contents;
/*     */   private int x;
/*     */   private int y;
/*     */   private Popup popup;
/*     */   private Border oldBorder;
/*     */   private boolean oldOpaque;
/*     */   private Container heavyWeightContainer;
/* 239 */   private static final Point point = new Point();
/* 240 */   private static final Rectangle rect = new Rectangle();
/*     */ 
/*     */   static Popup getInstance(Component owner, Component contents, int x, int y, Popup delegate)
/*     */   {
/*     */     ShadowPopup result;
/* 123 */     synchronized (ShadowPopup.class) {
/* 124 */       if (cache == null)
/* 125 */         cache = new ArrayList(5);
/*     */       ShadowPopup result;
/* 127 */       if (cache.size() > 0)
/* 128 */         result = (ShadowPopup)cache.remove(0);
/*     */       else {
/* 130 */         result = new ShadowPopup();
/*     */       }
/*     */     }
/* 133 */     result.reset(owner, contents, x, y, delegate);
/* 134 */     return result;
/*     */   }
/*     */ 
/*     */   private static void recycle(ShadowPopup popup)
/*     */   {
/* 141 */     synchronized (ShadowPopup.class) {
/* 142 */       if (cache.size() < 5)
/* 143 */         cache.add(popup);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean canSnapshot()
/*     */   {
/* 149 */     return canSnapshot;
/*     */   }
/*     */ 
/*     */   public void hide()
/*     */   {
/* 154 */     JComponent parent = (JComponent)this.contents.getParent();
/* 155 */     this.popup.hide();
/* 156 */     if (parent.getBorder() == SHADOW_BORDER) {
/* 157 */       parent.setBorder(this.oldBorder);
/* 158 */       parent.setOpaque(this.oldOpaque);
/* 159 */       this.oldBorder = null;
/* 160 */       if (this.heavyWeightContainer != null) {
/* 161 */         parent.putClientProperty("jgoodies.hShadowBg", null);
/* 162 */         parent.putClientProperty("jgoodies.vShadowBg", null);
/* 163 */         this.heavyWeightContainer = null;
/*     */       }
/*     */     }
/* 166 */     this.owner = null;
/* 167 */     this.contents = null;
/* 168 */     this.popup = null;
/* 169 */     recycle(this);
/*     */   }
/*     */ 
/*     */   public void show()
/*     */   {
/* 174 */     if (this.heavyWeightContainer != null) {
/* 175 */       snapshot();
/*     */     }
/* 177 */     this.popup.show();
/*     */   }
/*     */ 
/*     */   private void reset(Component theOwner, Component theContents, int newX, int newY, Popup thePopup)
/*     */   {
/* 191 */     this.owner = theOwner;
/* 192 */     this.contents = theContents;
/* 193 */     this.popup = thePopup;
/* 194 */     this.x = newX;
/* 195 */     this.y = newY;
/* 196 */     if ((theOwner instanceof JComboBox)) {
/* 197 */       return;
/*     */     }
/* 199 */     Container mediumWeightContainer = null;
/* 200 */     for (Container p = theContents.getParent(); p != null; p = p.getParent()) {
/* 201 */       if ((p instanceof JWindow))
/*     */       {
/* 203 */         p.setBackground(theContents.getBackground());
/* 204 */         this.heavyWeightContainer = p;
/* 205 */         break;
/* 206 */       }if ((p instanceof Panel))
/*     */       {
/* 210 */         Color bg = p.getBackground();
/* 211 */         int rgba = theContents.getBackground().getRGB() & 0xFFFFFF;
/* 212 */         if ((bg == null) || (bg.getRGB() != rgba)) {
/* 213 */           p.setBackground(new Color(rgba, true));
/*     */         }
/* 215 */         mediumWeightContainer = p;
/* 216 */         break;
/*     */       }
/*     */     }
/* 219 */     JComponent parent = (JComponent)theContents.getParent();
/* 220 */     this.oldOpaque = parent.isOpaque();
/* 221 */     this.oldBorder = parent.getBorder();
/* 222 */     parent.setOpaque(false);
/* 223 */     parent.setBorder(SHADOW_BORDER);
/*     */ 
/* 225 */     if (mediumWeightContainer != null)
/* 226 */       mediumWeightContainer.setSize(
/* 227 */         mediumWeightContainer.getPreferredSize());
/*     */     else
/* 229 */       parent.setSize(parent.getPreferredSize());
/*     */   }
/*     */ 
/*     */   private void snapshot()
/*     */   {
/*     */     try
/*     */     {
/* 258 */       Robot robot = new Robot();
/*     */ 
/* 260 */       Dimension size = this.heavyWeightContainer.getPreferredSize();
/* 261 */       int width = size.width;
/* 262 */       int height = size.height;
/*     */ 
/* 264 */       rect.setBounds(this.x, this.y + height - 5, width, 5);
/* 265 */       BufferedImage hShadowBg = robot.createScreenCapture(rect);
/*     */ 
/* 267 */       rect.setBounds(this.x + width - 5, this.y, 5, 
/* 268 */         height - 5);
/* 269 */       BufferedImage vShadowBg = robot.createScreenCapture(rect);
/*     */ 
/* 271 */       JComponent parent = (JComponent)this.contents.getParent();
/* 272 */       parent.putClientProperty("jgoodies.hShadowBg", hShadowBg);
/* 273 */       parent.putClientProperty("jgoodies.vShadowBg", vShadowBg);
/*     */ 
/* 275 */       JComponent layeredPane = getLayeredPane();
/* 276 */       if (layeredPane == null)
/*     */       {
/* 278 */         return;
/*     */       }
/*     */ 
/* 281 */       int layeredPaneWidth = layeredPane.getWidth();
/* 282 */       int layeredPaneHeight = layeredPane.getHeight();
/*     */ 
/* 284 */       point.x = this.x;
/* 285 */       point.y = this.y;
/* 286 */       SwingUtilities.convertPointFromScreen(point, layeredPane);
/*     */ 
/* 289 */       rect.x = point.x;
/* 290 */       rect.y = (point.y + height - 5);
/* 291 */       rect.width = width;
/* 292 */       rect.height = 5;
/*     */ 
/* 294 */       if (rect.x + rect.width > layeredPaneWidth) {
/* 295 */         rect.width = (layeredPaneWidth - rect.x);
/*     */       }
/* 297 */       if (rect.y + rect.height > layeredPaneHeight) {
/* 298 */         rect.height = (layeredPaneHeight - rect.y);
/*     */       }
/* 300 */       if (!rect.isEmpty()) {
/* 301 */         Graphics g = hShadowBg.createGraphics();
/* 302 */         g.translate(-rect.x, -rect.y);
/* 303 */         g.setClip(rect);
/* 304 */         boolean doubleBuffered = layeredPane.isDoubleBuffered();
/* 305 */         layeredPane.setDoubleBuffered(false);
/* 306 */         layeredPane.paint(g);
/* 307 */         layeredPane.setDoubleBuffered(doubleBuffered);
/* 308 */         g.dispose();
/*     */       }
/*     */ 
/* 312 */       rect.x = (point.x + width - 5);
/* 313 */       rect.y = point.y;
/* 314 */       rect.width = 5;
/* 315 */       rect.height = (height - 5);
/*     */ 
/* 317 */       if (rect.x + rect.width > layeredPaneWidth) {
/* 318 */         rect.width = (layeredPaneWidth - rect.x);
/*     */       }
/* 320 */       if (rect.y + rect.height > layeredPaneHeight) {
/* 321 */         rect.height = (layeredPaneHeight - rect.y);
/*     */       }
/* 323 */       if (!rect.isEmpty()) {
/* 324 */         Graphics g = vShadowBg.createGraphics();
/* 325 */         g.translate(-rect.x, -rect.y);
/* 326 */         g.setClip(rect);
/* 327 */         boolean doubleBuffered = layeredPane.isDoubleBuffered();
/* 328 */         layeredPane.setDoubleBuffered(false);
/* 329 */         layeredPane.paint(g);
/* 330 */         layeredPane.setDoubleBuffered(doubleBuffered);
/* 331 */         g.dispose();
/*     */       }
/*     */     } catch (AWTException e) {
/* 334 */       canSnapshot = false;
/*     */     } catch (SecurityException e) {
/* 336 */       canSnapshot = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   private JComponent getLayeredPane()
/*     */   {
/* 345 */     Container parent = null;
/* 346 */     if (this.owner != null) {
/* 347 */       parent = (this.owner instanceof Container) ? 
/* 348 */         (Container)this.owner : 
/* 349 */         this.owner.getParent();
/*     */     }
/*     */ 
/* 352 */     for (Container p = parent; p != null; p = p.getParent()) {
/* 353 */       if ((p instanceof JRootPane)) {
/* 354 */         if (!(p.getParent() instanceof JInternalFrame))
/*     */         {
/* 357 */           parent = ((JRootPane)p).getLayeredPane();
/*     */         }
/*     */       }
/* 360 */       else if ((p instanceof Window)) {
/* 361 */         if (parent == null)
/* 362 */           parent = p;
/*     */       }
/*     */       else {
/* 365 */         if ((p instanceof JApplet))
/*     */         {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 372 */     return (JComponent)parent;
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.common.ShadowPopup
 * JD-Core Version:    0.6.2
 */