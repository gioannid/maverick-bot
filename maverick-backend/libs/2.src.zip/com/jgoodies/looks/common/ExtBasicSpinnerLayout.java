/*     */ package com.jgoodies.looks.common;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.ComponentOrientation;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ import javax.swing.UIManager;
/*     */ 
/*     */ public final class ExtBasicSpinnerLayout
/*     */   implements LayoutManager
/*     */ {
/*  56 */   private static final Dimension ZERO_SIZE = new Dimension(0, 0);
/*     */ 
/*  59 */   private Component nextButton = null;
/*  60 */   private Component previousButton = null;
/*  61 */   private Component editor = null;
/*     */ 
/*     */   public void addLayoutComponent(String name, Component c)
/*     */   {
/*  65 */     if ("Next".equals(name))
/*  66 */       this.nextButton = c;
/*  67 */     else if ("Previous".equals(name))
/*  68 */       this.previousButton = c;
/*  69 */     else if ("Editor".equals(name))
/*  70 */       this.editor = c;
/*     */   }
/*     */ 
/*     */   public void removeLayoutComponent(Component c)
/*     */   {
/*  76 */     if (c == this.nextButton)
/*  77 */       c = null;
/*  78 */     else if (c == this.previousButton)
/*  79 */       this.previousButton = null;
/*  80 */     else if (c == this.editor)
/*  81 */       this.editor = null;
/*     */   }
/*     */ 
/*     */   private Dimension preferredSize(Component c)
/*     */   {
/*  87 */     return c == null ? ZERO_SIZE : c.getPreferredSize();
/*     */   }
/*     */ 
/*     */   public Dimension preferredLayoutSize(Container parent)
/*     */   {
/*  92 */     Dimension nextD = preferredSize(this.nextButton);
/*  93 */     Dimension previousD = preferredSize(this.previousButton);
/*  94 */     Dimension editorD = preferredSize(this.editor);
/*     */ 
/*  96 */     Dimension size = new Dimension(editorD.width, editorD.height);
/*  97 */     size.width += Math.max(nextD.width, previousD.width);
/*  98 */     Insets insets = parent.getInsets();
/*  99 */     size.width += insets.left + insets.right;
/* 100 */     size.height += insets.top + insets.bottom;
/* 101 */     return size;
/*     */   }
/*     */ 
/*     */   public Dimension minimumLayoutSize(Container parent)
/*     */   {
/* 106 */     return preferredLayoutSize(parent);
/*     */   }
/*     */ 
/*     */   private void setBounds(Component c, int x, int y, int width, int height)
/*     */   {
/* 111 */     if (c != null)
/* 112 */       c.setBounds(x, y, width, height);
/*     */   }
/*     */ 
/*     */   public void layoutContainer(Container parent)
/*     */   {
/* 118 */     int width = parent.getWidth();
/* 119 */     int height = parent.getHeight();
/*     */ 
/* 121 */     Insets insets = parent.getInsets();
/* 122 */     Dimension nextD = preferredSize(this.nextButton);
/* 123 */     Dimension previousD = preferredSize(this.previousButton);
/* 124 */     int buttonsWidth = Math.max(nextD.width, previousD.width);
/* 125 */     int editorHeight = height - (insets.top + insets.bottom);
/*     */ 
/* 132 */     Insets buttonInsets = 
/* 133 */       UIManager.getInsets("Spinner.arrowButtonInsets");
/* 134 */     if (buttonInsets == null)
/* 135 */       buttonInsets = insets;
/*     */     int buttonsX;
/*     */     int buttonsX;
/*     */     int editorX;
/*     */     int editorWidth;
/* 142 */     if (parent.getComponentOrientation().isLeftToRight()) {
/* 143 */       int editorX = insets.left;
/* 144 */       int editorWidth = width - insets.left - buttonsWidth - 
/* 145 */         buttonInsets.right;
/* 146 */       buttonsX = width - buttonsWidth - buttonInsets.right;
/*     */     } else {
/* 148 */       buttonsX = buttonInsets.left;
/* 149 */       editorX = buttonsX + buttonsWidth;
/* 150 */       editorWidth = width - buttonInsets.left - buttonsWidth - 
/* 151 */         insets.right;
/*     */     }
/*     */ 
/* 154 */     int nextY = buttonInsets.top;
/* 155 */     int nextHeight = height / 2 + height % 2 - nextY;
/* 156 */     int previousY = buttonInsets.top + nextHeight;
/* 157 */     int previousHeight = height - previousY - buttonInsets.bottom;
/*     */ 
/* 159 */     setBounds(this.editor, editorX, insets.top, editorWidth, editorHeight);
/* 160 */     setBounds(this.nextButton, buttonsX, nextY, buttonsWidth, nextHeight);
/* 161 */     setBounds(this.previousButton, buttonsX, previousY, buttonsWidth, 
/* 162 */       previousHeight);
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.common.ExtBasicSpinnerLayout
 * JD-Core Version:    0.6.2
 */