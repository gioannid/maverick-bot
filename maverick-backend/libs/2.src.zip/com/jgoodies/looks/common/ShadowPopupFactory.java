/*     */ package com.jgoodies.looks.common;
/*     */ 
/*     */ import com.jgoodies.looks.Options;
/*     */ import java.awt.Component;
/*     */ import javax.swing.Popup;
/*     */ import javax.swing.PopupFactory;
/*     */ 
/*     */ public final class ShadowPopupFactory extends PopupFactory
/*     */ {
/*     */   static final String PROP_HORIZONTAL_BACKGROUND = "jgoodies.hShadowBg";
/*     */   static final String PROP_VERTICAL_BACKGROUND = "jgoodies.vShadowBg";
/*     */   private final PopupFactory storedFactory;
/*     */ 
/*     */   private ShadowPopupFactory(PopupFactory storedFactory)
/*     */   {
/*  95 */     this.storedFactory = storedFactory;
/*     */   }
/*     */ 
/*     */   public static void install()
/*     */   {
/* 109 */     PopupFactory factory = PopupFactory.getSharedInstance();
/* 110 */     if ((factory instanceof ShadowPopupFactory)) {
/* 111 */       return;
/*     */     }
/* 113 */     PopupFactory.setSharedInstance(new ShadowPopupFactory(factory));
/*     */   }
/*     */ 
/*     */   public static void uninstall()
/*     */   {
/* 123 */     PopupFactory factory = PopupFactory.getSharedInstance();
/* 124 */     if (!(factory instanceof ShadowPopupFactory)) {
/* 125 */       return;
/*     */     }
/* 127 */     PopupFactory stored = ((ShadowPopupFactory)factory).storedFactory;
/* 128 */     PopupFactory.setSharedInstance(stored);
/*     */   }
/*     */ 
/*     */   public Popup getPopup(Component owner, Component contents, int x, int y)
/*     */     throws IllegalArgumentException
/*     */   {
/* 135 */     Popup popup = this.storedFactory.getPopup(owner, contents, x, y);
/* 136 */     return Options.isPopupDropShadowActive() ? 
/* 137 */       ShadowPopup.getInstance(owner, contents, x, y, popup) : 
/* 138 */       popup;
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.common.ShadowPopupFactory
 * JD-Core Version:    0.6.2
 */