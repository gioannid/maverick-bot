/*     */ package com.jgoodies.looks.common;
/*     */ 
/*     */ import java.awt.AWTEvent;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.FocusTraversalPolicy;
/*     */ import java.awt.KeyboardFocusManager;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.text.AttributedCharacterIterator;
/*     */ import java.text.DateFormat.Field;
/*     */ import java.text.Format;
/*     */ import java.text.Format.Field;
/*     */ import java.text.ParseException;
/*     */ import java.util.Map;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.JFormattedTextField.AbstractFormatter;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.JSpinner.DateEditor;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.SpinnerDateModel;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.Timer;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.InternationalFormatter;
/*     */ 
/*     */ public final class ExtBasicArrowButtonHandler extends AbstractAction
/*     */   implements MouseListener
/*     */ {
/*     */   private final Timer autoRepeatTimer;
/*     */   private final boolean isNext;
/*  79 */   private JSpinner spinner = null;
/*     */ 
/*     */   public ExtBasicArrowButtonHandler(String name, boolean isNext)
/*     */   {
/*  83 */     super(name);
/*  84 */     this.isNext = isNext;
/*  85 */     this.autoRepeatTimer = new Timer(60, this);
/*  86 */     this.autoRepeatTimer.setInitialDelay(300);
/*     */   }
/*     */ 
/*     */   private JSpinner eventToSpinner(AWTEvent e)
/*     */   {
/*  91 */     Object src = e.getSource();
/*  92 */     while (((src instanceof Component)) && (!(src instanceof JSpinner))) {
/*  93 */       src = ((Component)src).getParent();
/*     */     }
/*  95 */     return (src instanceof JSpinner) ? (JSpinner)src : null;
/*     */   }
/*     */ 
/*     */   public void actionPerformed(ActionEvent e)
/*     */   {
/* 100 */     JSpinner aSpinner = this.spinner;
/*     */ 
/* 102 */     if (!(e.getSource() instanceof Timer))
/*     */     {
/* 104 */       aSpinner = eventToSpinner(e);
/*     */     }
/* 106 */     if (aSpinner != null)
/*     */       try {
/* 108 */         int calendarField = getCalendarField(aSpinner);
/* 109 */         aSpinner.commitEdit();
/* 110 */         if (calendarField != -1) {
/* 111 */           ((SpinnerDateModel)aSpinner.getModel()).setCalendarField(calendarField);
/*     */         }
/* 113 */         Object value = this.isNext ? aSpinner.getNextValue() : aSpinner.getPreviousValue();
/* 114 */         if (value != null) {
/* 115 */           aSpinner.setValue(value);
/* 116 */           select(aSpinner);
/*     */         }
/*     */       } catch (IllegalArgumentException iae) {
/* 119 */         UIManager.getLookAndFeel().provideErrorFeedback(aSpinner);
/*     */       } catch (ParseException pe) {
/* 121 */         UIManager.getLookAndFeel().provideErrorFeedback(aSpinner);
/*     */       }
/*     */   }
/*     */ 
/*     */   private void select(JSpinner aSpinner)
/*     */   {
/* 132 */     JComponent editor = aSpinner.getEditor();
/*     */ 
/* 134 */     if ((editor instanceof JSpinner.DateEditor)) {
/* 135 */       JSpinner.DateEditor dateEditor = (JSpinner.DateEditor)editor;
/* 136 */       JFormattedTextField ftf = dateEditor.getTextField();
/* 137 */       Format format = dateEditor.getFormat();
/*     */       Object value;
/* 140 */       if ((format != null) && ((value = aSpinner.getValue()) != null)) {
/* 141 */         SpinnerDateModel model = dateEditor.getModel();
/* 142 */         DateFormat.Field field = DateFormat.Field.ofCalendarField(model.getCalendarField());
/*     */ 
/* 144 */         if (field != null)
/*     */           try {
/* 146 */             AttributedCharacterIterator iterator = 
/* 147 */               format.formatToCharacterIterator(value);
/* 148 */             if ((!select(ftf, iterator, field)) && (field == DateFormat.Field.HOUR0))
/* 149 */               select(ftf, iterator, DateFormat.Field.HOUR1);
/*     */           }
/*     */           catch (IllegalArgumentException localIllegalArgumentException)
/*     */           {
/*     */           }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean select(JFormattedTextField ftf, AttributedCharacterIterator iterator, DateFormat.Field field)
/*     */   {
/* 167 */     int max = ftf.getDocument().getLength();
/*     */ 
/* 169 */     iterator.first();
/*     */     do {
/* 171 */       Map attrs = iterator.getAttributes();
/*     */ 
/* 173 */       if ((attrs != null) && (attrs.containsKey(field))) {
/* 174 */         int start = iterator.getRunStart(field);
/* 175 */         int end = iterator.getRunLimit(field);
/*     */ 
/* 177 */         if ((start != -1) && (end != -1) && (start <= max) && (end <= max)) {
/* 178 */           ftf.select(start, end);
/*     */         }
/* 180 */         return true;
/*     */       }
/*     */     }
/* 182 */     while (iterator.next() != 65535);
/* 183 */     return false;
/*     */   }
/*     */ 
/*     */   private int getCalendarField(JSpinner aSpinner)
/*     */   {
/* 193 */     JComponent editor = aSpinner.getEditor();
/*     */ 
/* 195 */     if ((editor instanceof JSpinner.DateEditor)) {
/* 196 */       JSpinner.DateEditor dateEditor = (JSpinner.DateEditor)editor;
/* 197 */       JFormattedTextField ftf = dateEditor.getTextField();
/* 198 */       int start = ftf.getSelectionStart();
/* 199 */       JFormattedTextField.AbstractFormatter formatter = ftf.getFormatter();
/*     */ 
/* 201 */       if ((formatter instanceof InternationalFormatter)) {
/* 202 */         Format.Field[] fields = ((InternationalFormatter)formatter).getFields(start);
/*     */ 
/* 204 */         for (int counter = 0; counter < fields.length; counter++) {
/* 205 */           if ((fields[counter] instanceof DateFormat.Field))
/*     */           {
/*     */             int calendarField;
/*     */             int calendarField;
/* 208 */             if (fields[counter] == DateFormat.Field.HOUR1)
/* 209 */               calendarField = 10;
/*     */             else {
/* 211 */               calendarField = ((DateFormat.Field)fields[counter]).getCalendarField();
/*     */             }
/* 213 */             if (calendarField != -1) {
/* 214 */               return calendarField;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 220 */     return -1;
/*     */   }
/*     */ 
/*     */   public void mousePressed(MouseEvent e) {
/* 224 */     if ((SwingUtilities.isLeftMouseButton(e)) && (e.getComponent().isEnabled())) {
/* 225 */       this.spinner = eventToSpinner(e);
/* 226 */       this.autoRepeatTimer.start();
/* 227 */       focusSpinnerIfNecessary();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mouseReleased(MouseEvent e) {
/* 232 */     this.autoRepeatTimer.stop();
/* 233 */     this.spinner = null;
/*     */   }
/*     */ 
/*     */   public void mouseClicked(MouseEvent e)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void mouseEntered(MouseEvent e)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void mouseExited(MouseEvent e)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void focusSpinnerIfNecessary()
/*     */   {
/* 254 */     Component fo = KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
/* 255 */     if ((this.spinner.isRequestFocusEnabled()) && (
/* 256 */       (fo == null) || (!SwingUtilities.isDescendingFrom(fo, this.spinner)))) {
/* 257 */       Container root = this.spinner;
/*     */ 
/* 259 */       if (!root.isFocusCycleRoot()) {
/* 260 */         root = root.getFocusCycleRootAncestor();
/*     */       }
/* 262 */       if (root != null) {
/* 263 */         FocusTraversalPolicy ftp = root.getFocusTraversalPolicy();
/* 264 */         Component child = ftp.getComponentAfter(root, this.spinner);
/*     */ 
/* 266 */         if ((child != null) && (SwingUtilities.isDescendingFrom(child, this.spinner)))
/* 267 */           child.requestFocus();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.common.ExtBasicArrowButtonHandler
 * JD-Core Version:    0.6.2
 */