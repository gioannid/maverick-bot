/*     */ package com.jgoodies.looks.common;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicMenuItemUI;
/*     */ 
/*     */ public class ExtBasicMenuItemUI extends BasicMenuItemUI
/*     */ {
/*     */   private static final int MINIMUM_WIDTH = 80;
/*     */   private MenuItemRenderer renderer;
/*     */ 
/*     */   public static ComponentUI createUI(JComponent b)
/*     */   {
/*  61 */     return new ExtBasicMenuItemUI();
/*     */   }
/*     */ 
/*     */   protected void installDefaults() {
/*  65 */     super.installDefaults();
/*  66 */     this.renderer = 
/*  67 */       new MenuItemRenderer(
/*  68 */       this.menuItem, 
/*  69 */       iconBorderEnabled(), 
/*  70 */       this.acceleratorFont, 
/*  71 */       this.selectionForeground, 
/*  72 */       this.disabledForeground, 
/*  73 */       this.acceleratorForeground, 
/*  74 */       this.acceleratorSelectionForeground);
/*  75 */     Integer gap = 
/*  76 */       (Integer)UIManager.get(getPropertyPrefix() + ".textIconGap");
/*  77 */     this.defaultTextIconGap = (gap != null ? gap.intValue() : 2);
/*     */   }
/*     */ 
/*     */   protected boolean iconBorderEnabled()
/*     */   {
/*  82 */     return false;
/*     */   }
/*     */ 
/*     */   protected void uninstallDefaults() {
/*  86 */     super.uninstallDefaults();
/*  87 */     this.renderer = null;
/*     */   }
/*     */ 
/*     */   protected Dimension getPreferredMenuItemSize(JComponent c, Icon aCheckIcon, Icon anArrowIcon, int textIconGap)
/*     */   {
/*  96 */     Dimension size = 
/*  97 */       this.renderer.getPreferredMenuItemSize(
/*  98 */       c, 
/*  99 */       aCheckIcon, 
/* 100 */       anArrowIcon, 
/* 101 */       textIconGap);
/* 102 */     int width = Math.max(80, size.width);
/* 103 */     int height = size.height;
/* 104 */     return new Dimension(width, height);
/*     */   }
/*     */ 
/*     */   protected void paintMenuItem(Graphics g, JComponent c, Icon aCheckIcon, Icon anArrowIcon, Color background, Color foreground, int textIconGap)
/*     */   {
/* 115 */     this.renderer.paintMenuItem(
/* 116 */       g, 
/* 117 */       c, 
/* 118 */       aCheckIcon, 
/* 119 */       anArrowIcon, 
/* 120 */       background, 
/* 121 */       foreground, 
/* 122 */       textIconGap);
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.common.ExtBasicMenuItemUI
 * JD-Core Version:    0.6.2
 */