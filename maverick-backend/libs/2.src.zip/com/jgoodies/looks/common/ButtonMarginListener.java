/*    */ package com.jgoodies.looks.common;
/*    */ 
/*    */ import com.jgoodies.looks.LookUtils;
/*    */ import java.beans.PropertyChangeEvent;
/*    */ import java.beans.PropertyChangeListener;
/*    */ import java.io.Serializable;
/*    */ import javax.swing.AbstractButton;
/*    */ 
/*    */ public final class ButtonMarginListener
/*    */   implements PropertyChangeListener, Serializable
/*    */ {
/*    */   private final String propertyPrefix;
/*    */ 
/*    */   public ButtonMarginListener(String propertyPrefix)
/*    */   {
/* 57 */     this.propertyPrefix = propertyPrefix;
/*    */   }
/*    */ 
/*    */   public void propertyChange(PropertyChangeEvent evt) {
/* 61 */     AbstractButton button = (AbstractButton)evt.getSource();
/* 62 */     if ("jgoodies.isNarrow".equals(evt.getPropertyName()))
/* 63 */       LookUtils.installNarrowMargin(button, this.propertyPrefix);
/*    */   }
/*    */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.jgoodies.looks.common.ButtonMarginListener
 * JD-Core Version:    0.6.2
 */