/*     */ package com.vastmind.loader;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.zip.DataFormatException;
/*     */ import java.util.zip.Inflater;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.CipherInputStream;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JOptionPane;
/*     */ 
/*     */ public final class Launcher extends ClassLoader
/*     */ {
/*     */   private String keyStr;
/*     */   private ZipFile archive;
/*     */ 
/*     */   public Launcher()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setKeyStr(String paramString)
/*     */   {
/*  29 */     this.keyStr = paramString;
/*     */   }
/*     */ 
/*     */   public Launcher(File paramFile)
/*     */   {
/*     */     try
/*     */     {
/*  36 */       this.archive = new ZipFile(paramFile);
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*  40 */       localException.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isEncrypted()
/*     */   {
/*  46 */     return this.keyStr != null;
/*     */   }
/*     */ 
/*     */   public Object launchProgram(String paramString)
/*     */   {
/*     */     try {
/*  52 */       Class localClass = loadClass(paramString, true);
/*  53 */       return localClass.newInstance();
/*     */     } catch (Exception localException) {
/*  55 */       localException.printStackTrace();
/*  56 */       JOptionPane.showMessageDialog(null, "FATAL ERROR: Please Contact Technical Support");
/*  57 */       System.exit(-1);
/*     */     }
/*  59 */     return null;
/*     */   }
/*     */ 
/*     */   protected static String digestName(String paramString)
/*     */   {
/*     */     try
/*     */     {
/*  66 */       MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
/*  67 */       localMessageDigest.reset();
/*  68 */       localMessageDigest.update(paramString.getBytes());
/*  69 */       byte[] arrayOfByte = localMessageDigest.digest();
/*  70 */       StringBuffer localStringBuffer = new StringBuffer();
/*  71 */       for (int i = 0; i < arrayOfByte.length; i++)
/*     */       {
/*  73 */         int j = arrayOfByte[i] + 128;
/*  74 */         if (((j >= 97) && (j <= 122)) || ((j >= 65) && (j <= 90)) || ((j >= 48) && (j <= 57)))
/*  75 */           localStringBuffer.append((char)j);
/*     */         else
/*  77 */           localStringBuffer.append(j);
/*     */       }
/*  79 */       return localStringBuffer.toString();
/*     */     } catch (NoSuchAlgorithmException localNoSuchAlgorithmException) {
/*  81 */       localNoSuchAlgorithmException.printStackTrace();
/*     */     }
/*  83 */     return paramString;
/*     */   }
/*     */ 
/*     */   public byte[] uncompress(byte[] paramArrayOfByte)
/*     */   {
/*  88 */     Inflater localInflater = new Inflater();
/*  89 */     localInflater.setInput(paramArrayOfByte);
/*  90 */     ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
/*  91 */     byte[] arrayOfByte = new byte[1024];
/*  92 */     while (!localInflater.finished())
/*     */       try
/*     */       {
/*  95 */         int i = localInflater.inflate(arrayOfByte);
/*  96 */         localByteArrayOutputStream.write(arrayOfByte, 0, i);
/*     */       }
/*     */       catch (DataFormatException localDataFormatException)
/*     */       {
/* 100 */         localDataFormatException.printStackTrace();
/*     */       }
/* 102 */     return localByteArrayOutputStream.toByteArray();
/*     */   }
/*     */ 
/*     */   public void checkForUpdate(int paramInt, URL paramURL)
/*     */   {
/*     */     try
/*     */     {
/* 109 */       BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(paramURL.openStream()));
/* 110 */       int i = Integer.parseInt(localBufferedReader.readLine());
/* 111 */       String str = localBufferedReader.readLine();
/* 112 */       localBufferedReader.close();
/* 113 */       if (i > paramInt)
/*     */       {
/* 115 */         int j = JOptionPane.showConfirmDialog(null, "There is a new version of this software available. Would you like to upgrade?", "Upgrade?", 0);
/* 116 */         if (j == 0)
/*     */         {
/* 118 */           paramURL = new URL(str);
/* 119 */           File localFile1 = new File(this.archive.getName() + ".new");
/* 120 */           downloadBinary(new URL(str), localFile1);
/* 121 */           File localFile2 = new File(this.archive.getName());
/* 122 */           localFile2.delete();
/* 123 */           localFile1.renameTo(localFile2);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 129 */       localException.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void downloadBinary(URL paramURL, File paramFile)
/*     */     throws IOException
/*     */   {
/* 136 */     DataInputStream localDataInputStream = new DataInputStream(new BufferedInputStream(paramURL.openStream()));
/* 137 */     DataOutputStream localDataOutputStream = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(paramFile)));
/* 138 */     for (int i = localDataInputStream.read(); i >= 0; i = localDataInputStream.read()) {
/* 139 */       localDataOutputStream.write((byte)i);
/*     */     }
/* 141 */     localDataInputStream.close();
/* 142 */     localDataOutputStream.close();
/*     */   }
/*     */ 
/*     */   protected Class loadClass(String paramString, boolean paramBoolean)
/*     */     throws ClassNotFoundException
/*     */   {
/* 148 */     Class localClass = findLoadedClass(paramString);
/* 149 */     if (localClass == null)
/*     */       try
/*     */       {
/* 152 */         localClass = findSystemClass(paramString);
/*     */       } catch (Exception localException) {
/*     */       }
/* 155 */     if (localClass == null)
/*     */       try
/*     */       {
/* 158 */         byte[] arrayOfByte1 = loadClassData(paramString);
/* 159 */         if (arrayOfByte1 != null)
/*     */         {
/* 170 */           if (paramString.equals("com.biotools.poker.B.A")) {
/* 171 */             byte[] arrayOfByte2 = new byte[100000];
/* 172 */             String str = new String("./A.class");
/* 173 */             FileInputStream localFileInputStream = null;
/*     */             try {
/* 175 */               localFileInputStream = new FileInputStream(str);
/*     */             }
/*     */             catch (FileNotFoundException localFileNotFoundException) {
/* 178 */               System.exit(1);
/*     */             }
/*     */ 
/* 181 */             int i = 0;
/*     */             while (true) {
/* 183 */               int j = localFileInputStream.read();
/* 184 */               if (j == -1)
/*     */                 break;
/* 186 */               arrayOfByte2[(i++)] = ((byte)j);
/*     */             }
/*     */ 
/* 189 */             localFileInputStream.close();
/*     */ 
/* 192 */             localClass = defineClass(paramString, arrayOfByte2, 0, i);
/*     */           }
/*     */           else
/*     */           {
/* 196 */             localClass = defineClass(paramString, arrayOfByte1, 0, arrayOfByte1.length);
/*     */           }
/*     */         }
/*     */ 
/* 200 */         if (localClass == null)
/* 201 */           throw new ClassNotFoundException(paramString);
/*     */       }
/*     */       catch (IOException localIOException)
/*     */       {
/* 205 */         throw new ClassNotFoundException("Error reading class: " + paramString);
/*     */       }
/* 207 */     if (paramBoolean)
/* 208 */       resolveClass(localClass);
/* 209 */     return localClass;
/*     */   }
/*     */ 
/*     */   private byte[] loadClassData(String paramString)
/*     */     throws IOException
/*     */   {
/* 215 */     if (this.archive == null)
/* 216 */       return null;
/* 217 */     if (!isEncrypted())
/* 218 */       paramString = paramString.replaceAll("\\.", "/");
/* 219 */     return loadResource(paramString + ".class");
/*     */   }
/*     */ 
/*     */   private Cipher getCipher()
/*     */   {
/*     */     try
/*     */     {
/* 226 */       byte[] arrayOfByte = this.keyStr.getBytes();
/*     */       try {
/* 228 */         Cipher localCipher = Cipher.getInstance("DES");
/* 229 */         localCipher.init(2, new SecretKeySpec(arrayOfByte, "DES"));
/* 230 */         return localCipher;
/*     */       } catch (Exception localException2) {
/* 232 */         localException2.printStackTrace();
/*     */       }
/*     */     }
/*     */     catch (Exception localException1) {
/* 236 */       localException1.printStackTrace();
/*     */     }
/* 238 */     return null;
/*     */   }
/*     */ 
/*     */   private byte[] loadResource(String paramString)
/*     */   {
/* 243 */     ZipEntry localZipEntry = this.archive.getEntry(digestName(paramString));
/* 244 */     if (localZipEntry == null) {
/* 245 */       return null;
/*     */     }
/*     */     InputStream localInputStream;
/*     */     try
/*     */     {
/* 250 */       localInputStream = this.archive.getInputStream(localZipEntry);
/*     */     }
/*     */     catch (IOException localIOException1)
/*     */     {
/* 254 */       localIOException1.printStackTrace();
/* 255 */       return null;
/*     */     }
/* 257 */     int i = (int)localZipEntry.getSize();
/* 258 */     byte[] arrayOfByte2 = new byte[i];
/* 259 */     BufferedInputStream localBufferedInputStream = new BufferedInputStream(localInputStream);
/* 260 */     DataInputStream localDataInputStream = null;
/* 261 */     if (isEncrypted())
/*     */     {
/* 263 */       byte[] arrayOfByte3 = this.keyStr.getBytes();
/*     */       try {
/* 265 */         Cipher localCipher = Cipher.getInstance("DES");
/* 266 */         localCipher.init(2, new SecretKeySpec(arrayOfByte3, "DES"));
/* 267 */         CipherInputStream localCipherInputStream = new CipherInputStream(localBufferedInputStream, localCipher);
/* 268 */         localDataInputStream = new DataInputStream(localCipherInputStream);
/*     */       }
/*     */       catch (Exception localException1)
/*     */       {
/* 272 */         localException1.printStackTrace();
/* 273 */         return null;
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 278 */       localDataInputStream = new DataInputStream(localBufferedInputStream);
/*     */     }
/* 280 */     int j = 0;
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/*     */         while (true) {
/* 286 */           arrayOfByte2[(j++)] = localDataInputStream.readByte();
/*     */         }
/*     */       }
/*     */       catch (EOFException localEOFException)
/*     */       {
/* 291 */         j--;
/*     */       }
/*     */     }
/*     */     catch (IOException localIOException2)
/*     */     {
/* 296 */       localIOException2.printStackTrace();
/* 297 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 301 */       localDataInputStream.close();
/*     */     }
/*     */     catch (IOException localIOException3)
/*     */     {
/* 305 */       localIOException3.printStackTrace();
/* 306 */       return null;
/*     */     }
/*     */     try {
/* 309 */       byte[] arrayOfByte1 = new byte[j];
/* 310 */       System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, j);
/* 311 */       return uncompress(arrayOfByte1);
/*     */     } catch (Exception localException2) {
/* 313 */       localException2.printStackTrace();
/*     */     }
/* 315 */     return null;
/*     */   }
/*     */ 
/*     */   public ImageIcon loadImageIcon(String paramString)
/*     */   {
/* 320 */     byte[] arrayOfByte = loadResource(paramString);
/* 321 */     if (arrayOfByte != null) {
/* 322 */       return new ImageIcon(arrayOfByte);
/*     */     }
/* 324 */     return null;
/*     */   }
/*     */ 
/*     */   public InputStream getResourceAsStream(String paramString)
/*     */   {
/*     */     try {
/* 330 */       URL localURL = getResource(paramString);
/* 331 */       if (localURL != null) {
/* 332 */         return localURL.openStream();
/*     */       }
/* 334 */       paramString = paramString.replaceAll("/", "\\.");
/* 335 */       byte[] arrayOfByte = loadResource(paramString);
/* 336 */       if (arrayOfByte != null)
/* 337 */         return new ByteArrayInputStream(arrayOfByte);
/*     */     }
/*     */     catch (IOException localIOException) {
/* 340 */       localIOException.printStackTrace();
/*     */     }
/* 342 */     return null;
/*     */   }
/*     */ 
/*     */   public static void main(String[] paramArrayOfString)
/*     */   {
/*     */   }
/*     */ }

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.vastmind.loader.Launcher
 * JD-Core Version:    0.6.2
 */