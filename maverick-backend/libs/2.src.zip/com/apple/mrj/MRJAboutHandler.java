package com.apple.mrj;

public abstract interface MRJAboutHandler
{
  public abstract void handleAbout();
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.apple.mrj.MRJAboutHandler
 * JD-Core Version:    0.6.2
 */