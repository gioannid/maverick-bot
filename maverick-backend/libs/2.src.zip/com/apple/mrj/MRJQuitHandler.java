package com.apple.mrj;

public abstract interface MRJQuitHandler
{
  public abstract void handleQuit();
}

/* Location:           E:\pokeracademy\2.jar
 * Qualified Name:     com.apple.mrj.MRJQuitHandler
 * JD-Core Version:    0.6.2
 */